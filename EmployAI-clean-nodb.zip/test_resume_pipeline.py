import unittest
import json
from app.services.resume_parser_service import ResumeParserService
from app.services.document_service import DocumentService
from app.services.ai_service import AIService
from app.schemas.document import StructuredResumeData


class TestResumePipeline(unittest.TestCase):
    """
    Comprehensive cross-domain and anti-hallucination test suite for EmployAI.
    Verifies that the uploaded document is the SINGLE SOURCE OF TRUTH.
    """

    def test_01_btech_cse_candidate(self):
        """TEST 1: B.Tech CSE Candidate extracts software skills and detects CSE domain."""
        resume_text = """
        Arjun Mehta
        arjun.mehta@cse-example.com | +91 91234 56789 | Mumbai, India
        LinkedIn: linkedin.com/in/arjun-cse-dev | GitHub: github.com/arjun-dev

        PROFESSIONAL SUMMARY
        Full stack software engineer experienced in scalable web systems, backend APIs, and containerized microservices.

        EDUCATION
        Bachelor of Technology in Computer Science
        Indian Institute of Technology Bombay | 2020 - 2024 | CGPA: 8.9 / 10

        SKILLS
        Python, JavaScript, TypeScript, React, FastAPI, PostgreSQL, Docker, Kubernetes, Git

        EXPERIENCE
        Software Engineering Intern | TechCorp India | Jan 2024 - Jun 2024
        • Developed high-performance REST APIs using FastAPI and PostgreSQL handling 50,000+ daily requests.
        • Containerized microservices using Docker and automated CI/CD deployment pipelines.

        PROJECTS
        Distributed Task Queue
        • Built an asynchronous task distribution system using Python and Redis with 99.9% uptime.
        """
        structured, metrics = ResumeParserService.parse_resume(resume_text)

        self.assertEqual(structured.personal_info.full_name, "Arjun Mehta")
        self.assertEqual(structured.personal_info.email, "arjun.mehta@cse-example.com")
        self.assertEqual(metrics["detected_domain"], "Computer Science")
        self.assertIn("Python", structured.skills)
        self.assertIn("FastAPI", structured.skills)
        self.assertIn("Docker", structured.skills)
        self.assertIn("React", structured.skills)

    def test_02_bcom_finance_candidate(self):
        """TEST 2: B.Com candidate extracts accounting/finance skills and ZERO CS technologies."""
        resume_text = """
        Priya Sharma
        priya.finance@commerce-example.com | +91 98111 22334 | New Delhi, India
        LinkedIn: linkedin.com/in/priya-finance

        PROFESSIONAL SUMMARY
        Detail-oriented commerce graduate with strong expertise in financial accounting, statutory auditing, and taxation.

        EDUCATION
        Bachelor of Commerce (B.Com) in Accounting & Finance
        Shri Ram College of Commerce | 2021 - 2024 | Score: 88%

        SKILLS
        Tally Prime, Financial Accounting, Auditing, Taxation, GST Compliance, Advanced Excel, Balance Sheet Analysis

        EXPERIENCE
        Audit Assistant Intern | Mehta & Associates CA Firm | Jun 2023 - Dec 2023
        • Prepared balance sheets and profit & loss statements for 25+ corporate clients using Tally Prime.
        • Reconciled bank accounts and audited GST tax returns ensuring 100% statutory compliance.

        PROJECTS
        Corporate Working Capital Optimization
        • Conducted financial modeling and cash flow analysis using Advanced Excel for retail suppliers.
        """
        structured, metrics = ResumeParserService.parse_resume(resume_text)

        self.assertEqual(structured.personal_info.full_name, "Priya Sharma")
        self.assertEqual(structured.personal_info.email, "priya.finance@commerce-example.com")
        self.assertEqual(metrics["detected_domain"], "Finance & Commerce")
        self.assertIn("Tally Prime", structured.skills)
        self.assertIn("Financial Accounting", structured.skills)
        self.assertIn("Auditing", structured.skills)
        self.assertIn("GST Compliance", structured.skills)

        # STRICT GUARANTEE: Zero CS technologies must be present
        for forbidden in ["Python", "React", "Docker", "Kubernetes", "C++", "FastAPI", "SolidWorks"]:
            self.assertNotIn(forbidden, structured.skills, f"Hallucinated skill '{forbidden}' found in B.Com resume!")

    def test_03_civil_engineering_candidate(self):
        """TEST 3: Civil Engineering candidate extracts civil skills without CS template."""
        resume_text = """
        Rahul Verma
        rahul.civil@infra-example.com | +91 97777 88899 | Hyderabad, India

        EDUCATION
        Bachelor of Technology in Civil Engineering
        National Institute of Technology Warangal | 2020 - 2024 | CGPA: 8.4

        SKILLS
        Revit, BIM, STAAD.Pro, Structural Analysis, Quantity Surveying, Total Station, Estimation & Costing

        EXPERIENCE
        Site Engineering Trainee | L&T Construction | May 2023 - Jul 2023
        • Assisted in structural analysis and load calculation using STAAD.Pro for multi-story residential towers.
        • Supervised on-site concrete casting and reinforced concrete quality testing.

        PROJECTS
        BIM-Based Clash Detection Model
        • Modeled 3D architectural and structural MEP elements in Revit eliminating 40+ layout clashes.
        """
        structured, metrics = ResumeParserService.parse_resume(resume_text)

        self.assertEqual(structured.personal_info.full_name, "Rahul Verma")
        self.assertEqual(metrics["detected_domain"], "Civil Engineering")
        self.assertIn("Revit", structured.skills)
        self.assertIn("BIM", structured.skills)
        self.assertIn("STAAD.Pro", structured.skills)
        self.assertIn("Quantity Surveying", structured.skills)

        for forbidden in ["Python", "React", "Docker", "Tally Prime", "Corporate Law"]:
            self.assertNotIn(forbidden, structured.skills)

    def test_04_mechanical_engineering_candidate(self):
        """TEST 4: Mechanical Engineering candidate extracts CAD/CAE competencies."""
        resume_text = """
        Vikram Patel
        vikram.mech@auto-example.com | +91 93333 44455 | Pune, India

        EDUCATION
        Bachelor of Technology in Mechanical Engineering
        College of Engineering Pune | 2020 - 2024

        SKILLS
        SolidWorks, CATIA, ANSYS, FEA, GD&T, ASME Y14.5, Thermodynamics, CNC Programming

        PROJECTS
        Formula Student Chassis Optimization
        • Designed 3D tubular spaceframe in SolidWorks and performed FEA structural stress simulation in ANSYS.
        """
        structured, metrics = ResumeParserService.parse_resume(resume_text)

        self.assertEqual(structured.personal_info.full_name, "Vikram Patel")
        self.assertEqual(metrics["detected_domain"], "Mechanical Engineering")
        self.assertIn("SolidWorks", structured.skills)
        self.assertIn("ANSYS", structured.skills)
        self.assertIn("FEA", structured.skills)
        self.assertIn("GD&T", structured.skills)

    def test_05_ba_llb_legal_candidate(self):
        """TEST 5: BA LLB candidate extracts legal terminology and law domain."""
        resume_text = """
        Ananya Iyer
        ananya.law@legal-example.com | +91 94444 55566 | New Delhi, India

        EDUCATION
        BA LLB (Honours) in Corporate Law
        National Law University Delhi | 2019 - 2024 | CGPA: 7.8

        SKILLS
        Corporate Law, Contract Drafting, Legal Research, Due Diligence, Arbitration, Manupatra, SCC Online

        EXPERIENCE
        Legal Intern | Shardul Amarchand Mangaldas | Jan 2024 - Apr 2024
        • Conducted legal due diligence and drafted non-disclosure agreements and commercial vendor contracts.
        • Researched case law precedents using Manupatra and SCC Online for appellate tribunal hearings.
        """
        structured, metrics = ResumeParserService.parse_resume(resume_text)

        self.assertEqual(structured.personal_info.full_name, "Ananya Iyer")
        self.assertEqual(metrics["detected_domain"], "Law & Legal")
        self.assertIn("Corporate Law", structured.skills)
        self.assertIn("Contract Drafting", structured.skills)
        self.assertIn("Legal Research", structured.skills)

    def test_06_bba_management_candidate(self):
        """TEST 6: BBA candidate extracts marketing, analytics and management skills."""
        resume_text = """
        Rohan Das
        rohan.bba@biz-example.com | +91 95555 66677

        EDUCATION
        Bachelor of Business Administration (BBA)
        Symbiosis Institute of Business Studies | 2021 - 2024

        SKILLS
        Digital Marketing, Market Research, SEO, Google Analytics, CRM, Salesforce, Agile

        PROJECTS
        Omnichannel Consumer Growth Strategy
        • Formulated SEO strategy and Google Analytics conversion funnel boosting organic leads by 35%.
        """
        structured, metrics = ResumeParserService.parse_resume(resume_text)

        self.assertEqual(structured.personal_info.full_name, "Rohan Das")
        self.assertIn("Digital Marketing", structured.skills)
        self.assertIn("Market Research", structured.skills)
        self.assertIn("SEO", structured.skills)

    def test_07_resume_with_no_email_returns_none(self):
        """TEST 7: Resume with no email address returns email=None, NEVER a fake email."""
        resume_text = """
        Kavita Nair
        Phone: +91 90000 11111 | Bengaluru, India

        EDUCATION
        Bachelor of Science in Mathematics | 2020 - 2023

        SKILLS
        Advanced Excel, Data Analytics, Tableau
        """
        structured, _ = ResumeParserService.parse_resume(resume_text)

        self.assertEqual(structured.personal_info.full_name, "Kavita Nair")
        self.assertIsNone(structured.personal_info.email, "Email must be None when absent from resume!")
        self.assertNotEqual(structured.personal_info.email, "akhtarkeeb52@gmail.com")
        self.assertNotEqual(structured.personal_info.email, "candidate@employai.edu")

    def test_08_resume_with_no_github_returns_none(self):
        """TEST 8: Resume with no GitHub returns github=None, NEVER a fake github URL."""
        resume_text = """
        Suresh Menon
        suresh@menon-consulting.com | +91 92222 33333

        EDUCATION
        Master of Business Administration (MBA) in Operations
        IIM Kozhikode | 2022 - 2024

        SKILLS
        Supply Chain Management, Logistics, Inventory Management
        """
        structured, _ = ResumeParserService.parse_resume(resume_text)

        self.assertIsNone(structured.personal_info.github, "GitHub must be None when absent from resume!")
        self.assertNotEqual(structured.personal_info.github, "github.com/engineering-candidate")

    def test_09_candidate_name_dynamically_extracted(self):
        """TEST 9: Candidate name is extracted dynamically without hardcoded fallback."""
        resume_text = """
        Dr. Sunita Deshmukh
        sunita@pharma-research.org | +91 96666 77788

        EDUCATION
        Bachelor of Pharmacy (B.Pharm) | 2018 - 2022

        SKILLS
        Pharmacology, Clinical Research, Medical Diagnostics, Drug Formulation
        """
        structured, _ = ResumeParserService.parse_resume(resume_text)

        self.assertEqual(structured.personal_info.full_name, "Dr Sunita Deshmukh")
        self.assertNotEqual(structured.personal_info.full_name, "Raza")
        self.assertNotEqual(structured.personal_info.full_name, "Engineering Candidate")

    def test_10_consecutive_upload_isolation(self):
        """TEST 10: Parsing Resume B after Resume A completely isolates candidate data."""
        resume_a = """
        Alice Smith
        alice@developer-corp.com | +91 99999 00001
        GitHub: github.com/alice-dev

        EDUCATION
        B.Tech Computer Science | 2020 - 2024
        SKILLS: Python, FastAPI, Docker
        """
        resume_b = """
        Bob Johnson
        bob@accounting-firm.com | +91 99999 00002

        EDUCATION
        Bachelor of Commerce (B.Com) | 2021 - 2024
        SKILLS: Tally Prime, Financial Accounting, Auditing
        """
        struct_a, _ = ResumeParserService.parse_resume(resume_a)
        struct_b, _ = ResumeParserService.parse_resume(resume_b)

        # Verify A
        self.assertEqual(struct_a.personal_info.full_name, "Alice Smith")
        self.assertEqual(struct_a.personal_info.email, "alice@developer-corp.com")
        self.assertEqual(struct_a.personal_info.github, "github.com/alice-dev")
        self.assertIn("Python", struct_a.skills)

        # Verify B has ZERO leakage from A
        self.assertEqual(struct_b.personal_info.full_name, "Bob Johnson")
        self.assertEqual(struct_b.personal_info.email, "bob@accounting-firm.com")
        self.assertIsNone(struct_b.personal_info.github)
        self.assertIn("Tally Prime", struct_b.skills)
        self.assertNotIn("Python", struct_b.skills)
        self.assertNotIn("FastAPI", struct_b.skills)
        self.assertNotIn("Docker", struct_b.skills)

    def test_11_critical_acceptance_test(self):
        """
        TEST 11: CRITICAL ACCEPTANCE TEST
        Upload resume with unique values:
        - Name: TEST CANDIDATE ALPHA
        - Email: alpha.unique@example.com
        - Degree: B.Com
        - Skill: Tally Prime
        - Project: Retail Inventory Analysis
        
        Must NOT contain: Raza, akhtarkeeb52@gmail.com, Python, React, Docker, Cloud Computing, Bengaluru.
        """
        resume_text = """
        TEST CANDIDATE ALPHA
        alpha.unique@example.com | +91 98888 77777 | Chandigarh, India

        PROFESSIONAL SUMMARY
        Commerce and financial analytics graduate specializing in statutory compliance and corporate accounting.

        EDUCATION
        Bachelor of Commerce (B.Com)
        Panjab University | 2021 - 2024 | CGPA: 8.5

        SKILLS
        Tally Prime, Financial Accounting, Advanced Excel, Taxation

        PROJECTS
        Retail Inventory Analysis
        • Analyzed 10,000+ SKU inventory records using Tally Prime and Advanced Excel reducing stockout discrepancies.
        """
        structured, metrics = ResumeParserService.parse_resume(resume_text)
        serialized_json = json.dumps(structured.model_dump())

        # Assert correct presence
        self.assertEqual(structured.personal_info.full_name, "TEST CANDIDATE ALPHA")
        self.assertEqual(structured.personal_info.email, "alpha.unique@example.com")
        self.assertEqual(structured.personal_info.location, "Chandigarh, India")
        self.assertIn("Tally Prime", structured.skills)
        self.assertEqual(structured.projects[0].title, "Retail Inventory Analysis")
        self.assertEqual(metrics["detected_domain"], "Finance & Commerce")

        # Assert absolute absence of demo/hardcoded values
        forbidden_strings = [
            "Raza",
            "akhtarkeeb52@gmail.com",
            "Python",
            "React",
            "Docker",
            "Cloud Computing",
            "Bengaluru",
            "engineering-candidate",
            "SolidWorks",
            "CAD & Simulation Software"
        ]
        for forbidden in forbidden_strings:
            self.assertNotIn(
                forbidden,
                serialized_json,
                f"CRITICAL REGRESSION: Hardcoded/demo string '{forbidden}' leaked into structured resume JSON!"
            )

    def test_12_candidate_headline_and_exact_phone_extraction(self):
        """TEST 12: Verifies exact phone number and candidate role headline extraction."""
        resume_text = """
        Rohit Sen
        AI/ML Engineer | Software Developer
        rohit.sen@aiml-dev.io | +91 98765 43210 | Bengaluru, India
        LinkedIn: linkedin.com/in/rohit-sen-dev | GitHub: github.com/rohit-aiml

        PROFESSIONAL SUMMARY
        AI/ML engineer and full stack developer specializing in LLMs, computer vision, and high-throughput Python backends.

        SKILLS
        Python, PyTorch, TensorFlow, FastAPI, React, Docker, SQL, Machine Learning, Deep Learning

        EXPERIENCE
        AI Software Developer | NeuralTech Labs | Jan 2025 - Present
        • Built scalable neural inference service reducing latency by 45%.
        """
        structured, metrics = ResumeParserService.parse_resume(resume_text)

        self.assertEqual(structured.personal_info.full_name, "Rohit Sen")
        self.assertEqual(structured.personal_info.headline, "AI/ML Engineer | Software Developer")
        self.assertEqual(structured.personal_info.title, "AI/ML Engineer | Software Developer")
        self.assertEqual(structured.personal_info.phone, "+91 98765 43210")
        self.assertEqual(structured.personal_info.email, "rohit.sen@aiml-dev.io")
        self.assertEqual(metrics["detected_domain"], "Computer Science")

    def test_13_dedicated_portfolio_section_extraction(self):
        """TEST 13: Verifies that a section named 'PORTFOLIO' extracts into structured.portfolio."""
        resume_text = """
        Siddharth Roy
        Software Developer & ML Engineer
        siddharth@roy-tech.dev | 9876543210 | Pune, India
        Portfolio: https://siddharth-portfolio.vercel.app

        PORTFOLIO
        AI Vision Studio [React, FastAPI, PyTorch]
        https://aivision.live
        • Engineered interactive computer vision playground handling 10,000+ monthly model inferences.
        • Published code repository at github.com/siddharth/ai-vision-studio.

        Full Stack Cloud Platform
        https://cloudplat.app
        • Deployed resilient microservices architecture with 99.9% uptime.

        SKILLS
        Python, React, TypeScript, FastAPI, PyTorch, Docker, Git
        """
        structured, metrics = ResumeParserService.parse_resume(resume_text)

        self.assertEqual(structured.personal_info.full_name, "Siddharth Roy")
        self.assertEqual(structured.personal_info.headline, "Software Developer & ML Engineer")
        self.assertEqual(structured.personal_info.phone, "9876543210")
        self.assertEqual(structured.personal_info.portfolio, "https://siddharth-portfolio.vercel.app")
        
        # Verify dedicated portfolio items
        self.assertGreaterEqual(len(structured.portfolio), 1)
        self.assertEqual(structured.portfolio[0].title, "AI Vision Studio")
        self.assertIn("React", structured.portfolio[0].technologies)
        self.assertEqual(structured.portfolio[0].url, "https://aivision.live")

    def test_14_unlabeled_phone_numbers_and_international_formats(self):
        """TEST 14: Verifies various phone formatting without labels or with international codes."""
        test_cases = [
            ("Candidate A\n+91-98765-43210 | a@test.com", "+91-98765-43210"),
            ("Candidate B\n(555) 123-4567 • b@test.com", "(555) 123-4567"),
            ("Candidate C\nPhone: +44 7911 123456\nc@test.com", "+44 7911 123456"),
            ("Candidate D\nMob: 9123456789\nd@test.com", "9123456789")
        ]
        for text, expected_phone in test_cases:
            struct, _ = ResumeParserService.parse_resume(text)
            self.assertEqual(struct.personal_info.phone, expected_phone)

    def test_15_multiple_internships_extraction_zero_hallucination(self):
        """TEST 15: Verifies that multiple internships (e.g. 2 internships) are distinctly extracted with full details and zero hallucination."""
        resume_text = """
        Raza Akhtar
        raza@example.com | +91 9876543210 | New Delhi, India
        LinkedIn: linkedin.com/in/raza-akhtar | GitHub: github.com/raza-akhtar

        PROFESSIONAL SUMMARY
        Full stack developer and machine learning enthusiast experienced in React, TypeScript, Python, and PyTorch.

        SKILLS
        React, TypeScript, Python, PyTorch, FastAPI, Docker, Tailwind CSS, PostgreSQL

        INTERNSHIPS
        Full Stack Engineering Intern | TechNova Solutions
        May 2024 - July 2024
        • Architected responsive frontend components in React and TypeScript improving load times by 40%.
        • Integrated real-time WebSocket communication for multi-user collaboration.

        Machine Learning Research Intern | AI Frontier Labs
        Jan 2024 - April 2024
        • Developed transformer-based NLP classification models with 95.2% precision using PyTorch.
        • Deployed containerized inference microservices with FastAPI and Docker.

        EDUCATION
        Bachelor of Technology in Computer Science
        Delhi Technological University | 2021 - 2025 | CGPA: 9.1
        """
        structured, metrics = ResumeParserService.parse_resume(resume_text)

        self.assertEqual(structured.personal_info.full_name, "Raza Akhtar")
        self.assertEqual(len(structured.experience), 2)
        
        # Internship 1
        intern1 = structured.experience[0]
        self.assertIn("Full Stack", intern1.role)
        self.assertIn("TechNova Solutions", intern1.company)
        self.assertIn("May 2024", intern1.duration)
        self.assertGreaterEqual(len(intern1.bullets), 2)
        self.assertIn("React", intern1.bullets[0])

        # Internship 2
        intern2 = structured.experience[1]
        self.assertIn("Machine Learning", intern2.role)
        self.assertIn("AI Frontier Labs", intern2.company)
        self.assertIn("Jan 2024", intern2.duration)
        self.assertGreaterEqual(len(intern2.bullets), 2)
        self.assertIn("PyTorch", intern2.bullets[0])


if __name__ == "__main__":
    unittest.main()

