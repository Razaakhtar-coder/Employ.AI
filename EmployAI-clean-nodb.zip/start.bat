@echo off
title EmployAI Fullstack Launcher
echo ===============================================================
echo   EmployAI - Starting Backend ^& Frontend Services
echo ===============================================================
echo.

node run-all.js

pause
