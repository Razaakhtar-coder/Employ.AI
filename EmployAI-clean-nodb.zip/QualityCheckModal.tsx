import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import type { QualityCheckResult, QualityIssueItem, StructuredResume } from '../types';
import { documentApi } from '../services/api';
import { 
  ShieldCheck, AlertCircle, Check, 
  X, RefreshCw, CheckCircle2, Zap
} from 'lucide-react';
import { FuturisticLoader } from './FuturisticLoader';

export interface QualityCheckModalProps {
  isOpen: boolean;
  onClose: () => void;
  structuredResume: StructuredResume | null;
  targetJob?: string;
  onApplyFix?: (issue: QualityIssueItem) => void;
}

export const QualityCheckModal: React.FC<QualityCheckModalProps> = ({
  isOpen,
  onClose,
  structuredResume,
  targetJob,
  onApplyFix,
}) => {
  const [result, setResult] = useState<QualityCheckResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [appliedIssueIds, setAppliedIssueIds] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  const runQualityAudit = async () => {
    if (!structuredResume) return;
    try {
      setIsLoading(true);
      setError(null);
      const res = await documentApi.qualityCheck({
        structured_resume: structuredResume,
        target_job_description: targetJob
      });
      setResult(res);
    } catch (err: any) {
      setError(err?.message || 'Failed to execute resume quality check.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && structuredResume) {
      runQualityAudit();
    }
  }, [isOpen, structuredResume]);

  if (!isOpen) return null;

  const handleFix = (issue: QualityIssueItem) => {
    if (onApplyFix) {
      onApplyFix(issue);
      setAppliedIssueIds(prev => [...prev, issue.id]);
    }
  };

  const issues = result?.issues || [];
  const filteredIssues = filterCategory === 'all' 
    ? issues 
    : issues.filter(i => i.category === filterCategory);

  const getSeverityBadge = (sev: string) => {
    switch (sev) {
      case 'high':
        return <span className="badge badge-danger" style={{ fontSize: '0.65rem' }}>High Priority</span>;
      case 'medium':
        return <span className="badge badge-warning" style={{ fontSize: '0.65rem' }}>Medium</span>;
      case 'low':
        return <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>Suggestion</span>;
      default:
        return <span className="badge badge-secondary" style={{ fontSize: '0.65rem' }}>Info</span>;
    }
  };

  const modalNode = (
    <div 
      className="modal-backdrop" 
      onClick={onClose} 
      style={{ 
        position: 'fixed',
        inset: 0,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100vw',
        height: '100vh',
        backgroundColor: 'rgba(3, 7, 18, 0.82)',
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 99999,
        padding: '1.25rem',
        boxSizing: 'border-box'
      }}
    >
      <div 
        className="glass-card modal-content" 
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '92%',
          maxWidth: '860px',
          maxHeight: '88vh',
          display: 'flex',
          flexDirection: 'column',
          padding: '1.75rem',
          borderRadius: '16px',
          background: 'var(--bg-modal)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-modal)',
          boxSizing: 'border-box'
        }}
      >
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div style={{ padding: '0.45rem', borderRadius: '10px', background: 'rgba(56, 189, 248, 0.12)', color: 'var(--accent-cyan)' }}>
              <ShieldCheck size={22} />
            </div>
            <div>
              <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                Resume Quality Check
              </h2>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                Deep audit for weak verbs, repetition, bullet length, metrics density, and formatting.
              </p>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <button
              type="button"
              onClick={runQualityAudit}
              className="btn btn-secondary btn-sm"
              disabled={isLoading}
              style={{ fontSize: '0.72rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
            >
              <RefreshCw size={12} className={isLoading ? 'animate-spin-slow' : ''} />
              Re-Audit
            </button>
            <button
              type="button"
              onClick={onClose}
              className="btn btn-ghost btn-sm"
              style={{ padding: '0.35rem', color: 'var(--text-muted)' }}
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {error && (
          <div style={{ padding: '0.6rem 0.85rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.1)', border: '1px solid rgba(244, 63, 94, 0.3)', color: '#fb7185', fontSize: '0.78rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <AlertCircle size={14} />
            <span>{error}</span>
          </div>
        )}

        {/* Quality Scorecard Overview */}
        {result && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: '0.65rem', marginBottom: '1.15rem' }}>
            <div style={{ padding: '0.75rem', borderRadius: '10px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', textAlign: 'center' }}>
              <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>Quality Score</div>
              <div style={{ fontSize: '1.4rem', fontWeight: 900, color: result.overall_score >= 80 ? 'var(--accent-emerald)' : 'var(--accent-amber)', marginTop: '0.15rem' }}>
                {Math.round(result.overall_score)}%
              </div>
            </div>

            <div style={{ padding: '0.75rem', borderRadius: '10px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', textAlign: 'center' }}>
              <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>Total Issues</div>
              <div style={{ fontSize: '1.4rem', fontWeight: 900, color: result.total_issues_count === 0 ? 'var(--accent-emerald)' : 'var(--accent-cyan)', marginTop: '0.15rem' }}>
                {result.total_issues_count}
              </div>
            </div>

            <div style={{ padding: '0.75rem', borderRadius: '10px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', textAlign: 'center' }}>
              <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>Weak Verbs</div>
              <div style={{ fontSize: '1.4rem', fontWeight: 900, color: result.weak_verbs_count > 0 ? 'var(--accent-rose)' : 'var(--accent-emerald)', marginTop: '0.15rem' }}>
                {result.weak_verbs_count}
              </div>
            </div>

            <div style={{ padding: '0.75rem', borderRadius: '10px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', textAlign: 'center' }}>
              <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>Repetitions</div>
              <div style={{ fontSize: '1.4rem', fontWeight: 900, color: result.repetition_count > 0 ? 'var(--accent-amber)' : 'var(--accent-emerald)', marginTop: '0.15rem' }}>
                {result.repetition_count}
              </div>
            </div>

            <div style={{ padding: '0.75rem', borderRadius: '10px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', textAlign: 'center' }}>
              <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>Metrics Density</div>
              <div style={{ fontSize: '1.4rem', fontWeight: 900, color: result.metrics_density_pct >= 40 ? 'var(--accent-emerald)' : 'var(--text-muted)', marginTop: '0.15rem' }}>
                {Math.round(result.metrics_density_pct)}%
              </div>
            </div>
          </div>
        )}

        {/* Category Filters */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap', marginBottom: '1rem' }}>
          {[
            { id: 'all', label: 'All Issues' },
            { id: 'weak_verbs', label: 'Weak Action Verbs' },
            { id: 'repetition', label: 'Repetitions' },
            { id: 'overly_long', label: 'Overly Long Bullets' },
            { id: 'missing_metrics', label: 'Missing Metrics' },
            { id: 'formatting', label: 'Formatting' },
          ].map(c => (
            <button
              key={c.id}
              type="button"
              onClick={() => setFilterCategory(c.id)}
              className={`btn btn-sm ${filterCategory === c.id ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.72rem', padding: '0.25rem 0.55rem' }}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Issues List */}
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '0.75rem', paddingRight: '0.35rem' }}>
          {isLoading ? (
            <div style={{ textAlign: 'center', padding: '2.5rem 1rem' }}>
              <FuturisticLoader
                size="sm"
                icon="shield"
                title="Auditing Resume Quality..."
                subtitle="Analyzing weak verbs, repetition density, and ATS readability"
              />
            </div>
          ) : filteredIssues.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '3rem 1rem', color: 'var(--text-muted)' }}>
              <CheckCircle2 size={36} color="var(--accent-emerald)" style={{ margin: '0 auto 0.75rem auto' }} />
              <h4 style={{ color: 'var(--text-primary)', marginBottom: '0.25rem' }}>No quality issues found!</h4>
              <p style={{ fontSize: '0.8rem', maxWidth: '360px', margin: '0 auto' }}>
                {filterCategory === 'all' ? 'Your resume meets high ATS readability and action verb standards.' : 'No issues found in this category.'}
              </p>
            </div>
          ) : (
            filteredIssues.map((issue) => {
              const isApplied = appliedIssueIds.includes(issue.id);

              return (
                <div
                  key={issue.id}
                  style={{
                    padding: '0.95rem 1.15rem',
                    borderRadius: '10px',
                    background: 'var(--bg-tertiary)',
                    border: '1px solid var(--border-subtle)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '0.45rem'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                      {getSeverityBadge(issue.severity)}
                      <h4 style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                        {issue.issue_title}
                      </h4>
                      {issue.location && (
                        <span style={{ fontSize: '0.72rem', color: 'var(--accent-cyan)' }}>
                          in {issue.location}
                        </span>
                      )}
                    </div>

                    {issue.suggested_fix && onApplyFix && (
                      <button
                        type="button"
                        onClick={() => handleFix(issue)}
                        disabled={isApplied}
                        className={`btn btn-sm ${isApplied ? 'btn-secondary' : 'btn-emerald'}`}
                        style={{ fontSize: '0.72rem', padding: '0.2rem 0.55rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                      >
                        {isApplied ? <Check size={11} /> : <Zap size={11} />}
                        {isApplied ? 'Applied' : 'Apply Fix'}
                      </button>
                    )}
                  </div>

                  {issue.snippet && (
                    <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', background: 'var(--bg-inset)', padding: '0.35rem 0.6rem', borderRadius: '6px', fontStyle: 'italic', border: '1px solid var(--border-subtle)' }}>
                      "{issue.snippet}"
                    </div>
                  )}

                  <div style={{ fontSize: '0.8rem', color: 'var(--text-primary)', lineHeight: 1.45 }}>
                    <strong style={{ color: 'var(--accent-amber)' }}>Recommendation: </strong>
                    {issue.recommendation}
                  </div>

                  {issue.suggested_fix && (
                    <div style={{ fontSize: '0.8rem', color: 'var(--accent-emerald)', background: 'rgba(16, 185, 129, 0.08)', padding: '0.4rem 0.65rem', borderRadius: '6px', border: '1px solid rgba(16, 185, 129, 0.25)' }}>
                      <strong>Suggested Wording: </strong>
                      {issue.suggested_fix}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', paddingTop: '1rem', borderTop: '1px solid var(--border-subtle)', marginTop: '0.75rem' }}>
          <button
            type="button"
            onClick={onClose}
            className="btn btn-secondary btn-sm"
          >
            Close Audit
          </button>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalNode, document.body) : modalNode;
};
