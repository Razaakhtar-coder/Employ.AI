import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import type { SavedResumeItem } from '../types';
import { documentApi, clearAllResumeStorage } from '../services/api';
import { 
  FolderKanban, Plus, Copy, Trash2, Edit2, Check, X, 
  Search, FileText, Clock, ArrowRight, RefreshCw, AlertCircle
} from 'lucide-react';
import { FuturisticLoader } from './FuturisticLoader';

export interface MyResumesModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentDocumentId?: string;
  onOpenResume: (documentId: string) => Promise<void>;
  onUploadNew: () => void;
  onDeleteCurrentResume?: () => void;
}

export const MyResumesModal: React.FC<MyResumesModalProps> = ({
  isOpen,
  onClose,
  currentDocumentId,
  onOpenResume,
  onUploadNew,
  onDeleteCurrentResume,
}) => {
  const [resumes, setResumes] = useState<SavedResumeItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState<string>('');
  const [actionInProgressId, setActionInProgressId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchResumes = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const list = await documentApi.listMyResumes();
      setResumes(list);
    } catch (err: any) {
      setError(err?.message || 'Failed to load saved resumes.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchResumes();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleOpen = async (docId: string) => {
    try {
      setActionInProgressId(docId);
      await onOpenResume(docId);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to open resume.');
    } finally {
      setActionInProgressId(null);
    }
  };

  const handleDuplicate = async (docId: string) => {
    try {
      setActionInProgressId(docId);
      const duplicated = await documentApi.duplicateResume(docId);
      setResumes(prev => [duplicated, ...prev]);
    } catch (err: any) {
      setError(err?.message || 'Failed to duplicate resume.');
    } finally {
      setActionInProgressId(null);
    }
  };

  const handleStartRename = (resume: SavedResumeItem) => {
    setEditingId(resume.id);
    setEditingTitle(resume.title || resume.original_filename);
  };

  const handleSaveRename = async (docId: string) => {
    if (!editingTitle.trim()) return;
    try {
      setActionInProgressId(docId);
      const updated = await documentApi.renameResume(docId, editingTitle.trim());
      setResumes(prev => prev.map(r => r.id === docId ? updated : r));
      setEditingId(null);
    } catch (err: any) {
      setError(err?.message || 'Failed to rename resume.');
    } finally {
      setActionInProgressId(null);
    }
  };

  const handleDelete = async (docId: string) => {
    if (!window.confirm('Are you sure you want to delete this resume? This cannot be undone.')) return;
    try {
      setActionInProgressId(docId);
      await documentApi.deleteResumeById(docId);
      setResumes(prev => {
        const remaining = prev.filter(r => r.id !== docId);
        if (remaining.length === 0 || currentDocumentId === docId) {
          clearAllResumeStorage();
          onDeleteCurrentResume?.();
          if (typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent('employai:resume-updated', { detail: null }));
            window.dispatchEvent(new Event('storage'));
          }
        }
        return remaining;
      });
    } catch (err: any) {
      setError(err?.message || 'Failed to delete resume.');
    } finally {
      setActionInProgressId(null);
    }
  };

  const filteredResumes = resumes.filter(r => {
    const q = searchQuery.toLowerCase();
    return (
      (r.title && r.title.toLowerCase().includes(q)) ||
      (r.original_filename && r.original_filename.toLowerCase().includes(q)) ||
      (r.detected_domain && r.detected_domain.toLowerCase().includes(q)) ||
      (r.target_job && r.target_job.toLowerCase().includes(q))
    );
  });

  const modalNode = (
    <div 
      className="modal-backdrop" 
      onClick={onClose} 
      style={{ 
        position: 'fixed',
        inset: 0,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100vw',
        height: '100vh',
        backgroundColor: 'rgba(3, 7, 18, 0.82)',
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 99999,
        padding: '1.25rem',
        boxSizing: 'border-box'
      }}
    >
      <div 
        className="glass-card modal-content" 
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '92%',
          maxWidth: '850px',
          maxHeight: '85vh',
          display: 'flex',
          flexDirection: 'column',
          padding: '1.75rem',
          borderRadius: '16px',
          background: 'var(--bg-modal)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-modal)',
          boxSizing: 'border-box'
        }}
      >
        {/* Modal Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div style={{ padding: '0.45rem', borderRadius: '10px', background: 'rgba(56, 189, 248, 0.12)', color: 'var(--accent-cyan)' }}>
              <FolderKanban size={22} />
            </div>
            <div>
              <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                My Resumes
              </h2>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                Manage your saved resumes, target job versions, and ATS scores.
              </p>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <button
              type="button"
              onClick={() => {
                onClose();
                onUploadNew();
              }}
              className="btn btn-primary btn-sm"
              style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}
            >
              <Plus size={13} /> Upload New Resume
            </button>
            <button
              type="button"
              onClick={onClose}
              className="btn btn-ghost btn-sm"
              style={{ padding: '0.35rem', color: 'var(--text-muted)' }}
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
          <div style={{ position: 'relative', flex: 1 }}>
            <Search size={14} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              type="text"
              placeholder="Search by resume title, domain, or target job..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="resume-doc-input"
              style={{ width: '100%', paddingLeft: '2.2rem', fontSize: '0.8rem', background: 'var(--bg-tertiary)', borderColor: 'var(--border-subtle)' }}
            />
          </div>
          <button
            type="button"
            onClick={fetchResumes}
            className="btn btn-secondary btn-sm"
            style={{ padding: '0.45rem 0.65rem' }}
            title="Refresh list"
          >
            <RefreshCw size={13} className={isLoading ? 'animate-spin-slow' : ''} />
          </button>
        </div>

        {error && (
          <div style={{ padding: '0.6rem 0.85rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.1)', border: '1px solid rgba(244, 63, 94, 0.3)', color: '#fb7185', fontSize: '0.78rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <AlertCircle size={14} />
            <span>{error}</span>
          </div>
        )}

        {/* Resumes List */}
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '0.65rem', paddingRight: '0.35rem' }}>
          {isLoading ? (
            <div style={{ textAlign: 'center', padding: '2.5rem 1rem' }}>
              <FuturisticLoader
                size="sm"
                icon="sparkles"
                title="Loading Saved Resumes..."
                subtitle="Fetching your document vault"
              />
            </div>
          ) : filteredResumes.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '3.5rem 1rem', color: 'var(--text-muted)' }}>
              <FileText size={36} style={{ margin: '0 auto 0.75rem auto', opacity: 0.4 }} />
              <h4 style={{ color: 'var(--text-primary)', marginBottom: '0.25rem' }}>No resumes found</h4>
              <p style={{ fontSize: '0.8rem', maxWidth: '340px', margin: '0 auto 1.25rem auto' }}>
                {searchQuery ? 'No resumes match your search query.' : 'Upload your first resume to get started with ATS analysis and optimization.'}
              </p>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onUploadNew();
                }}
                className="btn btn-primary btn-sm"
              >
                <Plus size={13} /> Upload Resume
              </button>
            </div>
          ) : (
            filteredResumes.map(item => {
              const isCurrent = item.id === currentDocumentId;
              const isEditing = editingId === item.id;
              const isBusy = actionInProgressId === item.id;

              return (
                <div
                  key={item.id}
                  style={{
                    padding: '1rem 1.15rem',
                    borderRadius: '10px',
                    background: isCurrent ? 'rgba(56, 189, 248, 0.12)' : 'var(--bg-tertiary)',
                    border: isCurrent ? '1.5px solid var(--accent-cyan)' : '1px solid var(--border-subtle)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: '1rem',
                    transition: 'all 0.15s ease'
                  }}
                >
                  {/* Left: Info */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.35rem' }}>
                      {isEditing ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', flex: 1 }}>
                          <input
                            type="text"
                            value={editingTitle}
                            onChange={(e) => setEditingTitle(e.target.value)}
                            className="resume-doc-input"
                            style={{ flex: 1, fontSize: '0.85rem', fontWeight: 700 }}
                            autoFocus
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveRename(item.id);
                              if (e.key === 'Escape') setEditingId(null);
                            }}
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveRename(item.id)}
                            className="btn btn-sm btn-emerald"
                            style={{ padding: '0.2rem 0.4rem' }}
                            title="Save title"
                          >
                            <Check size={12} />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingId(null)}
                            className="btn btn-sm btn-secondary"
                            style={{ padding: '0.2rem 0.4rem' }}
                            title="Cancel"
                          >
                            <X size={12} />
                          </button>
                        </div>
                      ) : (
                        <>
                          <h4 style={{ fontSize: '0.925rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {item.title || item.original_filename}
                          </h4>
                          <button
                            type="button"
                            onClick={() => handleStartRename(item)}
                            className="btn btn-ghost btn-sm"
                            style={{ padding: '0.15rem 0.3rem', color: 'var(--text-muted)' }}
                            title="Rename resume"
                          >
                            <Edit2 size={11} />
                          </button>
                          {isCurrent && (
                            <span className="badge badge-cyan" style={{ fontSize: '0.62rem', padding: '0.1rem 0.35rem' }}>
                              Active Workspace
                            </span>
                          )}
                        </>
                      )}
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', flexWrap: 'wrap', fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                      <span style={{ color: '#38bdf8', fontWeight: 600 }}>
                        {item.detected_domain || 'General Professional'}
                      </span>
                      <span>•</span>
                      <span>{item.version_count || 1} version{(item.version_count || 1) > 1 ? 's' : ''}</span>
                      {item.target_job && (
                        <>
                          <span>•</span>
                          <span style={{ color: '#a78bfa' }}>Target: {item.target_job}</span>
                        </>
                      )}
                      <span>•</span>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
                        <Clock size={10} />
                        {new Date(item.updated_at || item.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  {/* Middle: ATS Score */}
                  <div style={{ textAlign: 'center', padding: '0.25rem 0.75rem', borderRadius: '8px', background: 'rgba(16, 185, 129, 0.08)', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
                    <div style={{ fontSize: '0.62rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>ATS Score</div>
                    <div style={{ fontSize: '1.1rem', fontWeight: 800, color: '#34d399' }}>
                      {Math.round(item.ats_score || 80)}
                    </div>
                  </div>

                  {/* Right: Actions */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                    <button
                      type="button"
                      onClick={() => handleOpen(item.id)}
                      className={`btn btn-sm ${isCurrent ? 'btn-secondary' : 'btn-primary'}`}
                      disabled={isBusy || isCurrent}
                      style={{ fontSize: '0.75rem', padding: '0.3rem 0.65rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
                    >
                      {isBusy ? <RefreshCw size={12} className="animate-spin-slow" /> : isCurrent ? 'Opened' : <>Open <ArrowRight size={11} /></>}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDuplicate(item.id)}
                      className="btn btn-secondary btn-sm"
                      disabled={isBusy}
                      style={{ padding: '0.35rem 0.5rem' }}
                      title="Duplicate Resume"
                    >
                      <Copy size={12} />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDelete(item.id)}
                      className="btn btn-outline-danger btn-sm"
                      disabled={isBusy}
                      style={{ padding: '0.35rem 0.5rem' }}
                      title="Delete Resume"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalNode, document.body) : modalNode;
};
