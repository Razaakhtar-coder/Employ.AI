import unittest
import io
from fastapi.testclient import TestClient
from app.main import app
from app.core.database import Base, engine, SessionLocal
from app.models.user import User
from app.models.profile import StudentProfile
from app.core.security import create_access_token, get_password_hash


class TestDocumentApiEndpoints(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        self.db = SessionLocal()

        # Clean / create test user
        self.db.query(User).filter(User.email == "test.upload.user@employai.edu").delete()
        self.db.commit()

        self.user = User(
            email="test.upload.user@employai.edu",
            full_name="Logged In Account Holder",
            hashed_password=get_password_hash("TestPass123!"),
            role="student",
            is_active=True
        )
        self.db.add(self.user)
        self.db.flush()

        self.profile = StudentProfile(user_id=self.user.id)
        self.db.add(self.profile)
        self.db.commit()

        self.token = create_access_token(subject=self.user.id, role="student")
        self.headers = {"Authorization": f"Bearer {self.token}"}

    def tearDown(self):
        self.db.close()

    def test_upload_and_get_latest_analysis_end_to_end(self):
        """Tests that uploading a real resume yields the candidate's actual data in the response and in latest-analysis."""
        resume_content = (
            "TEST CANDIDATE OMEGA\n"
            "omega.real@unique-domain.org | +91 91111 22222 | Kolkata, India\n\n"
            "EDUCATION\n"
            "Bachelor of Commerce (B.Com) in Taxation\n"
            "Calcutta University | 2021 - 2024\n\n"
            "SKILLS\n"
            "Tally Prime, GST Compliance, Financial Accounting, Auditing, Advanced Excel\n\n"
            "EXPERIENCE\n"
            "Finance Associate | East India Auditing | 2023 - 2024\n"
            "• Managed statutory GST filing for 30+ SME clients using Tally Prime.\n"
        ).encode("utf-8")

        files = {
            "file": ("omega_resume.txt", io.BytesIO(resume_content), "text/plain")
        }

        # 1. Upload
        resp = self.client.post("/api/v1/documents/upload", files=files, headers=self.headers)
        self.assertEqual(resp.status_code, 201)
        data = resp.json()

        self.assertIn("structured_resume", data)
        struct = data["structured_resume"]
        self.assertEqual(struct["personal_info"]["full_name"], "TEST CANDIDATE OMEGA")
        self.assertEqual(struct["personal_info"]["email"], "omega.real@unique-domain.org")
        self.assertEqual(struct["personal_info"]["location"], "Kolkata, India")
        self.assertIn("Tally Prime", struct["skills"])
        self.assertIn("GST Compliance", struct["skills"])

        # Check that user account name ("Logged In Account Holder") was NOT used as candidate name
        self.assertNotEqual(struct["personal_info"]["full_name"], "Logged In Account Holder")
        self.assertNotEqual(struct["personal_info"]["email"], "test.upload.user@employai.edu")

        # 2. Get latest analysis
        latest_resp = self.client.get("/api/v1/documents/latest-analysis", headers=self.headers)
        self.assertEqual(latest_resp.status_code, 200)
        latest_data = latest_resp.json()
        self.assertEqual(latest_data["structured_resume"]["personal_info"]["full_name"], "TEST CANDIDATE OMEGA")
        self.assertEqual(latest_data["structured_resume"]["personal_info"]["email"], "omega.real@unique-domain.org")

    def test_target_job_description_analysis_endpoint(self):
        """Tests re-analyzing an active resume against a target job description."""
        resume_content = (
            "Marcus Vance\n"
            "marcus.vance@civil-works.com | +91 93333 77777\n\n"
            "EDUCATION\n"
            "Bachelor of Technology in Civil Engineering\n"
            "NIT Trichy | 2020 - 2024\n\n"
            "SKILLS\n"
            "Revit, BIM, STAAD.Pro, Structural Analysis\n"
        ).encode("utf-8")

        files = {
            "file": ("civil_resume.txt", io.BytesIO(resume_content), "text/plain")
        }
        self.client.post("/api/v1/documents/upload", files=files, headers=self.headers)

        job_payload = {
            "target_job_description": "We are seeking a BIM Coordinator proficient in Revit and Quantity Surveying.",
            "target_job_title": "BIM Coordinator"
        }
        resp = self.client.post("/api/v1/documents/analyze-job", json=job_payload, headers=self.headers)
        self.assertEqual(resp.status_code, 200)
        data = resp.json()

        self.assertIsNotNone(data.get("job_analysis"))
        job_eval = data["job_analysis"]
        matched_skills = [m["skill"] for m in job_eval["matched_skills"]]
        self.assertIn("Revit", matched_skills)

    def test_delete_active_resume_and_reupload(self):
        """Tests deleting the active resume, verifying state is wiped, and uploading a brand new resume."""
        # 1. Upload initial resume
        initial_resume = (
            "FIRST CANDIDATE\n"
            "first.candidate@test.edu | +91 90000 11111\n\n"
            "EDUCATION\n"
            "B.Tech Mechanical Engineering | 2020 - 2024\n\n"
            "SKILLS\n"
            "SolidWorks, ANSYS, GD&T, FEA\n"
        ).encode("utf-8")
        files = {
            "file": ("first_resume.txt", io.BytesIO(initial_resume), "text/plain")
        }
        upload_resp = self.client.post("/api/v1/documents/upload", files=files, headers=self.headers)
        self.assertEqual(upload_resp.status_code, 201)

        # 2. Verify it's present
        latest_resp = self.client.get("/api/v1/documents/latest-analysis", headers=self.headers)
        self.assertEqual(latest_resp.status_code, 200)
        self.assertEqual(latest_resp.json()["structured_resume"]["personal_info"]["full_name"], "FIRST CANDIDATE")

        # 3. Delete active resume
        delete_resp = self.client.delete("/api/v1/documents/active", headers=self.headers)
        self.assertEqual(delete_resp.status_code, 200)
        self.assertIn("deleted successfully", delete_resp.json()["message"])

        # 4. Verify getting latest-analysis now returns 404
        empty_resp = self.client.get("/api/v1/documents/latest-analysis", headers=self.headers)
        self.assertEqual(empty_resp.status_code, 404)

        # 5. Upload new resume
        new_resume = (
            "SECOND CANDIDATE NEW\n"
            "second.new@finance-firm.com | +91 98888 22222\n\n"
            "EDUCATION\n"
            "Bachelor of Commerce | 2021 - 2024\n\n"
            "SKILLS\n"
            "Tally Prime, Financial Accounting, Taxation\n"
        ).encode("utf-8")
        new_files = {
            "file": ("second_resume.txt", io.BytesIO(new_resume), "text/plain")
        }
        new_upload_resp = self.client.post("/api/v1/documents/upload", files=new_files, headers=self.headers)
        self.assertEqual(new_upload_resp.status_code, 201)
        new_data = new_upload_resp.json()

        self.assertEqual(new_data["structured_resume"]["personal_info"]["full_name"], "SECOND CANDIDATE NEW")
        self.assertEqual(new_data["structured_resume"]["personal_info"]["email"], "second.new@finance-firm.com")
        self.assertIn("Tally Prime", new_data["structured_resume"]["skills"])
        self.assertNotIn("SolidWorks", new_data["structured_resume"]["skills"])


if __name__ == "__main__":
    unittest.main()
