import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import type { BulletImprovementOption } from '../types';
import { documentApi } from '../services/api';
import { 
  Sparkles, Check, X, Edit3, 
  Lightbulb, RefreshCw, AlertCircle, Info, ShieldCheck
} from 'lucide-react';
import { FuturisticLoader } from './FuturisticLoader';

export interface BulletImprovementModalProps {
  isOpen: boolean;
  onClose: () => void;
  originalBullet: string;
  roleOrProject?: string;
  targetDomain?: string;
  targetJob?: string;
  onApply: (improvedBullet: string, rationale?: string) => void;
}

export const BulletImprovementModal: React.FC<BulletImprovementModalProps> = ({
  isOpen,
  onClose,
  originalBullet,
  roleOrProject,
  targetDomain,
  targetJob,
  onApply,
}) => {
  const [options, setOptions] = useState<BulletImprovementOption[]>([]);
  const [missingMetricsAdvice, setMissingMetricsAdvice] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedIdx, setSelectedIdx] = useState<number>(0);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editedText, setEditedText] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [selectedArchetype, setSelectedArchetype] = useState<string>('all');
  const [regenCount, setRegenCount] = useState<number>(0);

  const fetchBulletOptions = async (overrideStyle?: string) => {
    if (!originalBullet) return;
    const styleId = overrideStyle || selectedArchetype;
    if (overrideStyle) setSelectedArchetype(overrideStyle);
    try {
      setIsLoading(true);
      setError(null);
      setRegenCount(prev => prev + 1);
      const res = await documentApi.generateBulletOptions({
        bullet: originalBullet,
        role_or_project: styleId !== 'all' ? `${roleOrProject || ''} (Focus: ${styleId} power verbs)`.trim() : roleOrProject,
        target_domain: targetDomain,
        target_job: targetJob
      });
      setOptions(res.options || []);
      setMissingMetricsAdvice(res.missing_metrics_advice);
      if (res.options && res.options.length > 0) {
        setSelectedIdx(0);
        setEditedText(res.options[0].text);
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to generate bullet improvements.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && originalBullet) {
      setIsEditing(false);
      fetchBulletOptions();
    }
  }, [isOpen, originalBullet]);

  if (!isOpen) return null;

  const currentSelected = options[selectedIdx];

  const handleSelectOption = (idx: number) => {
    setSelectedIdx(idx);
    setEditedText(options[idx].text);
  };

  const handleApply = () => {
    const textToApply = isEditing ? editedText.trim() : (currentSelected?.text || editedText.trim());
    if (!textToApply) return;
    const rationale = currentSelected ? currentSelected.why_better.join(' ') : 'AI improved bullet';
    onApply(textToApply, rationale);
    onClose();
  };

  const modalNode = (
    <div 
      className="modal-backdrop" 
      onClick={onClose} 
      style={{ 
        position: 'fixed',
        inset: 0,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100vw',
        height: '100vh',
        backgroundColor: 'rgba(3, 7, 18, 0.82)',
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 99999,
        padding: '1.25rem',
        boxSizing: 'border-box'
      }}
    >
      <div 
        className="glass-card modal-content" 
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '92%',
          maxWidth: '820px',
          maxHeight: '88vh',
          display: 'flex',
          flexDirection: 'column',
          padding: '1.75rem',
          borderRadius: '16px',
          background: 'var(--bg-modal)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-modal)',
          boxSizing: 'border-box'
        }}
      >
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div style={{ padding: '0.45rem', borderRadius: '10px', background: 'rgba(16, 185, 129, 0.12)', color: 'var(--accent-emerald)' }}>
              <Sparkles size={22} />
            </div>
            <div>
              <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                AI Bullet Improvement
              </h2>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                {roleOrProject ? `Optimizing for ${roleOrProject}` : 'Rewriting with STAR framework and strong active verbs'}
              </p>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <button
              type="button"
              onClick={() => fetchBulletOptions()}
              className="btn btn-secondary btn-sm"
              disabled={isLoading}
              style={{ fontSize: '0.72rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
              title="Regenerate with another fresh set of action verbs"
            >
              <RefreshCw size={12} className={isLoading ? 'animate-spin-slow' : ''} />
              Regenerate {regenCount > 1 ? `(${regenCount})` : ''}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="btn btn-ghost btn-sm"
              style={{ padding: '0.35rem', color: 'var(--text-muted)' }}
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Original Bullet Box */}
        <div style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', borderRadius: '10px', padding: '0.85rem 1rem', marginBottom: '0.85rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.3rem' }}>
            <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 700 }}>
              Original Bullet Statement
            </span>
            <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>
              {originalBullet.length} chars
            </span>
          </div>
          <p style={{ fontSize: '0.84rem', color: 'var(--text-primary)', margin: 0, lineHeight: 1.5 }}>
            {originalBullet}
          </p>
        </div>

        {/* Style & Action Verb Archetypes */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', flexWrap: 'wrap', marginBottom: '0.85rem' }}>
          <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 700 }}>Wording Style:</span>
          {[
            { id: 'all', label: '✨ Mixed Verbs' },
            { id: 'innovation', label: '💡 Innovation & Method' },
            { id: 'velocity', label: '🚀 Velocity & Delivery' },
            { id: 'scale', label: '⚡ Scale & Optimization' },
            { id: 'leadership', label: '🎯 Leadership & Executive' }
          ].map(arch => (
            <button
              key={arch.id}
              type="button"
              onClick={() => fetchBulletOptions(arch.id)}
              disabled={isLoading}
              className={`btn btn-sm ${selectedArchetype === arch.id ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.68rem', padding: '0.2rem 0.5rem', borderRadius: '6px' }}
            >
              {arch.label}
            </button>
          ))}
        </div>

        {error && (
          <div style={{ padding: '0.6rem 0.85rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.1)', border: '1px solid rgba(244, 63, 94, 0.3)', color: '#fb7185', fontSize: '0.78rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <AlertCircle size={14} />
            <span>{error}</span>
          </div>
        )}

        {/* Options List */}
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '0.85rem', paddingRight: '0.35rem' }}>
          {isLoading ? (
            <div style={{ textAlign: 'center', padding: '2rem 1rem' }}>
              <FuturisticLoader
                size="sm"
                icon="sparkles"
                title="Generating High-Impact STAR Bullets..."
                subtitle="Engineering action-oriented bullet alternatives with quantified metrics"
              />
            </div>
          ) : (
            options.map((opt, idx) => {
              const isSelected = selectedIdx === idx;

              return (
                <div
                  key={opt.option_id || idx}
                  onClick={() => handleSelectOption(idx)}
                  style={{
                    padding: '1rem 1.15rem',
                    borderRadius: '10px',
                    background: isSelected ? 'rgba(16, 185, 129, 0.12)' : 'var(--bg-tertiary)',
                    border: isSelected ? '1.5px solid var(--accent-emerald)' : '1px solid var(--border-subtle)',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.45rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <span className={`badge ${isSelected ? 'badge-emerald' : 'badge-secondary'}`} style={{ fontSize: '0.68rem' }}>
                        Option {idx + 1}: {opt.style_label}
                      </span>
                      {opt.action_verb_used && (
                        <span style={{ fontSize: '0.72rem', color: 'var(--accent-cyan)', fontWeight: 600 }}>
                          Verb: {opt.action_verb_used}
                        </span>
                      )}
                    </div>
                    {isSelected && (
                      <span style={{ color: 'var(--accent-emerald)', fontSize: '0.75rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
                        <Check size={14} /> Selected
                      </span>
                    )}
                  </div>

                  <p style={{ fontSize: '0.86rem', color: 'var(--text-primary)', margin: '0 0 0.65rem 0', lineHeight: 1.5, fontWeight: 500 }}>
                    {opt.text}
                  </p>

                  {/* Why this is better */}
                  {opt.why_better && opt.why_better.length > 0 && (
                    <div style={{ background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)', padding: '0.5rem 0.75rem', borderRadius: '6px', fontSize: '0.74rem' }}>
                      <span style={{ color: 'var(--accent-emerald)', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.25rem', marginBottom: '0.2rem' }}>
                        <Lightbulb size={11} /> Why this is better:
                      </span>
                      <ul style={{ margin: 0, paddingLeft: '1rem', color: 'var(--text-secondary)' }}>
                        {opt.why_better.map((w, wIdx) => (
                          <li key={wIdx}>{w}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              );
            })
          )}

          {/* Missing Metrics Advice */}
          {missingMetricsAdvice && (
            <div style={{ padding: '0.75rem 1rem', borderRadius: '8px', background: 'rgba(56, 189, 248, 0.08)', border: '1px solid var(--border-glass)', display: 'flex', alignItems: 'flex-start', gap: '0.5rem' }}>
              <Info size={15} style={{ color: 'var(--accent-cyan)', marginTop: '0.1rem', flexShrink: 0 }} />
              <div style={{ fontSize: '0.76rem', color: 'var(--text-primary)', lineHeight: 1.45 }}>
                <strong style={{ color: 'var(--accent-cyan)' }}>Metrics Recommendation: </strong>
                {missingMetricsAdvice}
              </div>
            </div>
          )}

          {/* Direct Edit Area if user wants to customize */}
          {isEditing && (
            <div style={{ marginTop: '0.5rem', background: 'var(--bg-tertiary)', padding: '0.85rem', borderRadius: '8px', border: '1px solid var(--border-glass)' }}>
              <label style={{ display: 'block', fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: '0.35rem', fontWeight: 700 }}>
                Customize Wording Before Applying:
              </label>
              <textarea
                rows={3}
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
                className="resume-doc-input"
                style={{ width: '100%', fontSize: '0.82rem', lineHeight: 1.45 }}
              />
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '1.25rem', borderTop: '1px solid var(--border-subtle)', marginTop: '0.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.7rem', color: 'var(--text-muted)' }}>
            <ShieldCheck size={13} color="var(--accent-emerald)" />
            <span>Anti-hallucination verified. Never invents metrics or false claims.</span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
            <button
              type="button"
              onClick={onClose}
              className="btn btn-secondary btn-sm"
              style={{ fontSize: '0.75rem' }}
            >
              Reject / Dismiss
            </button>
            <button
              type="button"
              onClick={() => setIsEditing(prev => !prev)}
              className="btn btn-ghost btn-sm"
              style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
            >
              <Edit3 size={12} /> {isEditing ? 'Done Editing' : 'Edit Before Applying'}
            </button>
            <button
              type="button"
              onClick={handleApply}
              disabled={isLoading || options.length === 0}
              className="btn btn-emerald btn-sm"
              style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}
            >
              <Check size={13} /> Apply Improvement
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalNode, document.body) : modalNode;
};
