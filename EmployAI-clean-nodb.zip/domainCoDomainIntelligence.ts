// ============================================================================
// Employ.AI - Complete Domain & Co-Domain Intelligence Engine
// High-Fidelity, Co-Domain & Project-Specific Pro-Tips, Pitfalls & Blueprints
// ============================================================================

import type { GoodProject, ProjectTier, ProjectInterviewQA, ProjectTaskItem, ProjectBuildStep } from './domainProjectData';

export interface PhaseIntelligence {
  phaseName: string;
  title: string;
  focus: string;
  deliverable: string;
  architectureFocus: string;
  tasks: ProjectTaskItem[];
  proTips: string[];
  pitfallsToAvoid: string[];
}

export interface TierProjectBlueprint {
  titleSuffix: string;
  tagline: string;
  description: string;
  hours: number;
  duration: string;
  recruiterReason: string;
  architecturePattern: string;
  resumeStarBullet: string;
  interviewQuestions: ProjectInterviewQA[];
  phases: PhaseIntelligence[];
}

export interface CoDomainIntelligenceProfile {
  coDomainName: string;
  stream: string;
  specialistRole: string;
  techStack: {
    frontend?: string[];
    backend?: string[];
    database?: string[];
    cloudDevOps?: string[];
    tools?: string[];
    aiLibraries?: string[];
    clinicalProtocols?: string[];
    standards?: string[];
    regulations?: string[];
    frameworks?: string[];
    hardware?: string[];
    jurisprudence?: string[];
    safetyProtocols?: string[];
  };
  blueprints: [TierProjectBlueprint, TierProjectBlueprint, TierProjectBlueprint, TierProjectBlueprint];
}

/**
 * Returns the professional role title for the pro-tip header according to stream/co-domain
 */
export function getRoleProTipLabel(stream?: string, coDomain?: string): string {
  const s = (stream || "").toLowerCase();
  const c = (coDomain || "").toLowerCase();
  if (s.includes("medic") || s.includes("mbbs") || s.includes("clinic") || c.includes("medic") || c.includes("clinic")) return "Senior Clinician Pro-Tip";
  if (s.includes("nurs") || c.includes("nurs")) return "Senior Clinical Nurse Specialist Pro-Tip";
  if (s.includes("law") || s.includes("llb") || s.includes("legal") || c.includes("law") || c.includes("contract")) return "Senior Legal Counsel Pro-Tip";
  if (s.includes("com") || s.includes("financ") || s.includes("account") || c.includes("gst") || c.includes("audit") || c.includes("tax")) return "Senior Financial Controller Pro-Tip";
  if (s.includes("analytic") || c.includes("analytics") || c.includes("power bi") || c.includes("tableau")) return "Lead Analytics Architect Pro-Tip";
  if (s.includes("cabin") || c.includes("cabin crew") || c.includes("in-flight")) return "In-Flight Safety Director Pro-Tip";
  if (s.includes("aviat") || s.includes("pilot") || c.includes("flight") || c.includes("ifr")) return "Chief Flight Instructor Pro-Tip";
  if (s.includes("bba") || s.includes("manage") || s.includes("strategy") || c.includes("supply chain") || c.includes("product ops")) return "Principal Business Strategist Pro-Tip";
  if (s.includes("hons") || s.includes("humanities") || c.includes("public policy") || c.includes("csr")) return "Senior Policy Fellow Pro-Tip";
  if (s.includes("biotech") || c.includes("crispr") || c.includes("fermentation")) return "Senior Bioprocess Scientist Pro-Tip";
  if (s.includes("marine") || c.includes("marine") || c.includes("ship")) return "Chief Marine Engineer Pro-Tip";
  return "Senior Engineer Pro-Tip";
}

export const STREAM_ARCHETYPES_REGISTRY: Record<string, any> = {
  "Computer Science": {
    "specialistRole": "Senior Software Architect",
    "techStack": {
      "frontend": [
        "TypeScript",
        "React 19 / Next.js",
        "Tailwind CSS"
      ],
      "backend": [
        "FastAPI / Node.js",
        "Python 3.12",
        "Pydantic v2"
      ],
      "database": [
        "PostgreSQL",
        "Redis",
        "TimescaleDB"
      ],
      "cloudDevOps": [
        "Docker",
        "Kubernetes",
        "GitHub Actions",
        "AWS / Cloud Run"
      ],
      "tools": [
        "Vitest / Pytest",
        "OpenAPI Specs",
        "Prometheus",
        "Grafana"
      ]
    },
    "tierSuffixes": [
      "Architecture Blueprint & Core Protocol Suite",
      "Production Workflow & Distributed API Platform",
      "High-Throughput Distributed Telemetry & Caching Engine",
      "Autonomous AI Copilot & Real-Time Decision Suite"
    ],
    "architecturePatterns": [
      "Clean Layered Architecture with Strict Domain Boundary Interfaces",
      "Event-Driven Microservices with Transactional Outbox Pattern",
      "Cache-Aside Read Architecture with Sharded Asynchronous Queues",
      "Retrieval-Augmented Autonomous Reasoning Engine with Streaming Telemetry"
    ],
    "phaseProTips": [
      [
        "Establish strict domain model schemas and boundary interfaces using TypeScript types or Pydantic v2 before writing any service code.",
        "Isolate database entities from API data transfer objects (DTOs) using clean repository abstractions.",
        "Use optimistic UI mutations with localized state rollbacks to give users instantaneous feedback without UI blocking.",
        "Profile database queries using EXPLAIN ANALYZE to identify sequential table scans and create targeted composite B-tree indices.",
        "Pin dependency versions and container base images with commit SHAs in GitHub Actions to guarantee reproducible CI/CD builds."
      ],
      [
        "Implement idempotent event consumers with deduplication tables to safely survive duplicate network message deliveries.",
        "Use connection pooling with PgBouncer and tune max_connections to prevent connection exhaustion under sudden load surges.",
        "Stream long-running API outputs via Server-Sent Events (SSE) or WebSockets with periodic keep-alive ping frames.",
        "Implement distributed rate-limiting using Redis token bucket Lua scripts to protect downstream services from brute-force floods.",
        "Perform zero-downtime database migrations using expand-and-contract schema changes rather than breaking column renames."
      ],
      [
        "Partition multi-million row time-series tables by monthly range to enable partition pruning and eliminate 90% of disk I/O.",
        "Batch bulk cache and database queries into pipeline operations to reduce round-trip network socket latencies by an order of magnitude.",
        "Use consistent hashing with virtual nodes to balance partition loads and avoid re-indexing the entire cluster during node scaling.",
        "Implement circuit breakers with exponential backoff and randomized jitter to prevent thundering herd crashes during service degradation.",
        "Deploy automated blue-green traffic shifting with metric thresholds, rolling back automatically if error rates exceed 0.5%."
      ],
      [
        "Benchmark hybrid retrieval combining BM25 keyword matching with dense vector embeddings (Reciprocal Rank Fusion) for optimal precision.",
        "Implement semantic caching with vector distance thresholds to bypass LLM inference latency for recurring queries.",
        "Wrap streaming Markdown and diagram parsers in React Error Boundaries to prevent malformed generative tokens from crashing the UI.",
        "Implement continuous evaluation pipelines using RAGAS benchmarks to quantitatively monitor faithfulness and context recall.",
        "Sanitize prompt templates with delimiter guards and enforce strict JSON Schema validation on all agent function-calling responses."
      ]
    ],
    "phasePitfalls": [
      [
        "Starting to write implementation logic before defining formal interface contracts and data models.",
        "Mixing database query logic directly into computational business functions, making unit testing impossible.",
        "Triggering unnecessary layout reflows and render thrashing by storing high-frequency event coordinates in component state.",
        "Exposing unauthenticated administrative endpoints or neglecting index creation on high-cardinality foreign keys.",
        "Leaving a blank or generic README file without architecture diagrams, API curl commands, or live demo URLs."
      ],
      [
        "Committing message queue offsets before the database transaction commits, resulting in silent message loss on crash.",
        "Holding open database connections during external third-party HTTP API calls, rapidly exhausting connection pools.",
        "Crashing the UI thread by attempting to render un-virtualized lists with thousands of DOM nodes simultaneously.",
        "Hardcoding sensitive JWT secrets or API tokens directly in source code instead of using environment secret managers.",
        "Deploying breaking API changes without backward-compatible versioning, breaking active mobile and frontend clients."
      ],
      [
        "Using simple modulo hashing across distributed nodes, causing almost all cache keys to be invalidated when a node joins or leaves.",
        "Running unbounded Redis KEYS * commands in production, which locks the single-threaded Redis event loop for seconds.",
        "Relying on client-side polling with fixed 1-second intervals instead of efficient WebSockets or push notifications.",
        "Setting retry loops without exponential backoff and jitter, creating self-inflicted DDoS attacks against recovering downstreams.",
        "Relying on manual release checklists for cluster updates instead of automated, declarative GitOps pipelines."
      ],
      [
        "Passing raw user inputs directly into LLM prompts without sanitization, exposing the system to prompt injection attacks.",
        "Uploading entire multi-megabyte raw documents into the LLM context window, resulting in astronomical API costs and context dilution.",
        "Rendering unvalidated LLM output directly into dangerouslySetInnerHTML, opening critical Cross-Site Scripting (XSS) vectors.",
        "Deploying AI reasoning loops without maximum step limits, allowing infinite recursive agent loops to burn API budgets.",
        "Failing to log structured evaluation metrics and latency percentiles, leaving the team blind to model degradation in production."
      ]
    ]
  },
  "MBBS": {
    "specialistRole": "Senior Attending Physician",
    "techStack": {
      "tools": [
        "3M Littmann Stethoscope",
        "12-Lead ECG Monitor",
        "Point-of-Care Ultrasound (POCUS)",
        "Epic / Cerner EHR",
        "ABG Blood Gas Analyzer"
      ],
      "clinicalProtocols": [
        "ATLS Trauma Resuscitation Protocol",
        "ACLS Cardiac Arrest Algorithms",
        "Surviving Sepsis Campaign Bundles",
        "UpToDate Clinical Evidence Guidelines"
      ]
    },
    "tierSuffixes": [
      "Clinical Examination & Diagnostic Reasoning Framework",
      "Acute Care Protocol & Patient Management System",
      "Critical Care Hemodynamic & ICU Monitoring Suite",
      "Clinical AI Decision Support & Diagnostic Copilot"
    ],
    "architecturePatterns": [
      "Systematic Evidence-Based Clinical Diagnostic Decision Tree",
      "Acute Triage Protocol with Multi-Parameter Warning Scores (NEWS2)",
      "Continuous Closed-Loop Hemodynamic Telemetry & Biomarker Monitoring",
      "Retrieval-Augmented Clinical Decision Support with PubMed Evidence Synthesis"
    ],
    "phaseProTips": [
      [
        "Always structure differential diagnoses with \"must-not-miss\" life-threatening emergencies ranked at the top before common benign etiologies.",
        "Correlate systemic physical findings with targeted laboratory biomarkers rather than ordering indiscriminate pan-cultures.",
        "Document negative findings meticulously; in clinical jurisprudence, an unrecorded physical sign is legally considered not examined.",
        "Cross-reference patient renal and hepatic clearance profiles before prescribing fixed therapeutic drug dosages.",
        "Structure clinical case presentations using the standard SBAR (Situation, Background, Assessment, Recommendation) communication format."
      ],
      [
        "Adhere strictly to the ABCDE (Airway, Breathing, Circulation, Disability, Exposure) protocol before addressing secondary extremity trauma.",
        "Calculate hourly fluid balance and urine output (target > 0.5 mL/kg/hr) to detect early prerenal acute kidney injury.",
        "Verify blood pressure in both arms simultaneously when evaluating acute tearing chest pain to rule out aortic dissection.",
        "Implement antibiotic stewardship protocols, obtaining blood cultures prior to administering broad-spectrum antimicrobials.",
        "Conduct structured pre-procedure time-outs verifying correct patient, anatomical site, and informed consent before invasive interventions."
      ],
      [
        "Titrate vasoactive infusions (norepinephrine, vasopressin) against Mean Arterial Pressure (MAP target > 65 mmHg) rather than systolic pressure alone.",
        "Maintain lung-protective mechanical ventilation with low tidal volumes (6 mL/kg ideal body weight) and plateau pressure < 30 cm H2O.",
        "Evaluate dynamic fluid responsiveness (passive leg raise, stroke volume variation) before administering further crystalloid boluses in sepsis.",
        "Calculate arterial blood gas PaO2/FiO2 ratios regularly to detect acute respiratory distress syndrome (ARDS) in its earliest exudative phase.",
        "Follow strict central line bundles (chlorhexidine prep, maximal sterile barriers, daily review of line necessity) to eliminate CLABSI."
      ],
      [
        "Benchmark diagnostic AI suggestion algorithms against peer-reviewed clinical consensus datasets (e.g. MIMIC-IV, UpToDate).",
        "Design clinician interfaces with prominent confidence calibrations and clear citations directly linked to primary clinical trials.",
        "Incorporate automated drug-drug interaction and allergy cross-checking in the prescription recommendation pathway.",
        "Audit machine learning models for demographic, gender, and socioeconomic biases in diagnostic recommendation accuracy.",
        "Maintain human-in-the-loop oversight: AI recommendations must require active clinician confirmation before entering the medical record."
      ]
    ],
    "phasePitfalls": [
      [
        "Premature closure bias: anchoring on an early diagnostic impression and ignoring contradictory laboratory or clinical signs.",
        "Treating laboratory numbers in isolation rather than evaluating the patient holistic clinical trajectory and symptomatology.",
        "Relying on memory for pediatric weight-based drug calculations instead of standardized dosing Nomograms or clinical calculators.",
        "Failing to warn patients about critical adverse drug reactions and red-flag symptoms requiring emergency re-attendance.",
        "Presenting disorganized clinical summaries during handover that omit vital patient allergies or code status."
      ],
      [
        "Delaying emergency decompression (needle thoracostomy) in tension pneumothorax while waiting for portable chest radiography.",
        "Administering excessive fluid boluses to patients with impaired ventricular ejection fraction, precipitating acute pulmonary edema.",
        "Overlooking occult hypovolemic shock in elderly or beta-blocked trauma patients whose heart rate fails to mount tachycardia.",
        "Switching broad-spectrum antibiotics without reviewing microbiological sensitivity and minimum inhibitory concentration (MIC) reports.",
        "Performing bedside surgical procedures without checking coagulation parameters (PT/INR, platelet counts) in high-risk patients."
      ],
      [
        "Over-resuscitating septic shock patients with crystalloids after hemodynamic stabilization, precipitating abdominal compartment syndrome.",
        "Weaning mechanical ventilation too aggressively without conducting structured spontaneous breathing trials (SBT) and cuff leak tests.",
        "Silencing ICU hemodynamic alarms without physically assessing the patient (alarm fatigue), missing early cardiovascular collapse.",
        "Leaving arterial and central lines in place past clinical necessity, significantly increasing secondary bloodstream infection rates.",
        "Failing to recognize ventilator-patient dyssynchrony, leading to alveolar barotrauma and prolonged ICU length of stay."
      ],
      [
        "Treating AI diagnostic predictions as ground truth without validating them against the patient unique clinical presentation.",
        "Displaying dense unprioritized drug interaction alerts, causing alarm fatigue that leads clinicians to override genuine critical warnings.",
        "Training diagnostic prediction models on biased historical data with under-represented minority populations.",
        "Failing to log clinician overrides and divergence rates, leaving clinical governance teams unable to audit model reliability.",
        "Exposing protected health information (PHI) in unencrypted third-party cloud API inference requests, violating HIPAA and DPDP laws."
      ]
    ]
  },
  "Nursing": {
    "specialistRole": "Senior Clinical Nurse Specialist",
    "techStack": {
      "tools": [
        "Arterial Line Transducer",
        "Crash Cart Defibrillator",
        "Infusion Pump Controller",
        "Braden & Morse Scales",
        "Epic Stork / Nursing EHR"
      ],
      "clinicalProtocols": [
        "5 Rights of Medication Administration",
        "Emergency Severity Index (ESI)",
        "Aseptic Wound Management",
        "Code Blue Rapid Response"
      ]
    },
    "tierSuffixes": [
      "Bedside Clinical Nursing & Patient Safety Framework",
      "Emergency Triage & Rapid Response Portal",
      "ICU Hemodynamic & Ventilator Monitoring Suite",
      "Intelligent Nursing Care Plan & Clinical Alert Sentinel"
    ],
    "architecturePatterns": [
      "Structured Nursing Process Model (Assessment, Diagnosis, Planning, Implementation, Evaluation)",
      "Dynamic Patient Acuity Scoring & Early Deterioration Protocol",
      "Multi-Parameter Invasive Telemetry with Automated Fluid Balance Tracking",
      "Predictive Nursing Workload Optimization & Alarm Triage Sentinel"
    ],
    "phaseProTips": [
      [
        "Strictly verify the 5 Rights of medication safety (Right Patient, Drug, Dose, Route, Time) using dual barcode scanning at bedside.",
        "Document skin integrity using the Braden Scale within 2 hours of admission and implement 2-hourly repositioning schedules.",
        "Calculate intake and output balance meticulously; subtle drops in hourly urine output precede systemic deterioration by hours.",
        "Establish clear baseline neurological observations (GCS, pupil reactivity) at the start of every shift for objective comparison.",
        "Maintain aseptic non-touch technique (ANTT) for all intravenous line accesses, wound dressings, and urinary catheter care."
      ],
      [
        "Prioritize triage assigning patients via the 5-level Emergency Severity Index (ESI) based on acuity and projected resource needs.",
        "Recognize early compensatory shock: tachycardia and narrow pulse pressure appear long before systemic hypotension develops.",
        "Prepare emergency resuscitation medications (epinephrine, amiodarone) using standardized concentration charts before Code Blue events.",
        "Use structured closed-loop communication during resuscitations: repeat medication names and doses out loud upon administration.",
        "Perform post-resuscitation debriefings with the clinical care team to evaluate protocol adherence and psychological well-being."
      ],
      [
        "Zero and calibrate arterial line pressure transducers at the phlebostatic axis (4th intercostal space, mid-axillary line) every shift.",
        "Perform endotracheal suctioning only on clinical indication (audible secretions, desaturation) rather than on fixed hourly schedules.",
        "Implement sedation vacation and spontaneous awakening trials daily to evaluate readiness for mechanical ventilator extubation.",
        "Monitor central venous pressure (CVP) trends in response to fluid challenges rather than relying on isolated static readings.",
        "Enforce strict oral hygiene protocols with chlorhexidine swabs every 4 hours to prevent ventilator-associated pneumonia (VAP)."
      ],
      [
        "Incorporate automated early warning scores (NEWS2) into the electronic nursing dashboard to flag subtle patient deterioration.",
        "Design clinical alert thresholds with hysteresis to prevent nuisance alarms when vital signs hover near trigger boundaries.",
        "Incorporate automated nurse-to-patient acuity weighting models to balance workload distribution across shift rotations.",
        "Audit nursing documentation for adherence to hospital care plans and regulatory accreditation standards (JCI / NABH).",
        "Provide clear clinical rationale and next-step nursing actions alongside automated predictive alerts to support novice nurses."
      ]
    ],
    "phasePitfalls": [
      [
        "Bypassing barcode medication scanning during busy shift hours, which dramatically increases the risk of medication administration errors.",
        "Massaging reddened, non-blanching skin over bony prominences, which tears delicate subcutaneous capillaries and accelerates stage 3 ulceration.",
        "Failing to re-check vital signs after administering antihypertensive or opioid medications to evaluate therapeutic response.",
        "Administering high-alert intravenous medications (potassium chloride, insulin, heparin) without independent dual-nurse verification.",
        "Failing to report subtle changes in respiratory rate (the most sensitive early indicator of clinical deterioration) to the attending team."
      ],
      [
        "Downgrading a triage category based on calm patient demeanor while vital sign indicators show decompensated shock.",
        "Failing to check capillary blood glucose immediately in altered mental status patients, missing easily reversible hypoglycemia.",
        "Interrupting chest compressions during CPR for longer than 10 seconds to check pulses or attempt intubation.",
        "Administering intravenous medications through unverified or extravasated peripheral lines, causing severe tissue necrosis.",
        "Leaving crash cart medication trays unsealed or expired without daily operational checklist sign-offs."
      ],
      [
        "Failing to level the arterial line transducer after patient bed elevation changes, creating falsely elevated or depressed blood pressure readings.",
        "Over-inflating endotracheal tube cuffs beyond 25-30 cm H2O, which compromises tracheal mucosal capillary perfusion and causes necrosis.",
        "Silencing ICU monitor alarms without physically inspecting the patient and verifying circuit connections.",
        "Bolusing vasoactive infusions through un-dedicated peripheral IV lines subject to accidental flushes or interruptions.",
        "Extubating patients without confirming adequate airway protective reflexes, cough strength, and negative cuff leak tests."
      ],
      [
        "Configuring overly sensitive alert thresholds that trigger hundreds of false alarms per shift, causing severe clinical alarm fatigue.",
        "Relying solely on automated computer alerts while neglecting bedside clinical visual assessment and palpation.",
        "Allowing predictive alert systems to interrupt nurses during sterile medication preparation routines.",
        "Failing to train nursing staff on the underlying clinical logic of predictive risk scores, resulting in widespread alert dismissals.",
        "Collecting sensitive clinical telemetry without role-based access control and encrypted data storage at rest."
      ]
    ]
  },
  "Business Analytics": {
    "specialistRole": "Lead Analytics Architect",
    "techStack": {
      "tools": [
        "Power BI Desktop",
        "DAX Studio",
        "Tableau Desktop",
        "Advanced Excel (Power Query)",
        "Tabular Editor"
      ],
      "backend": [
        "Python (Pandas / NumPy / Statsmodels)",
        "SQL Server / PostgreSQL",
        "Jupyter Lab"
      ],
      "database": [
        "Star Schema Data Marts",
        "Snowflake / BigQuery"
      ]
    },
    "tierSuffixes": [
      "Exploratory Analytics & Business Data Pipeline",
      "Executive BI Dashboard & DAX Metrics Platform",
      "Predictive Analytics & Statistical Decision Engine",
      "Autonomous AI Enterprise Insights & Anomaly Sentinel"
    ],
    "architecturePatterns": [
      "Medallion Data Architecture (Bronze Raw -> Silver Cleaned -> Gold Dimension Tables)",
      "Dimensional Star Schema with Explicit DAX Measure Modeling",
      "Supervised Predictive Modeling Pipeline with Cross-Validation",
      "Retrieval-Augmented Conversational Business Intelligence with Automated Anomaly Detection"
    ],
    "phaseProTips": [
      [
        "Profile raw datasets for missing value distributions, skewness, and cardinality before writing transformation pipelines.",
        "Use vectorized Pandas operations and categorical data types to reduce memory footprints on large datasets by over 80%.",
        "Establish data quality expectation suites (Great Expectations) validating schema types, null thresholds, and valid ranges.",
        "Design clean Star Schemas with denormalized dimension tables surrounding fact tables for optimal SQL analytical query speeds.",
        "Document every data transformation decision in reproducible Jupyter / Quarto analysis notebooks with stakeholder takeaways."
      ],
      [
        "Enforce single-direction 1-to-many relationships in Power BI models; avoid bidirectional cross-filtering to prevent ambiguous calculation paths.",
        "Write explicit DAX measures (using DIVIDE, CALCULATE, FILTER) rather than implicit column aggregations or calculated columns.",
        "Use DAX Studio Server Timings to identify expensive visual queries spending more than 100ms in the Formula Engine.",
        "Design executive dashboard cards using the 5-second rule: the primary KPI, trend direction, and variance must be legible at a glance.",
        "Implement Row-Level Security (RLS) in analytical data models using user principal names (USERPRINCIPALNAME()) for multi-tenant data governance."
      ],
      [
        "Conduct rigorous exploratory feature correlation analysis to eliminate multicollinear features (VIF > 5.0) before model training.",
        "Use stratified k-fold cross-validation when modeling imbalanced datasets (e.g. customer churn, fraud detection).",
        "Evaluate classification models using Precision-Recall curves and Area Under PR Curve (PR-AUC) rather than deceptive overall accuracy.",
        "Calculate customer Lifetime Value (LTV) and Customer Acquisition Cost (CAC) payback periods to establish true cohort unit economics.",
        "Translate machine learning model feature importances into clear, non-technical executive business recommendations using SHAP value waterfall plots."
      ],
      [
        "Implement automated statistical anomaly detection using double-exponential smoothing and Z-score alerts on core business KPIs.",
        "Cache semantic vector embeddings of historical financial queries to provide sub-second executive Q&A responses.",
        "Implement strict guardrails ensuring generative BI summaries never fabricate metrics not present in underlying data marts.",
        "Establish automated data drift detection pipelines comparing incoming production inference data against training baselines.",
        "Author comprehensive case studies documenting dollar-for-dollar revenue optimization and cost reduction achieved by your models."
      ]
    ],
    "phasePitfalls": [
      [
        "Applying a single global mean imputation to missing values across heterogeneous customer segments, severely distorting distributions.",
        "Modifying raw source files in place without maintaining an immutable raw bronze staging layer.",
        "Using slow procedural row-by-row iterrows() loops in Python instead of fast vectorized Pandas transformations.",
        "Hardcoding database connection strings and credentials directly inside analytical scripts.",
        "Publishing analytical reports without checking for Survivorship Bias or Selection Bias in the underlying customer survey cohorts."
      ],
      [
        "Creating bidirectional cross-filtering across many-to-many relationships, causing unexpected filter propagation and erroneous calculations.",
        "Creating heavy calculated columns inside fact tables instead of thin DAX measures, consuming massive memory in the VertiPaq engine.",
        "Cluttering executive dashboards with 15+ competing visual cards, pie charts, and gauges that distract from core strategic metrics.",
        "Failing to establish a dedicated Date dimension table, breaking all DAX Time Intelligence functions (YTD, SAMEPERIODLASTYEAR).",
        "Publishing dashboards to production workspaces without validating Row-Level Security permissions across role groups."
      ],
      [
        "Training predictive models on features containing target leakage (e.g. including cancellation date when predicting customer churn).",
        "Relying solely on accuracy metrics when evaluating 99% imbalanced fraud datasets where a dumb \"predict zero\" model achieves 99% accuracy.",
        "Treating correlation as causation when presenting findings to C-suite executives without verifying confounding variables.",
        "Deploying machine learning models without monitoring concept drift as customer purchasing behavior evolves seasonally.",
        "Failing to set up automated model retraining pipelines when prediction errors begin to drift outside acceptable confidence intervals."
      ],
      [
        "Allowing LLM query interfaces to execute raw unvalidated SQL queries directly against production databases without read-only restrictions.",
        "Configuring anomaly alerts on raw daily numbers rather than rolling baselines, triggering panic over normal weekend volume dips.",
        "Failing to log executive user prompts and feedback ratings, leaving product teams unable to diagnose user dissatisfaction.",
        "Presenting raw technical model evaluation metrics (e.g. F1-score: 0.84) to business stakeholders without explaining bottom-line revenue impact.",
        "Exposing sensitive employee salary or customer PII in generative AI dashboard prompts without data masking and redaction."
      ]
    ]
  },
  "BCOM": {
    "specialistRole": "Senior Financial Controller",
    "techStack": {
      "tools": [
        "3-Statement Financial Model in Excel",
        "TallyPrime 4.0",
        "SAP S/4HANA Finance",
        "Power BI Reporting",
        "MCA-21 / XBRL Portal"
      ],
      "standards": [
        "Ind AS / IFRS Standards",
        "GST Portal (GSTR 1/3B/9)",
        "Companies Act 2013 Compliance",
        "Standards on Auditing (SA)"
      ]
    },
    "tierSuffixes": [
      "Statutory Accounting & Financial Compliance Framework",
      "Corporate Direct & Indirect Taxation Engine",
      "Enterprise 3-Statement Valuation & Treasury Platform",
      "Intelligent Audit Sentinel & Forensic Accounting Suite"
    ],
    "architecturePatterns": [
      "Double-Entry Accounting Verification Engine with Real-Time Trial Balance Auditing",
      "Automated GST Input Tax Credit (ITC) Reconciliation & Section 17(5) Gatekeeper",
      "Dynamic 3-Statement Financial Forecasting Engine with Integrated Debt Schedules",
      "Benford Law Anomaly Detection & AI Forensic Transaction Screening Suite"
    ],
    "phaseProTips": [
      [
        "Ensure revenue recognition strictly follows the 5-step model under Ind AS 115 / IFRS 15, identifying distinct performance obligations.",
        "Structure Chart of Accounts with standardized parent-child hierarchies to enable instant drill-down from Balance Sheet to journal vouchers.",
        "Reconcile general ledger accounts with monthly bank statements, generating structured bank reconciliation statements (BRS) with zero unexplained variance.",
        "Distinguish clearly between capital expenditure (CapEx) and operational expenditure (OpEx) to avoid distorting reported EBITDA.",
        "Format financial reports adhering strictly to Schedule III Division II of the Companies Act 2013 for corporate statutory presentation."
      ],
      [
        "Perform automated monthly reconciliation between the Purchase Register and GSTR-2B before finalizing monthly GSTR-3B filings.",
        "Segregate blocked input tax credits under Section 17(5) (e.g. motor vehicles, food & beverages) to prevent audit penalties.",
        "Verify reverse charge mechanism (RCM) liabilities on unregistered vendor procurements and import of services under Section 9(3)/9(4).",
        "Calculate corporate advance tax liability quarterly based on estimated profits, adhering to mandatory installment deadlines (15%, 45%, 75%, 100%).",
        "Reconcile Tax Deducted at Source (TDS) entries in financial books against Form 26AS and AIS before filing quarterly TDS returns (24Q/26Q)."
      ],
      [
        "Link Income Statement net income dynamically to the Cash Flow Statement and Balance Sheet retained earnings with zero hardcoded balancing figures.",
        "Sensitize Weighted Average Cost of Capital (WACC) and terminal growth rates in a dynamic DCF sensitivity matrix (data tables).",
        "Incorporate circularity breakers in financial models when calculating dynamic interest expense tied to average revolving debt balances.",
        "Calculate working capital operating cycle (DIO + DSO - DPO) to identify trapped cash flow across inventory and accounts receivable aging.",
        "Perform scenario analysis (Bull, Base, Bear cases) toggling revenue growth assumptions, gross margins, and debt interest rates dynamically."
      ],
      [
        "Apply Benford Law first-digit statistical tests across vendor invoice registers to detect fraudulent or fabricated expense vouchers.",
        "Cross-reference vendor GSTINs against cancelled and non-compliant GST portal databases to prevent fake invoicing fraud.",
        "Screen general ledger journal entries for high-risk red flags: entries posted on weekends, round-number vouchers, and entries just below authorization limits.",
        "Generate automated working paper documentation cross-referencing audit findings directly to Standards on Auditing (SA 240 / SA 315).",
        "Publish an executive audit committee deck summarizing key audit matters (KAM), internal financial control gaps, and corrective action timelines."
      ]
    ],
    "phasePitfalls": [
      [
        "Capitalizing routine maintenance expenses as fixed assets to artificially inflate current-period operating profits.",
        "Failing to adjust closing stock balances for obsolete or slow-moving inventory under the lower of cost or net realizable value (NRV) rule.",
        "Booking revenue prior to transferring control of goods or satisfying performance obligations to customers.",
        "Omitting contingent liabilities (pending tax disputes, corporate guarantees) from financial statement disclosure notes.",
        "Allowing un-reconciled suspense account balances to carry forward across accounting year-end financial closings."
      ],
      [
        "Claiming Input Tax Credit on vendor invoices that do not appear in GSTR-2B, leading to automated GST portal demand notices with 18% interest.",
        "Failing to reverse ITC on invoice payments pending beyond 180 days from the date of issue under the second proviso to Section 16(2).",
        "Missing quarterly advance tax deadlines, triggering mandatory penal interest calculations under Sections 234B and 234C.",
        "Misclassifying employee compensation as professional fees to avoid employer Provident Fund contributions, risking severe labor law penalties.",
        "Filing direct tax returns without reconciling turnover figures between financial books, GSTR-9, and the Income Tax AIS database."
      ],
      [
        "Mismatching cash flows and discount rates in valuation models (e.g. discounting Free Cash Flow to Equity using WACC instead of Cost of Equity).",
        "Allowing terminal value to exceed 85% of total enterprise value without justifying why the firm will outpace the long-term GDP growth rate.",
        "Hardcoding numbers inside formula cells in financial model calculation tabs, destroying financial auditability.",
        "Ignoring deferred tax liabilities resulting from temporary timing differences between book depreciation and tax depreciation.",
        "Failing to model debt covenant thresholds (e.g. minimum DSCR > 1.25x), giving management a false sense of debt repayment security."
      ],
      [
        "Relying solely on management written representations without independently obtaining third-party bank confirmations and debtor balance verifications.",
        "Failing to document substantive analytical procedures and justification for sample size selections in statutory audit working papers.",
        "Treating audit anomaly alerts as conclusive evidence of fraud without performing detailed corroborative voucher tracing.",
        "Conducting audit sampling on non-representative populations, missing high-risk unusual transactions outside standard testing thresholds.",
        "Failing to report identified material weaknesses in Internal Financial Controls over Financial Reporting (IFCoFR) to the board of directors."
      ]
    ]
  },
  "BBA": {
    "specialistRole": "Principal Business Strategist",
    "techStack": {
      "tools": [
        "Jira Agile Scrum Board",
        "Tableau Executive Dashboards",
        "HubSpot CRM / GA4",
        "Notion Product Wiki",
        "Miro Process Flowcharting"
      ],
      "frameworks": [
        "Porter Five Forces Model",
        "Balanced Scorecard (BSC)",
        "Economic Order Quantity (EOQ)",
        "OKRs & KPI Cascading"
      ]
    },
    "tierSuffixes": [
      "Business Model Strategy & Market Feasibility Blueprint",
      "Digital Marketing Growth & Customer Acquisition Platform",
      "Enterprise Supply Chain & Operational Excellence System",
      "Autonomous AI Product Strategy & Decision Copilot"
    ],
    "architecturePatterns": [
      "Strategic Framework Mapping (PESTLE, Porter 5 Forces, Value Chain)",
      "Omnichannel Growth Funnel with Cohort Unit Economics Modeling",
      "Demand-Driven Supply Chain Network with Just-In-Time (JIT) Buffer Control",
      "Retrieval-Augmented Competitive Intelligence & Dynamic Pricing Engine"
    ],
    "phaseProTips": [
      [
        "Quantify Total Addressable Market (TAM), Serviceable Addressable Market (SAM), and Serviceable Obtainable Market (SOM) using bottom-up calculations.",
        "Conduct competitor teardowns mapping features against customer willingness-to-pay using Strategy Canvas value curves.",
        "Validate problem-solution fit through at least 30 structured customer discovery interviews using The Mom Test methodology.",
        "Define clear North Star Metrics and cascade company Objectives and Key Results (OKRs) into bi-weekly team deliverables.",
        "Present strategic business plans with clear unit economics: show customer lifetime value (LTV), acquisition cost (CAC), and payback timelines."
      ],
      [
        "Optimize marketing budgets across acquisition channels to maintain an LTV-to-CAC ratio greater than 3.0 and payback under 12 months.",
        "Structure multi-variant A/B test experiments with clear null hypotheses and sample sizes calculated for 95% statistical significance.",
        "Map end-to-end customer journey touchpoints to identify the primary drop-off stages in your conversion funnel.",
        "Implement automated email nurture workflows triggered by behavioral events (abandoned cart, feature inactivity) rather than arbitrary timers.",
        "Track monthly cohort retention curves to verify whether customer retention flattens into a healthy smile curve over 6 months."
      ],
      [
        "Calculate Economic Order Quantity (EOQ) incorporating annual carrying costs, ordering costs, and supplier volume discount tiers.",
        "Establish safety stock buffers using demand standard deviation and target service level Z-scores (e.g. 95% service level = Z: 1.65).",
        "Map internal business processes using BPMN 2.0 notation, identifying non-value-added bottlenecks that inflate lead times.",
        "Implement supplier scorecard metrics evaluating on-time in-full (OTIF) delivery rates, quality reject ratios, and payment compliance.",
        "Design dual-sourcing contingency plans for critical inventory components to mitigate single-supplier supply chain disruptions."
      ],
      [
        "Incorporate automated competitive web scraping and pricing telemetry into real-time executive market intelligence dashboards.",
        "Use natural language sentiment analysis on customer reviews to extract recurring feature requests and product frustration themes.",
        "Build dynamic pricing elasticity models that adjust promotional discounts based on real-time inventory holding levels.",
        "Establish structured Product Requirement Documents (PRDs) with clear user stories, edge cases, and engineering acceptance criteria.",
        "Author comprehensive strategic case studies detailing ROI, operational margin expansion, and market share capture."
      ]
    ],
    "phasePitfalls": [
      [
        "Using top-down market sizing based on arbitrary 1% market capture claims instead of verified bottom-up pricing models.",
        "Confusing customer praise in interviews with genuine purchasing intent; only commitments involving time, data, or money validate demand.",
        "Establishing 15+ competing company priorities instead of focusing executive attention on 3 measurable strategic OKRs.",
        "Failing to analyze regulatory, legal, and intellectual property barriers to entry in your competitive landscape analysis.",
        "Drafting pitch decks that highlight product features rather than quantifying customer ROI and quantifiable business outcomes."
      ],
      [
        "Pouring paid advertising budget into top-of-funnel customer acquisition while 30-day cohort retention drops to zero (leaky bucket).",
        "Ending A/B tests prematurely after 3 days upon seeing a temporary spike without reaching statistical significance.",
        "Evaluating marketing campaigns on vanity metrics (impressions, social likes) rather than qualified leads and revenue attribution.",
        "Blasting unsegmented generic email newsletters to all contacts, causing high unsubscribe rates and domain spam reputation damage.",
        "Failing to track customer acquisition cost (CAC) on a fully-loaded basis (including marketing salaries, software tooling, and agency fees)."
      ],
      [
        "Operating with Just-In-Time (JIT) lean inventory models without safety buffers during periods of global geopolitical logistics volatility.",
        "Failing to factor in inventory carrying costs (storage, insurance, obsolescence, capital cost) which typically total 20-30% of inventory value annually.",
        "Measuring manufacturing efficiency solely on machine utilization, which incentivizes overproduction of unneeded inventory.",
        "Over-relying on a single overseas vendor without auditing their financial solvency and secondary manufacturing capacity.",
        "Automating a broken, inefficient business process with expensive enterprise software instead of fixing the underlying workflow first."
      ],
      [
        "Deploying dynamic pricing algorithms without price floor constraints, triggering self-destructive automated race-to-the-bottom price wars.",
        "Relying on generic AI market summaries without verifying data recency against primary quarterly earnings filings.",
        "Allowing product teams to build features based on subjective executive intuition without validating against behavioral analytics data.",
        "Failing to establish privacy protections when analyzing customer demographic and behavioral tracking datasets.",
        "Presenting operational recommendations without calculating return on invested capital (ROIC) and payback periods for stakeholders."
      ]
    ]
  },
  "BA LLB": {
    "specialistRole": "Senior Legal Counsel",
    "techStack": {
      "tools": [
        "SCC Online Web Edition",
        "Manupatra Precedent Database",
        "MS Word Advanced Redline / Track Changes",
        "ContractPodAi / Ironclad CLM",
        "DocuSign Legal Workflows"
      ],
      "jurisprudence": [
        "Bharatiya Nyaya Sanhita (BNS)",
        "Companies Act 2013",
        "Arbitration & Conciliation Act 1996",
        "Digital Personal Data Protection (DPDP) Act 2023"
      ]
    },
    "tierSuffixes": [
      "Commercial Contract Drafting & Risk Allocation Framework",
      "Corporate Governance & Regulatory Compliance Portal",
      "Commercial Dispute Resolution & Arbitration Suite",
      "Intelligent Legal Due Diligence & Contract Analytics Engine"
    ],
    "architecturePatterns": [
      "Structured Legal Instrument Drafting with Standardized Boilerplate Segregation",
      "Regulatory Compliance Matrix with Automated Board Resolution Governance",
      "Multi-Tier Dispute Resolution Escalation Framework with Institutional Arbitration Rules",
      "Retrieval-Augmented Precedent Analysis & Clause Anomaly Detection Engine"
    ],
    "phaseProTips": [
      [
        "Draft clear, reciprocal carve-outs to the Limitation of Liability clause for gross negligence, willful misconduct, and IP infringement.",
        "Structure Indemnification clauses with precise triggers, explicit control-of-defense procedures, and mandatory mitigation obligations.",
        "Ensure representations and warranties are explicitly tied to indemnity remedies or damages, specifying survival periods post-closing.",
        "Define Governing Law and Exclusive Jurisdiction clearly; never leave dispute forum selection silent or ambiguous.",
        "Use defined terms consistently with capitalized initial letters; compile a dedicated Section 1 definitions schedule to prevent judicial misinterpretation."
      ],
      [
        "Ensure related-party transactions (RPTs) comply with Section 188 approval thresholds and audit committee scrutiny under the Companies Act 2013.",
        "Structure Board Resolutions with unambiguous explanatory statements demonstrating compliance with directors fiduciary duties under Section 166.",
        "Draft comprehensive Shareholder Agreements (SHA) incorporating clear drag-along, tag-along, ROFR, and liquidation preference waterfalls.",
        "Audit corporate secretarial records to ensure timely filing of MCA forms (MGT-7, AOC-4, DIR-12) within statutory limitation periods.",
        "Establish an independent whistleblower and POSH Internal Committee framework to maintain corporate governance integrity."
      ],
      [
        "Draft multi-tier dispute resolution clauses specifying mandatory executive negotiation, mediation, and finally institutional arbitration.",
        "Explicitly designate the \"Seat\" of arbitration (which determines supervisory court curial law), not merely the convenient geographical \"Venue\".",
        "Specify the number of arbitrators (sole vs three-member tribunal), appointing authority, and governing institutional rules (MCIA, SIAC, LCIA).",
        "Draft Section 9 interim relief petitions with demonstrable proof of prima facie case, balance of convenience, and irreparable injury.",
        "Ensure arbitral awards adhere strictly to public policy boundaries under Section 34 of the Arbitration and Conciliation Act 1996."
      ],
      [
        "Index and categorize M&A due diligence documentation into structured virtual data rooms (VDR) across corporate, labor, IP, and tax streams.",
        "Author comprehensive Red-Flag Due Diligence Memos highlighting material litigation risks, regulatory license gaps, and change-of-control triggers.",
        "Map personal data collection touchpoints against the Digital Personal Data Protection (DPDP) Act 2023, identifying legitimate uses and notice mechanisms.",
        "Draft standardized Data Processing Agreements (DPAs) with mandatory data breach notification timelines (within 72 hours).",
        "Publish an executive legal risk matrix categorizing identified contract liabilities by probability and financial exposure."
      ]
    ],
    "phasePitfalls": [
      [
        "Using generic copy-pasted indemnity boilerplate that exposes the client to unlimited indirect, consequential, and punitive damages.",
        "Failing to specify whether a contract termination clause requires cause, cure periods, or allows termination for convenience upon written notice.",
        "Allowing ambiguous survival clauses where confidentiality and non-solicitation obligations expire immediately upon contract termination.",
        "Confusing the legal distinction between \"best efforts\" and \"commercially reasonable efforts\" under standard common law interpretation.",
        "Failing to obtain necessary corporate board authorizations or power of attorney approvals prior to contract execution."
      ],
      [
        "Passing board resolutions on related-party contracts with interested directors participating and voting, rendering the resolution void.",
        "Failing to disclose shareholder voting agreements in public company filings where required by SEBI (LODR) regulations.",
        "Drafting share transfer restriction clauses without mirroring them into the company Articles of Association (AoA), making them unenforceable against the company.",
        "Missing statutory annual return filing deadlines on the MCA portal, triggering severe cumulative director disqualification penalties under Section 164.",
        "Failing to conduct periodic POSH compliance training, exposing the corporate entity to severe reputational damage and legal liability."
      ],
      [
        "Conflating the legal concepts of \"Seat\" and \"Venue\" in arbitration clauses, triggering protracted litigation over court jurisdiction.",
        "Drafting pathological arbitration clauses with contradictory terms (e.g. naming two competing arbitration institutions simultaneously).",
        "Filing Section 11 arbitration appointment applications before fulfilling mandatory pre-arbitration conciliation steps outlined in the contract.",
        "Failing to issue a formal Section 21 Notice of Arbitration invoking the arbitration clause before approaching the High Court for arbitrator appointment.",
        "Delaying enforcement petitions for domestic awards beyond statutory limitation periods."
      ],
      [
        "Conducting M&A due diligence without reviewing underlying customer contracts for change-of-control termination triggers.",
        "Overlooking unresolved statutory employee gratuity and provident fund liabilities during corporate acquisition audits.",
        "Processing personal data without documented user consent frameworks, exposing the organization to statutory DPDP Act penalties up to 250 Crores.",
        "Failing to verify whether intellectual property developed by contractors was explicitly assigned in writing under IP assignment agreements.",
        "Presenting raw legal citations to C-suite clients without translating risks into concrete commercial deal adjustments or escrow holdbacks."
      ]
    ]
  },
  "Mechanical": {
    "specialistRole": "Senior Mechanical Design Engineer",
    "techStack": {
      "tools": [
        "SolidWorks 2024 (Parametric CAD)",
        "ANSYS Mechanical (FEA)",
        "Mastercam CNC CAM Toolpaths",
        "Mitutoyo Digital Calipers & CMM",
        "MATLAB Simulink Thermal Toolbox"
      ],
      "standards": [
        "ASME Y14.5 Geometric Dimensioning & Tolerancing (GD&T)",
        "Design for Manufacturing and Assembly (DFMA)",
        "Von Mises Yield Criterion",
        "TEMA Heat Exchanger Standards"
      ]
    },
    "tierSuffixes": [
      "Parametric 3D CAD & Precision Engineering Blueprint",
      "Finite Element Analysis (FEA) Structural Optimization Suite",
      "Thermal-Fluid Heat Exchanger & Thermodynamic System",
      "Generative AI Mechanical Component & DFMA Validator"
    ],
    "architecturePatterns": [
      "Top-Down Parametric Assembly with Skeleton Modeling & Kinematic Mates",
      "Non-Linear Structural FEA with Mesh Convergence & Fatigue Life Estimation",
      "Thermal-Hydraulic Sizing Engine with Log Mean Temperature Difference (LMTD)",
      "Generative Topology Optimization with Automated DFM Toolpath Verification"
    ],
    "phaseProTips": [
      [
        "Establish fully defined 2D sketches referencing primary origin planes before extruding features; avoid floating under-defined geometry.",
        "Select functional datums that mirror physical manufacturing fixturing and mating surfaces in assembly.",
        "Apply ASME Y14.5 Geometric Dimensioning & Tolerancing (GD&T) feature control frames to govern critical hole locations and planar parallelism.",
        "Design plastic injection molded parts with uniform wall thickness and 1-2 degree draft angles to prevent sink marks and mold sticking.",
        "Generate comprehensive Bills of Materials (BOM) linking part numbers, materials, quantities, and supplier part numbers directly to 3D assemblies."
      ],
      [
        "Perform mesh convergence studies by refining element sizes until maximum von Mises stress changes by less than 3% between iterations.",
        "Apply boundary constraints that accurately replicate physical bolted and pinned joints rather than applying artificial rigid zero-displacement fixtures.",
        "Check factor of safety (FOS) against material yield strength for static loads, maintaining FOS > 1.5 for critical structural members.",
        "Calculate fatigue life using S-N curves and Miner Rule when evaluating cyclic loading on alternating mechanical components.",
        "Document finite element analysis reports with full boundary condition illustrations, mesh metrics, and stress contour plots."
      ],
      [
        "Size shell-and-tube heat exchangers using Log Mean Temperature Difference (LMTD) with F-correction factors for multi-pass configurations.",
        "Calculate tube-side and shell-side pressure drops to ensure pumping power requirements remain within allowable hydraulic limits.",
        "Account for fouling resistance factors over time to guarantee specified heat transfer rates after months of operation.",
        "Select heat exchanger materials (316L Stainless, Titanium, Copper-Nickel) based on corrosion resistance and thermal conductivity profiles.",
        "Incorporate thermal expansion relief bellows or floating head designs to prevent thermal stress cracking during startup and shutdown."
      ],
      [
        "Set up generative topology optimization boundary conditions with design and non-design spaces to achieve 30% lightweighting.",
        "Simulate CNC milling toolpaths in Mastercam, verifying cutter entry angles, chip load per tooth, and collision clearance.",
        "Audit components against DFMA principles: minimize fastener counts by incorporating snap fits and self-aligning features.",
        "Verify additive manufacturing overhang angles (keep > 45 degrees) to eliminate unnecessary internal support structures.",
        "Author comprehensive engineering case studies featuring 3D CAD renders, stress comparison charts, and manufacturing cost savings."
      ]
    ],
    "phasePitfalls": [
      [
        "Creating circular external references across parts in top-down assemblies, resulting in slow rebuild times and broken component mates.",
        "Specifying overly tight dimensional tolerances (e.g. \u00b10.002 mm) on non-critical features, needlessly inflating manufacturing costs by 400%.",
        "Designing deep internal right-angle pockets that cannot be cut by standard rotating CNC end mills without specialized EDM tooling.",
        "Neglecting thermal expansion clearances between dissimilar metal components (e.g. aluminum housing with steel shaft).",
        "Publishing 2D manufacturing drawings without specifying surface finish roughness (Ra) and burr removal notes."
      ],
      [
        "Applying rigid boundary constraints directly on sharp re-entrant corners, causing artificial stress singularities with infinite stresses.",
        "Using coarse, distorted tetrahedral meshes in high-stress gradient zones, which severely underestimates peak von Mises stresses.",
        "Evaluating fatigue life under cyclic loads using static yield strength criteria, leading to sudden catastrophic fatigue fractures.",
        "Ignoring material non-linearity and plastic deformation when analyzing components subjected to severe overload conditions.",
        "Failing to verify FEA simulation results against analytical hand calculations or physical prototype strain gauge testing."
      ],
      [
        "Optimizing heat transfer coefficient while ignoring excessive fluid velocity, which causes severe tube erosion and pump cavitation.",
        "Operating shell-and-tube heat exchangers in laminar flow regimes where heat transfer rates drop precipitously.",
        "Neglecting fluid cross-flow induced tube vibration, which leads to tube-to-baffle fretting wear and premature tube failure.",
        "Failing to provide adequate drain and vent ports, resulting in trapped air pockets that degrade thermal efficiency.",
        "Using incompatible tube and tubesheet materials without galvanic isolation, causing rapid localized galvanic corrosion."
      ],
      [
        "Generating un-manufacturable topology optimized geometries that require expensive 5-axis machining or metal 3D printing without commercial justification.",
        "Failing to verify whether lightweighted structures maintain required natural vibrational frequencies, risking resonance under operational speeds.",
        "Exporting STL files with coarse chordal tolerance tessellations, producing faceted surfaces on precision cylindrical bores.",
        "Ignoring tool deflection during high-speed CNC milling of thin-walled features, resulting in out-of-tolerance part dimensions.",
        "Presenting product designs without physical prototype testing validation under realistic environmental temperature extremes."
      ]
    ]
  },
  "Civil": {
    "specialistRole": "Senior Structural Engineer",
    "techStack": {
      "tools": [
        "STAAD.Pro Connect Edition (Structural Analysis)",
        "Autodesk Revit (BIM & Clash Detection)",
        "Primavera P6 (CPM Scheduling)",
        "AutoCAD Civil 3D",
        "GeoStudio Soil Stability"
      ],
      "standards": [
        "IS 456 / ACI 318 Reinforced Concrete Code",
        "IS 1893 Seismic Design Code",
        "IS 875 Wind Load Specifications",
        "CPWD / DSR Schedule of Rates"
      ]
    },
    "tierSuffixes": [
      "3D Space Frame & Seismic Structural Engineering Blueprint",
      "Building Information Modeling (BIM) & Clash Coordination Platform",
      "Reinforced Concrete Design & Foundation Engineering System",
      "Autonomous AI Structural Optimization & Construction Cost Sentinel"
    ],
    "architecturePatterns": [
      "Finite Element Space Frame Model with Equivalent Static & Response Spectrum Seismic Analysis",
      "Multi-Disciplinary Federated BIM Model with Automated 4D Construction Scheduling",
      "Limit State Reinforced Concrete Design with Soil-Structure Interaction Foundations",
      "Parametric Structural Topology Optimization with Real-Time BOQ Material Estimation"
    ],
    "phaseProTips": [
      [
        "Verify base shear reactions against manual IS 1893 seismic calculations before accepting multi-story 3D frame displacements.",
        "Model primary lateral load resisting systems (shear walls, moment frames) to satisfy maximum story drift limits (h/250).",
        "Release beam-end moments at secondary beam connections to prevent unrealistic torsion transfer into supporting girders.",
        "Apply dead loads, live loads (IS 875 Part 2), and wind pressure load combinations with appropriate partial safety factors (1.5 DL + 1.5 LL).",
        "Document structural design calculation briefs cross-referencing bending moment envelopes, shear force diagrams, and reinforcement schedules."
      ],
      [
        "Establish a unified shared coordinate system across architectural, structural, and MEP Revit models to prevent spatial misalignment.",
        "Run automated Navisworks clash tests between structural beams and HVAC ductwork, eliminating clashes before pouring concrete on site.",
        "Structure the 3D model with Level of Development (LOD 350) containing accurate rebar detailing and mechanical connection points.",
        "Link 3D BIM components to Primavera P6 construction activities to generate dynamic 4D construction schedule simulations.",
        "Export automated Bill of Quantities (BOQ) with precise rebar tonnage, concrete volume, and formwork area straight from the model."
      ],
      [
        "Design reinforced concrete beams ensuring under-reinforced failure modes (xu < xu,max) to provide ductile warning before failure.",
        "Check crack width criteria and long-term creep deflection in addition to ultimate limit state flexural moment capacities.",
        "Ensure ductile detailing of column-beam joints following IS 13920 seismic detailing provisions (close tie spacing, anchor development length).",
        "Calculate soil bearing capacity using Terzaghi formulas incorporating water table depth and settlement criteria (limiting settlement < 25 mm).",
        "Design isolated and raft footings with adequate shear depth to prevent two-way punching shear failure around column bases."
      ],
      [
        "Incorporate automated topology optimization algorithms to minimize concrete and steel quantities while meeting structural deflection limits.",
        "Implement computer vision inspection pipelines analyzing construction site drone footage for rebar spacing verification.",
        "Build dynamic cost variance tracking models comparing actual site material consumption against budgeted CPWD/DSR rates.",
        "Generate automated structural inspection checklists cross-referenced to standard testing protocols (slump test, cube compressive strength).",
        "Author comprehensive structural engineering portfolio case studies showcasing seismic stability reports, BIM walkthroughs, and cost savings."
      ]
    ],
    "phasePitfalls": [
      [
        "Forgetting to release beam-end moments at secondary beam connections, resulting in unrealistic torsion transfer into supporting girders.",
        "Ignoring vertical and plan irregularities in building geometry, which triggers severe torsional amplification during earthquakes.",
        "Designing columns based on axial load alone without accounting for biaxial bending moments caused by lateral wind and seismic forces.",
        "Applying arbitrary stiffness reduction factors to structural members without justification from IS 1893 seismic design standards.",
        "Failing to verify joint equilibrium and reactions at base supports in finite element structural analysis software."
      ],
      [
        "Over-modeling small hardware items in Revit families, inflating file sizes beyond 500MB and crippling model navigation.",
        "Conducting clash coordination late in the construction phase after rebar has been ordered and ductwork fabricated.",
        "Failing to establish model maintenance protocols, resulting in discrepancies between architectural floor levels and structural slab elevations.",
        "Relying on generic material families without specifying concrete strength grades (M25, M30) and rebar yield strength (Fe 500D).",
        "Exporting quantities from incomplete 3D models without cross-checking against traditional 2D structural layout drawings."
      ],
      [
        "Over-congesting reinforcement rebar at column-beam junctions, preventing concrete aggregate from flowing and creating fatal honeycombing.",
        "Failing to provide adequate development length (Ld) for tension reinforcement bars terminating at beam supports.",
        "Assuming uniform soil strata without assessing high groundwater table fluctuations, risking liquefaction or excessive differential settlement.",
        "Neglecting long-term creep deflection when designing slender reinforced concrete slabs with long spans.",
        "Omitting shear reinforcement in deep transfer girders, risking brittle diagonal tension failure under heavy concentrated column loads."
      ],
      [
        "Reducing rebar quantities in structural elements without checking maximum bar spacing limits required for surface crack width control.",
        "Treating drone construction progress photos as verified inspection sign-offs without certified site engineer physical verification.",
        "Relying on generic historical cost indices without accounting for local steel rebar and cement market price inflation.",
        "Deploying parametric structural models without validating geometric constraints against site access and constructability limitations.",
        "Publishing structural calculations without signing off on peer-review checks by an independent chartered structural engineer."
      ]
    ]
  },
  "Electrical": {
    "specialistRole": "Senior Embedded Hardware Architect",
    "techStack": {
      "tools": [
        "Altium Designer (Multi-Layer PCB)",
        "Keil MDK / STM32CubeIDE (Embedded C)",
        "Saleae Logic Pro Analyzer",
        "MATLAB Simulink Power Systems",
        "Keysight Digital Storage Oscilloscope"
      ],
      "hardware": [
        "ARM Cortex-M4 Microcontroller",
        "3-Phase Inverter Bridge (MOSFET/IGBT)",
        "CAN Bus / SPI / I2C / UART Interfaces",
        "Li-Ion Battery Management System (BMS)"
      ]
    },
    "tierSuffixes": [
      "Embedded C Firmware & ARM Cortex Microcontroller Blueprint",
      "High-Speed Multi-Layer PCB Design & Signal Integrity Platform",
      "Power Electronics Motor Inverter & Gate Driver Suite",
      "EV Battery Management System (BMS) Telemetry & SoC Sentinel"
    ],
    "architecturePatterns": [
      "Bare-Metal HAL & Register Abstraction Layer with Deterministic ISR Handlers",
      "Controlled Impedance Multi-Layer Stackup with Continuous Ground Return Planes",
      "Space Vector Pulse Width Modulation (SVPWM) with Hardware Dead-Time Insertion",
      "Extended Kalman Filter (EKF) State of Charge (SoC) & Active Cell Balancing Architecture"
    ],
    "phaseProTips": [
      [
        "Declare hardware peripheral registers and variables shared with Interrupt Service Routines (ISRs) as \"volatile\" in C to prevent compiler optimization bugs.",
        "Configure direct memory access (DMA) controllers for high-throughput SPI/UART data streams, freeing up CPU cycles for core application calculations.",
        "Implement circular ring buffers with head and tail pointers for non-blocking serial communication.",
        "Use hardware timer input-capture channels rather than polling loops to measure PWM pulse widths with sub-microsecond precision.",
        "Configure independent hardware watchdog timers (IWDG) to automatically reset firmware in the event of an unhandled hard fault or deadlock."
      ],
      [
        "Maintain continuous, unbroken ground return reference planes directly beneath high-speed differential pairs (USB, Ethernet, CAN).",
        "Calculate trace width and dielectric spacing using IPC-2141 formulas to match single-ended (50 ohm) and differential (90/100 ohm) characteristic impedance.",
        "Place high-frequency ceramic decoupling capacitors (0.1 uF) immediately adjacent to IC power pins with short, low-inductance via pairs.",
        "Route high-frequency switching power supply inductor loops with minimal surface area to contain electromagnetic radiation (EMI).",
        "Generate comprehensive Gerber RS-274X manufacturing files, IPC-D-356 netlists, and drill tables with clear board fabrication notes."
      ],
      [
        "Incorporate hardware dead-time (minimum 1.5 us) between complementary high-side and low-side gate driver pulses to eliminate shoot-through current spikes.",
        "Use isolated gate driver ICs with high Common Mode Transient Immunity (CMTI > 100 kV/us) to survive rapid dV/dt switching transients in SiC/GaN FETs.",
        "Design Kelvin source connections on power MOSFET packages to prevent load current feedback into the gate drive loop.",
        "Calculate thermal heatsink resistance (Rth_ha) based on maximum continuous RMS load currents and ambient operating temperatures.",
        "Implement fast hardware desaturation (DESAT) fault detection circuits that shut down gate pulses within 2 microseconds of an overcurrent event."
      ],
      [
        "Implement Extended Kalman Filtering (EKF) combining Coulomb counting with open-circuit voltage curves for accurate battery State of Charge (SoC).",
        "Design active cell balancing circuits that transfer energy from higher-voltage cells to lower-voltage cells with minimal thermal dissipation.",
        "Monitor individual cell voltages and multi-point NTC thermistor temperatures across the battery pack with sub-millivolt accuracy.",
        "Incorporate dual redundant contactors (positive and negative) with a pre-charge resistor circuit to prevent high inrush current into inverter DC bus capacitors.",
        "Author comprehensive hardware testing reports validating thermal runaway containment, short-circuit response times, and ISO 26262 ASIL-D safety compliance."
      ]
    ],
    "phasePitfalls": [
      [
        "Executing blocking delay loops or heavy printf debugging calls inside Interrupt Service Routines (ISRs), causing missed interrupts and system crashes.",
        "Failing to handle compiler structure padding and alignment when transmitting binary communication packets across mismatched CPU architectures.",
        "Leaving unused microcontroller GPIO pins floating in high-impedance states, which draws excessive leakage current and introduces noise.",
        "Allocating dynamic heap memory (malloc/free) inside real-time embedded firmware, risking catastrophic runtime heap fragmentation.",
        "Failing to debounce physical pushbuttons and limit switches in hardware or software, resulting in spurious repeated trigger events."
      ],
      [
        "Routing high-speed clock or signal traces across split power/ground planes, which creates massive electromagnetic loop antennas and fails FCC/CE testing.",
        "Placing decoupling capacitors far from IC power pins, where trace inductance renders them completely ineffective against high-frequency voltage dips.",
        "Connecting analog ground (AGND) and digital ground (DGND) in multiple locations, creating noisy ground loops that corrupt ADC sensor readings.",
        "Using overly thin copper traces for high-current power paths without verifying IPC-2152 temperature rise standards.",
        "Specifying unstandardized via drill sizes that needlessly increase PCB fabrication tooling costs."
      ],
      [
        "Omitting hardware dead-time between complementary inverter switching transistors, resulting in catastrophic shoot-through and exploded MOSFETs.",
        "Underestimating MOSFET reverse recovery charge (Qrr) of body diodes in inductive switching circuits, causing severe switching losses and over-temperature shutdown.",
        "Neglecting gate drive loop parasitic inductance, which triggers destructive gate-to-source voltage ringing that punctures gate oxide layers.",
        "Relying solely on software interrupt routines for short-circuit protection instead of dedicated hardware comparator trips.",
        "Operating electrolytic DC bus capacitors near their maximum ripple current ratings, leading to rapid electrolyte dry-out and premature failure."
      ],
      [
        "Relying solely on open-circuit cell voltage for battery SoC estimation under active vehicle acceleration, resulting in wild gauge fluctuations and unexpected shutdown.",
        "Failing to isolate high-voltage traction battery packs (> 400V) from 12V chassis ground, creating fatal electric shock hazards for technicians.",
        "Allowing cell balancing to run during active vehicle charging without monitoring temperature, triggering localized hot spots and thermal runaway.",
        "Neglecting contactor weld detection routines before closing high-voltage battery contactors.",
        "Presenting battery management hardware without physical thermal chamber validation under sub-zero and maximum operating temperatures."
      ]
    ]
  },
  "Chemical": {
    "specialistRole": "Senior Chemical Process Engineer",
    "techStack": {
      "tools": [
        "Aspen Plus / Aspen HYSYS (Process Simulation)",
        "AutoCAD P&ID (ISA-5.1 Symbols)",
        "ChemCAD Flowsheet Engine",
        "HAZOP Risk Matrix Worksheets",
        "Polymath ODE Reactor Solver"
      ],
      "standards": [
        "McCabe-Thiele Distillation Methodology",
        "NRTL / Peng-Robinson Thermodynamic Models",
        "OSHA Process Safety Management (PSM)",
        "API 520 / 521 Pressure Relief Standards"
      ]
    },
    "tierSuffixes": [
      "Process Flowsheet Simulation & Thermodynamic Convergence Blueprint",
      "Distillation Column Sizing & Multi-Component Separation Platform",
      "Process Safety Management (PSM) & HAZOP Analysis Suite",
      "Autonomous Plant Energy Integration & Pinch Optimization Sentinel"
    ],
    "architecturePatterns": [
      "Sequential Modular Steady-State Process Simulation with Closed-Loop Tear Stream Convergence",
      "Equilibrium Stage Vapor-Liquid Mass Transfer Model with Hydraulic Tray Sizing",
      "Layer of Protection Analysis (LOPA) & Safety Instrumented System (SIS) Safety Matrix",
      "Pinch Analysis Heat Exchanger Network (HEN) Synthesis with Minimum Utility Consumption"
    ],
    "phaseProTips": [
      [
        "Validate thermodynamic property packages (NRTL vs Peng-Robinson) against experimental vapor-liquid equilibrium (VLE) data before running flash convergence.",
        "Select tear streams with moderate flow rates and minimal sensitivity to accelerate flowsheet recycle loop convergence.",
        "Perform overall mass and elemental stoichiometric balances across reactor blocks to verify conservation of mass before refining unit details.",
        "Document physical property parameter regressions with residual root mean square error (RMSE) comparison plots.",
        "Establish standardized stream summary tables detailing temperature, pressure, vapor fraction, molar enthalpy, and component flow rates."
      ],
      [
        "Size distillation column diameters based on 80% of flooding velocity to prevent liquid entrainment and excessive pressure drop across tray decks.",
        "Calculate minimum reflux ratio (Rmin) using the Underwood equation and operate at an optimal economic reflux ratio (typically 1.2 * Rmin).",
        "Select column internals (sieve trays vs structured packing) based on operating pressure, liquid loading, and fouling propensities.",
        "Incorporate temperature-composition cascade control loops on sensitive stage temperatures to maintain overhead distillate purity.",
        "Design column reboiler circuits with adequate thermosiphon liquid driving head to guarantee stable two-phase natural circulation."
      ],
      [
        "Apply HAZOP guide words (More, Less, Reverse, No, As Well As) systematically to every process node and piping line.",
        "Size pressure relief valves (PRVs) according to API 520 / 521 standards, considering worst-case fire envelope and blocked outlet relief scenarios.",
        "Verify that emergency safety shutoff valves (SDVs) operate independently of standard automated regulatory process control valves (PCVs).",
        "Design relief valve flare discharge headers with adequate backpressure ratings to prevent choking during multi-unit relief events.",
        "Establish Safety Integrity Levels (SIL 1, 2, or 3) using risk graph matrices for critical emergency shutdown interlocks."
      ],
      [
        "Construct Composite Curves and Grand Composite Curves to identify the process Pinch point and minimum external hot and cold utility requirements.",
        "Never transfer heat across the Pinch point; cross-pinch heat transfer causes double energy penalties on both hot and cold utilities.",
        "Design heat exchanger network (HEN) loops that maximize heat recovery while maintaining realistic minimum approach temperatures (delta T_min: 10\u00b0C).",
        "Incorporate automated steam and cooling water valve trim optimization to match real-time diurnal ambient cooling tower variations.",
        "Author comprehensive chemical process engineering design packages including stream tables, PFDs, P&IDs, and energy savings reports."
      ]
    ],
    "phasePitfalls": [
      [
        "Ignoring recycle stream convergence tolerances in Aspen Plus, which leads to mathematical convergence on physically impossible flow rates.",
        "Selecting an ideal gas or ideal liquid property method for strongly non-ideal polar or azeotropic mixtures, yielding completely erroneous separations.",
        "Failing to verify whether operating pressures exceed component critical pressures, causing vapor-liquid equilibrium flash calculations to fail.",
        "Using default un-regressed binary interaction parameters (BIPs) for custom chemical components in thermodynamic databases.",
        "Publishing process flow diagrams (PFDs) without showing major utility supply and return lines (cooling water, high-pressure steam)."
      ],
      [
        "Operating distillation columns near weeping limits at low boil-up rates, causing liquid to dump through tray perforations without contacting vapor.",
        "Designing distillation columns without checking downcomer liquid backup limits, triggering downcomer flooding and massive liquid carryover.",
        "Failing to provide adequate reboiler liquid return disengagement volume, causing liquid droplets to enter reboiler vapor return lines.",
        "Locating feed trays arbitrarily without calculating optimum feed stage location using the Fenske-Underwood-Gilliland shortcut method.",
        "Neglecting column tray thermal expansion allowances, resulting in buckled tray decks and weeping during high-temperature operation."
      ],
      [
        "Treating standard process control loops as safety instrumented systems; safety shutoff valves must be completely independent of control valves.",
        "Failing to account for thermal relief valve requirements on blocked liquid lines exposed to solar radiation or steam tracing.",
        "Conducting HAZOP reviews without cross-functional participation from operations, maintenance, instrumentation, and process safety engineers.",
        "Directing toxic or flammable relief valve discharge vents to atmosphere at ground level instead of safe scrubbed flare headers.",
        "Allowing manual bypasses around critical emergency shutdown trips without strict administrative lock-out tag-out (LOTO) procedures."
      ],
      [
        "Violating the golden rule of Pinch Technology by transferring heat from above the Pinch to below the Pinch, increasing plant operating fuel consumption.",
        "Designing overly complex heat exchanger networks with excessive stream splitting, creating severe operability and plant startup headaches.",
        "Selecting overly tight temperature approach margins (delta T_min < 5\u00b0C) that require astronomically large heat exchanger surface areas.",
        "Neglecting heat exchanger fouling factors in network synthesis, resulting in heat deficit after a few months of continuous operation.",
        "Presenting process designs without calculating capital expenditure (CapEx) payback periods and operational greenhouse gas emission reductions."
      ]
    ]
  },
  "Aeronautical": {
    "specialistRole": "Senior Aerospace Engineer",
    "techStack": {
      "tools": [
        "ANSYS Fluent (CFD)",
        "SolidWorks Aerospace CAD",
        "XFLR5 Airfoil Analysis",
        "MATLAB Flight Dynamics Toolbox",
        "OpenVSP"
      ],
      "standards": [
        "NACA 4/5-Digit Airfoil Polars",
        "FAR Part 25 Airworthiness Criteria",
        "ARINC 429 Avionics Bus Standard",
        "Brayton Thermodynamic Cycle"
      ]
    },
    "tierSuffixes": [
      "Airfoil Aerodynamics & Wind Tunnel Simulation Blueprint",
      "Subsonic Flight Dynamics & Control Law Platform",
      "Gas Turbine Engine Propulsion & Thermodynamic Cycle System",
      "Autonomous UAV Flight Control & Aerodynamic Optimization Suite"
    ],
    "architecturePatterns": [
      "Navier-Stokes Computational Fluid Dynamics with SST k-omega Turbulence Modeling",
      "Linearized 6-DOF Aircraft Equations of Motion with State-Space Modal Eigenvalue Analysis",
      "Multi-Spool Gas Turbine Brayton Thermodynamic Cycle Engine with Component Matching",
      "Model Predictive Flight Control with Non-Linear Aerodynamic Parameter Estimation"
    ],
    "phaseProTips": [
      [
        "Ensure non-dimensional wall distance y+ < 1 near airfoil boundary surfaces when using wall-resolved turbulence models (k-omega SST) for accurate skin friction drag predictions.",
        "Generate structured O-grid or C-grid meshes around the airfoil leading edge to capture sharp suction peaks without numerical diffusion.",
        "Compare computed lift (Cl), drag (Cd), and pitching moment (Cm) curves against validated NASA Langley / Abbott & von Doenhoff experimental wind tunnel data.",
        "Refine boundary layer prism layers with a growth ratio under 1.2 to accurately capture boundary layer transition and separation bubbles.",
        "Document aerodynamic drag polar curves (Cl vs Cd) and identify the maximum lift-to-drag ratio (L/D_max) angle of attack."
      ],
      [
        "Extract dynamic longitudinal stability derivatives (phugoid and short-period damping) using linearized state-space matrices in MATLAB.",
        "Verify that the aircraft center of gravity (CG) remains forward of the neutral point to ensure positive static longitudinal stability margin (Kn > 5%).",
        "Model lateral-directional Dutch roll, spiral mode, and roll subsidence dynamics, ensuring damping ratios comply with military specification MIL-F-8785C.",
        "Design stability augmentation systems (SAS) using pitch-rate and yaw-damper feedback loops to eliminate adverse Dutch roll oscillations.",
        "Simulate control surface deflections (ailerons, elevator, rudder) to verify adequate roll rate and trim authority across the flight envelope."
      ],
      [
        "Calculate multi-spool Brayton thermodynamic cycle parameters: compressor pressure ratios, turbine inlet temperatures (TIT), and bypass ratios.",
        "Perform turbine blade cooling calculations using film cooling and internal serpentine convective passages to survive gas temperatures exceeding metallurgical melting limits.",
        "Match compressor and turbine mass flow characteristics across the operating line, maintaining adequate compressor surge margin (> 15%).",
        "Calculate net thrust, specific fuel consumption (SFC), and propulsive efficiency across sea-level static and high-altitude cruise conditions.",
        "Design converging-diverging exhaust nozzles for supersonic expansion, verifying no shock-induced flow separation inside the nozzle bell."
      ],
      [
        "Implement non-linear model predictive control (NMPC) algorithms running in real time to handle aggressive high-angle-of-attack maneuvers.",
        "Simulate autonomous flight profiles in hardware-in-the-loop (HIL) environments using PX4 autopilot or MATLAB Simulink Aerospace Blockset.",
        "Incorporate automated sensor fusion (EKF) combining Pitot-static air data, GPS, and MEMS IMU sensors with fault detection and isolation.",
        "Conduct aerodynamic wing-body topology optimization to minimize induced drag by optimizing spanwise lift distribution toward an elliptical ideal.",
        "Author comprehensive aerospace engineering technical papers featuring CFD flow field contours, stability root locus plots, and flight telemetry."
      ]
    ],
    "phasePitfalls": [
      [
        "Using first-order upwind spatial discretization schemes, which introduces severe numerical diffusion that masks true flow separation and vortex shedding.",
        "Placing farfield domain boundaries too close to the airfoil (less than 20 chord lengths), causing artificial pressure reflections that distort lift values.",
        "Relying on standard k-epsilon turbulence models for aerodynamics; k-epsilon severely underpredicts adverse pressure gradient separation.",
        "Ignoring Mach tuck and compressibility effects as airspeeds approach transonic regimes (M > 0.7).",
        "Failing to conduct a formal grid convergence index (GCI) study to prove mesh-independent CFD results."
      ],
      [
        "Locating the aircraft center of gravity aft of the neutral point, producing an unstable pitch-up divergence that causes uncontrolled stalls.",
        "Failing to account for aeroelastic wing twist and control surface reversal at high dynamic pressures.",
        "Designing vertical tail surfaces with insufficient volume coefficient, causing lateral directional instability and unrecoverable spin entry.",
        "Neglecting gyroscopic precession forces from rotating engine spools during rapid pitch and yaw combat maneuvers.",
        "Simulating flight dynamics using simplified 2D linearized equations without verifying cross-coupling effects between roll and yaw."
      ],
      [
        "Overlooking thermal creep deformation on turbine blades operating near metallurgical melting points during continuous takeoff thrust.",
        "Allowing compressor operating lines to cross into the surge line during rapid throttle slam accelerations, causing catastrophic engine flameout.",
        "Neglecting rotor dynamic critical speeds and shaft whirl frequencies, risking severe unbalance vibrations and bearing destruction.",
        "Designing combustor liners without adequate dilution air holes, creating turbine inlet temperature hot spots that burn through nozzle guide vanes.",
        "Failing to incorporate bird strike and foreign object damage (FOD) structural containment rings around high-speed fan casings."
      ],
      [
        "Testing autonomous flight control algorithms on flight hardware without an independent physical manual override kill-switch.",
        "Failing to model wind gusts and atmospheric microburst disturbances in autonomous flight simulation testbenches.",
        "Allowing sensor latency and computational jitter in the flight control computer to degrade control loop phase margin below 45 degrees.",
        "Neglecting battery voltage sag under peak motor throttle loads on electric UAVs, triggering premature low-voltage battery fail-safes.",
        "Presenting aerospace flight control algorithms without flight test telemetry data proving stability under real-world turbulence."
      ]
    ]
  },
  "Aviation": {
    "specialistRole": "Chief Flight Instructor",
    "techStack": {
      "tools": [
        "Jeppesen Airway Manual & Approach Plates",
        "Airbus A320 / Boeing 737 FMS MCDU",
        "Aviation Weather METAR / TAF Decoders",
        "Garmin G1000 Integrated Flight Deck",
        "Load & Trim Sheet Calculator"
      ],
      "regulations": [
        "ICAO Annex 2 / 6 / 14",
        "DGCA Civil Aviation Requirements (CAR)",
        "FAA Instrument Flying Handbook",
        "Crew Resource Management (CRM / TEM)"
      ]
    },
    "tierSuffixes": [
      "Instrument Flight Rules (IFR) & Navigation Procedure Blueprint",
      "Flight Management System (FMS) Flight Planning Platform",
      "Severe Weather Hazard Assessment & Meteorology Telemetry Suite",
      "Airline Threat & Error Management (CRM) Decision Simulator"
    ],
    "architecturePatterns": [
      "Precision IFR Instrument Procedure Navigation Model with Standard Instrument Departures (SID) & STARs",
      "Performance-Based Navigation (PBN) Flight Planning Engine with Cost Index Optimization",
      "Multi-Source Aviation Weather Decoding & Convective Sigmet Hazard Prediction Engine",
      "Non-Technical Skills (NOTECHS) & Crew Resource Management (CRM) Decision Protocol"
    ],
    "phaseProTips": [
      [
        "Cross-check FMS navigation waypoint coordinates, magnetic bearings, and crossing altitudes against published Jeppesen approach plates during pre-departure briefing.",
        "Calculate Required Navigation Performance (RNP) and ensure autonomous GPS Receiver Autonomous Integrity Monitoring (RAIM) availability before flight.",
        "Brief missed approach procedures, holding fixes, and fuel reserves before commencing any precision Instrument Landing System (ILS) approach.",
        "Adhere strictly to stabilized approach criteria (speed within +10/-0 kt, on glidepath, engines spooled, fully configured) by 1,000 feet IMC / 500 feet VMC.",
        "Calculate one-engine-inoperative (OEI) drift-down altitudes and escape routes for high-terrain mountainous departure profiles."
      ],
      [
        "Compute Zero Fuel Weight (ZFW), Takeoff Weight (TOW), and Center of Gravity (CG) envelopes meticulously to prevent aerodynamic pitch trim instability.",
        "Calculate Cost Index (CI) trade-offs balancing fuel burn rate against hourly flight crew and aircraft maintenance costs.",
        "Determine V1 (decision speed), VR (rotation speed), and V2 (takeoff safety speed) adjusted for runway slope, contamination, and ambient air density.",
        "Incorporate mandatory fuel reserves (taxi, trip, contingency 5%, alternate, and 30-minute final reserve) on every flight dispatch release.",
        "Program secondary flight plans in the FMS for immediate diversion routing in the event of engine failure or cabin depressurization."
      ],
      [
        "Decode raw METAR, TAF, and SIGMET bulletins for freezing levels, microburst indicators, wind shear, and severe turbulence before dispatch.",
        "Use onboard airborne weather radar antenna tilt controls actively during climb and cruise to distinguish storm tops from ground clutter.",
        "Maintain a minimum lateral clearance of 20 nautical miles from severe convective thunderstorm cells (cumulonimbus) showing radar red returns.",
        "Recognize clear air turbulence (CAT) potential when flying in the vicinity of high-velocity jet streams and sharp horizontal temperature gradients.",
        "Brief aircraft de-icing and anti-icing fluid holdover times (HOT) meticulously during sub-zero precipitation prior to runway takeoff."
      ],
      [
        "Enforce strict Sterile Cockpit rules below 10,000 feet, eliminating non-essential conversations during critical taxi, takeoff, and landing phases.",
        "Practice assertiveness and situational awareness using the PACE framework (Probe, Alert, Challenge, Emergency intervention).",
        "Structure emergency decision-making using the DODAR framework (Diagnose, Options, Decide, Act/Assign, Review).",
        "Conduct structured Threat and Error Management (TEM) briefings before descent to anticipate terrain, fatigue, and complex ATC clearances.",
        "Author comprehensive airline flight operations case studies detailing fuel efficiency gains, safety audit compliance, and stabilized approach rates."
      ]
    ],
    "phasePitfalls": [
      [
        "Descending below Minimum Descent Altitude (MDA) or Decision Altitude (DA) without required visual runway references distinctly in sight.",
        "Continuing an un-stabilized approach below 1,000 feet IMC instead of immediately initiating a mandatory go-around.",
        "Entering incorrect performance initialization weights into the FMS MCDU, leading to erroneous V1, VR, and V2 speed calculations.",
        "Failing to monitor primary flight instruments during automated autoflight operations, leading to automation complacency and mode confusion.",
        "Neglecting altimeter subscale barometric setting changes (QNH vs QNE / Standard 1013.25 hPa) when climbing through transition altitude."
      ],
      [
        "Operating aircraft with Center of Gravity located outside certified forward or aft limits, resulting in severe pitch control loss.",
        "Over-relying on automated flight planning systems without verifying whether alternate aerodromes meet legal weather minima for the ETA.",
        "Applying assumed temperature (flexible thrust) takeoff reductions on contaminated or slippery runways, which is prohibited by regulation.",
        "Neglecting runway surface condition NOTAMs and runway condition assessment matrix (RCAM) codes when calculating landing roll distances.",
        "Taking off with less than regulatory minimum diversion and final reserve fuel on board."
      ],
      [
        "Attempting to penetration-fly through convective thunderstorm cells (cumulonimbus) rather than executing proactive 20-mile lateral deviations.",
        "Taking off with structural ice, snow, or frost adhering to critical wing surfaces, violating the mandatory Clean Aircraft Concept.",
        "Failing to recognize low-level wind shear alerts on takeoff or landing approach, risking uncontrollable loss of airspeed and terrain impact.",
        "Exceeding anti-icing fluid holdover times and attempting takeoff without conducting a physical pre-takeoff contamination check.",
        "Operating radar with improper gain or antenna tilt settings, masking severe severe weather returns."
      ],
      [
        "Succumbing to Plan Continuation Bias (get-there-itis) during deteriorating weather conditions instead of diverting to designated alternates.",
        "Allowing a steep authority gradient in the cockpit to prevent the First Officer from challenging an erratic Captain decision.",
        "Engaging in non-essential casual chatter during critical taxi operations, leading to runway incursions or missed ATC hold-short instructions.",
        "Failing to conduct a formal review after taking emergency action, resulting in compounding secondary errors.",
        "Presenting flight procedures without demonstrating adherence to standard operating procedures (SOPs) and ICAO Annex standards."
      ]
    ]
  },
  "Cabin Crew": {
    "specialistRole": "In-Flight Safety Director",
    "techStack": {
      "tools": [
        "Halon 1211 Fire Extinguisher",
        "Protective Breathing Equipment (PBE)",
        "Automated External Defibrillator (AED)",
        "Emergency Evacuation Slide Drill Mockup",
        "Megaphone & Passenger Restraint Kits"
      ],
      "safetyProtocols": [
        "90-Second Cabin Evacuation Standard",
        "Pre-Flight Emergency Equipment Inspection",
        "DODAR Decision Framework",
        "Dangerous Goods Regulations (IATA DGR)"
      ]
    },
    "tierSuffixes": [
      "Cabin Safety & Emergency Evacuation Protocol Blueprint",
      "In-Flight Medical Triage & First Aid Response System",
      "Aviation Fire Fighting & Smoke Mitigation Platform",
      "Crew Resource Management & Passenger De-escalation Suite"
    ],
    "architecturePatterns": [
      "Standardized 90-Second Emergency Evacuation & Slide Deployment Protocol",
      "In-Flight Aviation Medical Response Framework with Telemedical Ground Support",
      "Aviation Fire Containment Protocol with Continuous Smoke Hood Operational Cycles",
      "Non-Violent Conflict De-Escalation & Level 1-4 Unruly Passenger Restraint Protocol"
    ],
    "phaseProTips": [
      [
        "Command 90-second cabin evacuations using authoritative, rhythmic commands (\"UNFASTEN SEATBELTS, LEAVE EVERYTHING BEHIND, COME THIS WAY\").",
        "Inspect emergency equipment (PBE seals, oxygen cylinder pressures, Halon pressure gauges, flashlight batteries) prior to every passenger boarding.",
        "Assess outside conditions through the door viewing window before opening any exit: never open an exit if fire, water, or debris is visible.",
        "Brief Able-Bodied Passengers (ABPs) seated at emergency exit rows on door operation, slide redirection, and holding back crowds.",
        "Maintain situational awareness during silent 30-second reviews on takeoff and landing: review brace positions, exit locations, and commands."
      ],
      [
        "Assess unresponsive passengers immediately using the CAB (Circulation, Airway, Breathing) algorithm and call for the AED and medical kit.",
        "Administer high-flow supplemental oxygen for suspected hypoxia, heart conditions, or severe shock while coordinating ground medical links.",
        "Recognize in-flight medical emergencies: stroke (FAST protocol), myocardial infarction, severe allergic anaphylaxis (Epipen administration).",
        "Use universal precautions (nitrile gloves, biohazard masks, eye protection) when handling bodily fluid contamination to prevent pathogen exposure.",
        "Deliver clear, structured medical status reports to the flight deck using the SBAR (Situation, Background, Assessment, Recommendation) format."
      ],
      [
        "Don Protective Breathing Equipment (PBE) within 15 seconds before approaching any suspected cabin, galley, or hidden lavatory fire.",
        "Aim Halon 1211 fire extinguishers at the base of the flames, discharging with a sweeping motion from a distance of 1.5 to 2 meters.",
        "Designate dedicated crew roles during a fire: Fire Fighter (attacks fire), Communicator (informs flight deck), Back-up (brings Halon and water).",
        "Never use water extinguishers on electrical or lithium-ion battery fires; use Halon to extinguish flames, then cool battery with non-alcoholic liquids.",
        "Feel closed lavatory doors with the back of the hand for heat before cracking the door open to discharge fire extinguishers."
      ],
      [
        "Apply verbal de-escalation frameworks (listen actively, validate frustrations without conceding safety regulations) for non-compliant passengers.",
        "Recognize unruly passenger threat levels: Level 1 (disruptive), Level 2 (physically abusive), Level 3 (life-threatening), Level 4 (flight deck breach).",
        "Coordinate with the Captain before applying physical flex-cuff restraints, documenting passenger statements and eyewitness testimonies.",
        "Ensure cultural sensitivity and professional hospitality etiquette in high-stress customer interactions across diverse international routes.",
        "Author comprehensive in-flight incident reports detailing timeline of events, safety protocol adherence, and regulatory compliance."
      ]
    ],
    "phasePitfalls": [
      [
        "Opening an emergency exit door when visible fire, thick smoke, or water immersion is observed outside the viewing window.",
        "Allowing passengers to evacuate with heavy carry-on luggage, which punctures inflatable evacuation slides and severely impedes exit flow.",
        "Hesitating during an evacuation; hesitation by crew members causes passenger bottlenecks and panic inside the cabin aisle.",
        "Failing to verify whether the door is in the ARMED or DISARMED mode before opening during normal passenger disembarkation.",
        "Skipping pre-flight emergency equipment checks during quick turnaround flights, risking missing or uncharged safety gear."
      ],
      [
        "Hesitating to attach and discharge an Automated External Defibrillator (AED) when advised by the machine during sudden cardiac arrest.",
        "Administering solid foods, fluids, or oral medications to a passenger with altered levels of consciousness or active seizures.",
        "Failing to alert the flight deck immediately when a medical emergency requires consideration of an unscheduled en-route diversion.",
        "Disposing of biohazardous materials in standard cabin trash receptacles without using designated biohazard containment kits.",
        "Attempting invasive medical procedures without authorization from a licensed on-board physician or ground telemedical doctor."
      ],
      [
        "Opening a closed lavatory door rapidly during a suspected fire, creating a backdraft flashover of superheated oxygen.",
        "Pouring ice over a thermal runaway lithium-ion laptop battery, which creates an insulating thermal blanket that traps heat.",
        "Approaching dense cabin smoke without donning a Protective Breathing Equipment (PBE) smoke hood, risking incapacitation within seconds.",
        "Failing to keep the flight deck continuously updated on fire location, smoke color, odor, and suppression effectiveness.",
        "Neglecting to perform a secondary search for hidden smoldering embers behind cabin sidewall panels after extinguishing an open flame."
      ],
      [
        "Responding to an angry passenger with confrontational or sarcastic language, which escalates minor non-compliance into physical violence.",
        "Applying physical restraints to a passenger without Captain authorization, exposing the airline and crew to unlawful restraint liabilities.",
        "Failing to confiscate and secure personal alcohol consumed by passengers in violation of aviation liquor regulations.",
        "Ignoring subtle early indicators of passenger intoxication before boarding, allowing disruptive passengers to board the aircraft.",
        "Submitting vague or emotional incident reports without precise factual timelines, witness names, and specific safety rule violations."
      ]
    ]
  },
  "Robotics": {
    "specialistRole": "Senior Robotics Engineer",
    "techStack": {
      "tools": [
        "ROS 2 (Humble / Iron)",
        "Nav2 Navigation Stack",
        "Gazebo Robot Simulator",
        "OpenCV & YOLOv8 Computer Vision",
        "Siemens TIA Portal (PLC)"
      ],
      "hardware": [
        "3D LiDAR Sensor",
        "BLDC Motors & PWM Drivers",
        "Inertial Measurement Unit (IMU)",
        "STM32 Microcontroller",
        "Robotic Gripper"
      ]
    },
    "tierSuffixes": [
      "ROS 2 Micro-Architecture & Kinematic Controller Blueprint",
      "Autonomous Mobile Robot (AMR) SLAM & Navigation Platform",
      "Industrial Robotic Arm Vision Grasping & Trajectory System",
      "Autonomous Multi-Robot Swarm Fleet & Task Allocation Sentinel"
    ],
    "architecturePatterns": [
      "Component-Based ROS 2 Node Architecture with Zero-Copy Intra-Process Communication",
      "Probabilistic Grid-Based 2D/3D SLAM with Costmap Trajectory Rollout Optimization",
      "Inverse Kinematics (IK) with MoveIt Motion Planning & Visual Grasp Pose Detection",
      "Distributed Multi-Agent Consensus Architecture with Real-Time Fleet Dispatch"
    ],
    "phaseProTips": [
      [
        "Use ROS 2 Composition (component nodes) to run nodes in a single process, enabling zero-copy intra-process message delivery.",
        "Structure URDF and Xacro kinematic descriptions with clean link-joint coordinate transforms referencing a standard base_link.",
        "Implement closed-loop PID velocity control with derivative low-pass filtering to eliminate high-frequency encoder noise.",
        "Define custom ROS 2 message and action types for long-running robot tasks that provide periodic feedback during execution.",
        "Benchmark ROS 2 DDS middleware performance (CycloneDDS vs FastDDS) and tune QoS reliability and durability profiles."
      ],
      [
        "Tune Nav2 costmap inflation radius and footprint padding to account for dynamic robot momentum and physical deceleration stopping distances.",
        "Fuse wheel odometry with 9-axis IMU angular rates using robot_localization Extended Kalman Filtering (EKF) to eliminate positional drift.",
        "Optimize 2D/3D LiDAR point cloud filtering (voxel grid downsampling) to maintain 20Hz scan matching without overloading CPU cores.",
        "Configure AMCL (Adaptive Monte Carlo Localization) recovery behaviors to allow the robot to self-recover when localized confidence drops.",
        "Implement dynamic obstacle avoidance using the DWB (Dynamic Window Approach) local planner with safety stop zones."
      ],
      [
        "Calibrate eye-in-hand RGB-D camera transformation matrices using chessboard or ChArUco fiducial targets to minimize grasp errors.",
        "Deploy YOLOv8 or segmented mask detection models for real-time 6-DOF object pose estimation on resource-constrained embedded GPUs.",
        "Configure MoveIt 2 motion planning pipelines with OMPL RRT-Connect algorithms to compute collision-free joint trajectories.",
        "Incorporate torque feedback sensing during gripper closing to verify stable grasp engagement before raising the robotic arm.",
        "Design mechanical end-effectors with compliance or suction cups to tolerate slight real-world visual position inaccuracies."
      ],
      [
        "Implement distributed fleet management using WebSockets or MQTT to coordinate multi-robot path reservation and avoid corridor deadlocks.",
        "Train reinforcement learning or behavior tree agents for autonomous task dispatch, battery recharging, and material handoffs.",
        "Build real-time 3D digital twin visualization dashboards in Three.js or Foxglove Studio displaying live robot fleet telemetry.",
        "Incorporate automated hardware watchdog safety circuits that instantly cut actuator motor power upon communication loss.",
        "Author comprehensive robotics engineering portfolios featuring Gazebo simulation videos, real-world navigation traces, and code repos."
      ]
    ],
    "phasePitfalls": [
      [
        "Publishing uncompressed high-resolution camera feeds at 60Hz over standard Wi-Fi DDS topics, choking the local wireless network stack.",
        "Failing to verify whether robot actuator kinematic limits exceed motor driver thermal thresholds under continuous duty cycles.",
        "Hardcoding absolute frame names in ROS 2 node transformations instead of reading tf2 tree transforms dynamically.",
        "Omitting hardware-level emergency stop (E-stop) interlocks, relying instead on software-level ROS topic shutdowns.",
        "Allocating dynamic memory inside high-frequency 1kHz real-time motor control loops, introducing unbounded latency spikes."
      ],
      [
        "Relying on wheel odometry alone without sensor fusion (IMU + EKF), resulting in severe cumulative drift on slippery terrain.",
        "Setting costmap inflation radius too small, allowing the robot chassis corners to clip doorframes during sharp turning maneuvers.",
        "Failing to provide clear feature-rich environmental landmarks in large open warehouse environments, causing LiDAR scan matching to fail.",
        "Permitting the robot to plan paths through glass partitions or black objects invisible to standard infrared LiDAR sensors.",
        "Neglecting automated recovery behaviors, leaving the mobile robot permanently stranded when minor obstacle blockages occur."
      ],
      [
        "Planning robot arm trajectories without checking kinematic singularities (e.g. wrist alignment), triggering infinite joint velocity demands.",
        "Failing to account for lens distortion when calculating 3D camera coordinates from 2D pixel detections.",
        "Attempting to grasp fragile objects without closed-loop force sensing, resulting in crushed workpieces or burnt gripper servo motors.",
        "Allowing robotic arms to execute planned trajectories without continuous real-time collision checking against dynamic obstacles.",
        "Failing to verify joint physical endstop limits, causing robotic arms to twist internal cables and snap wiring harnesses."
      ],
      [
        "Operating multi-robot fleets without spatial reservation locks, causing two robots to enter narrow single-lane corridors and deadlock.",
        "Neglecting battery state-of-charge decay curves, leaving robots dead in the middle of active production facility travel aisles.",
        "Allowing fleet dispatch servers to control robots without end-to-end TLS encryption and cryptographic node authentication.",
        "Failing to test robotic fleet behaviors under severe network latency and simulated packet loss conditions.",
        "Presenting robotics projects based solely on basic ROS tutorials without demonstrating physical hardware integration or custom algorithms."
      ]
    ]
  },
  "Biotechnology": {
    "specialistRole": "Senior Bioprocess Scientist",
    "techStack": {
      "tools": [
        "Benchling CRISPR Guide Designer",
        "BioPython Sequence Alignment",
        "Bioflo Bioreactor DO/pH Controller",
        "AKTA FPLC Protein Purification",
        "Agilent HPLC System"
      ],
      "standards": [
        "NCBI BLAST & GenBank",
        "FDA 21 CFR Part 11 Regulatory Compliance",
        "ISO 14644 Cleanroom Classification",
        "SDS-PAGE Gel Electrophoresis"
      ]
    },
    "tierSuffixes": [
      "Recombinant Plasmid & CRISPR-Cas9 Protocol Blueprint",
      "Bioreactor Fermentation & Scale-Up Analytics Platform",
      "Downstream Protein Purification & Chromatography Suite",
      "Bioinformatics Genomic Pipeline & Variant Analysis Sentinel"
    ],
    "architecturePatterns": [
      "In-Silico Plasmid Vector Design with Dual Guide RNA Target Validation",
      "Automated Closed-Loop Fed-Batch Fermentation Control (pH, DO, Agitation, Nutrient Feed)",
      "Multi-Step Chromatographic Purification (Affinity -> Ion Exchange -> Size Exclusion)",
      "High-Throughput Next-Generation Sequencing (NGS) Quality Control & Variant Calling Pipeline"
    ],
    "phaseProTips": [
      [
        "Design guide RNAs with non-overlapping PAM sites and score off-target cleavage probability using Cas-OFFinder before synthesis.",
        "Verify recombinant plasmid insert sequences via Sanger sequencing chromatograms, confirming reading frame alignment and promoter integrity.",
        "Select appropriate selectable antibiotic resistance markers and origin of replication (high vs low copy number) for host expression hosts.",
        "Optimize codon usage bias for target expression hosts (E. coli, CHO cells) to prevent ribosomal pausing and truncated protein products.",
        "Document recombinant DNA constructs in standardized SBOL (Synthetic Biology Open Language) format with full annotated GenBank files."
      ],
      [
        "Maintain dissolved oxygen (DO) saturation above 20% in bioreactors by cascading agitation speed, airflow, and pure oxygen enrichment.",
        "Monitor offline optical density (OD600) and glucose consumption kinetics to initiate nutrient feeding during mid-exponential growth.",
        "Control bioreactor pH within \u00b10.05 units using automated micro-dosing of sterile acid and base solutions to prevent cellular stress.",
        "Calculate specific growth rate (mu) and biomass yield on substrate (Y_x/s) across batch, fed-batch, and continuous culture regimes.",
        "Maintain strict cleanroom ISO class 7/8 standards and sterile SIP/CIP cycles to guarantee zero microbial contamination."
      ],
      [
        "Optimize FPLC elution gradients using step-wise pH or salt concentration increments to separate closely related protein isoforms.",
        "Use immobilized metal affinity chromatography (IMAC) with imidazole gradients, followed by size-exclusion chromatography (SEC) for polishing.",
        "Analyze purified protein fractions using SDS-PAGE and Western Blot to confirm molecular weight, purity (> 95%), and structural integrity.",
        "Quantify total protein concentration using spectrophotometric absorbance at 280 nm (A280) calibrated against theoretical extinction coefficients.",
        "Verify biological activity and binding affinity (Kd) of purified therapeutic proteins using Surface Plasmon Resonance (SPR) or ELISA."
      ],
      [
        "Filter raw Next-Generation Sequencing (NGS) FASTQ reads for Phred quality scores (Q > 30) before genome alignment.",
        "Index reference genomes with BWA or Bowtie2 to ensure rapid, memory-efficient alignment of millions of short genomic reads.",
        "Identify single nucleotide polymorphisms (SNPs) and insertions/deletions using GATK best practice variant calling pipelines.",
        "Integrate automated FDA 21 CFR Part 11 audit trails logging user modifications, electronic signatures, and data integrity checks.",
        "Author comprehensive bioprocess research reports detailing fermentation yield metrics, purification recovery rates, and genomic variant findings."
      ]
    ],
    "phasePitfalls": [
      [
        "Failing to verify plasmid vector insertion sequences via Sanger sequencing prior to large-scale mammalian cell transfection.",
        "Selecting guide RNA target sequences with high off-target sequence homology across the host genome, inducing unintended genomic mutations.",
        "Using high-copy plasmids for toxic recombinant protein expression, which causes plasmid instability and metabolic burden in host bacteria.",
        "Neglecting to verify restriction enzyme methylation sensitivity before setting up molecular cloning digestions.",
        "Handling RNA samples without certified RNase-free reagents and dedicated barrier pipettes, resulting in rapid sample degradation."
      ],
      [
        "Allowing foaming in high-density bioreactor cultures without automated antifoam injection, suffocating cells and fouling exhaust filters.",
        "Exceeding maximum impeller tip speeds in mammalian cell bioreactors, causing fatal shear-induced cell lysis.",
        "Over-feeding glucose during fed-batch fermentation, triggering the Crabtree effect in yeast or overflow acetate toxicity in E. coli.",
        "Calibrating pH and dissolved oxygen probes after autoclave sterilization without verifying temperature compensation.",
        "Failing to maintain positive pressure across sterile vessel seals, allowing environmental spore contamination during long runs."
      ],
      [
        "Overloading chromatography columns beyond manufacturer dynamic binding capacities, resulting in severe target protein breakthrough loss.",
        "Dialyzing or concentrating proteins too rapidly without compatible buffer salts, triggering catastrophic protein precipitation and aggregation.",
        "Failing to clean and sanitize FPLC resin columns with 0.1M NaOH between runs, resulting in cross-contamination and column bed fouling.",
        "Storing purified enzymes and antibodies at ambient temperatures without protease inhibitors or cryoprotectants (glycerol).",
        "Interpreting single-band purity on crude Coomassie-stained gels without verifying secondary bands via high-sensitivity silver staining."
      ],
      [
        "Running sequence alignment algorithms against unindexed reference genomes, resulting in days of unnecessary compute latency.",
        "Interpreting low-coverage sequencing reads as genuine genomic mutations without filtering for PCR duplication artifacts.",
        "Modifying clinical bioprocess data records without tamper-evident audit trails, violating cGMP and regulatory compliance laws.",
        "Neglecting negative control runs during bio-informatics pipeline validation, leading to high false-positive variant calls.",
        "Presenting biotechnology projects without quantifiable biological assay results proving functional activity and purity."
      ]
    ]
  },
  "Marine": {
    "specialistRole": "Chief Marine Engineer",
    "techStack": {
      "tools": [
        "Maxsurf Naval Architecture CAD",
        "2-Stroke Marine Diesel Engine Simulator",
        "Exhaust Gas Economizer Boiler Controller",
        "Centrifugal Fuel Oil Purifier",
        "Oily Water Separator (15 ppm Alarm)"
      ],
      "regulations": [
        "IMO MARPOL Annex I-VI Regulations",
        "SOLAS Chapter II-1 / II-2 Safety Protocols",
        "STCW Code Engine Room Watchkeeping",
        "Ship Stability & Hydrostatic Curves"
      ]
    },
    "tierSuffixes": [
      "Marine Propulsion & 2-Stroke Diesel Diagnostic Blueprint",
      "Ship Hydrostatics, Metacentric Height & Stability Platform",
      "Auxiliary Marine Machinery & Waste Heat Recovery System",
      "Autonomous Vessel Engine Room Telemetry & MARPOL Sentinel"
    ],
    "architecturePatterns": [
      "Slow-Speed Crosshead Diesel Engine Thermodynamic Model with Closed-Loop Combustion Balancing",
      "Ship Hydrostatic Hull Surface Modeling with Intact & Damage Stability Cross-Curves",
      "Multi-Stage Waste Heat Recovery Rankine Cycle with Marine Auxiliary Steam Integration",
      "Real-Time Shipboard Telemetry Monitoring with Automated MARPOL Annex Emissions Compliance"
    ],
    "phaseProTips": [
      [
        "Analyze diesel engine indicator cards (P-theta diagrams) to balance peak cylinder firing pressures within \u00b12.5 bar across all units.",
        "Monitor exhaust gas temperature deviations across cylinders; a single elevated cylinder indicates fuel injector dribble or timing drift.",
        "Conduct crankcase deflections using a dial gauge indicator on every crankshaft web to detect bearing wear and hull misalignment.",
        "Perform scavenge space inspections to check cylinder liner lubrication condition and verify that piston rings move freely in their grooves.",
        "Sample system lubricating oil regularly, monitoring viscosity, total base number (TBN), water content, and insolubles."
      ],
      [
        "Calculate metacentric height (GM) with free surface corrections for partially filled fuel, freshwater, and ballast bunker tanks.",
        "Verify that ship intact stability curves (GZ curves) comply with IMO Code on Intact Stability (maximum GZ at theta > 30 degrees, positive range > 60 degrees).",
        "Simulate progressive flooding scenarios across compartments to verify vessel survivability under SOLAS damage stability criteria.",
        "Monitor hull hogging and sagging stresses during ballasting operations to keep longitudinal bending moments within permissible sea limits.",
        "Model hull hydrodynamics in Maxsurf to calculate vessel resistance curves and effective power (EHP) across varying draft conditions."
      ],
      [
        "Maintain fuel oil purification temperatures at 98\u00b0C to maximize density disparity between heavy fuel oil and water droplets.",
        "Operate auxiliary exhaust gas economizer boilers safely, conducting regular soot blowing to prevent catastrophic soot fires.",
        "Test oily water separator (OWS) 15-ppm bilge alarms and three-way divert valves prior to overboard discharge in designated sea areas.",
        "Monitor fresh water generator (FWG) vacuum levels (keep > 90% vacuum) to boil seawater at low temperatures (45\u00b0C) using jacket water heat.",
        "Maintain proper chemical treatment in auxiliary boiler feed water (alkalinity, phosphate, dissolved oxygen scavenger) to prevent scale buildup."
      ],
      [
        "Log continuous emissions monitoring data (NOx, SOx) adhering strictly to IMO MARPOL Annex VI statutory limits inside ECA zones.",
        "Integrate shipboard vibration telemetry across turbochargers and thrust bearings to predict bearing failure weeks before catastrophic seizure.",
        "Implement automated electrical power management systems (PMS) for auxiliary diesel generators with auto-synchronization and load sharing.",
        "Maintain secure tamper-proof Electronic Oil Record Books (Part I & II) adhering to international maritime port state control standards.",
        "Author comprehensive marine engineering case studies featuring engine indicator diagrams, stability curves, and fuel efficiency audits."
      ]
    ],
    "phasePitfalls": [
      [
        "Ignoring turbocharger surging during rapid engine acceleration, causing severe thermal and mechanical fatigue on turbine blading.",
        "Operating diesel engines with un-balanced cylinder peak pressures, causing severe torsional vibration and premature crankshaft fracture.",
        "Failing to test crankcase oil mist detectors (OMD), risking catastrophic crankcase explosions caused by overheated bearing hot spots.",
        "Bypassing cylinder oil lubricator flow alarms, leading to severe metal-to-metal scuffing and seizure of piston rings inside liners.",
        "Failing to drain scavenge air receiver drain valves, allowing accumulation of unburned cylinder oil that triggers dangerous scavenge fires."
      ],
      [
        "Ballasting tanks without calculating longitudinal bending moments, risking structural hull girder failure in heavy sea states.",
        "Underestimating free surface effects in wide, slack double-bottom tanks, resulting in a sudden drop in metacentric height (GM) and vessel capsize.",
        "Loading cargo without checking maximum permissible deck load limits (tonnes/m2), causing structural deformation of tanktop plating.",
        "Failing to secure watertight doors and deadlights in heavy weather, violating SOLAS subdivision integrity regulations.",
        "Attempting damage stability calculations using generic estimates rather than hydrostatic cross-curves matching actual ship draft."
      ],
      [
        "Operating oily water separators without testing the 15-ppm bilge alarm, risking international maritime port detention under MARPOL Annex I.",
        "Starting auxiliary boilers without adequate pre-purge cycles, risking catastrophic furnace gas explosions from unburned oil vapor.",
        "Allowing seawater leakage into auxiliary boiler feed water systems, triggering rapid localized boiler tube scaling and rupture.",
        "Operating fresh water generators with failing vacuum, which forces boiling temperatures above 60\u00b0C and causes rapid scale fouling of evaporator plates.",
        "Discharging untreated sewage or machinery space bilges inside designated MARPOL Special Areas, incurring massive international fines."
      ],
      [
        "Allowing vessel emissions telemetry to drop below regulatory compliance standards inside Emission Control Areas (ECAs).",
        "Failing to test emergency steering gear changeover from the bridge and engine control room prior to port departure.",
        "Operating automated machinery spaces (UMS) without verifying that critical alarm extension systems alert the duty engineer cabin.",
        "Neglecting regular calibration of bilge alarm sensors and gas detection equipment in hazardous machinery spaces.",
        "Presenting marine engineering portfolios without practical shipboard operational data and internationally recognized STCW standards."
      ]
    ]
  },
  "BA Hons": {
    "specialistRole": "Senior Policy Fellow",
    "techStack": {
      "tools": [
        "RStudio / SPSS Statistical Suite",
        "NVivo Qualitative Thematic Coding",
        "Policy Brief Formatting Templates",
        "GRI Standards Sustainability Matrix",
        "Tableau Public Civic Dashboards"
      ],
      "frameworks": [
        "Cost-Benefit Socioeconomic Analysis (CBA)",
        "Stakeholder Multi-Criteria Decision Analysis",
        "Schedule VII CSR Compliance Framework",
        "National Sample Survey (NSSO) Datasets"
      ]
    },
    "tierSuffixes": [
      "Public Policy Whitepaper & Regulatory Impact Assessment Blueprint",
      "Socioeconomic Survey & Quantitative Research Platform",
      "Corporate Social Responsibility (CSR) & ESG Governance Suite",
      "Macroeconomic Policy Forecasting & Civic Intelligence Sentinel"
    ],
    "architecturePatterns": [
      "Evidence-Based Policy Cycle Model (Agenda, Formulation, Adoption, Implementation, Evaluation)",
      "Multi-Stage Stratified Sampling Survey Framework with Thematic Coding",
      "ESG Stakeholder Materiality Matrix with Global Reporting Initiative (GRI) Standards",
      "Econometric Regression & Fiscal Multiplier Forecasting Model"
    ],
    "phaseProTips": [
      [
        "Conduct rigorous Cost-Benefit Analysis (CBA) and stakeholder mapping, evaluating fiscal multipliers and long-term distributional equity.",
        "Synthesize empirical literature systematically, distinguishing high-quality randomized controlled trials from correlational studies.",
        "Draft executive policy briefs with actionable recommendations presented within a strict 1-page executive summary format.",
        "Map regulatory ripple effects and unintended behavioral consequences before proposing statutory legislative changes.",
        "Present policy proposals with transparent budgetary impact estimates and phased implementation timelines."
      ],
      [
        "Calculate statistical power and required sample sizes before deploying civic field surveys to guarantee statistically valid inferences.",
        "Use multi-stage stratified random sampling to ensure accurate representation of marginalized demographic cohorts.",
        "Code qualitative interview transcripts using inter-coder reliability metrics (Cohen Kappa > 0.8) to establish thematic validity.",
        "Triangulate qualitative focus group insights with quantitative survey statistics to uncover underlying behavioral motivators.",
        "Document research methodologies following open-science principles with reproducible R / Python analysis scripts."
      ],
      [
        "Align corporate CSR expenditure with Schedule VII of the Companies Act 2013, establishing quantifiable Key Impact Indicators (KIIs).",
        "Conduct double materiality assessments evaluating both financial impact on the company and the company external impact on society and environment.",
        "Structure sustainability reporting adhering strictly to Global Reporting Initiative (GRI) and BRSR (Business Responsibility and Sustainability Reporting) guidelines.",
        "Perform independent third-party impact assessments verifying whether community development initiatives achieve sustained long-term outcomes.",
        "Publish an executive ESG scorecard highlighting quantifiable carbon offsets, diversity ratios, and community health improvements."
      ],
      [
        "Model macroeconomic fiscal policy shifts using vector autoregression (VAR) to estimate impacts on inflation and unemployment (Phillips Curve).",
        "Incorporate interactive data visualization dashboards allowing civic stakeholders to explore policy scenario trade-offs dynamically.",
        "Analyze public sentiment trends across digital news and civic feedback platforms using natural language processing (NLP).",
        "Establish policy evaluation benchmarks to assess whether implemented social welfare schemes achieve target delivery efficiency.",
        "Author comprehensive socioeconomic research publications featuring econometric regression tables, policy recommendations, and visual charts."
      ]
    ],
    "phasePitfalls": [
      [
        "Authoring academic policy documents dense with theoretical jargon that fail to address concrete budgetary and implementation constraints.",
        "Ignoring political economy constraints and administrative capacity when designing complex public welfare programs.",
        "Failing to analyze how proposed regulatory policies disproportionately affect lower-income and vulnerable socioeconomic groups.",
        "Recommending policy interventions based on pilot studies without accounting for general equilibrium effects at nationwide scale.",
        "Presenting policy whitepapers without consulting frontline administrative stakeholders who execute the policy."
      ],
      [
        "Extrapolating policy interventions from pilot samples without controlling for selection bias and socioeconomic confounding variables.",
        "Using leading or ambiguous survey question wording that introduces systematic response bias into quantitative research.",
        "Treating self-reported survey responses as objective ground truth without corroborating against official administrative data.",
        "Failing to obtain formal Institutional Review Board (IRB) ethical clearances before interviewing vulnerable community members.",
        "Reporting statistical significance (p-values) without discussing practical effect sizes and real-world policy relevance."
      ],
      [
        "Publishing unverified corporate sustainability claims (greenwashing) without verified carbon audit methodologies or GRI alignment.",
        "Treating corporate CSR expenditure as mere transactional philanthropy rather than designing sustainable community capacity-building.",
        "Selecting CSR projects arbitrarily based on executive personal interests rather than conducting formal community needs assessments.",
        "Failing to monitor whether funded CSR educational or healthcare facilities remain operational after initial project inauguration.",
        "Reporting superficial outputs (e.g. number of trees planted) rather than verifiable long-term outcomes (e.g. survival rate after 3 years)."
      ],
      [
        "Relying on simplistic linear economic models that fail to capture non-linear tipping points and macroeconomic feedback loops.",
        "Presenting macroeconomic forecasts as definitive predictions without publishing transparent confidence intervals and scenario bounds.",
        "Allowing partisan political biases to influence objective statistical interpretation of economic and employment indicators.",
        "Failing to make civic dashboards accessible, mobile-responsive, and multilingual for broader public community engagement.",
        "Publishing research findings without providing open access to underlying anonymized datasets and reproducible statistical code."
      ]
    ]
  }
};

export const CO_DOMAIN_SPECIALIZED_REGISTRY: Record<string, any> = {
  "docker & container orchestration": {
    "coDomainName": "Docker & Container Orchestration",
    "stream": "Computer Science",
    "specialistRole": "Senior DevOps & Platform Engineer",
    "techStack": {
      "cloudDevOps": [
        "Docker Engine",
        "Docker Compose",
        "Kubernetes (minikube/k8s)",
        "Trivy Security Scanner",
        "Helm",
        "GitHub Actions"
      ],
      "tools": [
        "cAdvisor",
        "Prometheus",
        "Containerd",
        "Alpine Linux",
        "Distroless Images"
      ]
    },
    "tierSuffixes": [
      "Multi-Stage Containerization & Hardening Pipeline",
      "Production Kubernetes Microservices & Helm Platform",
      "High-Throughput Enterprise Service Mesh & Chaos Testing System",
      "Autonomous AI-Driven Cluster Autoscaler & Cost Sentinel"
    ],
    "architecturePatterns": [
      "Immutable Multi-Stage Container Hierarchy with Security Gateways",
      "Declarative Helm Orchestration with Ingress Controller & Horizontal Pod Autoscaler",
      "Sidecar Proxy Service Mesh with mTLS & Distributed Tracing Telemetry",
      "Predictive ML Telemetry Pipeline with Custom Kubernetes Metrics API Adapter"
    ],
    "phaseProTips": [
      [
        "Use multi-stage Docker builds with distroless or alpine base images to reduce final image size from 1.2GB down to <50MB and eliminate unused compilers.",
        "Define healthchecks with start_period to allow database migrations and warm-up cycles to finish before traffic routing starts.",
        "Use Docker internal bridge DNS service names (e.g. http://db:5432) for inter-container communication instead of binding to host IP addresses.",
        "Always drop ALL Linux kernel capabilities by default (cap_drop: ALL) and add back only NET_BIND_SERVICE if unprivileged ports cannot be used.",
        "Use GitHub Actions docker/build-push-action with GitHub Actions cache (type=gha) to cut cloud container build times by 70%."
      ],
      [
        "Set pod anti-affinity in Helm templates to ensure replicas are scheduled across distinct physical nodes or availability zones.",
        "Use cert-manager ClusterIssuer with Let's Encrypt staging environment first to verify ACME challenge validation before requesting production certificates.",
        "Add a preStop hook with \"sleep 5\" to give ingress controllers time to stop sending traffic before the application receives SIGTERM.",
        "Configure scaleDown stabilizationWindowSeconds (e.g. 300s) on HPA to prevent rapid pod flapping (thrashing) when traffic fluctuates.",
        "Store Helm application configurations and Helm infrastructure charts in separate Git repositories to decouple developer releases from platform changes."
      ],
      [
        "Always configure sidecar.istio.io/proxyCPU and proxyMemory limits to prevent Envoy proxies from starving microservices of cluster compute.",
        "Use Istio AuthorizationPolicy with operation.paths and methods to enforce that service A can only call POST /orders and cannot access admin endpoints.",
        "Implement header-based routing (e.g. x-canary: true) alongside weight-based splitting so QA teams can test canaries directly in production.",
        "Use sampling rate configuration (e.g. 5% in production) in Jaeger to capture representative performance profiles without overwhelming storage.",
        "Set outlierDetection (circuit breaking) in DestinationRules with consecutive5xxErrors: 3 to automatically eject unhealthy pods from the mesh for 30 seconds."
      ],
      [
        "Aggregate metrics into 1-minute buckets before feeding into ML models to eliminate transient jitter from CPU garbage collection spikes.",
        "Always use the upper 95th percentile confidence bound for autoscaling decisions; under-provisioning causes service outages while slight over-provisioning only costs pennies.",
        "Implement local caching with 30-second TTL inside the Custom Metrics Adapter to prevent kube-controller-manager polling from overloading your inference service.",
        "Set container memory request equal to memory limit for predictable QoS (Guaranteed class) to prevent unexpected node evictions.",
        "Highlight dollar-for-dollar monthly infrastructure savings ($4,200/mo saved) directly in your GitHub header and resume bullet."
      ]
    ],
    "phasePitfalls": [
      [
        "Running containers as root (UID 0) inside production pods, which allows host container breakout if an RCE vulnerability exists.",
        "Wrapping container entrypoints in bash scripts without using \"exec\" or tini/dumb-init, swallowing SIGTERM signals and causing 30-second ungraceful SIGKILL terminations.",
        "Hardcoding localhost or 127.0.0.1 in inter-container network calls instead of using Docker internal bridge DNS service names.",
        "Running containers without memory limits on production hosts; an application memory leak can trigger the host kernel OOM killer to terminate critical system processes.",
        "Tagging and deploying images solely with \":latest\"; always tag images with immutable git commit SHAs to enable predictable rollbacks."
      ],
      [
        "Omitting resource requests and limits in Kubernetes manifests, causing Kubernetes scheduler to place pods blind, resulting in node starvation.",
        "Exposing internal databases or cache ports via LoadBalancer or public NodePort services instead of keeping them strictly ClusterIP.",
        "Setting identical liveness and readiness probe endpoints that fail simultaneously when a database has transient latency, triggering a cluster-wide restart storm.",
        "Autoscaling on CPU alone for I/O-bound microservices; if threads block on database locks, CPU stays low while requests queue infinitely.",
        "Manually modifying production Kubernetes resources using kubectl edit or apply; manual drift will be wiped out or cause GitOps sync conflicts."
      ],
      [
        "Enabling STRICT mTLS globally before verifying that legacy or third-party ingress services support mTLS certificates, breaking all ingress traffic.",
        "Relying on IP addresses for internal cluster authorization; pod IPs are ephemeral and reusable, violating zero-trust principles.",
        "Running canary deployments without session affinity or sticky routing on stateful user sessions, causing inconsistent user experience during rollouts.",
        "Failing to forward HTTP trace headers in backend application code; if a service drops x-request-id, distributed traces break into disconnected spans.",
        "Setting aggressive retry counts without exponential backoff and jitter; retrying failing services instantly creates a thundering herd that takes down downstreams."
      ],
      [
        "Querying Prometheus directly for multi-month training datasets; large range queries lock Prometheus TSDB and crash monitoring.",
        "Training models on dirty historical data containing unhandled outage spikes without clipping statistical outliers.",
        "Allowing custom metrics server to return 500 errors to Kubernetes API aggregator, which disables autoscaling cluster-wide.",
        "Applying automatic Vertical Pod Autoscaler (VPA) restarts during business peak hours; container restarts drop active WebSocket connections.",
        "Presenting an infrastructure project without concrete metrics; hiring managers want to see latency percentiles (p95/p99) and quantifiable cost reductions."
      ]
    ]
  },
  "cloud computing (aws / gcp)": {
    "coDomainName": "Cloud Computing (AWS / GCP)",
    "stream": "Computer Science",
    "specialistRole": "Senior Cloud Solutions Architect",
    "techStack": {
      "cloudDevOps": [
        "AWS IAM & STS",
        "Amazon ECS / EKS",
        "AWS Lambda (Serverless)",
        "Terraform (IaC)",
        "Amazon CloudWatch & WAF",
        "AWS CDK / S3"
      ],
      "tools": [
        "tflint",
        "checkov",
        "LocalStack",
        "AWS CLI v2"
      ]
    },
    "tierSuffixes": [
      "Zero-Trust IAM & Multi-VPC Cloud Network Blueprint",
      "Serverless Event-Driven Microservices & RDS Proxy Platform",
      "Multi-Region Auto-Scaling & Disaster Recovery System",
      "Autonomous AI Cloud Cost & Anomaly Detection Sentinel"
    ],
    "architecturePatterns": [
      "Hub-and-Spoke Transit Gateway Architecture with Least-Privilege IAM Roles",
      "Event-Driven Serverless Pipeline with SQS Dead-Letter Queues & DynamoDB Streams",
      "Active-Active Multi-Region Deployment with Route 53 Latency Routing & Aurora Global DB",
      "FinOps Automated Cost Analysis Engine with Real-Time Idle Resource Reclaim"
    ],
    "phaseProTips": [
      [
        "Enforce least-privilege IAM roles with session policies and temporary STS credentials; never create long-lived access key pairs.",
        "Segment cloud networks into public, private (compute), and isolated (database) subnets across multiple availability zones.",
        "Use Terraform remote state storage in Amazon S3 with DynamoDB state locking to prevent concurrent state corruption.",
        "Enable AWS CloudTrail in all regions with log file validation and send logs to an encrypted, write-once S3 bucket.",
        "Use Terraform module version pinning and run checkov static security analysis in CI before applying infrastructure changes."
      ],
      [
        "Keep Lambda execution contexts warm by placing heavy SDK clients, DB connections, and cryptographic keys outside the handler function.",
        "Connect Lambda functions to relational databases exclusively through Amazon RDS Proxy to pool connections and avoid connection exhaustion.",
        "Configure Amazon SQS dead-letter queues (DLQs) with maxReceiveCount: 3 to quarantine poisoned messages without blocking queue processing.",
        "Use DynamoDB Single Table Design with composite partition and sort keys (PK / SK) to fetch related entities in a single round-trip.",
        "Implement AWS API Gateway HTTP APIs with JWT authorizers for 3x lower latency and 70% cost savings over REST APIs."
      ],
      [
        "Deploy compute across multiple AWS Availability Zones behind an Application Load Balancer with cross-zone load balancing enabled.",
        "Use Amazon Route 53 latency-based routing paired with health checks to automatically route users to the lowest-latency healthy AWS region.",
        "Configure Amazon Aurora Global Database with asynchronous storage-based replication, achieving cross-region replication lag under 1 second.",
        "Implement AWS WAF rate-limiting rules and AWS Shield to automatically mitigate Layer 7 DDoS floods at the edge.",
        "Practice Chaos Engineering by running automated AWS Fault Injection Simulator (FIS) experiments to verify cross-region failover."
      ],
      [
        "Query AWS Cost and Usage Reports (CUR) using Amazon Athena to identify unattached EBS volumes and idle NAT Gateways.",
        "Train an anomaly detection model on historical daily AWS billing metrics to detect runaway Lambda recursion within 30 minutes.",
        "Implement automated Lambda Janitor scripts that scan for non-production EC2 instances running outside business hours and stop them.",
        "Use Compute Savings Plans and EC2 Spot Fleets with price-capacity-optimized allocation strategies to slash compute costs by 65%.",
        "Author comprehensive cloud architecture case studies featuring Well-Architected Framework reviews and verified FinOps ROI."
      ]
    ],
    "phasePitfalls": [
      [
        "Attaching AdministratorAccess or wildcards (Action: \"*\") to application compute roles or IAM user accounts.",
        "Deploying database instances in public subnets with public IP addresses (0.0.0.0/0) instead of private isolated subnets.",
        "Committing unencrypted AWS access keys or secret keys to GitHub repositories, resulting in automated bot compromise within seconds.",
        "Leaving S3 buckets world-readable or omitting S3 Block Public Access settings on production data buckets.",
        "Failing to enable multi-factor authentication (MFA) on AWS root accounts and administrator roles."
      ],
      [
        "Opening unbounded PostgreSQL connections inside serverless Lambda handlers without RDS Proxy, instantly exhausting database connection limits.",
        "Invoking Lambda functions synchronously from other Lambda functions, creating billing cascades and compounding latency.",
        "Using DynamoDB Scan operations instead of indexed queries (Query API), which consumes massive read capacity units and degrades as tables grow.",
        "Omitting dead-letter queues on asynchronous SQS/SNS event processors, causing failed messages to be silently dropped into the void.",
        "Placing Lambda functions inside VPCs without dedicated VPC endpoints, triggering slow cold starts and routing traffic through expensive NAT Gateways."
      ],
      [
        "Routing write operations or strict read-your-own-writes queries to asynchronous read replicas without accounting for replication lag.",
        "Configuring multi-region failover with hardcoded DNS IP addresses instead of CNAME aliases managed by Route 53 health checks.",
        "Testing disaster recovery solely on paper; un-tested backup snapshots frequently fail during real-world restore drills due to permission gaps.",
        "Allowing security group ingress rules with 0.0.0.0/0 on SSH port 22 or RDP port 3389.",
        "Failing to configure CloudWatch billing alarm notifications, allowing misconfigured recursive Lambdas to rack up thousands in charges overnight."
      ],
      [
        "Executing automated resource termination scripts in production without dry-run validation and approval safeguards.",
        "Purchasing rigid 3-year Reserved Instances for rapidly evolving workloads instead of flexible Compute Savings Plans.",
        "Relying on manual spreadsheets for cloud cost tracking instead of automated programmatic CUR billing pipelines.",
        "Ignoring inter-region and NAT Gateway data transfer costs, which frequently exceed raw compute charges on high-volume architectures.",
        "Presenting cloud infrastructure projects without demonstrating adherence to the 6 pillars of the AWS Well-Architected Framework."
      ]
    ]
  },
  "cybersecurity & oauth2 / jwt": {
    "coDomainName": "Cybersecurity & OAuth2 / JWT",
    "stream": "Computer Science",
    "specialistRole": "Senior Application Security Architect",
    "techStack": {
      "tools": [
        "OWASP ZAP",
        "Burp Suite Community",
        "Semgrep SAST",
        "OpenSSL / Jose JWT",
        "Wireshark Network Analyzer"
      ],
      "backend": [
        "Python 3.12 (Cryptography)",
        "OAuth2 / OIDC",
        "Redis Rate Limiter",
        "Pydantic v2",
        "Argon2 / bcrypt"
      ]
    },
    "tierSuffixes": [
      "Zero-Trust Auth & PKCE Token Architecture Blueprint",
      "Enterprise Role-Based Access Control (RBAC) & Audit Platform",
      "High-Throughput Rate-Limiting & Threat Defense Shield",
      "Autonomous AI Vulnerability Scanner & Penetration Sentinel"
    ],
    "architecturePatterns": [
      "OAuth2.1 Authorization Code Flow with PKCE & Asymmetric RS256 Token Verification",
      "Hierarchical Role & Attribute-Based Access Control (RBAC / ABAC) with Tamper-Proof Audit Logging",
      "Distributed Token Bucket Rate Limiting with Threat Intelligence IP Reputation Blocking",
      "Automated SAST/DAST Security Scanning Pipeline with OWASP Top 10 Exploit Verification"
    ],
    "phaseProTips": [
      [
        "Store JWT tokens in HttpOnly, SameSite=Strict, Secure cookies instead of localStorage to prevent token theft via Cross-Site Scripting (XSS).",
        "Sign tokens using asymmetric RS256 or EdDSA private keys and expose public verification keys via standard JWKS (JSON Web Key Set) endpoints.",
        "Enforce OAuth2 Proof Key for Code Exchange (PKCE) with SHA-256 code challenge even for confidential web clients.",
        "Set short access token lifetimes (15 minutes) paired with rotating refresh tokens stored with unique family IDs to detect token reuse attacks.",
        "Hash user passwords using Argon2id or bcrypt with cost factor 12, never using deprecated SHA-256 or MD5 hashes."
      ],
      [
        "Validate user tenant ID, permissions, and roles on every single backend route handler; never trust client-side role assertions.",
        "Implement cryptographically hashed, append-only security audit logs capturing timestamp, user ID, IP address, and authorization outcomes.",
        "Use parameterized SQL queries or ORMs exclusively to completely eliminate SQL Injection vulnerabilities.",
        "Configure strict Content Security Policy (CSP) headers (script-src \"self\") to neutralize unauthorized inline script execution.",
        "Enforce multi-factor authentication (MFA) using TOTP (RFC 6238) with time-drift tolerance of \u00b11 time step (30 seconds)."
      ],
      [
        "Implement sliding-window token bucket rate limiting using Redis Lua scripts to throttle brute-force credential stuffing and DDoS attacks.",
        "Maintain an in-memory Redis blocklist for revoked JWT IDs (jti) to achieve instantaneous token invalidation upon user logout or password reset.",
        "Strip all internal server headers (X-Powered-By, Server) and sanitize error responses to prevent tech stack fingerprinting.",
        "Validate and sanitize all incoming file uploads by checking MIME types, file magic bytes, and scanning with ClamAV before cloud storage.",
        "Implement automated account lockout after 5 consecutive failed login attempts with exponential backoff delays."
      ],
      [
        "Integrate Semgrep SAST rules into GitHub Actions to scan pull requests for hardcoded secrets and OWASP Top 10 vulnerabilities.",
        "Perform automated DAST security scanning using OWASP ZAP against staging environments prior to every production release.",
        "Implement automated threat modeling following the STRIDE methodology across all microservice communication boundaries.",
        "Conduct red-team penetration testing validating defenses against IDOR (Insecure Direct Object Reference) and CSRF attacks.",
        "Author comprehensive security audit whitepapers documenting threat models, penetration test findings, and remediation timelines."
      ]
    ],
    "phasePitfalls": [
      [
        "Storing JWTs in browser localStorage, making them easily accessible to any malicious third-party script injected via XSS.",
        "Using symmetric HS256 algorithm with a weak, guessable secret key instead of RS256 asymmetric public-private key cryptography.",
        "Accepting tokens with the \"alg\": \"none\" header or failing to strictly validate the signature algorithm on the backend.",
        "Allowing refresh tokens to be used indefinitely without rotation, meaning a stolen token gives permanent unauthorized account access.",
        "Failing to validate the \"iss\" (issuer) and \"aud\" (audience) claims in JWT payloads, allowing tokens from other apps to be accepted."
      ],
      [
        "Allowing IDOR vulnerabilities where an attacker modifies an order ID or account ID in the URL to view or edit another user data.",
        "Displaying raw database error messages or internal stack traces in HTTP 500 API responses, giving attackers complete schema visibility.",
        "Relying on client-side JavaScript to hide UI elements based on roles without enforcing authorization checks on the API endpoint.",
        "Omitting CSRF protection tokens on cookie-authenticated state-changing POST/PUT/DELETE requests.",
        "Failing to sanitize user input rendered into HTML, leaving the application vulnerable to stored and reflected XSS."
      ],
      [
        "Implementing rate limiting solely by client IP address; multiple corporate users sharing an egress NAT gateway get unfairly blocked.",
        "Failing to implement a token revocation mechanism, meaning compromised 30-day JWTs remain active until natural expiration.",
        "Allowing file uploads to retain original filenames or executing uploaded files directly from the web server document root.",
        "Omitting security headers (HSTS, X-Content-Type-Options, X-Frame-Options) across production HTTP responses.",
        "Failing to log failed authorization attempts, leaving security operations teams blind to active brute-force credential attacks."
      ],
      [
        "Disabling SAST security checks in CI/CD pipelines to speed up build times, allowing security regressions into production.",
        "Relying solely on automated vulnerability scanners without manual security code reviews for business logic vulnerabilities.",
        "Testing penetration payloads against production databases without isolated staging environments and data backups.",
        "Ignoring security vulnerabilities in third-party npm or pip dependencies; 80% of real-world breaches originate in dependencies.",
        "Presenting security projects without demonstrable proof of vulnerability mitigation against OWASP Top 10 benchmarks."
      ]
    ]
  }
};

/**
 * Resolves or dynamically synthesizes a complete 4-tier domain intelligence profile
 * guaranteeing unique, domain-specific, and project-specific Pro-Tips & Pitfalls.
 */
export function resolveCoDomainProfile(coDomainName: string, stream: string): CoDomainIntelligenceProfile {
  const cleanName = coDomainName.replace(/\(.*?\)/g, "").trim();
  const cleanLower = cleanName.toLowerCase();
  const slug = cleanName.toLowerCase().replace(/[^a-z0-9]+/g, "-");

  const specKey = Object.keys(CO_DOMAIN_SPECIALIZED_REGISTRY).find(k => 
    cleanLower === k || cleanLower.includes(k) || k.includes(cleanLower)
  );
  if (specKey && CO_DOMAIN_SPECIALIZED_REGISTRY[specKey]) {
    const spec = CO_DOMAIN_SPECIALIZED_REGISTRY[specKey];
    const hoursList = [20, 28, 36, 42];
    const durations = ["2 Weeks (18 hrs total)", "3 Weeks (25 hrs total)", "4 Weeks (35 hrs total)", "4-5 Weeks (40 hrs total)"];
    const blueprints: any = [0, 1, 2, 3].map(tIdx => {
      const titleSuffix = spec.tierSuffixes[tIdx];
      const archPattern = spec.architecturePatterns[tIdx];
      const projectTitle = `${cleanName}: ${titleSuffix}`;
      const phaseNames = [
        "Phase 1: Architecture, Modeling & Foundational Scaffolding",
        "Phase 2: Core Engine & Computational Business Logic",
        "Phase 3: Interactive Dashboard & Operational Execution",
        "Phase 4: Advanced Hardening, Security & Edge Case Optimization",
        "Phase 5: Automated Verification, CI/CD & Recruiter Portfolio"
      ];
      const phases = [0, 1, 2, 3, 4].map(pIdx => ({
        phaseName: phaseNames[pIdx],
        title: `${phaseNames[pIdx].split(": ")[1]} for ${cleanName}`,
        focus: `Mastering ${cleanName} standards, domain data contracts, and systematic implementation.`,
        deliverable: `Verified production deliverable adhering strictly to industry-grade ${cleanName} requirements.`,
        architectureFocus: archPattern,
        tasks: [
          { id: `${slug}-p${tIdx}-s${pIdx}-t1`, title: `Design & Modeling for ${cleanName}`, description: `Establish core schema, interface specifications, and baseline logic.`, estimatedHours: 2 },
          { id: `${slug}-p${tIdx}-s${pIdx}-t2`, title: `Implementation & Protocol Verification`, description: `Build computational rules, validation handlers, and error mitigation routines.`, estimatedHours: 2 },
          { id: `${slug}-p${tIdx}-s${pIdx}-t3`, title: `Quality Audit & Documentation`, description: `Verify edge cases, security/safety limits, and document working procedures.`, estimatedHours: 1.5 }
        ],
        proTips: [spec.phaseProTips[tIdx][pIdx]],
        pitfallsToAvoid: [spec.phasePitfalls[tIdx][pIdx]]
      }));

      return {
        titleSuffix: titleSuffix,
        tagline: `Industry-standard ${titleSuffix.toLowerCase()} engineered specifically for ${cleanName}.`,
        description: `A production-caliber project demonstrating applied expertise in ${cleanName}. Implements real-world conventions, error boundaries, and verifiable industry standards without generic placeholders.`,
        hours: hoursList[tIdx],
        duration: durations[tIdx],
        recruiterReason: `Proves to hiring managers and technical leads that you have mastered authentic industry practices in ${cleanName}.`,
        architecturePattern: archPattern,
        resumeStarBullet: `Architected ${projectTitle} leveraging ${archPattern}, achieving 100% compliance with industry standards and reducing processing latency by 35%.`,
        interviewQuestions: [
          {
            question: `What was the most critical technical or domain trade-off you evaluated while building ${projectTitle}?`,
            recruiterIntent: "Evaluates problem-solving rigor, critical thinking, and technical decision making.",
            answerStrategy: `Discuss the specific trade-off you evaluated in ${cleanName} (e.g. latency vs consistency, strictness vs flexibility), why you chose this design, and how the results validated your choice.`
          },
          {
            question: `How did you test, audit, and guarantee the reliability of your implementation?`,
            recruiterIntent: "Tests engineering discipline, domain standards awareness, and production readiness.",
            answerStrategy: `Detail your boundary condition verification strategy, automated checks, and adherence to established ${cleanName} standards to eliminate failure modes.`
          }
        ],
        phases: phases
      };
    });

    return {
      coDomainName: cleanName,
      stream: stream,
      specialistRole: spec.specialistRole,
      techStack: spec.techStack,
      blueprints: blueprints as [TierProjectBlueprint, TierProjectBlueprint, TierProjectBlueprint, TierProjectBlueprint]
    };
  }

  const sKey = Object.keys(STREAM_ARCHETYPES_REGISTRY).find(k => k.toLowerCase() === stream.toLowerCase()) ||
               Object.keys(STREAM_ARCHETYPES_REGISTRY).find(k => stream.toLowerCase().includes(k.toLowerCase()) || k.toLowerCase().includes(stream.toLowerCase())) ||
               "Computer Science";

  const arch = STREAM_ARCHETYPES_REGISTRY[sKey] || STREAM_ARCHETYPES_REGISTRY["Computer Science"];
  const hoursList = [18, 28, 36, 42];
  const durations = ["2 Weeks (15 hrs total)", "3 Weeks (25 hrs total)", "4 Weeks (35 hrs total)", "4-5 Weeks (40 hrs total)"];

  const blueprints: any = [0, 1, 2, 3].map(tIdx => {
    const titleSuffix = arch.tierSuffixes[tIdx];
    const archPattern = arch.architecturePatterns[tIdx];
    const projectTitle = `${cleanName}: ${titleSuffix}`;
    const hours = hoursList[tIdx];
    const duration = durations[tIdx];

    const phaseNames = [
      "Phase 1: Architecture, Modeling & Foundational Scaffolding",
      "Phase 2: Core Engine & Computational Business Logic",
      "Phase 3: Interactive Dashboard & Operational Execution",
      "Phase 4: Advanced Hardening, Security & Edge Case Optimization",
      "Phase 5: Automated Verification, CI/CD & Recruiter Portfolio"
    ];

    const phases = [0, 1, 2, 3, 4].map(pIdx => {
      const proTip = arch.phaseProTips[tIdx][pIdx];
      const pitfall = arch.phasePitfalls[tIdx][pIdx];
      return {
        phaseName: phaseNames[pIdx],
        title: `${phaseNames[pIdx].split(": ")[1]} for ${cleanName}`,
        focus: `Mastering ${cleanName} standards, domain data contracts, and systematic implementation.`,
        deliverable: `Verified production deliverable adhering strictly to industry-grade ${cleanName} requirements.`,
        architectureFocus: archPattern,
        tasks: [
          { id: `${slug}-p${tIdx}-s${pIdx}-t1`, title: `Design & Modeling for ${cleanName}`, description: `Establish core schema, interface specifications, and baseline logic.`, estimatedHours: 2 },
          { id: `${slug}-p${tIdx}-s${pIdx}-t2`, title: `Implementation & Protocol Verification`, description: `Build computational rules, validation handlers, and error mitigation routines.`, estimatedHours: 2 },
          { id: `${slug}-p${tIdx}-s${pIdx}-t3`, title: `Quality Audit & Documentation`, description: `Verify edge cases, security/safety limits, and document working procedures.`, estimatedHours: 1.5 }
        ],
        proTips: [proTip],
        pitfallsToAvoid: [pitfall]
      };
    });

    return {
      titleSuffix: titleSuffix,
      tagline: `Industry-standard ${titleSuffix.toLowerCase()} engineered specifically for ${cleanName}.`,
      description: `A production-caliber project demonstrating applied expertise in ${cleanName}. Implements real-world conventions, error boundaries, and verifiable industry standards without generic placeholders.`,
      hours: hours,
      duration: duration,
      recruiterReason: `Proves to hiring managers and technical leads that you have mastered authentic industry practices in ${cleanName}.`,
      architecturePattern: archPattern,
      resumeStarBullet: `Architected ${projectTitle} leveraging ${archPattern}, achieving 100% compliance with industry standards and reducing processing latency by 35%.`,
      interviewQuestions: [
        {
          question: `What was the most critical technical or domain trade-off you evaluated while building ${projectTitle}?`,
          recruiterIntent: "Evaluates problem-solving rigor, critical thinking, and technical decision making.",
          answerStrategy: `Discuss the specific trade-off you evaluated in ${cleanName} (e.g. latency vs consistency, strictness vs flexibility), why you chose this design, and how the results validated your choice.`
        },
        {
          question: `How did you test, audit, and guarantee the reliability of your implementation?`,
          recruiterIntent: "Tests engineering discipline, domain standards awareness, and production readiness.",
          answerStrategy: `Detail your boundary condition verification strategy, automated checks, and adherence to established ${cleanName} standards to eliminate failure modes.`
        }
      ],
      phases: phases
    };
  });

  return {
    coDomainName: cleanName,
    stream: stream,
    specialistRole: arch.specialistRole,
    techStack: arch.techStack,
    blueprints: blueprints as [TierProjectBlueprint, TierProjectBlueprint, TierProjectBlueprint, TierProjectBlueprint]
  };
}

/**
 * Builds the 4 GoodProject instances from a resolved CoDomainIntelligenceProfile
 */
export function buildProjectsFromProfile(profile: CoDomainIntelligenceProfile, cleanName: string, stream: string): GoodProject[] {
  const tiers: ProjectTier[] = ["foundational", "applied", "scalable", "flagship"];
  const tierLabels = [
    "Tier 1: Foundational Architecture",
    "Tier 2: Applied Production MVP",
    "Tier 3: Scalable Enterprise System",
    "Tier 4: Flagship Capstone Portfolio"
  ];
  const difficulties: ("Beginner" | "Intermediate" | "Advanced" | "Flagship Production")[] = [
    "Beginner", "Intermediate", "Advanced", "Flagship Production"
  ];
  const slug = cleanName.toLowerCase().replace(/[^a-z0-9]+/g, "-");

  return tiers.map((tier, idx) => {
    const bp = profile.blueprints[idx];
    const projectTitle = `${cleanName}: ${bp.titleSuffix}`;

    const buildRoadmap: ProjectBuildStep[] = bp.phases.map((p, pIdx) => ({
      stepNumber: pIdx + 1,
      phaseName: p.phaseName,
      title: p.title,
      focus: p.focus,
      estimatedHours: Math.round(bp.hours * 0.2),
      deliverable: p.deliverable,
      architectureFocus: p.architectureFocus,
      tasks: p.tasks,
      proTips: p.proTips,
      pitfallsToAvoid: p.pitfallsToAvoid
    }));

    return {
      id: `${slug}-p${idx + 1}`,
      coDomainName: cleanName,
      stream: stream,
      tier: tier,
      tierLabel: tierLabels[idx],
      title: projectTitle,
      tagline: bp.tagline,
      description: bp.description,
      difficulty: difficulties[idx],
      estimatedDuration: bp.duration,
      totalEstimatedHours: bp.hours,
      recruiterAppeal: bp.recruiterReason,
      techStack: profile.techStack,
      keyFeatures: [
        `Production-grade architecture tailored specifically for ${cleanName}`,
        "Strict domain verification and automated error mitigation",
        "Interactive operational visibility and compliance tracking",
        "Automated validation coverage of edge cases and safety limits",
        "Comprehensive case study documentation with demonstrable results"
      ],
      architecturePattern: bp.architecturePattern,
      buildRoadmap: buildRoadmap,
      resumeStarBullet: bp.resumeStarBullet,
      interviewQuestions: bp.interviewQuestions,
      githubTemplateHint: `Includes /src/core, /src/protocols, /src/ui, /tests, and /docs/architecture.png`
    };
  });
}
