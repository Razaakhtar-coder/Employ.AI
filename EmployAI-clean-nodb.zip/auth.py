from typing import Optional
from pydantic import BaseModel, EmailStr, Field


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    user_id: str
    email: str
    full_name: str
    avatar_url: Optional[str] = None
    is_premium: bool = False
    subscription_plan: Optional[str] = None
    subscription_valid_until: Optional[str] = None
    days_remaining: Optional[int] = 0
    is_expired: Optional[bool] = False


class TokenPayload(BaseModel):
    sub: Optional[str] = None
    role: Optional[str] = None
    exp: Optional[int] = None


class UserRegister(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=1)
    full_name: Optional[str] = None
    role: str = Field(default="student", pattern="^(student|academia|industry|admin)$")
    institution_or_company: Optional[str] = None
    department_or_domain: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str
    username: Optional[str] = None


class PasswordResetRequest(BaseModel):
    email: EmailStr
    new_password: str = Field(..., min_length=6)



class GoogleAuthRequest(BaseModel):
    id_token: Optional[str] = None
    email: Optional[EmailStr] = None
    password: Optional[str] = None
    full_name: Optional[str] = None
    avatar_url: Optional[str] = None
    role: Optional[str] = "student"
    isRegister: Optional[bool] = False


class UserResponse(BaseModel):
    id: str
    email: str
    full_name: str
    role: str
    auth_provider: str
    avatar_url: Optional[str] = None
    is_active: bool
    is_premium: bool = False
    subscription_plan: Optional[str] = None
    subscription_valid_until: Optional[str] = None
    days_remaining: Optional[int] = 0
    is_expired: Optional[bool] = False

    class Config:
        from_attributes = True

