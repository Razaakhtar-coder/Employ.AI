import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useRazorpay } from '../hooks/useRazorpay';
import { type SubscriptionPlanType } from '../services/api';
import { 
  Lock, Sparkles, Check, ArrowRight, Zap, CreditCard, 
  AlertCircle, CheckCircle, ShieldCheck 
} from 'lucide-react';

export interface LockedFeatureGateProps {
  sectionName: string;
  sectionSubtitle?: string;
  features: string[];
}

export const LockedFeatureGate: React.FC<LockedFeatureGateProps> = ({
  sectionName,
  sectionSubtitle,
  features
}) => {
  const { user, checkSubscription, openSubscriptionModal } = useAuth();

  const [rzpSuccess, setRzpSuccess] = useState<string | null>(null);
  const [payingPlan, setPayingPlan] = useState<SubscriptionPlanType | null>(null);

  const { startPayment, isLoading, error, isSuccess, setError } = useRazorpay({
    targetFeature: sectionName,
    onSuccess: async (data) => {
      if (data.is_premium) {
        setRzpSuccess('🎉 Payment verified! This section is now unlocked.');
        await checkSubscription();
        // Page will re-render showing the actual content once isPremium is true
      }
    },
    onDismiss: () => {
      setPayingPlan(null);
    },
  });

  const handleRazorpayPay = async (plan: SubscriptionPlanType) => {
    setError(null);
    setPayingPlan(plan);
    try {
      await startPayment(plan);
    } finally {
      setPayingPlan(null);
    }
  };

  return (
    <div className="locked-gate-container">
      {/* Dynamic ambient radial glow */}
      <div className="locked-gate-ambient-glow" />

      <div className="locked-gate-card">
        {/* Floating lock emblem */}
        <div className="locked-gate-lock-box">
          <Lock size={32} strokeWidth={2.4} />
        </div>

        {/* PRO Badge Pill */}
        <div className="locked-gate-pill">
          <Sparkles size={13} />
          <span className="locked-gate-pill-text">
            {user?.is_expired ? 'Subscription Expired · Action Required' : 'PRO Subscription Locked'}
          </span>
        </div>

        {/* High-Contrast Section Title */}
        <h2 className="locked-gate-title">{sectionName}</h2>

        {/* Informative Subtitle */}
        <p className="locked-gate-subtitle">
          {sectionSubtitle || 'This premium feature is locked. Subscribe to Employ.AI PRO (₹49/month or ₹499/year) to unlock immediate access.'}
        </p>

        {/* Expired Subscription Notice */}
        {user?.is_expired && (
          <div style={{
            margin: '0.4rem auto 1rem auto',
            maxWidth: '430px',
            width: '100%',
            padding: '0.65rem 0.95rem',
            borderRadius: '10px',
            background: 'rgba(245, 158, 11, 0.12)',
            border: '1px solid rgba(245, 158, 11, 0.45)',
            color: '#fbbf24',
            fontSize: '0.8rem',
            fontWeight: 700,
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            textAlign: 'left'
          }}>
            <AlertCircle size={17} style={{ flexShrink: 0 }} />
            <span>
              Your {user.subscription_plan === 'annual' ? 'Annual (365 Days)' : 'Monthly (30 Days)'} PRO access has ended. Choose a plan below to renew immediately.
            </span>
          </div>
        )}

        {/* Feature Highlights Grid */}
        <div className="locked-gate-feature-list">
          {features.map((f, i) => (
            <div key={i} className="locked-gate-feature-item">
              <div className="locked-gate-check-wrap">
                <Check size={12} strokeWidth={3} />
              </div>
              <span className="locked-gate-feature-text">{f}</span>
            </div>
          ))}
        </div>

        {/* ============================================================ */}
        {/* Action Buttons & Dual Plan Selection                          */}
        {/* ============================================================ */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.75rem', width: '100%', maxWidth: '430px' }}>

          {/* Success state */}
          {(rzpSuccess || isSuccess) && (
            <div style={{
              width: '100%', padding: '0.8rem 1rem', borderRadius: '10px',
              background: 'rgba(16,185,129,0.15)', border: '1px solid rgba(16,185,129,0.4)',
              color: '#34d399', fontSize: '0.85rem', fontWeight: 700,
              display: 'flex', alignItems: 'center', gap: '0.5rem', justifyContent: 'center'
            }}>
              <CheckCircle size={16} /> {rzpSuccess || 'Payment verified! Refreshing...'}
            </div>
          )}

          {/* Error state */}
          {error && !rzpSuccess && (
            <div style={{
              width: '100%', padding: '0.7rem 0.9rem', borderRadius: '8px',
              background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.35)',
              color: '#f87171', fontSize: '0.78rem',
              display: 'flex', alignItems: 'center', gap: '0.45rem'
            }}>
              <AlertCircle size={15} style={{ flexShrink: 0 }} /><span>{error}</span>
            </div>
          )}

          {/* Dual Plan Overview Cards */}
          {!rzpSuccess && (
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '0.65rem',
              width: '100%',
              marginBottom: '0.2rem'
            }}>
              {/* Annual Plan Card (Best Value) */}
              <div 
                onClick={() => !isLoading && handleRazorpayPay('annual')}
                style={{
                  padding: '0.75rem 0.8rem',
                  borderRadius: '10px',
                  border: '1.5px solid rgba(245, 158, 11, 0.55)',
                  background: 'rgba(245, 158, 11, 0.08)',
                  textAlign: 'center',
                  cursor: isLoading ? 'not-allowed' : 'pointer',
                  position: 'relative',
                  transition: 'all 0.2s',
                  boxShadow: '0 4px 14px rgba(245, 158, 11, 0.12)'
                }}
                title="Click to subscribe Annually (₹499/year)"
              >
                <span style={{
                  position: 'absolute',
                  top: '-9px',
                  right: '8px',
                  background: 'linear-gradient(135deg, #f59e0b, #ea580c)',
                  color: '#ffffff',
                  fontSize: '0.6rem',
                  fontWeight: 900,
                  padding: '0.12rem 0.45rem',
                  borderRadius: '4px',
                  boxShadow: '0 2px 6px rgba(0,0,0,0.35)',
                  letterSpacing: '0.04em'
                }}>
                  SAVE 15%
                </span>
                <div style={{ fontSize: '0.72rem', fontWeight: 800, color: '#f59e0b', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                  Annual Plan
                </div>
                <div style={{ fontSize: '1.2rem', fontWeight: 900, color: 'var(--text-primary)', margin: '0.15rem 0' }}>
                  ₹499 <span style={{ fontSize: '0.72rem', fontWeight: 500, color: 'var(--text-muted)' }}>/ yr</span>
                </div>
                <div style={{ fontSize: '0.68rem', fontWeight: 600, color: 'var(--text-muted)' }}>
                  365 Days · Best Value
                </div>
              </div>

              {/* Monthly Plan Card */}
              <div 
                onClick={() => !isLoading && handleRazorpayPay('monthly')}
                style={{
                  padding: '0.75rem 0.8rem',
                  borderRadius: '10px',
                  border: '1.5px solid rgba(2, 132, 199, 0.4)',
                  background: 'rgba(2, 132, 199, 0.08)',
                  textAlign: 'center',
                  cursor: isLoading ? 'not-allowed' : 'pointer',
                  transition: 'all 0.2s',
                  boxShadow: '0 4px 14px rgba(2, 132, 199, 0.08)'
                }}
                title="Click to subscribe Monthly (₹49/month)"
              >
                <div style={{ fontSize: '0.72rem', fontWeight: 800, color: '#0284c7', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                  Monthly Plan
                </div>
                <div style={{ fontSize: '1.2rem', fontWeight: 900, color: 'var(--text-primary)', margin: '0.15rem 0' }}>
                  ₹49 <span style={{ fontSize: '0.72rem', fontWeight: 500, color: 'var(--text-muted)' }}>/ mo</span>
                </div>
                <div style={{ fontSize: '0.68rem', fontWeight: 600, color: 'var(--text-muted)' }}>
                  30 Days · Standard
                </div>
              </div>
            </div>
          )}

          {/* 1. Annual Checkout Button (Best Value - Save 15%) */}
          {!rzpSuccess && (
            <button
              id={`razorpay-unlock-annual-${sectionName.replace(/\s+/g, '-').toLowerCase()}`}
              onClick={() => handleRazorpayPay('annual')}
              disabled={isLoading}
              className={`locked-gate-unlock-btn locked-gate-unlock-btn-annual ${payingPlan === 'annual' && isLoading ? 'is-loading' : ''}`}
              type="button"
            >
              {payingPlan === 'annual' && isLoading ? (
                <>
                  <div className="spinner-border" style={{ width: '16px', height: '16px', borderWidth: '2px' }} />
                  <span>Initiating Annual Razorpay (₹499)...</span>
                </>
              ) : (
                <>
                  <Sparkles size={17} />
                  <span>Pay ₹499 / Year — Unlock Instantly</span>
                  <span className="locked-gate-annual-tag">SAVE 15%</span>
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          )}

          {/* 2. Monthly Checkout Button (Standard ₹49) */}
          {!rzpSuccess && (
            <button
              id={`razorpay-unlock-monthly-${sectionName.replace(/\s+/g, '-').toLowerCase()}`}
              onClick={() => handleRazorpayPay('monthly')}
              disabled={isLoading}
              className={`locked-gate-unlock-btn ${payingPlan === 'monthly' && isLoading ? 'is-loading' : ''}`}
              type="button"
            >
              {payingPlan === 'monthly' && isLoading ? (
                <>
                  <div className="spinner-border" style={{ width: '16px', height: '16px', borderWidth: '2px' }} />
                  <span>Initiating Monthly Razorpay (₹49)...</span>
                </>
              ) : (
                <>
                  <CreditCard size={17} />
                  <span>Pay ₹49 / Month — Unlock Instantly</span>
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          )}

          {/* Trust strip */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.68rem', color: 'var(--text-muted)' }}>
            <ShieldCheck size={12} color="var(--accent-emerald)" />
            <span>256-bit SSL · PCI-DSS · Razorpay Verified</span>
          </div>

          {/* Secondary: open full modal (View All Features / Other options) */}
          <button
            onClick={openSubscriptionModal}
            type="button"
            className="locked-gate-check-status-btn"
          >
            <Zap size={12} style={{ display: 'inline', marginRight: '0.25rem' }} />
            View All PRO Features & Comparison Table
          </button>
        </div>
      </div>
    </div>
  );
};

export default LockedFeatureGate;
