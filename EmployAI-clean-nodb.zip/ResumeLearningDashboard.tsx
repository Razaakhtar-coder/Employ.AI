import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  BookOpen, CheckCircle2, Sparkles, AlertCircle, 
  Layers, Code, Briefcase, GraduationCap, Award, 
  ShieldCheck, ChevronRight, ChevronLeft,
  ArrowLeft, RefreshCw, Check, FileText,
  HelpCircle, Compass, Zap, BookMarked, Trophy,
  ChevronDown, ChevronUp, Cpu, Server,
  Flame
} from 'lucide-react';
import { FuturisticLoader } from './FuturisticLoader';
import { documentApi, getUserScopedStorageKey } from '../services/api';
import type { 
  ResumeAnalysisResult, StructuredResume, ResumeLearningGuideResponse,
  ResumeLearningSkillItem, ResumeLearningProjectItem,
  ResumeLearningExperienceItem, ResumeLearningEducationItem,
  ResumeLearningCertificationItem, ResumeLearningAchievementItem,
  ResumeLearningClaimItem, ResumeLearningSummarySection,
  ResumeLearningLineBreakdown,
  DeepDiveTopicDetail
} from '../types';
import { buildClientResumeLearningGuide } from '../utils/resumeLearningEngine';

interface ResumeLearningDashboardProps {
  onNavigateToResume?: () => void;
  initialSectionId?: string | null;
  resumeData?: {
    analysis: ResumeAnalysisResult | null;
    structuredResume: StructuredResume | null;
  };
}

export const ResumeLearningDashboard: React.FC<ResumeLearningDashboardProps> = ({
  onNavigateToResume,
  initialSectionId = null,
  resumeData
}) => {
  const [guide, setGuide] = useState<ResumeLearningGuideResponse | null>(null);
  const [activeDocumentId, setActiveDocumentId] = useState<string>('default');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  
  // Active viewing state
  const [activeSectionId, setActiveSectionId] = useState<string | null>(initialSectionId);
  const [activeItemIndex, setActiveItemIndex] = useState<number>(0);
  const [explanationLevel, setExplanationLevel] = useState<'beginner' | 'deeper'>('beginner');

  // Track reviewed items per specific resume document ID
  const [reviewedKeys, setReviewedKeys] = useState<Set<string>>(new Set());

  // Load reviewed keys for specific document ID
  const loadReviewedKeysForDoc = useCallback((docId: string) => {
    try {
      const storageKey = `employai_learning_reviewed_${docId}`;
      const saved = localStorage.getItem(storageKey);
      setReviewedKeys(saved ? new Set(JSON.parse(saved)) : new Set());
    } catch {
      setReviewedKeys(new Set());
    }
  }, []);

  // Save reviewed keys to localStorage for active document
  const toggleReviewed = useCallback((key: string) => {
    setReviewedKeys(prev => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      try {
        const storageKey = `employai_learning_reviewed_${activeDocumentId}`;
        localStorage.setItem(storageKey, JSON.stringify(Array.from(next)));
      } catch (err) {
        console.warn('Failed to save learning progress to localStorage:', err);
      }
      return next;
    });
  }, [activeDocumentId]);

  // Fetch or generate truthful learning guide from active resume
  const loadLearningGuide = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      let analysis: ResumeAnalysisResult | null = resumeData?.analysis || null;
      let struct: StructuredResume | null = resumeData?.structuredResume || null;

      // 1. If not provided via props, inspect localStorage with full scoping
      if (!analysis || !struct) {
        try {
          const scopedResumeKey = getUserScopedStorageKey('employai_active_resume_analysis');
          const scopedStructKey = getUserScopedStorageKey('employai_active_structured_resume');

          const rawResume = localStorage.getItem(scopedResumeKey) || 
                            localStorage.getItem('employai_active_resume_analysis');
          const rawStruct = localStorage.getItem(scopedStructKey) || 
                            localStorage.getItem('employai_active_structured_resume');

          if (rawResume) {
            try { analysis = JSON.parse(rawResume); } catch {}
          }
          if (rawStruct) {
            try { struct = JSON.parse(rawStruct); } catch {}
          } else if (analysis?.structured_resume) {
            struct = analysis.structured_resume;
          }

          // Scan all employai_active_resume_analysis keys across localStorage
          if (!analysis) {
            for (let i = 0; i < localStorage.length; i++) {
              const k = localStorage.key(i);
              if (k && k.startsWith('employai_active_resume_analysis')) {
                const val = localStorage.getItem(k);
                if (val) {
                  try {
                    analysis = JSON.parse(val);
                    struct = analysis?.structured_resume || struct;
                    break;
                  } catch {}
                }
              }
            }
          }

          // Scan employai_my_resumes as fallback
          if (!analysis) {
            for (let i = 0; i < localStorage.length; i++) {
              const k = localStorage.key(i);
              if (k && k.startsWith('employai_my_resumes')) {
                const val = localStorage.getItem(k);
                if (val) {
                  try {
                    const arr = JSON.parse(val);
                    if (Array.isArray(arr) && arr.length > 0) {
                      analysis = arr[0];
                      struct = analysis?.structured_resume || struct;
                      break;
                    }
                  } catch {}
                }
              }
            }
          }
        } catch (storageErr) {
          console.warn('Error reading resume from localStorage:', storageErr);
        }
      }

      // 2. Try fetching from backend if still not found
      if (!analysis && !struct) {
        analysis = await documentApi.getLatestAnalysis().catch(() => null);
        struct = analysis?.structured_resume || null;
      }

      // 3. Fallbacks between struct and analysis
      if (analysis && !struct) {
        struct = analysis.structured_resume || null;
      }
      if (struct && !analysis) {
        analysis = {
          id: 'local_resume',
          filename: struct.personal_info?.full_name ? `${struct.personal_info.full_name}_Resume.pdf` : 'My_Resume.pdf',
          detected_domain: 'Engineering & Technology',
          resume_quality_score: 85,
          score_breakdown: { structure: 85, content_impact: 85, skill_density: 85, formatting_clarity: 85, overall_quality: 85 },
          strengths: ['Verified extracted sections'],
          weaknesses: [],
          extracted_skills: struct.skills || [],
          extracted_projects: (struct.projects || []).map(p => ({
            title: p.title,
            role_or_tech: p.role_or_tech,
            description: p.description || '',
            key_technologies: p.technologies || []
          })),
          extracted_experience: (struct.experience || []).map(e => ({
            company_or_org: e.company,
            role: e.role,
            duration: e.duration,
            highlights: e.bullets || []
          })),
          improvements: [],
          structured_resume: struct,
          created_at: new Date().toISOString()
        };
      }

      if (!analysis && !struct) {
        setError('No uploaded resume found. Please upload or parse a resume first.');
        setIsLoading(false);
        return;
      }

      const docId = analysis?.document_id || analysis?.id || analysis?.filename || 'default_resume';
      setActiveDocumentId(docId);
      loadReviewedKeysForDoc(docId);

      // Try fetching from backend endpoint with fallback to client deterministic engine
      try {
        const backendGuide = await documentApi.getResumeLearningGuide(analysis?.document_id);
        if (backendGuide && backendGuide.sections && backendGuide.sections.length > 0) {
          setGuide(backendGuide);
          setIsLoading(false);
          return;
        }
      } catch (apiErr) {
        console.info('[INFO] Backend endpoint fallback to client learning engine:', apiErr);
      }

      // Fallback to client deterministic engine with rich deep-dive logic
      const clientGuide = buildClientResumeLearningGuide(struct, analysis);
      setGuide(clientGuide);
    } catch (err: any) {
      console.error('Failed to load resume learning guide:', err);
      setError(err?.message || 'Failed to load resume learning guide.');
    } finally {
      setIsLoading(false);
    }
  }, [resumeData, loadReviewedKeysForDoc]);

  useEffect(() => {
    loadLearningGuide();
  }, [loadLearningGuide]);

  // Synchronize immediately if resume is uploaded anywhere in the app
  useEffect(() => {
    const handleResumeUpdated = (e: any) => {
      if (e?.detail) {
        loadLearningGuide();
      }
    };
    window.addEventListener('employai:resume-updated', handleResumeUpdated);
    window.addEventListener('storage', handleResumeUpdated);
    return () => {
      window.removeEventListener('employai:resume-updated', handleResumeUpdated);
      window.removeEventListener('storage', handleResumeUpdated);
    };
  }, [loadLearningGuide]);

  // If initialSectionId changes from props
  useEffect(() => {
    if (initialSectionId) {
      setActiveSectionId(initialSectionId);
      setActiveItemIndex(0);
    }
  }, [initialSectionId]);

  // Compute live progress percentage based on reviewed items
  const progressStats = useMemo(() => {
    if (!guide) return { totalItems: 0, reviewedCount: 0, percentage: 0, sectionBreakdown: [] };

    let total = 0;
    let reviewed = 0;
    const sectionBreakdown: { id: string; title: string; total: number; reviewed: number; isComplete: boolean }[] = [];

    // Summary
    if (guide.summary_section) {
      total += 1;
      const isRev = reviewedKeys.has('summary-0');
      if (isRev) reviewed += 1;
      sectionBreakdown.push({ id: 'summary', title: 'Summary', total: 1, reviewed: isRev ? 1 : 0, isComplete: isRev });
    }

    // Skills
    if (guide.skills && guide.skills.length > 0) {
      total += guide.skills.length;
      const revCount = guide.skills.filter((_, idx) => reviewedKeys.has(`skill-${idx}`)).length;
      reviewed += revCount;
      sectionBreakdown.push({ id: 'skills', title: 'Skills', total: guide.skills.length, reviewed: revCount, isComplete: revCount === guide.skills.length });
    }

    // Experience
    if (guide.experience && guide.experience.length > 0) {
      total += guide.experience.length;
      const revCount = guide.experience.filter((_, idx) => reviewedKeys.has(`exp-${idx}`)).length;
      reviewed += revCount;
      sectionBreakdown.push({ id: 'experience', title: 'Experience', total: guide.experience.length, reviewed: revCount, isComplete: revCount === guide.experience.length });
    }

    // Internships
    if (guide.internships && guide.internships.length > 0) {
      total += guide.internships.length;
      const revCount = guide.internships.filter((_, idx) => reviewedKeys.has(`intern-${idx}`)).length;
      reviewed += revCount;
      sectionBreakdown.push({ id: 'internship', title: 'Internship', total: guide.internships.length, reviewed: revCount, isComplete: revCount === guide.internships.length });
    }

    // Projects
    if (guide.projects && guide.projects.length > 0) {
      total += guide.projects.length;
      const revCount = guide.projects.filter((_, idx) => reviewedKeys.has(`prj-${idx}`)).length;
      reviewed += revCount;
      sectionBreakdown.push({ id: 'projects', title: 'Projects', total: guide.projects.length, reviewed: revCount, isComplete: revCount === guide.projects.length });
    }

    // Education
    if (guide.education && guide.education.length > 0) {
      total += guide.education.length;
      const revCount = guide.education.filter((_, idx) => reviewedKeys.has(`edu-${idx}`)).length;
      reviewed += revCount;
      sectionBreakdown.push({ id: 'education', title: 'Education', total: guide.education.length, reviewed: revCount, isComplete: revCount === guide.education.length });
    }

    // Certifications
    if (guide.certifications && guide.certifications.length > 0) {
      total += guide.certifications.length;
      const revCount = guide.certifications.filter((_, idx) => reviewedKeys.has(`cert-${idx}`)).length;
      reviewed += revCount;
      sectionBreakdown.push({ id: 'certifications', title: 'Certifications', total: guide.certifications.length, reviewed: revCount, isComplete: revCount === guide.certifications.length });
    }

    // Achievements
    if (guide.achievements && guide.achievements.length > 0) {
      total += guide.achievements.length;
      const revCount = guide.achievements.filter((_, idx) => reviewedKeys.has(`ach-${idx}`)).length;
      reviewed += revCount;
      sectionBreakdown.push({ id: 'achievements', title: 'Achievements', total: guide.achievements.length, reviewed: revCount, isComplete: revCount === guide.achievements.length });
    }

    // Claims
    if (guide.claims && guide.claims.length > 0) {
      total += guide.claims.length;
      const revCount = guide.claims.filter((_, idx) => reviewedKeys.has(`claim-${idx}`)).length;
      reviewed += revCount;
      sectionBreakdown.push({ id: 'claims', title: 'Claims', total: guide.claims.length, reviewed: revCount, isComplete: revCount === guide.claims.length });
    }

    const pct = total > 0 ? Math.round((reviewed / total) * 100) : 0;
    return { totalItems: total, reviewedCount: reviewed, percentage: pct, sectionBreakdown };
  }, [guide, reviewedKeys]);

  // Section icons mapping
  const getSectionIcon = (id: string, size = 18) => {
    switch (id) {
      case 'summary': return <FileText size={size} color="var(--accent-cyan)" />;
      case 'skills': return <Code size={size} color="#34d399" />;
      case 'experience': return <Briefcase size={size} color="#60a5fa" />;
      case 'internship': return <Compass size={size} color="#a78bfa" />;
      case 'projects': return <Layers size={size} color="#f59e0b" />;
      case 'education': return <GraduationCap size={size} color="#ec4899" />;
      case 'certifications': return <Award size={size} color="#38bdf8" />;
      case 'achievements': return <Trophy size={size} color="#eab308" />;
      case 'claims': return <Sparkles size={size} color="#fbbf24" />;
      default: return <BookOpen size={size} color="var(--accent-cyan)" />;
    }
  };

  // Reset progress handler
  const handleResetProgress = () => {
    if (window.confirm('Reset your resume learning progress for this resume?')) {
      setReviewedKeys(new Set());
      try {
        localStorage.removeItem(`employai_learning_reviewed_${activeDocumentId}`);
      } catch (e) {
        console.warn(e);
      }
    }
  };

  // Render Loading State
  if (isLoading) {
    return (
      <div className="glass-card" style={{ padding: '3.5rem 2rem', textAlign: 'center' }}>
        <FuturisticLoader
          size="lg"
          icon="sparkles"
          title="Generating Deep Personalized Resume Learning Guide..."
          subtitle="Extracting ground-truth sections, skills, and claims directly from your uploaded resume with in-depth technical analysis."
        />
      </div>
    );
  }

  // Render Error / Empty State
  if (error || !guide) {
    return (
      <div className="glass-card" style={{ padding: '2.5rem 2rem', textAlign: 'center' }}>
        <AlertCircle size={40} color="#f43f5e" style={{ margin: '0 auto 1rem auto' }} />
        <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)' }}>
          Resume Data Not Available
        </h3>
        <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.4rem', maxWidth: '480px', margin: '0.4rem auto 1.5rem auto' }}>
          {error || 'Please upload or analyze a resume first to generate your interactive learning guide.'}
        </p>
        {onNavigateToResume && (
          <button onClick={onNavigateToResume} className="btn btn-primary btn-sm">
            <FileText size={14} /> Go to AI Resume Analyzer
          </button>
        )}
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      
      {/* 1. Header Banner */}
      <div 
        className="glass-card role-hero-banner" 
        style={{ 
          padding: '1.5rem 1.75rem', 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between', 
          flexWrap: 'wrap', 
          gap: '1rem',
          background: 'var(--grad-banner)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-md)'
        }}
      >
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.35rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '32px', height: '32px', borderRadius: '8px', background: 'rgba(56, 189, 248, 0.15)', border: '1px solid var(--accent-cyan)' }}>
              <BookMarked size={18} color="var(--accent-cyan)" />
            </div>
            <h1 style={{ fontSize: '1.45rem', fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.02em', margin: 0 }}>
              READ & LEARN MY RESUME
            </h1>
            <span className="badge badge-cyan" style={{ fontSize: '0.68rem', fontWeight: 700 }}>
              <ShieldCheck size={12} /> Ground-Truth Analysis
            </span>
          </div>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', margin: 0 }}>
            Understand every section, skill, project, and claim on your resume with deep architectural context.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
          <div style={{ padding: '0.4rem 0.8rem', borderRadius: '8px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontWeight: 600 }}>CANDIDATE:</span>
            <strong style={{ fontSize: '0.78rem', color: 'var(--text-primary)', fontWeight: 700 }}>{guide.candidate_name || 'Candidate'}</strong>
            <span style={{ color: 'var(--text-muted)' }}>•</span>
            <span style={{ fontSize: '0.72rem', color: 'var(--accent-cyan)', fontWeight: 600 }}>{guide.detected_domain}</span>
          </div>

          <button onClick={loadLearningGuide} className="btn btn-secondary btn-sm" title="Reload Learning Guide">
            <RefreshCw size={13} /> Refresh
          </button>
        </div>
      </div>

      {/* 2. Overall Progress Tracker Bar */}
      <div className="glass-card" style={{ padding: '1.25rem 1.5rem', display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <Zap size={16} color="#fbbf24" />
            <h3 style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
              Resume Learning Progress
            </h3>
            <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              ({progressStats.reviewedCount}/{progressStats.totalItems} items reviewed)
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <span style={{ fontSize: '1.1rem', fontWeight: 800, color: progressStats.percentage === 100 ? '#34d399' : 'var(--accent-cyan)' }}>
              Resume Learning: {progressStats.percentage}% complete
            </span>
            {progressStats.reviewedCount > 0 && (
              <button 
                onClick={handleResetProgress}
                style={{ background: 'transparent', border: 'none', color: 'var(--text-muted)', fontSize: '0.72rem', cursor: 'pointer', textDecoration: 'underline' }}
              >
                Reset
              </button>
            )}
          </div>
        </div>

        {/* Multi-gradient progress bar */}
        <div style={{ width: '100%', height: '8px', borderRadius: '4px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)', overflow: 'hidden' }}>
          <div 
            style={{ 
              width: `${progressStats.percentage}%`, 
              height: '100%', 
              background: 'linear-gradient(90deg, #38bdf8 0%, #34d399 100%)', 
              borderRadius: '4px',
              transition: 'width 0.4s ease-in-out',
              boxShadow: '0 0 10px rgba(56, 189, 248, 0.5)'
            }} 
          />
        </div>

        <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', margin: 0, fontStyle: 'italic' }}>
          * This represents how much of your resume you have reviewed, NOT your actual skill level.
        </p>

        {/* Section checklist chips */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginTop: '0.2rem' }}>
          {progressStats.sectionBreakdown.map((sec) => (
            <button
              key={sec.id}
              onClick={() => {
                setActiveSectionId(sec.id);
                setActiveItemIndex(0);
              }}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.35rem',
                padding: '0.3rem 0.65rem',
                borderRadius: '6px',
                background: sec.isComplete ? 'rgba(16, 185, 129, 0.12)' : (activeSectionId === sec.id ? 'rgba(56, 189, 248, 0.12)' : 'var(--bg-inset)'),
                border: sec.isComplete ? '1px solid rgba(16, 185, 129, 0.35)' : (activeSectionId === sec.id ? '1px solid rgba(56, 189, 248, 0.4)' : '1px solid var(--border-subtle)'),
                color: sec.isComplete ? '#34d399' : (activeSectionId === sec.id ? 'var(--accent-cyan)' : 'var(--text-secondary)'),
                fontSize: '0.74rem',
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'all 0.15s'
              }}
            >
              {sec.isComplete ? <CheckCircle2 size={13} color="#34d399" /> : getSectionIcon(sec.id, 13)}
              <span>{sec.title}</span>
              <span style={{ fontSize: '0.66rem', opacity: 0.8 }}>
                {sec.isComplete ? '✓' : `${sec.reviewed}/${sec.total}`}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* 3. Section Overview vs Focused Deep-Dive Mode */}
      {!activeSectionId ? (
        /* SECTION CARDS GRID (Overview Mode) */
        <div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
            <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
              Detected Resume Sections ({guide.sections.length})
            </h3>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              Only showing sections that actually exist on your resume
            </span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.25rem' }}>
            {guide.sections.map((sec) => {
              const secStat = progressStats.sectionBreakdown.find(s => s.id === sec.id);
              const isComp = secStat?.isComplete || false;

              return (
                <div 
                  key={sec.id}
                  className="glass-card"
                  style={{
                    padding: '1.35rem',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    gap: '1rem',
                    border: isComp ? '1px solid rgba(16, 185, 129, 0.3)' : '1px solid var(--border-subtle)',
                    transition: 'transform 0.2s, box-shadow 0.2s',
                    cursor: 'pointer'
                  }}
                  onClick={() => {
                    setActiveSectionId(sec.id);
                    setActiveItemIndex(0);
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-2px)';
                    e.currentTarget.style.boxShadow = 'var(--shadow-md)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                >
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.65rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <div style={{ padding: '0.4rem', borderRadius: '8px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)' }}>
                          {getSectionIcon(sec.id, 18)}
                        </div>
                        <h4 style={{ fontSize: '0.98rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0, textTransform: 'uppercase' }}>
                          {sec.title}
                        </h4>
                      </div>

                      {isComp ? (
                        <span className="badge badge-emerald" style={{ fontSize: '0.68rem' }}>
                          <CheckCircle2 size={11} /> Reviewed ✓
                        </span>
                      ) : (
                        <span className="badge badge-secondary" style={{ fontSize: '0.68rem' }}>
                          {secStat?.reviewed || 0}/{sec.total_items} Items
                        </span>
                      )}
                    </div>

                    <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', lineHeight: 1.5, margin: 0 }}>
                      {sec.id === 'summary' && 'Understand your candidate positioning, elevator pitch, and value proposition.'}
                      {sec.id === 'skills' && `Study all ${sec.total_items} verified skills, runtime architecture, memory models, and interview talking points.`}
                      {sec.id === 'experience' && `Review your work responsibilities, verified contributions, engineering lifecycle, and terminology.`}
                      {sec.id === 'internship' && `Review your internship scope, deliverables, and demonstrated skills.`}
                      {sec.id === 'projects' && `Understand system architecture, technical decisions, trade-offs, and scaling plans for your ${sec.total_items} projects.`}
                      {sec.id === 'education' && 'Review foundational academic principles, domain theory, and degree credentials.'}
                      {sec.id === 'certifications' && 'Understand the standardized vendor frameworks validated by your credentials.'}
                      {sec.id === 'achievements' && 'Review context, criteria, and talking points for your listed achievements.'}
                      {sec.id === 'claims' && 'Prepare for critical technical questions and verification on your specific resume claims.'}
                    </p>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '0.75rem', borderTop: '1px solid var(--border-subtle)' }}>
                    <span style={{ fontSize: '0.72rem', color: isComp ? '#34d399' : 'var(--accent-cyan)', fontWeight: 600 }}>
                      {isComp ? '✓ Reviewed' : 'Click to Study'}
                    </span>
                    <button 
                      className="btn btn-primary btn-sm"
                      style={{ fontSize: '0.72rem', padding: '0.35rem 0.75rem', display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}
                    >
                      <BookOpen size={12} /> Read & Learn
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* FOCUSED SECTION DEEP DIVE VIEWER */
        <FocusedSectionViewer 
          guide={guide}
          activeSectionId={activeSectionId}
          activeItemIndex={activeItemIndex}
          explanationLevel={explanationLevel}
          reviewedKeys={reviewedKeys}
          onBack={() => {
            setActiveSectionId(null);
            setActiveItemIndex(0);
          }}
          onSelectIndex={(idx) => setActiveItemIndex(idx)}
          onToggleExplanationLevel={(lvl) => setExplanationLevel(lvl)}
          onToggleReviewed={toggleReviewed}
          getSectionIcon={getSectionIcon}
        />
      )}

    </div>
  );
};

/* =========================================================================
   FOCUSED SECTION VIEWER COMPONENT
   ========================================================================= */

interface FocusedSectionViewerProps {
  guide: ResumeLearningGuideResponse;
  activeSectionId: string;
  activeItemIndex: number;
  explanationLevel: 'beginner' | 'deeper';
  reviewedKeys: Set<string>;
  onBack: () => void;
  onSelectIndex: (idx: number) => void;
  onToggleExplanationLevel: (lvl: 'beginner' | 'deeper') => void;
  onToggleReviewed: (key: string) => void;
  getSectionIcon: (id: string, size?: number) => React.ReactNode;
}

const FocusedSectionViewer: React.FC<FocusedSectionViewerProps> = ({
  guide,
  activeSectionId,
  activeItemIndex,
  explanationLevel,
  reviewedKeys,
  onBack,
  onSelectIndex,
  onToggleExplanationLevel,
  onToggleReviewed,
  getSectionIcon
}) => {
  // Render sub-items based on section
  const renderContent = () => {
    switch (activeSectionId) {
      case 'summary':
        return guide.summary_section ? (
          <SummarySectionCard 
            summary={guide.summary_section}
            explanationLevel={explanationLevel}
            isReviewed={reviewedKeys.has('summary-0')}
            onToggleReviewed={() => onToggleReviewed('summary-0')}
          />
        ) : null;

      case 'skills': {
        const skills = guide.skills || [];
        const item = skills[activeItemIndex] || skills[0];
        const itemKey = `skill-${activeItemIndex}`;
        return item ? (
          <SkillSectionCard 
            skill={item}
            explanationLevel={explanationLevel}
            isReviewed={reviewedKeys.has(itemKey)}
            onToggleReviewed={() => onToggleReviewed(itemKey)}
          />
        ) : null;
      }

      case 'projects': {
        const projects = guide.projects || [];
        const item = projects[activeItemIndex] || projects[0];
        const itemKey = `prj-${activeItemIndex}`;
        return item ? (
          <ProjectSectionCard 
            project={item}
            explanationLevel={explanationLevel}
            isReviewed={reviewedKeys.has(itemKey)}
            onToggleReviewed={() => onToggleReviewed(itemKey)}
          />
        ) : null;
      }

      case 'experience': {
        const expList = guide.experience || [];
        const item = expList[activeItemIndex] || expList[0];
        const itemKey = `exp-${activeItemIndex}`;
        return item ? (
          <ExperienceSectionCard 
            exp={item}
            explanationLevel={explanationLevel}
            isReviewed={reviewedKeys.has(itemKey)}
            onToggleReviewed={() => onToggleReviewed(itemKey)}
          />
        ) : null;
      }

      case 'internship': {
        const internList = guide.internships || [];
        const item = internList[activeItemIndex] || internList[0];
        const itemKey = `intern-${activeItemIndex}`;
        return item ? (
          <ExperienceSectionCard 
            exp={item}
            explanationLevel={explanationLevel}
            isReviewed={reviewedKeys.has(itemKey)}
            onToggleReviewed={() => onToggleReviewed(itemKey)}
          />
        ) : null;
      }

      case 'education': {
        const eduList = guide.education || [];
        const item = eduList[activeItemIndex] || eduList[0];
        const itemKey = `edu-${activeItemIndex}`;
        return item ? (
          <EducationSectionCard 
            edu={item}
            explanationLevel={explanationLevel}
            isReviewed={reviewedKeys.has(itemKey)}
            onToggleReviewed={() => onToggleReviewed(itemKey)}
          />
        ) : null;
      }

      case 'certifications': {
        const certList = guide.certifications || [];
        const item = certList[activeItemIndex] || certList[0];
        const itemKey = `cert-${activeItemIndex}`;
        return item ? (
          <CertificationSectionCard 
            cert={item}
            explanationLevel={explanationLevel}
            isReviewed={reviewedKeys.has(itemKey)}
            onToggleReviewed={() => onToggleReviewed(itemKey)}
          />
        ) : null;
      }

      case 'achievements': {
        const achList = guide.achievements || [];
        const item = achList[activeItemIndex] || achList[0];
        const itemKey = `ach-${activeItemIndex}`;
        return item ? (
          <AchievementSectionCard 
            ach={item}
            explanationLevel={explanationLevel}
            isReviewed={reviewedKeys.has(itemKey)}
            onToggleReviewed={() => onToggleReviewed(itemKey)}
          />
        ) : null;
      }

      case 'claims': {
        const claimList = guide.claims || [];
        const item = claimList[activeItemIndex] || claimList[0];
        const itemKey = `claim-${activeItemIndex}`;
        return item ? (
          <ClaimSectionCard 
            claim={item}
            explanationLevel={explanationLevel}
            isReviewed={reviewedKeys.has(itemKey)}
            onToggleReviewed={() => onToggleReviewed(itemKey)}
          />
        ) : null;
      }

      default:
        return null;
    }
  };

  // Get total count of items in current section
  const getItemsCount = () => {
    switch (activeSectionId) {
      case 'summary': return guide.summary_section ? 1 : 0;
      case 'skills': return guide.skills.length;
      case 'projects': return guide.projects.length;
      case 'experience': return guide.experience.length;
      case 'internship': return guide.internships.length;
      case 'education': return guide.education.length;
      case 'certifications': return guide.certifications.length;
      case 'achievements': return (guide.achievements || []).length;
      case 'claims': return guide.claims.length;
      default: return 0;
    }
  };

  const totalItems = getItemsCount();

  // Item selector tabs labels
  const getItemLabel = (idx: number) => {
    switch (activeSectionId) {
      case 'skills': return guide.skills[idx]?.skill_name || `Skill ${idx + 1}`;
      case 'projects': return guide.projects[idx]?.project_name || `Project ${idx + 1}`;
      case 'experience': return guide.experience[idx]?.role || `Role ${idx + 1}`;
      case 'internship': return guide.internships[idx]?.role || `Internship ${idx + 1}`;
      case 'education': return guide.education[idx]?.degree || `Degree ${idx + 1}`;
      case 'certifications': return guide.certifications[idx]?.name || `Cert ${idx + 1}`;
      case 'achievements': return guide.achievements?.[idx]?.title || `Achievement ${idx + 1}`;
      case 'claims': return `Claim #${idx + 1}`;
      default: return `Item ${idx + 1}`;
    }
  };

  const getPrefix = () => {
    switch (activeSectionId) {
      case 'skills': return 'skill';
      case 'projects': return 'prj';
      case 'experience': return 'exp';
      case 'internship': return 'intern';
      case 'education': return 'edu';
      case 'certifications': return 'cert';
      case 'achievements': return 'ach';
      case 'claims': return 'claim';
      default: return 'item';
    }
  };

  const prefix = getPrefix();

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      
      {/* Top Navigation & Controls */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <button 
            onClick={onBack} 
            className="btn btn-secondary btn-sm"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}
          >
            <ArrowLeft size={14} /> Back to All Sections
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            {getSectionIcon(activeSectionId, 18)}
            <h3 style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0, textTransform: 'uppercase' }}>
              SECTION: {activeSectionId === 'claims' ? 'RESUME CLAIMS' : activeSectionId.toUpperCase()}
            </h3>
            <span className="badge badge-cyan" style={{ fontSize: '0.68rem' }}>
              {totalItems} {totalItems === 1 ? 'Item' : 'Items'}
            </span>
          </div>
        </div>

        {/* Explanation Depth Toggle (Beginner vs Deeper) */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', background: 'var(--bg-inset)', padding: '0.2rem', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
          <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', paddingLeft: '0.5rem' }}>Learning Level:</span>
          <button
            type="button"
            onClick={() => onToggleExplanationLevel('beginner')}
            style={{
              padding: '0.3rem 0.65rem',
              borderRadius: '6px',
              border: explanationLevel === 'beginner' ? '1px solid var(--accent-cyan)' : '1px solid transparent',
              background: explanationLevel === 'beginner' ? 'rgba(56, 189, 248, 0.15)' : 'transparent',
              color: explanationLevel === 'beginner' ? 'var(--accent-cyan)' : 'var(--text-muted)',
              fontSize: '0.72rem',
              fontWeight: 700,
              cursor: 'pointer'
            }}
          >
            Beginner Explanation
          </button>
          <button
            type="button"
            onClick={() => onToggleExplanationLevel('deeper')}
            style={{
              padding: '0.3rem 0.65rem',
              borderRadius: '6px',
              border: explanationLevel === 'deeper' ? '1px solid #34d399' : '1px solid transparent',
              background: explanationLevel === 'deeper' ? 'rgba(16, 185, 129, 0.15)' : 'transparent',
              color: explanationLevel === 'deeper' ? '#34d399' : 'var(--text-muted)',
              fontSize: '0.72rem',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.3rem'
            }}
          >
            <Flame size={12} color="#34d399" /> Deeper Technical
          </button>
        </div>
      </div>

      {/* Deeper Mode Banner */}
      {explanationLevel === 'deeper' && (
        <div style={{ padding: '0.75rem 1rem', borderRadius: '8px', background: 'linear-gradient(90deg, rgba(16, 185, 129, 0.1) 0%, rgba(56, 189, 248, 0.1) 100%)', border: '1px solid rgba(16, 185, 129, 0.3)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Cpu size={16} color="#34d399" />
            <span style={{ fontSize: '0.78rem', color: 'var(--text-primary)', fontWeight: 600 }}>
              ⚡ <strong>Deeper Technical Mastery Active:</strong> Low-level architecture, runtime mechanics, trade-offs, and interview defense strategies.
            </span>
          </div>
          <span className="badge badge-emerald" style={{ fontSize: '0.65rem' }}>
            Detailed Breakdown
          </span>
        </div>
      )}

      {/* Item Selector Tabs (if multiple items in section e.g. Skills or Projects) */}
      {totalItems > 1 && (
        <div style={{ display: 'flex', gap: '0.4rem', overflowX: 'auto', paddingBottom: '0.4rem' }}>
          {Array.from({ length: totalItems }).map((_, idx) => {
            const itKey = `${prefix}-${idx}`;
            const isRev = reviewedKeys.has(itKey);
            const isCur = activeItemIndex === idx;
            const label = getItemLabel(idx);

            return (
              <button
                key={idx}
                onClick={() => onSelectIndex(idx)}
                style={{
                  padding: '0.4rem 0.75rem',
                  borderRadius: '8px',
                  background: isCur ? 'rgba(56, 189, 248, 0.15)' : 'var(--bg-inset)',
                  border: isCur ? '1.5px solid var(--accent-cyan)' : '1px solid var(--border-subtle)',
                  color: isCur ? 'var(--accent-cyan)' : 'var(--text-secondary)',
                  fontSize: '0.76rem',
                  fontWeight: isCur ? 700 : 500,
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.4rem',
                  whiteSpace: 'nowrap',
                  flexShrink: 0
                }}
              >
                {isRev ? <CheckCircle2 size={12} color="#34d399" /> : <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: isCur ? 'var(--accent-cyan)' : 'var(--text-muted)' }} />}
                <span>{label}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* RENDER ACTIVE SECTION CARD */}
      {renderContent()}

      {/* Pagination Footer (if multiple items) */}
      {totalItems > 1 && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.75rem 0' }}>
          <button
            disabled={activeItemIndex === 0}
            onClick={() => onSelectIndex(Math.max(0, activeItemIndex - 1))}
            className="btn btn-secondary btn-sm"
            style={{ opacity: activeItemIndex === 0 ? 0.5 : 1 }}
          >
            <ChevronLeft size={14} /> Previous Item
          </button>

          <span style={{ fontSize: '0.76rem', color: 'var(--text-muted)' }}>
            Item {activeItemIndex + 1} of {totalItems}
          </span>

          <button
            disabled={activeItemIndex === totalItems - 1}
            onClick={() => onSelectIndex(Math.min(totalItems - 1, activeItemIndex + 1))}
            className="btn btn-secondary btn-sm"
            style={{ opacity: activeItemIndex === totalItems - 1 ? 0.5 : 1 }}
          >
            Next Item <ChevronRight size={14} />
          </button>
        </div>
      )}

    </div>
  );
};

/* =========================================================================
   EXPANDABLE DEEP DIVE TOPIC CARD COMPONENT
   ========================================================================= */

const DeepDiveTopicCard: React.FC<{
  topic: DeepDiveTopicDetail;
  defaultExpanded?: boolean;
}> = ({ topic, defaultExpanded = false }) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(defaultExpanded);

  return (
    <div 
      style={{ 
        borderRadius: '8px', 
        background: 'var(--bg-secondary)', 
        border: '1px solid var(--border-subtle)',
        overflow: 'hidden',
        transition: 'all 0.2s',
        boxShadow: 'var(--shadow-sm)'
      }}
    >
      <div 
        onClick={() => setIsExpanded(prev => !prev)}
        style={{
          padding: '0.75rem 1rem',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          cursor: 'pointer',
          background: isExpanded ? 'var(--bg-inset)' : 'transparent',
          borderBottom: isExpanded ? '1px solid var(--border-subtle)' : 'none'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <span style={{ color: 'var(--accent-cyan)', fontSize: '0.85rem' }}>▶</span>
          <strong style={{ fontSize: '0.84rem', color: 'var(--text-primary)' }}>
            {topic.title}
          </strong>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
            {isExpanded ? 'Collapse' : 'Deep Dive'}
          </span>
          {isExpanded ? <ChevronUp size={14} color="var(--accent-cyan)" /> : <ChevronDown size={14} color="var(--text-muted)" />}
        </div>
      </div>

      <div style={{ padding: '0.85rem 1rem' }}>
        <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.55, margin: 0 }}>
          {topic.summary}
        </p>

        {isExpanded && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem', marginTop: '0.85rem', paddingTop: '0.75rem', borderTop: '1px solid var(--border-subtle)' }}>
            {topic.architecture_mechanism && (
              <div style={{ padding: '0.65rem 0.85rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid var(--border-glass)' }}>
                <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--accent-cyan)', textTransform: 'uppercase', display: 'block', marginBottom: '0.2rem' }}>
                  ⚙️ Under-The-Hood Mechanism:
                </span>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-primary)', lineHeight: 1.5, margin: 0 }}>
                  {topic.architecture_mechanism}
                </p>
              </div>
            )}

            {topic.why_it_matters && (
              <div style={{ padding: '0.65rem 0.85rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid rgba(5, 150, 105, 0.25)' }}>
                <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--accent-emerald)', textTransform: 'uppercase', display: 'block', marginBottom: '0.2rem' }}>
                  🎯 Why It Matters in Production:
                </span>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.5, margin: 0 }}>
                  {topic.why_it_matters}
                </p>
              </div>
            )}

            {topic.interview_defense && (
              <div style={{ padding: '0.65rem 0.85rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid rgba(217, 119, 6, 0.25)' }}>
                <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--accent-amber)', textTransform: 'uppercase', display: 'block', marginBottom: '0.2rem' }}>
                  🗣️ Interview Talking Point (How to Answer):
                </span>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-primary)', fontStyle: 'italic', lineHeight: 1.5, margin: 0 }}>
                  "{topic.interview_defense}"
                </p>
              </div>
            )}

            {topic.common_pitfalls && (
              <div style={{ padding: '0.65rem 0.85rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid rgba(225, 29, 72, 0.25)' }}>
                <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--accent-rose)', textTransform: 'uppercase', display: 'block', marginBottom: '0.2rem' }}>
                  ⚠️ Common Pitfall to Avoid:
                </span>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.5, margin: 0 }}>
                  {topic.common_pitfalls}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

/* =========================================================================
   LINE-BY-LINE EXPLAINER CARD (FOR EVERY RESUME SUBSECTION)
   ========================================================================= */

const LineByLineExplainerCard: React.FC<{
  lines?: ResumeLearningLineBreakdown[];
  sectionTitle?: string;
}> = ({ lines, sectionTitle }) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(true);

  if (!lines || lines.length === 0) return null;

  return (
    <div style={{
      marginTop: '0.5rem',
      borderRadius: '10px',
      border: '1px solid var(--border-glass)',
      background: 'var(--bg-secondary)',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-sm)'
    }}>
      <div
        onClick={() => setIsExpanded(prev => !prev)}
        style={{
          padding: '0.85rem 1.15rem',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          cursor: 'pointer',
          background: 'var(--bg-inset)',
          borderBottom: isExpanded ? '1px solid var(--border-subtle)' : 'none',
          userSelect: 'none'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Sparkles size={16} color="var(--accent-cyan)" />
          <span style={{ fontSize: '0.78rem', fontWeight: 800, color: 'var(--text-primary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            {sectionTitle ? `${sectionTitle}: Line-By-Line Breakdown & Interview Guide` : 'Line-By-Line Breakdown & Interview Guide'}
          </span>
          <span className="badge badge-cyan" style={{ fontSize: '0.68rem', padding: '0.15rem 0.5rem' }}>
            {lines.length} Line{lines.length > 1 ? 's' : ''} Explained
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>
          <span>{isExpanded ? 'Collapse' : 'Expand All'}</span>
          {isExpanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
        </div>
      </div>

      {isExpanded && (
        <div style={{ padding: '1rem', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {lines.map((item, idx) => (
            <div
              key={idx}
              style={{
                borderRadius: '8px',
                background: 'var(--bg-card)',
                border: '1px solid var(--border-subtle)',
                padding: '0.9rem 1rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.55rem',
                boxShadow: 'var(--shadow-sm)'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
                <span style={{ fontSize: '0.72rem', fontWeight: 800, color: 'var(--accent-cyan)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                  {item.line_label || `Line ${idx + 1}`}
                </span>
                <span style={{ 
                  fontSize: '0.68rem', 
                  fontWeight: 700, 
                  color: 'var(--accent-emerald)', 
                  background: 'rgba(5, 150, 105, 0.1)', 
                  border: '1px solid rgba(5, 150, 105, 0.25)', 
                  padding: '0.2rem 0.55rem', 
                  borderRadius: '4px' 
                }}>
                  {item.what_it_demonstrates}
                </span>
              </div>

              <div style={{
                fontSize: '0.86rem',
                color: 'var(--text-primary)',
                fontWeight: 600,
                padding: '0.6rem 0.85rem',
                background: 'var(--bg-inset)',
                borderLeft: '3px solid var(--accent-cyan)',
                borderTop: '1px solid var(--border-subtle)',
                borderRight: '1px solid var(--border-subtle)',
                borderBottom: '1px solid var(--border-subtle)',
                borderRadius: '0 8px 8px 0',
                lineHeight: 1.5,
                fontStyle: 'italic'
              }}>
                "{item.raw_line}"
              </div>

              <div style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.55 }}>
                <strong style={{ color: 'var(--text-primary)' }}>💡 Plain-English Meaning:</strong> {item.brief_explanation}
              </div>

              <div style={{
                fontSize: '0.82rem',
                color: 'var(--text-primary)',
                background: 'var(--bg-inset)',
                padding: '0.6rem 0.85rem',
                borderRadius: '8px',
                border: '1px solid var(--border-glass)',
                lineHeight: 1.55
              }}>
                <strong style={{ color: 'var(--accent-cyan)', display: 'inline-flex', alignItems: 'center', gap: '0.3rem', marginRight: '0.35rem' }}>
                  🗣️ Interview Defense:
                </strong>
                <span style={{ color: 'var(--text-secondary)', fontStyle: 'italic' }}>
                  "{item.key_talking_point}"
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/* =========================================================================
   1. SUMMARY SECTION CARD
   ========================================================================= */

const SummarySectionCard: React.FC<{
  summary: ResumeLearningSummarySection;
  explanationLevel: 'beginner' | 'deeper';
  isReviewed: boolean;
  onToggleReviewed: () => void;
}> = ({ summary, explanationLevel, isReviewed, onToggleReviewed }) => (
  <div className="glass-card" style={{ padding: '1.75rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', paddingBottom: '1rem', borderBottom: '1px solid var(--border-subtle)' }}>
      <div>
        <span style={{ fontSize: '0.7rem', color: 'var(--accent-cyan)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          SECTION: SUMMARY
        </span>
        <h2 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)', marginTop: '0.2rem' }}>
          Professional Summary & Positioning
        </h2>
      </div>

      <button
        type="button"
        onClick={onToggleReviewed}
        className={`btn btn-sm ${isReviewed ? 'btn-emerald' : 'btn-secondary'}`}
        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
      >
        {isReviewed ? <><CheckCircle2 size={14} /> Reviewed & Understood ✓</> : <><Check size={14} /> Mark as Reviewed</>}
      </button>
    </div>

    {/* WHAT YOU WROTE */}
    <div style={{ background: 'var(--bg-inset)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid var(--border-glass)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.5rem' }}>
        <FileText size={14} color="var(--accent-cyan)" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: 'var(--accent-cyan)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          What You Wrote (Actual Resume Content)
        </span>
      </div>
      <div style={{ fontSize: '0.86rem', color: 'var(--text-primary)', lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
        {summary.what_you_wrote}
      </div>
    </div>

    {/* UNDERSTAND IT */}
    <div style={{ background: 'var(--bg-secondary)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.5rem' }}>
        <Sparkles size={14} color="#34d399" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#34d399', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Understand It ({explanationLevel === 'beginner' ? 'Beginner Explanation' : 'Deeper Technical Positioning'})
        </span>
      </div>
      <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
        {explanationLevel === 'beginner' ? summary.beginner_explanation || summary.understand_it : summary.deeper_explanation || summary.understand_it}
      </p>
    </div>

    {/* LINE-BY-LINE BREAKDOWN & INTERVIEW GUIDE */}
    <LineByLineExplainerCard lines={summary.line_by_line_breakdown} sectionTitle="Professional Summary" />

    {/* KEY THINGS TO KNOW & DEEP TOPICS */}
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.75rem' }}>
        <HelpCircle size={15} color="#f59e0b" />
        <span style={{ fontSize: '0.76rem', fontWeight: 800, color: '#f59e0b', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Key Things To Know
        </span>
      </div>

      {explanationLevel === 'deeper' && summary.deeper_positioning_topics && summary.deeper_positioning_topics.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
          {summary.deeper_positioning_topics.map((top, idx) => (
            <DeepDiveTopicCard key={idx} topic={top} defaultExpanded={idx === 0} />
          ))}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          {summary.key_things_to_know.map((point, idx) => (
            <div key={idx} style={{ padding: '0.65rem 0.85rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'flex-start', gap: '0.5rem' }}>
              <span style={{ color: 'var(--accent-cyan)', fontWeight: 700, fontSize: '0.8rem' }}>▶</span>
              <span style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
                {point}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>

    {/* WHY IT MATTERS & WHAT YOU SHOULD BE ABLE TO EXPLAIN */}
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
      <div style={{ padding: '1rem', borderRadius: '8px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)' }}>
        <h4 style={{ fontSize: '0.78rem', fontWeight: 700, color: '#38bdf8', marginBottom: '0.4rem' }}>
          🎯 Why It Matters
        </h4>
        <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: 1.5, margin: 0 }}>
          {summary.why_it_matters}
        </p>
      </div>

      <div style={{ padding: '1rem', borderRadius: '8px', background: 'var(--bg-inset)', border: '1px solid var(--border-glass)' }}>
        <h4 style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--accent-cyan)', marginBottom: '0.4rem' }}>
          🗣️ What You Should Be Able To Explain (Elevator Pitch)
        </h4>
        <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: 1.5, margin: 0 }}>
          {summary.what_you_should_explain}
        </p>
      </div>
    </div>
  </div>
);

/* =========================================================================
   2. SKILLS SECTION CARD (WITH EXTENSIVE DEEP TOPIC ELABORATION)
   ========================================================================= */

const SkillSectionCard: React.FC<{
  skill: ResumeLearningSkillItem;
  explanationLevel: 'beginner' | 'deeper';
  isReviewed: boolean;
  onToggleReviewed: () => void;
}> = ({ skill, explanationLevel, isReviewed, onToggleReviewed }) => (
  <div className="glass-card" style={{ padding: '1.75rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', paddingBottom: '1rem', borderBottom: '1px solid var(--border-subtle)' }}>
      <div>
        <span style={{ fontSize: '0.7rem', color: '#34d399', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          SECTION: SKILLS
        </span>
        <h2 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)', marginTop: '0.2rem', textTransform: 'uppercase' }}>
          {skill.skill_name}
        </h2>
      </div>

      <button
        type="button"
        onClick={onToggleReviewed}
        className={`btn btn-sm ${isReviewed ? 'btn-emerald' : 'btn-secondary'}`}
        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
      >
        {isReviewed ? <><CheckCircle2 size={14} /> Reviewed & Understood ✓</> : <><Check size={14} /> Mark as Reviewed</>}
      </button>
    </div>

    {/* WHAT YOU WROTE */}
    <div style={{ background: 'var(--bg-inset)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid rgba(16, 185, 129, 0.3)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
        <FileText size={14} color="#34d399" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#34d399', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          What You Wrote (Exact Resume Entry)
        </span>
      </div>
      <div style={{ fontSize: '0.86rem', color: 'var(--text-primary)', fontWeight: 600 }}>
        Listed under Skills on your resume: <span style={{ color: 'var(--accent-cyan)' }}>"{skill.skill_name}"</span>
      </div>
    </div>

    {/* UNDERSTAND IT */}
    <div style={{ background: 'var(--bg-secondary)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.5rem' }}>
        <Sparkles size={14} color="#34d399" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#34d399', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Understand It ({explanationLevel === 'beginner' ? 'Beginner Explanation' : 'Deeper Technical Architecture'})
        </span>
      </div>
      <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
        {explanationLevel === 'beginner' ? skill.beginner_explanation || skill.what_it_is : skill.deeper_explanation || skill.what_it_is}
      </p>
    </div>

    {/* ARCHITECTURE RUNTIME MECHANICS (DEEPER MODE ONLY) */}
    {explanationLevel === 'deeper' && skill.architecture_breakdown && (
      <div style={{ padding: '1.1rem 1.25rem', borderRadius: '10px', background: 'var(--bg-inset)', border: '1px solid var(--border-glass)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', marginBottom: '0.4rem' }}>
          <Cpu size={15} color="var(--accent-cyan)" />
          <h4 style={{ fontSize: '0.78rem', fontWeight: 800, color: 'var(--accent-cyan)', margin: 0, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            Runtime & Internal Architecture Breakdown
          </h4>
        </div>
        <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
          {skill.architecture_breakdown}
        </p>
      </div>
    )}

    {/* WHAT IT IS & WHAT IT IS USED FOR */}
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
      <div style={{ padding: '1rem', borderRadius: '8px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)' }}>
        <h4 style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.4rem' }}>
          💡 What It Is
        </h4>
        <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: 1.5, margin: 0 }}>
          {skill.what_it_is}
        </p>
      </div>

      <div style={{ padding: '1rem', borderRadius: '8px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)' }}>
        <h4 style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.4rem' }}>
          🛠️ What It Is Used For
        </h4>
        <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: 1.5, margin: 0 }}>
          {skill.what_it_is_used_for}
        </p>
      </div>

      <div style={{ padding: '1rem', borderRadius: '8px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)' }}>
        <h4 style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--accent-cyan)', marginBottom: '0.4rem' }}>
          📋 What It Means On Your Resume
        </h4>
        <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: 1.5, margin: 0 }}>
          {skill.what_it_means_on_resume}
        </p>
      </div>
    </div>

    {/* WHAT YOU SHOULD KNOW (WITH EXTENSIVE DEEP TOPIC ELABORATION) */}
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <HelpCircle size={15} color="#f59e0b" />
          <span style={{ fontSize: '0.76rem', fontWeight: 800, color: '#f59e0b', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            What You Should Know (Fundamental to Advanced Concepts)
          </span>
        </div>
        {explanationLevel === 'deeper' && (
          <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
            Click topics to expand deep mechanisms & interview defense
          </span>
        )}
      </div>

      {explanationLevel === 'deeper' && skill.deeper_topics && skill.deeper_topics.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {skill.deeper_topics.map((topic, idx) => (
            <DeepDiveTopicCard key={idx} topic={topic} defaultExpanded={idx === 0} />
          ))}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          {skill.what_you_should_know.map((point, idx) => (
            <div key={idx} style={{ padding: '0.65rem 0.85rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'flex-start', gap: '0.5rem' }}>
              <span style={{ color: '#34d399', fontWeight: 700, fontSize: '0.8rem' }}>▶</span>
              <span style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
                {point}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>

    {/* TRADE-OFFS & PITFALLS (DEEPER MODE ONLY) */}
    {explanationLevel === 'deeper' && skill.trade_offs_and_pitfalls && skill.trade_offs_and_pitfalls.length > 0 && (
      <div style={{ padding: '1rem 1.25rem', borderRadius: '10px', background: 'rgba(244, 63, 94, 0.03)', border: '1px solid rgba(244, 63, 94, 0.2)' }}>
        <h4 style={{ fontSize: '0.78rem', fontWeight: 800, color: '#fb7185', marginBottom: '0.4rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          ⚖️ Engineering Trade-Offs & Pitfalls to Defend
        </h4>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
          {skill.trade_offs_and_pitfalls.map((t, idx) => (
            <p key={idx} style={{ fontSize: '0.8rem', color: '#fecdd3', margin: 0, lineHeight: 1.5 }}>
              • {t}
            </p>
          ))}
        </div>
      </div>
    )}

    {/* LINE-BY-LINE BREAKDOWN & INTERVIEW GUIDE */}
    <LineByLineExplainerCard lines={skill.line_by_line_breakdown} sectionTitle="Skill" />

    {/* HOW TO EXPLAIN IT */}
    <div style={{ padding: '1.1rem 1.25rem', borderRadius: '10px', background: 'var(--bg-inset)', border: '1px solid var(--border-glass)' }}>
      <h4 style={{ fontSize: '0.78rem', fontWeight: 800, color: 'var(--accent-cyan)', marginBottom: '0.4rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
        💬 How To Explain It (Spoken Interview Talking Point)
      </h4>
      <p style={{ fontSize: '0.84rem', color: 'var(--text-primary)', fontStyle: 'italic', lineHeight: 1.6, margin: 0 }}>
        "{skill.how_to_explain_it}"
      </p>
    </div>
  </div>
);

/* =========================================================================
   3. PROJECTS SECTION CARD (WITH EXTENSIVE DEEP TOPIC ELABORATION)
   ========================================================================= */

const ProjectSectionCard: React.FC<{
  project: ResumeLearningProjectItem;
  explanationLevel: 'beginner' | 'deeper';
  isReviewed: boolean;
  onToggleReviewed: () => void;
}> = ({ project, explanationLevel, isReviewed, onToggleReviewed }) => (
  <div className="glass-card" style={{ padding: '1.75rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', paddingBottom: '1rem', borderBottom: '1px solid var(--border-subtle)' }}>
      <div>
        <span style={{ fontSize: '0.7rem', color: '#f59e0b', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          SECTION: PROJECTS
        </span>
        <h2 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)', marginTop: '0.2rem' }}>
          {project.project_name}
        </h2>
      </div>

      <button
        type="button"
        onClick={onToggleReviewed}
        className={`btn btn-sm ${isReviewed ? 'btn-emerald' : 'btn-secondary'}`}
        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
      >
        {isReviewed ? <><CheckCircle2 size={14} /> Reviewed & Understood ✓</> : <><Check size={14} /> Mark as Reviewed</>}
      </button>
    </div>

    {/* WHAT YOU WROTE */}
    <div style={{ background: 'var(--bg-inset)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid rgba(245, 158, 11, 0.35)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.5rem' }}>
        <FileText size={14} color="#f59e0b" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#f59e0b', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          What You Wrote (Actual Project Content)
        </span>
      </div>
      <div style={{ fontSize: '0.86rem', color: 'var(--text-primary)', lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
        {project.what_you_wrote}
      </div>
    </div>

    {/* UNDERSTAND IT / PROJECT EXPLANATION */}
    <div style={{ background: 'var(--bg-secondary)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.5rem' }}>
        <Sparkles size={14} color="#34d399" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#34d399', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Project Explanation ({explanationLevel === 'beginner' ? 'Beginner Overview' : 'Deeper System Evaluation'})
        </span>
      </div>
      <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
        {explanationLevel === 'beginner' ? project.beginner_explanation || project.project_explanation : project.deeper_explanation || project.project_explanation}
      </p>
    </div>

    {/* SYSTEM ARCHITECTURE BLUEPRINT (DEEPER MODE ONLY) */}
    {explanationLevel === 'deeper' && project.system_architecture && (
      <div style={{ padding: '1.1rem 1.25rem', borderRadius: '10px', background: 'var(--bg-inset)', border: '1px solid rgba(245, 158, 11, 0.35)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', marginBottom: '0.4rem' }}>
          <Server size={15} color="#f59e0b" />
          <h4 style={{ fontSize: '0.78rem', fontWeight: 800, color: '#f59e0b', margin: 0, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            System Architecture Blueprint
          </h4>
        </div>
        <p style={{ fontSize: '0.82rem', color: 'var(--text-primary)', fontFamily: 'monospace', lineHeight: 1.6, margin: 0 }}>
          {project.system_architecture}
        </p>
      </div>
    )}

    {/* TECHNOLOGIES MENTIONED (ONLY FROM RESUME) */}
    {project.technologies_mentioned && project.technologies_mentioned.length > 0 && (
      <div>
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: 'var(--text-muted)', textTransform: 'uppercase', display: 'block', marginBottom: '0.4rem' }}>
          Technologies Verified On Resume:
        </span>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
          {project.technologies_mentioned.map((t, idx) => (
            <span key={idx} className="badge badge-cyan" style={{ fontSize: '0.72rem' }}>
              {t}
            </span>
          ))}
        </div>
      </div>
    )}

    {/* YOUR CONTRIBUTION */}
    <div style={{ padding: '1rem 1.25rem', borderRadius: '8px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)' }}>
      <h4 style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--accent-cyan)', marginBottom: '0.4rem' }}>
        👤 Your Contribution (Stated in Resume)
      </h4>
      <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.5, margin: 0 }}>
        {project.your_contribution}
      </p>
    </div>

    {/* CONCEPTS TO UNDERSTAND (EXPANDABLE IN DEEPER MODE) */}
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <HelpCircle size={14} color="#f59e0b" />
          <span style={{ fontSize: '0.74rem', fontWeight: 800, color: '#f59e0b', textTransform: 'uppercase' }}>
            Concepts To Understand & System Design
          </span>
        </div>
        {explanationLevel === 'deeper' && (
          <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
            Expand topics for mechanisms & edge cases
          </span>
        )}
      </div>

      {explanationLevel === 'deeper' && project.deeper_concepts && project.deeper_concepts.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {project.deeper_concepts.map((c, idx) => (
            <DeepDiveTopicCard key={idx} topic={c} defaultExpanded={idx === 0} />
          ))}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
          {project.concepts_to_understand.map((c, idx) => (
            <div key={idx} style={{ padding: '0.65rem 0.85rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)', fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
              ▶ {c}
            </div>
          ))}
        </div>
      )}
    </div>

    {/* WHAT YOU SHOULD KNOW & BE PREPARED TO DEFEND */}
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <HelpCircle size={14} color="var(--accent-cyan)" />
          <span style={{ fontSize: '0.74rem', fontWeight: 800, color: 'var(--accent-cyan)', textTransform: 'uppercase' }}>
            What You Should Know & Be Prepared To Defend (Scaling & Trade-offs)
          </span>
        </div>
      </div>

      {explanationLevel === 'deeper' && project.deeper_defense_points && project.deeper_defense_points.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {project.deeper_defense_points.map((p, idx) => (
            <DeepDiveTopicCard key={idx} topic={p} defaultExpanded={idx === 0} />
          ))}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
          {project.what_you_should_know.map((k, idx) => (
            <div key={idx} style={{ padding: '0.65rem 0.85rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid var(--border-glass)', fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
              ▶ {k}
            </div>
          ))}
        </div>
      )}
    </div>

    {/* LINE-BY-LINE BREAKDOWN & INTERVIEW GUIDE */}
    <LineByLineExplainerCard lines={project.line_by_line_breakdown} sectionTitle="Project" />
  </div>
);

/* =========================================================================
   4. EXPERIENCE / INTERNSHIP SECTION CARD
   ========================================================================= */

const ExperienceSectionCard: React.FC<{
  exp: ResumeLearningExperienceItem;
  explanationLevel: 'beginner' | 'deeper';
  isReviewed: boolean;
  onToggleReviewed: () => void;
}> = ({ exp, explanationLevel, isReviewed, onToggleReviewed }) => (
  <div className="glass-card" style={{ padding: '1.75rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', paddingBottom: '1rem', borderBottom: '1px solid var(--border-subtle)' }}>
      <div>
        <span style={{ fontSize: '0.7rem', color: exp.is_internship ? '#a78bfa' : '#60a5fa', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          SECTION: {exp.is_internship ? 'INTERNSHIP' : 'EXPERIENCE'}
        </span>
        <h2 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)', marginTop: '0.2rem' }}>
          {exp.role}
        </h2>
        <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
          {exp.company} {exp.dates ? `• ${exp.dates}` : ''}
        </p>
      </div>

      <button
        type="button"
        onClick={onToggleReviewed}
        className={`btn btn-sm ${isReviewed ? 'btn-emerald' : 'btn-secondary'}`}
        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
      >
        {isReviewed ? <><CheckCircle2 size={14} /> Reviewed & Understood ✓</> : <><Check size={14} /> Mark as Reviewed</>}
      </button>
    </div>

    {/* WHAT YOU WROTE / DESCRIPTION */}
    <div style={{ background: 'var(--bg-inset)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid var(--border-glass)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.5rem' }}>
        <FileText size={14} color="#60a5fa" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#60a5fa', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          What You Wrote (Actual Experience Entry)
        </span>
      </div>
      <div style={{ fontSize: '0.86rem', color: 'var(--text-primary)', lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
        {exp.description}
      </div>
    </div>

    {/* WHAT YOU CLAIMED */}
    <div style={{ background: 'var(--bg-secondary)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
        <Sparkles size={14} color="#34d399" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#34d399', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          What You Claimed
        </span>
      </div>
      <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
        {explanationLevel === 'beginner' ? exp.beginner_explanation || exp.what_you_claimed : exp.deeper_explanation || exp.what_you_claimed}
      </p>
    </div>

    {/* SKILLS DEMONSTRATED & IMPORTANT TERMINOLOGY */}
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
      {exp.skills_demonstrated && exp.skills_demonstrated.length > 0 && (
        <div style={{ padding: '1rem', borderRadius: '8px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)' }}>
          <h4 style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--accent-cyan)', marginBottom: '0.5rem' }}>
            🛠️ Skills Demonstrated (Supported by Resume)
          </h4>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
            {exp.skills_demonstrated.map((s, idx) => (
              <span key={idx} className="badge badge-secondary" style={{ fontSize: '0.7rem' }}>
                {s}
              </span>
            ))}
          </div>
        </div>
      )}

      {exp.important_terminology && exp.important_terminology.length > 0 && (
        <div style={{ padding: '1rem', borderRadius: '8px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)' }}>
          <h4 style={{ fontSize: '0.78rem', fontWeight: 700, color: '#fbbf24', marginBottom: '0.5rem' }}>
            📖 Important Terminology
          </h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
            {exp.important_terminology.map((t, idx) => (
              <div key={idx} style={{ fontSize: '0.78rem', lineHeight: 1.4 }}>
                <strong style={{ color: 'var(--text-primary)' }}>{t.term}:</strong>{' '}
                <span style={{ color: 'var(--text-secondary)' }}>{t.definition}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>

    {/* WHAT YOU SHOULD UNDERSTAND */}
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.75rem' }}>
        <HelpCircle size={15} color="#f59e0b" />
        <span style={{ fontSize: '0.76rem', fontWeight: 800, color: '#f59e0b', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          What You Should Understand About This Experience
        </span>
      </div>

      {explanationLevel === 'deeper' && exp.deeper_learnings && exp.deeper_learnings.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {exp.deeper_learnings.map((top, idx) => (
            <DeepDiveTopicCard key={idx} topic={top} defaultExpanded={idx === 0} />
          ))}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          {exp.what_you_should_understand.map((point, idx) => (
            <div key={idx} style={{ padding: '0.65rem 0.85rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'flex-start', gap: '0.5rem' }}>
              <span style={{ color: 'var(--accent-cyan)', fontWeight: 700, fontSize: '0.8rem' }}>▶</span>
              <span style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
                {point}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>

    {/* LINE-BY-LINE BREAKDOWN & INTERVIEW GUIDE */}
    <LineByLineExplainerCard lines={exp.line_by_line_breakdown} sectionTitle={exp.is_internship ? 'Internship' : 'Experience'} />
  </div>
);

/* =========================================================================
   5. EDUCATION SECTION CARD
   ========================================================================= */

const EducationSectionCard: React.FC<{
  edu: ResumeLearningEducationItem;
  explanationLevel: 'beginner' | 'deeper';
  isReviewed: boolean;
  onToggleReviewed: () => void;
}> = ({ edu, explanationLevel, isReviewed, onToggleReviewed }) => (
  <div className="glass-card" style={{ padding: '1.75rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', paddingBottom: '1rem', borderBottom: '1px solid var(--border-subtle)' }}>
      <div>
        <span style={{ fontSize: '0.7rem', color: '#ec4899', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          SECTION: EDUCATION
        </span>
        <h2 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)', marginTop: '0.2rem' }}>
          {edu.degree}
        </h2>
        <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
          {edu.institution} {edu.dates_or_grade ? `• ${edu.dates_or_grade}` : ''}
        </p>
      </div>

      <button
        type="button"
        onClick={onToggleReviewed}
        className={`btn btn-sm ${isReviewed ? 'btn-emerald' : 'btn-secondary'}`}
        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
      >
        {isReviewed ? <><CheckCircle2 size={14} /> Reviewed & Understood ✓</> : <><Check size={14} /> Mark as Reviewed</>}
      </button>
    </div>

    {/* WHAT YOU WROTE */}
    <div style={{ background: 'var(--bg-inset)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid rgba(236, 72, 153, 0.35)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
        <FileText size={14} color="#ec4899" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#ec4899', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          What You Wrote (Academic Credential)
        </span>
      </div>
      <div style={{ fontSize: '0.86rem', color: 'var(--text-primary)', fontWeight: 600 }}>
        {edu.degree} from {edu.institution} {edu.dates_or_grade ? `(${edu.dates_or_grade})` : ''}
      </div>
    </div>

    {/* WHAT IT DEMONSTRATES */}
    <div style={{ background: 'var(--bg-secondary)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
        <Sparkles size={14} color="#34d399" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#34d399', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          What It Demonstrates
        </span>
      </div>
      <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
        {edu.what_it_demonstrates}
      </p>
    </div>

    {/* RELEVANT COURSEWORK (IF PRESENT) */}
    {edu.relevant_coursework && edu.relevant_coursework.length > 0 && (
      <div>
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: 'var(--text-muted)', textTransform: 'uppercase', display: 'block', marginBottom: '0.4rem' }}>
          Relevant Coursework Listed on Resume:
        </span>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
          {edu.relevant_coursework.map((c, idx) => (
            <span key={idx} className="badge badge-cyan" style={{ fontSize: '0.7rem' }}>
              {c}
            </span>
          ))}
        </div>
      </div>
    )}

    {/* KEY CONCEPTS */}
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.6rem' }}>
        <HelpCircle size={14} color="#f59e0b" />
        <span style={{ fontSize: '0.74rem', fontWeight: 800, color: '#f59e0b', textTransform: 'uppercase' }}>
          {edu.key_concepts_title || 'Academic Core Concepts & Foundational Principles'}
        </span>
      </div>

      {explanationLevel === 'deeper' && edu.deeper_foundations && edu.deeper_foundations.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {edu.deeper_foundations.map((f, idx) => (
            <DeepDiveTopicCard key={idx} topic={f} defaultExpanded={true} />
          ))}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
          {edu.key_concepts.map((k, idx) => (
            <div key={idx} style={{ padding: '0.6rem 0.75rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)', fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: 1.4 }}>
              ▶ {k}
            </div>
          ))}
        </div>
      )}
    </div>

    {/* LINE-BY-LINE BREAKDOWN & INTERVIEW GUIDE */}
    <LineByLineExplainerCard lines={edu.line_by_line_breakdown} sectionTitle="Education" />
  </div>
);

/* =========================================================================
   6. CERTIFICATIONS SECTION CARD
   ========================================================================= */

const CertificationSectionCard: React.FC<{
  cert: ResumeLearningCertificationItem;
  explanationLevel: 'beginner' | 'deeper';
  isReviewed: boolean;
  onToggleReviewed: () => void;
}> = ({ cert, explanationLevel, isReviewed, onToggleReviewed }) => (
  <div className="glass-card" style={{ padding: '1.75rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', paddingBottom: '1rem', borderBottom: '1px solid var(--border-subtle)' }}>
      <div>
        <span style={{ fontSize: '0.7rem', color: '#38bdf8', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          SECTION: CERTIFICATIONS
        </span>
        <h2 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)', marginTop: '0.2rem' }}>
          {cert.name}
        </h2>
        {cert.issuer && (
          <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
            Issuer: {cert.issuer}
          </p>
        )}
      </div>

      <button
        type="button"
        onClick={onToggleReviewed}
        className={`btn btn-sm ${isReviewed ? 'btn-emerald' : 'btn-secondary'}`}
        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
      >
        {isReviewed ? <><CheckCircle2 size={14} /> Reviewed & Understood ✓</> : <><Check size={14} /> Mark as Reviewed</>}
      </button>
    </div>

    {/* WHAT THE CERTIFICATION REPRESENTS */}
    <div style={{ background: 'var(--bg-secondary)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
        <Sparkles size={14} color="#38bdf8" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#38bdf8', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          What The Certification Represents
        </span>
      </div>
      <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
        {cert.what_it_represents}
      </p>
    </div>

    {/* KNOWLEDGE GENERALLY COVERED & IMPORTANT CONCEPTS */}
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
      <div>
        <h4 style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.4rem' }}>
          📚 What Knowledge It Generally Covers
        </h4>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
          {cert.knowledge_covered.map((k, idx) => (
            <div key={idx} style={{ padding: '0.55rem 0.75rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
              • {k}
            </div>
          ))}
        </div>
      </div>

      <div>
        <h4 style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--accent-cyan)', marginBottom: '0.4rem' }}>
          💡 Important Concepts Associated With It
        </h4>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
          {cert.important_concepts.map((c, idx) => (
            <div key={idx} style={{ padding: '0.55rem 0.75rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid var(--border-glass)', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
              • {c}
            </div>
          ))}
        </div>
      </div>
    </div>

    {/* DEEPER STANDARDS TOPICS */}
    {explanationLevel === 'deeper' && cert.deeper_standards && cert.deeper_standards.length > 0 && (
      <div>
        <h4 style={{ fontSize: '0.78rem', fontWeight: 800, color: 'var(--accent-cyan)', marginBottom: '0.5rem', textTransform: 'uppercase' }}>
          Standardized Industry Competencies
        </h4>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
          {cert.deeper_standards.map((s, idx) => (
            <DeepDiveTopicCard key={idx} topic={s} defaultExpanded={true} />
          ))}
        </div>
      </div>
    )}

    {/* WHAT YOU SHOULD UNDERSTAND */}
    <div style={{ padding: '1.1rem 1.25rem', borderRadius: '10px', background: 'var(--bg-inset)', border: '1px solid var(--border-glass)' }}>
      <h4 style={{ fontSize: '0.78rem', fontWeight: 800, color: 'var(--accent-cyan)', marginBottom: '0.4rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
        🎯 What You Should Understand About This Certification
      </h4>
      <p style={{ fontSize: '0.84rem', color: 'var(--text-secondary)', lineHeight: 1.5, margin: 0 }}>
        {cert.what_you_should_understand}
      </p>
    </div>

    {/* LINE-BY-LINE BREAKDOWN & INTERVIEW GUIDE */}
    <LineByLineExplainerCard lines={cert.line_by_line_breakdown} sectionTitle="Certification" />
  </div>
);

/* =========================================================================
   7. ACHIEVEMENTS SECTION CARD
   ========================================================================= */

const AchievementSectionCard: React.FC<{
  ach: ResumeLearningAchievementItem;
  explanationLevel: 'beginner' | 'deeper';
  isReviewed: boolean;
  onToggleReviewed: () => void;
}> = ({ ach, explanationLevel, isReviewed, onToggleReviewed }) => (
  <div className="glass-card" style={{ padding: '1.75rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', paddingBottom: '1rem', borderBottom: '1px solid var(--border-subtle)' }}>
      <div>
        <span style={{ fontSize: '0.7rem', color: '#eab308', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          SECTION: ACHIEVEMENTS
        </span>
        <h2 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)', marginTop: '0.2rem' }}>
          {ach.title}
        </h2>
      </div>

      <button
        type="button"
        onClick={onToggleReviewed}
        className={`btn btn-sm ${isReviewed ? 'btn-emerald' : 'btn-secondary'}`}
        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
      >
        {isReviewed ? <><CheckCircle2 size={14} /> Reviewed & Understood ✓</> : <><Check size={14} /> Mark as Reviewed</>}
      </button>
    </div>

    {/* WHAT YOU WROTE */}
    <div style={{ background: 'var(--bg-inset)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid rgba(234, 179, 8, 0.35)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
        <Trophy size={14} color="#eab308" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#eab308', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          What You Wrote (Actual Achievement from Resume)
        </span>
      </div>
      <div style={{ fontSize: '0.86rem', color: 'var(--text-primary)', lineHeight: 1.6 }}>
        {ach.what_you_wrote}
      </div>
    </div>

    {/* UNDERSTAND IT */}
    <div style={{ background: 'var(--bg-secondary)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
        <Sparkles size={14} color="#34d399" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#34d399', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Understand It
        </span>
      </div>
      <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
        {explanationLevel === 'beginner' ? ach.beginner_explanation || ach.understand_it : ach.deeper_explanation || ach.understand_it}
      </p>
    </div>

    {/* DEEPER CONTEXT */}
    {explanationLevel === 'deeper' && ach.deeper_context && ach.deeper_context.length > 0 && (
      <div>
        <h4 style={{ fontSize: '0.78rem', fontWeight: 800, color: '#fbbf24', marginBottom: '0.5rem', textTransform: 'uppercase' }}>
          Competitive Differentiation
        </h4>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
          {ach.deeper_context.map((d, idx) => (
            <DeepDiveTopicCard key={idx} topic={d} defaultExpanded={true} />
          ))}
        </div>
      </div>
    )}

    {/* WHY IT MATTERS */}
    <div style={{ padding: '1rem', borderRadius: '8px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)' }}>
      <h4 style={{ fontSize: '0.78rem', fontWeight: 700, color: '#38bdf8', marginBottom: '0.4rem' }}>
        🎯 Why It Matters
      </h4>
      <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: 1.5, margin: 0 }}>
        {ach.why_it_matters}
      </p>
    </div>

    {/* WHAT YOU SHOULD BE ABLE TO EXPLAIN */}
    {ach.what_you_should_explain && ach.what_you_should_explain.length > 0 && (
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.6rem' }}>
          <HelpCircle size={14} color="#f59e0b" />
          <span style={{ fontSize: '0.74rem', fontWeight: 800, color: '#f59e0b', textTransform: 'uppercase' }}>
            What You Should Be Able To Explain
          </span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
          {ach.what_you_should_explain.map((p, idx) => (
            <div key={idx} style={{ padding: '0.6rem 0.75rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid var(--border-glass)', fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: 1.4 }}>
              ▶ {p}
            </div>
          ))}
        </div>
      </div>
    )}

    {/* LINE-BY-LINE BREAKDOWN & INTERVIEW GUIDE */}
    <LineByLineExplainerCard lines={ach.line_by_line_breakdown} sectionTitle="Achievement" />
  </div>
);

/* =========================================================================
   8. CLAIMS SECTION CARD (WITH EXTENSIVE DEEP DIVE ELABORATION)
   ========================================================================= */

const ClaimSectionCard: React.FC<{
  claim: ResumeLearningClaimItem;
  explanationLevel: 'beginner' | 'deeper';
  isReviewed: boolean;
  onToggleReviewed: () => void;
}> = ({ claim, explanationLevel, isReviewed, onToggleReviewed }) => (
  <div className="glass-card" style={{ padding: '1.75rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', paddingBottom: '1rem', borderBottom: '1px solid var(--border-subtle)' }}>
      <div>
        <span style={{ fontSize: '0.7rem', color: '#fbbf24', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          SECTION: RESUME CLAIMS
        </span>
        <h2 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)', marginTop: '0.2rem' }}>
          Resume Claim Reflection
        </h2>
        <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
          Source: {claim.source_section}
        </p>
      </div>

      <button
        type="button"
        onClick={onToggleReviewed}
        className={`btn btn-sm ${isReviewed ? 'btn-emerald' : 'btn-secondary'}`}
        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
      >
        {isReviewed ? <><CheckCircle2 size={14} /> Reviewed & Understood ✓</> : <><Check size={14} /> Mark as Reviewed</>}
      </button>
    </div>

    {/* CLAIM (WHAT YOU WROTE) */}
    <div style={{ background: 'var(--bg-inset)', padding: '1.1rem 1.25rem', borderRadius: '10px', border: '1px solid rgba(251, 191, 36, 0.35)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
        <FileText size={14} color="#fbbf24" />
        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#fbbf24', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Claim Stated On Your Resume
        </span>
      </div>
      <div style={{ fontSize: '0.92rem', color: 'var(--text-primary)', fontWeight: 600, fontStyle: 'italic', lineHeight: 1.6 }}>
        "{claim.claim_text}"
      </div>
    </div>

    {/* WHAT YOU SHOULD UNDERSTAND (NO HALLUCINATIONS / DIRECT REFLECTION) */}
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.75rem' }}>
        <HelpCircle size={15} color="#34d399" />
        <span style={{ fontSize: '0.76rem', fontWeight: 800, color: '#34d399', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          What You Should Understand & Be Prepared To Answer About This Claim:
        </span>
      </div>

      {explanationLevel === 'deeper' && claim.deeper_claim_breakdown && claim.deeper_claim_breakdown.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '0.75rem' }}>
          {claim.deeper_claim_breakdown.map((b, idx) => (
            <DeepDiveTopicCard key={idx} topic={b} defaultExpanded={true} />
          ))}
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        {claim.what_you_should_understand.map((question, idx) => (
          <div key={idx} style={{ padding: '0.75rem 0.9rem', borderRadius: '6px', background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'flex-start', gap: '0.5rem' }}>
            <span style={{ color: 'var(--accent-cyan)', fontWeight: 700, fontSize: '0.85rem' }}>•</span>
            <span style={{ fontSize: '0.84rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
              {question}
            </span>
          </div>
        ))}
      </div>
    </div>

    <div style={{ padding: '0.8rem 1rem', borderRadius: '8px', background: 'var(--bg-inset)', border: '1px dashed var(--border-subtle)' }}>
      <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: 0 }}>
        💡 <strong>Interview Tip:</strong> When interviewers ask about this point, walk through your exact technical choices, baseline metrics, and the specific hurdles you solved.
      </p>
    </div>
  </div>
);
