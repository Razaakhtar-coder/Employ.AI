from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user
from app.models.user import User
from app.models.profile import IndustryProfile
from app.models.opportunity import Opportunity, OpportunitySkill
from app.models.taxonomy import Skill
from app.schemas.opportunity import (
    OpportunityCreate, OpportunityResponse, CandidateMatchCard, OpportunitySkillItem
)
from app.schemas.analytics import RecruiterDashboardStats
from app.services.industry_service import IndustryService

router = APIRouter(prefix="/industry", tags=["Industry & Recruiters"])


@router.get("/dashboard", response_model=RecruiterDashboardStats)
def get_recruiter_dashboard_stats(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieve recruiter dashboard metrics."""
    ind_profile = db.query(IndustryProfile).filter(IndustryProfile.user_id == current_user.id).first()
    if not ind_profile:
        ind_profile = IndustryProfile(user_id=current_user.id, company_name="Enterprise Recruiter")
        db.add(ind_profile)
        db.commit()
        db.refresh(ind_profile)

    return IndustryService.get_recruiter_stats(db, ind_profile)


@router.post("/opportunities", response_model=OpportunityResponse, status_code=status.HTTP_201_CREATED)
def post_new_opportunity(
    data: OpportunityCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Recruiter creates a new internship or job opportunity."""
    ind_profile = db.query(IndustryProfile).filter(IndustryProfile.user_id == current_user.id).first()
    if not ind_profile:
        ind_profile = IndustryProfile(user_id=current_user.id, company_name="Enterprise Recruiter")
        db.add(ind_profile)
        db.commit()
        db.refresh(ind_profile)

    opp = IndustryService.create_opportunity(db, ind_profile, current_user.id, data)

    opp_skills = db.query(OpportunitySkill).filter(OpportunitySkill.opportunity_id == opp.id).all()
    skill_items = []
    for os in opp_skills:
        sk = db.query(Skill).filter(Skill.id == os.skill_id).first()
        if sk:
            skill_items.append(OpportunitySkillItem(
                skill_id=sk.id,
                skill_name=sk.canonical_name,
                is_required=os.is_required,
                weight=os.weight
            ))

    return OpportunityResponse(
        id=opp.id,
        company_id=opp.company_id,
        company_name=ind_profile.company_name,
        company_location=ind_profile.location,
        title=opp.title,
        type=opp.type,
        domain=opp.domain,
        location=opp.location,
        work_mode=opp.work_mode,
        description=opp.description,
        stipend_salary=opp.stipend_salary,
        eligibility_min_cgpa=opp.eligibility_min_cgpa,
        eligible_departments=opp.eligible_departments_json or [],
        deadline=opp.deadline,
        is_active=opp.is_active,
        created_at=opp.created_at,
        skills=skill_items
    )


@router.get("/opportunities/{opportunity_id}/candidates", response_model=List[CandidateMatchCard])
def get_matched_candidates_for_opportunity(
    opportunity_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Retrieve ranked candidate matches with explainable skill comparisons for a specific job.
    Strictly verifies employer ownership to prevent unauthorized applicant data exposure.
    """
    from app.core.dependencies import ADMIN_EMAIL
    is_admin = current_user.email.strip().lower() == ADMIN_EMAIL.lower()
    if not is_admin:
        opp = db.query(Opportunity).filter(Opportunity.id == opportunity_id).first()
        if not opp:
            raise HTTPException(status_code=404, detail="Opportunity not found.")
        ind_profile = db.query(IndustryProfile).filter(IndustryProfile.user_id == current_user.id).first()
        is_owner = False
        if ind_profile and opp.company_id == ind_profile.id:
            is_owner = True
        elif getattr(opp, "posted_by_user_id", None) == current_user.id:
            is_owner = True
        if not is_owner:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Forbidden: Only the posting employer or administrator can view matched candidate records."
            )

    return IndustryService.get_candidate_matches_for_opportunity(db, opportunity_id)
