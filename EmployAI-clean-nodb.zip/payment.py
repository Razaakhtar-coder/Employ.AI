from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field


class PaymentSubmitRequest(BaseModel):
    utr_number: str = Field(..., min_length=8, max_length=40, description="12-digit UPI UTR / Transaction Reference ID")
    payer_name: Optional[str] = Field(None, max_length=255)
    payer_upi: Optional[str] = Field(None, max_length=100)
    payment_app: Optional[str] = Field("PhonePe", max_length=50)
    screenshot_url: Optional[str] = None
    notes: Optional[str] = Field(None, max_length=500)


class PaymentVerifyInstantRequest(BaseModel):
    utr_number: str = Field(..., min_length=8, max_length=40)


class PaymentResponse(BaseModel):
    id: str
    user_id: str
    user_email: Optional[str] = None
    user_name: Optional[str] = None
    amount: float
    currency: str
    upi_id: str
    utr_number: str
    payer_name: Optional[str] = None
    payer_upi: Optional[str] = None
    payment_app: Optional[str] = None
    screenshot_url: Optional[str] = None
    status: str  # pending, verified, rejected
    verified_at: Optional[datetime] = None
    verified_by: Optional[str] = None
    notes: Optional[str] = None
    razorpay_order_id: Optional[str] = None
    razorpay_payment_id: Optional[str] = None
    plan_type: Optional[str] = "monthly"
    valid_until: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True


class PaymentStatusResponse(BaseModel):
    is_premium: bool
    is_admin: bool
    email: str
    role: str
    has_pending: bool
    active_payment: Optional[PaymentResponse] = None
    history: List[PaymentResponse] = []
    plan_type: Optional[str] = None
    subscription_valid_until: Optional[datetime] = None
    days_remaining: Optional[int] = None
    is_expired: bool = False


class RazorpayCreateOrderRequest(BaseModel):
    target_feature: Optional[str] = Field("all", description="Feature being unlocked")
    plan_type: Optional[str] = Field("monthly", description="'monthly' or 'annual'")
    notes: Optional[dict] = None


class RazorpayOrderResponse(BaseModel):
    order_id: str
    amount: int  # in paise (4900 for monthly ₹49, 49900 for annual ₹499)
    amount_formatted: str
    currency: str
    key_id: str
    user_name: Optional[str] = None
    user_email: Optional[str] = None
    business_name: str
    description: str
    theme_color: str
    target_feature: Optional[str] = None
    plan_type: str = "monthly"
    duration_days: int = 30


class RazorpayVerifyRequest(BaseModel):
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str
    target_feature: Optional[str] = None
    plan_type: Optional[str] = Field("monthly", description="'monthly' or 'annual'")


class RazorpayConfigResponse(BaseModel):
    key_id: str
    amount: float = 49.0
    monthly_amount: float = 49.0
    annual_amount: float = 499.0
    currency: str = "INR"
    is_test_mode: bool
    enabled: bool = True
    company_name: str = "Employ.AI PRO"


class AdminVerifyPaymentRequest(BaseModel):
    notes: Optional[str] = None


class AdminGrantPremiumRequest(BaseModel):
    email: str
    grant: bool = True

