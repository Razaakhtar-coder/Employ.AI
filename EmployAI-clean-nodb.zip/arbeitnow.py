import re
import html
import asyncio
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting


class ArbeitnowProvider(JobProviderAdapter):
    """
    Arbeitnow Job Board API Adapter.
    Public, license-compliant, free job API for tech, design, marketing, and engineering roles.
    Fetches multiple pages for rich multi-domain opportunity volume.
    """

    API_URL = "https://www.arbeitnow.com/api/job-board-api"

    @property
    def name(self) -> str:
        return "Arbeitnow"

    def _strip_html(self, raw_html: str) -> str:
        if not raw_html:
            return ""
        clean = re.sub(r"<[^>]+>", " ", raw_html)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    async def _fetch_single_page(self, client: httpx.AsyncClient, page_num: int) -> List[dict]:
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) EmployAI/1.0",
                "Accept": "application/json"
            }
            response = await client.get(self.API_URL, params={"page": page_num}, headers=headers)
            if response.status_code == 200:
                payload = response.json()
                return payload.get("data", [])
        except Exception as e:
            print(f"[WARN] Arbeitnow page {page_num} fetch failed: {e}")
        return []

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        postings: List[RawJobPosting] = []

        try:
            async with httpx.AsyncClient(timeout=12.0, follow_redirects=True) as client:
                # Fetch up to 3 pages concurrently for wide inventory
                pages_to_fetch = [page, page + 1, page + 2] if page == 1 else [page]
                tasks = [self._fetch_single_page(client, p) for p in pages_to_fetch]
                results = await asyncio.gather(*tasks, return_exceptions=True)

                all_items = []
                for res in results:
                    if isinstance(res, list):
                        all_items.extend(res)

                for item in all_items:
                    raw_title = item.get("title", "")
                    raw_desc = self._strip_html(item.get("description", ""))
                    is_remote = bool(item.get("remote", False))
                    tags = item.get("tags") or []
                    job_types_list = item.get("job_types") or []

                    # Determine job type
                    mapped_type = "full-time"
                    types_lower = " ".join(job_types_list).lower() + " " + raw_title.lower()
                    if "intern" in types_lower or "trainee" in types_lower:
                        mapped_type = "internship"
                    elif "part-time" in types_lower or "part time" in types_lower:
                        mapped_type = "part-time"
                    elif "contract" in types_lower or "freelance" in types_lower:
                        mapped_type = "contract"

                    # Experience level heuristic
                    exp_level = "entry"
                    title_desc = (raw_title + " " + raw_desc[:400]).lower()
                    if re.search(r"\b(intern|internship|trainee|fresher|junior)\b", title_desc):
                        exp_level = "intern" if "intern" in title_desc or "trainee" in title_desc else "entry"
                    elif re.search(r"\b(senior|lead|principal|staff|director|head of|vp|architect)\b", title_desc):
                        exp_level = "senior"
                    elif re.search(r"\b(mid|intermediate|2-4 years|3\+ years)\b", title_desc):
                        exp_level = "mid"

                    if remote is True and not is_remote:
                        continue
                    if query and query.lower() not in (raw_title + " " + raw_desc + " " + " ".join(tags)).lower():
                        continue

                    postings.append(RawJobPosting(
                        source_id=f"arbeitnow-{item.get('slug', item.get('title', 'job'))}",
                        source="Arbeitnow",
                        title=raw_title,
                        company=item.get("company_name", "Innovative Tech Partner"),
                        location=item.get("location") or ("Remote" if is_remote else "Global"),
                        remote=is_remote,
                        job_type=mapped_type,
                        experience_level=exp_level,
                        description=raw_desc,
                        required_skills=tags,
                        apply_url=item.get("url") or "https://www.arbeitnow.com",
                        posted_date=str(item.get("created_at") or "Recently")
                    ))
        except Exception as e:
            print(f"[ERROR] Arbeitnow fetch_jobs failed: {e}")

        return postings
