from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field


class RawJobPosting(BaseModel):
    source_id: str
    source: str  # "Arbeitnow", "RemoteOK", "JSearch", "Adzuna", "EmployAI Campus"
    title: str
    company: str
    location: str = "Remote / Global"
    remote: bool = False
    job_type: str = "full-time"  # "internship", "full-time", "part-time", "contract"
    experience_level: str = "entry"  # "intern", "entry", "mid", "senior"
    domain: Optional[str] = "Computer Science"
    description: str
    required_skills: List[str] = Field(default_factory=list)
    apply_url: str
    salary_range: Optional[str] = None
    posted_date: Optional[str] = None


class JobSkillItem(BaseModel):
    skill_name: str
    is_matched: bool = False
    is_required: bool = True
    importance: str = "high"  # "critical", "high", "medium"
    recommendation: Optional[str] = None


class JobScoreBreakdown(BaseModel):
    skill_overlap_score: float = 0.0
    experience_fit_score: float = 0.0
    domain_fit_score: float = 0.0
    ats_readiness_score: float = 0.0
    overall_match: float = 0.0


class JobPostingResponse(BaseModel):
    id: str
    source_id: str
    source: str
    title: str
    company: str
    location: str
    remote: bool
    job_type: str
    experience_level: str
    domain: str
    description: str
    required_skills: List[str] = Field(default_factory=list)
    apply_url: str
    salary_range: Optional[str] = None
    posted_date: Optional[str] = None
    last_refreshed_at: Optional[datetime] = None
    created_at: Optional[datetime] = None

    # User Match Attributes (populated when requested by or on behalf of a student)
    match_score: Optional[float] = None
    match_badge: Optional[str] = None  # "High Fit", "Good Fit", "Skill Gap"
    matched_skills: Optional[List[str]] = None
    missing_skills: Optional[List[str]] = None
    is_eligible: bool = True


class JobExplainResponse(BaseModel):
    job_id: str
    title: str
    company: str
    source: str
    match_score: float
    breakdown: JobScoreBreakdown
    matched_skills: List[JobSkillItem] = Field(default_factory=list)
    missing_skills: List[JobSkillItem] = Field(default_factory=list)
    summary: str
    why_matches: List[str] = Field(default_factory=list)
    missing_critical_gaps: List[str] = Field(default_factory=list)
    recommended_action_plan: List[str] = Field(default_factory=list)
    experience_assessment: str
    domain_assessment: str


class ManualJobMatchRequest(BaseModel):
    job_url: Optional[str] = None
    pasted_description: Optional[str] = None
    title: Optional[str] = None
    company: Optional[str] = None


class ManualJobMatchResponse(BaseModel):
    title: str
    company: str
    domain: str
    extracted_skills: List[str]
    experience_level: str
    match_score: float
    breakdown: JobScoreBreakdown
    matched_skills: List[JobSkillItem]
    missing_skills: List[JobSkillItem]
    summary: str
    why_matches: List[str]
    missing_critical_gaps: List[str]
    recommended_action_plan: List[str]


class JobRefreshResponse(BaseModel):
    status: str
    refreshed_count: int
    sources_contacted: List[str]
    message: str
    timestamp: datetime


class ProviderKeyUpdateRequest(BaseModel):
    provider: str
    api_key: str


class ProviderMetadataItem(BaseModel):
    name: str
    key: str
    category: str
    crowd_level: str
    is_enabled: bool
    is_configured: bool
    has_live_feed: bool
    description: str
    api_key_name: str
    active_jobs_count: Optional[int] = 0


class ProvidersListResponse(BaseModel):
    providers: List[ProviderMetadataItem]
    total_active: int
    curated_low_crowd_count: int
    last_sync_timestamp: Optional[str] = None

