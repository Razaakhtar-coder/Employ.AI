import uvicorn
import os
import sys

# Ensure backend root is in pythonpath
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Ensure Windows console encoding does not crash on non-ASCII characters
if sys.platform.startswith("win"):
    try:
        if sys.stdout and hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if sys.stderr and hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

if __name__ == "__main__":
    print("=" * 65)
    print("  [EmployAI] Backend Server Starting...")
    print("  API Endpoint: http://127.0.0.1:8000/api/v1")
    print("  Swagger Docs: http://127.0.0.1:8000/docs")
    print("  Health Check: http://127.0.0.1:8000/health")
    print("=" * 65)
    backend_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.join(backend_dir, "app")

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        reload_dirs=[app_dir],
        reload_excludes=[
            "*.db",
            "*.db-wal",
            "*.db-shm",
            "*.db-journal",
            "*.sqlite*",
            "storage/*",
            "*.log",
            "__pycache__/*",
            "*.tmp"
        ],
        access_log=True
    )

