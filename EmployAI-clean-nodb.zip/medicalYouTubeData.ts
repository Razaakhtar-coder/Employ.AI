import type { DomainPhaseVideoMap } from './domainYouTubeData';

// ============================================================================
// Medical & Nursing Co-Domain 5-Phase YouTube Registry
// Each track provides 5 distinct, verified, top-tier clinical video courses:
// Phase 0: Foundations & Examination First Principles
// Phase 1: Applied Tooling & Clinical Diagnostics
// Phase 2: Advanced Management, Pathophysiology & Resuscitation
// Phase 3: Flagship Clinical Capstone & Procedure Mastery
// Phase 4: Medical Board Screening, OSCE & Clinical Placement Prep
// ============================================================================

export const MEDICAL_YOUTUBE_REGISTRY: Record<string, DomainPhaseVideoMap> = {
  // --------------------------------------------------------------------------
  // 1. Clinical Diagnostics & Physical Examination
  // --------------------------------------------------------------------------
  'med-diagnostics': {
    0: [{
      id: "med-diag-p0-cardio-exam",
      title: "Systematic Cardiovascular & Bedside Clinical Examination",
      youtube_video_id: "XU_xeUMJ3Zc",
      youtube_url: "https://www.youtube.com/watch?v=XU_xeUMJ3Zc",
      fallback_video_id: "9u0bhcYYd-8",
      search_query: "Geeky Medics Cardiovascular Examination bedside clinical examination",
      channel_name: "Geeky Medics",
      duration: "18:40",
      difficulty: "Beginner",
      topic_focus: "IPPA Systematic Cardiovascular & Peripheral Signs Examination",
      key_takeaways: [
        "Systematic inspection, palpation, percussion, and auscultation (IPPA)",
        "Assessing jugular venous pressure (JVP), peripheral edema, and carotid pulse",
        "Auscultating S1, S2, and differentiating systolic vs diastolic murmurs",
        "Clinical bedside correlation with systemic symptoms"
      ]
    }],
    1: [{
      id: "med-diag-p1-respiratory-exam",
      title: "Systematic Respiratory Bedside Examination & Auscultation",
      youtube_video_id: "q6w3CClfhdk",
      youtube_url: "https://www.youtube.com/watch?v=q6w3CClfhdk",
      fallback_video_id: "3mlPpOxbJbA",
      search_query: "Geeky Medics Respiratory Examination chest auscultation breath sounds",
      channel_name: "Geeky Medics",
      duration: "16:20",
      difficulty: "Intermediate",
      topic_focus: "Vesicular Breath Sounds, Crackles, Wheezes & Tactile Fremitus",
      key_takeaways: [
        "Tracheal deviation and chest wall expansion measurement",
        "Percussion note differentiation: Resonant vs dull vs stony dull",
        "Auscultation: Normal vesicular vs bronchial breathing and crackles",
        "Vocal resonance and tactile fremitus in consolidation vs effusion"
      ]
    }],
    2: [{
      id: "med-diag-p2-abdominal-exam",
      title: "Gastrointestinal & Abdominal Examination: Liver, Spleen & Ascites",
      youtube_video_id: "PYAnF6GJY2I",
      youtube_url: "https://www.youtube.com/watch?v=PYAnF6GJY2I",
      fallback_video_id: "KvNbtoxO6t4",
      search_query: "Geeky Medics Abdominal Examination palpation liver spleen",
      channel_name: "Geeky Medics",
      duration: "17:15",
      difficulty: "Advanced",
      topic_focus: "Light & Deep Palpation, Hepatomegaly, Splenomegaly & Peritonitis",
      key_takeaways: [
        "Distinguishing involuntary guarding from voluntary tenderness",
        "Palpating liver edge, splenic notch, and bimanual renal ballottement",
        "Eliciting shifting dullness and fluid thrill for ascites assessment",
        "Evaluating acute surgical abdomen: McBurney's, Murphy's, and Rovsing's signs"
      ]
    }],
    3: [{
      id: "med-diag-p3-neurological-exam",
      title: "Cranial Nerves Examination & Motor/Sensory Neurological Assessment",
      youtube_video_id: "yZ5kV7dJoZw",
      youtube_url: "https://www.youtube.com/watch?v=yZ5kV7dJoZw",
      fallback_video_id: "BKOcqlZnCIM",
      search_query: "Geeky Medics Cranial Nerves Examination neurological exam",
      channel_name: "Geeky Medics",
      duration: "21:30",
      difficulty: "Advanced",
      topic_focus: "Cranial Nerves I-XII, Upper & Lower Motor Neuron Reflexes",
      key_takeaways: [
        "Systematic cranial nerves CN I through XII clinical tests",
        "Upper motor neuron (UMN) vs lower motor neuron (LMN) signs",
        "Tendon reflexes grading (0-4+) and Babinski extensor plantar response",
        "Cerebellar signs: Dysdiadochokinesia, ataxia, nystagmus, intention tremor"
      ]
    }],
    4: [{
      id: "med-diag-p4-clinical-osce",
      title: "Medical Licensing Clinical OSCE Examination & Differential Diagnosis Viva",
      youtube_video_id: "OVlEXQRXQR0",
      youtube_url: "https://www.youtube.com/watch?v=OVlEXQRXQR0",
      fallback_video_id: "wHAKLSSc6P8",
      search_query: "MedCram Clinical History Taking Differential Diagnosis OSCE",
      channel_name: "Rhesus Medicine",
      duration: "32:45",
      difficulty: "Placement",
      topic_focus: "Patient Communication, Differential Synthesis & Medical Viva",
      key_takeaways: [
        "Structuring clinical history: SOCRATES pain analysis and review of systems",
        "Synthesizing clinical findings into prioritized differential diagnoses",
        "Patient-centered communication, empathy, and professional ethics",
        "Acing medical residency interviews and final MBBS clinical viva"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 2. Radiology & Imaging Interpretation
  // --------------------------------------------------------------------------
  'med-radiology': {
    0: [{
      id: "med-rad-p0-cxr-abcde",
      title: "Systematic Chest X-Ray (CXR) Interpretation: The ABCDE Method",
      youtube_video_id: "e39pLXGjNbA",
      youtube_url: "https://www.youtube.com/watch?v=e39pLXGjNbA",
      fallback_video_id: "lEvSw4GcXPM",
      search_query: "Ninja Nerd Chest X Ray interpretation CXR radiology ABCDE",
      channel_name: "Geeky Medics",
      duration: "24:10",
      difficulty: "Beginner",
      topic_focus: "Systematic ABCDE CXR Reading & Common Pulmonary Pathologies",
      key_takeaways: [
        "Airway, Breathing, Cardiac silhouette, Diaphragm, Everything else (ABCDE)",
        "Assessing inspiratory effort, rotation, penetration, and cardiothoracic ratio",
        "Identifying consolidation, pleural effusion, and meniscus sign",
        "Detecting pneumothorax and tension pneumothorax deep sulcus sign"
      ]
    }],
    1: [{
      id: "med-rad-p1-brain-ct",
      title: "Brain CT Scan Interpretation: Hemorrhage, Stroke & Trauma Anatomy",
      youtube_video_id: "sh_2ZUnKodE",
      youtube_url: "https://www.youtube.com/watch?v=sh_2ZUnKodE",
      fallback_video_id: "5_Zf8371sZY",
      search_query: "Conceptual Radiology Systematic Brain CT Scan Interpretation",
      channel_name: "Radiology Masters",
      duration: "22:15",
      difficulty: "Intermediate",
      topic_focus: "Blood Can Be Very Bad (BCBVB) Systematic Non-Contrast Head CT",
      key_takeaways: [
        "Evaluating non-contrast head CT: Blood, Cisterns, Brain, Ventricles, Bones",
        "Differentiating epidural hematoma (lenticular) vs subdural hematoma (crescent)",
        "Subarachnoid hemorrhage (starfish pattern) and midline shift measurement",
        "Early signs of ischemic stroke: Hyperdense MCA sign and sulcal effacement"
      ]
    }],
    2: [{
      id: "med-rad-p2-abdominal-ct",
      title: "Abdominal & Pelvic CT Scan Anatomy, Contrast Phases & Pathologies",
      youtube_video_id: "MPo1i0WvdAg",
      youtube_url: "https://www.youtube.com/watch?v=MPo1i0WvdAg",
      fallback_video_id: "4su7Gj6wyLg",
      search_query: "Radiopaedia Abdominal CT Scan Anatomy Pathology bowel liver",
      channel_name: "Radiology Tutorials",
      duration: "28:30",
      difficulty: "Advanced",
      topic_focus: "Arterial vs Portal Venous Phase, Bowel Obstruction & Perforation",
      key_takeaways: [
        "Contrast phases: Non-contrast, arterial, portal venous, and delayed",
        "Recognizing free intraperitoneal air (pneumoperitoneum) indicating perforation",
        "Small bowel obstruction transitions and mesenteric ischemia signs",
        "Acute appendicitis, diverticulitis, and pancreatic necrosis scoring"
      ]
    }],
    3: [{
      id: "med-rad-p3-pocus-fast",
      title: "Point-of-Care Ultrasound (POCUS) & The FAST Exam in Trauma",
      youtube_video_id: "JcCZBKSdIRk",
      youtube_url: "https://www.youtube.com/watch?v=JcCZBKSdIRk",
      fallback_video_id: "yRr0PJ7_w2U",
      search_query: "SonoSite Point of Care Ultrasound POCUS FAST Exam Trauma",
      channel_name: "POCUS 101",
      duration: "19:40",
      difficulty: "Advanced",
      topic_focus: "Morison Pouch, Splenorenal Recess, Pelvic Pouch & Pericardial Fluid",
      key_takeaways: [
        "Focused Assessment with Sonography for Trauma (FAST) four acoustic windows",
        "Detecting hemoperitoneum in Morison's pouch (hepatorenal space)",
        "Evaluating pericardial effusion and cardiac tamponade in subxiphoid view",
        "Extended FAST (eFAST) for pneumothorax: Lung sliding and seashore sign"
      ]
    }],
    4: [{
      id: "med-rad-p4-radiology-viva",
      title: "Radiology Residency Technical Screening & High-Yield Film Viva",
      youtube_video_id: "uYA2qkW67gU",
      youtube_url: "https://www.youtube.com/watch?v=uYA2qkW67gU",
      fallback_video_id: "QNezlIiEI1E",
      search_query: "Radiology Board Review High Yield Case Viva Film Screening",
      channel_name: "RadioGyan - Radiology Made Easy! (Radiology Made Easy!)",
      duration: "34:00",
      difficulty: "Placement",
      topic_focus: "Rapid Film Triage, Structured Reporting & Radiologist Oral Board",
      key_takeaways: [
        "Structured radiology reporting templates: Findings, impression, recommendations",
        "Spotting emergency critical findings: Aortic dissection, tension pneumothorax",
        "Articulating diagnostic confidence and recommending appropriate modalities",
        "Acing clinical radiology case presentations and final MD/DNB film viva"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 3. Cardiology & 12-Lead ECG Analysis
  // --------------------------------------------------------------------------
  'med-ecg': {
    0: [{
      id: "med-ecg-p0-fundamentals",
      title: "12-Lead ECG Reading: Waves, Segments, Intervals & Rate Calculation",
      youtube_video_id: "kwLbSx9BNbU",
      youtube_url: "https://www.youtube.com/watch?v=kwLbSx9BNbU",
      fallback_video_id: "TTYGxK1DNKA",
      search_query: "Ninja Nerd 12 Lead ECG Reading Waves Segments Intervals",
      channel_name: "Alila Medical Media",
      duration: "26:30",
      difficulty: "Beginner",
      topic_focus: "P-QRS-T Waves, PR Interval, QTc Calculation & Rate/Rhythm Rules",
      key_takeaways: [
        "Electrophysiological basis of P wave, QRS complex, ST segment, and T wave",
        "Calculating heart rate (300/1500 method) and assessing regular vs irregular rhythm",
        "Normal PR interval (120-200ms) and QRS duration (<120ms)",
        "QTc calculation (Bazett's formula) and risk of Torsades de Pointes"
      ]
    }],
    1: [{
      id: "med-ecg-p1-arrhythmias",
      title: "Cardiac Arrhythmias & Conduction Blocks: AFib, SVT & Heart Blocks",
      youtube_video_id: "JhqVivwes_g",
      youtube_url: "https://www.youtube.com/watch?v=JhqVivwes_g",
      fallback_video_id: "-ZDudr8tqxQ",
      search_query: "Strong Medicine Arrhythmias Heart Blocks AV Blocks AFib SVT",
      channel_name: "Zero To Finals",
      duration: "29:15",
      difficulty: "Intermediate",
      topic_focus: "Atrial Fibrillation, Supraventricular Tachycardia & 1st-3rd Degree AV Block",
      key_takeaways: [
        "Atrial fibrillation: Absent P waves, irregularly irregular baseline",
        "Narrow complex tachycardias: SVT vs sinus tachycardia vs atrial flutter",
        "1st, 2nd degree (Mobitz I Wenckebach vs Mobitz II), and 3rd degree AV block",
        "Ventricular tachycardia (VTach) vs ventricular fibrillation (VFib)"
      ]
    }],
    2: [{
      id: "med-ecg-p2-stemi-nstemi",
      title: "STEMI vs NSTEMI: Myocardial Infarction Localization & Reciprocal Changes",
      youtube_video_id: "lSxD3Vxd2jA",
      youtube_url: "https://www.youtube.com/watch?v=lSxD3Vxd2jA",
      fallback_video_id: "tc_T1KtUmFI",
      search_query: "MedCram STEMI vs NSTEMI Ischemia Injury Infarction ECG",
      channel_name: "Ninja Nerd",
      duration: "25:40",
      difficulty: "Advanced",
      topic_focus: "ST Elevation Criteria, Coronary Artery Territories & Reciprocal Depression",
      key_takeaways: [
        "Anterior STEMI (V1-V4, LAD) vs Inferior STEMI (II, III, aVF, RCA)",
        "Lateral STEMI (I, aVL, V5-V6, LCx) and Posterior MI reciprocal changes in V1-V2",
        "Pathological Q waves and T wave inversion progression in ischemia",
        "Sgarbossa criteria for identifying STEMI in the presence of LBBB"
      ]
    }],
    3: [{
      id: "med-ecg-p3-axis-hypertrophy",
      title: "Cardiac Axis Deviation, Bundle Branch Blocks & Ventricular Hypertrophy",
      youtube_video_id: "LfipQ-GYTqk",
      youtube_url: "https://www.youtube.com/watch?v=LfipQ-GYTqk",
      fallback_video_id: "lSxD3Vxd2jA",
      search_query: "Lecturio Axis Deviation Bundle Branch Blocks LBBB RBBB LVH",
      channel_name: "Osmosis from Elsevier",
      duration: "23:10",
      difficulty: "Advanced",
      topic_focus: "Lead I & aVF Quadrant Method, LBBB vs RBBB & Sokolow-Lyon Criteria",
      key_takeaways: [
        "Determining electrical axis: Normal (-30 to +90), LAD vs RAD",
        "Left Bundle Branch Block (LBBB: broad notched R in I/aVL/V6) vs RBBB (M-shaped V1)",
        "Left Ventricular Hypertrophy (LVH) Sokolow-Lyon and Cornell criteria",
        "Electrolyte ECG patterns: Hyperkalemia tall tented T waves and hypokalemia U waves"
      ]
    }],
    4: [{
      id: "med-ecg-p4-clinical-ecg-viva",
      title: "Emergency Cardiology ECG Triage & Board Examination Case Screening",
      youtube_video_id: "tc_T1KtUmFI",
      youtube_url: "https://www.youtube.com/watch?v=tc_T1KtUmFI",
      fallback_video_id: "4vUMpG_wsrM",
      search_query: "EM Ireland Emergency Cardiology ECG Triage Board Exam Viva",
      channel_name: "CARE Hospitals",
      duration: "31:00",
      difficulty: "Placement",
      topic_focus: "Rapid 10-Second ECG Interpretation, Code STEMI Activation & Case Viva",
      key_takeaways: [
        "Executing systematic 10-second ECG triage in emergency department settings",
        "Recognizing STEMI equivalents: Wellens syndrome and de Winter T waves",
        "Deciding emergency interventions: Synchronized cardioversion vs defibrillation",
        "Acing cardiology fellowship and medical licensing clinical ECG viva"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 4. Emergency Medicine & Trauma Care
  // --------------------------------------------------------------------------
  'med-emergency': {
    0: [{
      id: "med-em-p0-atls-primary",
      title: "Advanced Trauma Life Support (ATLS): ABCDE Primary Survey & Resuscitation",
      youtube_video_id: "5AAj3Nkp5W4",
      youtube_url: "https://www.youtube.com/watch?v=5AAj3Nkp5W4",
      fallback_video_id: "aJKt5o5szVU",
      search_query: "Lecturio Trauma Resuscitation ATLS primary survey ABCDE",
      channel_name: "Anaesthesia Review hub",
      duration: "24:15",
      difficulty: "Beginner",
      topic_focus: "Airway with C-Spine, Breathing, Circulation, Disability, Exposure",
      key_takeaways: [
        "Primary survey priorities: Airway maintenance with cervical spine restriction",
        "Breathing assessment: Excluding life threats (tension pneumothorax, flail chest)",
        "Circulation: Rapid hemorrhage control, pulse assessment, large-bore IV access",
        "Disability: GCS scoring, pupillary light reflex, and full patient exposure"
      ]
    }],
    1: [{
      id: "med-em-p1-shock-resuscitation",
      title: "Hemorrhagic Shock Classes & Massive Transfusion Protocols (MTP)",
      youtube_video_id: "IoJSN9u7qS0",
      youtube_url: "https://www.youtube.com/watch?v=IoJSN9u7qS0",
      fallback_video_id: "ezx3Kuoo_z4",
      search_query: "EM Ireland Hemorrhagic Shock Classes Massive Transfusion Protocol MTP",
      channel_name: "ICU Advantage",
      duration: "22:40",
      difficulty: "Intermediate",
      topic_focus: "Classes I-IV Shock, Balanced 1:1:1 Hemostatic Resuscitation & TXA",
      key_takeaways: [
        "Class I through IV hemorrhagic shock grading by blood loss and vitals",
        "Balanced blood component therapy: 1:1:1 ratio (PRBCs, FFP, Platelets)",
        "Early administration of tranexamic acid (TXA) within 3 hours of trauma",
        "Damage control resuscitation: Permissive hypotension and hypothermia avoidance"
      ]
    }],
    2: [{
      id: "med-em-p2-airway-rsi",
      title: "Emergency Airway Management & Rapid Sequence Intubation (RSI)",
      youtube_video_id: "pZ1eEAx7aOM",
      youtube_url: "https://www.youtube.com/watch?v=pZ1eEAx7aOM",
      fallback_video_id: "4trIrJyFv5A",
      search_query: "MedCram Emergency Airway Management Rapid Sequence Intubation RSI",
      channel_name: "Anaesthetix",
      duration: "26:50",
      difficulty: "Advanced",
      topic_focus: "The 7 Ps of RSI, Induction & Paralytic Agents, Difficult Airway Plan",
      key_takeaways: [
        "The 7 Ps of RSI: Preparation, Preoxygenation, Pretreatment, Paralysis, Placement",
        "Selecting induction agents: Etomidate vs ketamine vs propofol",
        "Neuromuscular blockade: Succinylcholine vs rocuronium dosages and caveats",
        "Difficult airway algorithm: Video laryngoscopy, supraglottic airway, and cricothyroidotomy"
      ]
    }],
    3: [{
      id: "med-em-p3-mass-casualty",
      title: "Mass Casualty Triage (START Protocol) & Thoracic Trauma Emergencies",
      youtube_video_id: "9QHDs10e-G0",
      youtube_url: "https://www.youtube.com/watch?v=9QHDs10e-G0",
      fallback_video_id: "ki1A0yOmugg",
      search_query: "St John Ambulance Mass Casualty Triage START Protocol Tension Pneumothorax",
      channel_name: "UNMC HEROES",
      duration: "21:15",
      difficulty: "Advanced",
      topic_focus: "START Triage Color Codes, Needle Decompression & Chest Tube Thoracostomy",
      key_takeaways: [
        "Simple Triage and Rapid Treatment (START): Green, Yellow, Red, Black categorization",
        "Emergency needle thoracostomy (2nd intercostal midclavicular / 5th intercostal anterior axillary)",
        "Chest tube thoracostomy (5th intercostal safe triangle of trauma)",
        "Recognizing massive hemothorax (>1500ml) requiring emergent thoracotomy"
      ]
    }],
    4: [{
      id: "med-em-p4-emergency-viva",
      title: "Emergency Medicine Board Examination & Resuscitation Simulation Viva",
      youtube_video_id: "_stGbg8kcW8",
      youtube_url: "https://www.youtube.com/watch?v=_stGbg8kcW8",
      fallback_video_id: "jvt63fQ2cUY",
      search_query: "Emergency Medicine Oral Board Review Resuscitation Case Screening",
      channel_name: "EM Board Bombs",
      duration: "30:00",
      difficulty: "Placement",
      topic_focus: "Trauma Team Leadership, Closed-Loop Communication & Oral Board Viva",
      key_takeaways: [
        "Trauma team leadership dynamics, role delegation, and closed-loop communication",
        "Managing polytrauma with head injury: Maintaining cerebral perfusion pressure (CPP)",
        "Secondary survey head-to-toe examination and definitive disposition planning",
        "Cracking emergency medicine residency entrance, MEM, and MRCEM clinical exams"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 5. General Surgery & Minor OT Skills
  // --------------------------------------------------------------------------
  'med-surgery': {
    0: [{
      id: "med-surg-p0-scrubbing-sterile",
      title: "Surgical Scrubbing, Gowning & Gloving: Aseptic OT Protocols",
      youtube_video_id: "wXJRBD_7Xvo",
      youtube_url: "https://www.youtube.com/watch?v=wXJRBD_7Xvo",
      fallback_video_id: "nD1YT_5QaxU",
      search_query: "Geeky Medics surgical scrub gown sterile gloving OT skills",
      channel_name: "Leeds School of Dentistry",
      duration: "15:20",
      difficulty: "Beginner",
      topic_focus: "Aseptic Technique, Chlorhexidine Scrubbing, Closed Gloving & Sterile Field",
      key_takeaways: [
        "Systematic surgical hand scrub from fingertips to elbows (3-5 minutes)",
        "Maintaining sterility: Closed glove technique and sterile gown tie assistance",
        "Draping the patient and defining sterile boundaries in the operating theater",
        "Sharps safety protocols and WHO surgical safety checklist"
      ]
    }],
    1: [{
      id: "med-surg-p1-suturing-skills",
      title: "Surgical Suturing Techniques: Simple Interrupted, Mattress & Subcuticular",
      youtube_video_id: "z8oWv-nVO6g",
      youtube_url: "https://www.youtube.com/watch?v=z8oWv-nVO6g",
      fallback_video_id: "AOfdq-h1WMg",
      search_query: "Geeky Medics surgical suturing techniques needle holder instrument tie",
      channel_name: "Geeky Medics",
      duration: "24:10",
      difficulty: "Intermediate",
      topic_focus: "Instrument Tie, Vertical/Horizontal Mattress, Subcuticular & Knot Tying",
      key_takeaways: [
        "Handling needle holder, toothed dissecting forceps, and Mayo scissors properly",
        "Simple interrupted sutures: Wound edge eversion and tension distribution",
        "Vertical and horizontal mattress sutures for high-tension laceration closure",
        "Continuous subcuticular closure using absorbable monofilament (Monocryl/Vicryl)"
      ]
    }],
    2: [{
      id: "med-surg-p2-minor-procedures",
      title: "Minor Surgical Procedures: Local Anesthesia, Abscess I&D & Cyst Excision",
      youtube_video_id: "_x8gYZ5fWGE",
      youtube_url: "https://www.youtube.com/watch?v=_x8gYZ5fWGE",
      fallback_video_id: "5lqtonfXDPw",
      search_query: "Larry Mellick Abscess Incision Drainage Local Anesthesia Sebaceous Cyst",
      channel_name: "Suturing & Procedures",
      duration: "22:15",
      difficulty: "Advanced",
      topic_focus: "Lidocaine Infiltration, Incision and Drainage, Packing & Excision",
      key_takeaways: [
        "Local anesthesia infiltration: Lidocaine with vs without adrenaline dosages",
        "Incision and drainage (I&D) of cutaneous abscess along Langer's lines",
        "Loculation breakdown with hemostat forceps and ribbon gauze wound packing",
        "Complete sebaceous cyst enucleation with intact capsule removal"
      ]
    }],
    3: [{
      id: "med-surg-p3-laparoscopy-basics",
      title: "Basic Laparoscopic Surgery Principles: Ergonomics & Port Placement",
      youtube_video_id: "jonXBwWHDrs",
      youtube_url: "https://www.youtube.com/watch?v=jonXBwWHDrs",
      fallback_video_id: "mqiRWQ_hSuY",
      search_query: "Surgical Associates Basic Laparoscopy Ergonomics Trocar Port placement",
      channel_name: "Vidya-mitra",
      duration: "25:30",
      difficulty: "Advanced",
      topic_focus: "Pneumoperitoneum, Veress Needle, Primary Trocar & Camera Navigation",
      key_takeaways: [
        "Creating pneumoperitoneum: Veress needle insufflation vs Hasson open technique",
        "Triangulation and ergonomic port placement for laparoscopic cholecystectomy",
        "Electrosurgical safety: Monopolar vs bipolar coagulation principles",
        "Managing laparoscopic complications: Trocar site hematoma and visceral injury"
      ]
    }],
    4: [{
      id: "med-surg-p4-mrcs-surgery-viva",
      title: "Surgical Residency Technical Screening & MRCS Part B Clinical Exam Viva",
      youtube_video_id: "8_bgb1tMmsM",
      youtube_url: "https://www.youtube.com/watch?v=8_bgb1tMmsM",
      fallback_video_id: "jprF9CrzXMs",
      search_query: "Royal College of Surgeons MRCS Part B Clinical Exam OSPE Viva",
      channel_name: "MEDICOPLASTY",
      duration: "32:00",
      difficulty: "Placement",
      topic_focus: "Surgical Anatomy, Pathology, Postoperative Complications & Viva",
      key_takeaways: [
        "Preoperative optimization and deep vein thrombosis (DVT) prophylaxis",
        "Postoperative complications: Fever causes (Wind, Water, Wound, Walking, Wonder drugs)",
        "Managing surgical shock, sepsis, and postoperative ileus vs bowel obstruction",
        "Cracking MS General Surgery, DNB, and MRCS clinical scenario viva rounds"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 6. Basic & Advanced Life Support (BLS / ACLS)
  // --------------------------------------------------------------------------
  'med-bls': {
    0: [{
      id: "med-bls-p0-cpr-aed",
      title: "BLS Provider CPR & AED Demonstration: High-Quality Chest Compressions",
      youtube_video_id: "hTS6gtaTHcI",
      youtube_url: "https://www.youtube.com/watch?v=hTS6gtaTHcI",
      fallback_video_id: "rCN5DU897r4",
      search_query: "American Heart Association BLS Healthcare Provider CPR AED",
      channel_name: "Medanta",
      duration: "16:45",
      difficulty: "Beginner",
      topic_focus: "High-Quality CPR (100-120 bpm), 30:2 Ratio, AED Pad Placement",
      key_takeaways: [
        "High-quality CPR: Depth of 2-2.4 inches (5-6 cm) and full chest recoil",
        "Compression rate: 100-120 compressions per minute with minimal interruptions (<10s)",
        "30 compressions to 2 rescue breaths ratio using bag-valve-mask (BVM)",
        "Prompt Automated External Defibrillator (AED) operation and voice prompt adherence"
      ]
    }],
    1: [{
      id: "med-bls-p1-acls-cardiac-arrest",
      title: "ACLS Cardiac Arrest Algorithm: Shockable vs Non-Shockable Rhythms",
      youtube_video_id: "F-udw0Av4kw",
      youtube_url: "https://www.youtube.com/watch?v=F-udw0Av4kw",
      fallback_video_id: "hTS6gtaTHcI",
      search_query: "MedCram ACLS Cardiac Arrest Algorithm VFib Pulseless VTach PEA Asystole",
      channel_name: "The Resuscitation Coach",
      duration: "27:10",
      difficulty: "Intermediate",
      topic_focus: "VF/pVT Defibrillation (200J Biphasic), Epinephrine & Amiodarone",
      key_takeaways: [
        "Shockable rhythms: Ventricular Fibrillation (VF) and Pulseless VT (pVT)",
        "Non-shockable rhythms: Pulseless Electrical Activity (PEA) and Asystole",
        "Medication dosing: Epinephrine 1mg IV every 3-5 min, Amiodarone 300mg then 150mg",
        "Investigating the reversible H's and T's of cardiac arrest"
      ]
    }],
    2: [{
      id: "med-bls-p2-tachy-bradycardia",
      title: "ACLS Tachycardia & Bradycardia with Pulse Algorithms",
      youtube_video_id: "jYjdUhfNTPw",
      youtube_url: "https://www.youtube.com/watch?v=jYjdUhfNTPw",
      fallback_video_id: "l8cQgdkGSM4",
      search_query: "Lecturio ACLS Bradycardia Tachycardia algorithms synchronized cardioversion",
      channel_name: "ICU Advantage",
      duration: "23:40",
      difficulty: "Advanced",
      topic_focus: "Atropine for Bradycardia, Synchronized Cardioversion for Unstable Tachycardia",
      key_takeaways: [
        "Assessing stability: Hypotension, altered mental status, signs of shock, ischemic chest pain",
        "Symptomatic bradycardia algorithm: Atropine 1mg, transcutaneous pacing, dopamine/epinephrine",
        "Unstable tachycardia: Immediate synchronized cardioversion with sedation",
        "Stable narrow complex SVT: Vagal maneuvers, Adenosine 6mg rapid IV push with flush"
      ]
    }],
    3: [{
      id: "med-bls-p3-post-arrest",
      title: "Post-Cardiac Arrest Care & Targeted Temperature Management (TTM)",
      youtube_video_id: "lha6CmPsrOc",
      youtube_url: "https://www.youtube.com/watch?v=lha6CmPsrOc",
      fallback_video_id: "hTS6gtaTHcI",
      search_query: "Resuscitation Council Post Cardiac Arrest Care Targeted Temperature TTM",
      channel_name: "ICU Advantage",
      duration: "21:30",
      difficulty: "Advanced",
      topic_focus: "ROSC Optimization, Targeted Temperature (32-36°C), Hemodynamics & EEG",
      key_takeaways: [
        "Immediate post-ROSC priorities: Securing airway, maintaining normocarbia and SpO2 92-98%",
        "Targeting mean arterial pressure (MAP) >= 65 mmHg with IV crystalloids and vasopressors",
        "Emergency coronary angiography for suspected cardiac etiology or STEMI on ECG",
        "Targeted Temperature Management (TTM) for comatose patients to prevent reperfusion injury"
      ]
    }],
    4: [{
      id: "med-bls-p4-megacode-screening",
      title: "ACLS MegaCode Mock Scenario & Hospital Resuscitation Team Screening",
      youtube_video_id: "hTS6gtaTHcI",
      youtube_url: "https://www.youtube.com/watch?v=hTS6gtaTHcI",
      fallback_video_id: "vin4Orr1r1U",
      search_query: "AHA ACLS MegaCode Mock Scenario Resuscitation Team Screening",
      channel_name: "Medanta",
      duration: "28:15",
      difficulty: "Placement",
      topic_focus: "MegaCode Team Leadership, High-Performance Resuscitation & Practical Viva",
      key_takeaways: [
        "Leading high-performance resuscitation teams: Directing compressor rotations",
        "Rapid rhythm recognition on real-time defibrillator monitor screens",
        "Preventing CPR interruptions during charging and pulse check transitions",
        "Passing AHA ACLS certification and hospital Code Blue team credentialing exams"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 7. Laboratory Reports & Clinical Pathology
  // --------------------------------------------------------------------------
  'med-lab': {
    0: [{
      id: "med-lab-p0-cbc",
      title: "Complete Blood Count (CBC) Interpretation & Differential White Cell Count",
      youtube_video_id: "MRzxsX5YG94",
      youtube_url: "https://www.youtube.com/watch?v=MRzxsX5YG94",
      fallback_video_id: "JVmPu8o2ycc",
      search_query: "Ninja Nerd Complete Blood Count CBC Interpretation RBC WBC Platelets",
      channel_name: "Ninja Nerd",
      duration: "24:10",
      difficulty: "Beginner",
      topic_focus: "Hemoglobin, MCV/MCH, Microcytic vs Macrocytic Anemia & Leukocytosis",
      key_takeaways: [
        "Evaluating RBC indices: MCV, MCH, and RDW to differentiate iron deficiency from thalassemia",
        "White blood cell differential: Neutrophilia, lymphocytosis, and bandemia shift to left",
        "Thrombocytopenia etiology vs reactive thrombocytosis",
        "Peripheral blood smear correlation with automated hematology analyzer values"
      ]
    }],
    1: [{
      id: "med-lab-p1-abg",
      title: "Arterial Blood Gas (ABG) Analysis: Acid-Base Disorders & Compensation",
      youtube_video_id: "D0haz5rtjnw",
      youtube_url: "https://www.youtube.com/watch?v=D0haz5rtjnw",
      fallback_video_id: "dg1IfEr_vEE",
      search_query: "MedCram Arterial Blood Gas ABG Analysis Acid Base Disorders Metabolic Acidosis",
      channel_name: "MedCram - Medical Lectures Explained CLEARLY",
      duration: "22:30",
      difficulty: "Intermediate",
      topic_focus: "pH, PaCO2, HCO3, Anion Gap & Winter's Formula Compensation",
      key_takeaways: [
        "Systematic step-by-step approach to primary acid-base disturbances",
        "Calculating serum anion gap and identifying high anion gap metabolic acidosis (MUDPILES)",
        "Assessing respiratory compensation using Winter's formula and delta-delta ratios",
        "Clinical management of respiratory acidosis vs alkalosis in ventilated patients"
      ]
    }],
    2: [{
      id: "med-lab-p2-lft-kft",
      title: "Liver Function Tests (LFT) & Renal Function Panels (KFT / RFT) Interpretation",
      youtube_video_id: "JiaMJaA34Jg",
      youtube_url: "https://www.youtube.com/watch?v=JiaMJaA34Jg",
      fallback_video_id: "e5R6tzJCCgw",
      search_query: "Ninja Nerd Liver Function Tests LFT AST ALT Bilirubin Renal Function Creatinine",
      channel_name: "Ninja Nerd",
      duration: "26:45",
      difficulty: "Intermediate",
      topic_focus: "Hepatocellular vs Cholestatic Patterns, BUN/Creatinine Ratio & eGFR",
      key_takeaways: [
        "Differentiating hepatocellular injury (AST/ALT elevation) from cholestasis (ALP/GGT)",
        "Direct vs indirect hyperbilirubinemia pathophysiology and jaundice differential",
        "Assessing acute kidney injury via serum creatinine trends and KDIGO staging criteria",
        "BUN-to-creatinine ratio interpretation: Prerenal azotemia vs intrinsic renal disease"
      ]
    }],
    3: [{
      id: "med-lab-p3-coagulation",
      title: "Coagulation Profiles (PT/INR, aPTT, D-Dimer) & Sepsis Biomarkers (Procalcitonin, CRP)",
      youtube_video_id: "SGzp9wqeu84",
      youtube_url: "https://www.youtube.com/watch?v=SGzp9wqeu84",
      fallback_video_id: "JspiAOXApvo",
      search_query: "Geeky Medics Coagulation Profile PT INR aPTT D Dimer Sepsis Biomarkers",
      channel_name: "Ninja Nerd",
      duration: "21:15",
      difficulty: "Advanced",
      topic_focus: "Extrinsic vs Intrinsic Coagulation Cascades, DIC & Sepsis Biomarkers",
      key_takeaways: [
        "Understanding PT/INR for extrinsic pathway and warfarin monitoring",
        "aPTT analysis for intrinsic pathway disorders and unfractionated heparin therapy",
        "D-dimer utilization and cutoffs for ruling out deep vein thrombosis and pulmonary embolism",
        "Procalcitonin and quantitative CRP kinetics in distinguishing bacterial from viral sepsis"
      ]
    }],
    4: [{
      id: "med-lab-p4-pathology-viva",
      title: "Clinical Pathology & Diagnostic Lab Medicine Board Viva / Residency Exam",
      youtube_video_id: "kA6l4SbnEaU",
      youtube_url: "https://www.youtube.com/watch?v=kA6l4SbnEaU",
      fallback_video_id: "C_d8wY1v2TU",
      search_query: "Clinical Pathology Board Exam Differential Diagnosis Lab Viva",
      channel_name: "PrepLadder NEET PG I FMGE I INI-CET",
      duration: "30:20",
      difficulty: "Placement",
      topic_focus: "Diagnostic Algorithms, Critical Panic Values & Clinical Case Synthesis",
      key_takeaways: [
        "Formulating targeted lab workup plans for acute undifferentiated presentations",
        "Managing critical laboratory panic values: Severe hyperkalemia, acute hypoglycemia, profound anemia",
        "Interpreting cerebrospinal fluid (CSF) analysis in bacterial vs viral vs fungal meningitis",
        "Excelling in clinical pathology viva questions for medical licensing and residency exams"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 8. Internal Medicine & Therapeutics
  // --------------------------------------------------------------------------
  'med-internal': {
    0: [{
      id: "med-int-p0-htn-dm",
      title: "Clinical Management of Hypertension & Type 2 Diabetes Mellitus Guidelines",
      youtube_video_id: "sNCtvsY3TS8",
      youtube_url: "https://www.youtube.com/watch?v=sNCtvsY3TS8",
      fallback_video_id: "rh8ycjPCj18",
      search_query: "Ninja Nerd Hypertension Management Guidelines Diabetes Mellitus Type 2 Treatment",
      channel_name: "Ninja Nerd",
      duration: "29:10",
      difficulty: "Beginner",
      topic_focus: "JNC-8 / ACC Guidelines, Metformin, SGLT2i, GLP-1 RA & Antihypertensives",
      key_takeaways: [
        "First-line antihypertensive classes: ACEi/ARBs, CCBs, and thiazide diuretics",
        "Target blood pressure thresholds based on age, chronic kidney disease, and cardiovascular risk",
        "ADA stepwise glycemic algorithm: Lifestyle, Metformin, SGLT-2 inhibitors, and GLP-1 receptor agonists",
        "Preventing microvascular (retinopathy, nephropathy) and macrovascular diabetic complications"
      ]
    }],
    1: [{
      id: "med-int-p1-copd-asthma",
      title: "Chronic Obstructive Pulmonary Disease (COPD) & Acute Asthma Exacerbations",
      youtube_video_id: "B3ZZp3ZRYTc",
      youtube_url: "https://www.youtube.com/watch?v=B3ZZp3ZRYTc",
      fallback_video_id: "_A7jgGAs0VI",
      search_query: "MedCram COPD Exacerbation Management Asthma Inhalers Spirometry",
      channel_name: "MedCore India ",
      duration: "25:40",
      difficulty: "Intermediate",
      topic_focus: "GOLD Guidelines, Inhaled Bronchodilators, Corticosteroids & Non-Invasive Ventilation",
      key_takeaways: [
        "Interpreting spirometry: FEV1/FVC ratio < 0.70 confirming non-reversible airflow limitation",
        "Stepwise inhalation therapy: SABA/LABA, LAMA, and inhaled corticosteroids (ICS)",
        "Managing acute COPD exacerbations: Nebulized bronchodilators, systemic steroids, and antibiotics",
        "Indications for Non-Invasive Positive Pressure Ventilation (BiPAP) in acute hypercapnic failure"
      ]
    }],
    2: [{
      id: "med-int-p2-sepsis",
      title: "Surviving Sepsis Campaign: Hour-1 Bundle & Septic Shock Resuscitation",
      youtube_video_id: "DmJKEt0Iod8",
      youtube_url: "https://www.youtube.com/watch?v=DmJKEt0Iod8",
      fallback_video_id: "vw_PwYTXPpA",
      search_query: "MedCram Sepsis Guidelines Hour 1 Bundle Septic Shock Vasopressors",
      channel_name: "ICU Advantage",
      duration: "28:15",
      difficulty: "Intermediate",
      topic_focus: "qSOFA / SOFA Scoring, Blood Cultures, Broad-Spectrum Antibiotics & Norepinephrine",
      key_takeaways: [
        "Recognizing sepsis early with qSOFA criteria: Altered mentation, respiratory rate >=22, SBP <=100",
        "Executing the Surviving Sepsis Hour-1 Bundle: Measure lactate, obtain blood cultures, start broad-spectrum IV antibiotics",
        "Administering 30 mL/kg crystalloid fluid bolus for hypotension or lactate >= 4 mmol/L",
        "Titrating first-line vasopressor Norepinephrine to maintain Mean Arterial Pressure (MAP) >= 65 mmHg"
      ]
    }],
    3: [{
      id: "med-int-p3-heart-failure",
      title: "Heart Failure with Reduced Ejection Fraction (HFrEF): Guideline-Directed Medical Therapy",
      youtube_video_id: "057uW1g0dak",
      youtube_url: "https://www.youtube.com/watch?v=057uW1g0dak",
      fallback_video_id: "Gsu8NT1yYes",
      search_query: "Ninja Nerd Heart Failure Pathophysiology GDMT ARNI Beta Blockers SGLT2i",
      channel_name: "medschoolbro",
      duration: "34:20",
      difficulty: "Advanced",
      topic_focus: "The 4 Pillars of GDMT: ARNI/ACEi, Beta-Blockers, MRA & SGLT2 Inhibitors",
      key_takeaways: [
        "Pathophysiology of neurohormonal activation in ventricular remodeling and systolic failure",
        "Implementing the 4 pillars of GDMT to reduce mortality and hospitalization",
        "Titration strategies, monitoring serum potassium and eGFR during ARNI and spironolactone initiation",
        "Managing acute decompensated heart failure with IV loop diuretics and vasodilators"
      ]
    }],
    4: [{
      id: "med-int-p4-residency-rounds",
      title: "Internal Medicine Clinical Grand Rounds & Ward Management Residency Prep",
      youtube_video_id: "FKmjCQ_W-pA",
      youtube_url: "https://www.youtube.com/watch?v=FKmjCQ_W-pA",
      fallback_video_id: "RJQPA2zFobE",
      search_query: "Internal Medicine Residency Case Presentation Clinical Grand Rounds Ward Rounds",
      channel_name: "Strong Medicine",
      duration: "31:40",
      difficulty: "Placement",
      topic_focus: "SOAP Case Presentations, Multimorbidity Synthesis & Inpatient Rounding Skills",
      key_takeaways: [
        "Delivering concise, structured SOAP daily progress presentations on morning ward rounds",
        "Prioritizing complex multimorbid inpatients with active medical decision trees",
        "Effective interdisciplinary collaboration with pharmacy, nursing, and surgical consultants",
        "Acing internal medicine clinical viva and residency board examinations"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 9. Pharmacology & Prescription Writing
  // --------------------------------------------------------------------------
  'med-pharma': {
    0: [{
      id: "med-phar-p0-pkpd",
      title: "Clinical Pharmacokinetics & Pharmacodynamics First Principles",
      youtube_video_id: "m07ON7VA7VE",
      youtube_url: "https://www.youtube.com/watch?v=m07ON7VA7VE",
      fallback_video_id: "JDpg2tdHdq0",
      search_query: "Ninja Nerd Pharmacokinetics Absorption Distribution Metabolism Excretion ADME",
      channel_name: "Ninja Nerd",
      duration: "27:30",
      difficulty: "Beginner",
      topic_focus: "ADME, Bioavailability, Half-Life, Volume of Distribution & Clearance",
      key_takeaways: [
        "Understanding Absorption, Distribution, Metabolism (Cytochrome P450), and Excretion (ADME)",
        "Calculating drug half-life (t1/2), steady-state concentration (Css), and loading dose",
        "Agonist, antagonist, and partial agonist receptor interactions and therapeutic index",
        "Renal and hepatic dose adjustments based on creatinine clearance (Cockcroft-Gault)"
      ]
    }],
    1: [{
      id: "med-phar-p1-antibiotics",
      title: "Antibiotic Stewardship: Spectrum of Activity & Rational Prescribing",
      youtube_video_id: "GGtwJ-SGXTA",
      youtube_url: "https://www.youtube.com/watch?v=GGtwJ-SGXTA",
      fallback_video_id: "gqoqexfqoBM",
      search_query: "Ninja Nerd Antibiotics Mechanism of Action Penicillins Cephalosporins Carbapenems",
      channel_name: "Ninja Nerd",
      duration: "32:15",
      difficulty: "Intermediate",
      topic_focus: "Beta-Lactams, Fluoroquinolones, Macrolides, MRSA & Pseudomonas Coverage",
      key_takeaways: [
        "Classifying antibacterials: Cell wall inhibitors, protein synthesis inhibitors, DNA gyrase inhibitors",
        "Selecting empiric coverage for community-acquired vs hospital-acquired infections",
        "Targeting resistant pathogens: Vancomycin for MRSA, Piperacillin-Tazobactam and Meropenem for Pseudomonas",
        "Adhering to antimicrobial stewardship protocols to curb hospital superbug resistance"
      ]
    }],
    2: [{
      id: "med-phar-p2-cardio-drugs",
      title: "Cardiovascular Pharmacology: Inotropes, Antiarrhythmics & Antihypertensives",
      youtube_video_id: "u7baG79qefY",
      youtube_url: "https://www.youtube.com/watch?v=u7baG79qefY",
      fallback_video_id: "jtq70pwfENw",
      search_query: "Ninja Nerd Cardiovascular Pharmacology Antiarrhythmics Inotropes Vasopressors",
      channel_name: "Ninja Nerd",
      duration: "30:40",
      difficulty: "Advanced",
      topic_focus: "Vaughan Williams Antiarrhythmic Classes, Beta Blockers, Digoxin & Nitrates",
      key_takeaways: [
        "Vaughan Williams classification of antiarrhythmics (Class I to IV) and channel mechanisms",
        "Mechanisms of positive inotropes (Dobutamine, Milrinone) vs vasopressors (Norepinephrine, Vasopressin)",
        "Cardiovascular toxicity recognition: Digoxin toxicity, QT-prolongation and Torsades de Pointes",
        "Drug-drug interactions between cardiovascular medications and CYP3A4 inhibitors"
      ]
    }],
    3: [{
      id: "med-phar-p3-prescription",
      title: "Rational Prescription Writing & High-Alert Drug Safety Protocols",
      youtube_video_id: "wtMLypHAsfY",
      youtube_url: "https://www.youtube.com/watch?v=wtMLypHAsfY",
      fallback_video_id: "td_023eLTK0",
      search_query: "Geeky Medics Prescription Writing How to Write a Prescription Safely",
      channel_name: "Dr. Shamim PharmaConcepts",
      duration: "19:50",
      difficulty: "Advanced",
      topic_focus: "Prescription Anatomy, Dosage Units, Controlled Substances & Error Prevention",
      key_takeaways: [
        "Standard components of a legal prescription: Patient demographics, superscription, inscription, subscription, and signature",
        "Eliminating dangerous abbreviations (avoiding U, IU, QD, trailing zeroes like 5.0 mg)",
        "Safe prescribing of high-alert medications: Insulins, anticoagulants, opioids, and chemotherapy",
        "Documenting known drug allergies and checking cross-reactivity before dispensing"
      ]
    }],
    4: [{
      id: "med-phar-p4-viva",
      title: "Medical Pharmacology Board Viva & Clinical Prescribing Screening",
      youtube_video_id: "tA40wTqONKQ",
      youtube_url: "https://www.youtube.com/watch?v=tA40wTqONKQ",
      fallback_video_id: "FlY_zGZ9tvE",
      search_query: "Medical Pharmacology Viva Questions Drug Mechanism Adverse Effects",
      channel_name: "RegisteredNurseRN",
      duration: "28:10",
      difficulty: "Placement",
      topic_focus: "Clinical Pharmacotherapy Viva, Adverse Drug Reactions & Emergency Antidotes",
      key_takeaways: [
        "Rapid recall of emergency antidotes: Naloxone for opioids, Flumazenil for benzodiazepines, N-acetylcysteine for acetaminophen",
        "Explaining pharmacogenomic variability in drug response (CYP2D6, HLA-B*5701)",
        "Handling clinical pharmacology oral viva questions under examiner pressure",
        "Successfully demonstrating safe prescribing competency in clinical licensing exams"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 10. Pediatrics & Neonatal Resuscitation
  // --------------------------------------------------------------------------
  'med-pediatrics': {
    0: [{
      id: "med-ped-p0-nrp",
      title: "Neonatal Resuscitation Program (NRP): Initial Steps & Golden Minute Protocol",
      youtube_video_id: "8HL6JtJi-7s",
      youtube_url: "https://www.youtube.com/watch?v=8HL6JtJi-7s",
      fallback_video_id: "KE1YyF5dd0k",
      search_query: "Neonatal Resuscitation Program NRP Golden Minute Positive Pressure Ventilation",
      channel_name: "The Resuscitation Coach",
      duration: "24:30",
      difficulty: "Beginner",
      topic_focus: "Thermal Care, Airway Clearing, Positive Pressure Ventilation (PPV) & APGAR",
      key_takeaways: [
        "Executing the initial steps within 60 seconds: Warm, dry, stimulate, position airway, suction if needed",
        "Indications for Positive Pressure Ventilation (PPV): Apnea, gasping, or heart rate < 100 bpm",
        "MR. SOPA corrective ventilation steps (Mask, Reposition, Suction, Open mouth, Pressure, Alternative airway)",
        "APGAR scoring at 1 minute and 5 minutes: Appearance, Pulse, Grimace, Activity, Respiration"
      ]
    }],
    1: [{
      id: "med-ped-p1-development",
      title: "Pediatric Developmental Milestones & Growth Chart Assessment (WHO / CDC)",
      youtube_video_id: "eNHA9VNbuhk",
      youtube_url: "https://www.youtube.com/watch?v=eNHA9VNbuhk",
      fallback_video_id: "VVmMK4ZcPxY",
      search_query: "Geeky Medics Pediatric Developmental Milestones Gross Motor Fine Motor Speech",
      channel_name: "Rhesus Medicine",
      duration: "22:15",
      difficulty: "Intermediate",
      topic_focus: "Gross Motor, Fine Motor, Language & Social Milestones at 2, 4, 6, 9, 12, 18 Months",
      key_takeaways: [
        "Assessing key gross motor milestones: Neck holding (3m), sitting without support (6m), walking independently (12-15m)",
        "Fine motor development: Pincer grasp (9-10m), scribbling, tower building",
        "Speech and language milestones: Cooing, babbling, single words with meaning (12m), 2-word phrases (24m)",
        "Plotting height, weight, and head circumference on WHO percentile growth charts to detect failure to thrive"
      ]
    }],
    2: [{
      id: "med-ped-p2-fluids",
      title: "Pediatric Fluid Management, Dehydration Assessment & Electrolyte Correction",
      youtube_video_id: "soE0lyFl1pY",
      youtube_url: "https://www.youtube.com/watch?v=soE0lyFl1pY",
      fallback_video_id: "6JRdfazlkJk",
      search_query: "Ninja Nerd Pediatric Dehydration Assessment Holliday Segar Fluid Calculation",
      channel_name: "Med School Made Easy",
      duration: "25:45",
      difficulty: "Intermediate",
      topic_focus: "Holliday-Segar Maintenance Formula, 4-2-1 Rule, Mild/Moderate/Severe Dehydration",
      key_takeaways: [
        "Clinical grading of pediatric dehydration: Sunken eyes, skin turgor, capillary refill time, tears",
        "Calculating maintenance fluid requirements using the 100/50/20 mL/kg Holliday-Segar method",
        "Administering emergency fluid boluses (20 mL/kg isotonic crystalloid) in hypovolemic pediatric shock",
        "Safe potassium replenishment and avoiding rapid fluid shifts that cause cerebral edema"
      ]
    }],
    3: [{
      id: "med-ped-p3-emergencies",
      title: "Pediatric Acute Emergencies: Croup, Epiglottitis, Bronchiolitis & Febrile Seizures",
      youtube_video_id: "d-oXzSaz81s",
      youtube_url: "https://www.youtube.com/watch?v=d-oXzSaz81s",
      fallback_video_id: "owXhSD7XwUk",
      search_query: "MedCram Pediatric Respiratory Emergencies Croup Stridor Bronchiolitis Febrile Seizure",
      channel_name: "Level Up RN",
      duration: "27:10",
      difficulty: "Advanced",
      topic_focus: "Stridor vs Wheezing, Westley Croup Score, Nebulized Epinephrine & Dexamethasone",
      key_takeaways: [
        "Differentiating viral croup (barking cough, steeple sign) from life-threatening epiglottitis (thumbprint sign, drooling)",
        "Medical therapy for moderate-to-severe croup: Oral/IV Dexamethasone (0.6 mg/kg) and nebulized racemic epinephrine",
        "Evidence-based supportive management of viral bronchiolitis (RSV): Minimal handling, nasal suction, hydration",
        "Managing simple vs complex febrile seizures: Clarifying benign natural history to parents"
      ]
    }],
    4: [{
      id: "med-ped-p4-osce",
      title: "Pediatrics Clinical OSCE Examination, Vaccination Schedule & Viva Prep",
      youtube_video_id: "QaRD3CV5SI0",
      youtube_url: "https://www.youtube.com/watch?v=QaRD3CV5SI0",
      fallback_video_id: "JGfTLxPkWho",
      search_query: "Pediatric Clinical Examination OSCE National Immunization Schedule Viva",
      channel_name: "Six Minute Medics",
      duration: "29:50",
      difficulty: "Placement",
      topic_focus: "Pediatric History Taking, National Immunization Schedule & Clinical Viva",
      key_takeaways: [
        "Conducting empathetic pediatric history taking with parents and child observation",
        "Mastering the National Immunization Schedule: BCG, OPV, Pentavalent, Rotavirus, Measles-Rubella",
        "Safe pediatric drug dosage calculation by weight and body surface area",
        "Passing pediatric clinical OSCE stations and residency entrance viva voce"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 11. Obstetrics & Gynecology (OB-GYN)
  // --------------------------------------------------------------------------
  'med-obgyn': {
    0: [{
      id: "med-obg-p0-antenatal",
      title: "Antenatal Care & Obstetric Abdominal Examination (Leopold Maneuvers)",
      youtube_video_id: "-pkkgBX7OFQ",
      youtube_url: "https://www.youtube.com/watch?v=-pkkgBX7OFQ",
      fallback_video_id: "rx_yn_cN8gg",
      search_query: "Geeky Medics Obstetric Examination Leopold Maneuvers Fundal Height FHR",
      channel_name: "Geeky Medics",
      duration: "18:45",
      difficulty: "Beginner",
      topic_focus: "Symphysis-Fundal Height, Fundal/Lateral/Pelvic Grips & Fetal Heart Sounds",
      key_takeaways: [
        "Measuring symphysis-fundal height (SFH) in centimeters to detect SGA and LGA fetuses",
        "Performing the 4 Leopold maneuvers: Fundal grip, lateral umbilical grip, Pawlik grip, and pelvic grip",
        "Auscultating fetal heart rate (110-160 bpm) using Pinard stethoscope or handheld Doppler",
        "Routine antenatal screening: Blood grouping/Rh, oral glucose tolerance test, and anomaly ultrasound"
      ]
    }],
    1: [{
      id: "med-obg-p1-partograph",
      title: "Stages of Normal Labor & WHO Labor Care Guide / Partograph Monitoring",
      youtube_video_id: "ruIa1bC4tsw",
      youtube_url: "https://www.youtube.com/watch?v=ruIa1bC4tsw",
      fallback_video_id: "qYv9Fyf8wCA",
      search_query: "WHO Labor Care Guide Partograph Monitoring Cervical Dilatation Fetal Descent",
      channel_name: "Geeky Medics",
      duration: "23:20",
      difficulty: "Intermediate",
      topic_focus: "First/Second/Third Stages of Labor, Cervical Dilatation, Action & Alert Lines",
      key_takeaways: [
        "Recognizing active first stage of labor (cervical dilatation >= 5 cm) and normal progression rate",
        "Plotting cervical dilatation and fetal head descent on the partograph across Alert and Action lines",
        "Monitoring uterine contraction frequency, duration, and fetal heart rate decelerations",
        "Active Management of the Third Stage of Labor (AMTSL): Prophylactic oxytocin (10 IU IM), controlled cord traction"
      ]
    }],
    2: [{
      id: "med-obg-p2-pph",
      title: "Postpartum Hemorrhage (PPH) Management & Obstetric Emergency Protocols",
      youtube_video_id: "aaV2MeDi7qI",
      youtube_url: "https://www.youtube.com/watch?v=aaV2MeDi7qI",
      fallback_video_id: "wo-5RRlOmog",
      search_query: "Postpartum Hemorrhage PPH Protocol Uterine Atony Bakri Balloon B-Lynch",
      channel_name: "IQ NURSING PATHSHALA",
      duration: "26:50",
      difficulty: "Advanced",
      topic_focus: "The 4 Ts (Tone, Tissue, Trauma, Thrombin), Uterotonics & Bakri Balloon Tamponade",
      key_takeaways: [
        "Diagnosing primary PPH (>500 mL vaginal, >1000 mL cesarean) and identifying the 4 Ts",
        "Stepwise uterotonic therapy: Oxytocin infusion, Ergometrine, Carboprost (PGF2alpha), Misoprostol",
        "Bimanual uterine compression and aortic compression for immediate hemostasis",
        "Surgical interventions: Intrauterine Bakri balloon tamponade, B-Lynch brace suturing, uterine artery ligation"
      ]
    }],
    3: [{
      id: "med-obg-p3-preeclampsia",
      title: "Hypertensive Disorders in Pregnancy: Preeclampsia & Eclampsia Magnesium Sulfate Protocol",
      youtube_video_id: "k_bQh3oXNdY",
      youtube_url: "https://www.youtube.com/watch?v=k_bQh3oXNdY",
      fallback_video_id: "CRhGx8A7Dqg",
      search_query: "Preeclampsia Eclampsia Magnesium Sulfate Pritchard Protocol Labetalol",
      channel_name: "OBS & GYNO PROFESSOR",
      duration: "25:35",
      difficulty: "Advanced",
      topic_focus: "Gestational Hypertension, Proteinuria, HELLP Syndrome & MgSO4 Pritchard Regimen",
      key_takeaways: [
        "Diagnostic criteria for preeclampsia: BP >= 140/90 after 20 weeks with proteinuria or end-organ dysfunction",
        "Identifying severe features and HELLP syndrome (Hemolysis, Elevated Liver enzymes, Low Platelets)",
        "Administering Magnesium Sulfate for eclampsia seizure prophylaxis: Pritchard / Zuspan protocol (4g IV loading dose)",
        "Monitoring magnesium toxicity (patellar reflex, respiratory rate >=16, urine output >30 mL/hr) and antidote Calcium Gluconate"
      ]
    }],
    4: [{
      id: "med-obg-p4-viva",
      title: "Obstetrics & Gynecology Clinical Board Viva & OSCE Labor Ward Simulation",
      youtube_video_id: "o6zVZR5-TTs",
      youtube_url: "https://www.youtube.com/watch?v=o6zVZR5-TTs",
      fallback_video_id: "cp5sNRWUaVg",
      search_query: "OBGYN Clinical Viva Questions Forceps Vacuum Delivery Episiotomy OSCE",
      channel_name: "medicos",
      duration: "31:15",
      difficulty: "Placement",
      topic_focus: "Operative Vaginal Delivery (Ventouse/Forceps), Episiotomy Repair & Board Viva",
      key_takeaways: [
        "Indications and prerequisites for instrumental delivery: Fully dilated, engaged head, ruptured membranes",
        "Performing and repairing medio-lateral episiotomy in layers to prevent 3rd/4th degree tears",
        "Gynecological differential diagnosis of abnormal uterine bleeding (PALM-COEIN classification)",
        "Excelling in OB-GYN clinical viva stations and post-graduate residency exams"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 12. Critical Care & Hemodynamic Monitoring
  // --------------------------------------------------------------------------
  'med-icu': {
    0: [{
      id: "med-icu-p0-vent-basics",
      title: "Mechanical Ventilation for Beginners: Modes, Settings & Waveform Interpretation",
      youtube_video_id: "E5uLM41URmE",
      youtube_url: "https://www.youtube.com/watch?v=E5uLM41URmE",
      fallback_video_id: "uuAEWlcY12Q",
      search_query: "MedCram Mechanical Ventilation Explained Modes Settings Tidal Volume PEEP",
      channel_name: "ICU Advantage",
      duration: "28:40",
      difficulty: "Beginner",
      topic_focus: "Volume Control (VC) vs Pressure Control (PC), PEEP, FiO2 & Plateau Pressure",
      key_takeaways: [
        "Differentiating control variables: Volume-cycled ventilation vs pressure-limited ventilation",
        "Core ventilator parameters: Tidal volume (6-8 mL/kg predicted body weight), respiratory rate, PEEP, FiO2",
        "Interpreting flow-time and pressure-time scalar waveforms on ICU bedside ventilator displays",
        "Preventing barotrauma by maintaining plateau pressure (Pplat) strictly below 30 cmH2O"
      ]
    }],
    1: [{
      id: "med-icu-p1-hemodynamics",
      title: "Invasive Hemodynamic Monitoring: Arterial Lines, CVP & Cardiac Output",
      youtube_video_id: "UbwdbK2inZY",
      youtube_url: "https://www.youtube.com/watch?v=UbwdbK2inZY",
      fallback_video_id: "58bZlwG1h3Q",
      search_query: "Ninja Nerd Hemodynamic Monitoring Arterial Line Central Venous Pressure CVP",
      channel_name: "ICU Advantage",
      duration: "26:50",
      difficulty: "Intermediate",
      topic_focus: "Arterial Line Transduction, Dicrotic Notch, Over/Under Damping & CVP Trends",
      key_takeaways: [
        "Setting up and zeroing the transducer at the phlebostatic axis (4th intercostal space, mid-axillary line)",
        "Interpreting arterial pressure waveforms: Systolic upstroke, dicrotic notch, pulse pressure variation (PPV)",
        "Performing the fast-flush square-wave test to diagnose overdamping vs underdamping artifacts",
        "Central Venous Pressure (CVP) catheter waveform analysis: a, c, v waves and x, y descents"
      ]
    }],
    2: [{
      id: "med-icu-p2-vasopressors",
      title: "Vasopressor & Inotrope Titration in Shock States: Receptors & Hemodynamic Goals",
      youtube_video_id: "mR6EMZYL9UM",
      youtube_url: "https://www.youtube.com/watch?v=mR6EMZYL9UM",
      fallback_video_id: "zf28Rjbu3VM",
      search_query: "Ninja Nerd Vasopressors Inotropes Norepinephrine Epinephrine Vasopressin Dobutamine",
      channel_name: "ICU Advantage",
      duration: "31:20",
      difficulty: "Advanced",
      topic_focus: "Alpha-1, Beta-1, Beta-2 & V1 Receptor Profiles, Titration & MAP Targets",
      key_takeaways: [
        "Receptor pharmacology: Norepinephrine (Alpha-1 > Beta-1), Epinephrine (Beta-1 + Alpha-1), Vasopressin (V1a)",
        "Selecting inotropic support for cardiogenic shock: Dobutamine and Milrinone mechanisms",
        "Executing peripheral to central line vasopressor transition safely to avoid extravasation necrosis",
        "Dynamic assessment of fluid responsiveness: Passive leg raise test (PLR) and stroke volume changes"
      ]
    }],
    3: [{
      id: "med-icu-p3-ards",
      title: "Acute Respiratory Distress Syndrome (ARDS) Management & Prone Positioning Protocol",
      youtube_video_id: "6nPufC7nKAg",
      youtube_url: "https://www.youtube.com/watch?v=6nPufC7nKAg",
      fallback_video_id: "FS4t5w1eCYw",
      search_query: "MedCram ARDS Net Protocol Lung Protective Ventilation Prone Positioning",
      channel_name: "ICU Advantage",
      duration: "29:30",
      difficulty: "Advanced",
      topic_focus: "Berlin Definition, PaO2/FiO2 Ratio, Low Tidal Volume (4-6 mL/kg) & Proning >16h",
      key_takeaways: [
        "Berlin ARDS definition: Bilateral infiltrates within 7 days, non-cardiogenic edema, PaO2/FiO2 <= 300",
        "Implementing ARDSNet lung-protective ventilation: Low tidal volume (4-6 mL/kg PBW) and permissive hypercapnia",
        "High PEEP titration tables to recruit atelectatic alveoli and improve oxygenation",
        "Prone positioning protocol: Mechanics of dorsal lung recruitment, evidence for 16-hour continuous proning"
      ]
    }],
    4: [{
      id: "med-icu-p4-grand-rounds",
      title: "ICU Multidisciplinary Grand Rounds & Critical Care Fellowship Viva Prep",
      youtube_video_id: "R8Q-9D4I_pc",
      youtube_url: "https://www.youtube.com/watch?v=R8Q-9D4I_pc",
      fallback_video_id: "u1J1ywhUQs8",
      search_query: "Critical Care Fellowship Interview ICU Rounds Sepsis Bundle Ventilator Weaning",
      channel_name: "Stethoscope 360",
      duration: "33:10",
      difficulty: "Placement",
      topic_focus: "ICU Daily FAST-HUG Bedside Bundle, Ventilator Weaning Trials & Board Viva",
      key_takeaways: [
        "Systematic daily FAST-HUGS BID check: Feeding, Analgesia, Sedation, Thromboembolism, Head of bed, Ulcer, Glucose",
        "Spontaneous Breathing Trials (SBT) and Rapid Shallow Breathing Index (RSBI < 105) for extubation readiness",
        "Troubleshooting acute ventilator dyssynchrony: Secretions, pneumothorax, bronchospasm, auto-PEEP",
        "Acing intensive care medicine viva questions and clinical fellowship entrance interviews"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 13. Medical Ethics & Medico-Legal Laws
  // --------------------------------------------------------------------------
  'med-ethics': {
    0: [{
      id: "med-eth-p0-consent",
      title: "Informed Consent, Autonomy & Capacity Assessment in Clinical Practice",
      youtube_video_id: "BgI5_hzsrcU",
      youtube_url: "https://www.youtube.com/watch?v=BgI5_hzsrcU",
      fallback_video_id: "doBQS2SNn4Q",
      search_query: "Medical Ethics Informed Consent Autonomy Competence Mental Capacity",
      channel_name: "Medcrine",
      duration: "21:40",
      difficulty: "Beginner",
      topic_focus: "The 4 Principles of Bioethics: Autonomy, Beneficence, Non-Maleficence & Justice",
      key_takeaways: [
        "The four foundational pillars of biomedical ethics: Autonomy, beneficence, non-maleficence, and justice",
        "Elements of legally valid informed consent: Voluntariness, full disclosure, comprehension, and decision capacity",
        "Assessing decision-making capacity in patients with delirium, dementia, or psychiatric conditions",
        "Emergency doctrine: Providing life-saving medical care to unconscious patients without consent"
      ]
    }],
    1: [{
      id: "med-eth-p1-confidentiality",
      title: "Patient Confidentiality, HIPAA / DPDP Compliance & Medico-Legal Exceptions",
      youtube_video_id: "CS4Q5EMHVEY",
      youtube_url: "https://www.youtube.com/watch?v=CS4Q5EMHVEY",
      fallback_video_id: "E6_5-Ei46Pw",
      search_query: "Patient Confidentiality HIPAA Exceptions Disclosure Tarasoff Duty to Warn",
      channel_name: "Clover Learning",
      duration: "19:25",
      difficulty: "Intermediate",
      topic_focus: "Protected Health Information (PHI), Tarasoff Duty to Protect & Notifiable Diseases",
      key_takeaways: [
        "Safeguarding electronic health records and maintaining strict bedside confidentiality",
        "Legal exceptions to medical secrecy: Statutory reporting of notifiable infectious diseases and gunshot/stab wounds",
        "Tarasoff rule: Duty to warn and protect identified third parties from imminent violent threats",
        "Adhering to medical council professional misconduct guidelines and digital privacy standards"
      ]
    }],
    2: [{
      id: "med-eth-p2-negligence",
      title: "Medical Negligence, Bolam / Montgomery Tests & Consumer Protection Law",
      youtube_video_id: "h1kmvZoXmAg",
      youtube_url: "https://www.youtube.com/watch?v=h1kmvZoXmAg",
      fallback_video_id: "skc69ipuHTQ",
      search_query: "Medical Negligence Bolam Test Montgomery Duty of Care Consumer Protection Act",
      channel_name: "JHP Medical UK",
      duration: "24:50",
      difficulty: "Intermediate",
      topic_focus: "Duty of Care, Breach, Causation, Bolam Standard & Material Risk Disclosure",
      key_takeaways: [
        "Four elements of actionable tort negligence: Duty of care owed, breach of duty, harm, and direct proximate causation",
        "The landmark Bolam test: Measuring clinical standard of care against responsible peer body opinion",
        "Shift to Montgomery standard: Mandatory disclosure of material risks that a reasonable patient would consider significant",
        "Medical indemnity insurance, defensive documentation, and preventing clinical lawsuits"
      ]
    }],
    3: [{
      id: "med-eth-p3-endoflife",
      title: "End-of-Life Care Ethics: DNR Orders, Brain Death Certification & Organ Donation",
      youtube_video_id: "jiIRlHnqBDM",
      youtube_url: "https://www.youtube.com/watch?v=jiIRlHnqBDM",
      fallback_video_id: "-H6-yUpzdt4",
      search_query: "Brain Death Certification Protocol Apnea Test DNR Orders Organ Donation Ethics",
      channel_name: "OAC,MD",
      duration: "26:30",
      difficulty: "Advanced",
      topic_focus: "Brainstem Reflexes, Apnea Testing, Advance Directives & Living Wills",
      key_takeaways: [
        "Standard clinical protocol for brain death certification: Absence of all brainstem reflexes and formal apnea test",
        "Ethical distinction between withholding/withdrawing non-beneficial life support vs active euthanasia",
        "Implementing Do Not Resuscitate (DNR) / DNACPR orders with family consensus and documentation",
        "Coordinating with organ transplant networks (NOTTO) for ethical deceased organ retrieval"
      ]
    }],
    4: [{
      id: "med-eth-p4-viva",
      title: "Forensic Medicine & Medico-Legal Jurisprudence Board Examination Viva",
      youtube_video_id: "r35F5o0rSpY",
      youtube_url: "https://www.youtube.com/watch?v=r35F5o0rSpY",
      fallback_video_id: "ri3LbDe-Y1A",
      search_query: "Forensic Medicine Medico Legal Report MLR Injury Report Death Certificate Viva",
      channel_name: "Pursuit of Medicine",
      duration: "27:45",
      difficulty: "Placement",
      topic_focus: "Medico-Legal Reports (MLR), Post-Mortem Documentation & Court Testimony Skills",
      key_takeaways: [
        "Drafting accurate Medico-Legal Injury Reports (MLR): Simple vs grievous hurt classification",
        "Proper completion of Medical Certification of Cause of Death (MCCD) without vague terminology",
        "Appearing as an expert medical witness in court: Deposition protocol, subpoena compliance, and cross-examination",
        "Acing forensic medicine and medical ethics viva in university licensing examinations"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 14. Infectious Diseases & Infection Control
  // --------------------------------------------------------------------------
  'med-infectious': {
    0: [{
      id: "med-inf-p0-precautions",
      title: "Hospital Infection Control: Standard Precautions & PPE Donning/Doffing",
      youtube_video_id: "g9Fvf4tlT9Q",
      youtube_url: "https://www.youtube.com/watch?v=g9Fvf4tlT9Q",
      fallback_video_id: "1W8Ai1avL7A",
      search_query: "WHO Hospital Infection Control Standard Precautions PPE Donning Doffing Hand Hygiene",
      channel_name: "RajNEET Medical Education",
      duration: "19:15",
      difficulty: "Beginner",
      topic_focus: "WHO 5 Moments of Hand Hygiene, Contact/Droplet/Airborne Isolation & PPE Sequences",
      key_takeaways: [
        "The WHO 5 Moments for Hand Hygiene: Before patient contact, before aseptic task, after body fluid exposure, after patient contact, after surroundings",
        "Transmission-based isolation categories: Contact isolation (C. diff, MRSA), droplet (Influenza), airborne (TB, Measles)",
        "Strict step-by-step sequence for donning and doffing Personal Protective Equipment (PPE) to avoid self-contamination",
        "Sharps safety protocols and post-exposure prophylaxis (PEP) for accidental needlestick injuries"
      ]
    }],
    1: [{
      id: "med-inf-p1-tb-hiv",
      title: "Tuberculosis & HIV Management: Diagnostic Algorithms & DOTS/ART Regimens",
      youtube_video_id: "6P6zBHpWiGA",
      youtube_url: "https://www.youtube.com/watch?v=6P6zBHpWiGA",
      fallback_video_id: "NNdeEUaW7Ng",
      search_query: "Ninja Nerd Tuberculosis Pathophysiology Mantoux GeneXpert RIF Resistance HIV ART",
      channel_name: "Osmosis from Elsevier",
      duration: "31:40",
      difficulty: "Intermediate",
      topic_focus: "GeneXpert NAAT, Primary vs Secondary TB, Rifampicin Resistance & 1st Line HRZE",
      key_takeaways: [
        "Diagnostic pathway for pulmonary and extrapulmonary TB: Sputum microscopy, GeneXpert (CBNAAT) for rifampicin resistance",
        "Standard 4-drug intensive phase regimen: Isoniazid, Rifampicin, Pyrazinamide, Ethambutol (HRZE) and hepatotoxicity monitoring",
        "Screening and monitoring HIV infection: CD4 count, viral load quantification, and integrase-inhibitor based ART",
        "Opportunistic infections prophylaxis: Cotrimoxazole for PCP and toxoplasmosis in advanced immunosuppression"
      ]
    }],
    2: [{
      id: "med-inf-p2-hai",
      title: "Healthcare-Associated Infections (HAI): CAUTI, CLABSI, VAP & SSI Prevention",
      youtube_video_id: "hibSUK3tzJc",
      youtube_url: "https://www.youtube.com/watch?v=hibSUK3tzJc",
      fallback_video_id: "YdR3TPNfMec",
      search_query: "Hospital Acquired Infections Prevention Bundles CLABSI CAUTI VAP SSI CDC",
      channel_name: "Basic Medical Practice",
      duration: "25:10",
      difficulty: "Intermediate",
      topic_focus: "Evidence-Based Prevention Bundles, Chlorhexidine Prep, Daily Line Necessity Reviews",
      key_takeaways: [
        "Central Line-Associated Bloodstream Infection (CLABSI) insertion and maintenance bundles: Full sterile drape, chlorhexidine skin prep",
        "Catheter-Associated Urinary Tract Infection (CAUTI) prevention: Aseptic insertion, dependent drainage bag, prompt removal",
        "Ventilator-Associated Pneumonia (VAP) bundle: 30-45 degree head elevation, daily sedation vacations, oral chlorhexidine hygiene",
        "Surgical Site Infection (SSI) bundle: Preoperative hair clipping (not shaving), antibiotic timing within 60 min of incision"
      ]
    }],
    3: [{
      id: "med-inf-p3-antimicrobial",
      title: "Antimicrobial Resistance & Superbug Management (MDR/XDR, CRE & MRSA)",
      youtube_video_id: "057phDG4mKU",
      youtube_url: "https://www.youtube.com/watch?v=057phDG4mKU",
      fallback_video_id: "HZ4udzNJbrs",
      search_query: "Ninja Nerd Antimicrobial Resistance Mechanisms Carbapenem Resistant Enterobacteriaceae MRSA",
      channel_name: "Armando Hasudungan",
      duration: "28:35",
      difficulty: "Advanced",
      topic_focus: "Beta-Lactamases (ESBL, NDM-1), Efflux Pumps, Colistin & Novel Antibiotic Combinations",
      key_takeaways: [
        "Mechanisms of bacterial resistance: Extended-spectrum beta-lactamases (ESBL), carbapenemases (NDM, KPC), and altered PBPs",
        "Clinical strategies for treating multi-drug resistant Gram-negative pathogens: Ceftazidime-avibactam, Polymyxin B, Colistin",
        "Vancomycin-resistant enterococci (VRE) management: Linezolid, Daptomycin, Tigecycline indications",
        "Executing hospital antibiotic restriction policies and de-escalation based on definitive culture sensitivity reports"
      ]
    }],
    4: [{
      id: "med-inf-p4-viva",
      title: "Infectious Diseases Fellowship Viva & Hospital Infection Control Screening",
      youtube_video_id: "kUlKRIMxpZQ",
      youtube_url: "https://www.youtube.com/watch?v=kUlKRIMxpZQ",
      fallback_video_id: "2JWku3Kjpq0",
      search_query: "Infectious Diseases Clinical Viva Outbreak Investigation Contact Tracing Epidemics",
      channel_name: "Let's Learn Public Health",
      duration: "30:45",
      difficulty: "Placement",
      topic_focus: "Outbreak Investigation Steps, Epicurves, Epidemic Response & Board Viva",
      key_takeaways: [
        "The 10 standard steps of hospital outbreak investigation: Confirm diagnosis, establish case definition, construct epidemic curve",
        "Airborne infection isolation room (AIIR) engineering controls: Negative pressure ventilation and 12 air changes per hour",
        "Syndromic management of acute febrile illness: Malaria, Dengue, Leptospirosis, Enteric fever differentiation",
        "Excelling in hospital infection control committee interviews and infectious disease board screening"
      ]
    }]
  },

  // ==========================================================================
  // NURSING CO-DOMAINS
  // ==========================================================================

  // --------------------------------------------------------------------------
  // 15. Clinical Patient Care & Bedside Nursing
  // --------------------------------------------------------------------------
  'nurs-care': {
    0: [{
      id: "nurs-care-p0-vitals",
      title: "Vital Signs Assessment, NEWS2 Scoring & Clinical Bedside Charting",
      youtube_video_id: "gUWJ-6nL5-8",
      youtube_url: "https://www.youtube.com/watch?v=gUWJ-6nL5-8",
      fallback_video_id: "-DTVZtp-ARM",
      search_query: "RegisteredNurseRN Vital Signs Assessment Blood Pressure Pulse Oximetry NEWS2",
      channel_name: "RegisteredNurseRN",
      duration: "21:30",
      difficulty: "Beginner",
      topic_focus: "Temperature, Pulse, Respirations, BP Cuff Sizing, SpO2 & Early Warning Signs",
      key_takeaways: [
        "Proper blood pressure measurement technique and cuff size selection to avoid erroneous readings",
        "Assessing respiratory rate unobtrusively while palpating radial pulse for accurate counts",
        "National Early Warning Score (NEWS2) escalation triggers for deteriorating adult inpatients",
        "Accurate clinical fluid balance chart documentation: Intake vs output calculations"
      ]
    }],
    1: [{
      id: "nurs-care-p1-catheter",
      title: "Male & Female Foley Catheterization: Sterile Aseptic Procedure Demonstration",
      youtube_video_id: "5WSdQ0M_xQc",
      youtube_url: "https://www.youtube.com/watch?v=5WSdQ0M_xQc",
      fallback_video_id: "fGCwMWod3BM",
      search_query: "RegisteredNurseRN Foley Catheter Insertion Male Female Sterile Procedure",
      channel_name: "RegisteredNurseRN",
      duration: "18:50",
      difficulty: "Intermediate",
      topic_focus: "Sterile Drape Setup, Peri-Care, Catheter Lubrication & Balloon Inflation",
      key_takeaways: [
        "Maintaining absolute sterile technique throughout catheter tray preparation and insertion",
        "Anatomical differences and positioning for female vs male urinary catheterization",
        "Confirming urine flashback before inflating the retention balloon with sterile water (never saline)",
        "Securing catheter tubing to prevent traction and practicing CAUTI prevention protocols"
      ]
    }],
    2: [{
      id: "nurs-care-p2-ng-tube",
      title: "Nasogastric (NG) Tube Insertion, Placement Verification & Enteral Feeding",
      youtube_video_id: "fwvVdw3tzg0",
      youtube_url: "https://www.youtube.com/watch?v=fwvVdw3tzg0",
      fallback_video_id: "WZvIw0SnYrE",
      search_query: "Geeky Medics Nasogastric Tube Insertion NG Tube Verification Enteral Nutrition",
      channel_name: "NURSINGcom",
      duration: "17:40",
      difficulty: "Intermediate",
      topic_focus: "NEX Measurement, Water Swallow Technique, Gastric Aspirate pH & Radiography",
      key_takeaways: [
        "Measuring insertion length: Nose to earlobe to xiphoid process (NEX distance) plus 5-10 cm",
        "Patient positioning and swallowing water to facilitate smooth esophageal passage",
        "Gold standard verification of gastric placement: Aspirate pH <= 5.5 and chest X-ray confirmation",
        "Flushing protocols before and after medication administration to prevent enteral tube occlusion"
      ]
    }],
    3: [{
      id: "nurs-care-p3-iv-cannula",
      title: "Intravenous (IV) Cannulation Technique, Fluid Infusion Rates & Complications",
      youtube_video_id: "ue96cuS-lNs",
      youtube_url: "https://www.youtube.com/watch?v=ue96cuS-lNs",
      fallback_video_id: "vE99rZ7JT3Q",
      search_query: "Geeky Medics IV Cannulation Insertion Technique Flashback Dressing Tourniquet",
      channel_name: "RegisteredNurseRN",
      duration: "19:20",
      difficulty: "Advanced",
      topic_focus: "Vein Selection, 18G/20G Cannula Insertion, Primary/Secondary Flashback & VIP Score",
      key_takeaways: [
        "Selecting appropriate gauge (16G/18G resuscitation vs 20G/22G maintenance fluids)",
        "Visualizing and palpating engorged forearm and dorsal hand veins using a tourniquet",
        "Recognizing primary needle flashback and secondary catheter advancement flashback",
        "Monitoring Visual Infusion Phlebitis (VIP) score to detect early infiltration and thrombophlebitis"
      ]
    }],
    4: [{
      id: "nurs-care-p4-nclex-prep",
      title: "NCLEX-RN Bedside Nursing Clinical Simulation & Staff Nurse Hospital Placement Viva",
      youtube_video_id: "11hP8FOywiY",
      youtube_url: "https://www.youtube.com/watch?v=11hP8FOywiY",
      fallback_video_id: "Bpz5BdSzsdM",
      search_query: "RegisteredNurseRN NCLEX Delegation Prioritization Clinical Nursing Interview",
      channel_name: "RegisteredNurseRN",
      duration: "32:15",
      difficulty: "Placement",
      topic_focus: "Patient Prioritization (Airway-Breathing-Circulation), Delegation & Clinical Viva",
      key_takeaways: [
        "Applying ABC (Airway, Breathing, Circulation) and Maslow's hierarchy in multi-patient prioritization",
        "Delegating tasks appropriately to Licensed Practical Nurses (LPN) and Unlicensed Assistive Personnel (UAP)",
        "Structured SBAR communication (Situation, Background, Assessment, Recommendation) when reporting to physicians",
        "Acing hospital staff nurse interview scenarios, clinical skills tests, and NCLEX-RN exams"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 16. ICU Hemodynamic & Ventilator Monitoring (Nursing)
  // --------------------------------------------------------------------------
  'nurs-icu': {
    0: [{
      id: "nurs-icu-p0-ett-suction",
      title: "Endotracheal Tube (ETT) Care, In-Line Suctioning & Oral Hygiene in ICU Patients",
      youtube_video_id: "7r4I2B1YXq0",
      youtube_url: "https://www.youtube.com/watch?v=7r4I2B1YXq0",
      fallback_video_id: "FVJ_09VKooA",
      search_query: "RegisteredNurseRN Endotracheal Tube Care Suctioning VAP Bundle Closed Suction",
      channel_name: "Chandan Pandey",
      duration: "20:45",
      difficulty: "Beginner",
      topic_focus: "Closed Suction Catheter Technique, Pre-Oxygenation, Cuff Pressure & Securement",
      key_takeaways: [
        "Indications for endotracheal suctioning: Coarse breath sounds, coughing, high peak inspiratory pressure",
        "Pre-oxygenating with 100% FiO2 for 1-2 minutes prior to closed in-line catheter advancement",
        "Limiting suction duration to <= 10-15 seconds while withdrawing with intermittent suction",
        "Monitoring and maintaining endotracheal tube cuff pressure between 20-30 cmH2O to prevent tracheal necrosis"
      ]
    }],
    1: [{
      id: "nurs-icu-p1-aline",
      title: "Arterial Line Setup, Transducer Calibration & Blood Sampling for Nurses",
      youtube_video_id: "c5mQK4tK864",
      youtube_url: "https://www.youtube.com/watch?v=c5mQK4tK864",
      fallback_video_id: "0xFBy7J71y4",
      search_query: "Arterial Line Nursing Care Transducer Leveling Zeroing Blood Sampling ABG",
      channel_name: "RegisteredNurseRN",
      duration: "23:15",
      difficulty: "Intermediate",
      topic_focus: "Leveling to Phlebostatic Axis, Continuous Flush System & Waste-Free ABG Sampling",
      key_takeaways: [
        "Assembling the pressurized bag (300 mmHg) with normal saline and pressure transducer kit",
        "Leveling the air-fluid interface stopcock precisely to the phlebostatic axis and performing atmospheric zeroing",
        "Drawing arterial blood gas (ABG) samples using closed needleless blood transfer systems",
        "Regular distal limb neurovascular checks to ensure patent circulation and prevent radial artery thrombosis"
      ]
    }],
    2: [{
      id: "nurs-icu-p2-sedation",
      title: "ICU Sedation Protocols: Richmond Agitation-Sedation Scale (RASS) & CAM-ICU Delirium",
      youtube_video_id: "-jnUsQIzSUs",
      youtube_url: "https://www.youtube.com/watch?v=-jnUsQIzSUs",
      fallback_video_id: "3GylI7AU3_8",
      search_query: "MedCram RASS Score CAM ICU Delirium Assessment ICU Sedation Titration",
      channel_name: "ICU REACH",
      duration: "22:40",
      difficulty: "Intermediate",
      topic_focus: "RASS Scoring (-5 to +4), Daily Sedation Vacations, Propofol/Dexmedetomidine & Delirium",
      key_takeaways: [
        "Utilizing the RASS scale to titrate continuous sedative infusions to a light sedation target (-1 to 0)",
        "Conducting daily spontaneous awakening trials (SAT) / sedation vacations to reduce ventilator days",
        "Screening for ICU delirium using the Confusion Assessment Method for the ICU (CAM-ICU)",
        "Implementing non-pharmacological delirium prevention: Early mobility, day-night circadian light cycles"
      ]
    }],
    3: [{
      id: "nurs-icu-p3-titration",
      title: "Continuous Vasoactive Infusion Titration & ICU Cardiac Monitor Alarms",
      youtube_video_id: "VxiDH8HpClw",
      youtube_url: "https://www.youtube.com/watch?v=VxiDH8HpClw",
      fallback_video_id: "-03v5sXE8uc",
      search_query: "ICU Nurse Vasopressor Titration Norepinephrine Dobutamine Syringe Pump Alarms",
      channel_name: "Future-RN NCLEX Review",
      duration: "27:50",
      difficulty: "Advanced",
      topic_focus: "Norepinephrine mcg/min & mcg/kg/min Calculations, Dedicated Central Lumen & Double-Checking",
      key_takeaways: [
        "Double-checking high-risk vasoactive medication concentrations and smart infusion pump programming",
        "Titrating vasopressor rates strictly according to ordered MAP parameters (e.g. titrate by 2 mcg/min q5min to MAP >= 65)",
        "Preventing sudden drug interruptions: Preparing replacement syringes well before the current infusion finishes",
        "Appropriately responding to clinical alarm fatigue while addressing red high-priority monitor alarms"
      ]
    }],
    4: [{
      id: "nurs-icu-p4-icu-interview",
      title: "ICU Staff Nurse Placement Interview Screening & Critical Care Competency Viva",
      youtube_video_id: "Mp3UWhlOO5U",
      youtube_url: "https://www.youtube.com/watch?v=Mp3UWhlOO5U",
      fallback_video_id: "NAsom4eqO1I",
      search_query: "ICU Nursing Interview Questions Critical Care Scenarios Hemodynamics Viva",
      channel_name: "Mihiraa OET",
      duration: "31:10",
      difficulty: "Placement",
      topic_focus: "ICU Clinical Scenarios, Sudden Hypotension Response, Ventilator Alarms & Placement Viva",
      key_takeaways: [
        "Systematic response to acute clinical decompensation in mechanically ventilated ICU patients",
        "Troubleshooting sudden high peak pressure alarms (DOPES: Displacement, Obstruction, Pneumothorax, Equipment, Stacking)",
        "Demonstrating composure, clinical prioritization, and clear communication under high-stress conditions",
        "Excelling in tertiary care hospital intensive care unit staffing interviews and CCRN qualification vivas"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 17. Emergency Triage & Rapid Code Blue Response (Nursing)
  // --------------------------------------------------------------------------
  'nurs-triage': {
    0: [{
      id: "nurs-tri-p0-esi",
      title: "Emergency Severity Index (ESI) Triage Algorithm: Levels 1 through 5",
      youtube_video_id: "qPWgr2u29_8",
      youtube_url: "https://www.youtube.com/watch?v=qPWgr2u29_8",
      fallback_video_id: "EX3enduJ3UE",
      search_query: "Emergency Severity Index ESI Triage Levels 1 to 5 Emergency Nursing Assessment",
      channel_name: "Lindsay Higgins",
      duration: "24:15",
      difficulty: "Beginner",
      topic_focus: "Immediate Life Threats (Level 1), High Risk (Level 2), Resources Required (Levels 3-5)",
      key_takeaways: [
        "Rapidly identifying ESI Level 1: Immediate life-saving intervention needed (unresponsive, severe respiratory distress)",
        "Identifying ESI Level 2: High risk situation, confused/lethargic/disoriented, or severe pain/distress",
        "Predicting healthcare resource utilization (labs, ECG, imaging, IV fluids) to differentiate Levels 3, 4, and 5",
        "Assessing pediatric vital sign warning zones during initial triage window (<5 minutes)"
      ]
    }],
    1: [{
      id: "nurs-tri-p1-crash-cart",
      title: "Crash Cart Anatomy & Defibrillator Operations for Emergency Nurses",
      youtube_video_id: "ooqrZ0r-iqs",
      youtube_url: "https://www.youtube.com/watch?v=ooqrZ0r-iqs",
      fallback_video_id: "QFww8xECfaA",
      search_query: "Emergency Nurse Crash Cart Equipment Defibrillator Operation Daily Checklist",
      channel_name: "Nursing Talk",
      duration: "21:40",
      difficulty: "Intermediate",
      topic_focus: "Crash Cart Drawers (Airway, IV/Lines, Drugs), Defibrillator Biphasic Pads & Shift Checks",
      key_takeaways: [
        "Daily crash cart readiness check: Expiry dates, battery status, oxygen tanks, and tamper-evident seal verification",
        "Drawer 1 emergency medications: Epinephrine 1:10,000, Amiodarone, Atropine, Dextrose 50%, Sodium Bicarbonate",
        "Drawer 2 airway equipment: Laryngoscope blades, handles, ETT sizes (6.0-8.5), stylets, and BVM masks",
        "Operating manual and automated biphasic defibrillators: Pad placement, energy selection (200J), charging and clearing"
      ]
    }],
    2: [{
      id: "nurs-tri-p2-code-blue",
      title: "Code Blue Team Roles & Nursing Responsibilities During In-Hospital Cardiac Arrest",
      youtube_video_id: "4cgvmHU-krw",
      youtube_url: "https://www.youtube.com/watch?v=4cgvmHU-krw",
      fallback_video_id: "uYynw4t2hp4",
      search_query: "Code Blue Team Roles Emergency Nurse Recorder Medication Compressor Airway",
      channel_name: "Atreya Hospital",
      duration: "26:30",
      difficulty: "Intermediate",
      topic_focus: "First Responder, Airway Nurse, Compressor, Medication Nurse & Code Recorder Documentation",
      key_takeaways: [
        "First responder actions: Call for help, activate Code Blue, bring crash cart, initiate high-quality chest compressions",
        "Medication nurse duties: Preparing and administering Epinephrine 1mg IV flush q3-5min and Amiodarone boluses",
        "Code recorder responsibilities: Exact timeline documentation of rhythm checks, shocks delivered, and medications pushed",
        "Seamless 2-minute compressor rotations to prevent rescuer fatigue and maintain compression depth >= 2 inches"
      ]
    }],
    3: [{
      id: "nurs-tri-p3-anaphylaxis",
      title: "Emergency Management of Anaphylaxis & Acute Polytrauma Resuscitation",
      youtube_video_id: "EjvyzTqS-3Y",
      youtube_url: "https://www.youtube.com/watch?v=EjvyzTqS-3Y",
      fallback_video_id: "bvVb-eI8lzU",
      search_query: "Anaphylaxis Emergency Management Epinephrine Intramuscular Trauma Resuscitation",
      channel_name: "Medical Animations | Pediatrician",
      duration: "25:15",
      difficulty: "Advanced",
      topic_focus: "IM Epinephrine 1:1000 (0.3-0.5 mg) Anterolateral Thigh, Airway Edema & Primary Survey",
      key_takeaways: [
        "First-line drug for anaphylaxis: Immediate intramuscular Epinephrine (1:1,000) in the mid-anterolateral thigh",
        "Secondary medications: H1 antihistamines, IV methylprednisolone, and albuterol nebulizers for bronchospasm",
        "Trauma nursing primary survey: (C)ATLS protocol (Catastrophic hemorrhage, Airway with C-spine, Breathing, Circulation, Disability, Exposure)",
        "Massive transfusion protocol (MTP) activation: 1:1:1 ratio of packed red blood cells, fresh frozen plasma, and platelets"
      ]
    }],
    4: [{
      id: "nurs-tri-p4-er-interview",
      title: "Emergency Room (ER) Staff Nurse Placement Interview & Simulation Screening",
      youtube_video_id: "7ldPMpzd4Rw",
      youtube_url: "https://www.youtube.com/watch?v=7ldPMpzd4Rw",
      fallback_video_id: "smHzmuGOWB0",
      search_query: "Emergency Room Nurse Interview Questions Scenarios Triage Code Blue Viva",
      channel_name: "Emergency Chaos",
      duration: "30:20",
      difficulty: "Placement",
      topic_focus: "ER Scenario Questions, De-escalation, Rapid Assessment & Hospital Placement Viva",
      key_takeaways: [
        "Demonstrating calm, decisive clinical decision making under unpredictable emergency department surges",
        "Verbal de-escalation strategies for agitated, aggressive, or intoxicated patients in the ER waiting area",
        "Cross-collaborative communication with emergency physicians, trauma surgeons, and radiology teams",
        "Acing emergency nursing job interviews and practical scenario simulations at top trauma centers"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 18. Medication Administration & 5 Rights Protocol
  // --------------------------------------------------------------------------
  'nurs-pharma': {
    0: [{
      id: "nurs-phar-p0-rights",
      title: "The 5 Rights & 10 Rights of Medication Administration for Nurses",
      youtube_video_id: "TqVrR69Swr0",
      youtube_url: "https://www.youtube.com/watch?v=TqVrR69Swr0",
      fallback_video_id: "YHBgApOKpaM",
      search_query: "RegisteredNurseRN 5 Rights of Medication Administration Patient Drug Dose Route Time",
      channel_name: "RegisteredNurseRN",
      duration: "18:40",
      difficulty: "Beginner",
      topic_focus: "Right Patient, Right Drug, Right Dose, Right Route, Right Time & Three Check Rule",
      key_takeaways: [
        "The core 5 Rights: Right Patient (2 identifiers), Right Medication, Right Dose, Right Route, and Right Time",
        "The extended 5 Rights: Right Documentation, Right Reason, Right Response, Right to Refuse, Right Education",
        "Performing the 3 Medication Checks: When retrieving from Pyxis/cart, when preparing dose, and at bedside before giving",
        "Using barcode medication administration (BCMA) scanning to eliminate bedside administration errors"
      ]
    }],
    1: [{
      id: "nurs-phar-p1-calculations",
      title: "Dosage Calculations, Metric Conversions & IV Drop Rate / Infusion Formulas",
      youtube_video_id: "hQY4otRR4TA",
      youtube_url: "https://www.youtube.com/watch?v=hQY4otRR4TA",
      fallback_video_id: "kza8QKqjnPM",
      search_query: "RegisteredNurseRN Dosage Calculations Nursing IV Drop Factor Drip Rates",
      channel_name: "RegisteredNurseRN",
      duration: "24:50",
      difficulty: "Intermediate",
      topic_focus: "Dimensional Analysis, Desired Over Have Formula, gtt/min Drops & mL/hr Rates",
      key_takeaways: [
        "Mastering the Desired over Have times Quantity formula: (D / H) x Q = Amount to Administer",
        "Calculating IV flow rates in mL per hour: Total Volume (mL) / Time (hr) = mL/hr",
        "Calculating gravity drop rates in gtt/min: [Volume (mL) x Drop Factor (gtt/mL)] / Time (minutes)",
        "Pediatric safe dosage verification: Milligrams per kilogram per day (mg/kg/day) divided into divided doses"
      ]
    }],
    2: [{
      id: "nurs-phar-p2-high-alert",
      title: "High-Alert Medications: Insulin, Heparin & Potassium Safety Protocols",
      youtube_video_id: "L_9OPbqxbmU",
      youtube_url: "https://www.youtube.com/watch?v=L_9OPbqxbmU",
      fallback_video_id: "kF0IVu_P9UM",
      search_query: "RegisteredNurseRN High Alert Medications Insulin Protocols Heparin Drip Potassium",
      channel_name: "RegisteredNurseRN",
      duration: "26:15",
      difficulty: "Intermediate",
      topic_focus: "Independent Double-Checks, IV Potassium Never Bolus, Sliding Scale & Heparin Nomograms",
      key_takeaways: [
        "ISMP high-alert medication protocols: Mandatory independent double-check by two registered nurses",
        "Insulin safety: Differentiating rapid-acting, regular, and long-acting insulins; matching with fingerstick glucose",
        "Weight-based unfractionated Heparin infusion titration based on consecutive aPTT or anti-Xa levels",
        "Absolute safety rule: IV Potassium Chloride (KCl) MUST NEVER be administered as an IV push or bolus"
      ]
    }],
    3: [{
      id: "nurs-phar-p3-routes",
      title: "Parenteral Injections: Intramuscular (IM), Subcutaneous (SubQ) & Intradermal (ID)",
      youtube_video_id: "DBHnd3N-5Ns",
      youtube_url: "https://www.youtube.com/watch?v=DBHnd3N-5Ns",
      fallback_video_id: "N3QBmlfzjSo",
      search_query: "Geeky Medics Injection Technique IM SubQ Intradermal Ventrogluteal Z Track",
      channel_name: "RegisteredNurseRN",
      duration: "20:30",
      difficulty: "Advanced",
      topic_focus: "Ventrogluteal vs Deltoid Sites, Z-Track Technique, 45 vs 90 Degree Angles",
      key_takeaways: [
        "Identifying injection landmarks: Ventrogluteal site (safest for large IM volumes) and deltoid muscle",
        "The Z-track injection technique for irritating drugs (Iron, Haldol) to prevent tracking into subcutaneous tissue",
        "Subcutaneous injection sites (abdomen, posterior arm) and angles: 45 degrees vs 90 degrees depending on skinfold thickness",
        "Intradermal injection technique (10-15 degree angle) to produce a characteristic wheal for Mantoux tuberculin skin test"
      ]
    }],
    4: [{
      id: "nurs-phar-p4-exam",
      title: "Nursing Pharmacology & Drug Dosage Exam: 100% Mastery Screening Viva",
      youtube_video_id: "hnzZKY8SGbE",
      youtube_url: "https://www.youtube.com/watch?v=hnzZKY8SGbE",
      fallback_video_id: "B8THrJVTeZU",
      search_query: "Nursing Pharmacology Exam NCLEX Medication Calculations Drug Administration Viva",
      channel_name: "RegisteredNurseRN",
      duration: "33:40",
      difficulty: "Placement",
      topic_focus: "Medication Error Root Cause Analysis, Adverse Reaction Reporting & Placement Screening",
      key_takeaways: [
        "Zero-tolerance 100% pass score requirements on hospital math dosage exams: Eliminating calculation errors",
        "Immediate nursing steps upon discovering a medication administration error: Assess patient, notify physician, file incident report",
        "Recognizing adverse drug reactions vs expected side effects and documenting in electronic health record",
        "Passing hospital onboarding pharmacology competency exams and staff nurse placement interviews"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 19. Aseptic Wound Care & Post-Operative Dressing
  // --------------------------------------------------------------------------
  'nurs-wound': {
    0: [{
      id: "nurs-wnd-p0-antt",
      title: "Aseptic Non-Touch Technique (ANTT) & Sterile Dressing Change Procedure",
      youtube_video_id: "VDngeM2NzPA",
      youtube_url: "https://www.youtube.com/watch?v=VDngeM2NzPA",
      fallback_video_id: "0vRFW2bsKpM",
      search_query: "Geeky Medics Wound Dressing ANTT Aseptic Non Touch Technique Sterile Dressing",
      channel_name: "Grampians Health Ballarat",
      duration: "18:15",
      difficulty: "Beginner",
      topic_focus: "Key Parts & Key Sites Protection, Sterile Field Setup & Wound Cleansing (Normal Saline)",
      key_takeaways: [
        "Core principles of Aseptic Non-Touch Technique (ANTT): Identifying and protecting Key Parts and Key Sites",
        "Establishing a sterile field using sterile dressing packs and sterile gloves",
        "Cleansing surgical wounds with sterile 0.9% normal saline: Cleaning from cleanest area outward (center to periphery)",
        "Drying wound edges gently without disrupting fragile newly formed granulation tissue"
      ]
    }],
    1: [{
      id: "nurs-wnd-p1-pressure-ulcer",
      title: "Pressure Injury Staging (Stages 1-4, Unstageable, DTI) & Braden Scale Risk Assessment",
      youtube_video_id: "U9ArLeYqMjc",
      youtube_url: "https://www.youtube.com/watch?v=U9ArLeYqMjc",
      fallback_video_id: "UHfZL5W9FEc",
      search_query: "RegisteredNurseRN Pressure Ulcers Staging Braden Scale Deep Tissue Injury",
      channel_name: "SimpleNursing",
      duration: "23:45",
      difficulty: "Intermediate",
      topic_focus: "Non-Blanchable Erythema (Stage 1), Partial Thickness (Stage 2), Full Thickness (Stages 3-4) & Slough",
      key_takeaways: [
        "Staging pressure injuries: Stage 1 non-blanchable erythema, Stage 2 partial-thickness dermis loss with blister",
        "Stage 3 full-thickness tissue loss exposing subcutaneous fat; Stage 4 exposing bone, tendon, or muscle",
        "Defining Unstageable wounds obscured by slough or eschar and Deep Tissue Pressure Injury (DTPI)",
        "Executing the Braden Scale risk assessment and implementing 2-hour patient repositioning schedules"
      ]
    }],
    2: [{
      id: "nurs-wnd-p2-drains",
      title: "Surgical Drain Maintenance: Jackson-Pratt (JP), Hemovac & Penrose Care",
      youtube_video_id: "wGLrMYFba60",
      youtube_url: "https://www.youtube.com/watch?v=wGLrMYFba60",
      fallback_video_id: "zu5tSPYSQaw",
      search_query: "RegisteredNurseRN Jackson Pratt JP Drain Hemovac Emptying Measuring Stripping Care",
      channel_name: "RegisteredNurseRN",
      duration: "17:30",
      difficulty: "Intermediate",
      topic_focus: "Closed Suction Bulbs, Milking/Stripping Protocols, Serosanguinous Output & Removal Triggers",
      key_takeaways: [
        "Maintaining closed negative-pressure suction by compressing the JP bulb / Hemovac spring before recapping",
        "Emptying and accurately measuring drain output in a graduated container; documenting output characteristics",
        "Differentiating drain fluid progression: Sanguineous (bright red) to serosanguinous (pink) to serous (straw-colored)",
        "Notifying surgical team if sudden bright red output > 100 mL/hr occurs indicating acute internal hemorrhage"
      ]
    }],
    3: [{
      id: "nurs-wnd-p3-modern-dressings",
      title: "Advanced Wound Care: Hydrocolloids, Alginates, Foams & Negative Pressure (VAC) Therapy",
      youtube_video_id: "-0eeoacEw-k",
      youtube_url: "https://www.youtube.com/watch?v=-0eeoacEw-k",
      fallback_video_id: "qlXfITvsPgM",
      search_query: "Wound Care Specialist Dressings Alginate Hydrocolloid Foam VAC Therapy NPWT",
      channel_name: "National Wound Care",
      duration: "25:20",
      difficulty: "Advanced",
      topic_focus: "Moist Wound Healing, Exudate Absorption, Cavity Packing & VAC Therapy (-125 mmHg)",
      key_takeaways: [
        "Selecting appropriate modern dressings: Calcium alginate for heavy exudate, hydrocolloid for low exudate wounds",
        "Using foam dressings for cushion and moderate moisture balance in pressure ulcers",
        "Proper technique for loose packing of tunneling wounds and undermined cavity edges",
        "Negative Pressure Wound Therapy (NPWT / Wound VAC): Foam dressing placement, occlusive film sealing, and -125 mmHg continuous suction"
      ]
    }],
    4: [{
      id: "nurs-wnd-p4-viva",
      title: "Surgical Ward Staff Nurse Clinical Examination & Wound Care Competency Viva",
      youtube_video_id: "W2cwr16zS2w",
      youtube_url: "https://www.youtube.com/watch?v=W2cwr16zS2w",
      fallback_video_id: "5NDiT9bk_0Q",
      search_query: "Surgical Nursing Wound Care Viva Questions Suture Removal Staples Post Op Care",
      channel_name: "RegisteredNurseRN",
      duration: "29:40",
      difficulty: "Placement",
      topic_focus: "Surgical Suture & Staple Removal, Wound Dehiscence / Evisceration Emergency & Placement Viva",
      key_takeaways: [
        "Safe technique for alternate suture and staple removal using sterile staple extractor kits",
        "Emergency management of acute abdominal wound evisceration: Cover with sterile saline-soaked gauze, call surgeon, stay calm",
        "Accurately documenting TIME framework: Tissue, Infection/Inflammation, Moisture imbalance, Edge of wound",
        "Passing surgical ward nursing competency assessments and clinical placement interview examinations"
      ]
    }]
  }
};

