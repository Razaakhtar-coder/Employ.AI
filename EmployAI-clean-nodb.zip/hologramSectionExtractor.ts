import type { StructuredResume, ResumeAnalysisResult } from '../types';

export interface HologramSectionData {
  id: string;
  label: string;
  originalTitle: string;
  count: number;
  stat: string;
  iconName: 'summary' | 'skills' | 'experience' | 'internship' | 'projects' | 'education' | 'certifications' | 'achievements' | 'publications' | 'languages' | 'volunteer';
  color: string;
  previewItems: string[];
  rawItems: any;
}

/**
 * Normalizes section titles to clean uppercase labels.
 */
export function normalizeSectionLabel(rawTitle: string): string {
  const lower = rawTitle.toLowerCase().trim();
  if (lower.includes('summar') || lower.includes('profile') || lower.includes('objective') || lower.includes('about')) {
    return 'SUMMARY';
  }
  if (lower.includes('skill') || lower.includes('competenc') || lower.includes('technolog') || lower.includes('stack') || lower.includes('expertise')) {
    return 'SKILLS';
  }
  if (lower.includes('intern') || lower.includes('clerkship') || lower.includes('residency') || lower.includes('trainee')) {
    return 'INTERNSHIP';
  }
  if (lower.includes('experien') || lower.includes('employ') || lower.includes('work') || lower.includes('histor') || lower.includes('clinical') || lower.includes('practice')) {
    return 'EXPERIENCE';
  }
  if (lower.includes('project') || lower.includes('portfolio') || lower.includes('case stud') || lower.includes('build') || lower.includes('audit')) {
    return 'PROJECTS';
  }
  if (lower.includes('educat') || lower.includes('academ') || lower.includes('degree') || lower.includes('school') || lower.includes('college') || lower.includes('university')) {
    return 'EDUCATION';
  }
  if (lower.includes('certif') || lower.includes('license') || lower.includes('credential') || lower.includes('accredit')) {
    return 'CERTIFICATIONS';
  }
  if (lower.includes('achieve') || lower.includes('award') || lower.includes('honor') || lower.includes('recognition')) {
    return 'ACHIEVEMENTS';
  }
  if (lower.includes('publicat') || lower.includes('research') || lower.includes('paper') || lower.includes('journal')) {
    return 'PUBLICATIONS';
  }
  if (lower.includes('languag')) {
    return 'LANGUAGES';
  }
  if (lower.includes('volunt') || lower.includes('leader') || lower.includes('community') || lower.includes('extracurricular')) {
    return 'VOLUNTEER';
  }
  return rawTitle.toUpperCase();
}

/**
 * Extracts and detects sections strictly from the real parsed resume data.
 * Does not show hardcoded placeholders. Empty sections are omitted.
 */
export function extractHologramSections(
  structuredResume: StructuredResume | null | undefined,
  analysis: ResumeAnalysisResult | null | undefined
): HologramSectionData[] {
  const sections: HologramSectionData[] = [];

  // 1. SUMMARY / OBJECTIVE
  const summaryText = structuredResume?.summary || 
    structuredResume?.personal_info?.summary || 
    (analysis?.strengths && analysis.strengths.length > 0 ? analysis.strengths.join(' ') : null);

  if (summaryText && summaryText.trim().length > 10) {
    sections.push({
      id: 'summary',
      label: 'SUMMARY',
      originalTitle: 'Professional Profile & Executive Summary',
      count: 1,
      stat: '1 Profile Record',
      iconName: 'summary',
      color: '#38bdf8',
      previewItems: [summaryText.slice(0, 160) + (summaryText.length > 160 ? '...' : '')],
      rawItems: {
        headline: structuredResume?.headline || structuredResume?.personal_info?.headline || structuredResume?.personal_info?.title || analysis?.detected_domain || 'Verified Candidate',
        summary: summaryText,
        email: structuredResume?.personal_info?.email,
        phone: structuredResume?.personal_info?.phone,
        location: structuredResume?.personal_info?.location,
        links: structuredResume?.personal_info?.links || analysis?.detected_links || []
      }
    });
  }

  // 2. SKILLS & COMPETENCIES
  const rawSkills = structuredResume?.skills || analysis?.extracted_skills || [];
  const validSkills = Array.from(new Set(rawSkills.filter(Boolean)));
  if (validSkills.length > 0) {
    sections.push({
      id: 'skills',
      label: 'SKILLS',
      originalTitle: 'Skills & Core Competencies',
      count: validSkills.length,
      stat: `${validSkills.length} Verified Skills`,
      iconName: 'skills',
      color: '#34d399',
      previewItems: validSkills.slice(0, 8),
      rawItems: {
        skills: validSkills,
        categories: structuredResume?.technical_skills || {}
      }
    });
  }

  // 3. EXPERIENCE & INTERNSHIPS (Combined & Deduplicated with Zero Loss)
  const allExpItems: any[] = [];
  const seenExpKeys = new Set<string>();

  const addUniqueExp = (item: any) => {
    if (!item || typeof item !== 'object') return;
    const role = (item.role || item.role_or_title || '').trim();
    const company = (item.company || item.company_or_org || '').trim();
    const duration = (item.duration || '').trim();
    if (!role && !company) return;

    const key = `${role.toLowerCase()}__${company.toLowerCase()}__${duration.toLowerCase()}`;
    const rawBullets = Array.isArray(item.bullets) && item.bullets.length > 0 
      ? item.bullets 
      : (Array.isArray(item.highlights) ? item.highlights : []);

    if (!seenExpKeys.has(key)) {
      seenExpKeys.add(key);
      allExpItems.push({
        id: item.id || `exp-${allExpItems.length + 1}`,
        role: role || 'Professional Role',
        company: company,
        duration: duration,
        bullets: rawBullets
      });
    } else {
      const existing = allExpItems.find(e => `${e.role.toLowerCase()}__${e.company.toLowerCase()}__${(e.duration || '').toLowerCase()}` === key);
      if (existing) {
        if (rawBullets.length > existing.bullets.length) {
          existing.bullets = rawBullets;
        }
        if (!existing.duration && duration) {
          existing.duration = duration;
        }
      }
    }
  };

  (structuredResume?.experience || []).forEach(addUniqueExp);
  (analysis?.extracted_experience || []).forEach((e) => addUniqueExp({
    role: e.role,
    company: e.company_or_org,
    duration: e.duration,
    bullets: e.highlights
  }));

  const standardExp: any[] = [];
  const internshipExp: any[] = [];

  const INTERN_KEYWORDS = [
    'intern', 'internship', 'trainee', 'clerkship', 'fellow', 'summer', 'research assistant',
    'apprentice', 'vocational', 'practical training', 'graduate trainee', 'student researcher'
  ];

  const SENIOR_FULLTIME_KEYWORDS = [
    'senior', 'lead', 'principal', 'staff', 'manager', 'director', 'head', 'architect',
    'full time', 'full-time', 'consultant', 'vice president', 'vp', 'founder', 'co-founder'
  ];

  const hasSeniorFulltime = allExpItems.some(item => {
    const r = (item.role || '').toLowerCase();
    return SENIOR_FULLTIME_KEYWORDS.some(kw => r.includes(kw));
  });

  allExpItems.forEach(item => {
    const roleText = (item.role || '').toLowerCase();
    const companyText = (item.company || '').toLowerCase();
    
    const isExplicitIntern = INTERN_KEYWORDS.some(kw => roleText.includes(kw) || companyText.includes(kw));
    
    if (isExplicitIntern || (!hasSeniorFulltime && allExpItems.length <= 4)) {
      internshipExp.push(item);
    } else {
      standardExp.push(item);
    }
  });

  // Standard Experience
  if (standardExp.length > 0) {
    sections.push({
      id: 'experience',
      label: 'EXPERIENCE',
      originalTitle: standardExp.length > 1 ? `Professional Experience (${standardExp.length} Positions)` : 'Professional & Work Experience',
      count: standardExp.length,
      stat: `${standardExp.length} ${standardExp.length === 1 ? 'Position' : 'Positions'}`,
      iconName: 'experience',
      color: '#00f2fe',
      previewItems: standardExp.map(e => {
        const role = e.role || 'Role';
        const orgStr = e.company ? ` @ ${e.company}` : '';
        const dur = e.duration ? ` (${e.duration})` : '';
        return `${role}${orgStr}${dur}`;
      }),
      rawItems: standardExp
    });
  }

  // Internship / Practical Training
  if (internshipExp.length > 0) {
    sections.push({
      id: 'internship',
      label: 'INTERNSHIP',
      originalTitle: internshipExp.length > 1 ? `Internships (${internshipExp.length} Roles)` : 'Internships & Practical Training',
      count: internshipExp.length,
      stat: `${internshipExp.length} ${internshipExp.length === 1 ? 'Internship' : 'Internships'}`,
      iconName: 'internship',
      color: '#a855f7',
      previewItems: internshipExp.map(i => {
        const role = i.role || 'Intern';
        const orgStr = i.company ? ` @ ${i.company}` : '';
        const dur = i.duration ? ` (${i.duration})` : '';
        return `${role}${orgStr}${dur}`;
      }),
      rawItems: internshipExp
    });
  }

  // 4. PROJECTS, CASE STUDIES & IMPLEMENTATIONS
  const rawProjects = (structuredResume?.projects && structuredResume.projects.length > 0 ? structuredResume.projects : null) || 
    (analysis?.extracted_projects && analysis.extracted_projects.length > 0 ? analysis.extracted_projects.map(p => ({
      title: p.title,
      role_or_tech: p.role_or_tech,
      description: p.description,
      bullets: [p.description, p.quantifiable_metrics || p.quantified_impact].filter(Boolean) as string[],
      technologies: p.key_technologies || []
    })) : null) ||
    (structuredResume?.portfolio && structuredResume.portfolio.length > 0 ? structuredResume.portfolio : null) || [];

  if (rawProjects.length > 0) {
    sections.push({
      id: 'projects',
      label: 'PROJECTS',
      originalTitle: 'Key Projects & Case Studies',
      count: rawProjects.length,
      stat: `${rawProjects.length} ${rawProjects.length === 1 ? 'Project' : 'Projects'}`,
      iconName: 'projects',
      color: '#f59e0b',
      previewItems: rawProjects.slice(0, 4).map(p => {
        const techStr = p.technologies && p.technologies.length > 0 ? ` [${p.technologies.slice(0, 3).join(', ')}]` : '';
        return `${p.title || 'Project'}${techStr}`;
      }),
      rawItems: rawProjects
    });
  }

  // 5. EDUCATION & ACADEMIC BACKGROUND
  const rawEdu = structuredResume?.education || [];
  if (rawEdu.length > 0) {
    sections.push({
      id: 'education',
      label: 'EDUCATION',
      originalTitle: 'Academic Background & Degrees',
      count: rawEdu.length,
      stat: `${rawEdu.length} ${rawEdu.length === 1 ? 'Qualification' : 'Qualifications'}`,
      iconName: 'education',
      color: '#f43f5e',
      previewItems: rawEdu.slice(0, 3).map(e => {
        const deg = e.degree || 'Degree';
        const inst = e.institution || 'University';
        const yr = e.end_year || e.start_year || '';
        const grade = e.grade_or_cgpa ? ` • ${e.grade_or_cgpa}` : '';
        return `${deg} - ${inst}${yr ? ` (${yr})` : ''}${grade}`;
      }),
      rawItems: rawEdu
    });
  }

  // 6. CERTIFICATIONS & CREDENTIALS
  const rawCerts = structuredResume?.certifications || [];
  if (rawCerts.length > 0) {
    sections.push({
      id: 'certifications',
      label: 'CERTIFICATIONS',
      originalTitle: 'Certifications & Credentials',
      count: rawCerts.length,
      stat: `${rawCerts.length} ${rawCerts.length === 1 ? 'Credential' : 'Credentials'}`,
      iconName: 'certifications',
      color: '#8b5cf6',
      previewItems: rawCerts.slice(0, 4).map(c => {
        const issuerStr = c.issuer ? ` (${c.issuer})` : '';
        return `${c.name || 'Verified Certificate'}${issuerStr}`;
      }),
      rawItems: rawCerts
    });
  }

  // 7. ACHIEVEMENTS & AWARDS
  const rawAchieve = structuredResume?.achievements || structuredResume?.awards || [];
  if (rawAchieve.length > 0) {
    sections.push({
      id: 'achievements',
      label: 'ACHIEVEMENTS',
      originalTitle: 'Achievements & Honors',
      count: rawAchieve.length,
      stat: `${rawAchieve.length} ${rawAchieve.length === 1 ? 'Award' : 'Awards'}`,
      iconName: 'achievements',
      color: '#fbbf24',
      previewItems: rawAchieve.slice(0, 4),
      rawItems: rawAchieve
    });
  }

  // 8. PUBLICATIONS & RESEARCH
  const rawPubs = structuredResume?.publications || [];
  if (rawPubs.length > 0) {
    sections.push({
      id: 'publications',
      label: 'PUBLICATIONS',
      originalTitle: 'Publications & Research Papers',
      count: rawPubs.length,
      stat: `${rawPubs.length} ${rawPubs.length === 1 ? 'Publication' : 'Publications'}`,
      iconName: 'publications',
      color: '#06b6d4',
      previewItems: rawPubs.slice(0, 3),
      rawItems: rawPubs
    });
  }

  // 9. LANGUAGES
  const rawLangs = structuredResume?.languages || [];
  if (rawLangs.length > 0) {
    sections.push({
      id: 'languages',
      label: 'LANGUAGES',
      originalTitle: 'Languages & Fluency',
      count: rawLangs.length,
      stat: `${rawLangs.length} ${rawLangs.length === 1 ? 'Language' : 'Languages'}`,
      iconName: 'languages',
      color: '#10b981',
      previewItems: rawLangs.slice(0, 4),
      rawItems: rawLangs
    });
  }

  // 10. VOLUNTEERING & LEADERSHIP
  const rawVol = structuredResume?.volunteering || [];
  if (rawVol.length > 0) {
    sections.push({
      id: 'volunteer',
      label: 'VOLUNTEER',
      originalTitle: 'Volunteering & Leadership',
      count: rawVol.length,
      stat: `${rawVol.length} ${rawVol.length === 1 ? 'Initiative' : 'Initiatives'}`,
      iconName: 'volunteer',
      color: '#ec4899',
      previewItems: rawVol.slice(0, 3),
      rawItems: rawVol
    });
  }

  return sections;
}

/**
 * Provides truthful, domain-aware recommendations for any section across all 15+ disciplines.
 */
export function getDomainSpecificRecommendation(sectionId: string, domain?: string): string {
  const dom = (domain || '').toLowerCase();

  if (dom.includes('mbbs') || dom.includes('medic') || dom.includes('health') || dom.includes('clinic') || dom.includes('pharm')) {
    switch (sectionId) {
      case 'skills':
        return 'Ensure clinical diagnostics, procedural competencies, triage management, and patient care methods are clearly highlighted.';
      case 'experience':
        return 'Document clinical rotations, patient bed counts, emergency triage caseloads, and diagnostic case outcomes with precise metrics.';
      case 'internship':
        return 'Detail compulsory rotating medical internship (CRMI) departments, outpatient consultations, and ICU/ward procedures managed.';
      case 'projects':
        return 'Highlight clinical audits, epidemiological research, hospital quality improvement protocols, and case presentations.';
      case 'summary':
        return 'Highlight registered medical council status, core clinical areas of interest, bedside diagnostic acumen, and patient care ethics.';
      default:
        return 'Maintain high clinical clarity, verified registration details, and accredited certifications.';
    }
  }

  if (dom.includes('law') || dom.includes('llb') || dom.includes('legal') || dom.includes('judic')) {
    switch (sectionId) {
      case 'skills':
        return 'Highlight statutory interpretation, legal research (SCC Online, Manupatra), brief drafting, contract review, and oral advocacy.';
      case 'experience':
        return 'Specify court appearances (High Court, District Courts, Tribunals), bench filings, arbitration proceedings, and matter types handled.';
      case 'internship':
        return 'Detail legal clerkships under senior advocates, judicial internships, legal aid clinics, and drafting assignments.';
      case 'projects':
        return 'Showcase moot court memorials, research publications in law journals, and statutory policy analysis briefs.';
      case 'summary':
        return 'Emphasize bar council enrollment status, specialized areas of law (Corporate, IP, Criminal, Constitutional), and litigation/advisory strengths.';
      default:
        return 'Ensure precise citation formatting, accurate forum references, and concise legal language.';
    }
  }

  if (dom.includes('bussiness') || dom.includes('business') || dom.includes('analyst') || dom.includes('finance') || dom.includes('commerce') || dom.includes('bcom') || dom.includes('mba') || dom.includes('consult')) {
    switch (sectionId) {
      case 'skills':
        return 'Highlight quantitative modeling, data visualization (Power BI, Tableau), SQL, financial statements, and business process mapping.';
      case 'experience':
        return 'Quantify business impact (e.g. ROI increased by 18%, cost reduction of $45K, variance analysis conducted for 12 business units).';
      case 'internship':
        return 'Detail deliverable ownership, stakeholder presentations, market research audits, and automated reporting dashboards created.';
      case 'projects':
        return 'Include business cases, DCF valuation models, supply chain optimization studies, and consumer segmentation analyses.';
      case 'summary':
        return 'Highlight commercial acumen, cross-functional stakeholder leadership, and data-backed decision-making abilities.';
      default:
        return 'Focus on quantifiable financial/operational outcomes and clean analytical structure.';
    }
  }

  // Engineering & Computer Science / General
  switch (sectionId) {
    case 'skills':
      return 'Ensure keywords match target job postings. Group into Core Foundations, Domain Tools, and Emerging Frameworks.';
    case 'experience':
      return 'Elevate bullet points using the Google XYZ formula: Accomplished [X], as measured by [Y], by doing [Z]. Include metrics (%/$).';
    case 'internship':
      return 'Highlight production deliverables, code reviews passed, sprint contributions, and performance improvements achieved.';
    case 'projects':
      return 'Include live repository links, specify architectural design choices, database optimizations, and system throughput metrics.';
    case 'summary':
      return 'Keep summary under 3-4 impactful sentences highlighting core specialization, problem-solving scale, and career value proposition.';
    default:
      return 'Maintain clean formatting and keep bullet points concise with strong action verbs and verified outcomes.';
  }
}

