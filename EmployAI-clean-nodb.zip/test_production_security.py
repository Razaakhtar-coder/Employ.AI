import unittest
import hmac
import hashlib
import json
from datetime import datetime, timezone
from fastapi.testclient import TestClient

from app.main import app
from app.core.config import settings
from app.core.security import create_access_token, get_password_hash
from app.core.database import SessionLocal
from app.models.user import User
from app.models.payment import Payment
from app.models.opportunity import Opportunity, Application
from app.models.profile import IndustryProfile, StudentProfile
from app.services.document_service import DocumentService
from app.core.exceptions import FileValidationException


class TestProductionSecurityAndPayments(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)
        cls.db = SessionLocal()

        # Create or ensure test user
        cls.test_email = "sec_test_user@example.com"
        cls.user = cls.db.query(User).filter(User.email == cls.test_email).first()
        if not cls.user:
            cls.user = User(
                email=cls.test_email,
                hashed_password=get_password_hash("StrongSecPass#1"),
                full_name="Security Test User",
                role="student",
                is_active=True,
                is_premium=False
            )
            cls.db.add(cls.user)
            cls.db.commit()
            cls.db.refresh(cls.user)

        cls.user_token = create_access_token(
            subject=cls.user.id,
            role=cls.user.role,
            email=cls.user.email,
            full_name=cls.user.full_name
        )

        # Create admin user
        cls.admin_email = "akhtarrakeeb52@gmail.com"
        cls.admin_token = create_access_token(
            subject="admin_user_id",
            role="admin",
            email=cls.admin_email,
            full_name="Admin"
        )

    @classmethod
    def tearDownClass(cls):
        cls.db.close()

    def test_security_headers_present(self):
        """Verify essential security headers and request-id are injected on every response."""
        res = self.client.get("/health")
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.headers.get("x-content-type-options"), "nosniff")
        self.assertEqual(res.headers.get("x-frame-options"), "DENY")
        self.assertEqual(res.headers.get("referrer-policy"), "strict-origin-when-cross-origin")
        self.assertIn("x-request-id", res.headers)

    def test_file_upload_magic_bytes_validation(self):
        """Verify that files with malicious or mismatched magic bytes are rejected."""
        # 1. PE executable disguised as PDF
        fake_exe = b"MZ\x90\x00\x03\x00\x00\x00This is a fake PE executable"
        with self.assertRaises(FileValidationException) as ctx:
            DocumentService.validate_content_bytes(fake_exe, "pdf")
        self.assertIn("Executable binaries are strictly forbidden", str(ctx.exception))

        # 2. Plain text disguised as PDF without %PDF header
        fake_pdf = b"Hello world, I am just plain text pretending to be pdf"
        with self.assertRaises(FileValidationException) as ctx:
            DocumentService.validate_content_bytes(fake_pdf, "pdf")
        self.assertIn("Missing genuine PDF file header signature", str(ctx.exception))

        # 3. Genuine PDF header passes
        valid_pdf_header = b"%PDF-1.4\n%real pdf content"
        # Should not raise
        DocumentService.validate_content_bytes(valid_pdf_header, "pdf")

    def test_payment_forged_signature_rejection(self):
        """Verify that forged Razorpay signatures are rejected with HTTP 400."""
        headers = {"Authorization": f"Bearer {self.user_token}"}
        res = self.client.post(
            "/api/v1/payments/razorpay/verify",
            headers=headers,
            json={
                "razorpay_order_id": "order_live_fake_123",
                "razorpay_payment_id": "pay_live_fake_456",
                "razorpay_signature": "forged_malicious_hmac_hex",
                "plan_type": "monthly"
            }
        )
        self.assertEqual(res.status_code, 400)
        self.assertIn("Invalid Razorpay payment signature", res.json()["detail"])

    def test_payment_valid_hmac_signature_verification(self):
        """Verify that cryptographically valid HMAC-SHA256 signature is accepted."""
        order_id = f"order_sec_{self.user.id[:8]}_123"
        payment_id = f"pay_sec_{self.user.id[:8]}_456"

        # Compute valid HMAC with configured secret
        secret = settings.RAZORPAY_KEY_SECRET or "test_secret_for_unit"
        msg = f"{order_id}|{payment_id}".encode("utf-8")
        valid_sig = hmac.new(secret.encode("utf-8"), msg, hashlib.sha256).hexdigest()

        # Temporarily mock the secret for this test
        orig_secret = settings.RAZORPAY_KEY_SECRET
        settings.RAZORPAY_KEY_SECRET = secret
        try:
            headers = {"Authorization": f"Bearer {self.user_token}"}
            res = self.client.post(
                "/api/v1/payments/razorpay/verify",
                headers=headers,
                json={
                    "razorpay_order_id": order_id,
                    "razorpay_payment_id": payment_id,
                    "razorpay_signature": valid_sig,
                    "plan_type": "monthly"
                }
            )
            self.assertEqual(res.status_code, 200)
            self.assertTrue(res.json()["is_premium"])

            # Verify idempotency: resending the same payment succeeds without error
            res_idempotent = self.client.post(
                "/api/v1/payments/razorpay/verify",
                headers=headers,
                json={
                    "razorpay_order_id": order_id,
                    "razorpay_payment_id": payment_id,
                    "razorpay_signature": valid_sig,
                    "plan_type": "monthly"
                }
            )
            self.assertEqual(res_idempotent.status_code, 200)
            self.assertTrue(res_idempotent.json()["is_premium"])
        finally:
            settings.RAZORPAY_KEY_SECRET = orig_secret

    def test_payment_webhook_hmac_verification_and_idempotency(self):
        """Verify Razorpay webhook endpoint signature checking and idempotent processing."""
        webhook_secret = "whsec_test_mock_12345"
        orig_wh_secret = settings.RAZORPAY_WEBHOOK_SECRET
        settings.RAZORPAY_WEBHOOK_SECRET = webhook_secret

        try:
            test_order_id = f"order_wh_{self.user.id[:8]}_789"
            test_pay_id = f"pay_wh_{self.user.id[:8]}_789"
            payload = {
                "event": "payment.captured",
                "payload": {
                    "payment": {
                        "entity": {
                            "id": test_pay_id,
                            "order_id": test_order_id,
                            "amount": 4900,
                            "notes": {
                                "user_id": self.user.id,
                                "plan_type": "monthly"
                            }
                        }
                    }
                }
            }
            body_bytes = json.dumps(payload).encode("utf-8")

            # 1. Test invalid signature is rejected with HTTP 400
            bad_headers = {"X-Razorpay-Signature": "invalid_signature_hex"}
            res_bad = self.client.post("/api/v1/payments/razorpay/webhook", headers=bad_headers, content=body_bytes)
            self.assertEqual(res_bad.status_code, 400)

            # 2. Test valid signature is accepted and fulfills order
            valid_sig = hmac.new(webhook_secret.encode("utf-8"), body_bytes, hashlib.sha256).hexdigest()
            good_headers = {"X-Razorpay-Signature": valid_sig}
            res_good = self.client.post("/api/v1/payments/razorpay/webhook", headers=good_headers, content=body_bytes)
            self.assertEqual(res_good.status_code, 200)
            self.assertEqual(res_good.json()["status"], "ok")

            # 3. Test duplicate webhook delivery is handled idempotently
            res_dup = self.client.post("/api/v1/payments/razorpay/webhook", headers=good_headers, content=body_bytes)
            self.assertEqual(res_dup.status_code, 200)
            self.assertIn("already processed", res_dup.json().get("message", ""))
        finally:
            settings.RAZORPAY_WEBHOOK_SECRET = orig_wh_secret

    def test_bola_unauthorized_application_status_update(self):
        """Verify that a candidate cannot change another user's application status (BOLA/IDOR)."""
        # Create a mock application
        app_rec = Application(
            opportunity_id="opp_mock_123",
            user_id="other_candidate_id",
            status="applied"
        )
        self.db.add(app_rec)
        self.db.commit()
        self.db.refresh(app_rec)

        # Regular test user attempts to update status to "selected"
        headers = {"Authorization": f"Bearer {self.user_token}"}
        res = self.client.patch(
            f"/api/v1/applications/{app_rec.id}/status",
            headers=headers,
            json={"new_status": "selected"}
        )
        self.assertEqual(res.status_code, 403)

    def test_rate_limiting_enforcement(self):
        """Verify that excessive requests to rate-limited auth endpoints return HTTP 429."""
        from app.core.rate_limit import rate_limiter
        rate_limiter._local_cache.clear()

        # Rapidly call reset-password which has a tight limit (5 req/min)
        hit_429 = False
        for i in range(7):
            res = self.client.post(
                "/api/v1/auth/reset-password",
                json={"email": "nobody@example.com", "new_password": "Short"}
            )
            if res.status_code == 429:
                hit_429 = True
                self.assertIn("Retry-After", res.headers)
                break

        self.assertTrue(hit_429, "Rate limiter did not trigger HTTP 429 after 5 requests")


if __name__ == "__main__":
    unittest.main()
