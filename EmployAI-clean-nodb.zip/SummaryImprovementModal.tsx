import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import type { SummaryImprovementOption } from '../types';
import { documentApi } from '../services/api';
import { 
  Sparkles, Check, X, Edit3, RefreshCw, 
  AlertCircle, Lightbulb, ShieldCheck
} from 'lucide-react';
import { FuturisticLoader } from './FuturisticLoader';

export interface SummaryImprovementModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSummary?: string;
  targetDomain?: string;
  skills?: string[];
  experienceSummary?: string;
  onApply: (improvedSummary: string) => void;
}

export const SummaryImprovementModal: React.FC<SummaryImprovementModalProps> = ({
  isOpen,
  onClose,
  currentSummary,
  targetDomain,
  skills,
  experienceSummary,
  onApply,
}) => {
  const [options, setOptions] = useState<SummaryImprovementOption[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedIdx, setSelectedIdx] = useState<number>(0);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editedText, setEditedText] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const fetchSummaryOptions = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const res = await documentApi.generateSummaryOptions({
        current_summary: currentSummary,
        target_domain: targetDomain,
        skills: skills,
        experience_summary: experienceSummary
      });
      setOptions(res.options || []);
      if (res.options && res.options.length > 0) {
        setSelectedIdx(0);
        setEditedText(res.options[0].summary_text);
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to generate summary improvements.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setIsEditing(false);
      fetchSummaryOptions();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const currentSelected = options[selectedIdx];

  const handleSelect = (idx: number) => {
    setSelectedIdx(idx);
    setEditedText(options[idx].summary_text);
  };

  const handleApply = () => {
    const textToApply = isEditing ? editedText.trim() : (currentSelected?.summary_text || editedText.trim());
    if (!textToApply) return;
    onApply(textToApply);
    onClose();
  };

  const modalNode = (
    <div 
      className="modal-backdrop" 
      onClick={onClose} 
      style={{ 
        position: 'fixed',
        inset: 0,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100vw',
        height: '100vh',
        backgroundColor: 'rgba(3, 7, 18, 0.82)',
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 99999,
        padding: '1.25rem',
        boxSizing: 'border-box'
      }}
    >
      <div 
        className="glass-card modal-content" 
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '92%',
          maxWidth: '820px',
          maxHeight: '88vh',
          display: 'flex',
          flexDirection: 'column',
          padding: '1.75rem',
          borderRadius: '16px',
          background: 'var(--bg-modal)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-modal)',
          boxSizing: 'border-box'
        }}
      >
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div style={{ padding: '0.45rem', borderRadius: '10px', background: 'rgba(56, 189, 248, 0.12)', color: 'var(--accent-cyan)' }}>
              <Sparkles size={22} />
            </div>
            <div>
              <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                AI Summary Improvement
              </h2>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                Choose from 3 curated professional summary variations tailored to your domain.
              </p>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <button
              type="button"
              onClick={fetchSummaryOptions}
              className="btn btn-secondary btn-sm"
              disabled={isLoading}
              style={{ fontSize: '0.72rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
            >
              <RefreshCw size={12} className={isLoading ? 'animate-spin-slow' : ''} />
              Regenerate
            </button>
            <button
              type="button"
              onClick={onClose}
              className="btn btn-ghost btn-sm"
              style={{ padding: '0.35rem', color: 'var(--text-muted)' }}
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Current Summary Box if exists */}
        {currentSummary && (
          <div style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', borderRadius: '10px', padding: '0.75rem 1rem', marginBottom: '1rem' }}>
            <span style={{ display: 'block', fontSize: '0.68rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 700, marginBottom: '0.2rem' }}>
              Current Summary
            </span>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.45 }}>
              {currentSummary}
            </p>
          </div>
        )}

        {error && (
          <div style={{ padding: '0.6rem 0.85rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.1)', border: '1px solid rgba(244, 63, 94, 0.3)', color: '#fb7185', fontSize: '0.78rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <AlertCircle size={14} />
            <span>{error}</span>
          </div>
        )}

        {/* 3 Summary Options */}
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '0.85rem', paddingRight: '0.35rem' }}>
          {isLoading ? (
            <div style={{ textAlign: 'center', padding: '2rem 1rem' }}>
              <FuturisticLoader
                size="sm"
                icon="sparkles"
                title="Generating Executive Summaries..."
                subtitle="Synthesizing 3 tailored professional options"
              />
            </div>
          ) : (
            options.map((opt, idx) => {
              const isSelected = selectedIdx === idx;

              return (
                <div
                  key={idx}
                  onClick={() => handleSelect(idx)}
                  style={{
                    padding: '1rem 1.15rem',
                    borderRadius: '10px',
                    background: isSelected ? 'rgba(56, 189, 248, 0.12)' : 'var(--bg-tertiary)',
                    border: isSelected ? '1.5px solid var(--accent-cyan)' : '1px solid var(--border-subtle)',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.45rem' }}>
                    <span className={`badge ${isSelected ? 'badge-cyan' : 'badge-secondary'}`} style={{ fontSize: '0.7rem', fontWeight: 700 }}>
                      {opt.style}
                    </span>
                    {isSelected && (
                      <span style={{ color: 'var(--accent-cyan)', fontSize: '0.75rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
                        <Check size={14} /> Selected
                      </span>
                    )}
                  </div>

                  <p style={{ fontSize: '0.86rem', color: 'var(--text-primary)', margin: '0 0 0.65rem 0', lineHeight: 1.5, fontWeight: 500 }}>
                    {opt.summary_text}
                  </p>

                  {/* Why this is better */}
                  {opt.why_better && opt.why_better.length > 0 && (
                    <div style={{ background: 'var(--bg-inset)', border: '1px solid var(--border-subtle)', padding: '0.5rem 0.75rem', borderRadius: '6px', fontSize: '0.74rem' }}>
                      <span style={{ color: 'var(--accent-cyan)', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.25rem', marginBottom: '0.2rem' }}>
                        <Lightbulb size={11} /> Why this works:
                      </span>
                      <ul style={{ margin: 0, paddingLeft: '1rem', color: 'var(--text-secondary)' }}>
                        {opt.why_better.map((w, wIdx) => (
                          <li key={wIdx}>{w}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              );
            })
          )}

          {isEditing && (
            <div style={{ marginTop: '0.5rem', background: 'var(--bg-tertiary)', padding: '0.85rem', borderRadius: '8px', border: '1px solid var(--border-glass)' }}>
              <label style={{ display: 'block', fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: '0.35rem', fontWeight: 700 }}>
                Customize Summary Before Applying:
              </label>
              <textarea
                rows={3}
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
                className="resume-doc-input"
                style={{ width: '100%', fontSize: '0.82rem', lineHeight: 1.45 }}
              />
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '1.25rem', borderTop: '1px solid var(--border-subtle)', marginTop: '0.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.7rem', color: 'var(--text-muted)' }}>
            <ShieldCheck size={13} color="#10b981" />
            <span>Strict anti-hallucination. Anchored directly to your domain competencies.</span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
            <button
              type="button"
              onClick={onClose}
              className="btn btn-secondary btn-sm"
              style={{ fontSize: '0.75rem' }}
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => setIsEditing(prev => !prev)}
              className="btn btn-ghost btn-sm"
              style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
            >
              <Edit3 size={12} /> {isEditing ? 'Done Editing' : 'Edit Text'}
            </button>
            <button
              type="button"
              onClick={handleApply}
              disabled={isLoading || options.length === 0}
              className="btn btn-primary btn-sm"
              style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}
            >
              <Check size={13} /> Apply Summary
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalNode, document.body) : modalNode;
};
