import type { DomainPhaseVideoMap } from './domainYouTubeData';

// ============================================================================
// Business Analytics, Commerce (BCOM) & Management (BBA) 5-Phase YouTube Registry
// Phase 0: Foundations, First Principles & Core Quantitative Frameworks
// Phase 1: Applied Industry Software, Modeling & Analytics Tooling
// Phase 2: Advanced Strategic Optimization, Financial Architecture & Compliance
// Phase 3: Flagship Capstone, Executive Deliverables & Full Production Pipeline
// Phase 4: Placement Screening, Viva Voce & Corporate Hiring Prep
// ============================================================================

export const BUSINESS_COMMERCE_YOUTUBE_REGISTRY: Record<string, DomainPhaseVideoMap> = {
  // ==========================================================================
  // BUSINESS ANALYTICS
  // ==========================================================================

  // --------------------------------------------------------------------------
  // 1. Data Wrangling & ETL Pipelines
  // --------------------------------------------------------------------------
  'ba-wrangling': {
    0: [{
      id: "ba-wrg-p0-pandas-basics",
      title: "Data Wrangling with Python & Pandas: DataFrames, Series & Inspection",
      youtube_video_id: "vmEHCJofslg",
      youtube_url: "https://www.youtube.com/watch?v=vmEHCJofslg",
      fallback_video_id: "ZyhVh-qRZPA",
      search_query: "Keith Galli Pandas Data Analysis Tutorial DataFrames Series CSV",
      channel_name: "Keith Galli",
      duration: "25:40",
      difficulty: "Beginner",
      topic_focus: "Reading CSV/Parquet, Indexing (.loc / .iloc), Filtering & Data Types",
      key_takeaways: [
        "Reading heterogeneous enterprise data sources: CSV, Excel workbooks, JSON, and Parquet",
        "Exploring data structures: Pandas Series and DataFrames with .info(), .describe(), and .shape",
        "Label-based indexing (.loc) vs positional integer slicing (.iloc)",
        "Boolean conditional filtering and multi-column slicing for exploratory data auditing"
      ]
    }],
    1: [{
      id: "ba-wrg-p1-cleaning-missing",
      title: "Data Cleaning: Missing Values (NaN), Imputation & Regex Data Normalization",
      youtube_video_id: "KdmPHEnPJPs",
      youtube_url: "https://www.youtube.com/watch?v=KdmPHEnPJPs",
      fallback_video_id: "5eYTaYHzoEE",
      search_query: "Pandas Missing Values Imputation dropna fillna Regex String Manipulation",
      channel_name: "Corey Schafer",
      duration: "28:15",
      difficulty: "Intermediate",
      topic_focus: "Missing Data Strategies (.isna(), .fillna(), .interpolate()), Type Casting & Regex",
      key_takeaways: [
        "Auditing missingness patterns: Missing Completely at Random (MCAR) vs MAR vs MNAR",
        "Imputation strategies: Forward fill, median replacement, K-Nearest Neighbor (KNN) imputation",
        "Cleaning messy string columns using regular expressions (.str.replace(), .str.extract())",
        "DateTime parsing: Handling multi-timezone UTC timestamps, period offsets, and date formatting"
      ]
    }],
    2: [{
      id: "ba-wrg-p2-merging-reshaping",
      title: "Data Reshaping: Merge, Join, Concat, Pivot Tables & Melt in Pandas",
      youtube_video_id: "TPivN7tpdwc",
      youtube_url: "https://www.youtube.com/watch?v=TPivN7tpdwc",
      fallback_video_id: "M3oB2urOHXY",
      search_query: "Pandas Merge Join Concatenate Pivot Table Melt Reshaping DataFrames",
      channel_name: "Alex The Analyst",
      duration: "29:30",
      difficulty: "Intermediate",
      topic_focus: "SQL-Style Joins (Inner, Left, Right, Outer), MultiIndex, .pivot() vs .melt()",
      key_takeaways: [
        "Executing relational joins: pd.merge() with one-to-one, one-to-many, and many-to-many validations",
        "Detecting join cardinality errors using the validate parameter ('1:m', 'm:1')",
        "Reshaping wide format datasets into long/tidy format using pd.melt()",
        "Multi-dimensional aggregations using .pivot_table() with custom margins and aggregate functions"
      ]
    }],
    3: [{
      id: "ba-wrg-p3-etl-pipeline",
      title: "Automated ETL Data Pipelines: Python, DuckDB & Batch Parquet Storage",
      youtube_video_id: "Vh0qcDerBMc",
      youtube_url: "https://www.youtube.com/watch?v=Vh0qcDerBMc",
      fallback_video_id: "WN09N4fnA6k",
      search_query: "Python ETL Pipeline Automated Data Cleaning DuckDB Parquet Data Engineering",
      channel_name: "Data with Baraa",
      duration: "34:20",
      difficulty: "Advanced",
      topic_focus: "Extract-Transform-Load (ETL) Architecture, Schema Validation (Pydantic) & Parquet Partitioning",
      key_takeaways: [
        "Designing modular ETL pipeline architectures: Staging, transformation, and curated data lakes",
        "Enforcing strict data schema contracts using Pydantic and Great Expectations data quality tests",
        "In-memory analytical SQL transformations at scale using DuckDB on multi-gigabyte datasets",
        "Writing partitioned columnar Parquet files optimized for downstream business intelligence queries"
      ]
    }],
    4: [{
      id: "ba-wrg-p4-wrangling-interview",
      title: "Data Analytics Technical Placement Interview: Pandas Live Coding & SQL/ETL Viva",
      youtube_video_id: "P5O5_V-QoZs",
      youtube_url: "https://www.youtube.com/watch?v=P5O5_V-QoZs",
      fallback_video_id: "0laFEPwQ59o",
      search_query: "Data Analyst Live Coding Interview Pandas Data Wrangling SQL Technical Questions",
      channel_name: "Jie Jenn",
      duration: "31:45",
      difficulty: "Placement",
      topic_focus: "Live Coding Screening, Vectorized Operations vs Slow Loops, Anomaly Detection & Viva",
      key_takeaways: [
        "Solving complex live coding data wrangling tasks under 45-minute timed interview constraints",
        "Vectorized execution vs Python for-loops: Explaining Cython-backed execution speeds",
        "Handling edge cases: Outliers, mismatched date formats, duplicate primary keys, null joins",
        "Acing data analyst technical screening at Deloitte, McKinsey, Amazon, and Fractal Analytics"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 2. Advanced Excel & Financial Modeling
  // --------------------------------------------------------------------------
  'ba-excel': {
    0: [{
      id: "ba-xl-p0-modern-formulas",
      title: "Modern Excel Mastery: XLOOKUP, INDEX/MATCH & Dynamic Array Functions",
      youtube_video_id: "4c0CLUER6nw",
      youtube_url: "https://www.youtube.com/watch?v=4c0CLUER6nw",
      fallback_video_id: "6JhbY8Mku1A",
      search_query: "Excel XLOOKUP vs INDEX MATCH Dynamic Arrays FILTER UNIQUE SORT",
      channel_name: "Leila Gharani",
      duration: "24:50",
      difficulty: "Beginner",
      topic_focus: "XLOOKUP Left-Lookups, Multi-Criteria Lookups, FILTER(), UNIQUE() & Spill Ranges (#)",
      key_takeaways: [
        "Why XLOOKUP obsoletes VLOOKUP: Exact match default, left lookups, horizontal lookups",
        "Two-way matrix lookup using nested XLOOKUP or classic INDEX/MATCH combinations",
        "Modern dynamic array formulas: FILTER(), UNIQUE(), SORT(), and SORTBY()",
        "Managing spill range operators (#) and resolving #SPILL! blockage errors"
      ]
    }],
    1: [{
      id: "ba-xl-p1-pivots-powerquery",
      title: "Power Query in Excel: Automated Data Cleaning & Advanced Pivot Tables",
      youtube_video_id: "x7mzOYEn0XA",
      youtube_url: "https://www.youtube.com/watch?v=x7mzOYEn0XA",
      fallback_video_id: "dvbLrwD2SpA",
      search_query: "Excel Power Query Tutorial Clean Data Automate Reports Pivot Tables Slicers",
      channel_name: "Leila Gharani",
      duration: "28:30",
      difficulty: "Intermediate",
      topic_focus: "Power Query Applied Steps (M Code), Unpivoting Columns, Pivot Table Slicers & Timelines",
      key_takeaways: [
        "Extracting and transforming recurring monthly data sheets automatically with Power Query",
        "Applied Steps pane: Cleaning headers, filtering rows, and unpivoting cross-tabulated reports",
        "Building interactive executive dashboards: Pivot Tables, Calculated Fields, and linked visual Slicers",
        "Refreshing all linked workbook connections with a single click without manual formula rewriting"
      ]
    }],
    2: [{
      id: "ba-xl-p2-scenario-modeling",
      title: "Scenario Planning & Financial Sensitivity: Data Tables, Goal Seek & Solver",
      youtube_video_id: "Sciznx39zzk",
      youtube_url: "https://www.youtube.com/watch?v=Sciznx39zzk",
      fallback_video_id: "ju0ZQRlDixM",
      search_query: "Excel What If Analysis Data Tables 1 Variable 2 Variable Goal Seek Solver Sensitivity",
      channel_name: "WsCube Tech",
      duration: "26:40",
      difficulty: "Intermediate",
      topic_focus: "What-If Analysis, 1-Variable & 2-Variable Sensitivity Data Tables, Goal Seek & Solver Optimization",
      key_takeaways: [
        "Constructing 1-variable and 2-variable sensitivity data tables for margin and pricing trade-offs",
        "Reverse engineering targets using Goal Seek: Determining required sales volume for target EBIT",
        "Multi-variable constrained optimization using Excel Solver (Simplex LP and GRG Non-Linear)",
        "Scenario Manager: Defining Best Case, Base Case, and Worst Case macroeconomic projections"
      ]
    }],
    3: [{
      id: "ba-xl-p3-3statement-model",
      title: "Dynamic 3-Statement Financial Modeling in Excel: Income Statement, Balance Sheet & Cash Flow",
      youtube_video_id: "UMYDxmiVin4",
      youtube_url: "https://www.youtube.com/watch?v=UMYDxmiVin4",
      fallback_video_id: "OGJBapKV1oE",
      search_query: "3 Statement Financial Model Excel Income Statement Balance Sheet Cash Flow Debt Schedule",
      channel_name: "Corporate Finance Institute",
      duration: "35:10",
      difficulty: "Advanced",
      topic_focus: "Circular References, Debt Schedules, Working Capital Drivers & Integrated Balance Check",
      key_takeaways: [
        "Structuring an institutional-grade 3-statement model: Historical data, assumptions, and forecast periods",
        "Forecasting operational revenue schedules, COGS gross margins, and SG&A expense drivers",
        "Building supporting debt and interest schedules, PP&E depreciation waterfalls",
        "Dynamic 3-statement integration: Linking Net Income to Cash Flow, and ending Cash to the Balance Sheet (Balance check = 0)"
      ]
    }],
    4: [{
      id: "ba-xl-p4-excel-interview",
      title: "Financial & Business Analyst Excel Modeling Placement Test / Screening Exam",
      youtube_video_id: "nh9F1YMY9nM",
      youtube_url: "https://www.youtube.com/watch?v=nh9F1YMY9nM",
      fallback_video_id: "sHpSVB9WSLc",
      search_query: "Excel Modeling Test for Finance Business Analyst Interview Questions Timed Test",
      channel_name: "Online Training for Everyone",
      duration: "30:20",
      difficulty: "Placement",
      topic_focus: "Keyboard Shortcuts (No Mouse), Audit Tracing (Ctrl + [), Error Checks & Modeling Viva",
      key_takeaways: [
        "Wall Street / corporate finance modeling standards: Blue inputs, black formulas, green cross-sheet links",
        "Navigating and building models entirely via keyboard shortcuts without touching the mouse",
        "Auditing formulas using Trace Precedents (Ctrl + [) and Trace Dependents (Ctrl + ])",
        "Passing 1-hour timed corporate modeling assessments at Goldman Sachs, EY, PwC, and Morgan Stanley"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 3. SQL & Relational Analytics
  // --------------------------------------------------------------------------
  'ba-sql': {
    0: [{
      id: "ba-sql-p0-queries-basics",
      title: "SQL for Analytics: SELECT, Filtering, Aggregations & GROUP BY Mastery",
      youtube_video_id: "OT1RErkfLNQ",
      youtube_url: "https://www.youtube.com/watch?v=OT1RErkfLNQ",
      fallback_video_id: "7mz73uXD9DA",
      search_query: "SQL for Beginners Full Course Alex The Analyst SELECT WHERE GROUP BY HAVING",
      channel_name: "Alex The Analyst",
      duration: "25:30",
      difficulty: "Beginner",
      topic_focus: "Order of Execution, WHERE vs HAVING, Aggregate Functions (SUM, AVG, COUNT) & CASE WHEN",
      key_takeaways: [
        "The relational SQL logical query execution order: FROM -> WHERE -> GROUP BY -> HAVING -> SELECT -> ORDER BY",
        "Differentiating row-level filtering (WHERE) from aggregated grouped filtering (HAVING)",
        "Conditional business logic using CASE WHEN ... THEN ... ELSE ... END statements",
        "Handling NULL values: IS NULL, IS NOT NULL, COALESCE(), and NULLIF() functions"
      ]
    }],
    1: [{
      id: "ba-sql-p1-joins-subqueries",
      title: "SQL Joins & Subqueries: Multi-Table Relational Data Modeling",
      youtube_video_id: "H6988OpZKTU",
      youtube_url: "https://www.youtube.com/watch?v=H6988OpZKTU",
      fallback_video_id: "0OQJDd3QqQM",
      search_query: "SQL Joins Inner Left Right Full Self Join Subqueries Correlated Subqueries",
      channel_name: "Rishabh Mishra",
      duration: "28:40",
      difficulty: "Intermediate",
      topic_focus: "INNER, LEFT, FULL OUTER Joins, Self-Joins, Anti-Joins & Correlated Subqueries",
      key_takeaways: [
        "Relational joins: Joining fact tables to dimension tables using primary and foreign key constraints",
        "Finding missing customer records using LEFT JOIN ... WHERE right_table.id IS NULL (Anti-Join)",
        "Self-joins for hierarchical organizational structures (manager-employee hierarchies)",
        "Scalar subqueries vs correlated subqueries and evaluating query execution plan bottlenecks"
      ]
    }],
    2: [{
      id: "ba-sql-p2-window-functions",
      title: "Advanced SQL Window Functions: ROW_NUMBER, RANK, DENSE_RANK, LEAD & LAG",
      youtube_video_id: "Ww71knvhQ-s",
      youtube_url: "https://www.youtube.com/watch?v=Ww71knvhQ-s",
      fallback_video_id: "K1WeoKxLZ5o",
      search_query: "SQL Window Functions OVER PARTITION BY ROW_NUMBER RANK DENSE_RANK LEAD LAG",
      channel_name: "techTFQ",
      duration: "31:15",
      difficulty: "Intermediate",
      topic_focus: "OVER (PARTITION BY ... ORDER BY ...), Running Totals, Moving Averages & Period-over-Period",
      key_takeaways: [
        "Understanding window frames: Computing row-level metrics without collapsing rows like GROUP BY",
        "Differentiating ranking functions: ROW_NUMBER() (unique), RANK() (skips ties), DENSE_RANK() (no gaps)",
        "Calculating period-over-period growth using LAG() and LEAD() offsets",
        "Computing rolling 7-day and 30-day moving averages using ROWS BETWEEN 6 PRECEDING AND CURRENT ROW"
      ]
    }],
    3: [{
      id: "ba-sql-p3-ctes-optimization",
      title: "Common Table Expressions (CTEs), Recursive Queries & Index Optimization",
      youtube_video_id: "QNfnuK-1YYY",
      youtube_url: "https://www.youtube.com/watch?v=QNfnuK-1YYY",
      fallback_video_id: "LJC8277LONg",
      search_query: "SQL Common Table Expressions CTE WITH Clause Recursive CTE Index Tuning EXPLAIN ANALYZE",
      channel_name: "techTFQ",
      duration: "33:45",
      difficulty: "Advanced",
      topic_focus: "WITH Clause Modularity, Recursive CTEs (Bill of Materials), EXPLAIN ANALYZE & B-Tree Indexes",
      key_takeaways: [
        "Refactoring complex nested subqueries into clean, readable Common Table Expressions (CTEs)",
        "Recursive CTEs for graph traversal, hierarchical reporting structures, and date spine generation",
        "Reading query execution plans using EXPLAIN ANALYZE: Identifying sequential table scans vs index scans",
        "Designing composite B-tree indexes matching query filter, join, and sort conditions"
      ]
    }],
    4: [{
      id: "ba-sql-p4-sql-interview",
      title: "SQL Analytics Technical Placement Interview: FAANG Hard LeetCode / HackerRank Viva",
      youtube_video_id: "Xh0EevUOWF0",
      youtube_url: "https://www.youtube.com/watch?v=Xh0EevUOWF0",
      fallback_video_id: "sua7xKN0cPc",
      search_query: "SQL Technical Interview Questions FAANG LeetCode Hard Data Analyst Viva Ankit Bansal",
      channel_name: "Ankit Bansal",
      duration: "32:50",
      difficulty: "Placement",
      topic_focus: "Retention Churn Queries, Nth Highest Salary, Consecutive Logins & SQL Viva",
      key_takeaways: [
        "Solving classic interview challenges: Nth highest salary using DENSE_RANK()",
        "User retention cohort analysis: Calculating Day-1, Day-7, and Day-30 retention rates in pure SQL",
        "Detecting consecutive active user login streaks using the difference between row numbers and dates",
        "Clearing data analyst and BI engineer SQL whiteboard screening rounds at Meta, Uber, and Amazon"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 4. Power BI & DAX Dashboards
  // --------------------------------------------------------------------------
  'ba-powerbi': {
    0: [{
      id: "ba-pbi-p0-data-model",
      title: "Power BI Desktop for Beginners: Data Loading, Relationships & Star Schema",
      youtube_video_id: "OmW9YvxSl1E",
      youtube_url: "https://www.youtube.com/watch?v=OmW9YvxSl1E",
      fallback_video_id: "1bysgMsPwC4",
      search_query: "Power BI Tutorial for Beginners Full Course Star Schema Data Modeling Guy in a Cube",
      channel_name: "Guy in a Cube",
      duration: "26:30",
      difficulty: "Beginner",
      topic_focus: "Star Schema (Fact Tables vs Dimension Tables), Cardinality (1:*), Cross-Filter Direction",
      key_takeaways: [
        "Principles of Kimball dimensional modeling: Central Fact table surrounded by Dimension tables",
        "Setting up relationship cardinality: One-to-many (1:*) single-direction relationships for optimal engine performance",
        "Why bidirectional cross-filtering introduces ambiguity and performance degradation in large data models",
        "Creating a dedicated, continuous Date Table using CALENDARAUTO() for time intelligence"
      ]
    }],
    1: [{
      id: "ba-pbi-p1-dax-basics",
      title: "DAX First Principles: Calculated Columns vs Measures and Context Transition",
      youtube_video_id: "SlQJaryCLy4",
      youtube_url: "https://www.youtube.com/watch?v=SlQJaryCLy4",
      fallback_video_id: "Rpa8mDH7mes",
      search_query: "DAX for Power BI Calculated Columns vs Measures Row Context Filter Context Avi Singh",
      channel_name: "Avi Singh - PowerBIPro",
      duration: "28:50",
      difficulty: "Intermediate",
      topic_focus: "Row Context vs Filter Context, CALCULATE(), Implicit vs Explicit Measures & Context Transition",
      key_takeaways: [
        "Crucial distinction: Calculated Columns (computed at refresh, stored in RAM) vs Measures (evaluated dynamically on query)",
        "The two evaluation contexts of DAX: Row Context (iterating tables) and Filter Context (active report filters)",
        "The master function of DAX: CALCULATE() and how it overrides and modifies existing filter context",
        "Context transition: Converting row context into an equivalent filter context inside CALCULATE()"
      ]
    }],
    2: [{
      id: "ba-pbi-p2-time-intelligence",
      title: "Advanced DAX Time Intelligence: YTD, MTD, SAMEPERIODLASTYEAR & Moving Totals",
      youtube_video_id: "WsWDjH-CgHg",
      youtube_url: "https://www.youtube.com/watch?v=WsWDjH-CgHg",
      fallback_video_id: "U86045UGoW8",
      search_query: "DAX Time Intelligence TOTALYTD SAMEPERIODLASTYEAR DATESYTD Moving Averages",
      channel_name: "Rahim Zulfiqar Ali",
      duration: "30:15",
      difficulty: "Intermediate",
      topic_focus: "TOTALYTD(), DATESYTD(), SAMEPERIODLASTYEAR(), YoY% Growth & Rolling LTM Calculations",
      key_takeaways: [
        "Prerequisites for accurate time intelligence: A dedicated calendar table marked as Date Table",
        "Writing Year-to-Date (YTD) and Quarter-to-Date (QTD) measures using TOTALYTD() and DATESBETWEEN()",
        "Computing Year-over-Year (YoY) revenue and growth percentages using SAMEPERIODLASTYEAR()",
        "Designing rolling Last Twelve Months (LTM) revenue calculations independent of calendar year boundaries"
      ]
    }],
    3: [{
      id: "ba-pbi-p3-rls-publishing",
      title: "Row-Level Security (RLS), Drillthrough Pages & Power BI Service Deployment",
      youtube_video_id: "MxU_FYSSnYU",
      youtube_url: "https://www.youtube.com/watch?v=MxU_FYSSnYU",
      fallback_video_id: "L-rGuFCOn18",
      search_query: "Power BI Row Level Security RLS Dynamic Security USERNAME Power BI Service Workspaces",
      channel_name: "Guy in a Cube",
      duration: "33:20",
      difficulty: "Advanced",
      topic_focus: "Dynamic RLS with USERPRINCIPALNAME(), Drillthrough Filters, Bookmarks & Workspace Roles",
      key_takeaways: [
        "Implementing dynamic Row-Level Security (RLS) using USERPRINCIPALNAME() to restrict data access by sales territory",
        "Designing intuitive navigation: Drillthrough target pages passing filter context automatically",
        "Using report bookmarks and selection panes to create interactive modal popup filter panels",
        "Publishing to Power BI Service: Configuring scheduled gateway refreshes, App workspaces, and viewer permissions"
      ]
    }],
    4: [{
      id: "ba-pbi-p4-powerbi-interview",
      title: "Power BI Developer / BI Engineer Placement Interview & DAX Performance Viva",
      youtube_video_id: "C5HBhlLUFsE",
      youtube_url: "https://www.youtube.com/watch?v=C5HBhlLUFsE",
      fallback_video_id: "aZihsRsEYTE",
      search_query: "Power BI Developer Interview Questions DAX Studio Performance Analyzer VertiPaq Viva",
      channel_name: "SQLBI",
      duration: "31:40",
      difficulty: "Placement",
      topic_focus: "VertiPaq Engine Compression, DAX Studio Query Plans, Performance Analyzer & Placement Viva",
      key_takeaways: [
        "How the VertiPaq columnar in-memory engine compresses data: Dictionary encoding, run-length encoding, bit-packing",
        "Diagnosing slow visual render times using Performance Analyzer and optimizing DAX queries in DAX Studio",
        "Eliminating high-cardinality datetime columns and converting auto-date/time hierarchies to save memory",
        "Acing Power BI developer and business intelligence consultant technical interviews at Accenture, KPMG, and Microsoft"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 5. Tableau Visual Analytics & Storytelling
  // --------------------------------------------------------------------------
  'ba-tableau': {
    0: [{
      id: "ba-tab-p0-tableau-basics",
      title: "Tableau Desktop for Beginners: Dimensions vs Measures, Discrete vs Continuous",
      youtube_video_id: "QYnkudCxbmE",
      youtube_url: "https://www.youtube.com/watch?v=QYnkudCxbmE",
      fallback_video_id: "iuYPp8KJ6lg",
      search_query: "Tableau for Beginners Full Course Dimensions Measures Blue vs Green Pills",
      channel_name: "Abhishek Agarrwal",
      duration: "25:15",
      difficulty: "Beginner",
      topic_focus: "Blue (Discrete) vs Green (Continuous) Pills, Marks Card (Color, Size, Shape) & Show Me Menu",
      key_takeaways: [
        "The core data distinction in Tableau: Blue pills (discrete headers) vs Green pills (continuous axes)",
        "Dimensions (categorical slice attributes) vs Measures (numeric quantitative values)",
        "Utilizing the Marks Card: Controlling visual encodings (Color, Size, Detail, Tooltip, Shape)",
        "Building foundational chart types: Bar charts, line trend charts, scatter plots, and dual-axis combination charts"
      ]
    }],
    1: [{
      id: "ba-tab-p1-calculated-fields",
      title: "Tableau Calculations: Logical Functions, Table Calculations & Quick Calculations",
      youtube_video_id: "2f7Sl5WEExw",
      youtube_url: "https://www.youtube.com/watch?v=2f7Sl5WEExw",
      fallback_video_id: "j3lFq-9SVLg",
      search_query: "Tableau Calculated Fields Table Calculations Running Total Percent of Total Rank",
      channel_name: "TutorialsPoint",
      duration: "28:10",
      difficulty: "Intermediate",
      topic_focus: "Calculated Fields (IF/THEN, CASE, DATEDIFF), Quick Table Calculations (Running Total, % of Total)",
      key_takeaways: [
        "Writing custom Calculated Fields for business logic: IF/THEN conditions, string parsing, and date manipulation",
        "Quick Table Calculations: Running total, percentage of total, rank, and difference from previous period",
        "Directional table computation options: Table (across), Table (down), Pane (across), or specific dimensions",
        "Creating interactive user parameters and linking them to dynamic dimension-swapping calculated fields"
      ]
    }],
    2: [{
      id: "ba-tab-p2-lod-expressions",
      title: "Level of Detail (LOD) Expressions in Tableau: FIXED, INCLUDE & EXCLUDE",
      youtube_video_id: "cnb_b3i0f-U",
      youtube_url: "https://www.youtube.com/watch?v=cnb_b3i0f-U",
      fallback_video_id: "8iXXjODMk-I",
      search_query: "Tableau Level of Detail LOD Expressions FIXED INCLUDE EXCLUDE Tutorial",
      channel_name: "datachampp",
      duration: "30:40",
      difficulty: "Advanced",
      topic_focus: "Tableau Order of Operations, FIXED LOD (Independent of View), INCLUDE vs EXCLUDE",
      key_takeaways: [
        "Tableau Order of Operations: Extract filters -> Data source filters -> Context filters -> FIXED LOD -> Dimension filters",
        "FIXED LOD expressions: Computing values at specified dimension levels independent of current worksheet visualization",
        "Calculating cohort lifetime value and customer first purchase date using {FIXED [Customer ID] : MIN([Order Date])}",
        "INCLUDE and EXCLUDE LODs: Adding or ignoring specific worksheet view dimensions for accurate granular averages"
      ]
    }],
    3: [{
      id: "ba-tab-p3-executive-dashboards",
      title: "Designing Executive Dashboards: Layout Containers, Actions & Visual Storytelling",
      youtube_video_id: "mAYvayW77Vw",
      youtube_url: "https://www.youtube.com/watch?v=mAYvayW77Vw",
      fallback_video_id: "PgKJ1ti_dRc",
      search_query: "Tableau Dashboard Design Layout Containers Filter Actions Parameter Actions UI UX",
      channel_name: "Data with Baraa",
      duration: "33:10",
      difficulty: "Advanced",
      topic_focus: "Tiled vs Floating Layouts, Horizontal/Vertical Containers, Dashboard Actions & Visual Hierarchy",
      key_takeaways: [
        "Structuring professional dashboard layouts using nested Horizontal and Vertical layout containers",
        "Implementing interactive Dashboard Actions: Filter actions, highlight actions, URL actions, and parameter actions",
        "Visual hierarchy and cognitive load: Placing executive North Star KPIs prominently at top-left",
        "Formatting custom Tooltips using Viz in Tooltip: Embedding micro-charts inside hover tooltips"
      ]
    }],
    4: [{
      id: "ba-tab-p4-tableau-interview",
      title: "Tableau Specialist / Business Intelligence Placement Interview Screening Viva",
      youtube_video_id: "_i5xyQXdLLw",
      youtube_url: "https://www.youtube.com/watch?v=_i5xyQXdLLw",
      fallback_video_id: "1IgTza3NaRk",
      search_query: "Tableau Developer Interview Questions Context Filters Order of Operations Viva",
      channel_name: "Meritshot Education",
      duration: "29:50",
      difficulty: "Placement",
      topic_focus: "Context Filter Promotion, Extract vs Live Connections, Tableau Server Publishing & Viva",
      key_takeaways: [
        "Explaining why promoting a normal dimension filter to a Context Filter forces it to execute before FIXED LODs",
        "Performance optimization: Live connections vs Hyper extracts; reducing mark counts and avoiding complex table calcs",
        "Managing Tableau Server / Tableau Cloud permissions, user filters, and automated subscription alerts",
        "Acing Tableau technical assessments and corporate business analyst interviews at Slalom, Bain, and Salesforce"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 6. Python for Data Analysis (Pandas/NumPy)
  // --------------------------------------------------------------------------
  'ba-python': {
    0: [{
      id: "ba-py-p0-numpy-vectorization",
      title: "NumPy for Data Science: N-Dimensional Arrays, Broadcasting & Vectorized Math",
      youtube_video_id: "GB9ByFAIAH4",
      youtube_url: "https://www.youtube.com/watch?v=GB9ByFAIAH4",
      fallback_video_id: "QUT1VHiLmmI",
      search_query: "NumPy Tutorial for Beginners Arrays Broadcasting Vectorization Keith Galli",
      channel_name: "Keith Galli",
      duration: "24:20",
      difficulty: "Beginner",
      topic_focus: "np.ndarray Memory Layout, Vectorized Arithmetic, Broadcasting Rules & Slicing",
      key_takeaways: [
        "Why NumPy arrays outperform Python lists: Contiguous C-memory blocks and homogeneous data types",
        "Array creation, reshaping, indexing, and slicing in multi-dimensional matrices",
        "The NumPy Broadcasting rules: Performing element-wise mathematical operations across arrays of compatible shapes",
        "Mathematical and statistical functions: np.sum(), np.mean(), np.std(), np.dot() matrix multiplication"
      ]
    }],
    1: [{
      id: "ba-py-p1-seaborn-eda",
      title: "Exploratory Data Analysis (EDA) with Seaborn & Matplotlib",
      youtube_video_id: "hLbVXF70BCE",
      youtube_url: "https://www.youtube.com/watch?v=hLbVXF70BCE",
      fallback_video_id: "-jTD74eEy2I",
      search_query: "Seaborn Data Visualization Tutorial Exploratory Data Analysis Heatmaps Distribution",
      channel_name: "WsCube Tech",
      duration: "27:45",
      difficulty: "Intermediate",
      topic_focus: "Distribution Plots (histplot, kdeplot), Categorical Plots (boxplot, violinplot) & Correlation Heatmaps",
      key_takeaways: [
        "Conducting structured Exploratory Data Analysis (EDA) to uncover patterns, skewness, and anomalies",
        "Visualizing numeric univariate distributions: Histograms with Kernel Density Estimation (KDE)",
        "Bivariate and multivariate relationship charting: Scatter plots with categorical hue conditioning",
        "Generating correlation matrices (df.corr()) and plotting Pearson correlation heatmaps with sns.heatmap()"
      ]
    }],
    2: [{
      id: "ba-py-p2-feature-engineering",
      title: "Feature Engineering with Scikit-Learn: Encoding, Scaling & Pipelines",
      youtube_video_id: "rsyrZnZ8J2o",
      youtube_url: "https://www.youtube.com/watch?v=rsyrZnZ8J2o",
      fallback_video_id: "777Qb0gHuJU",
      search_query: "Feature Engineering Scikit Learn OneHotEncoder StandardScaler ColumnTransformer Pipeline",
      channel_name: "Ryan & Matt Data Science",
      duration: "29:30",
      difficulty: "Intermediate",
      topic_focus: "OneHotEncoder vs OrdinalEncoder, StandardScaler vs MinMaxScaler, ColumnTransformer & Pipeline",
      key_takeaways: [
        "Encoding categorical features: OneHotEncoder (nominal data) vs OrdinalEncoder (ordered tiers)",
        "Feature scaling: StandardScaler (z-score normalization) vs MinMaxScaler (0-1 range) to prevent gradient divergence",
        "Preventing data leakage: Fitting scalers strictly on training splits before transforming test splits",
        "Assembling reproducible preprocessing workflows using Scikit-Learn's ColumnTransformer and Pipeline"
      ]
    }],
    3: [{
      id: "ba-py-p3-customer-segmentation",
      title: "Customer Segmentation Capstone: RFM Analysis & K-Means Clustering in Python",
      youtube_video_id: "WvmFjuGxneI",
      youtube_url: "https://www.youtube.com/watch?v=WvmFjuGxneI",
      fallback_video_id: "-LGwdrajMZ0",
      search_query: "Customer Segmentation RFM Analysis KMeans Clustering Python Machine Learning Project",
      channel_name: "Ronith Sharmila",
      duration: "34:10",
      difficulty: "Advanced",
      topic_focus: "Recency, Frequency, Monetary (RFM) Scoring, Elbow Method, Silhouette Score & PCA",
      key_takeaways: [
        "Engineering behavioral e-commerce features: Calculating Recency, Frequency, and Monetary (RFM) values",
        "Log-transforming skewed financial spending distributions and scaling variables",
        "K-Means clustering: Finding optimal cluster count (K) using the Elbow Method (Inertia) and Silhouette Scores",
        "Dimensionality reduction with Principal Component Analysis (PCA) to visualize multi-dimensional customer clusters in 2D"
      ]
    }],
    4: [{
      id: "ba-py-p4-python-analytics-interview",
      title: "Python Data Analyst / Analytics Engineer Placement Interview Screening Viva",
      youtube_video_id: "0laFEPwQ59o",
      youtube_url: "https://www.youtube.com/watch?v=0laFEPwQ59o",
      fallback_video_id: "NLBQaNl__JI",
      search_query: "Python Data Analyst Technical Interview Questions Pandas Algorithm Coding Viva",
      channel_name: "Dr. Aditi Gupta",
      duration: "30:40",
      difficulty: "Placement",
      topic_focus: "Memory Management (Categorical Dtypes), GroupBy Aggregations, Vectorization & Technical Viva",
      key_takeaways: [
        "Optimizing DataFrame memory consumption by 80% using categorical data types and downcasting integers",
        "Complex grouping operations: .groupby() combined with custom lambda functions and .agg() dictionaries",
        "Defending data science design choices: Model evaluation metrics (Precision, Recall, F1) vs Business ROI",
        "Acing Python analytics technical interviews at Uber, Airbnb, Capital One, and Target"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 7. Business Requirements Gathering (BRD/FRD)
  // --------------------------------------------------------------------------
  'ba-brd': {
    0: [{
      id: "ba-brd-p0-ba-role",
      title: "Role of the Business Analyst: Software Development Life Cycle (SDLC) & BABOK Guide",
      youtube_video_id: "tv0XBLZjLkw",
      youtube_url: "https://www.youtube.com/watch?v=tv0XBLZjLkw",
      fallback_video_id: "rgP0RR4Kaxc",
      search_query: "Business Analyst Role Explained BABOK SDLC Agile vs Waterfall Business Analysis",
      channel_name: "Techcanvass",
      duration: "24:15",
      difficulty: "Beginner",
      topic_focus: "IIBA BABOK Core Knowledge Areas, SDLC Lifecycles (Agile Scrum vs Waterfall) & BA Deliverables",
      key_takeaways: [
        "The primary mission of the Business Analyst: Bridging business stakeholder problems with technical software solutions",
        "The 6 Knowledge Areas of the IIBA BABOK Guide: Elicitation, Requirements Lifecycle, Strategy Analysis",
        "Differentiating delivery methodologies: Waterfall (sequential documentation) vs Agile Scrum (iterative sprints)",
        "Core BA artifacts: Business Case, BRD, FRD, Traceability Matrix, and User Acceptance Criteria"
      ]
    }],
    1: [{
      id: "ba-brd-p1-elicitation",
      title: "Requirements Elicitation Techniques: Stakeholder Interviews, JAD Sessions & Surveys",
      youtube_video_id: "_O24OWWZOVI",
      youtube_url: "https://www.youtube.com/watch?v=_O24OWWZOVI",
      fallback_video_id: "oPBvItl2-cs",
      search_query: "Requirements Elicitation Techniques Business Analysis JAD Sessions Interviews Surveys",
      channel_name: "Effortless Business Analysis",
      duration: "27:30",
      difficulty: "Intermediate",
      topic_focus: "Stakeholder Identification (RACI Matrix), Open-Ended Discovery Questions & Active Listening",
      key_takeaways: [
        "Mapping project stakeholders using the RACI Matrix: Responsible, Accountable, Consulted, Informed",
        "Conducting effective stakeholder discovery interviews: Open-ended probing questions vs leading questions",
        "Facilitating Joint Application Design (JAD) workshops to achieve rapid consensus across conflicting departments",
        "Documenting elicitation interview notes into verifiable stakeholder requirement statements"
      ]
    }],
    2: [{
      id: "ba-brd-p2-brd-vs-frd",
      title: "Authoring Business Requirements (BRD) vs Functional Requirements Documents (FRD)",
      youtube_video_id: "Cdbhq7ut6Lw",
      youtube_url: "https://www.youtube.com/watch?v=Cdbhq7ut6Lw",
      fallback_video_id: "h5LGD3xLNaM",
      search_query: "BRD vs FRD Business Requirements Document Functional Specifications Document SRS",
      channel_name: "YourITLearning",
      duration: "29:45",
      difficulty: "Intermediate",
      topic_focus: "Business Needs (Why & What) vs Functional Specs (How the System Operates), Non-Functional Requirements",
      key_takeaways: [
        "Structure of a formal BRD: Executive summary, business problem statement, project scope, and business rules",
        "Decomposing BRD into FRD / Software Requirements Specifications (SRS): Exact system screens, inputs, error states",
        "Specifying Non-Functional Requirements (NFRs): Performance latency (<200ms), security, scalability, and availability",
        "Writing unambiguous, testable requirement statements using RFC 2119 keywords (SHALL, MUST, SHOULD)"
      ]
    }],
    3: [{
      id: "ba-brd-p3-user-stories-rtm",
      title: "Agile User Stories, Acceptance Criteria (Gherkin / Given-When-Then) & RTM",
      youtube_video_id: "7hoGqhb6qAs",
      youtube_url: "https://www.youtube.com/watch?v=7hoGqhb6qAs",
      fallback_video_id: "q5E2hFOpooI",
      search_query: "Agile User Stories Acceptance Criteria Given When Then INVEST Requirements Traceability Matrix",
      channel_name: "The Agile Shop",
      duration: "32:20",
      difficulty: "Advanced",
      topic_focus: "INVEST User Story Framework, Gherkin Syntax (Given-When-Then) & Requirements Traceability (RTM)",
      key_takeaways: [
        "Authoring Agile User Stories: 'As a [user role], I want [capability] so that [business benefit]'",
        "Applying the INVEST criteria: Independent, Negotiable, Valuable, Estimable, Small, Testable",
        "Writing testable Acceptance Criteria using Behavior-Driven Development (BDD) Gherkin syntax (Given-When-Then)",
        "Maintaining a bidirectional Requirements Traceability Matrix (RTM) linking business needs to test cases"
      ]
    }],
    4: [{
      id: "ba-brd-p4-ba-interview",
      title: "Business Analyst Placement Interview & Requirements Scenario Case Study Viva",
      youtube_video_id: "tDn2P9YW1mU",
      youtube_url: "https://www.youtube.com/watch?v=tDn2P9YW1mU",
      fallback_video_id: "rb7JWRVMfr0",
      search_query: "Business Analyst Interview Questions Scenario Based Case Study Scope Creep Viva",
      channel_name: "Angelo the BA",
      duration: "31:10",
      difficulty: "Placement",
      topic_focus: "Managing Scope Creep, Conflicting Stakeholder Priorities, Change Requests & Placement Viva",
      key_takeaways: [
        "Managing scope creep: Formal Change Request (CR) assessment, impact analysis on cost and timeline",
        "Handling conflicting requirements between senior executive sponsors and day-to-day end users",
        "Leading User Acceptance Testing (UAT): Defect triaging, sign-off criteria, and Go/No-Go readiness reviews",
        "Passing Business Analyst scenario interviews at Accenture, Cognizant, Infosys, and Capgemini"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 8. Business Process Modeling (BPMN 2.0)
  // --------------------------------------------------------------------------
  'ba-bpmn': {
    0: [{
      id: "ba-bpm-p0-basics",
      title: "BPMN 2.0 for Beginners: Activities, Events, Gateways & Sequence Flows",
      youtube_video_id: "1ZPLfjkU564",
      youtube_url: "https://www.youtube.com/watch?v=1ZPLfjkU564",
      fallback_video_id: "iSlR0Q0nlIk",
      search_query: "BPMN 2.0 Tutorial for Beginners Business Process Model and Notation Gateways Events",
      channel_name: "Champa Intelligence",
      duration: "23:40",
      difficulty: "Beginner",
      topic_focus: "Flow Objects (Start/End Events, Tasks), Gateways (Exclusive, Parallel) & Connecting Objects",
      key_takeaways: [
        "The standard BPMN 2.0 notation symbols: Tasks (rectangles), Events (circles), and Gateways (diamonds)",
        "Connecting objects: Unbroken solid line for Sequence Flows; dashed line with open arrow for Message Flows",
        "Exclusive XOR Gateway (X): Diverting execution along exactly one path based on condition evaluation",
        "Parallel AND Gateway (+): Forking execution into concurrent parallel workflows; synchronizing paths"
      ]
    }],
    1: [{
      id: "ba-bpm-p1-pools-lanes",
      title: "Pools & Swimlanes in BPMN: Business-to-Business (B2B) Process Collaboration",
      youtube_video_id: "SSh5mlgB4Ks",
      youtube_url: "https://www.youtube.com/watch?v=SSh5mlgB4Ks",
      fallback_video_id: "4LM29lI3C3I",
      search_query: "BPMN Pools and Swimlanes Business Process Mapping Cross Functional Flowchart",
      channel_name: "Camunda",
      duration: "27:15",
      difficulty: "Intermediate",
      topic_focus: "Pools (Organizations/Systems), Swimlanes (Departments/Roles) & Message Flow Rules",
      key_takeaways: [
        "Pools: Representing distinct organizational boundaries or external business partners (e.g. Customer vs Vendor)",
        "Swimlanes: Subdividing pools into internal organizational departments (e.g. Sales, Finance, Warehouse)",
        "Strict BPMN syntax rule: Sequence flows MUST NOT cross pool boundaries; communication across pools uses Message Flows",
        "White-box internal executable processes vs black-box external participant pools"
      ]
    }],
    2: [{
      id: "ba-bpm-p2-events-exceptions",
      title: "Advanced BPMN Events: Timer Events, Error Events & Message Catch/Throw",
      youtube_video_id: "04AANAbeAvI",
      youtube_url: "https://www.youtube.com/watch?v=04AANAbeAvI",
      fallback_video_id: "ijdFO7PrBic",
      search_query: "Advanced BPMN Intermediate Events Boundary Events Timer Error Message Subprocess",
      channel_name: "YAWL User Group",
      duration: "29:50",
      difficulty: "Intermediate",
      topic_focus: "Catching vs Throwing Events, Boundary Interrupting Events, Timer SLA Expiry & Error Handlers",
      key_takeaways: [
        "Catching events (hollow icons, waiting for trigger) vs Throwing events (solid dark icons, emitting triggers)",
        "Boundary interrupting events attached to task borders: Immediately canceling task upon trigger (e.g. 48-hour timeout)",
        "Non-interrupting boundary events: Triggering parallel escalation notifications while allowing main task to proceed",
        "Error handling: Catching business exceptions (e.g. payment rejected) and routing to compensation sub-processes"
      ]
    }],
    3: [{
      id: "ba-bpm-p3-as-is-to-be",
      title: "Business Process Re-Engineering: As-Is vs To-Be Mapping & Bottleneck Elimination",
      youtube_video_id: "UBSdMqO4lBk",
      youtube_url: "https://www.youtube.com/watch?v=UBSdMqO4lBk",
      fallback_video_id: "fOyuu5hZRYE",
      search_query: "Business Process Reengineering As Is To Be Process Mapping Value Stream Lean Waste",
      channel_name: "DWIVEDI GUIDANCE",
      duration: "32:40",
      difficulty: "Advanced",
      topic_focus: "Current State (As-Is), Cycle Time Analysis, Eliminating Lean Wastes (Muda) & Future State (To-Be)",
      key_takeaways: [
        "Documenting the Current State (As-Is) process baseline through stakeholder observation and timestamps",
        "Identifying Lean process wastes (Muda): Waiting delays, manual paper handoffs, over-processing, duplicate approvals",
        "Calculating Process Cycle Efficiency (PCE = Value-Added Time / Total Lead Time)",
        "Designing the optimized Future State (To-Be) architecture incorporating automation and straight-through processing (STP)"
      ]
    }],
    4: [{
      id: "ba-bpm-p4-bpmn-interview",
      title: "Process Analyst / BPM Consultant Placement Interview & Live Modeling Viva",
      youtube_video_id: "tDn2P9YW1mU",
      youtube_url: "https://www.youtube.com/watch?v=tDn2P9YW1mU",
      fallback_video_id: "KebU2qtBPwM",
      search_query: "Process Analyst Interview Questions BPMN Modeling Case Study Automation Viva",
      channel_name: "Angelo the BA",
      duration: "30:25",
      difficulty: "Placement",
      topic_focus: "Live Process Modeling Case Study, Common BPMN Semantic Errors & Placement Viva",
      key_takeaways: [
        "Avoiding common BPMN modeling mistakes: Dead ends, dangling gateways, and invalid sequence flows across pools",
        "Evaluating Robotic Process Automation (RPA) feasibility for high-volume, rule-based manual tasks",
        "Leading process walkthroughs with senior business process owners to secure formal sign-off",
        "Clearing process consultant technical interviews at PwC, EY, KPMG, and Gartner"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 9. Statistical Testing & A/B Experimentation
  // --------------------------------------------------------------------------
  'ba-stats': {
    0: [{
      id: "ba-sta-p0-hypothesis-basics",
      title: "Statistical Testing Fundamentals: Null Hypothesis, p-Values & Significance (Alpha)",
      youtube_video_id: "vemZtEM63GY",
      youtube_url: "https://www.youtube.com/watch?v=vemZtEM63GY",
      fallback_video_id: "tdj-hoivzHQ",
      search_query: "StatQuest Hypothesis Testing p value Null Hypothesis Significance Level Alpha",
      channel_name: "StatQuest with Josh Starmer",
      duration: "24:10",
      difficulty: "Beginner",
      topic_focus: "Null Hypothesis (H0) vs Alternative (H1), Alpha (0.05), p-Value Interpretation & Normal Curve",
      key_takeaways: [
        "Formulating statistical hypotheses: Null hypothesis (H0: no effect / equal means) vs Alternative hypothesis (H1)",
        "Understanding the p-value: Probability of observing data at least as extreme assuming the null hypothesis is true",
        "Significance threshold alpha (typically 0.05): Rejecting the null hypothesis when p < alpha",
        "Differentiating Type I error (False Positive, alpha) from Type II error (False Negative, beta)"
      ]
    }],
    1: [{
      id: "ba-sta-p1-ttest-anova",
      title: "Parametric Tests: One-Sample, Two-Sample Student's t-Test & One-Way ANOVA",
      youtube_video_id: "Q_pO9NzWxPY",
      youtube_url: "https://www.youtube.com/watch?v=Q_pO9NzWxPY",
      fallback_video_id: "R7xd624pR1A",
      search_query: "Students t-Test Two Sample Independent Paired t-Test One Way ANOVA StatQuest",
      channel_name: "numiqo",
      duration: "28:30",
      difficulty: "Intermediate",
      topic_focus: "Independent Two-Sample t-Test, Paired t-Test, One-Way ANOVA (F-Statistic) & Tukey HSD",
      key_takeaways: [
        "Comparing two group means: Independent two-sample t-test (assessing variance equality with Levene's test)",
        "Paired t-test: Measuring within-subject changes before and after an experimental treatment",
        "One-Way ANOVA: Comparing means across 3 or more variants simultaneously using the F-ratio (Between / Within variance)",
        "Post-hoc multiple comparison corrections: Tukey's Honestly Significant Difference (HSD) to avoid family-wise error rate inflation"
      ]
    }],
    2: [{
      id: "ba-sta-p2-ab-sample-sizing",
      title: "A/B Testing Architecture: Minimum Detectable Effect (MDE), Power (1 - Beta) & Sample Size",
      youtube_video_id: "mEit1zwWhxE",
      youtube_url: "https://www.youtube.com/watch?v=mEit1zwWhxE",
      fallback_video_id: "KC1nwY7YCUE",
      search_query: "AB Testing Sample Size Calculation Minimum Detectable Effect MDE Statistical Power",
      channel_name: "VWO (Now Wingify)",
      duration: "29:15",
      difficulty: "Intermediate",
      topic_focus: "Statistical Power (80%), Minimum Detectable Effect (MDE), Sample Sizing Formulas & Test Duration",
      key_takeaways: [
        "Statistical Power (1 - beta): The probability of correctly rejecting a false null hypothesis (standard target 80%)",
        "Minimum Detectable Effect (MDE): Smallest uplift in conversion rate that the business cares to detect",
        "Calculating required sample size per variant: Evan Miller formula balancing alpha, power, and baseline conversion rate",
        "Determining test duration: Running tests for full business cycles (1-2 full weeks) to account for day-of-week seasonality"
      ]
    }],
    3: [{
      id: "ba-sta-p3-peeking-pitfalls",
      title: "A/B Testing Pitfalls: Peeking Problem, Multiple Testing & Non-Parametric Chi-Square",
      youtube_video_id: "vD9x3of3Gyo",
      youtube_url: "https://www.youtube.com/watch?v=vD9x3of3Gyo",
      fallback_video_id: "7_cs1YlZoug",
      search_query: "AB Testing Peeking Problem Sequential Testing Chi Square Test Contingency Table",
      channel_name: "5 Minutes Engineering",
      duration: "32:45",
      difficulty: "Advanced",
      topic_focus: "The Peeking Problem (Inflated False Positives), Chi-Square Test of Independence & Bonferroni Correction",
      key_takeaways: [
        "The Peeking Problem: Why checking p-values repeatedly and stopping early inflates Type I errors from 5% up to 30%+",
        "Continuous monitoring solutions: Sequential testing (mSPRT) and Bayesian experimentation approaches",
        "Chi-Square test of independence (chi^2): Testing categorical conversion counts across A/B test variations",
        "Mitigating multiple variant testing issues (A/B/C/n tests): Applying Bonferroni or False Discovery Rate (FDR) corrections"
      ]
    }],
    4: [{
      id: "ba-sta-p4-stats-interview",
      title: "Data Science / Analytics A/B Testing Placement Interview & Case Study Viva",
      youtube_video_id: "OMHbYrL09io",
      youtube_url: "https://www.youtube.com/watch?v=OMHbYrL09io",
      fallback_video_id: "Au9BB-JCbjs",
      search_query: "AB Testing Interview Questions Product Analyst Statistical Significance Twyman Law Viva",
      channel_name: "StrataScratch",
      duration: "31:20",
      difficulty: "Placement",
      topic_focus: "Novelty Effect, Network Cannibalization, Twyman's Law ('Too Good to be True') & Product Viva",
      key_takeaways: [
        "Diagnosing the Novelty Effect: Initial customer interest spike that degrades over subsequent weeks",
        "Network interference and spillover effects in two-sided marketplaces (Uber/Airbnb): Cluster-based randomization",
        "Applying Twyman's Law: Any figure that looks interesting or unusual is usually wrong (instrumentation tracking bug)",
        "Clearing A/B testing product analytics interviews at Meta, Netflix, Booking.com, and Spotify"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 10. Predictive Machine Learning Modeling
  // --------------------------------------------------------------------------
  'ba-predictive': {
    0: [{
      id: "ba-pml-p0-regression-classification",
      title: "Supervised Learning Fundamentals: Linear Regression, Logistic Regression & Cost Functions",
      youtube_video_id: "yIYKR4sgzI8",
      youtube_url: "https://www.youtube.com/watch?v=yIYKR4sgzI8",
      fallback_video_id: "sDv4f4s2SB8",
      search_query: "StatQuest Linear Regression Logistic Regression Cost Function Gradient Descent",
      channel_name: "StatQuest with Josh Starmer",
      duration: "25:30",
      difficulty: "Beginner",
      topic_focus: "Ordinary Least Squares (OLS), Sigmoid Activation, Log-Loss & Gradient Descent",
      key_takeaways: [
        "Linear regression for continuous numerical targets: Minimizing Residual Sum of Squares (RSS)",
        "Logistic regression for binary classification: Sigmoid function mapping linear combinations into probabilities (0 to 1)",
        "Evaluating cost functions: Mean Squared Error (MSE) vs Binary Cross-Entropy (Log-Loss)",
        "Gradient descent optimization: Updating weight coefficients iteratively based on learning rate alpha"
      ]
    }],
    1: [{
      id: "ba-pml-p1-trees-random-forest",
      title: "Decision Trees, Gini Impurity & Random Forest Ensembles in Scikit-Learn",
      youtube_video_id: "_L39rN6gz7Y",
      youtube_url: "https://www.youtube.com/watch?v=_L39rN6gz7Y",
      fallback_video_id: "_QuGM_FW9eo",
      search_query: "StatQuest Decision Trees Random Forest Gini Impurity Bagging Bootstrapping",
      channel_name: "StatQuest with Josh Starmer",
      duration: "28:45",
      difficulty: "Intermediate",
      topic_focus: "Recursive Binary Splitting, Gini Impurity vs Entropy, Bootstrap Aggregation (Bagging) & Out-of-Bag Error",
      key_takeaways: [
        "Decision tree splitting criteria: Maximizing information gain or minimizing Gini impurity",
        "Preventing decision tree overfitting: Controlling max_depth, min_samples_split, and cost-complexity pruning",
        "Random Forest: An ensemble of de-correlated decision trees trained on bootstrap samples with random feature subsets",
        "Out-of-Bag (OOB) error estimation and evaluating global feature importances (MDI)"
      ]
    }],
    2: [{
      id: "ba-pml-p2-churn-metrics",
      title: "Customer Churn Prediction & Model Evaluation: ROC-AUC, Precision, Recall & PR-Curves",
      youtube_video_id: "4jRBRDbJemM",
      youtube_url: "https://www.youtube.com/watch?v=4jRBRDbJemM",
      fallback_video_id: "vP06aMoz4v8",
      search_query: "ROC AUC Curve Precision Recall Tradeoff Imbalanced Data Customer Churn StatQuest",
      channel_name: "StatQuest with Josh Starmer",
      duration: "30:20",
      difficulty: "Intermediate",
      topic_focus: "Confusion Matrix (TP, FP, TN, FN), Precision vs Recall, ROC Curve & PR-AUC for Imbalanced Data",
      key_takeaways: [
        "The Confusion Matrix: True Positives, False Positives, True Negatives, False Negatives",
        "Why accuracy is deceptive on imbalanced datasets (e.g. 2% churn rate = 98% dummy accuracy)",
        "Receiver Operating Characteristic (ROC) curve: True Positive Rate vs False Positive Rate across classification thresholds",
        "Precision-Recall (PR) curves: The gold standard metric for highly imbalanced fraud and churn modeling"
      ]
    }],
    3: [{
      id: "ba-pml-p3-xgboost-tuning",
      title: "Gradient Boosting Mastery: XGBoost / LightGBM & Hyperparameter Tuning (Optuna)",
      youtube_video_id: "OtD8wVaFm6E",
      youtube_url: "https://www.youtube.com/watch?v=OtD8wVaFm6E",
      fallback_video_id: "D9xPjkOwpNk",
      search_query: "XGBoost Tutorial StatQuest Gradient Boosting LightGBM Hyperparameter Tuning Optuna",
      channel_name: "StatQuest with Josh Starmer",
      duration: "34:15",
      difficulty: "Advanced",
      topic_focus: "Sequential Pseudo-Residual Fitting, Shrinkage (Learning Rate), LightGBM Histograms & Optuna Bayesian Search",
      key_takeaways: [
        "Gradient Boosting principles: Training successive weak learner decision trees to predict the negative gradients of residuals",
        "XGBoost algorithmic enhancements: Second-order Taylor series expansion, L1/L2 tree regularization, and sparsity awareness",
        "LightGBM efficiency: Histogram-based splitting and Leaf-wise (best-first) tree growth for 10x faster training",
        "Bayesian hyperparameter optimization using Optuna: Tuning learning_rate, n_estimators, max_depth, and subsample"
      ]
    }],
    4: [{
      id: "ba-pml-p4-ml-interview",
      title: "Machine Learning / Data Science Placement Interview & Model Production Viva",
      youtube_video_id: "EuBBz3bI-aA",
      youtube_url: "https://www.youtube.com/watch?v=EuBBz3bI-aA",
      fallback_video_id: "dBvjBwga8pU",
      search_query: "Machine Learning Engineer Interview Questions Bias Variance Tradeoff Overfitting Viva",
      channel_name: "StatQuest with Josh Starmer",
      duration: "31:50",
      difficulty: "Placement",
      topic_focus: "Bias-Variance Trade-off, Data Drift & Concept Drift Monitoring, SHAP Interpretability & Viva",
      key_takeaways: [
        "Explaining the Bias-Variance Trade-off: Underfitting high bias vs overfitting high variance",
        "Model explainability: Computing SHAP (SHapley Additive exPlanations) values to explain individual predictions to executives",
        "Monitoring production models: Detecting Covariate Data Drift (KS-test) and Concept Drift after deployment",
        "Acing data science and machine learning engineer technical interviews at Google, Amazon, Stripe, and JPMorgan"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 11. Financial KPI Analysis & Unit Economics
  // --------------------------------------------------------------------------
  'ba-kpi': {
    0: [{
      id: "ba-kpi-p0-saas-metrics",
      title: "SaaS Financial Metrics: ARR, MRR, Churn Rate & Net Revenue Retention (NRR)",
      youtube_video_id: "XaOgak-YulM",
      youtube_url: "https://www.youtube.com/watch?v=XaOgak-YulM",
      fallback_video_id: "9ViZZ4MZTPs",
      search_query: "SaaS Financial Metrics ARR MRR Churn Rate Net Revenue Retention NRR LTV CAC",
      channel_name: "VCPete",
      duration: "24:40",
      difficulty: "Beginner",
      topic_focus: "Annual/Monthly Recurring Revenue (ARR/MRR), Logo Churn vs Dollar Churn, Expansion MRR & NRR",
      key_takeaways: [
        "Deconstructing Monthly Recurring Revenue (MRR): New MRR, Expansion MRR, Contraction MRR, and Churned MRR",
        "Differentiating customer logo churn (count percentage) from net revenue churn (dollar amount)",
        "Net Revenue Retention (NRR): Why NRR > 100% (ideal target 120-130%) proves customer expansion exceeds churn",
        "The Rule of 40: Revenue Growth Rate (%) + Free Cash Flow Margin (%) should equal or exceed 40%"
      ]
    }],
    1: [{
      id: "ba-kpi-p1-unit-economics",
      title: "Unit Economics: Customer Acquisition Cost (CAC), Lifetime Value (LTV) & Payback Period",
      youtube_video_id: "clfYlmidxX0",
      youtube_url: "https://www.youtube.com/watch?v=clfYlmidxX0",
      fallback_video_id: "kfnTjD8wpK4",
      search_query: "Unit Economics CAC LTV Ratio Customer Acquisition Cost Lifetime Value Payback Period",
      channel_name: "Eric Andrews Clips",
      duration: "27:15",
      difficulty: "Intermediate",
      topic_focus: "Blended vs Paid CAC, LTV Formula (ARPU * Gross Margin / Churn), LTV:CAC Ratio (3:1 Benchmark)",
      key_takeaways: [
        "Computing Fully Burdened CAC: Total sales and marketing expenditures divided by new customers acquired",
        "Calculating Customer Lifetime Value: LTV = (Average Revenue Per User * Gross Margin %) / Churn Rate",
        "The institutional LTV:CAC health ratio: 3:1 benchmark (less than 3 indicates inefficient marketing; greater than 5 indicates under-investing)",
        "CAC Payback Period: Number of months required to recover acquisition costs from gross margin cash flow (< 12 months target)"
      ]
    }],
    2: [{
      id: "ba-kpi-p2-cohort-retention",
      title: "Cohort Analysis & Customer Retention Heatmaps in Excel / Python",
      youtube_video_id: "GOLv8xbd6t0",
      youtube_url: "https://www.youtube.com/watch?v=GOLv8xbd6t0",
      fallback_video_id: "OwCATJh4lNg",
      search_query: "Cohort Analysis Customer Retention Triangular Heatmap Excel Python Churn",
      channel_name: "Kenji Explains",
      duration: "29:30",
      difficulty: "Intermediate",
      topic_focus: "Acquisition Cohorts, Triangular Retention Matrix, Month-over-Month Retention Curves & Asymptotes",
      key_takeaways: [
        "Grouping customers by acquisition vintage month to track behavioral longevity independently of company growth",
        "Constructing triangular cohort retention matrices showing percentage of retained users from Month 0 to Month 12+",
        "Identifying Product-Market Fit: Retention curves flattening horizontally into a stable asymptote (stable core audience)",
        "Differentiating behavioral product churn from pricing or payment failure involuntary churn"
      ]
    }],
    3: [{
      id: "ba-kpi-p3-ebitda-waterfall",
      title: "Corporate Financial Statements: Revenue to EBITDA Bridge & Cash Conversion Cycle",
      youtube_video_id: "lAUcqDp3A7M",
      youtube_url: "https://www.youtube.com/watch?v=lAUcqDp3A7M",
      fallback_video_id: "vG9AFwqKpFc",
      search_query: "Revenue to EBITDA Bridge Waterfall Chart Gross Margin Operating Margin Cash Conversion Cycle",
      channel_name: "YouExcel Tutorials",
      duration: "33:10",
      difficulty: "Advanced",
      topic_focus: "Gross Margin, Contribution Margin, EBITDA, Adjusted EBITDA, Waterfall Bridge & Free Cash Flow",
      key_takeaways: [
        "Tracing the operational P&L: Gross Profit -> Contribution Margin -> Operating Income (EBIT) -> EBITDA",
        "Designing executive EBITDA Bridge / Waterfall charts decomposing variance drivers (Volume, Price, Mix, Inflation)",
        "Cash Conversion Cycle (CCC): Days Sales Outstanding (DSO) + Days Inventory Outstanding (DIO) - Days Payable Outstanding (DPO)",
        "Free Cash Flow conversion: Unlevered Free Cash Flow = NOPAT + D&A - CapEx - Change in Net Working Capital"
      ]
    }],
    4: [{
      id: "ba-kpi-p4-kpi-interview",
      title: "Strategic Business Analyst / FP&A Placement Interview & Unit Economics Viva",
      youtube_video_id: "j87IfoL-GB8",
      youtube_url: "https://www.youtube.com/watch?v=j87IfoL-GB8",
      fallback_video_id: "npHOE0bsvJU",
      search_query: "FPA Business Analyst Interview Questions SaaS Metrics Unit Economics Case Study Viva",
      channel_name: "365 Financial Analyst",
      duration: "30:40",
      difficulty: "Placement",
      topic_focus: "Price Elasticity, Customer Churn Mitigation Strategies, Capital Allocation & Board Viva",
      key_takeaways: [
        "Diagnosing negative financial trends: Responding to sudden CAC inflation due to privacy changes or search bid competition",
        "Modeling price elasticity of demand and evaluating ARR revenue expansion vs churn risk from price increases",
        "Presenting multi-scenario financial forecasts and capital allocation recommendations to the Board of Directors",
        "Acing Corporate Strategy and FP&A technical interviews at Stripe, Uber, Salesforce, and Microsoft"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 12. Data Storytelling & Executive Presentations
  // --------------------------------------------------------------------------
  'ba-storytelling': {
    0: [{
      id: "ba-sty-p0-principles",
      title: "Storytelling with Data: Cole Nussbaumer Knaflic Principles & Decluttering",
      youtube_video_id: "X79o46W5plI",
      youtube_url: "https://www.youtube.com/watch?v=X79o46W5plI",
      fallback_video_id: "vy9JqtMkmsI",
      search_query: "Storytelling with Data Cole Nussbaumer Knaflic Decluttering Data Visualization",
      channel_name: "storytelling with data",
      duration: "23:50",
      difficulty: "Beginner",
      topic_focus: "Signal-to-Noise Ratio, Removing Chartjunk (Gridlines, 3D Effects), Preattentive Visual Attributes",
      key_takeaways: [
        "Core thesis of Storytelling with Data: Communicating insights clearly rather than merely displaying data",
        "Eliminating non-value-added 'chartjunk': Removing heavy gridlines, artificial 3D bevels, and redundant axis labels",
        "Leveraging preattentive visual attributes: Intentional use of color contrast, bold text, and size to guide eye flow in <250ms",
        "Choosing the right visual: Why pie charts fail and when to select horizontal bar charts vs slopegraphs"
      ]
    }],
    1: [{
      id: "ba-sty-p1-scqa-framework",
      title: "Executive Communication: The Minto Pyramid Principle & SCQA Narrative Framework",
      youtube_video_id: "j4Y3TdVVBCA",
      youtube_url: "https://www.youtube.com/watch?v=j4Y3TdVVBCA",
      fallback_video_id: "elMPIxLYtoc",
      search_query: "Minto Pyramid Principle SCQA Framework Executive Business Presentation McKinsey",
      channel_name: "EPM",
      duration: "26:30",
      difficulty: "Intermediate",
      topic_focus: "Barbara Minto Pyramid, Top-Down Communication, SCQA (Situation, Complication, Question, Answer)",
      key_takeaways: [
        "The McKinsey Minto Pyramid Principle: Stating the core conclusion/recommendation first before supporting evidence",
        "Structuring business narratives with SCQA: Situation (context), Complication (the burning problem), Question, Answer",
        "Mutually Exclusive, Collectively Exhaustive (MECE) problem structuring to eliminate logical overlaps and gaps",
        "Transforming descriptive passive chart titles into action-oriented insight headlines"
      ]
    }],
    2: [{
      id: "ba-sty-p2-color-hierarchy",
      title: "Color Theory & Typography in Analytics: Creating Cognitive Visual Hierarchy",
      youtube_video_id: "_13uWOyJV5w",
      youtube_url: "https://www.youtube.com/watch?v=_13uWOyJV5w",
      fallback_video_id: "v5brQ4WTlmQ",
      search_query: "Data Visualization Color Theory Gray Base Accent Color Visual Hierarchy Dashboards",
      channel_name: "Delivering Data Analytics",
      duration: "27:10",
      difficulty: "Intermediate",
      topic_focus: "Muted Gray Baseline Palette, Single Bold Accent Color, Font Pairings & Accessibility (Colorblind-Safe)",
      key_takeaways: [
        "The 80/20 gray rule: Using muted slate grays for baseline contextual data, reserving one vibrant accent color for the key insight",
        "Categorical vs Sequential vs Diverging color ramps and when each mathematical mapping is appropriate",
        "Designing accessible dashboards for color-vision deficiency (avoiding red-green combinations without shape cues)",
        "Consistent typography: Pairing legible sans-serif font weights (Inter, Roboto) to enforce hierarchical scanning"
      ]
    }],
    3: [{
      id: "ba-sty-p3-csuite-deck",
      title: "Authoring C-Suite Decision Decks: Slide Design, Data Annotations & Action Items",
      youtube_video_id: "oWBx_5pmnEE",
      youtube_url: "https://www.youtube.com/watch?v=oWBx_5pmnEE",
      fallback_video_id: "PB52Ct8Fdnw",
      search_query: "Consulting Slide Presentation Design McKinsey BCG Deck Structure Executive Summary",
      channel_name: "Hamdi | Presentation Design",
      duration: "32:15",
      difficulty: "Advanced",
      topic_focus: "Action Tracker Headlines, Direct Data Callout Annotations, One-Idea-Per-Slide & Decision Ask",
      key_takeaways: [
        "Crafting institutional consulting slide decks: Action tracker headlines summarizing the takeaway on every slide",
        "Direct visual annotations: Replacing separate legend boxes with direct in-chart text callouts at key deflection points",
        "The 5-second test: Ensuring any executive can grasp the primary message of a slide within five seconds",
        "Concluding with explicit actionable decisions: Required capital investment, expected ROI, risk mitigations, and timeline"
      ]
    }],
    4: [{
      id: "ba-sty-p4-executive-presentation",
      title: "Executive Storytelling, Defending Analytical Models & Strategy Interview Screening",
      youtube_video_id: "haRX9N5xVrA",
      youtube_url: "https://www.youtube.com/watch?v=haRX9N5xVrA",
      fallback_video_id: "KVZimVICjMo",
      search_query: "Business Analyst Case Interview Presentation BCG McKinsey Bain Screening",
      channel_name: "The Career Accelerators",
      duration: "45:30",
      difficulty: "Placement",
      topic_focus: "Handling Executive Interruptions, Defending Analytical Assumptions, Live Q&A & Placement Viva",
      key_takeaways: [
        "Navigating high-pressure C-level presentation interruptions: Pivoting immediately to the bottom line without losing composure",
        "Defending quantitative model assumptions and data limitations transparently during live executive interrogation",
        "Translating complex machine learning and statistical outputs into dollar-impact business terminology",
        "Clearing final-round partner interviews and senior stakeholder presentations at BCG, Bain, McKinsey, and Big 4"
      ]
    }]
  },

  // ==========================================================================
  // BCOM (COMMERCE & ACCOUNTING)
  // ==========================================================================

  // --------------------------------------------------------------------------
  // 13. Financial Accounting & Ind AS / IFRS
  // --------------------------------------------------------------------------
  'bcom-indas': {
    0: [{
      id: "bcom-ind-p0-principles",
      title: "Double-Entry Bookkeeping & Ind AS / IFRS Conceptual Framework",
      youtube_video_id: "VhwZ9t2b3Zk",
      youtube_url: "https://www.youtube.com/watch?v=VhwZ9t2b3Zk",
      fallback_video_id: "kFFaCkGKhs0",
      search_query: "Double Entry Bookkeeping Debit Credit Ind AS IFRS Conceptual Framework",
      channel_name: "Accounting Stuff",
      duration: "25:40",
      difficulty: "Beginner",
      topic_focus: "Golden Rules of Accounting, Accrual Concept, Ind AS Framework & Trial Balance",
      key_takeaways: [
        "The three Golden Rules of Accounting: Real accounts, Personal accounts, and Nominal accounts",
        "Accrual accounting principle vs cash basis: Matching revenues and expenses in the correct financial period",
        "Structure of the Ind AS / IFRS conceptual framework: Qualitative characteristics (relevance, faithful representation)",
        "Preparing the adjusted Trial Balance and identifying errors that do and do not affect trial balance agreement"
      ]
    }],
    1: [{
      id: "bcom-ind-p1-revenue-leases",
      title: "Ind AS 115 (Revenue from Contracts) & Ind AS 116 (Leases Accounting)",
      youtube_video_id: "jtPvV90SwqM",
      youtube_url: "https://www.youtube.com/watch?v=jtPvV90SwqM",
      fallback_video_id: "H-VWjtHnHw0",
      search_query: "Ind AS 115 Revenue from Contracts 5 Step Model Ind AS 116 Leases Right of Use",
      channel_name: "Atul Agarwal",
      duration: "29:10",
      difficulty: "Intermediate",
      topic_focus: "The 5-Step Revenue Recognition Model, Right-of-Use (ROU) Asset & Lease Liability",
      key_takeaways: [
        "The 5-Step Model under Ind AS 115: Identify contract, performance obligations, transaction price, allocation, recognition",
        "Differentiating point-in-time revenue recognition from over-time (input/output percentage of completion) recognition",
        "Ind AS 116 Leases revolution: Bringing operating leases onto the balance sheet as Right-of-Use (ROU) assets",
        "Calculating the present value of lease payments using the incremental borrowing rate and amortization schedules"
      ]
    }],
    2: [{
      id: "bcom-ind-p2-financial-instruments",
      title: "Ind AS 109 (Financial Instruments): Amortized Cost, FVTPL & FVTOCI",
      youtube_video_id: "LhX_9EB3Uew",
      youtube_url: "https://www.youtube.com/watch?v=LhX_9EB3Uew",
      fallback_video_id: "DiVPAjgmnj0",
      search_query: "Ind AS 109 Financial Instruments Classification Amortised Cost FVTPL FVTOCI",
      channel_name: "PW Skills - Finance",
      duration: "31:15",
      difficulty: "Intermediate",
      topic_focus: "Business Model Test, SPPI Test, Fair Value Through P&L (FVTPL) vs OCI & ECL Model",
      key_takeaways: [
        "Classification criteria for financial assets: Business Model test and Solely Payments of Principal and Interest (SPPI) test",
        "Amortized Cost vs Fair Value Through Other Comprehensive Income (FVTOCI) vs Fair Value Through P&L (FVTPL)",
        "The Expected Credit Loss (ECL) model: Replacing incurred loss with forward-looking 3-stage impairment staging",
        "Accounting for derivative instruments and hedge accounting effectiveness documentation"
      ]
    }],
    3: [{
      id: "bcom-ind-p3-consolidation",
      title: "Consolidated Financial Statements (Ind AS 110): Goodwill, NCI & Intercompany Eliminations",
      youtube_video_id: "3_Tal4ZVoR4",
      youtube_url: "https://www.youtube.com/watch?v=3_Tal4ZVoR4",
      fallback_video_id: "RArHWl11EnY",
      search_query: "Consolidated Financial Statements Ind AS 110 Goodwill Non Controlling Interest Intercompany",
      channel_name: "CA Aakash Kandoi",
      duration: "34:40",
      difficulty: "Advanced",
      topic_focus: "Acquisition Method, Purchase Price Allocation (PPA), Non-Controlling Interest (NCI) & Eliminations",
      key_takeaways: [
        "Assessing control under Ind AS 110: Power over investee, exposure to variable returns, and ability to use power",
        "Purchase Price Allocation (PPA): Fair valuing net identifiable assets and calculating residual Goodwill or Bargain Purchase",
        "Measuring Non-Controlling Interest (NCI): Proportionate share of net identifiable assets vs full fair value method",
        "Eliminating intra-group transactions: Unrealized intercompany profits in ending inventory and parent-subsidiary balances"
      ]
    }],
    4: [{
      id: "bcom-ind-p4-indas-interview",
      title: "Chartered Accountant (CA) / Corporate Accounting Placement Interview & Ind AS Viva",
      youtube_video_id: "pIDHUxvZHNA",
      youtube_url: "https://www.youtube.com/watch?v=pIDHUxvZHNA",
      fallback_video_id: "Xn0gxkK_qD0",
      search_query: "CA Technical Interview Questions Financial Accounting Ind AS Schedule III Viva",
      channel_name: "CareerVidz",
      duration: "30:25",
      difficulty: "Placement",
      topic_focus: "Schedule III Division II Disclosures, Deferred Tax (Ind AS 12), Cash Flow Statements & Viva",
      key_takeaways: [
        "Preparing balance sheets and profit & loss statements compliant with Schedule III Division II (Ind AS) of Companies Act 2013",
        "Computing Deferred Tax Assets (DTA) and Deferred Tax Liabilities (DTL) using balance sheet temporary difference approach (Ind AS 12)",
        "Direct vs indirect methods for Statement of Cash Flows (Ind AS 7) and non-cash financing disclosures",
        "Clearing accounting and audit technical rounds at Big 4 accounting firms (Deloitte, PwC, EY, KPMG)"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 14. Taxation & GST Return Filing (GSTR 1/3B/9)
  // --------------------------------------------------------------------------
  'bcom-gst': {
    0: [{
      id: "bcom-gst-p0-basics",
      title: "GST in India for Beginners: CGST, SGST, IGST & Supply Fundamentals",
      youtube_video_id: "tWmgVw75oT0",
      youtube_url: "https://www.youtube.com/watch?v=tWmgVw75oT0",
      fallback_video_id: "hqujnXWYI98",
      search_query: "GST Full Course for Beginners CGST SGST IGST Section 7 Supply Scope",
      channel_name: "DWIVEDI GUIDANCE",
      duration: "25:10",
      difficulty: "Beginner",
      topic_focus: "Dual GST Model, Intra-State vs Inter-State, Section 7 Definition of Supply & Tax Invoices",
      key_takeaways: [
        "Constitutional framework of Indian GST: The dual structure (CGST + SGST for intra-state, IGST for inter-state)",
        "Section 7 of CGST Act: Definition and scope of 'Supply' (goods, services, consideration, course of business)",
        "Differentiating taxable supply, exempt supply, nil-rated supply, and non-GST goods (petroleum, alcohol)",
        "Mandatory contents of a valid GST Tax Invoice: HSN/SAC codes, place of supply, supplier/buyer GSTIN"
      ]
    }],
    1: [{
      id: "bcom-gst-p1-itc-rules",
      title: "Input Tax Credit (ITC) Rules (Section 16-17) & GSTR-2B Matching Reconciliation",
      youtube_video_id: "NeST32Hbu-M",
      youtube_url: "https://www.youtube.com/watch?v=NeST32Hbu-M",
      fallback_video_id: "OlyLjLbCGpI",
      search_query: "Input Tax Credit ITC Rules Section 16 17 Blocked Credit GSTR 2B Reconciliation",
      channel_name: "MyOnlineCA",
      duration: "28:30",
      difficulty: "Intermediate",
      topic_focus: "Conditions for Availing ITC (Section 16), Blocked Credits (Section 17(5)) & Rule 37 180-Day Rule",
      key_takeaways: [
        "The 4 statutory conditions to claim ITC under Section 16: Possession of tax invoice, receipt of goods, supplier tax paid, return filed",
        "Blocked credits under Section 17(5): Motor vehicles, food and beverages, club memberships, personal consumption",
        "Rule 37 180-day payment rule: Mandatory reversal of ITC with interest if supplier is not paid within 180 days",
        "Automated monthly reconciliation of purchase register books against static auto-drafted GSTR-2B"
      ]
    }],
    2: [{
      id: "bcom-gst-p2-gstr1-3b-filing",
      title: "Live Portal Filing: GSTR-1 (Outward Supplies) & GSTR-3B (Monthly Summary Return)",
      youtube_video_id: "3n8hAyjMJ8E",
      youtube_url: "https://www.youtube.com/watch?v=3n8hAyjMJ8E",
      fallback_video_id: "5wKLx_xiz5o",
      search_query: "GSTR 1 Filing Live Demo GST Portal GSTR 3B Return Filing Tax Payment Offline Tool",
      channel_name: "Accounts Advice",
      duration: "29:40",
      difficulty: "Intermediate",
      topic_focus: "Table 4 B2B Invoices, B2CL vs B2CS, Tax Liability Ledger, Cash Ledger & Electronic Credit Ledger",
      key_takeaways: [
        "Filing GSTR-1 on the GST portal: Table 4 (B2B registered sales), Table 5/7 (B2C large and small sales), Table 12 (HSN summary)",
        "Generating GSTR-3B monthly return: Auto-population of outward liabilities from GSTR-1 and eligible ITC from GSTR-2B",
        "Reverse Charge Mechanism (RCM): Section 9(3) and 9(4) liabilities requiring cash payment without utilizing credit ledger",
        "Utilizing the electronic cash ledger and electronic credit ledger cross-utilization rules (IGST -> CGST -> SGST)"
      ]
    }],
    3: [{
      id: "bcom-gst-p3-annual-return-gstr9",
      title: "Annual Return Filing (GSTR-9) & Reconciliation Statement (GSTR-9C)",
      youtube_video_id: "ry7zvfryp6M",
      youtube_url: "https://www.youtube.com/watch?v=ry7zvfryp6M",
      fallback_video_id: "EsTm9BaALJA",
      search_query: "GSTR 9 Annual Return Filing GSTR 9C Reconciliation Statement Table 6 Table 8 CA Certification",
      channel_name: "CA Guru Ji",
      duration: "33:15",
      difficulty: "Advanced",
      topic_focus: "GSTR-9 Table 6 (ITC Breakdown), Table 8 (GSTR-2A vs 3B), GSTR-9C Audited Financials Reconciliation",
      key_takeaways: [
        "Preparing annual return GSTR-9: Reporting cumulative financial year turnover, taxes paid, and ITC adjustments",
        "Analyzing Table 8 reconciliation: Explaining differences between ITC available as per GSTR-2A/2B and ITC availed in GSTR-3B",
        "Filing self-certified reconciliation statement GSTR-9C: Reconciling audited financial statements with GST annual returns",
        "Identifying and paying differential tax liabilities along with applicable interest via Form DRC-03"
      ]
    }],
    4: [{
      id: "bcom-gst-p4-gst-interview",
      title: "GST Practitioner / Corporate Tax Executive Placement Interview Screening Viva",
      youtube_video_id: "txgHoRp7wPY",
      youtube_url: "https://www.youtube.com/watch?v=txgHoRp7wPY",
      fallback_video_id: "-Ma5t13OX_4",
      search_query: "GST Practitioner Interview Questions Corporate Tax Executive E-Invoicing E-Way Bill Viva",
      channel_name: "Accounts Advice",
      duration: "30:50",
      difficulty: "Placement",
      topic_focus: "E-Invoicing (IRN & QR Code), E-Way Bill Generation & Rules, GST Department Audits (ASMT-10) & Viva",
      key_takeaways: [
        "Mandatory E-Invoicing rules: Generating Invoice Reference Number (IRN) and signed QR code through IRP portal",
        "E-Way Bill generation rules under Rule 138: Consignments exceeding Rs. 50,000, Part A and Part B conveyance details",
        "Responding to GST department scrutiny notices (Form ASMT-10) for discrepancies between GSTR-1 and GSTR-3B",
        "Acing corporate indirect tax executive interviews at Big 4 tax advisory practices and large FMCG conglomerates"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 15. Statutory Auditing & Internal Assurance
  // --------------------------------------------------------------------------
  'bcom-audit': {
    0: [{
      id: "bcom-aud-p0-standards",
      title: "Statutory Auditing Principles: Standards on Auditing (SA 200/315/500) & Professional Skepticism",
      youtube_video_id: "Hd8ua303jeA",
      youtube_url: "https://www.youtube.com/watch?v=Hd8ua303jeA",
      fallback_video_id: "uDOUXFyd3EU",
      search_query: "Standards on Auditing SA 200 Overall Objectives Professional Skepticism SA 315 Risk Assessment",
      channel_name: "DWIVEDI GUIDANCE",
      duration: "25:30",
      difficulty: "Beginner",
      topic_focus: "SA 200 Overall Objectives, Reasonable Assurance, Inherent Limitations of Audit & Professional Skepticism",
      key_takeaways: [
        "The overall objectives of the independent auditor under SA 200: Obtaining reasonable assurance that financials are free from material misstatement",
        "Maintaining professional skepticism: Questioning contradictory evidence and alert mindset toward fraud indicators",
        "Understanding inherent limitations of an audit: Nature of financial reporting, management judgment, and use of sampling",
        "Audit Risk model: Audit Risk = Inherent Risk (IR) * Control Risk (CR) * Detection Risk (DR)"
      ]
    }],
    1: [{
      id: "bcom-aud-p1-vouching-verification",
      title: "Substantive Audit Procedures: Vouching of Transactions & Physical Verification of Assets",
      youtube_video_id: "21xFRSgnvV4",
      youtube_url: "https://www.youtube.com/watch?v=21xFRSgnvV4",
      fallback_video_id: "2Cf-KgSvxQk",
      search_query: "Substantive Audit Procedures Vouching Verification Management Assertions Completeness Existence",
      channel_name: "Learn with Himanshu Nandwani",
      duration: "28:40",
      difficulty: "Intermediate",
      topic_focus: "Management Assertions (Existence, Completeness, Valuation, Rights & Obligations), Vouching Sales/Expenses",
      key_takeaways: [
        "Testing management assertions for balance sheet items: Existence, Rights & Obligations, Completeness, Valuation",
        "Testing assertions for P&L transactions: Occurrence, Completeness, Accuracy, Cut-off, and Classification",
        "Vouching purchase and revenue transactions: Three-way matching (Purchase Order, Goods Receipt Note, Vendor Tax Invoice)",
        "Witnessing and performing physical inventory count verification at client warehouses at year-end"
      ]
    }],
    2: [{
      id: "bcom-aud-p2-internal-controls",
      title: "Internal Financial Controls (IFC) & Test of Controls (TOC) under SOX / Companies Act",
      youtube_video_id: "URtX2Q12zYs",
      youtube_url: "https://www.youtube.com/watch?v=URtX2Q12zYs",
      fallback_video_id: "l5_n4yi9dMU",
      search_query: "Internal Financial Controls IFC Test of Controls Walkthrough SOX 404 Deficiencies",
      channel_name: "Mayank Katariya",
      duration: "29:50",
      difficulty: "Intermediate",
      topic_focus: "COSO Internal Control Framework, Process Walkthroughs, Design vs Operating Effectiveness & Deficiencies",
      key_takeaways: [
        "The 5 components of the COSO internal control framework: Control Environment, Risk Assessment, Control Activities, Info, Monitoring",
        "Conducting process walkthroughs from initiation to recording in the general ledger (Order-to-Cash, Procure-to-Pay)",
        "Testing design effectiveness vs operating effectiveness of automated application controls and manual review controls",
        "Evaluating control deficiencies: Significant deficiencies vs Material Weaknesses requiring board audit committee reporting"
      ]
    }],
    3: [{
      id: "bcom-aud-p3-caro-reporting",
      title: "Companies (Auditor's Report) Order (CARO 2020) & Audit Report Drafting (SA 700/705)",
      youtube_video_id: "1gvtDuF18Vg",
      youtube_url: "https://www.youtube.com/watch?v=1gvtDuF18Vg",
      fallback_video_id: "hCt_JvjOsmY",
      search_query: "CARO 2020 Clauses Audit Report SA 700 SA 705 Modified Opinion Qualified Adverse Disclaimer",
      channel_name: "TheForensicAccountant",
      duration: "33:20",
      difficulty: "Advanced",
      topic_focus: "CARO 2020 21 Clauses (Inventory, PP&E, Loans, Benami, Fraud Reporting), SA 705 Modifications",
      key_takeaways: [
        "Navigating the 21 comprehensive reporting clauses of CARO 2020: Physical verification of PP&E, Benami properties, working capital limits",
        "Reporting statutory whistle-blower complaints, corporate fraud reporting (Section 143(12) Form ADT-4 to Central Government)",
        "Types of audit opinions under SA 700 and SA 705: Unmodified (Clean), Qualified opinion, Adverse opinion, Disclaimer of opinion",
        "Key Audit Matters (KAM under SA 701): Communicating high-risk areas requiring significant auditor attention to shareholders"
      ]
    }],
    4: [{
      id: "bcom-aud-p4-audit-interview",
      title: "Statutory & Internal Audit Placement Interview: Big 4 Case Scenarios & Ethics Viva",
      youtube_video_id: "CCVdwuI0v0c",
      youtube_url: "https://www.youtube.com/watch?v=CCVdwuI0v0c",
      fallback_video_id: "tSFh76EQ8N4",
      search_query: "Big 4 Audit Interview Questions Going Concern SA 570 Materiality SA 320 Viva",
      channel_name: "CA Shivam Palan_CA Monk",
      duration: "31:30",
      difficulty: "Placement",
      topic_focus: "Materiality Determination (SA 320), Going Concern Evaluation (SA 570), Independence & Viva",
      key_takeaways: [
        "Determining benchmark audit materiality: Overall Materiality, Performance Materiality, and de minimis threshold",
        "Evaluating Going Concern basis of accounting (SA 570): Assessing management's cash flow forecast over next 12 months",
        "Auditor independence rules: Prohibited non-audit services under Section 144 of Companies Act 2013",
        "Cracking statutory and internal audit partner interview rounds at Deloitte, PwC, EY, KPMG, and BDO"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 16. TallyPrime & SAP ERP Financials
  // --------------------------------------------------------------------------
  'bcom-tally': {
    0: [{
      id: "bcom-tly-p0-tally-basics",
      title: "TallyPrime for Beginners: Company Creation, Chart of Accounts & Master Ledgers",
      youtube_video_id: "v02NSo-Bd4E",
      youtube_url: "https://www.youtube.com/watch?v=v02NSo-Bd4E",
      fallback_video_id: "TMxYh9mGVos",
      search_query: "TallyPrime Full Course for Beginners Company Creation Ledger Groups Voucher",
      channel_name: "Upciss Prime",
      duration: "26:10",
      difficulty: "Beginner",
      topic_focus: "Company Setup, Primary & Secondary Groups, Creating Sundry Debtors/Creditors & Bank Accounts",
      key_takeaways: [
        "Creating and configuring a business company entity in TallyPrime: Financial year beginning, base currency symbols",
        "The Chart of Accounts architecture: Pre-defined 28 accounting groups (15 Primary, 13 Secondary)",
        "Creating customer (Sundry Debtors) and vendor (Sundry Creditors) ledgers with bill-wise details",
        "Enabling statutory features: Goods and Services Tax (GST), Tax Deducted at Source (TDS), and e-Invoicing"
      ]
    }],
    1: [{
      id: "bcom-tly-p1-vouchers-inventory",
      title: "Voucher Entry in TallyPrime: Payment, Receipt, Journal, Contra & Sales/Purchase Invoicing",
      youtube_video_id: "MbFqs5xAafE",
      youtube_url: "https://www.youtube.com/watch?v=MbFqs5xAafE",
      fallback_video_id: "UaacbStR2Yo",
      search_query: "TallyPrime Voucher Entry Payment Receipt Journal Contra Sales Purchase GST Invoice",
      channel_name: "Computer Tech Academy",
      duration: "28:50",
      difficulty: "Intermediate",
      topic_focus: "Voucher Types (F4 Contra, F5 Payment, F6 Receipt, F7 Journal, F8 Sales, F9 Purchase), Inventory Items",
      key_takeaways: [
        "Mastering core voucher types: Contra (cash-bank fund transfers), Payment, Receipt, and non-cash Journal entries",
        "Item-invoice mode for sales and purchases: Integrating stock items, unit of measure (UoM), and HSN tax rates",
        "Multi-currency transactions and recording foreign exchange gain/loss adjustments",
        "Generating professional, tax-compliant GST e-invoices with QR codes directly from TallyPrime"
      ]
    }],
    2: [{
      id: "bcom-tly-p2-brs-costcenters",
      title: "Bank Reconciliation Statement (BRS) & Cost Center Accounting in TallyPrime",
      youtube_video_id: "W8xQCgLLeQ0",
      youtube_url: "https://www.youtube.com/watch?v=W8xQCgLLeQ0",
      fallback_video_id: "gHGjjFd33oI",
      search_query: "TallyPrime Auto Bank Reconciliation BRS Cost Center Cost Category Allocation",
      channel_name: "TALLY SPARKLY",
      duration: "27:40",
      difficulty: "Intermediate",
      topic_focus: "Auto BRS (Importing Bank Statement CSV/Excel), Cheques Issued but Not Presented, Cost Categories",
      key_takeaways: [
        "Performing Bank Reconciliation: Identifying timing differences between company ledger and bank passbook",
        "Automated BRS in TallyPrime: Importing electronic bank statements to reconcile cleared dates automatically",
        "Configuring Cost Categories and Cost Centers for divisional departmental profitability tracking",
        "Allocating revenue and expense voucher amounts across multiple cost centers during data entry"
      ]
    }],
    3: [{
      id: "bcom-tly-p3-sap-fico-basics",
      title: "SAP S/4HANA FICO Overview: Enterprise Structure, General Ledger (G/L) & AP/AR",
      youtube_video_id: "ZXBMyFGDc40",
      youtube_url: "https://www.youtube.com/watch?v=ZXBMyFGDc40",
      fallback_video_id: "Q9Aq0DaRKSY",
      search_query: "SAP FICO S4HANA Tutorial for Beginners Enterprise Structure Company Code GL AP AR",
      channel_name: "GS EasyTech Computer Education",
      duration: "33:40",
      difficulty: "Advanced",
      topic_focus: "Company Code, Chart of Accounts, Universal Journal (ACDOCA), Accounts Payable (AP) & T-Codes",
      key_takeaways: [
        "Enterprise organizational structure in SAP: Client, Operating Concern, Controlling Area, and Company Code",
        "S/4HANA Universal Journal table (ACDOCA): Combining Financial Accounting (FI) and Controlling (CO) into a single source of truth",
        "Posting standard transactions using SAP Transaction Codes (T-Codes: FB50 for G/L, FB60 for vendor invoice, F-28 for payment)",
        "Accounts Payable (FI-AP) and Accounts Receivable (FI-AR) sub-ledger integration with the general ledger"
      ]
    }],
    4: [{
      id: "bcom-tly-p4-erp-interview",
      title: "ERP Accountant / SAP FICO Associate Placement Interview Screening Viva",
      youtube_video_id: "PhP8wN22FBE",
      youtube_url: "https://www.youtube.com/watch?v=PhP8wN22FBE",
      fallback_video_id: "dHVc_3aahkQ",
      search_query: "SAP FICO Consultant Interview Questions TallyPrime Accountant Month End Close Viva",
      channel_name: "Tally with Rahul Chaudhary",
      duration: "30:15",
      difficulty: "Placement",
      topic_focus: "Month-End Close Checklist, Foreign Currency Revaluation, Depreciation Run & ERP Viva",
      key_takeaways: [
        "Executing the structured month-end financial closing schedule: Accruals, prepayments, and foreign currency revaluation",
        "Running automated fixed asset depreciation runs (T-Code AFAB) in SAP Asset Accounting",
        "Extracting and analyzing trial balance, aging reports, and P&L financial statement versions",
        "Acing accounting software proficiency exams and ERP consultant interviews at Genpact, Wipro, and Accenture"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 17. 3-Statement Financial Modeling in Excel
  // --------------------------------------------------------------------------
  'bcom-modeling': {
    0: [{
      id: "bcom-mod-p0-architecture",
      title: "Financial Modeling Architecture: Formatting Standards, Assumptions & Revenue Builds",
      youtube_video_id: "YZMmIHb8jbA",
      youtube_url: "https://www.youtube.com/watch?v=YZMmIHb8jbA",
      fallback_video_id: "RnKdNEmzs8I",
      search_query: "Financial Modeling Standards Assumptions Formatting Wall Street Prep Revenue Build",
      channel_name: "Advanced Excel with Arun",
      duration: "26:30",
      difficulty: "Beginner",
      topic_focus: "Color Coding (Blue Hardcodes, Black Formulas), Revenue Segmentation (Price x Volume) & Gross Margins",
      key_takeaways: [
        "Adhering to FAST financial modeling standards: Flexible, Appropriate, Structured, and Transparent",
        "Color-coding discipline: Blue for hardcoded historical assumptions, Black for calculations, Green for cross-sheet links",
        "Bottom-up revenue forecasting builds: Volume (units sold / active users) multiplied by Average Selling Price (ASP)",
        "Modeling direct cost of goods sold (COGS) and fixed vs variable operating expenditure lines"
      ]
    }],
    1: [{
      id: "bcom-mod-p1-working-capital-schedules",
      title: "Supporting Schedules: Working Capital, PP&E Depreciation Waterfall & CapEx",
      youtube_video_id: "UMYDxmiVin4",
      youtube_url: "https://www.youtube.com/watch?v=UMYDxmiVin4",
      fallback_video_id: "f3T0tCjw1k8",
      search_query: "Working Capital Schedule PP&E Depreciation Waterfall Schedule Financial Model",
      channel_name: "Corporate Finance Institute",
      duration: "29:10",
      difficulty: "Intermediate",
      topic_focus: "Days Sales Outstanding (DSO), Inventory Days, Straight-Line Depreciation Roll-Forward & CapEx",
      key_takeaways: [
        "Working capital schedules: Forecasting Accounts Receivable using DSO = (AR / Revenue) * 365",
        "Forecasting inventory using Days Inventory Outstanding (DIO) and accounts payable using DPO",
        "Property, Plant & Equipment (PP&E) roll-forward schedule: Beginning PP&E + CapEx - Depreciation = Ending PP&E",
        "Straight-line vs accelerated tax depreciation waterfalls for existing and newly acquired capital assets"
      ]
    }],
    2: [{
      id: "bcom-mod-p2-debt-schedule-circularity",
      title: "Debt Schedules, Revolver Financing & Handling Circular Reference Interest",
      youtube_video_id: "GbRaypRUXXM",
      youtube_url: "https://www.youtube.com/watch?v=GbRaypRUXXM",
      fallback_video_id: "tX5Ev_HkXa8",
      search_query: "Debt Schedule Revolver Cash Sweep Circular Reference Average Debt Interest Expense",
      channel_name: "Victor Ogundele",
      duration: "31:45",
      difficulty: "Intermediate",
      topic_focus: "Senior Debt Tranches, Revolver Cash Sweep, Interest on Average Debt Balance & Circularity Breaker",
      key_takeaways: [
        "Modeling multi-tranche debt capital structures: Senior term loans, subordinated notes, and revolving credit facilities",
        "Calculating interest expense on average debt balance: Interest = Average(Beginning Debt, Ending Debt) * Interest Rate",
        "Understanding circular references: Interest expense affects Net Income, which affects Cash, which affects Debt Paydown, which affects Interest",
        "Implementing a manual circularity breaker toggle (IF circularity_breaker = 1) to eliminate Excel crash loops"
      ]
    }],
    3: [{
      id: "bcom-mod-p3-balance-sheet-integration",
      title: "Integrating the 3 Statements: Balance Sheet Balancing & Cash Flow Statement Linkage",
      youtube_video_id: "CfkFFk-r9aA",
      youtube_url: "https://www.youtube.com/watch?v=CfkFFk-r9aA",
      fallback_video_id: "yIJjUzyNGqg",
      search_query: "Linking 3 Financial Statements Balance Sheet Balancing Check Cash Flow Statement Model",
      channel_name: "Corporate Finance Institute",
      duration: "35:20",
      difficulty: "Advanced",
      topic_focus: "Cash from Operations (CFO), Cash from Investing (CFI), Cash from Financing (CFF) & Balance Check = 0",
      key_takeaways: [
        "Building the Cash Flow Statement from operational balance sheet changes: Net Income + D&A - Change in NWC",
        "Cash from Investing: Cash outflows for capital expenditures (CapEx) and asset acquisitions",
        "Cash from Financing: Debt issuances, principal repayments, dividend payments, and equity repurchases",
        "Rigorous verification: Total Assets must strictly equal Total Liabilities plus Shareholders' Equity (Balance check = 0)"
      ]
    }],
    4: [{
      id: "bcom-mod-p4-modeling-interview",
      title: "Investment Banking / Equity Research Financial Modeling Placement Exam & Viva",
      youtube_video_id: "ETs4mRAOF70",
      youtube_url: "https://www.youtube.com/watch?v=ETs4mRAOF70",
      fallback_video_id: "wSjk7j9rN_M",
      search_query: "Investment Banking Modeling Test Walk Me Through 3 Statements Interview Questions Viva",
      channel_name: "City Investment Training",
      duration: "32:30",
      difficulty: "Placement",
      topic_focus: "'Walk Me Through the 3 Statements', Depreciation Impact Case Study ($10 Depreciation) & IB Viva",
      key_takeaways: [
        "The classic interview question: 'Walk me through how $10 of depreciation affects the three statements'",
        "Income statement: Operating income drops $10, at 20% tax rate net income drops $8; Cash flow: Net income down $8, add back $10 D&A, cash up $2",
        "Balance sheet: Cash is up $2, PP&E down $10 (Assets down $8); Retained earnings down $8 (Liabilities/Equity down $8, balances!)",
        "Passing timed 2-hour modeling assessments at JPMorgan, Goldman Sachs, Jefferies, and Lazard"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 18. Corporate Finance & Valuation (DCF / WACC)
  // --------------------------------------------------------------------------
  'bcom-corpfin': {
    0: [{
      id: "bcom-fin-p0-time-value",
      title: "Time Value of Money (TVM) & Capital Budgeting: NPV, IRR & Payback Period",
      youtube_video_id: "pUqPuAXb4uA",
      youtube_url: "https://www.youtube.com/watch?v=pUqPuAXb4uA",
      fallback_video_id: "nO7_xTNXay4",
      search_query: "Time Value of Money Net Present Value NPV Internal Rate of Return IRR Capital Budgeting",
      channel_name: "DWIVEDI GUIDANCE",
      duration: "25:15",
      difficulty: "Beginner",
      topic_focus: "Discount Factors (1 / (1+r)^t), Net Present Value (NPV), Internal Rate of Return (IRR) & Hurdle Rates",
      key_takeaways: [
        "Time Value of Money: Why a dollar today is worth more than a dollar tomorrow (purchasing power, opportunity cost, risk)",
        "Net Present Value (NPV): Sum of discounted future cash inflows minus initial capital investment",
        "Internal Rate of Return (IRR): The discount rate at which project NPV equals zero; comparing against company hurdle rate",
        "NPV vs IRR conflicts in mutually exclusive projects: Why NPV is the theoretically superior decision rule"
      ]
    }],
    1: [{
      id: "bcom-fin-p1-wacc-capm",
      title: "Cost of Capital: Weighted Average Cost of Capital (WACC) & The CAPM Model",
      youtube_video_id: "QXoFB4-MV_I",
      youtube_url: "https://www.youtube.com/watch?v=QXoFB4-MV_I",
      fallback_video_id: "1nU8gRTHU4o",
      search_query: "Weighted Average Cost of Capital WACC Cost of Equity CAPM Beta Tax Shield",
      channel_name: "CA. Naresh Aggarwal",
      duration: "29:30",
      difficulty: "Intermediate",
      topic_focus: "Cost of Equity (Ke via CAPM), After-Tax Cost of Debt (Kd * (1 - t)), Equity/Debt Capital Weights",
      key_takeaways: [
        "The WACC formula: WACC = (E/V * Ke) + (D/V * Kd * (1 - Tax Rate))",
        "Capital Asset Pricing Model (CAPM): Cost of Equity Ke = Risk-Free Rate (Rf) + Beta * Equity Risk Premium (ERP)",
        "Understanding Beta: Measuring systematic market risk; unlevering peer betas and relevering for target capital structure",
        "The corporate tax shield on debt interest: Why debt capital is cheaper than equity capital up to financial distress limits"
      ]
    }],
    2: [{
      id: "bcom-fin-p2-dcf-valuation",
      title: "Discounted Cash Flow (DCF) Valuation: Unlevered Free Cash Flows & Terminal Value",
      youtube_video_id: "ljW8OWzoUww",
      youtube_url: "https://www.youtube.com/watch?v=ljW8OWzoUww",
      fallback_video_id: "3AVZWOZxixc",
      search_query: "Discounted Cash Flow DCF Valuation Unlevered Free Cash Flow Gordon Growth Exit Multiple",
      channel_name: "DWIVEDI GUIDANCE",
      duration: "32:40",
      difficulty: "Advanced",
      topic_focus: "Free Cash Flow to Firm (FCFF = EBIT*(1-t) + D&A - CapEx - Delta NWC), Terminal Value, Enterprise Value",
      key_takeaways: [
        "Deriving Unlevered Free Cash Flow (FCFF): Operating cash generated available to all capital providers independent of debt",
        "Discounting 5-year discrete forecast cash flows to present value using WACC",
        "Calculating Terminal Value (TV): Gordon Growth Model (Perpetuity growth g < GDP) vs Exit Multiple Method (EV/EBITDA)",
        "Bridging Enterprise Value to Equity Value: Enterprise Value - Net Debt (Total Debt - Cash) - NCI = Equity Value; share price derivation"
      ]
    }],
    3: [{
      id: "bcom-fin-p3-comparable-multiples",
      title: "Relative Valuation: Trading Comps (EV/EBITDA, P/E) & Precedent Transactions",
      youtube_video_id: "mE7_w0kjdt0",
      youtube_url: "https://www.youtube.com/watch?v=mE7_w0kjdt0",
      fallback_video_id: "azRiPvprU8s",
      search_query: "Comparable Company Analysis Trading Comps Precedent Transactions EV EBITDA PE Ratio",
      channel_name: "Corporate Finance Institute",
      duration: "31:10",
      difficulty: "Advanced",
      topic_focus: "Enterprise Value Multiples (EV/Revenue, EV/EBITDA) vs Equity Multiples (P/E), Peer Group Benchmarking",
      key_takeaways: [
        "Selecting peer company universe: Matching industry sector, business model, geographic geography, and size",
        "Enterprise Value multiples (EV/EBITDA): Capital-structure neutral metric suitable for comparing companies with differing debt levels",
        "Equity multiples (P/E ratio, Price-to-Book): Reflecting post-interest equity shareholder returns",
        "Precedent Transaction Analysis: Why historical M&A deal multiples incorporate a 20-30% control acquisition premium"
      ]
    }],
    4: [{
      id: "bcom-fin-p4-valuation-interview",
      title: "Corporate Finance / Investment Banking Valuation Placement Interview Viva",
      youtube_video_id: "6SI2vtm8HuQ",
      youtube_url: "https://www.youtube.com/watch?v=6SI2vtm8HuQ",
      fallback_video_id: "hQWxKGEcokw",
      search_query: "Investment Banking Valuation Technical Interview Questions DCF Comps Football Field Chart Viva",
      channel_name: "Knowledge Topper",
      duration: "30:50",
      difficulty: "Placement",
      topic_focus: "Football Field Valuation Summary, DCF Sensitivity Tables, Terminal Value Sensitivities & IB Viva",
      key_takeaways: [
        "Constructing the Football Field valuation summary chart: Comparing valuation ranges across DCF, Trading Comps, and Precedents",
        "Conducting two-way sensitivity tables on WACC vs Long-term Terminal Growth Rate (g)",
        "Responding to valuation edge cases: Negative EBITDA companies (EV/ARR multiples) and financial institutions (Dividend Discount Model)",
        "Clearing valuation technical rounds at Goldman Sachs, Morgan Stanley, Moelis, and Lazard"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 19. Cost & Management Accounting
  // --------------------------------------------------------------------------
  'bcom-costing': {
    0: [{
      id: "bcom-cst-p0-classification",
      title: "Cost Accounting Fundamentals: Fixed, Variable, Direct, Indirect & Cost Sheets",
      youtube_video_id: "7wMAzy2sD3s",
      youtube_url: "https://www.youtube.com/watch?v=7wMAzy2sD3s",
      fallback_video_id: "OpIQuGSdAwk",
      search_query: "Cost Accounting Fundamentals Prime Cost Factory Cost Cost Sheet Preparation",
      channel_name: "Avanit Academy ",
      duration: "24:20",
      difficulty: "Beginner",
      topic_focus: "Prime Cost (Direct Material + Direct Labor), Factory Overhead, Cost of Production & Cost Sheet",
      key_takeaways: [
        "Classifying costs by behavior: Fixed costs (constant in total, variable per unit) vs Variable costs",
        "Direct costs (traceable directly to product) vs Indirect factory manufacturing overheads",
        "Structuring a formal industrial Cost Sheet: Prime Cost -> Works/Factory Cost -> Cost of Production -> Cost of Goods Sold -> Total Cost",
        "Determining final unit sales price by adding target operating profit margin"
      ]
    }],
    1: [{
      id: "bcom-cst-p1-marginal-costing",
      title: "Marginal Costing & Cost-Volume-Profit (CVP) Analysis: Break-Even Point & PV Ratio",
      youtube_video_id: "9PW5gQ6C8EM",
      youtube_url: "https://www.youtube.com/watch?v=9PW5gQ6C8EM",
      fallback_video_id: "swRHc2JqaVE",
      search_query: "Marginal Costing Cost Volume Profit CVP Analysis Break Even Point PV Ratio Margin of Safety",
      channel_name: "CWG for BCom",
      duration: "28:10",
      difficulty: "Intermediate",
      topic_focus: "Contribution = Sales - Variable Cost, Profit-Volume (PV) Ratio, Break-Even Point (BEP) & Margin of Safety",
      key_takeaways: [
        "Marginal costing equation: Sales - Variable Costs = Contribution = Fixed Costs + Profit",
        "Calculating Profit-Volume (P/V) Ratio: (Contribution / Sales) * 100",
        "Break-Even Point (BEP): The sales volume where company incurs zero profit and zero loss (BEP = Fixed Costs / PV Ratio)",
        "Margin of Safety (MOS): Actual Sales minus Break-Even Sales; financial cushion before incurring operating losses"
      ]
    }],
    2: [{
      id: "bcom-cst-p2-standard-costing",
      title: "Standard Costing & Variance Analysis: Material, Labor & Overhead Variances",
      youtube_video_id: "V-slJPTzFH4",
      youtube_url: "https://www.youtube.com/watch?v=V-slJPTzFH4",
      fallback_video_id: "25ROCurV9s8",
      search_query: "Standard Costing Variance Analysis Material Cost Price Usage Labor Rate Efficiency Variance",
      channel_name: "(BCOM, BAF, BMS) Scholarszilla",
      duration: "30:40",
      difficulty: "Intermediate",
      topic_focus: "Material Cost Variance (Price vs Usage), Labor Variance (Rate vs Efficiency) & Favorable/Adverse",
      key_takeaways: [
        "Establishing standard costs per unit based on engineering studies and expected procurement prices",
        "Material Cost Variance decomposition: Material Price Variance = AQ * (SP - AP); Material Usage Variance = SP * (SQ - AQ)",
        "Labor Cost Variance decomposition: Labor Rate Variance = AH * (SR - AR); Labor Efficiency Variance = SR * (SH - AH)",
        "Investigating root causes of Adverse variances: Raw material supplier price hikes, machine downtime, untrained labor"
      ]
    }],
    3: [{
      id: "bcom-cst-p3-activity-based-costing",
      title: "Activity-Based Costing (ABC) vs Traditional Overhead Allocation & Target Costing",
      youtube_video_id: "GK-_IMrGW28",
      youtube_url: "https://www.youtube.com/watch?v=GK-_IMrGW28",
      fallback_video_id: "pYSgMGoK_Jo",
      search_query: "Activity Based Costing ABC Cost Pools Cost Drivers Machine Hours Setup Hours Target Costing",
      channel_name: "Mathur Sir Classes",
      duration: "32:15",
      difficulty: "Advanced",
      topic_focus: "Cost Pools, Cost Drivers (Machine Setups, Inspection Batches), Under/Over Costing & Target Costing",
      key_takeaways: [
        "Distortions of traditional volume-based overhead allocation (direct labor hour allocations in automated plants)",
        "Activity-Based Costing (ABC) mechanism: Assigning costs to activities, then assigning activity costs to products via Cost Drivers",
        "Identifying cost drivers: Number of production runs, purchase orders processed, machine setup hours",
        "Target Costing (Japanese manufacturing philosophy): Target Cost = Market Competitive Price - Required Profit Margin"
      ]
    }],
    4: [{
      id: "bcom-cst-p4-costing-interview",
      title: "Cost Accountant / Management Accountant (CMA) Placement Interview Screening Viva",
      youtube_video_id: "AapYqwd06nE",
      youtube_url: "https://www.youtube.com/watch?v=AapYqwd06nE",
      fallback_video_id: "X6XqORI_jqg",
      search_query: "Cost Accountant CMA Interview Questions Marginal Costing Make or Buy Decision Viva",
      channel_name: "CareerRide",
      duration: "29:45",
      difficulty: "Placement",
      topic_focus: "Make vs Buy Decisions, Key Limiting Factor (Limiting Resource Optimization) & Management Viva",
      key_takeaways: [
        "Short-term operational managerial decisions: Evaluating Make or Buy decisions based strictly on differential marginal costs",
        "Optimizing product mix when facing Key Limiting Factors (e.g. machine hour bottleneck): Ranking products by Contribution per Bottleneck Hour",
        "Shut-down point decisions: Whether to continue manufacturing during temporary economic downturns (Price > Average Variable Cost)",
        "Acing Cost and Management Accountant (CMA) technical interviews at Tata Motors, L&T, ITC, and Unilever"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 20. Working Capital Management & Cash Forecasting
  // --------------------------------------------------------------------------
  'bcom-workingcap': {
    0: [{
      id: "bcom-wcm-p0-ccc-basics",
      title: "Working Capital Fundamentals: Operating Cycle & Cash Conversion Cycle (CCC)",
      youtube_video_id: "JLxy4cs8Kr8",
      youtube_url: "https://www.youtube.com/watch?v=JLxy4cs8Kr8",
      fallback_video_id: "APMNtfwC56Q",
      search_query: "Working Capital Management Operating Cycle Cash Conversion Cycle CCC Formula",
      channel_name: "Finance with Manoj Rajgopal",
      duration: "24:30",
      difficulty: "Beginner",
      topic_focus: "Gross vs Net Working Capital, Operating Cycle, Days Inventory, Days Receivables, Days Payables",
      key_takeaways: [
        "Net Working Capital (NWC): Current Assets minus Current Liabilities; measure of short-term liquidity",
        "The Operating Cycle: Time required to acquire inventory, manufacture goods, and collect cash from debtors",
        "Cash Conversion Cycle (CCC) equation: CCC = Days Inventory Outstanding (DIO) + Days Sales Outstanding (DSO) - Days Payable Outstanding (DPO)",
        "Negative working capital business models (Amazon, Dell): Collecting cash from customers long before paying suppliers"
      ]
    }],
    1: [{
      id: "bcom-wcm-p1-receivables-inventory",
      title: "Accounts Receivable Management: Credit Policies, Aging Schedules & Factoring",
      youtube_video_id: "0n-PPY3P9YM",
      youtube_url: "https://www.youtube.com/watch?v=0n-PPY3P9YM",
      fallback_video_id: "UtRsR46-69E",
      search_query: "Accounts Receivable Management Aging Schedule Credit Terms 2 10 Net 30 Factoring",
      channel_name: "Preksha Mehta",
      duration: "27:40",
      difficulty: "Intermediate",
      topic_focus: "Credit Standards (5 Cs of Credit), Aging Schedules (0-30, 31-60, 90+ days), Cash Discounts (2/10 net 30)",
      key_takeaways: [
        "Formulating commercial credit terms: Evaluating trade credit discounts (e.g. 2/10 net 30 = 2% discount if paid in 10 days)",
        "Calculating the implied annual interest cost of skipping trade discounts: Cost = (Discount % / (100 - Discount %)) * (365 / (Credit Period - Discount Period))",
        "Monitoring debtor risk using Accounts Receivable Aging Schedules and bad debt provisioning",
        "Receivables financing: Factoring (recourse vs non-recourse) and invoice discounting for immediate liquidity"
      ]
    }],
    2: [{
      id: "bcom-wcm-p2-inventory-eoq",
      title: "Inventory Control Techniques: Economic Order Quantity (EOQ), ABC Analysis & JIT",
      youtube_video_id: "6sCQeDotuNI",
      youtube_url: "https://www.youtube.com/watch?v=6sCQeDotuNI",
      fallback_video_id: "f3ci2aDvMsI",
      search_query: "Economic Order Quantity EOQ Formula Carrying Cost Ordering Cost ABC Inventory Control",
      channel_name: "CA. Naresh Aggarwal",
      duration: "28:20",
      difficulty: "Intermediate",
      topic_focus: "EOQ = sqrt(2*D*S / H), Ordering Costs vs Holding Costs, Safety Stock & Reorder Levels (ROL)",
      key_takeaways: [
        "Economic Order Quantity (EOQ) formula: Balancing annual fixed ordering costs against per-unit holding inventory costs",
        "Calculating Reorder Level: ROL = (Maximum consumption * Maximum lead time) + Safety stock",
        "ABC Inventory Classification: Category A (high value 70%, low volume 10%), Category B, Category C bulk fasteners",
        "Just-in-Time (JIT) Kanban pull systems minimizing warehouse holding costs and inventory obsolescence"
      ]
    }],
    3: [{
      id: "bcom-wcm-p3-cash-budgeting",
      title: "13-Week Cash Forecasting & Treasury Liquidity Management in Excel",
      youtube_video_id: "slOq10c8vvg",
      youtube_url: "https://www.youtube.com/watch?v=slOq10c8vvg",
      fallback_video_id: "Rkhc6mQaOY4",
      search_query: "13 Week Cash Flow Forecast Direct Method Treasury Cash Management Working Capital",
      channel_name: "CFO Sense",
      duration: "32:50",
      difficulty: "Advanced",
      topic_focus: "13-Week Rolling Cash Forecast (Direct Cash In/Out), Target Cash Balance & Commercial Paper",
      key_takeaways: [
        "Building a 13-week direct cash forecast: Tracking exact timing of cash receipts and cash disbursement disbursements",
        "Why 13 weeks: Equivalent to one full financial quarter, providing granular visibility into potential liquidity crunches",
        "Establishing Minimum Operating Cash Balances and investing surplus treasury balances in overnight money market mutual funds",
        "Short-term corporate debt instruments: Commercial Paper (CP), Treasury Bills, and bank overdraft working capital lines"
      ]
    }],
    4: [{
      id: "bcom-wcm-p4-treasury-interview",
      title: "Corporate Treasury / Working Capital Placement Interview & Liquidity Viva",
      youtube_video_id: "4slO7pxmymU",
      youtube_url: "https://www.youtube.com/watch?v=4slO7pxmymU",
      fallback_video_id: "ODX5yE2lZ8k",
      search_query: "Treasury Analyst Interview Questions Working Capital Liquidity Management Viva",
      channel_name: "Ready2Interview",
      duration: "30:10",
      difficulty: "Placement",
      topic_focus: "Bank Covenant Compliance (Current Ratio, Quick Ratio), Overtrading Symptoms & Treasury Viva",
      key_takeaways: [
        "Monitoring bank loan covenants: Current Ratio (>= 1.33:1 Tandon committee norms) and Quick Acid-Test Ratio",
        "Diagnosing 'Overtrading': Rapid sales expansion on an inadequate capital base leading to sudden catastrophic cash starvation",
        "Managing foreign exchange transaction exposure: Using forward contracts and currency options to hedge cross-border payables",
        "Clearing corporate treasury analyst and commercial banking credit analyst technical interview panels"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 21. Corporate Direct Taxation & ITR Computations
  // --------------------------------------------------------------------------
  'bcom-directtax': {
    0: [{
      id: "bcom-dtx-p0-basics",
      title: "Income Tax Act 1961 Fundamentals: Heads of Income & Residential Status",
      youtube_video_id: "5WU3uzWlCRg",
      youtube_url: "https://www.youtube.com/watch?v=5WU3uzWlCRg",
      fallback_video_id: "MC44R_nVHDM",
      search_query: "Income Tax Act 1961 5 Heads of Income Residential Status Section 6 Assessment Year",
      channel_name: "ACCOUNTSOLOGY",
      duration: "24:50",
      difficulty: "Beginner",
      topic_focus: "Previous Year vs Assessment Year, The 5 Heads of Income, Section 6 Residential Status & Tax Slabs",
      key_takeaways: [
        "Core tax terminology: Financial/Previous Year (income earned) vs Assessment Year (tax assessed and filed)",
        "The 5 statutory Heads of Income: Salaries, House Property, PGBP, Capital Gains, and Income from Other Sources",
        "Determining residential status under Section 6: Resident and Ordinarily Resident (ROR), RNOR, and Non-Resident (NR)",
        "Scope of total income: Global income taxed for residents vs Indian-sourced income for non-residents"
      ]
    }],
    1: [{
      id: "bcom-dtx-p1-pgbp",
      title: "Profits and Gains of Business or Profession (PGBP): Deductions & Disallowances",
      youtube_video_id: "6zAO7Hzm_TU",
      youtube_url: "https://www.youtube.com/watch?v=6zAO7Hzm_TU",
      fallback_video_id: "Kza6X_UXfIw",
      search_query: "PGBP Income Tax Section 28 to 44 Allowable Deductions Section 40a Disallowance Depreciation",
      channel_name: "Unacademy CA ",
      duration: "29:15",
      difficulty: "Intermediate",
      topic_focus: "Net Profit to PGBP Reconciliation, Block of Assets Depreciation (Section 32), Section 40(a) Disallowances",
      key_takeaways: [
        "Reconciling net profit as per P&L to taxable PGBP income: Adding back inadmissible expenses and deducting exempt incomes",
        "Tax depreciation under Section 32: Block of Assets concept (15% plant & machinery, 40% computers) and half-year rule",
        "Statutory disallowances: Section 40(a)(ia) for failure to deduct TDS (30% disallowed); Section 40A(3) for cash payments > Rs. 10,000",
        "Section 43B statutory dues: Deductions allowed strictly on actual payment basis before filing return due date"
      ]
    }],
    2: [{
      id: "bcom-dtx-p2-capitalgains-mat",
      title: "Capital Gains (LTCG / STCG) & Minimum Alternate Tax (MAT Section 115JB)",
      youtube_video_id: "8_BB_fx-3lM",
      youtube_url: "https://www.youtube.com/watch?v=8_BB_fx-3lM",
      fallback_video_id: "dSMITV2X918",
      search_query: "Capital Gains Section 54 Exemptions LTCG STCG Minimum Alternate Tax MAT Section 115JB Book Profit",
      channel_name: "Let's Go Digital",
      duration: "30:40",
      difficulty: "Intermediate",
      topic_focus: "Short-Term vs Long-Term Capital Gains, Cost Inflation Index (CII), Section 115JB MAT on Book Profits",
      key_takeaways: [
        "Differentiating Short-Term (STCG) from Long-Term Capital Gains (LTCG) based on holding period (12, 24, 36 months)",
        "Taxation of equity shares: Section 111A STCG (15%) and Section 112A LTCG (10% exceeding Rs. 1 Lakh without indexation)",
        "Minimum Alternate Tax (MAT under Section 115JB): Levied at 15% on adjusted Book Profits of corporate companies",
        "Carrying forward and utilizing MAT credit against normal tax liabilities over subsequent 15 assessment years"
      ]
    }],
    3: [{
      id: "bcom-dtx-p3-corporate-tax-regimes",
      title: "New Corporate Tax Regimes (Section 115BAA - 22%) & Tax Audit Form 3CD",
      youtube_video_id: "_1wzQ10UjcQ",
      youtube_url: "https://www.youtube.com/watch?v=_1wzQ10UjcQ",
      fallback_video_id: "sSY5L9V-Zro",
      search_query: "Section 115BAA Concessional Corporate Tax Rate 22% Tax Audit Form 3CA 3CD Section 44AB",
      channel_name: "CA Nilesh Chandak (AIR 18 | 29)",
      duration: "33:10",
      difficulty: "Advanced",
      topic_focus: "Concessional 22% Base Corporate Tax (Effective 25.17%), Forfeiture of Deductions & Form 3CD Clauses",
      key_takeaways: [
        "Evaluating Section 115BAA: Concessional base tax rate of 22% (effective 25.17% including surcharge and cess)",
        "Trade-off analysis: Opting for Section 115BAA requires forfeiting exemptions, special deductions, and existing MAT credit balances",
        "Mandatory Tax Audit under Section 44AB: Turnover thresholds (Rs. 1 Crore business, Rs. 10 Crores if cash transactions < 5%)",
        "Auditing Form 3CD clauses: Prior period expenses, personal expenditures, TDS compliance, and opening/closing stock valuation"
      ]
    }],
    4: [{
      id: "bcom-dtx-p4-directtax-interview",
      title: "Direct Tax Consultant / Corporate Tax Analyst Placement Interview & Viva",
      youtube_video_id: "yt-gzD9RNd0",
      youtube_url: "https://www.youtube.com/watch?v=yt-gzD9RNd0",
      fallback_video_id: "H0BUisbp8tE",
      search_query: "Direct Tax Technical Interview Questions Corporate Tax Filing Advance Tax TDS Viva",
      channel_name: "Gunjan Rathore",
      duration: "30:30",
      difficulty: "Placement",
      topic_focus: "Advance Tax Installments (15%, 45%, 75%, 100%), Interest Under 234A/B/C, ITR-6 Filing & Viva",
      key_takeaways: [
        "Advance tax schedules: Due dates (June 15, Sept 15, Dec 15, March 15) and statutory interest penalties (Sections 234B and 234C)",
        "TDS and TCS compliance: Section 194C (contractors), 194J (professional fees), 194Q (purchase of goods)",
        "Filing corporate tax return ITR-6: Mandatory digital signature certificate (DSC) and balance sheet mapping",
        "Acing corporate direct tax interviews at Big 4 accounting firms and multinational tax compliance teams"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 22. Company Law & MCA Statutory Filings
  // --------------------------------------------------------------------------
  'bcom-compliancelaw': {
    0: [{
      id: "bcom-clw-p0-companiesact",
      title: "Companies Act 2013 Fundamentals: Types of Companies & Incorporation Procedures",
      youtube_video_id: "bTGCfUp8eFw",
      youtube_url: "https://www.youtube.com/watch?v=bTGCfUp8eFw",
      fallback_video_id: "9zQbsHO6PH8",
      search_query: "Companies Act 2013 Types of Companies Private Public OPC Incorporation SPICe Plus",
      channel_name: "Unacademy CA 360 Foundation",
      duration: "25:20",
      difficulty: "Beginner",
      topic_focus: "Corporate Personality (Salomon Principle), Private vs Public Companies, OPC & SPICe+ Portal",
      key_takeaways: [
        "Corporate legal personality: Separate legal entity doctrine (Salomon v Salomon & Co), perpetual succession, common seal",
        "Classifying corporate forms: Private Limited, Public Limited, One Person Company (OPC), Section 8 Non-Profit",
        "Memorandum of Association (MOA) clauses (Name, Registered Office, Object, Liability, Capital) vs Articles (AOA)",
        "Online incorporation via MCA SPICe+ form: Integrated DIN allotment, PAN/TAN, EPFO/ESIC, and bank account opening"
      ]
    }],
    1: [{
      id: "bcom-clw-p1-board-meetings",
      title: "Board Meetings & General Meetings: Quorum, Resolutions & Secretarial Standards",
      youtube_video_id: "Jtunkon-Ofw",
      youtube_url: "https://www.youtube.com/watch?v=Jtunkon-Ofw",
      fallback_video_id: "CMFUWMZH0x4",
      search_query: "Board Meetings Section 173 AGM Annual General Meeting Quorum Ordinary Special Resolution",
      channel_name: "Bapuji Stationery Mart Parel (trusted since 1948)",
      duration: "28:40",
      difficulty: "Intermediate",
      topic_focus: "Board Meetings (Section 173 - Min 4 per year), Quorum (1/3rd or 2 directors), Ordinary vs Special Resolutions",
      key_takeaways: [
        "Board meeting statutory rules: Minimum 4 meetings per calendar year with maximum gap of 120 days between consecutive meetings",
        "Annual General Meeting (AGM Section 96): Holding AGM within 6 months from financial year close; 21 clear days notice",
        "Quorum requirements: Board meeting (1/3rd total strength or 2 directors); General meeting (based on member count tiers)",
        "Differentiating Ordinary Resolutions (simple >50% majority) from Special Resolutions (super-majority >= 75%)"
      ]
    }],
    2: [{
      id: "bcom-clw-p2-csr-compliance",
      title: "Corporate Social Responsibility (CSR Section 135) & Related Party Transactions (Section 188)",
      youtube_video_id: "uBUEy2kPuu4",
      youtube_url: "https://www.youtube.com/watch?v=uBUEy2kPuu4",
      fallback_video_id: "YQhNyibR6Ms",
      search_query: "CSR Section 135 Companies Act Net Worth Turnover Profit Related Party Transactions Section 188",
      channel_name: "CA Kavita",
      duration: "29:50",
      difficulty: "Intermediate",
      topic_focus: "CSR Eligibility Thresholds (Net Worth 500 Cr / Turnover 1000 Cr / Net Profit 5 Cr), 2% Spending Rule",
      key_takeaways: [
        "Section 135 CSR applicability thresholds: Net worth >= 500 Cr, Turnover >= 1000 Cr, or Net Profit >= 5 Cr",
        "Mandatory spending rule: Minimum 2% of average net profits of preceding 3 financial years on Schedule VII activities",
        "Unspent CSR account rules: Transferring to designated bank account within 30 days and spending within 3 fiscal years",
        "Related Party Transactions (Section 188): Arm's length principle, Audit Committee approvals, and shareholder consent"
      ]
    }],
    3: [{
      id: "bcom-clw-p3-mca-filings",
      title: "MCA Annual E-Filings: Form AOC-4 (Financials), MGT-7 (Annual Return) & DIR-3 KYC",
      youtube_video_id: "qziYplu0pIY",
      youtube_url: "https://www.youtube.com/watch?v=qziYplu0pIY",
      fallback_video_id: "x2lFVKbq37Y",
      search_query: "MCA ROC Annual Filing Form AOC 4 Balance Sheet MGT 7 Annual Return DIR 3 KYC",
      channel_name: "FCS Divesh Goyal",
      duration: "32:30",
      difficulty: "Advanced",
      topic_focus: "ROC E-Filings, Form AOC-4 (XBRL Financials), Form MGT-7/7A, Board Report & Penalties for Delay",
      key_takeaways: [
        "Annual statutory filings with Registrar of Companies (ROC): Form AOC-4 for filing audited balance sheet and P&L",
        "XBRL mandate: Filing AOC-4 XBRL for listed companies and public companies with paid-up capital >= 5 Crores",
        "Form MGT-7 / MGT-7A: Annual return detailing shareholding pattern, indebtedness, director remuneration, and meeting dates",
        "Director compliance: Annual DIR-3 KYC filing to avoid deactivation of Director Identification Number (DIN)"
      ]
    }],
    4: [{
      id: "bcom-clw-p4-compliance-interview",
      title: "Company Secretary (CS) / Corporate Legal Compliance Placement Interview Viva",
      youtube_video_id: "vagYSFKRsZg",
      youtube_url: "https://www.youtube.com/watch?v=vagYSFKRsZg",
      fallback_video_id: "sjKcLEVhNfc",
      search_query: "Company Secretary Interview Questions Secretarial Audit MCA Compliance Director Duties Viva",
      channel_name: "CareerVidz",
      duration: "31:15",
      difficulty: "Placement",
      topic_focus: "Director Disqualification (Section 164), Secretarial Audit (Form MR-3), NCLT Petitions & Viva",
      key_takeaways: [
        "Grounds for director disqualification under Section 164(2): Failure to file annual accounts or returns for continuous 3 years",
        "Secretarial Audit mandate under Section 204: Mandatory for listed companies; Form MR-3 issued by practicing CS",
        "Filing petitions before the National Company Law Tribunal (NCLT) for oppression and mismanagement (Section 241)",
        "Acing corporate secretarial and legal compliance interviews at listed conglomerates and corporate law firms"
      ]
    }]
  },

  // ==========================================================================
  // BBA (BUSINESS ADMINISTRATION & MANAGEMENT)
  // ==========================================================================

  // --------------------------------------------------------------------------
  // 23. Business Strategy & Corporate OKRs
  // --------------------------------------------------------------------------
  'bba-strategy': {
    0: [{
      id: "bba-str-p0-frameworks",
      title: "Strategic Management Fundamentals: Porter's 5 Forces, SWOT & PESTLE Analysis",
      youtube_video_id: "CVFgWuerrR0",
      youtube_url: "https://www.youtube.com/watch?v=CVFgWuerrR0",
      fallback_video_id: "UqPKdl8TfZI",
      search_query: "Porters Five Forces Model Industry Analysis SWOT PESTLE Framework Harvard Business",
      channel_name: "sanjay_appan",
      duration: "24:15",
      difficulty: "Beginner",
      topic_focus: "Michael Porter's 5 Forces (Rivalry, Entrants, Substitutes, Buyer/Supplier Power), PESTLE & SWOT",
      key_takeaways: [
        "Evaluating industry attractiveness using Porter's Five Forces: Threat of new entrants, buyer power, supplier power, substitutes, rivalry",
        "Macro-environmental screening using PESTLE: Political, Economic, Social, Technological, Legal, Environmental drivers",
        "Internal vs external strategic audit: Synthesizing Strengths, Weaknesses, Opportunities, and Threats (SWOT Matrix)",
        "Generic competitive strategies: Cost Leadership, Differentiation, and Focused Niche strategies"
      ]
    }],
    1: [{
      id: "bba-str-p1-vrio-bcg",
      title: "Internal Resource Analysis: VRIO Framework, Core Competencies & BCG Growth Matrix",
      youtube_video_id: "afrPC91zCkQ",
      youtube_url: "https://www.youtube.com/watch?v=afrPC91zCkQ",
      fallback_video_id: "a9LWp9y2fMw",
      search_query: "VRIO Framework Sustainable Competitive Advantage BCG Matrix Stars Cash Cows Dogs",
      channel_name: "Business School 101",
      duration: "27:40",
      difficulty: "Intermediate",
      topic_focus: "VRIO Criteria (Valuable, Rare, Inimitable, Organized), BCG Matrix (Stars, Cash Cows, Question Marks, Dogs)",
      key_takeaways: [
        "Testing internal resources for sustained competitive advantage with VRIO: Valuable, Rare, Inimitable, Organizationally embedded",
        "Prahalad & Hamel Core Competencies: Harmonizing diverse production skills into difficult-to-replicate crown jewels",
        "The Boston Consulting Group (BCG) Growth-Share Matrix: Stars (invest), Cash Cows (milk for cash), Question Marks, Dogs (divest)",
        "Ansoff Product-Market Growth Matrix: Market Penetration, Product Development, Market Development, Diversification"
      ]
    }],
    2: [{
      id: "bba-str-p2-okrs-balanced-scorecard",
      title: "Executing Corporate Strategy: Objectives & Key Results (OKRs) & Balanced Scorecard",
      youtube_video_id: "drTeC6DffFM",
      youtube_url: "https://www.youtube.com/watch?v=drTeC6DffFM",
      fallback_video_id: "65MavBVSp1o",
      search_query: "Objectives and Key Results OKRs John Doerr Measure What Matters Balanced Scorecard",
      channel_name: "Call Me Griffin",
      duration: "28:50",
      difficulty: "Intermediate",
      topic_focus: "John Doerr OKR Framework, Aspirational vs Committed OKRs, The 4 Perspectives of Balanced Scorecard",
      key_takeaways: [
        "The Google / Intel OKR methodology: Qualitative inspirational Objectives paired with 3-5 quantitative measurable Key Results",
        "Committed OKRs (expected 100% attainment) vs Aspirational stretch OKRs (60-70% achievement considered success)",
        "The Balanced Scorecard (Kaplan & Norton): Balancing Financial, Customer, Internal Business Processes, and Learning/Growth",
        "Cascading strategic priorities from C-suite corporate OKRs down to department, team, and individual milestones"
      ]
    }],
    3: [{
      id: "bba-str-p3-blue-ocean",
      title: "Blue Ocean Strategy: Value Innovation, Strategy Canvas & Four Actions Framework",
      youtube_video_id: "5GKLqs1IkpU",
      youtube_url: "https://www.youtube.com/watch?v=5GKLqs1IkpU",
      fallback_video_id: "lQWWXiV23EQ",
      search_query: "Blue Ocean Strategy Value Innovation Strategy Canvas Four Actions Framework ERR C",
      channel_name: "OKR Institute®",
      duration: "32:15",
      difficulty: "Advanced",
      topic_focus: "Red Oceans (Bloody Price Competition) vs Blue Oceans (Uncontested Market Space), ERRC Grid (Eliminate, Reduce, Raise, Create)",
      key_takeaways: [
        "Escaping bloody 'Red Oceans' of cut-throat commodity competition into uncontested, high-growth 'Blue Oceans'",
        "Value Innovation: Simultaneously pursuing product differentiation and low cost by breaking the value-cost trade-off",
        "The Four Actions Framework (ERRC Grid): What factors to Eliminate, Reduce below industry standards, Raise, and Create newly",
        "Plotting the Strategy Canvas curve against legacy incumbents (e.g. Cirque du Soleil reinventing traditional circus entertainment)"
      ]
    }],
    4: [{
      id: "bba-str-p4-strategy-interview",
      title: "Management Consulting / Strategy Associate Placement Interview & Case Study Viva",
      youtube_video_id: "JXZF31xbyz0",
      youtube_url: "https://www.youtube.com/watch?v=JXZF31xbyz0",
      fallback_video_id: "gCEPeB0zETc",
      search_query: "Management Consulting Case Interview Profitability Market Entry McKinsey BCG Case Interview",
      channel_name: "Ziad Shares",
      duration: "31:45",
      difficulty: "Placement",
      topic_focus: "Profitability Tree (Revenue - Cost), Market Entry Sizing, M&A Synergy Evaluation & Partner Case Viva",
      key_takeaways: [
        "Structuring live consulting case interviews: Profitability framework (Revenue = Price * Vol; Cost = Fixed + Variable)",
        "Market Sizing and Guesstimations using structured top-down population pyramids and bottom-up replacement rates",
        "Evaluating strategic M&A acquisitions: Revenue synergies (cross-selling) vs Cost synergies (headcount rationalization)",
        "Acing case interview rounds at McKinsey & Company, Boston Consulting Group (BCG), Bain, and Strategy&"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 24. Brand Marketing & Digital Growth Funnels
  // --------------------------------------------------------------------------
  'bba-marketing': {
    0: [{
      id: "bba-mkt-p0-4ps-funnel",
      title: "Marketing Fundamentals: The 4 Ps, STP Framework & The AIDA Marketing Funnel",
      youtube_video_id: "Mco8vBAwOmA",
      youtube_url: "https://www.youtube.com/watch?v=Mco8vBAwOmA",
      fallback_video_id: "iGOw39GWDaI",
      search_query: "Marketing 4 Ps Product Price Place Promotion STP Segmentation AIDA Funnel Philip Kotler",
      channel_name: "College & Career Ready Labs │ Paxton Patterson",
      duration: "24:30",
      difficulty: "Beginner",
      topic_focus: "Marketing Mix (Product, Price, Place, Promotion), STP (Segmentation, Targeting, Positioning) & AIDA",
      key_takeaways: [
        "The traditional 4 Ps Marketing Mix: Product design, Pricing strategy, Place distribution channels, Promotional tactics",
        "The STP Framework: Segmenting markets (demographic, psychographic, behavioral), Targeting viable segments, Brand Positioning",
        "The AIDA purchase funnel: Attention (Brand awareness), Interest, Desire, Action (Conversion)",
        "Developing distinct Ideal Customer Profiles (ICP) and multi-dimensional buyer personas"
      ]
    }],
    1: [{
      id: "bba-mkt-p1-digital-growth",
      title: "Performance Marketing: Google Ads (SEM), Facebook / Meta Ads & ROAS Optimization",
      youtube_video_id: "jQjOD579jhI",
      youtube_url: "https://www.youtube.com/watch?v=jQjOD579jhI",
      fallback_video_id: "N0dlAUOFGvs",
      search_query: "Performance Marketing Tutorial Google Ads Meta Ads ROAS Cost Per Click Conversion Tracking",
      channel_name: "Explained Hub",
      duration: "28:15",
      difficulty: "Intermediate",
      topic_focus: "Search Intent (SEM), Paid Social Ads, Cost Per Click (CPC), Cost Per Acquisition (CPA) & ROAS",
      key_takeaways: [
        "High-intent Search Engine Marketing (SEM): Keyword match types, Quality Score, ad rank auctions, negative keywords",
        "Paid social media marketing on Meta/Instagram: Audience pixel retargeting, Lookalike audiences, creative fatigue",
        "Core performance metrics: Click-Through Rate (CTR), Cost Per Click (CPC), Conversion Rate (CVR), Customer Acquisition Cost (CAC)",
        "Calculating Return on Ad Spend: ROAS = Campaign Revenue Generated / Total Advertising Spend"
      ]
    }],
    2: [{
      id: "bba-mkt-p2-seo-content",
      title: "Content Marketing & Search Engine Optimization (SEO): On-Page, Off-Page & Technical SEO",
      youtube_video_id: "0h5Fl8N3hJc",
      youtube_url: "https://www.youtube.com/watch?v=0h5Fl8N3hJc",
      fallback_video_id: "F4Gwmx0mP3o",
      search_query: "Search Engine Optimization SEO Full Course Keyword Research On Page Technical Backlinks",
      channel_name: "D2C Decoded By Nikhil",
      duration: "29:40",
      difficulty: "Intermediate",
      topic_focus: "Keyword Search Volume & Keyword Difficulty, Title Tags, Meta Descriptions, Core Web Vitals & Backlinks",
      key_takeaways: [
        "Conducting keyword research: Identifying high commercial-intent search terms with realistic Keyword Difficulty (KD)",
        "On-page optimization: Title tags, meta descriptions, semantic H1/H2 header hierarchies, internal linking architecture",
        "Technical SEO fundamentals: XML sitemaps, robots.txt directives, mobile responsiveness, Core Web Vitals speed scores",
        "Off-page authority building: High-quality editorial backlink acquisition and digital PR outreach"
      ]
    }],
    3: [{
      id: "bba-mkt-p3-funnel-attribution",
      title: "Omni-Channel Marketing Automation, Email Drip Campaigns & Multi-Touch Attribution",
      youtube_video_id: "8LmdfySS-N4",
      youtube_url: "https://www.youtube.com/watch?v=8LmdfySS-N4",
      fallback_video_id: "cBCzt5vGvZE",
      search_query: "Marketing Attribution Models First Touch Last Touch W Shaped Email Automation Drip Campaign",
      channel_name: "Management Mantra ",
      duration: "32:30",
      difficulty: "Advanced",
      topic_focus: "Attribution Models (First-Click, Last-Click, Linear, W-Shaped), Lifecycle Drip Sequences & Churn Re-engagement",
      key_takeaways: [
        "Marketing attribution models: Comparing First-Touch (acquisition source) vs Last-Touch vs Multi-Touch W-Shaped attribution",
        "Designing lifecycle email automation flows: Welcome onboarding series, abandoned cart recovery, browse abandonment drips",
        "Analyzing email performance: Deliverability, open rate, click-to-open rate (CTOR), and unsubscribe rates",
        "Omni-channel synchronization: Aligning push notifications, SMS marketing, and email messaging to customer journey stages"
      ]
    }],
    4: [{
      id: "bba-mkt-p4-marketing-interview",
      title: "Brand Marketing Manager / Growth Marketer Placement Interview Screening Viva",
      youtube_video_id: "G-ZLiUWT4UQ",
      youtube_url: "https://www.youtube.com/watch?v=G-ZLiUWT4UQ",
      fallback_video_id: "x1jchUY0ekU",
      search_query: "Marketing Manager Interview Questions Campaign Budget Allocation Growth Marketing Case Viva",
      channel_name: "CareerVidz",
      duration: "30:45",
      difficulty: "Placement",
      topic_focus: "Campaign Budget Allocation Across Channels, Creative Testing Frameworks & Marketing Director Viva",
      key_takeaways: [
        "Allocating marketing budgets across top-of-funnel brand awareness (30%) vs bottom-of-funnel direct response performance (70%)",
        "Managing brand positioning crises and public relations (PR) reputational damage on social media",
        "Structuring rapid iterative creative testing: Hook testing, angle testing, user-generated content (UGC) ad formats",
        "Passing Marketing Manager and Growth Lead interviews at Unilever, Procter & Gamble, L'Oréal, and Zomato"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 25. Product Operations & Lifecycle Management
  // --------------------------------------------------------------------------
  'bba-productops': {
    0: [{
      id: "bba-pop-p0-pm-lifecycle",
      title: "Product Management Fundamentals: The Product Lifecycle (PLC) & Agile Frameworks",
      youtube_video_id: "CIfkA9JhYIw",
      youtube_url: "https://www.youtube.com/watch?v=CIfkA9JhYIw",
      fallback_video_id: "NwiIY3dZr1k",
      search_query: "Product Management for Beginners Product Life Cycle Introduction Growth Maturity Decline",
      channel_name: "Simplilearn",
      duration: "24:10",
      difficulty: "Beginner",
      topic_focus: "The 4 PLC Stages (Introduction, Growth, Maturity, Decline), Scrum Ceremonies & The Product Triad",
      key_takeaways: [
        "Navigating the Product Life Cycle (PLC): Introduction (R&D burn), Growth (scaling), Maturity (cash cow), Decline",
        "The Product Triad: Collaboration between Product Management (Value), Product Design/UX (Usability), Engineering (Feasibility)",
        "Agile Scrum ceremonies: Daily standups, sprint planning, backlog refinement, sprint review, and retrospectives",
        "Defining the Minimum Viable Product (MVP): The smallest experiment allowing validated learning with least effort"
      ]
    }],
    1: [{
      id: "bba-pop-p1-plg-flywheels",
      title: "Product-Led Growth (PLG): Self-Serve Onboarding, Freemium & The Value Flywheel",
      youtube_video_id: "xef_bCjoRCk",
      youtube_url: "https://www.youtube.com/watch?v=xef_bCjoRCk",
      fallback_video_id: "GnIkr6cWBr8",
      search_query: "Product Led Growth PLG Freemium vs Free Trial Time to Value Aha Moment Slack Zoom",
      channel_name: "Gate Smashers",
      duration: "28:30",
      difficulty: "Intermediate",
      topic_focus: "Product-Led Growth (PLG) Principles, Shortening Time-to-Value (TTV), The 'Aha!' Moment & Freemium",
      key_takeaways: [
        "Product-Led Growth (PLG) philosophy: Using the product itself as the primary driver of acquisition, retention, and expansion",
        "Minimizing Time-to-Value (TTV): Frictionless self-serve onboarding without sales gatekeepers",
        "Identifying the critical 'Aha!' moment (e.g. Slack: sending 2,000 team messages; Dropbox: saving 1 file)",
        "Freemium vs Free Trial: Structuring paywalls around feature gates, usage caps, or team collaboration features"
      ]
    }],
    2: [{
      id: "bba-pop-p2-prioritization-frameworks",
      title: "Roadmap Prioritization: RICE, MoSCoW, Kano Model & Backlog Grooming",
      youtube_video_id: "JJzODsXsCt0",
      youtube_url: "https://www.youtube.com/watch?v=JJzODsXsCt0",
      fallback_video_id: "UXgOOCy95EA",
      search_query: "Product Roadmap Prioritization RICE Scoring Framework Kano Model MoSCoW Backlog",
      channel_name: "HelloPM",
      duration: "29:15",
      difficulty: "Intermediate",
      topic_focus: "RICE Scoring Formula (Reach * Impact * Confidence / Effort), MoSCoW Method & Kano Customer Satisfaction",
      key_takeaways: [
        "The RICE prioritization score: (Reach * Impact * Confidence %) / Effort; objective scoring removing executive bias",
        "MoSCoW method: Categorizing backlog epics into Must-have, Should-have, Could-have, and Won't-have this release",
        "The Kano Model: Basic threshold expectations (Must-be), linear performance attributes, and unexpected Delighters",
        "Managing technical debt: Balancing new feature development against architectural refactoring and bug fixes"
      ]
    }],
    3: [{
      id: "bba-pop-p3-northstar-metrics",
      title: "Product Analytics: North Star Metric, Heart Framework & Retention Cohorts",
      youtube_video_id: "5rBu6izpWfo",
      youtube_url: "https://www.youtube.com/watch?v=5rBu6izpWfo",
      fallback_video_id: "HkKf3Mhszww",
      search_query: "North Star Metric Product Analytics Google HEART Framework Mixpanel Amplitude",
      channel_name: "GrizzPM: Product Management & Strategy Applied",
      duration: "32:40",
      difficulty: "Advanced",
      topic_focus: "North Star Metric (Capturing Value Delivered), Google HEART Framework, Event Tracking & Drop-off Funnels",
      key_takeaways: [
        "Defining the North Star Metric: The single key metric that best captures core customer value delivered (e.g. Airbnb: Nights booked)",
        "Google's HEART framework: Happiness, Engagement, Adoption, Retention, and Task Success metrics",
        "Event tracking instrumentations in Mixpanel and Amplitude: Defining user events, properties, and funnels",
        "Analyzing user conversion funnels: Locating specific drop-off friction steps in checkout and registration flows"
      ]
    }],
    4: [{
      id: "bba-pop-p4-product-interview",
      title: "Associate Product Manager (APM) / Product Ops Placement Interview Screening Viva",
      youtube_video_id: "bAMh8eWRShU",
      youtube_url: "https://www.youtube.com/watch?v=bAMh8eWRShU",
      fallback_video_id: "yHJYtNLh4Vo",
      search_query: "Product Manager Interview Questions Product Design Metric Decline Case Study APM Viva",
      channel_name: "Malay Krishna",
      duration: "31:30",
      difficulty: "Placement",
      topic_focus: "Product Design Scenarios ('Design an Alarm Clock for the Blind'), Metric Drop Root Cause & PM Viva",
      key_takeaways: [
        "Product Design interview questions: Clarifying context, user segmentation, pain points, prioritizing solutions, trade-offs",
        "Root cause analysis for metric drops: 'Daily Active Users dropped 10% yesterday—how would you investigate?'",
        "Executing stakeholder alignment: Navigating pushback from engineering leads on unrealistic delivery deadlines",
        "Acing APM and Product Manager hiring loops at Google, Uber, Atlassian, Swiggy, and Microsoft"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 26. Human Resource Management & Talent Acquisition
  // --------------------------------------------------------------------------
  'bba-hrm': {
    0: [{
      id: "bba-hrm-p0-foundations",
      title: "Human Resource Management (HRM): Strategic HR, Job Analysis & Job Description (JD)",
      youtube_video_id: "SZPL7c0Cd3Q",
      youtube_url: "https://www.youtube.com/watch?v=SZPL7c0Cd3Q",
      fallback_video_id: "fWG-bwTKVXk",
      search_query: "Human Resource Management Introduction Strategic HRM Job Analysis Job Description",
      channel_name: "DWIVEDI GUIDANCE",
      duration: "23:45",
      difficulty: "Beginner",
      topic_focus: "Administrative vs Strategic HRM, Job Analysis (Observation, Interviews), Job Description vs Job Specification",
      key_takeaways: [
        "Transition from administrative personnel management to Strategic Human Resource Management (SHRM)",
        "Conducting Job Analysis: Systematically gathering duties, responsibilities, necessary skills, and work environment",
        "Authoring clear Job Descriptions (JD): Role summary, key performance areas, reporting line, and working conditions",
        "Specifying Job Specifications: Minimum education qualifications, technical skills, certifications, and competencies"
      ]
    }],
    1: [{
      id: "bba-hrm-p1-talent-acquisition",
      title: "Talent Acquisition & Sourcing Pipelines: Inbound, Outbound & ATS Management",
      youtube_video_id: "TpO_kogeHLA",
      youtube_url: "https://www.youtube.com/watch?v=TpO_kogeHLA",
      fallback_video_id: "uhDLHn6uVUg",
      search_query: "Talent Acquisition Recruitment Strategies Boolean Search LinkedIn Sourcing ATS Systems",
      channel_name: "Keka HR",
      duration: "27:10",
      difficulty: "Intermediate",
      topic_focus: "Recruitment Funnel, Boolean Search on LinkedIn, Employer Branding & Applicant Tracking Systems (ATS)",
      key_takeaways: [
        "Managing the Talent Acquisition funnel: Sourced -> Screened -> First Round -> Technical -> Offer -> Onboarded",
        "Advanced Boolean search strings on LinkedIn Recruiter: AND, OR, NOT, title operators, and location radius filters",
        "Employer Value Proposition (EVP): Fostering strong employer branding to attract passive candidates organically",
        "Operating modern Applicant Tracking Systems (Greenhouse, Lever, Workday) and tracking Time-to-Hire and Cost-per-Hire"
      ]
    }],
    2: [{
      id: "bba-hrm-p2-appraisal-performance",
      title: "Performance Management Systems: 360-Degree Feedback & Bell Curve Appraisal",
      youtube_video_id: "rm7RzBE5NJA",
      youtube_url: "https://www.youtube.com/watch?v=rm7RzBE5NJA",
      fallback_video_id: "r3qCuoNndgw",
      search_query: "Performance Appraisal Methods 360 Degree Feedback Bell Curve Normal Distribution KPI",
      channel_name: "DoerPreneur Soft",
      duration: "28:50",
      difficulty: "Intermediate",
      topic_focus: "360-Degree Multi-Rater Feedback, Forced Ranking (Bell Curve Method), Continuous Reviews & PIP",
      key_takeaways: [
        "360-degree feedback appraisal: Gathering holistic ratings from supervisors, peers, direct reports, and self-evaluations",
        "Forced Distribution / Bell Curve ranking method: Top performers (20%), average performers (70%), low performers (10%)",
        "Modern shift toward continuous performance check-ins replacing once-a-year backward-looking annual reviews",
        "Structuring formal Performance Improvement Plans (PIP): Measurable 30/60/90-day goals and documented legal support"
      ]
    }],
    3: [{
      id: "bba-hrm-p3-labor-laws",
      title: "Labor Laws & Statutory Compliance: Industrial Relations, POSH Act & Gratuity/PF",
      youtube_video_id: "tDHYY_pLA_8",
      youtube_url: "https://www.youtube.com/watch?v=tDHYY_pLA_8",
      fallback_video_id: "6-WGjOdzFo0",
      search_query: "Labor Laws India Statutory Compliance POSH Act Internal Complaints Committee Provident Fund",
      channel_name: "DWIVEDI GUIDANCE",
      duration: "32:15",
      difficulty: "Advanced",
      topic_focus: "POSH Act 2013 (Internal Complaints Committee ICC), EPF (12%), ESIC, Payment of Gratuity Act & Code on Wages",
      key_takeaways: [
        "Compliance under the POSH Act 2013 (Prevention of Sexual Harassment): Mandatory Internal Committee (IC) constitution",
        "Statutory employee retirement benefits: Employees' Provident Fund (EPF 12% match), ESI healthcare coverage",
        "Payment of Gratuity Act: Mandatory gratuity eligibility upon completing 5 years of continuous service (15 days last drawn salary / 26 * service years)",
        "Industrial Disputes Act and the new Indian Labor Codes: Retrenchment compensation, notice periods, and dispute conciliation"
      ]
    }],
    4: [{
      id: "bba-hrm-p4-hr-interview",
      title: "Human Resources (HR) Generalist / HRBP Placement Interview Screening Viva",
      youtube_video_id: "kdrSRcwssZg",
      youtube_url: "https://www.youtube.com/watch?v=kdrSRcwssZg",
      fallback_video_id: "ZOc6VMhzoio",
      search_query: "HR Business Partner HRBP Interview Questions Employee Relations Grievance Handling Viva",
      channel_name: "Ready to get Update",
      duration: "30:20",
      difficulty: "Placement",
      topic_focus: "Employee Grievance Redressal, Attrition Rate Analysis, Salary Benchmarking & HRBP Viva",
      key_takeaways: [
        "Handling toxic employee grievance conflicts and confidential disciplinary inquiries objectively",
        "Calculating and mitigating voluntary employee attrition rates: Analyzing exit interview trend themes",
        "Compensation and Benefits benchmarking: Designing competitive CTC salary structures (Base, HRA, Variable, ESOPs)",
        "Acing HR Business Partner (HRBP) and Talent Lead interviews at Google, TCS, Deloitte, and HDFC Bank"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // 27. Supply Chain Logistics & Operations
  // --------------------------------------------------------------------------
  'bba-supplychain': {
    0: [{
      id: "bba-scm-p0-basics",
      title: "Supply Chain Management Fundamentals: Upstream, Downstream & The SCOR Model",
      youtube_video_id: "7EYKwnhnLOE",
      youtube_url: "https://www.youtube.com/watch?v=7EYKwnhnLOE",
      fallback_video_id: "k1FYft3cfok",
      search_query: "Supply Chain Management Fundamentals SCOR Model Plan Source Make Deliver Return",
      channel_name: "AIMS Education",
      duration: "24:45",
      difficulty: "Beginner",
      topic_focus: "Upstream Suppliers vs Downstream Distribution, The SCOR Model (Plan, Source, Make, Deliver, Return)",
      key_takeaways: [
        "Supply Chain architecture: Upstream tier 1/2 suppliers -> focal manufacturer -> downstream distributors, retailers, consumers",
        "The APICS SCOR Model processes: Plan (forecasting), Source (procurement), Make (manufacturing), Deliver (logistics), Return (reverse logistics)",
        "Push vs Pull supply chain strategies: Make-to-Stock (MTS based on forecasts) vs Make-to-Order (MTO based on real demand)",
        "Measuring Order Fill Rate and On-Time In-Full (OTIF) delivery performance metrics"
      ]
    }],
    1: [{
      id: "bba-scm-p1-bullwhip-effect",
      title: "The Bullwhip Effect in Supply Chains: Causes, Beer Game Simulation & Remedies",
      youtube_video_id: "qpkUhFyneRg",
      youtube_url: "https://www.youtube.com/watch?v=qpkUhFyneRg",
      fallback_video_id: "m_LGdGsGH8k",
      search_query: "Bullwhip Effect Supply Chain MIT Beer Game Order Batching Price Fluctuations",
      channel_name: "DWIVEDI GUIDANCE",
      duration: "27:50",
      difficulty: "Intermediate",
      topic_focus: "Demand Distortion Amplification, The 4 Drivers of Bullwhip Effect, Vendor-Managed Inventory (VMI)",
      key_takeaways: [
        "The Bullwhip Effect: Small fluctuations in consumer retail demand creating exponentially massive swings upstream to component suppliers",
        "The four primary root causes: Demand forecast updating, order batching, price fluctuations (promotions), and rationing gaming",
        "Mitigating demand distortion: Sharing real-time Point of Sale (POS) electronic barcode data across all tiers",
        "Vendor-Managed Inventory (VMI): Suppliers monitoring customer stock levels and replenishing inventory proactively"
      ]
    }],
    2: [{
      id: "bba-scm-p2-warehouse-logistics",
      title: "Warehouse Operations: Cross-Docking, Layout Optimization & WMS Software",
      youtube_video_id: "0XvTJgoWY74",
      youtube_url: "https://www.youtube.com/watch?v=0XvTJgoWY74",
      fallback_video_id: "b3fVAAyfrV4",
      search_query: "Warehouse Management Cross Docking Pick and Pack WMS Systems Inbound Outbound",
      channel_name: "Brain Logistic",
      duration: "29:10",
      difficulty: "Intermediate",
      topic_focus: "Cross-Docking Strategy, Wave vs Zone Picking, Slotting Optimization & Warehouse Management Systems (WMS)",
      key_takeaways: [
        "Cross-docking logistics: Unloading inbound trailer shipments and loading directly onto outbound trucks with near-zero storage holding time",
        "Order picking methodologies: Single-order picking, batch picking, wave picking, and zone picking",
        "Warehouse slotting optimization: Placing fast-moving high-velocity SKUs closest to main shipping docks to reduce forklift travel time",
        "Operating Warehouse Management Systems (WMS): Barcode scanning, RFID tags, automated guided vehicles (AGV), and pallet racking"
      ]
    }],
    3: [{
      id: "bba-scm-p3-network-procurement",
      title: "Strategic Procurement: Kraljic Matrix, Incoterms 2020 & Total Cost of Ownership (TCO)",
      youtube_video_id: "OZzMcnAtexE",
      youtube_url: "https://www.youtube.com/watch?v=OZzMcnAtexE",
      fallback_video_id: "L9-B3inc-J4",
      search_query: "Kraljic Matrix Procurement Strategy Incoterms 2020 FOB CIF DDP Total Cost of Ownership",
      channel_name: "Supply Chain Doctrine",
      duration: "33:15",
      difficulty: "Advanced",
      topic_focus: "Kraljic Portfolio Matrix (Non-Critical, Leverage, Bottleneck, Strategic), Incoterms 2020 & TCO",
      key_takeaways: [
        "The Kraljic Portfolio Matrix: Categorizing purchased items by Supply Risk and Financial Profit Impact",
        "Procurement strategies: Strategic items (partnerships), Leverage items (competitive tenders), Bottleneck items (buffer stocks)",
        "Incoterms 2020 rules: EXW (buyer bears all risk), FOB (Free on Board), CIF (Cost Insurance Freight), DDP (Delivered Duty Paid)",
        "Total Cost of Ownership (TCO): Factoring freight, customs tariffs, holding costs, and supplier quality failure rates"
      ]
    }],
    4: [{
      id: "bba-scm-p4-scm-interview",
      title: "Supply Chain Analyst / Operations Placement Interview & Inventory Case Viva",
      youtube_video_id: "uXfmbhG-xzA",
      youtube_url: "https://www.youtube.com/watch?v=uXfmbhG-xzA",
      fallback_video_id: "3_clehPHDQ4",
      search_query: "Supply Chain Analyst Interview Questions Operations Management Inventory Case Study Viva",
      channel_name: "Knowledge Topper",
      duration: "30:40",
      difficulty: "Placement",
      topic_focus: "Supplier Disruption Resiliency, Dual Sourcing, Transportation Sizing & SCM Placement Viva",
      key_takeaways: [
        "Building resilient supply chains: Balancing single-sourcing cost benefits against dual-sourcing disruption risk mitigations",
        "Responding to global shipping container port delays, air freight emergency expedited logistics, and customs holds",
        "Solving network optimization transportation problems: Linear programming for warehouse distribution hub locations",
        "Clearing supply chain operations technical interviews at Amazon, Apple, DHL, Maersk, and Walmart"
      ]
    }]
  }
};

