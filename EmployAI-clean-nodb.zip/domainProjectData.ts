// ============================================================================
// Employ.AI - Industry-Grade Good Projects & Step-by-Step Build Roadmaps Engine
// Covers all domains and co-domains with multi-tiered production-grade projects
// ============================================================================

import { resolveCoDomainProfile, buildProjectsFromProfile } from './domainCoDomainIntelligence';

export type ProjectTier = 'foundational' | 'applied' | 'scalable' | 'flagship';

export interface ProjectTaskItem {
  id: string;
  title: string;
  description: string;
  estimatedHours: number;
}

export interface ProjectBuildStep {
  stepNumber: number;
  title: string;
  phaseName: string;
  focus: string;
  estimatedHours: number;
  deliverable: string;
  architectureFocus: string;
  tasks: ProjectTaskItem[];
  pitfallsToAvoid: string[];
  proTips: string[];
}

export interface ProjectInterviewQA {
  question: string;
  recruiterIntent: string;
  answerStrategy: string;
}

export interface GoodProject {
  id: string;
  coDomainName: string;
  stream: string;
  tier: ProjectTier;
  tierLabel: string;
  title: string;
  tagline: string;
  description: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Flagship Production';
  estimatedDuration: string;
  totalEstimatedHours: number;
  recruiterAppeal: string;
  techStack: {
    frontend?: string[];
    backend?: string[];
    database?: string[];
    cloudDevOps?: string[];
    aiLibraries?: string[];
    tools?: string[];
  };
  keyFeatures: string[];
  architecturePattern: string;
  buildRoadmap: ProjectBuildStep[];
  resumeStarBullet: string;
  interviewQuestions: ProjectInterviewQA[];
  githubTemplateHint: string;
}

// ----------------------------------------------------------------------------
// Curated Hand-Crafted Projects for High-Demand Co-Domains
// ----------------------------------------------------------------------------
const CURATED_PROJECTS: Record<string, GoodProject[]> = {
  // --------------------------------------------------------------------------
  // REACT & NEXT.JS
  // --------------------------------------------------------------------------
  'React & Next.js UI Architecture': [
    {
      id: 'react-p1-canvas',
      coDomainName: 'React & Next.js UI Architecture',
      stream: 'Computer Science',
      tier: 'foundational',
      tierLabel: 'Tier 1: Foundational Architecture',
      title: 'Real-Time Collaborative Wireframe & Canvas Studio',
      tagline: 'Infinite pan/zoom vector canvas with optimistic mutations and undo/redo stacks.',
      description: 'A high-performance infinite canvas built with React 19, TypeScript, and HTML5 Canvas / SVG rendering. Features full command-pattern history (undo/redo), custom shape rendering, and snappy 60fps gesture handling without rerender thrashing.',
      difficulty: 'Intermediate',
      estimatedDuration: '2 Weeks (20 hrs total)',
      totalEstimatedHours: 20,
      recruiterAppeal: 'Demonstrates deep mastery of the React render cycle, memory leak prevention in event listeners, and clean component decoupling rather than basic UI library stitching.',
      techStack: {
        frontend: ['React 19', 'Next.js 15 (App Router)', 'TypeScript', 'Tailwind / Vanilla CSS', 'Zustand'],
        tools: ['Vitest', 'Canvas API', 'Lucide Icons']
      },
      keyFeatures: [
        'Infinite pan-and-zoom viewport with matrix transforms',
        'Command pattern undo/redo stack with 50-step depth',
        'Optimistic state updates with localized re-rendering',
        'Multi-element bounding box selection and group transformation',
        'Export to PNG, SVG, and structured JSON schemas'
      ],
      architecturePattern: 'State Machine & Command Pattern with Canvas Offscreen Buffering',
      buildRoadmap: [
        {
          stepNumber: 1,
          phaseName: 'Phase 1: Architecture & Vector Mathematics',
          title: 'Viewport Math, Coordinate System & Canvas Pipeline',
          focus: 'Translating screen space (client X/Y) into infinite world coordinates.',
          estimatedHours: 4,
          deliverable: 'Pan-and-zoom viewport with zero jitter and smooth 60fps wheel delta handling.',
          architectureFocus: 'Avoid React state in mousemove events; use useRef with requestAnimationFrame.',
          tasks: [
            { id: 'react-p1-s1-t1', title: 'World Coordinate Transform System', description: 'Implement 2D affine transformation matrix for zoom (0.1x to 5x) and pan offsets.', estimatedHours: 1.5 },
            { id: 'react-p1-s1-t2', title: 'Decoupled Gesture Listener Engine', description: 'Mount pointer listeners to window ref with passive event listener optimizations.', estimatedHours: 1.5 },
            { id: 'react-p1-s1-t3', title: 'Grid & Snap-to-Grid Math', description: 'Add isometric dot grid background with dynamic sub-pixel division rounding.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Storing pointer coordinates in React useState causing 120 rerenders per second.'],
          proTips: ['Use requestAnimationFrame throttle and ref-backed render loops for buttery smoothness.']
        },
        {
          stepNumber: 2,
          phaseName: 'Phase 2: Data Modeling & Element Tree',
          title: 'Vector Shape Models & Normalized Store',
          focus: 'Structuring elements into a normalized lookup table with O(1) attribute access.',
          estimatedHours: 4,
          deliverable: 'Zustand or Redux slice with element registry and spatial spatial indexing.',
          architectureFocus: 'Store shapes as flat dictionary { [id]: ShapeRecord } with separate zIndex array.',
          tasks: [
            { id: 'react-p1-s2-t1', title: 'TypeScript Shape Discriminators', description: 'Define strict union types for Rect, Ellipse, Text, Arrow, and Group shapes.', estimatedHours: 1.5 },
            { id: 'react-p1-s2-t2', title: 'Zustand Store Slice with Immer', description: 'Create mutation actions for move, resize, rotate, and style modifications.', estimatedHours: 1.5 },
            { id: 'react-p1-s2-t3', title: 'Z-Index Ordering Engine', description: 'Implement Bring to Front, Send to Back, and depth swapping algorithms.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Deeply nested arrays where updating one shape clones the entire document tree.'],
          proTips: ['Use shallow equality selectors to ensure only modified shapes trigger DOM updates.']
        },
        {
          stepNumber: 3,
          phaseName: 'Phase 3: Interactive Selection & Handles',
          title: 'Bounding Box Transformer & Snapping',
          focus: 'Multi-selection bounding box with 8-point resize handles and rotation.',
          estimatedHours: 4,
          deliverable: 'Interactive selection marquee and transform bounding box with aspect-ratio locking.',
          architectureFocus: 'Composite SVG overlay overlaying the canvas canvas layer.',
          tasks: [
            { id: 'react-p1-s3-t1', title: 'Marquee Multi-Select Algorithm', description: 'Calculate Axis-Aligned Bounding Box (AABB) collisions for lasso selection.', estimatedHours: 1.5 },
            { id: 'react-p1-s3-t2', title: '8-Point Resize Anchor Logic', description: 'Compute anchor-anchored delta changes preserving top-left vs bottom-right origins.', estimatedHours: 1.5 },
            { id: 'react-p1-s3-t3', title: 'Alignment Guides & Smart Snapping', description: 'Draw dynamic guidelines when edge alignment matches adjacent shapes within 4px.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Flipping negative width/height during inverted drag without coordinate normalization.'],
          proTips: ['Normalize coordinates immediately upon mouseup to keep shapes strictly positive in dimensions.']
        },
        {
          stepNumber: 4,
          phaseName: 'Phase 4: History & State Replay',
          title: 'Command Pattern History (Undo / Redo)',
          focus: 'Bulletproof transactional undo and redo stack supporting compound edits.',
          estimatedHours: 4,
          deliverable: 'Undo/Redo buttons + Ctrl+Z / Ctrl+Y keyboard shortcuts with instant state revert.',
          architectureFocus: 'Command interface with execute() and undo() closures storing delta differences.',
          tasks: [
            { id: 'react-p1-s4-t1', title: 'Command Interface & Stack Sizing', description: 'Build bounded 50-item double stack for previous states and future redo branches.', estimatedHours: 1.5 },
            { id: 'react-p1-s4-t2', title: 'Transaction Batching for Drag Operations', description: 'Collate continuous drag deltas into a single discrete command on pointer up.', estimatedHours: 1.5 },
            { id: 'react-p1-s4-t3', title: 'Keyboard Shortcut Manager', description: 'Implement global keyboard accelerator hook with collision protection for inputs.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Pushing every intermediate drag frame onto the undo stack, requiring 30 undos for 1 move.'],
          proTips: ['Record the initial snapshot on pointerdown, and only commit the delta command on pointerup.']
        },
        {
          stepNumber: 5,
          phaseName: 'Phase 5: Exporting, Testing & Live Deployment',
          title: 'High-Res Rasterization & Vercel Edge Deployment',
          focus: 'Exporting vector canvas to 2x/4x retina PNGs and deploying on Next.js edge.',
          estimatedHours: 4,
          deliverable: 'Production Next.js 15 deployment with 100% Lighthouse performance score.',
          architectureFocus: 'Headless OffscreenCanvas rendering for lossless image synthesis.',
          tasks: [
            { id: 'react-p1-s5-t1', title: 'Lossless SVG & Retina PNG Export', description: 'Serialize element models into SVG string and draw onto OffscreenCanvas for download.', estimatedHours: 1.5 },
            { id: 'react-p1-s5-t2', title: 'Vitest Unit & Gesture Testing', description: 'Write unit tests for transform math, AABB intersection, and undo/redo stacks.', estimatedHours: 1.5 },
            { id: 'react-p1-s5-t3', title: 'Production Vercel Deployment & SEO', description: 'Configure OpenGraph dynamic card preview and automated GitHub Actions build.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['CORS issues when exporting canvases that contain external images without crossOrigin="anonymous".'],
          proTips: ['Include an animated Loom walkthrough and live demo URL directly in the repository README.']
        }
      ],
      resumeStarBullet: 'Engineered a high-performance vector canvas studio in React 19 & Next.js using custom 2D affine transforms and a command-pattern undo stack, achieving 60 FPS under 1,000+ active shapes and sub-10ms state replays.',
      interviewQuestions: [
        {
          question: 'How did you prevent React component re-rendering lag while dragging elements across the canvas?',
          recruiterIntent: 'Checks if the candidate understands the difference between reactive state and imperative animation loops.',
          answerStrategy: 'Explain decoupling mousemove handling into window refs, updating coordinate transforms via direct DOM/Canvas ref manipulation inside requestAnimationFrame, and committing to reactive Zustand state only upon mouseup.'
        },
        {
          question: 'How is the undo/redo stack implemented without consuming excessive memory?',
          recruiterIntent: 'Tests knowledge of the Command Pattern and state delta compression vs deep copying.',
          answerStrategy: 'Discuss the Command pattern where each action stores only inverted element diffs (e.g. previous coords vs new coords) rather than full document copies, bounded to a maximum depth of 50 operations.'
        }
      ],
      githubTemplateHint: 'Includes modular folders: /components/canvas, /hooks/useViewportMath, /store/canvasStore.ts, and /utils/transforms.ts'
    },
    {
      id: 'react-p2-saas',
      coDomainName: 'React & Next.js UI Architecture',
      stream: 'Computer Science',
      tier: 'applied',
      tierLabel: 'Tier 2: Applied Full-Stack SaaS',
      title: 'Enterprise Multi-Tenant Kanban & Sprint Management Platform',
      tagline: 'Next.js 15 App Router platform with Server Components, optimistic drag-and-drop, and Stripe billing.',
      description: 'A production-ready project management tool modeled after Linear and Jira. Features Server Actions for mutations, optimistic column drag-and-drop, workspace role-based access control (RBAC), and webhook-driven subscription billing.',
      difficulty: 'Advanced',
      estimatedDuration: '3 Weeks (30 hrs total)',
      totalEstimatedHours: 30,
      recruiterAppeal: 'Directly mirrors the architecture of modern enterprise web products. Proves proficiency with Next.js 15 Server Components vs Client Components boundary design.',
      techStack: {
        frontend: ['Next.js 15 (React 19)', 'TypeScript', 'Tailwind CSS', 'Radix UI', '@hello-pangea/dnd'],
        backend: ['Next.js Server Actions', 'Prisma ORM', 'NextAuth / Auth.js v5'],
        database: ['PostgreSQL (Supabase / Neon)'],
        cloudDevOps: ['Vercel', 'Stripe Billing Webhooks']
      },
      keyFeatures: [
        'Multi-tenant workspace isolation with role hierarchies (Owner, Admin, Member)',
        'Optimistic Kanban board drag-and-drop with server sync rollbacks',
        'Next.js 15 Server Components with streaming Suspense skeletons',
        'Stripe customer portal integration with tier feature-gating',
        'Real-time activity audit log with markdown task comments'
      ],
      architecturePattern: 'Server-Driven UI with React Server Components & Optimistic Client Bounds',
      buildRoadmap: [
        {
          stepNumber: 1,
          phaseName: 'Phase 1: Multi-Tenant Schema & Auth',
          title: 'PostgreSQL Relational Schema & Auth.js Multi-Tenancy',
          focus: 'Designing workspace-scoped database tables with strict foreign key cascaded security.',
          estimatedHours: 6,
          deliverable: 'Prisma schema with User, Workspace, Membership, Board, Column, and Task entities.',
          architectureFocus: 'Enforce tenant isolation at the query level: WHERE workspaceId = currentSession.workspaceId.',
          tasks: [
            { id: 'react-p2-s1-t1', title: 'Prisma Schema Multi-Tenant Models', description: 'Design relations between Users, Workspaces, Boards, Tasks, and AuditLogs.', estimatedHours: 2.5 },
            { id: 'react-p2-s1-t2', title: 'Auth.js v5 JWT Multi-Session Setup', description: 'Configure Google & GitHub OAuth with active workspace claims in session JWT.', estimatedHours: 2 },
            { id: 'react-p2-s1-t3', title: 'Workspace Switching Middleware', description: 'Intercept subdomain/route params to validate user permissions per tenant.', estimatedHours: 1.5 }
          ],
          pitfallsToAvoid: ['Allowing IDOR vulnerabilities where user edits another workspace task by guessing taskId.'],
          proTips: ['Always wrap database mutations in a scoped helper that enforces workspace membership validation.']
        },
        {
          stepNumber: 2,
          phaseName: 'Phase 2: App Router Layouts & Streaming',
          title: 'Server Components, Suspense Skeletons & Layouts',
          focus: 'Leveraging React Server Components for zero-bundle-size initial database fetches.',
          estimatedHours: 6,
          deliverable: 'Instant page loading with nested streaming Suspense skeletons and zero layout shift.',
          architectureFocus: 'Keep data fetching in RSC pages; pass lean serialized props to client interaction islands.',
          tasks: [
            { id: 'react-p2-s2-t1', title: 'Nested App Router Hierarchy', description: 'Structure app/[workspaceSlug]/boards/[boardId]/page.tsx with persistent layout sidebar.', estimatedHours: 2 },
            { id: 'react-p2-s2-t2', title: 'Streaming Suspense Skeleton UI', description: 'Create loading.tsx with animated Shimmer pulse cards matching exact card dimensions.', estimatedHours: 2 },
            { id: 'react-p2-s2-t3', title: 'Server Action Mutation Endpoints', description: 'Build typed Server Actions with Zod schema validation for task creation and updates.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Passing entire Prisma models with sensitive user password hashes into Client Components.'],
          proTips: ['Use Prisma select: { id: true, title: true } to project only fields required by the UI.']
        },
        {
          stepNumber: 3,
          phaseName: 'Phase 3: Optimistic Kanban Drag & Drop',
          title: 'Drag-and-Drop Columns with Instant Re-ordering',
          focus: 'Building 0ms perceived latency board reordering with automatic rollback on server error.',
          estimatedHours: 6,
          deliverable: 'Smooth drag-and-drop between columns using fractional indexing for order persistence.',
          architectureFocus: 'Use Lexorank / fractional indexing (e.g. order = (prev + next) / 2) to eliminate bulk updates.',
          tasks: [
            { id: 'react-p2-s3-t1', title: 'DND Board Component Setup', description: 'Integrate @hello-pangea/dnd with custom draggable task cards and droppable columns.', estimatedHours: 2 },
            { id: 'react-p2-s3-t2', title: 'useOptimistic React 19 Hook', description: 'Update column position in local UI instantly before Server Action resolves.', estimatedHours: 2 },
            { id: 'react-p2-s3-t3', title: 'Fractional Index Calculation Engine', description: 'Implement floating midpoint index generation avoiding full column re-indexing.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Re-indexing 10,000 database rows on every drag-and-drop instead of using fractional ordering.'],
          proTips: ['Store task order as floating-point or Lexorank strings for O(1) single-row updates.']
        },
        {
          stepNumber: 4,
          phaseName: 'Phase 4: Stripe Billing & Feature Gating',
          title: 'Stripe Subscription Webhooks & Usage Limits',
          focus: 'Monetization architecture gating free vs Pro workspaces with automated webhook processing.',
          estimatedHours: 6,
          deliverable: 'Working Stripe checkout, billing portal redirect, and webhook event listener.',
          architectureFocus: 'Process webhook events with signature verification and idempotent database transactions.',
          tasks: [
            { id: 'react-p2-s4-t1', title: 'Stripe Checkout & Customer Portal Route', description: 'Create API routes for generating checkout sessions linked to workspace ID.', estimatedHours: 2 },
            { id: 'react-p2-s4-t2', title: 'Cryptographic Webhook Verification', description: 'Handle customer.subscription.updated/deleted events with Prisma updates.', estimatedHours: 2 },
            { id: 'react-p2-s4-t3', title: 'Tier Limit Interceptor', description: 'Gate board creation at 3 boards on Free tier, prompting upgrade modal.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Updating subscription status in the client redirect URL instead of verifying webhook signatures.'],
          proTips: ['Use Stripe CLI locally (stripe listen --forward-to localhost:3000/api/webhooks) for fast debugging.']
        },
        {
          stepNumber: 5,
          phaseName: 'Phase 5: Production Deployment & Observability',
          title: 'Vercel Deployment, Edge Caching & End-to-End Tests',
          focus: 'Hardening for enterprise reliability with Playwright automated regression suites.',
          estimatedHours: 6,
          deliverable: 'Live production URL with automated GitHub CI/CD test runners and Sentry monitoring.',
          architectureFocus: 'Static layout generation with revalidateTag for instant cache invalidation.',
          tasks: [
            { id: 'react-p2-s5-t1', title: 'Playwright E2E Test Suite', description: 'Automate user sign-in, board creation, and task drag-and-drop validation.', estimatedHours: 2.5 },
            { id: 'react-p2-s5-t2', title: 'Cache Tags & On-Demand Revalidation', description: 'Use revalidatePath and revalidateTag inside Server Actions for instant updates.', estimatedHours: 1.5 },
            { id: 'react-p2-s5-t3', title: 'Sentry Error Tracing & Production Audit', description: 'Configure Sentry Next.js SDK for client/server uncaught exception telemetry.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Not configuring database connection pooling for serverless environments (use PgBouncer / Neon).'],
          proTips: ['Document your schema with an interactive Mermaid ER diagram directly inside your GitHub repository.']
        }
      ],
      resumeStarBullet: 'Architected a multi-tenant SaaS project platform in Next.js 15 with Server Actions and optimistic drag-and-drop, utilizing fractional order indexing to reduce card reorder DB latency by 90% and securing 100% tenant isolation.',
      interviewQuestions: [
        {
          question: 'How did you handle race conditions or network failures during optimistic drag-and-drop updates?',
          recruiterIntent: 'Checks if candidate understands rollback strategies and state consistency.',
          answerStrategy: 'Explain React 19 useOptimistic where local UI state displays the predicted order immediately, while the Server Action executes in the background. If the server throws an error, the optimistic state automatically discards the pending transition and reverts to the committed snapshot.'
        },
        {
          question: 'Why did you use fractional indexing instead of integer index updates for ordering?',
          recruiterIntent: 'Tests database scalability thinking and understanding of algorithmic costs.',
          answerStrategy: 'Explain that integer ordering requires updating N rows in the database whenever a task is moved to the top of a column, causing lock contention and high write loads. Fractional indexing computes a midpoint value between the two adjacent cards, requiring only a single row UPDATE operation (O(1)).'
        }
      ],
      githubTemplateHint: 'Includes /app/(dashboard), /actions/tasks.ts, /lib/stripe.ts, /prisma/schema.prisma, and /tests/e2e'
    },
    {
      id: 'react-p3-fintech',
      coDomainName: 'React & Next.js UI Architecture',
      stream: 'Computer Science',
      tier: 'scalable',
      tierLabel: 'Tier 3: Scalable High-Concurrency',
      title: 'High-Frequency Financial Ticker & Live Orderbook Terminal',
      tagline: 'Sub-50ms WebSocket streaming orderbook terminal with web worker offloading and canvas rendering.',
      description: 'A Bloomberg/Binance style financial trading dashboard handling 5,000+ WebSocket message ticks per second. Utilizes Web Workers to parse and aggregate binary market depth feeds off the main thread, rendering live candlestick charts via Canvas API.',
      difficulty: 'Flagship Production',
      estimatedDuration: '4 Weeks (36 hrs total)',
      totalEstimatedHours: 36,
      recruiterAppeal: 'Proves the candidate can build interfaces that push browser performance limits. Highly prized by FinTech firms, trading desks, and high-scale real-time SaaS teams.',
      techStack: {
        frontend: ['React 19', 'Next.js 15', 'TypeScript', 'Web Workers', 'OffscreenCanvas'],
        backend: ['FastAPI / Node.js Mock Exchange Feed', 'WebSockets'],
        tools: ['Chrome Performance Profiler', 'ArrayBuffers', 'TypedArrays']
      },
      keyFeatures: [
        '5,000+ ticks/sec WebSocket ingestion with zero UI frame drops',
        'Web Worker offloading for orderbook aggregation and spread calculation',
        'Dual-buffered Canvas candlestick chart with custom RSI / MACD indicators',
        'Visual trade execution simulator with slippage and fee calculations',
        'Zero garbage collection pressure using pre-allocated TypedArrays'
      ],
      architecturePattern: 'Worker-Threaded Data Pipeline with Canvas Dual-Buffering',
      buildRoadmap: [
        {
          stepNumber: 1,
          phaseName: 'Phase 1: WebSocket Pipeline & Web Worker',
          title: 'Off-Thread Market Ingestion with Web Workers',
          focus: 'Parsing and sorting bid/ask depth data without blocking the browser main thread.',
          estimatedHours: 8,
          deliverable: 'Web Worker receiving binary WebSocket packets and sending 60fps batched snapshots.',
          architectureFocus: 'Transferable objects (ArrayBuffer) to avoid structured cloning overhead.',
          tasks: [
            { id: 'react-p3-s1-t1', title: 'Dedicated Web Worker Worker Thread', description: 'Initialize market-worker.ts to handle WebSocket connection and binary message decoding.', estimatedHours: 3 },
            { id: 'react-p3-s1-t2', title: 'Red-Black Tree Orderbook Depth', description: 'Maintain sorted order book for bids (desc) and asks (asc) with O(log N) price updates.', estimatedHours: 3 },
            { id: 'react-p3-s1-t3', title: '60 FPS PostMessage Throttling', description: 'Accumulate raw ticks and dispatch aggregated depth state to main thread at 16ms intervals.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Calling postMessage for every individual tick causing message queue congestion.'],
          proTips: ['Throttle worker updates to requestAnimationFrame ticks so the UI thread renders at its native refresh rate.']
        },
        {
          stepNumber: 2,
          phaseName: 'Phase 2: OffscreenCanvas Charting Engine',
          title: 'High-Performance Candlestick & Volume Canvas',
          focus: 'Rendering hundreds of candles, grid lines, and crosshairs with sub-2ms draw cycles.',
          estimatedHours: 8,
          deliverable: 'Interactive candlestick chart with mouse hover crosshair and dynamic price scaling.',
          architectureFocus: 'Dual-buffer canvas pattern: render background grid once, draw candles on foreground.',
          tasks: [
            { id: 'react-p3-s2-t1', title: 'Dynamic Price Scale & Y-Axis Math', description: 'Calculate min/max bounds and tick interval intervals based on visible timeframe.', estimatedHours: 3 },
            { id: 'react-p3-s2-t2', title: 'Candle & Volume Bar Drawing Routine', description: 'Render green/red candle bodies, wicks, and volume histograms via Canvas 2D context.', estimatedHours: 3 },
            { id: 'react-p3-s2-t3', title: 'Crosshair Overlay & Coordinate Magnet', description: 'Snap crosshair line to candle close prices with dynamic tooltips.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Re-creating Canvas rendering contexts on every frame instead of reusing existing context.'],
          proTips: ['Use ctx.beginPath() and batch all similar-colored paths into a single ctx.stroke() call.']
        },
        {
          stepNumber: 3,
          phaseName: 'Phase 3: Live Orderbook Heatmap UI',
          title: 'Bids vs Asks Depth Ladder with Animated Flash',
          focus: 'Visualizing depth bars with background fills representing cumulative volume.',
          estimatedHours: 7,
          deliverable: 'Animated DOM/Canvas depth ladder showing live price shifts and size fluctuations.',
          architectureFocus: 'CSS will-change transforms or memoized virtual table for price rows.',
          tasks: [
            { id: 'react-p3-s3-t1', title: 'Cumulative Depth Volume Aggregator', description: 'Compute rolling cumulative sum of shares up to the 50th depth level.', estimatedHours: 2.5 },
            { id: 'react-p3-s3-t2', title: 'Relative Depth Bar Fill Percentage', description: 'Render background horizontal bar relative to largest cumulative volume on screen.', estimatedHours: 2 },
            { id: 'react-p3-s3-t3', title: 'Price Flash Animation System', description: 'Flash row background green/red briefly when trades occur at specific price points.', estimatedHours: 2.5 }
          ],
          pitfallsToAvoid: ['Triggering layout reflows during rapid price flashes by mutating inline CSS classes.'],
          proTips: ['Use opacity transitions and CSS custom properties (--flash-color) to run on the GPU compositor.']
        },
        {
          stepNumber: 4,
          phaseName: 'Phase 4: Trading Simulator & Order Execution',
          title: 'Order Placement Engine & Portfolio Accounting',
          focus: 'Simulating market, limit, and stop orders with realistic slippage against live orderbook.',
          estimatedHours: 7,
          deliverable: 'Buy/Sell order form with instant balance deduction, open order tracking, and P&L.',
          architectureFocus: 'Client-side order matching simulation against incoming trade tape.',
          tasks: [
            { id: 'react-p3-s4-t1', title: 'Order Execution Matching Logic', description: 'Match market orders against top of the book and fill limit orders when price crosses.', estimatedHours: 2.5 },
            { id: 'react-p3-s4-t2', title: 'Unrealized & Realized P&L Tracker', description: 'Compute marked-to-market position value and weighted average entry prices.', estimatedHours: 2.5 },
            { id: 'react-p3-s4-t3', title: 'Audio & Visual Execution Signals', description: 'Add optional synthetic Web Audio API ping sound upon order fill.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Floating point precision bugs in monetary arithmetic (e.g. 0.1 + 0.2 = 0.30000000000000004).'],
          proTips: ['Store all prices and quantities as integer cents/satoshis or use a BigNumber library.']
        },
        {
          stepNumber: 5,
          phaseName: 'Phase 5: Performance Profiling & Documentation',
          title: 'Chrome DevTools Profiling, FPS Guarantee & Deployment',
          focus: 'Validating zero memory leaks and consistent 60 FPS under extreme 10,000 tick stress test.',
          estimatedHours: 6,
          deliverable: 'Published terminal demo on Vercel with automated test suite and recorded performance profile.',
          architectureFocus: 'Heap snapshot comparison to ensure zero garbage collection pauses.',
          tasks: [
            { id: 'react-p3-s5-t1', title: 'Memory Leak & Heap Audit', description: 'Record 10-minute Chrome heap profile to confirm event listeners and buffers are freed.', estimatedHours: 2 },
            { id: 'react-p3-s5-t2', title: 'Mock WebSocket Stress Test Generator', description: 'Create high-volume mock data generator streaming 10,000 messages/second.', estimatedHours: 2 },
            { id: 'react-p3-s5-t3', title: 'Architecture Case Study README', description: 'Write deep architectural breakdown detailing thread communication and canvas pipelines.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Not closing WebSocket connections and worker threads on React component unmount.'],
          proTips: ['Include the Chrome DevTools 60 FPS performance trace screenshot right at the top of your GitHub README.']
        }
      ],
      resumeStarBullet: 'Engineered a high-frequency live trading terminal in React 19 and Web Workers that ingests 5,000+ WebSocket ticks/sec, offloading orderbook aggregation off the main thread and rendering 60 FPS Canvas charts with zero GC lag.',
      interviewQuestions: [
        {
          question: 'Why did you move orderbook processing into a Web Worker instead of running it on the main thread?',
          recruiterIntent: 'Checks understanding of the JavaScript event loop, single-threaded bottlenecks, and concurrency.',
          answerStrategy: 'Explain that parsing high-frequency JSON/binary WebSocket packets and sorting 50+ depth levels every few milliseconds blocks the browser main thread, causing frame drops and unresponsive user clicks. Offloading to a Web Worker processes the raw math independently and emits throttled 60 FPS snapshots via postMessage.'
        },
        {
          question: 'How did you avoid memory leaks and garbage collection stutters when receiving thousands of messages per second?',
          recruiterIntent: 'Proves advanced knowledge of V8 memory management and object allocation.',
          answerStrategy: 'Describe object pooling and using pre-allocated TypedArrays (Float64Array) to update values in-place rather than instantiating thousands of ephemeral JavaScript objects every second, which prevents GC pause spikes.'
        }
      ],
      githubTemplateHint: 'Includes /workers/marketWorker.ts, /canvas/candlestickRenderer.ts, and /hooks/useOrderbookStream.ts'
    },
    {
      id: 'react-p4-ai',
      coDomainName: 'React & Next.js UI Architecture',
      stream: 'Computer Science',
      tier: 'flagship',
      tierLabel: 'Tier 4: Flagship AI & Production Capstone',
      title: 'AI Multi-Agent Research Assistant & Knowledge Synthesis Canvas',
      tagline: 'Multi-modal research workbench with streaming LLM generation, vector memory, and voice synthesis.',
      description: 'An AI-powered copilot workspace that searches documents, synthesizes research briefs, and drafts structured reports. Features streaming tokens via Server-Sent Events, interactive citation cards, and markdown rendering with live diagram generation.',
      difficulty: 'Flagship Production',
      estimatedDuration: '4 Weeks (40 hrs total)',
      totalEstimatedHours: 40,
      recruiterAppeal: 'The pinnacle of modern engineering hiring: demonstrates real AI/LLM integration with clean UI ergonomics, robust streaming error handling, and production-grade state synchronization.',
      techStack: {
        frontend: ['Next.js 15 (App Router)', 'React 19', 'TypeScript', 'Tailwind CSS', 'Vercel AI SDK'],
        backend: ['FastAPI / Next.js Edge Routes', 'LangChain / LlamaIndex'],
        database: ['Pinecone / pgvector (PostgreSQL)', 'Redis (Rate Limiting)'],
        aiLibraries: ['OpenAI / Gemini API', 'Whisper Web Speech API', 'Mermaid.js']
      },
      keyFeatures: [
        'Streaming Server-Sent Events (SSE) with token-by-token markdown rendering',
        'Interactive citation badges linking to exact PDF source chunks',
        'Dynamic Mermaid diagram and table generation from natural language prompts',
        'Voice conversation mode with live speech-to-text and low-latency audio response',
        'Document RAG upload (PDF/DOCX) with client-side chunking and embedding status'
      ],
      architecturePattern: 'Asynchronous Streaming RAG Pipeline with Edge-Terminated LLM Gateways',
      buildRoadmap: [
        {
          stepNumber: 1,
          phaseName: 'Phase 1: Streaming Architecture & Vercel AI SDK',
          title: 'Streaming SSE Pipeline & Token Parser',
          focus: 'Building resilient token streaming with instant user stop/abort controls.',
          estimatedHours: 8,
          deliverable: 'Chat interface with streaming AI responses, auto-scrolling, and abort controllers.',
          architectureFocus: 'Edge runtime route handlers with ReadableStream and Server-Sent Events.',
          tasks: [
            { id: 'react-p4-s1-t1', title: 'Next.js Edge Route for LLM Streaming', description: 'Configure edge route streaming OpenAI / Gemini tokens via Vercel AI SDK.', estimatedHours: 3 },
            { id: 'react-p4-s1-t2', title: 'Token-by-Token Markdown Parser', description: 'Render incoming tokens safely with code syntax highlighting and copy-code buttons.', estimatedHours: 3 },
            { id: 'react-p4-s1-t3', title: 'Smooth Auto-Scroll with User Lock', description: 'Scroll to bottom automatically unless user actively scrolls up to read history.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Re-parsing entire markdown document on every single streaming token causing CPU spikes.'],
          proTips: ['Use memoized streaming markdown parsers that only render new tokens into the active block.']
        },
        {
          stepNumber: 2,
          phaseName: 'Phase 2: Document RAG & Vector Embeddings',
          title: 'PDF Document Ingestion & Chunk Retrieval',
          focus: 'Enabling users to upload research papers and ground AI responses with verified citations.',
          estimatedHours: 8,
          deliverable: 'File uploader with chunking progress bar and Pinecone / pgvector similarity search.',
          architectureFocus: 'Hybrid keyword (BM25) and semantic vector similarity search for high precision.',
          tasks: [
            { id: 'react-p4-s2-t1', title: 'Client-Side PDF Text Extraction', description: 'Extract page-by-page text using pdfjs-dist with metadata preservation.', estimatedHours: 2.5 },
            { id: 'react-p4-s2-t2', title: 'Vector Embedding Generation Pipeline', description: 'Chunk text into 500-token blocks with 50-token overlap and generate embeddings.', estimatedHours: 3 },
            { id: 'react-p4-s2-t3', title: 'Context Injection & Citation Tagging', description: 'Inject top 4 retrieved chunks into system prompt with [1], [2] citation markers.', estimatedHours: 2.5 }
          ],
          pitfallsToAvoid: ['Uploading full 100-page raw text into the LLM context window exceeding token limits.'],
          proTips: ['Display hovering preview popovers when users hover over citation [1] badges showing the exact source snippet.']
        },
        {
          stepNumber: 3,
          phaseName: 'Phase 3: Interactive Artifacts & Canvas Export',
          title: 'Dynamic Code & Mermaid Diagram Artifacts',
          focus: 'Rendering interactive diagrams, tables, and sandbox previews in a split-screen canvas.',
          estimatedHours: 8,
          deliverable: 'Split-view workspace with Claude Artifacts style preview panel for diagrams and tables.',
          architectureFocus: 'Safe isolated iframe or sandboxed DOM rendering for generated HTML/Mermaid.',
          tasks: [
            { id: 'react-p4-s3-t1', title: 'Artifact Detection & Split-Pane Layout', description: 'Detect ```mermaid or ```html blocks in streaming responses and route to preview panel.', estimatedHours: 3 },
            { id: 'react-p4-s3-t2', title: 'Live Mermaid.js Diagram Render Engine', description: 'Parse mermaid syntax on the fly and render zoomable/pannable SVG flowcharts.', estimatedHours: 2.5 },
            { id: 'react-p4-s3-t3', title: 'Export to PDF & Markdown Document', description: 'Generate polished downloadable research summary documents with executive summaries.', estimatedHours: 2.5 }
          ],
          pitfallsToAvoid: ['Crashing the UI when LLM generates invalid or incomplete Mermaid syntax during streaming.'],
          proTips: ['Catch Mermaid parse exceptions with an Error Boundary and show an animated "Synthesizing diagram..." loader.']
        },
        {
          stepNumber: 4,
          phaseName: 'Phase 4: Voice Interactivity & Audio Synthesis',
          title: 'Real-Time Voice Assistant with Web Speech API',
          focus: 'Hands-free voice consultation with automatic silence detection and natural speech playback.',
          estimatedHours: 8,
          deliverable: 'Live audio waveform visualizer that records user questions and plays AI voice replies.',
          architectureFocus: 'MediaRecorder API with Web Audio AnalyserNode for audio frequency bars.',
          tasks: [
            { id: 'react-p4-s4-t1', title: 'Audio Waveform Visualizer Component', description: 'Render pulsing glowing circular visualizer using Web Audio API frequency data.', estimatedHours: 2.5 },
            { id: 'react-p4-s4-t2', title: 'Automatic Voice Activity Detection (VAD)', description: 'Detect when user stops speaking for 1.2s and trigger automatic prompt submission.', estimatedHours: 3 },
            { id: 'react-p4-s4-t3', title: 'Text-to-Speech Streaming Synthesis', description: 'Stream AI response chunks into audio player for sub-second voice latency.', estimatedHours: 2.5 }
          ],
          pitfallsToAvoid: ['Echo feedback loops where microphone picks up the speaker output.'],
          proTips: ['Mute the microphone input stream automatically while the assistant is speaking.']
        },
        {
          stepNumber: 5,
          phaseName: 'Phase 5: Production Hardening, Rate Limiting & CI/CD',
          title: 'Redis Token-Bucket Rate Limiter & Cloud Deployment',
          focus: 'Protecting LLM API endpoints from abuse and deploying to production with GitHub Actions.',
          estimatedHours: 8,
          deliverable: 'Production deployment with Redis Upstash rate limiting and automated Vitest suite.',
          architectureFocus: 'Sliding-window rate limiting per IP / User ID to prevent billing exhaustion.',
          tasks: [
            { id: 'react-p4-s5-t1', title: 'Upstash Redis Sliding-Window Limiter', description: 'Limit requests to 10 queries per minute per user with 429 Retry-After headers.', estimatedHours: 2.5 },
            { id: 'react-p4-s5-t2', title: 'Token Usage & Cost Telemetry Dashboard', description: 'Track prompt vs completion token consumption and display usage meter.', estimatedHours: 2.5 },
            { id: 'react-p4-s5-t3', title: 'Production Vercel Deployment & Showcase', description: 'Deploy with edge caching, custom domain, and comprehensive documentation.', estimatedHours: 3 }
          ],
          pitfallsToAvoid: ['Exposing raw OpenAI / Gemini API keys on the frontend or in public GitHub repositories.'],
          proTips: ['Store all LLM keys exclusively in server-side environment variables and proxy all requests through edge routes.']
        }
      ],
      resumeStarBullet: 'Architected an AI research synthesis platform in Next.js 15 & React 19 with streaming RAG citations, processing PDF embeddings via pgvector and reducing time-to-first-token to under 350ms with edge routes.',
      interviewQuestions: [
        {
          question: 'How did you implement streaming responses with Server-Sent Events without breaking markdown formatting?',
          recruiterIntent: 'Checks real-world experience with LLM streaming edge cases and UI rendering performance.',
          answerStrategy: 'Explain utilizing the Vercel AI SDK ReadableStream pipeline over SSE, buffering token deltas into a reactive state accumulator, and using a virtualized markdown parser that avoids re-parsing completed paragraphs when new tokens arrive.'
        },
        {
          question: 'How does your retrieval-augmented generation (RAG) pipeline prevent hallucinated responses?',
          recruiterIntent: 'Tests understanding of grounding, prompt engineering, and similarity thresholding.',
          answerStrategy: 'Describe setting strict cosine similarity thresholds (e.g. > 0.78) during vector retrieval, injecting source citations directly into the prompt context, and instructing the model with explicit guardrails to cite chunk references or state lack of evidence.'
        }
      ],
      githubTemplateHint: 'Includes /app/api/chat/route.ts, /lib/rag.ts, /components/ArtifactPreview.tsx, and /lib/rateLimiter.ts'
    }
  ],

  // --------------------------------------------------------------------------
  // FASTAPI & ASYNC MICROSERVICES
  // --------------------------------------------------------------------------
  'FastAPI & Async Microservices': [
    {
      id: 'fastapi-p1-shortener',
      coDomainName: 'FastAPI & Async Microservices',
      stream: 'Computer Science',
      tier: 'foundational',
      tierLabel: 'Tier 1: High-Throughput Core Service',
      title: 'Async High-Throughput URL Shortener & Analytics Engine',
      tagline: 'Sub-3ms redirect service with Redis caching, Base62 encoding, and geolocation analytics.',
      description: 'A production-grade URL shortening microservice engineered with async FastAPI and Python 3.12. Features non-blocking Redis cache-aside reads, PostgreSQL persistence with Alembic migrations, and background geolocation analytics recording.',
      difficulty: 'Intermediate',
      estimatedDuration: '2 Weeks (20 hrs total)',
      totalEstimatedHours: 20,
      recruiterAppeal: 'Proves mastery of async/await event loops, database connection pooling, Redis caching, and Pydantic v2 validation without relying on bloated full-stack frameworks.',
      techStack: {
        backend: ['FastAPI (Python 3.12)', 'Asyncpg', 'SQLAlchemy 2.0 (Async)', 'Pydantic v2'],
        database: ['PostgreSQL 16', 'Redis (Cache-Aside)'],
        tools: ['Docker Compose', 'Pytest-Asyncio', 'Locust (Load Testing)']
      },
      keyFeatures: [
        'Sub-3ms 301/307 HTTP redirects served directly from in-memory Redis cache',
        'Collision-resistant Base62 shortcode generation from 64-bit integer IDs',
        'Background task analytics capturing user-agent, IP, and referrer without slowing redirects',
        'Custom domain alias support and expiring URLs with TTL eviction',
        'Interactive Swagger OpenAPI documentation with automated schema generation'
      ],
      architecturePattern: 'Cache-Aside Read Architecture with Fire-and-Forget Analytics Workers',
      buildRoadmap: [
        {
          stepNumber: 1,
          phaseName: 'Phase 1: Architecture & Base62 Engine',
          title: 'Async App Scaffolding & Base62 Encoder',
          focus: 'Setting up structured FastAPI project with dependency injection and Base62 logic.',
          estimatedHours: 4,
          deliverable: 'Clean modular repository structure with Pytest test runner and Base62 unit tests.',
          architectureFocus: 'Deterministic mathematical Base62 bijective encoding from sequential IDs.',
          tasks: [
            { id: 'fa-p1-s1-t1', title: 'Modular Folder Structure & Config', description: 'Scaffold app/api, app/core, app/models, app/services with Pydantic BaseSettings.', estimatedHours: 1.5 },
            { id: 'fa-p1-s1-t2', title: 'Bijective Base62 Encoder/Decoder', description: 'Implement zero-collision conversion between 64-bit integer IDs and 7-character shortcodes.', estimatedHours: 1.5 },
            { id: 'fa-p1-s1-t3', title: 'Unit Tests for Base62 Encoding', description: 'Write Pytest suite covering zero, large integers, and boundary cases.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Generating random strings and querying the database in a while loop to check for collisions.'],
          proTips: ['Use auto-incrementing integer IDs or Snowflake IDs encoded to Base62 for guaranteed O(1) uniqueness.']
        },
        {
          stepNumber: 2,
          phaseName: 'Phase 2: Async Database & Migrations',
          title: 'Async SQLAlchemy 2.0 & PostgreSQL Schema',
          focus: 'Connecting asyncpg engine with connection pooling and automated Alembic migrations.',
          estimatedHours: 4,
          deliverable: 'PostgreSQL schema with indexed short_code columns and automated migration scripts.',
          architectureFocus: 'B-tree index on short_code and compound index on (created_at, user_id).',
          tasks: [
            { id: 'fa-p1-s2-t1', title: 'Async Engine & Session Dependency', description: 'Configure async_sessionmaker with connection pool recycle and pre-ping checks.', estimatedHours: 1.5 },
            { id: 'fa-p1-s2-t2', title: 'SQLAlchemy 2.0 Mapped Models', description: 'Create URL and ClickEvent models with foreign keys and cascade delete rules.', estimatedHours: 1.5 },
            { id: 'fa-p1-s2-t3', title: 'Alembic Migration Setup', description: 'Generate and execute initial database migration inside Docker PostgreSQL container.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Using synchronous psycopg2 inside async def route handlers, blocking the event loop.'],
          proTips: ['Always use asyncpg with SQLAlchemy async_engine for high concurrent throughput.']
        },
        {
          stepNumber: 3,
          phaseName: 'Phase 3: Redis Cache-Aside & Redirect Route',
          title: 'Sub-3ms Redis Cache-Aside & 307 Redirects',
          focus: 'Serving hot URLs directly from Redis memory with automatic fallback to PostgreSQL.',
          estimatedHours: 4,
          deliverable: 'Redirect endpoint responding in under 3 milliseconds under concurrent load.',
          architectureFocus: 'Cache-aside pattern: check Redis GET url:{code}; if miss, query DB and SETEX.',
          tasks: [
            { id: 'fa-p1-s3-t1', title: 'Async Redis Client Dependency', description: 'Initialize aioredis / redis-py async client with connection pooling.', estimatedHours: 1.5 },
            { id: 'fa-p1-s3-t2', title: 'Cache-Aside Query Service', description: 'Implement get_original_url with 24-hour TTL caching and cache invalidation on delete.', estimatedHours: 1.5 },
            { id: 'fa-p1-s3-t3', title: 'Fast Redirect Route Handler', description: 'Return RedirectResponse(status_code=307) with cache-control headers.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Using 301 Permanent Redirect without caution (browsers cache 301 forever, bypassing analytics).'],
          proTips: ['Use 307 Temporary Redirect so every click reaches your server to track real-time analytics accurately.']
        },
        {
          stepNumber: 4,
          phaseName: 'Phase 4: Non-Blocking Analytics Pipeline',
          title: 'BackgroundTasks Click Telemetry & IP Geo-Lookup',
          focus: 'Recording click data asynchronously without delaying the user HTTP redirect response.',
          estimatedHours: 4,
          deliverable: 'Analytics endpoint showing total clicks, referrer breakdown, and geographic country counts.',
          architectureFocus: 'FastAPI BackgroundTasks offloading click persistence after response headers are sent.',
          tasks: [
            { id: 'fa-p1-s4-t1', title: 'Background Click Logger Task', description: 'Parse Request headers (User-Agent, Referer, Client IP) in background coroutine.', estimatedHours: 1.5 },
            { id: 'fa-p1-s4-t2', title: 'GeoIP Country Resolution', description: 'Resolve IP address to country and city using local MaxMind GeoLite database.', estimatedHours: 1.5 },
            { id: 'fa-p1-s4-t3', title: 'Aggregated Analytics SQL Endpoint', description: 'Write SQL query with date truncation and group-by to return hourly click counts.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Performing blocking external HTTP API calls inside the redirect request handler.'],
          proTips: ['Use FastAPI BackgroundTasks or Redis Streams so database writes never delay redirect latencies.']
        },
        {
          stepNumber: 5,
          phaseName: 'Phase 5: Load Testing & Dockerization',
          title: 'Locust 2,000 RPS Benchmark & Docker Compose',
          focus: 'Proving system resilience under heavy concurrency with Locust load generation.',
          estimatedHours: 4,
          deliverable: 'Docker Compose configuration running app, Redis, and Postgres, with verified 2,000 RPS.',
          architectureFocus: 'Multi-worker Uvicorn deployment behind Nginx reverse proxy.',
          tasks: [
            { id: 'fa-p1-s5-t1', title: 'Multi-Stage Dockerfile', description: 'Build slim 80MB Python 3.12 Docker image with non-root security user.', estimatedHours: 1.5 },
            { id: 'fa-p1-s5-t2', title: 'Locust Concurrent Load Test Script', description: 'Simulate 500 concurrent users performing 2,000 redirects/sec with < 5ms p99 latency.', estimatedHours: 1.5 },
            { id: 'fa-p1-s5-t3', title: 'GitHub Actions Automated Testing Pipeline', description: 'Run flake8 linting, safety security checks, and Pytest coverage in CI.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Running Uvicorn with a single worker in production instead of matching available CPU cores.'],
          proTips: ['Include your Locust latency percentiles chart (p50, p95, p99) right inside your GitHub README.']
        }
      ],
      resumeStarBullet: 'Engineered an async URL shortener in FastAPI & Redis handling 2,500+ requests/sec with sub-3ms p95 latency, implementing non-blocking background telemetry and Base62 encoding with zero key collisions.',
      interviewQuestions: [
        {
          question: 'Why did you use Base62 encoding instead of a hash function like MD5 or SHA256?',
          recruiterIntent: 'Checks understanding of collision domains, hash truncation risks, and URL safety.',
          answerStrategy: 'Explain that truncating an MD5/SHA256 hash to 6 or 7 characters creates a high risk of collisions (Birthday Paradox). Converting sequential 64-bit database IDs into Base62 characters ([0-9, a-z, A-Z]) is a bijective mapping with zero collisions and generates clean, URL-safe short strings.'
        },
        {
          question: 'How did you ensure click analytics did not add latency to the user redirect?',
          recruiterIntent: 'Tests understanding of non-blocking I/O and asynchronous request lifecycles.',
          answerStrategy: 'Explain using FastAPI BackgroundTasks, which immediately dispatches the 307 Redirect HTTP response headers over the wire, and then executes the analytics logging coroutine asynchronously before closing the connection.'
        }
      ],
      githubTemplateHint: 'Includes /app/main.py, /app/api/v1/endpoints/urls.py, /docker-compose.yml, and /locustfile.py'
    },
    {
      id: 'fastapi-p2-agent',
      coDomainName: 'FastAPI & Async Microservices',
      stream: 'Computer Science',
      tier: 'flagship',
      tierLabel: 'Tier 4: Distributed AI Microservice',
      title: 'Distributed Autonomous AI Agent & Tool Execution Orchestrator',
      tagline: 'Async microservice with Redis message queues, sandbox tool execution, and streaming SSE tokens.',
      description: 'An enterprise microservice engine for running multi-step AI agents. Features async Celery/Redis background task queues, sandboxed Python code execution environments, tool registry with OpenAPI schema reflection, and real-time Server-Sent Events streaming.',
      difficulty: 'Flagship Production',
      estimatedDuration: '4 Weeks (36 hrs total)',
      totalEstimatedHours: 36,
      recruiterAppeal: 'Demonstrates modern agentic architecture: combining FastAPI async microservices, distributed queues, security sandboxing, and LLM tool calling.',
      techStack: {
        backend: ['FastAPI', 'Celery / ARQ', 'Redis', 'Python 3.12', 'Pydantic v2'],
        aiLibraries: ['LangChain Core', 'OpenAI Function Calling', 'Tavily Search API'],
        cloudDevOps: ['Docker Sandbox', 'PostgreSQL', 'Prometheus Metrics']
      },
      keyFeatures: [
        'Dynamic tool execution framework with Pydantic runtime parameter validation',
        'Isolated Docker execution sandbox for safe untrusted Python code execution',
        'Distributed task queue (ARQ / Celery) with Redis state persistence',
        'Streaming execution traces via Server-Sent Events (SSE) with live step progress',
        'Token budgeting and maximum loop guardrails preventing infinite recursion'
      ],
      architecturePattern: 'Event-Driven Distributed Agent Architecture with Sandboxed Execution Pools',
      buildRoadmap: [
        {
          stepNumber: 1,
          phaseName: 'Phase 1: Agent State Machine & Pydantic Contracts',
          title: 'Agent State Machine & Tool Registry',
          focus: 'Designing typed agent state, conversation memory, and reflection tool decorators.',
          estimatedHours: 7,
          deliverable: 'Typed AgentState Pydantic model and @tool decorator auto-generating JSON schemas.',
          architectureFocus: 'Pydantic v2 BaseModel with model_json_schema() for LLM tool function calling.',
          tasks: [
            { id: 'fa-p2-s1-t1', title: 'AgentState & Message Schema Design', description: 'Define structured message history supporting user, assistant, and tool call outputs.', estimatedHours: 2.5 },
            { id: 'fa-p2-s1-t2', title: '@tool Decorator & Schema Reflection', description: 'Build decorator inspecting function docstrings and type annotations to generate OpenAI schemas.', estimatedHours: 2.5 },
            { id: 'fa-p2-s1-t3', title: 'Tool Registry & Dispatcher Engine', description: 'Implement O(1) tool lookup registry with argument deserialization and validation.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Passing unvalidated tool inputs to execution engines resulting in command injection vulnerabilities.'],
          proTips: ['Use Pydantic v2 for 5x-10x faster schema validation and automatic JSON Schema generation.']
        },
        {
          stepNumber: 2,
          phaseName: 'Phase 2: Isolated Code Execution Sandbox',
          title: 'Docker Sandboxed Python Runner',
          focus: 'Safely running arbitrary Python code generated by the LLM without endangering the host.',
          estimatedHours: 8,
          deliverable: 'Sandboxed code execution service with CPU, memory, and network isolation limits.',
          architectureFocus: 'Ephemeral Docker container or gVisor sandbox with 5-second execution timeouts.',
          tasks: [
            { id: 'fa-p2-s2-t1', title: 'Docker Client Sandbox Manager', description: 'Spin up disposable alpine-python containers with --network=none and read-only filesystems.', estimatedHours: 3 },
            { id: 'fa-p2-s2-t2', title: 'Resource Quotas & Timeout Killers', description: 'Enforce 256MB RAM cap, 1 CPU core limit, and SIGKILL termination after 5 seconds.', estimatedHours: 2.5 },
            { id: 'fa-p2-s2-t3', title: 'Standard Out & Exception Capture', description: 'Capture stdout, stderr, and tracebacks safely to return clean error messages to agent.', estimatedHours: 2.5 }
          ],
          pitfallsToAvoid: ['Using eval() or exec() directly inside the main application process.'],
          proTips: ['Never run untrusted code with host networking; always configure network=none on container runners.']
        },
        {
          stepNumber: 3,
          phaseName: 'Phase 3: Redis Distributed Queue & Worker',
          title: 'Async Job Queue (ARQ) & Progress Tracking',
          focus: 'Offloading long-running agent reasoning loops to distributed background workers.',
          estimatedHours: 7,
          deliverable: 'Job submission endpoint returning taskId, with background worker updating state.',
          architectureFocus: 'Redis-backed asynchronous job queue with atomic state transitions.',
          tasks: [
            { id: 'fa-p2-s3-t1', title: 'ARQ / Celery Worker Configuration', description: 'Configure async worker pool consuming tasks from Redis with exponential backoff.', estimatedHours: 2.5 },
            { id: 'fa-p2-s3-t2', title: 'Task State Machine & Redis Storage', description: 'Store job status (PENDING, RUNNING, STEP_COMPLETE, FAILED, DONE) in Redis hashes.', estimatedHours: 2.5 },
            { id: 'fa-p2-s3-t3', title: 'Max-Step Loop & Token Guardrails', description: 'Abort execution if agent reaches 10 iterations or exceeds 8,000 token allowance.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Holding open HTTP connections while an agent runs a 60-second multi-step research loop.'],
          proTips: ['Always decouple long-running operations into a job ID pattern (POST /jobs -> GET /jobs/{id}).']
        },
        {
          stepNumber: 4,
          phaseName: 'Phase 4: Streaming Telemetry via SSE',
          title: 'Server-Sent Events (SSE) Live Execution Stream',
          focus: 'Streaming live agent thoughts, tool invocations, and answers directly to clients.',
          estimatedHours: 7,
          deliverable: 'SSE endpoint streaming JSON events for agent steps: "Calling Search", "Executing Code", etc.',
          architectureFocus: 'Redis Pub/Sub broadcasting worker events to FastAPI EventSourceResponse stream.',
          tasks: [
            { id: 'fa-p2-s4-t1', title: 'Redis Pub/Sub Event Channel', description: 'Publish step event payloads to Redis channel agent:events:{task_id}.', estimatedHours: 2.5 },
            { id: 'fa-p2-s4-t2', title: 'FastAPI EventSourceResponse Stream', description: 'Yield SSE formatted messages to connected web clients with heartbeat keep-alive.', estimatedHours: 2.5 },
            { id: 'fa-p2-s4-t3', title: 'Client Reconnect & State Replay', description: 'Store past step history so clients that reconnect mid-run receive missed events.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Allowing SSE connections to drop silently on corporate proxies without periodic :ping keep-alive frames.'],
          proTips: ['Send a comment ping every 15 seconds to keep proxies and cloud load balancers from terminating the stream.']
        },
        {
          stepNumber: 5,
          phaseName: 'Phase 5: Observability, Metrics & Docker Compose',
          title: 'Prometheus Metrics, Health Probes & Deployment',
          focus: 'Adding real-time Prometheus telemetry tracking agent latency, tool success rates, and token cost.',
          estimatedHours: 7,
          deliverable: 'Complete docker-compose stack with FastAPI app, ARQ workers, Redis, and Prometheus metrics.',
          architectureFocus: 'Prometheus counter and histogram metrics exposed on /metrics endpoint.',
          tasks: [
            { id: 'fa-p2-s5-t1', title: 'Prometheus Instrumentation', description: 'Add prometheus-fastapi-instrumentator tracking request duration, tool calls, and error rates.', estimatedHours: 2.5 },
            { id: 'fa-p2-s5-t2', title: 'Kubernetes Liveness & Readiness Probes', description: 'Implement /health/live and /health/ready verifying database and Redis connectivity.', estimatedHours: 2 },
            { id: 'fa-p2-s5-t3', title: 'Docker Compose Orchestration Stack', description: 'Orchestrate API gateway, workers, Redis, Postgres, and sandbox container network.', estimatedHours: 2.5 }
          ],
          pitfallsToAvoid: ['Failing health checks when external APIs (e.g. OpenAI) have brief transient outages.'],
          proTips: ['Separate readiness (checks internal DB/Redis) from external dependency status to prevent restart loops.']
        }
      ],
      resumeStarBullet: 'Engineered an asynchronous multi-agent orchestrator in FastAPI & Redis, implementing sandboxed Docker tool execution and SSE streaming that supported 20+ concurrent multi-step agent runs with zero security breaches.',
      interviewQuestions: [
        {
          question: 'How did you prevent infinite loops when the agent got stuck repeating the same tool call?',
          recruiterIntent: 'Checks understanding of agent failure modes, cycle detection, and production guardrails.',
          answerStrategy: 'Explain implementing a finite state machine with a maximum step limit (e.g. 10 steps), tracking consecutive identical tool calls using message history hashes, and injecting an explicit reflection prompt when duplicate calls are detected.'
        },
        {
          question: 'How did you ensure security when executing untrusted Python code generated by the LLM?',
          recruiterIntent: 'Tests understanding of security sandboxing, container isolation, and resource quotas.',
          answerStrategy: 'Detail running code inside disposable ephemeral Docker containers with dropped Linux capabilities, --network=none to prevent exfiltration, 256MB memory ceilings, read-only root filesystems, and strict 5-second SIGKILL process timers.'
        }
      ],
      githubTemplateHint: 'Includes /app/agent/orchestrator.py, /app/sandbox/dockerRunner.py, /app/workers/arqWorker.py, and /docker-compose.yml'
    }
  ],

  // --------------------------------------------------------------------------
  // DATA STRUCTURES & ALGORITHMS (DSA)
  // --------------------------------------------------------------------------
  'Data Structures & Algorithms (DSA)': [
    {
      id: 'dsa-p1-visualizer',
      coDomainName: 'Data Structures & Algorithms (DSA)',
      stream: 'Computer Science',
      tier: 'foundational',
      tierLabel: 'Tier 1: Algorithmic Architecture',
      title: 'Interactive Algorithm Visualizer & Memory Heatmap Engine',
      tagline: 'Step-by-step interactive visualizer for Graph Traversal (Dijkstra, A*), Trees, and Dynamic Programming.',
      description: 'A visual computer science tool built to demonstrate deep algorithmic mechanics. Renders step-by-step state machines for pathfinding, Red-Black tree rebalancing rotations, and 2D DP matrix filling with live time and space complexity counters.',
      difficulty: 'Intermediate',
      estimatedDuration: '2 Weeks (20 hrs total)',
      totalEstimatedHours: 20,
      recruiterAppeal: 'Recruiters immediately see that you understand underlying algorithmic logic, recursion call stacks, and pointer manipulations rather than just memorizing LeetCode solutions.',
      techStack: {
        frontend: ['TypeScript', 'React 19', 'Canvas API / SVG', 'Tailwind CSS'],
        tools: ['Vitest', 'Web Workers']
      },
      keyFeatures: [
        'Interactive weighted grid for Dijkstra, A* (heuristic), and BFS/DFS with wall placement',
        'Self-balancing Red-Black and AVL Tree visualizer with left/right rotation animations',
        'Dynamic Programming 2D memoization matrix fill visualizer (Knapsack, LCS, Edit Distance)',
        'Play, pause, step-forward, step-backward time-travel controls',
        'Real-time Big-O time and space operational counter during execution'
      ],
      architecturePattern: 'Generator Pattern with Reversible State Snapshots',
      buildRoadmap: [
        {
          stepNumber: 1,
          phaseName: 'Phase 1: Generator Engine & State Snapshots',
          title: 'JavaScript Generator Functions & Frame Recording',
          focus: 'Using ES6 generator functions (yield) to pause and step through algorithms frame-by-frame.',
          estimatedHours: 4,
          deliverable: 'Reusable step-engine recording immutable algorithmic states at each yield.',
          architectureFocus: 'Algorithms yield discrete state snapshots { visitedNodes, currentPointer, costTable }.',
          tasks: [
            { id: 'dsa-p1-s1-t1', title: 'Generator-Driven Algorithm Runner', description: 'Wrap graph traversal inside generator function yielding at each node expansion.', estimatedHours: 1.5 },
            { id: 'dsa-p1-s1-t2', title: 'Snapshot History & Scrubbing Controller', description: 'Store frames in array enabling forward play, pause, and scrubber scrubbing.', estimatedHours: 1.5 },
            { id: 'dsa-p1-s1-t3', title: 'Playhead Speed & Timer Controller', description: 'Build adjustable playback speed (10ms to 1000ms delay per step).', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Mutating object references in state snapshots, causing past steps to reflect current values.'],
          proTips: ['Shallow-clone active node sets at each yield step to guarantee immutable historical frames.']
        },
        {
          stepNumber: 2,
          phaseName: 'Phase 2: Graph Pathfinding Visualizer',
          title: 'Dijkstra, A* & Heuristic Traversal Grid',
          focus: 'Building 2D grid with start/target nodes, weighted terrain, and shortest-path backtracing.',
          estimatedHours: 4,
          deliverable: 'Grid where users drag obstacles and watch priority queue node expansions in real time.',
          architectureFocus: 'Min-Heap Priority Queue implementation in TypeScript with O(log N) extract-min.',
          tasks: [
            { id: 'dsa-p1-s2-t1', title: 'Binary Min-Heap Priority Queue', description: 'Implement custom generic MinHeap class with bubbleUp and sinkDown methods.', estimatedHours: 1.5 },
            { id: 'dsa-p1-s2-t2', title: 'A* Pathfinding with Manhattan Heuristic', description: 'Calculate f(n) = g(n) + h(n) scoring with wall avoidance and diagonal options.', estimatedHours: 1.5 },
            { id: 'dsa-p1-s2-t3', title: 'Backtracking Shortest Path Animator', description: 'Trace parent pointers from destination back to origin with glowing path animation.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Using Array.sort() on every iteration instead of a Min-Heap, degrading Dijkstra from O(E log V) to O(E * V log V).'],
          proTips: ['Include an obstacle maze generator using Recursive Division algorithm for instant testing.']
        },
        {
          stepNumber: 3,
          phaseName: 'Phase 3: Self-Balancing Binary Search Trees',
          title: 'AVL & Red-Black Tree Rebalancing Rotations',
          focus: 'Visualizing pointer re-linking during Left-Left, Right-Right, and double rotations.',
          estimatedHours: 4,
          deliverable: 'Interactive tree where inserting numbers shows rebalancing rotations with color coding.',
          architectureFocus: 'Recursive tree layout algorithm calculating (x, y) coordinates with node spacing.',
          tasks: [
            { id: 'dsa-p1-s3-t1', title: 'AVL Tree Rotation Math & Node Positioning', description: 'Implement balance factor tracking and left/right rotation algorithms.', estimatedHours: 1.5 },
            { id: 'dsa-p1-s3-t2', title: 'SVG Tree Edge Curve Renderer', description: 'Render smooth cubic bezier curves connecting parent and child nodes dynamically.', estimatedHours: 1.5 },
            { id: 'dsa-p1-s3-t3', title: 'Red-Black Tree Color Inversion Rules', description: 'Visualize uncle node recoloring and black-height invariant preservation.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Overlapping child node coordinates as tree depth increases.'],
          proTips: ['Use Reingold-Tilford tidy tree layout algorithm for clean, non-overlapping tree diagrams.']
        },
        {
          stepNumber: 4,
          phaseName: 'Phase 4: Dynamic Programming Matrix Heatmap',
          title: '2D DP Grid Fill & State Transitions',
          focus: 'Visualizing 2D memoization tables for 0/1 Knapsack, Longest Common Subsequence, and Edit Distance.',
          estimatedHours: 4,
          deliverable: 'Grid matrix highlighting predecessor cells that contribute to the current subproblem solution.',
          architectureFocus: 'Color gradient heatmap reflecting matrix cell values and active recurrence dependencies.',
          tasks: [
            { id: 'dsa-p1-s4-t1', title: '0/1 Knapsack Recurrence Step Engine', description: 'Step through dp[i][w] = max(dp[i-1][w], val + dp[i-1][w-wt]) with visual pointer arrows.', estimatedHours: 1.5 },
            { id: 'dsa-p1-s4-t2', title: 'Levenshtein Edit Distance Matrix', description: 'Fill matrix comparing two strings with insert, delete, and replace operation highlights.', estimatedHours: 1.5 },
            { id: 'dsa-p1-s4-t3', title: 'Optimal Path Reconstruction Backtracker', description: 'Highlight exact cells in the completed table that produce the optimal solution.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Showing final matrix without demonstrating how previous row/column cells computed it.'],
          proTips: ['Draw glowing arrows pointing from predecessor subproblem cells to the active cell being computed.']
        },
        {
          stepNumber: 5,
          phaseName: 'Phase 5: Performance & GitHub Deployment',
          title: 'Web Worker Offloading & GitHub Pages Deployment',
          focus: 'Ensuring complex maze solving never locks the UI by running graph logic in Web Workers.',
          estimatedHours: 4,
          deliverable: 'Fast, responsive web app deployed to GitHub Pages / Vercel with zero input latency.',
          architectureFocus: 'Offload heavy maze calculations and pathfinding searches to Web Worker.',
          tasks: [
            { id: 'dsa-p1-s5-t1', title: 'Web Worker Computation Thread', description: 'Move pathfinding iterations to worker thread, streaming batched steps to main UI.', estimatedHours: 1.5 },
            { id: 'dsa-p1-s5-t2', title: 'Vitest Algorithmic Correctness Suite', description: 'Verify MinHeap, A*, and AVL tree implementations with 100% test coverage.', estimatedHours: 1.5 },
            { id: 'dsa-p1-s5-t3', title: 'Documentation & Algorithmic Analysis', description: 'Document Big-O proofs for all supported algorithms in project README.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Not testing graph searches on cyclic or disconnected graphs.'],
          proTips: ['Host a live demo link prominently in your GitHub header to make testing effortless for recruiters.']
        }
      ],
      resumeStarBullet: 'Architected an interactive algorithm visualizer in TypeScript & React using generator state machines and a custom binary Min-Heap, visualizing A* pathfinding and AVL balancing across 10,000+ nodes at 60 FPS.',
      interviewQuestions: [
        {
          question: 'How does A* pathfinding differ from Dijkstra, and what makes a heuristic admissible?',
          recruiterIntent: 'Tests fundamental theoretical understanding of shortest-path graph search algorithms.',
          answerStrategy: 'Explain that Dijkstra explores nodes equally in all directions based on g(n) (cost from start), while A* guides search toward the goal using f(n) = g(n) + h(n), where h(n) is an admissible heuristic (it never overestimates the true cost to reach the target, such as Euclidean or Manhattan distance).'
        },
        {
          question: 'Why did you use ES6 generator functions for the visualization playback engine?',
          recruiterIntent: 'Checks understanding of JavaScript language design, iterators, and execution contexts.',
          answerStrategy: 'Explain that generators allow pausing algorithm execution mid-function using yield without losing local scope variables, call stack state, or loop pointers. This makes forward stepping, pause, and scrubber time travel trivial to orchestrate without hacky setTimeout loops.'
        }
      ],
      githubTemplateHint: 'Includes /algorithms/pathfinding/astar.ts, /structures/MinHeap.ts, and /engine/playbackEngine.ts'
    },
    {
      id: 'dsa-p2-kvstore',
      coDomainName: 'Data Structures & Algorithms (DSA)',
      stream: 'Computer Science',
      tier: 'scalable',
      tierLabel: 'Tier 3: Distributed Systems Architecture',
      title: 'In-Memory Key-Value Store with Write-Ahead Log (WAL) & LRU/LFU Eviction',
      tagline: 'Miniature Redis clone with disk persistence, TTL expirations, and concurrent hash table indexing.',
      description: 'A high-performance in-memory database built from scratch in Python or Go. Implements doubly linked list + hash map LRU/LFU cache eviction, append-only Write-Ahead Logging (WAL) for durability, and RESP wire protocol support.',
      difficulty: 'Advanced',
      estimatedDuration: '3 Weeks (30 hrs total)',
      totalEstimatedHours: 30,
      recruiterAppeal: 'Demonstrates systems programming depth. Recruiters immediately recognize that you understand operating system caching, disk synchronization (fsync), and low-level memory layout.',
      techStack: {
        backend: ['Python 3.12 / Go', 'Socket Server', 'Binary Serialization'],
        tools: ['Pytest', 'Benchmarking Suites', 'Redis-CLI compatibility']
      },
      keyFeatures: [
        'O(1) GET, SET, and DELETE operations via hash table with bucket chaining',
        'LRU and LFU cache eviction strategies with max memory limits',
        'Write-Ahead Logging (WAL) with periodic background compaction (snapshotting)',
        'TTL key expiration using min-heap time scheduling',
        'Redis RESP protocol parser allowing standard redis-cli connections'
      ],
      architecturePattern: 'Log-Structured Append Engine with Hash Indexing & Cache Eviction',
      buildRoadmap: [
        {
          stepNumber: 1,
          phaseName: 'Phase 1: LRU & LFU Cache Eviction',
          title: 'Doubly Linked List & Hash Map Eviction',
          focus: 'Building O(1) eviction algorithms that discard least recently/frequently used keys.',
          estimatedHours: 6,
          deliverable: 'Standalone LRUCache and LFUCache classes with verified O(1) performance benchmarks.',
          architectureFocus: 'Combine dictionary for O(1) key lookup with doubly linked list for O(1) node detachment.',
          tasks: [
            { id: 'dsa-p2-s1-t1', title: 'Doubly Linked List Implementation', description: 'Build Node, head, and tail sentinel pointer structure with insert and remove methods.', estimatedHours: 2 },
            { id: 'dsa-p2-s1-t2', title: 'LRU Cache with Hash Map Index', description: 'Implement get and put operations updating access order and evicting tail upon capacity.', estimatedHours: 2 },
            { id: 'dsa-p2-s1-t3', title: 'LFU Frequency Bucket Architecture', description: 'Build frequency-indexed doubly linked lists with min_frequency tracking for LFU.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Using array shifts (arr.shift() / list.pop(0)) which are O(N) operations for eviction.'],
          proTips: ['Use head and tail dummy sentinel nodes to eliminate null checks when adding or removing elements.']
        },
        {
          stepNumber: 2,
          phaseName: 'Phase 2: Write-Ahead Logging & Durability',
          title: 'Append-Only Write-Ahead Log (WAL)',
          focus: 'Guaranteeing data recovery across crashes by logging every mutation to disk before RAM.',
          estimatedHours: 6,
          deliverable: 'Crash-resilient storage engine that reconstructs database state upon restart.',
          architectureFocus: 'Append-only log file with CRC32 checksums to detect corrupted disk blocks.',
          tasks: [
            { id: 'dsa-p2-s2-t1', title: 'WAL Binary Record Serialization', description: 'Format log entries: [Timestamp, CRC32, OpType, KeyLength, Key, ValLength, Value].', estimatedHours: 2.5 },
            { id: 'dsa-p2-s2-t2', title: 'fsync Synchronization Policies', description: 'Support configurable sync modes: ALWAYS (strict ACID) vs EVERYSEC (high throughput).', estimatedHours: 1.5 },
            { id: 'dsa-p2-s2-t3', title: 'Crash Recovery Replay Engine', description: 'Parse WAL from disk on startup, verifying checksums and repopulating in-memory hash table.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Relying on standard file.write() without calling os.fsync(), which leaves bytes in OS page cache.'],
          proTips: ['Add a CRC32 checksum header to every WAL record to detect partial writes from sudden power loss.']
        },
        {
          stepNumber: 3,
          phaseName: 'Phase 3: Log Compaction & Snapshotting',
          title: 'Background Log Compaction & Snapshots',
          focus: 'Preventing the WAL from growing infinitely by merging duplicate key mutations.',
          estimatedHours: 6,
          deliverable: 'Background compaction worker that compacts 1GB logs down to only active keys.',
          architectureFocus: 'Copy-on-write snapshotting similar to Redis RDB fork process.',
          tasks: [
            { id: 'dsa-p2-s3-t1', title: 'Compacted Snapshot Generation', description: 'Iterate active memory table and write clean state snapshot to a temporary file.', estimatedHours: 2.5 },
            { id: 'dsa-p2-s3-t2', title: 'Atomic File Rename Replacement', description: 'Use atomic os.replace() to swap compacted snapshot without downtime.', estimatedHours: 1.5 },
            { id: 'dsa-p2-s3-t3', title: 'Tombstone Purging for Deleted Keys', description: 'Ensure DELETE operations clear historical records during compaction.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Locking the entire database for writes during log compaction.'],
          proTips: ['Perform compaction in a separate process or write to a staging file before performing an atomic swap.']
        },
        {
          stepNumber: 4,
          phaseName: 'Phase 4: TTL Scheduling & RESP Protocol',
          title: 'TTL Expiration & Redis RESP Wire Protocol',
          focus: 'Parsing Redis Serialization Protocol (RESP) to allow standard redis-cli connectivity.',
          estimatedHours: 6,
          deliverable: 'Socket server speaking RESP protocol compatible with redis-cli and Redis SDKs.',
          architectureFocus: 'Min-Heap for key expirations: peek at top to expire dead keys without O(N) scanning.',
          tasks: [
            { id: 'dsa-p2-s4-t1', title: 'Min-Heap Expiration Scheduler', description: 'Store (expiry_timestamp, key) in MinHeap and evaluate on timer ticks.', estimatedHours: 2 },
            { id: 'dsa-p2-s4-t2', title: 'RESP Parser (Simple Strings, Errors, Integers, Bulk Strings)', description: 'Parse incoming *3\r\n$3\r\nSET\r\n$3\r\nfoo\r\n$3\r\nbar bytes.', estimatedHours: 2.5 },
            { id: 'dsa-p2-s4-t3', title: 'Async Socket Server Connection Loop', description: 'Handle multiple client socket connections concurrently with async event loop.', estimatedHours: 1.5 }
          ],
          pitfallsToAvoid: ['Checking every single key in the database on every second (active expiration O(N)).'],
          proTips: ['Combine passive expiration (check on GET) with active sampling (check 20 keys from heap every 100ms).']
        },
        {
          stepNumber: 5,
          phaseName: 'Phase 5: Benchmarking & Redis-Benchmark Comparison',
          title: 'Throughput Benchmarking & Memory Profiling',
          focus: 'Benchmarking operations per second using redis-benchmark tool against real Redis.',
          estimatedHours: 6,
          deliverable: 'Documented performance benchmark report showing 80,000+ ops/sec throughput.',
          architectureFocus: 'Flame graph profiling to eliminate internal string allocation bottlenecks.',
          tasks: [
            { id: 'dsa-p2-s5-t1', title: 'redis-benchmark Execution', description: 'Run redis-benchmark -q -n 100000 -c 50 -P 16 and measure operations per second.', estimatedHours: 2 },
            { id: 'dsa-p2-s5-t2', title: 'Concurrency & Race Condition Tests', description: 'Stress test multi-threaded access using concurrent clients to verify data integrity.', estimatedHours: 2 },
            { id: 'dsa-p2-s5-t3', title: 'Technical Architecture Report', description: 'Author detailed GitHub README comparing design choices with Redis and RocksDB.', estimatedHours: 2 }
          ],
          pitfallsToAvoid: ['Not measuring pipelined requests (batching makes a 10x difference in socket throughput).'],
          proTips: ['Include benchmark comparison charts against Redis 7 to showcase performance optimization.']
        }
      ],
      resumeStarBullet: 'Engineered an in-memory key-value database with Write-Ahead Logging (WAL) and LRU/LFU cache eviction, achieving 75,000+ ops/sec and sub-1ms crash recovery with full Redis RESP protocol compatibility.',
      interviewQuestions: [
        {
          question: 'How does an LRU cache achieve O(1) time complexity for both get and put operations?',
          recruiterIntent: 'Checks understanding of composite data structures and pointer decoupling.',
          answerStrategy: 'Explain pairing a hash map with a doubly linked list. The hash map stores keys mapped directly to linked list node pointers for O(1) lookup. The doubly linked list maintains the temporal order; accessing or updating an item detaches the node and moves it to the head in O(1) time. When capacity is exceeded, the tail node is removed in O(1).'
        },
        {
          question: 'What is the purpose of a Write-Ahead Log (WAL), and what happens if the system crashes during a write?',
          recruiterIntent: 'Tests database storage engine, persistence, and crash recovery understanding.',
          answerStrategy: 'Explain that WAL guarantees durability (ACID) by appending the mutation to a sequential disk log before updating in-memory state. If a crash occurs, the memory state is rebuilt on startup by replaying the log. CRC32 checksums allow discarding any incomplete/corrupted trailing record caused by mid-write crashes.'
        }
      ],
      githubTemplateHint: 'Includes /engine/lruCache.py, /storage/wal.py, /protocol/respParser.py, and /server/socketServer.py'
    }
  ],

  // --------------------------------------------------------------------------
  // BUSINESS ANALYTICS & DATA SCIENCE
  // --------------------------------------------------------------------------
  'Data Wrangling & ETL Pipelines': [
    {
      id: 'ba-p1-etl',
      coDomainName: 'Data Wrangling & ETL Pipelines',
      stream: 'Business Analytics',
      tier: 'applied',
      tierLabel: 'Tier 2: Production Data Pipeline',
      title: 'Automated E-Commerce Multi-Channel Sales ETL & Data Warehouse',
      tagline: 'Automated ingestion pipeline reconciling Shopify, Amazon, and Stripe into a dimensional Snowflake/Postgres warehouse.',
      description: 'An enterprise data engineering project that pulls messy JSON/CSV exports from diverse e-commerce platforms, normalizes currency exchange rates and order statuses, runs automated data validation checks (Great Expectations), and loads into a clean Star Schema data warehouse.',
      difficulty: 'Intermediate',
      estimatedDuration: '3 Weeks (25 hrs total)',
      totalEstimatedHours: 25,
      recruiterAppeal: 'Every enterprise deals with fragmented, dirty sales data. Demonstrates practical ETL design, handling schema drift, missing timestamps, and currency conversions.',
      techStack: {
        backend: ['Python 3.12', 'Pandas / Polars', 'DuckDB / PostgreSQL', 'Apache Airflow / Prefect'],
        tools: ['Great Expectations', 'dbt (data build tool)', 'Metabase / Power BI']
      },
      keyFeatures: [
        'Multi-channel ingestion (Shopify, Amazon, Stripe) with deduplication',
        'Automated currency normalization using real-time forex rates',
        'Data quality validation gates using Great Expectations with automated alerting',
        'Dimensional Star Schema modeling (DimCustomer, DimProduct, DimDate, FactSales)',
        'dbt transformation models with automated lineage graphs and documentation'
      ],
      architecturePattern: 'Modern Data Stack (ELT) with Star Schema Dimensional Modeling',
      buildRoadmap: [
        {
          stepNumber: 1,
          phaseName: 'Phase 1: Ingestion & Raw Data Lake',
          title: 'Extract Pipeline & Raw Parquet Staging',
          focus: 'Extracting messy multi-source data and storing raw immutable snapshots.',
          estimatedHours: 5,
          deliverable: 'Automated Python extraction scripts saving raw data into date-partitioned Parquet files.',
          architectureFocus: 'Store raw untouched payload first (Bronze Layer) before attempting any transformations.',
          tasks: [
            { id: 'ba-p1-s1-t1', title: 'Multi-Source Extract Script', description: 'Write API extractors for Shopify REST, Amazon CSVs, and Stripe transactions.', estimatedHours: 2 },
            { id: 'ba-p1-s1-t2', title: 'Parquet Partitioned Storage', description: 'Save raw payloads as year=YYYY/month=MM/day=DD partitioned Parquet files.', estimatedHours: 1.5 },
            { id: 'ba-p1-s1-t3', title: 'Deduplication by Natural Key', description: 'De-duplicate order line items using composite hash of (order_id, sku, transaction_time).', estimatedHours: 1.5 }
          ],
          pitfallsToAvoid: ['Modifying raw incoming data before writing to bronze staging storage.'],
          proTips: ['Use Parquet format with Snappy compression for 5x smaller file sizes and 10x faster queries than CSV.']
        },
        {
          stepNumber: 2,
          phaseName: 'Phase 2: Cleaning & Normalization',
          title: 'Polars / Pandas Cleaning & Currency Normalization',
          focus: 'Resolving missing values, date format variances, and multi-currency conversions.',
          estimatedHours: 5,
          deliverable: 'Clean Silver Layer table with standardized UTC timestamps and USD normalized values.',
          architectureFocus: 'Vectorized Polars transformations for high-speed batch data cleaning.',
          tasks: [
            { id: 'ba-p1-s2-t1', title: 'Timestamp Normalization to UTC', description: 'Parse mixed ISO-8601 and US/European date strings into uniform UTC datetimes.', estimatedHours: 1.5 },
            { id: 'ba-p1-s2-t2', title: 'Daily Forex Exchange Rate Join', description: 'Join daily foreign exchange rates to convert EUR, GBP, and INR orders into standardized USD.', estimatedHours: 2 },
            { id: 'ba-p1-s2-t3', title: 'Missing Address & Category Imputation', description: 'Impute missing product categories using title regex keyword heuristics.', estimatedHours: 1.5 }
          ],
          pitfallsToAvoid: ['Applying a single static exchange rate across orders spanning multiple months.'],
          proTips: ['Join historical forex rates matching the exact date of transaction to ensure financial precision.']
        },
        {
          stepNumber: 3,
          phaseName: 'Phase 3: Data Quality Validation (Great Expectations)',
          title: 'Automated Quality Gates & Pipeline Halting',
          focus: 'Setting up automated data contract tests to halt the pipeline if dirty data arrives.',
          estimatedHours: 5,
          deliverable: 'Quality suite checking null thresholds, price ranges, and uniqueness constraints.',
          architectureFocus: 'Fail-fast data contracts that quarantine anomalous records into a dead-letter table.',
          tasks: [
            { id: 'ba-p1-s3-t1', title: 'Great Expectations Suite Setup', description: 'Define expectations: order_total > 0, order_id is unique, status in valid enum list.', estimatedHours: 2 },
            { id: 'ba-p1-s3-t2', title: 'Dead-Letter Quarantine Logic', description: 'Route failed records to quarantined_records table instead of failing the entire batch.', estimatedHours: 1.5 },
            { id: 'ba-p1-s3-t3', title: 'Automated Quality Slack / Email Alert', description: 'Trigger webhook notifications when validation error rates exceed 1%.', estimatedHours: 1.5 }
          ],
          pitfallsToAvoid: ['Allowing silent data corruptions (e.g. negative revenue) to pass unnoticed into executive dashboards.'],
          proTips: ['Always publish Great Expectations HTML Data Docs to a GitHub Pages or internal S3 site.']
        },
        {
          stepNumber: 4,
          phaseName: 'Phase 4: Dimensional Modeling & dbt Transformations',
          title: 'Star Schema Data Warehouse with dbt',
          focus: 'Modeling fact and dimension tables optimized for BI analytical aggregation queries.',
          estimatedHours: 5,
          deliverable: 'Star schema with FactOrders joined to DimCustomers, DimProducts, and DimDate.',
          architectureFocus: 'Surrogate keys and slowly changing dimensions (SCD Type 2) in dbt.',
          tasks: [
            { id: 'ba-p1-s4-t1', title: 'dbt Staging & Dimension Models', description: 'Create dim_customers and dim_products with surrogate keys using dbt_utils.generate_surrogate_key.', estimatedHours: 2 },
            { id: 'ba-p1-s4-t2', title: 'Fact Table Aggregation', description: 'Build fact_sales with pre-calculated margins, discount rates, and net profit columns.', estimatedHours: 1.5 },
            { id: 'ba-p1-s4-t3', title: 'dbt Documentation & Lineage DAG', description: 'Generate interactive dbt documentation displaying full table dependency graphs.', estimatedHours: 1.5 }
          ],
          pitfallsToAvoid: ['Querying massive un-indexed raw JSON files directly in BI reporting dashboards.'],
          proTips: ['Organize transformations into clean layers: staging (stg_), intermediate (int_), and mart (fct_/dim_).']
        },
        {
          stepNumber: 5,
          phaseName: 'Phase 5: BI Dashboard & Orchestration Schedule',
          title: 'Prefect Orchestration & Executive Dashboard',
          focus: 'Automating daily pipeline execution and connecting an interactive analytics dashboard.',
          estimatedHours: 5,
          deliverable: 'Automated pipeline scheduled via Prefect with live Metabase/PowerBI executive dashboard.',
          architectureFocus: 'Orchestrated DAG running extract -> clean -> dbt run -> dbt test.',
          tasks: [
            { id: 'ba-p1-s5-t1', title: 'Prefect Flow & Scheduled Trigger', description: 'Schedule daily 02:00 UTC execution with automated retry on network timeout.', estimatedHours: 2 },
            { id: 'ba-p1-s5-t2', title: 'Executive BI Dashboard in Metabase / PowerBI', description: 'Build visual KPIs: Gross Merchandise Value (GMV), Customer Acquisition, and Channel Margin.', estimatedHours: 2 },
            { id: 'ba-p1-s5-t3', title: 'Case Study & Architecture Presentation', description: 'Document business impact, pipeline architecture diagrams, and cost savings in README.', estimatedHours: 1 }
          ],
          pitfallsToAvoid: ['Not scheduling automated retries for transient third-party API rate limits (HTTP 429).'],
          proTips: ['Highlight business unit economics (LTV:CAC ratio and gross margin per channel) prominently in the BI cards.']
        }
      ],
      resumeStarBullet: 'Engineered an automated multi-channel sales ETL pipeline using Python, dbt, and Great Expectations, consolidating $10M+ in GMV data across 3 platforms into a Star Schema warehouse with 100% data contract compliance.',
      interviewQuestions: [
        {
          question: 'What is the difference between Star Schema and Snowflake Schema, and why did you choose Star Schema?',
          recruiterIntent: 'Checks understanding of dimensional modeling, query performance, and normalization trade-offs.',
          answerStrategy: 'Explain that Star Schema denormalizes dimensions around a centralized fact table, minimizing the number of SQL JOINs required for analytical aggregation queries (making it ideal for BI tools like Power BI and Tableau). Snowflake schema further normalizes dimension tables (e.g. splitting categories from products), which saves disk space but increases join complexity and slows down reporting queries.'
        },
        {
          question: 'How do you handle schema drift when a source API adds or removes fields unexpectedly?',
          recruiterIntent: 'Tests data engineering resilience and real-world production readiness.',
          answerStrategy: 'Describe using a Bronze/Silver/Gold architecture. In the Bronze layer, raw JSON is stored immutably in Parquet/JSONB without transformation. The ingestion script applies schema validation via Pydantic or Great Expectations. If new fields appear, they are recorded in metadata without breaking downstreams; if critical required fields are missing, the batch is routed to a quarantine dead-letter table with alert dispatch.'
        }
      ],
      githubTemplateHint: 'Includes /flows/sales_pipeline.py, /dbt_project/models/marts, /great_expectations/expectations, and /docs/architecture.png'
    }
  ]
};

// ----------------------------------------------------------------------------
// // Procedural Project Generator Engine
// Guarantees 4 high-impact, realistic good projects for ANY discipline/co-domain
// with authentic, co-domain and project-specific Pro-Tips and Pitfalls.
// ----------------------------------------------------------------------------
export function generateProjectsForCoDomain(coDomainName: string, stream: string): GoodProject[] {
  // 1. Direct match in curated collection (only if it has all 4 complete tiers)
  if (CURATED_PROJECTS[coDomainName] && CURATED_PROJECTS[coDomainName].length === 4) {
    return CURATED_PROJECTS[coDomainName];
  }

  // 2. Fuzzy match within curated collection
  const matchKey = Object.keys(CURATED_PROJECTS).find(k => 
    (k.toLowerCase().includes(coDomainName.toLowerCase()) || 
    coDomainName.toLowerCase().includes(k.toLowerCase())) &&
    CURATED_PROJECTS[k].length === 4
  );
  if (matchKey && CURATED_PROJECTS[matchKey]) {
    return CURATED_PROJECTS[matchKey];
  }

  // 3. Complete Domain & Co-Domain Intelligence Engine
  const profile = resolveCoDomainProfile(coDomainName, stream);
  return buildProjectsFromProfile(profile, coDomainName, stream);
}

