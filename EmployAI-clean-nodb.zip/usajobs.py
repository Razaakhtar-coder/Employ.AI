import os
import re
import html
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting
from app.core.config import settings


class USAJobsProvider(JobProviderAdapter):
    """
    USAJobs Public Research & Engineering Openings Adapter.
    Pulls verified listings across Civil Engineering, Healthcare, Biomedical,
    Environmental Sciences, and Mechanical Engineering when credentials are set.
    """

    API_URL = "https://data.usajobs.gov/api/search"

    def __init__(self):
        self.api_key = settings.USAJOBS_API_KEY or os.getenv("USAJOBS_API_KEY", "")
        self.user_email = settings.USAJOBS_EMAIL or os.getenv("USAJOBS_EMAIL", "")

    @property
    def name(self) -> str:
        return "USAJobs"

    @property
    def is_enabled(self) -> bool:
        return bool(self.api_key and self.user_email)

    def _strip_html(self, raw_html: str) -> str:
        if not raw_html:
            return ""
        clean = re.sub(r"<[^>]+>", " ", raw_html)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        if not self.is_enabled:
            return []

        postings: List[RawJobPosting] = []
        headers = {
            "Host": "data.usajobs.gov",
            "User-Agent": self.user_email,
            "Authorization-Key": self.api_key
        }
        params = {
            "Keyword": query or "Engineering Trainee",
            "ResultsPerPage": 20,
            "Page": page
        }

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(self.API_URL, headers=headers, params=params)
                if resp.status_code == 200:
                    data = resp.json()
                    search_result = data.get("SearchResult", {})
                    items = search_result.get("SearchResultItems", [])
                    for item in items:
                        desc_obj = item.get("MatchedObjectDescriptor", {})
                        raw_title = desc_obj.get("PositionTitle", "")
                        org_name = desc_obj.get("OrganizationName", "Public Research Institution")
                        dept_name = desc_obj.get("DepartmentName", "")
                        company = f"{org_name} ({dept_name})" if dept_name else org_name
                        apply_uri = desc_obj.get("PositionURI", "https://www.usajobs.gov")
                        summary = desc_obj.get("UserArea", {}).get("Details", {}).get("JobSummary", "")
                        clean_desc = self._strip_html(summary)

                        postings.append(RawJobPosting(
                            source_id=f"usajobs-{desc_obj.get('PositionID', raw_title)}",
                            source="USAJobs",
                            title=raw_title,
                            company=company,
                            location=desc_obj.get("PositionLocationDisplay", "Global"),
                            remote="remote" in (raw_title + " " + clean_desc).lower(),
                            job_type="internship" if "student" in raw_title.lower() or "intern" in raw_title.lower() else "full-time",
                            experience_level="intern" if "student" in raw_title.lower() or "intern" in raw_title.lower() else "entry",
                            description=clean_desc,
                            required_skills=[],
                            apply_url=apply_uri,
                            posted_date=desc_obj.get("PublicationStartDate", "Recently")[:10]
                        ))
        except Exception as e:
            print(f"[WARN] USAJobs fetch failed: {e}")

        return postings
