import time
import os
import logging
from typing import Optional, Dict, Tuple
from fastapi import Request, HTTPException, status

logger = logging.getLogger(__name__)

# Redis optional client initialization
REDIS_URL = os.getenv("REDIS_URL", "")
_redis_client = None

if REDIS_URL:
    try:
        import redis
        _redis_client = redis.Redis.from_url(REDIS_URL, decode_responses=True)
        logger.info("Distributed Redis rate limiter connected successfully.")
    except Exception as e:
        logger.warning("Could not connect to Redis (%s); falling back to in-memory sliding window.", e)


class SlidingWindowRateLimiter:
    """
    Sliding window rate limiter supporting distributed Redis with an in-memory fallback.
    Safely identifies clients via authenticated user ID or reverse-proxy sanitized IP.
    """
    def __init__(self):
        # In-memory storage: {key: [(timestamp, count)]}
        self._local_cache: Dict[str, list] = {}

    @staticmethod
    def get_client_identifier(request: Request, user_id: Optional[str] = None) -> str:
        """
        Determines the most reliable client identifier:
        1. Authenticated user ID (prevents NAT collision and header spoofing)
        2. Real client IP from trusted reverse proxy headers (Vercel / Cloudflare)
        3. Direct socket host fallback
        """
        if user_id:
            return f"user:{user_id}"

        # Safe reverse-proxy client IP extraction
        # On Vercel / Cloudflare, x-real-ip or cf-connecting-ip contains the upstream verified client IP
        real_ip = request.headers.get("x-real-ip") or request.headers.get("cf-connecting-ip")
        if real_ip:
            return f"ip:{real_ip.strip()}"

        x_forwarded = request.headers.get("x-forwarded-for")
        if x_forwarded:
            # Take the leftmost untrusted IP only if no trusted header exists, or last proxy hop
            hops = [ip.strip() for ip in x_forwarded.split(",") if ip.strip()]
            if hops:
                return f"ip:{hops[0]}"

        client_host = request.client.host if request.client else "unknown_client"
        return f"ip:{client_host}"

    def check_rate_limit(
        self,
        identifier: str,
        scope: str,
        max_requests: int,
        window_seconds: int = 60
    ) -> Tuple[bool, int]:
        """
        Checks whether the rate limit is exceeded.
        Returns: (is_allowed: bool, retry_after_seconds: int)
        """
        key = f"rl:{scope}:{identifier}"
        now = time.time()

        # 1. Distributed Redis Strategy
        if _redis_client:
            try:
                pipe = _redis_client.pipeline()
                clear_before = now - window_seconds
                pipe.zremrangebyscore(key, 0, clear_before)
                pipe.zcard(key)
                pipe.zadd(key, {str(now): now})
                pipe.expire(key, window_seconds + 5)
                results = pipe.execute()
                current_count = results[1]

                if current_count >= max_requests:
                    # Exceeded
                    return False, int(window_seconds)
                return True, 0
            except Exception as e:
                logger.warning("Redis rate limit check failed (%s), using local fallback.", e)

        # 2. In-Memory Sliding Window Fallback
        timestamps = self._local_cache.get(key, [])
        cutoff = now - window_seconds
        valid_timestamps = [t for t in timestamps if t > cutoff]

        if len(valid_timestamps) >= max_requests:
            earliest = valid_timestamps[0]
            retry_after = max(1, int(window_seconds - (now - earliest)))
            self._local_cache[key] = valid_timestamps
            return False, retry_after

        valid_timestamps.append(now)
        self._local_cache[key] = valid_timestamps

        # Cleanup cache periodically
        if len(self._local_cache) > 5000:
            keys_to_delete = [
                k for k, ts in self._local_cache.items()
                if not ts or ts[-1] < cutoff
            ]
            for k in keys_to_delete[:1000]:
                self._local_cache.pop(k, None)

        return True, 0


rate_limiter = SlidingWindowRateLimiter()


def enforce_rate_limit(
    scope: str,
    max_requests: int,
    window_seconds: int = 60
):
    """
    FastAPI dependency factory to enforce endpoint-specific rate limits.
    Returns HTTP 429 Too Many Requests with standard Retry-After header.
    """
    async def dependency(request: Request):
        # Extract user ID from auth header if present
        user_id = None
        auth_header = request.headers.get("authorization")
        if auth_header and auth_header.startswith("Bearer "):
            try:
                from app.core.security import decode_access_token
                payload = decode_access_token(auth_header.split(" ")[1])
                if payload:
                    user_id = payload.get("sub")
            except Exception:
                pass

        identifier = rate_limiter.get_client_identifier(request, user_id=user_id)
        is_allowed, retry_after = rate_limiter.check_rate_limit(
            identifier=identifier,
            scope=scope,
            max_requests=max_requests,
            window_seconds=window_seconds
        )

        if not is_allowed:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Too Many Requests. Rate limit of {max_requests} requests per {window_seconds}s exceeded. Please try again in {retry_after} seconds.",
                headers={"Retry-After": str(retry_after)}
            )

    return dependency
