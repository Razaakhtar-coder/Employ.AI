import React, { useState, useRef } from 'react';
import { 
  Play, Pause, RotateCcw, Sparkles, CheckCircle2, 
  Zap, Volume2, VolumeX, Maximize, Target, FileText, ArrowRight
} from 'lucide-react';

export interface JobTailoringExplainerVideoProps {
  onOpenTailoring?: () => void;
  onUseExample?: (jobTitle: string, jobDesc: string) => void;
  compact?: boolean;
}

export const JobTailoringExplainerVideo: React.FC<JobTailoringExplainerVideoProps> = ({
  onOpenTailoring,
  onUseExample,
  compact = false
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [isVideoLoaded, setIsVideoLoaded] = useState<boolean>(false);
  const [loadError, setLoadError] = useState<boolean>(false);

  // Format seconds to mm:ss
  const formatTime = (timeInSec: number): string => {
    if (isNaN(timeInSec) || timeInSec < 0) return '00:00';
    const mins = Math.floor(timeInSec / 60);
    const secs = Math.floor(timeInSec % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Video event handlers
  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
      setIsVideoLoaded(true);
      setLoadError(false);
    }
  };

  const handleVideoEnded = () => {
    setIsPlaying(false);
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(err => {
        console.warn('Playback failed:', err);
      });
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const targetTime = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = targetTime;
      setCurrentTime(targetTime);
    }
  };

  const handleRestart = () => {
    if (!videoRef.current) return;
    videoRef.current.currentTime = 0;
    setCurrentTime(0);
    videoRef.current.play().then(() => {
      setIsPlaying(true);
    }).catch(console.warn);
  };

  const handleSpeedChange = (speed: number) => {
    if (!videoRef.current) return;
    videoRef.current.playbackRate = speed;
    setPlaybackSpeed(speed);
  };

  const handleFullscreen = () => {
    if (containerRef.current) {
      if (document.fullscreenElement) {
        document.exitFullscreen();
      } else {
        containerRef.current.requestFullscreen().catch(console.warn);
      }
    }
  };

  const handleApplySampleToWorkspace = () => {
    const sampleTitle = 'Full-Stack AI Engineer';
    const sampleDesc = 'Job Title: Full-Stack AI Engineer\n\nKey Responsibilities:\n• Architect and deploy high-performance RAG pipelines using Python, FastAPI, LangChain, and vector embeddings.\n• Build interactive frontend interfaces with React 19, TypeScript, and modern component libraries.\n• Containerize microservices using Docker and manage CI/CD pipelines.\n• Optimize SQL and vector database queries for sub-second retrieval.\n\nRequired Qualifications:\n• 3+ years experience with Python, React, and REST/GraphQL APIs.\n• Proven experience deploying LLMs, Prompt Engineering, and Vector Search systems.\n• Strong foundation in System Design, Git, and Docker.';

    if (onUseExample) {
      onUseExample(sampleTitle, sampleDesc);
    } else if (onOpenTailoring) {
      onOpenTailoring();
    }
  };

  return (
    <div 
      ref={containerRef}
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '1rem',
        width: '100%'
      }}
    >
      {/* Top Walkthrough Header & Action Banner */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '0.75rem',
        background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.1) 0%, rgba(168, 85, 247, 0.08) 100%)',
        border: '1px solid rgba(56, 189, 248, 0.25)',
        borderRadius: '12px',
        padding: '0.75rem 1rem'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <div style={{
            width: '36px',
            height: '36px',
            borderRadius: '10px',
            background: 'linear-gradient(135deg, #00f2fe 0%, #38bdf8 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 0 14px rgba(56, 189, 248, 0.4)',
            flexShrink: 0
          }}>
            <Sparkles size={18} color="#030712" />
          </div>
          <div>
            <h4 style={{ fontSize: '0.98rem', fontWeight: 800, color: '#ffffff', margin: 0, display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              How Resume Tailoring Works
              <span className="badge badge-cyan" style={{ fontSize: '0.62rem', fontWeight: 700, padding: '0.15rem 0.45rem' }}>
                Video Walkthrough
              </span>
            </h4>
            <p style={{ fontSize: '0.75rem', color: '#94a3b8', margin: '0.15rem 0 0 0' }}>
              See how Employ.AI extracts required skills from job postings and dynamically tailors your resume for maximum ATS score.
            </p>
          </div>
        </div>

        {/* Quick Launch Buttons */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
          <button
            type="button"
            onClick={handleApplySampleToWorkspace}
            className="btn btn-secondary btn-sm"
            style={{
              fontSize: '0.75rem',
              fontWeight: 700,
              padding: '0.35rem 0.75rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem'
            }}
          >
            <FileText size={13} color="#38bdf8" />
            <span>Load Sample Job Description</span>
          </button>

          {onOpenTailoring && (
            <button
              type="button"
              onClick={onOpenTailoring}
              className="btn btn-primary btn-sm"
              style={{
                fontSize: '0.75rem',
                fontWeight: 800,
                padding: '0.35rem 0.85rem',
                background: 'linear-gradient(135deg, #00f2fe 0%, #38bdf8 100%)',
                color: '#030712',
                border: 'none',
                boxShadow: '0 0 14px rgba(56, 189, 248, 0.4)',
                display: 'flex',
                alignItems: 'center',
                gap: '0.35rem'
              }}
            >
              <Zap size={13} />
              <span>Open Live Workspace</span>
              <ArrowRight size={13} />
            </button>
          )}
        </div>
      </div>

      {/* Main Video Player Container */}
      <div 
        style={{
          position: 'relative',
          background: '#030712',
          border: '1.5px solid rgba(56, 189, 248, 0.3)',
          borderRadius: '14px',
          overflow: 'hidden',
          boxShadow: '0 12px 36px rgba(0, 0, 0, 0.6), 0 0 24px rgba(56, 189, 248, 0.15)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center'
        }}
      >
        {/* Video Element */}
        <div style={{ position: 'relative', width: '100%', maxHeight: compact ? '320px' : '480px', backgroundColor: '#000000', display: 'flex', justifyContent: 'center' }}>
          <video
            ref={videoRef}
            src="/videos/tailor-resume-demo.mp4"
            playsInline
            preload="auto"
            onClick={togglePlay}
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            onEnded={handleVideoEnded}
            onError={() => {
              // Try fallback root path if /videos/ fails
              if (videoRef.current && videoRef.current.src.includes('/videos/')) {
                videoRef.current.src = '/tailor-resume-demo.mp4';
              } else {
                setLoadError(true);
              }
            }}
            style={{
              width: '100%',
              maxHeight: compact ? '320px' : '480px',
              objectFit: 'contain',
              display: 'block',
              cursor: 'pointer'
            }}
          >
            <source src="/videos/tailor-resume-demo.mp4" type="video/mp4" />
            <source src="/tailor-resume-demo.mp4" type="video/mp4" />
            Your browser does not support HTML5 video playback.
          </video>

          {/* Big Play Overlay (when paused) */}
          {!isPlaying && isVideoLoaded && !loadError && (
            <div 
              onClick={togglePlay}
              style={{
                position: 'absolute',
                inset: 0,
                background: 'rgba(3, 7, 18, 0.45)',
                backdropFilter: 'blur(2px)',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                gap: '0.6rem',
                transition: 'all 0.2s ease'
              }}
            >
              <div style={{
                width: '64px',
                height: '64px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #00f2fe 0%, #38bdf8 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 0 28px rgba(56, 189, 248, 0.7)',
                paddingLeft: '4px'
              }}>
                <Play size={30} fill="#030712" color="#030712" />
              </div>
              <span style={{ fontSize: '0.85rem', fontWeight: 800, color: '#ffffff', textShadow: '0 2px 8px rgba(0,0,0,0.8)' }}>
                Click to Play Tailoring Walkthrough
              </span>
            </div>
          )}

          {/* Error Message if video fails to load */}
          {loadError && (
            <div style={{
              padding: '2.5rem 1.5rem',
              textAlign: 'center',
              color: '#f87171',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '0.75rem'
            }}>
              <p style={{ fontSize: '0.9rem', fontWeight: 700, margin: 0 }}>
                Unable to load the video walkthrough file.
              </p>
              <p style={{ fontSize: '0.76rem', color: '#94a3b8', margin: 0, maxWidth: '400px' }}>
                Please ensure the video file exists in the public directory or click below to retry.
              </p>
              <button 
                type="button" 
                onClick={handleRestart}
                className="btn btn-secondary btn-sm"
                style={{ marginTop: '0.5rem' }}
              >
                <RotateCcw size={13} /> Retry Video
              </button>
            </div>
          )}
        </div>

        {/* Custom Video Control Bar */}
        <div style={{
          width: '100%',
          background: 'rgba(10, 15, 30, 0.95)',
          borderTop: '1px solid rgba(255, 255, 255, 0.08)',
          padding: '0.6rem 0.9rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.45rem',
          boxSizing: 'border-box'
        }}>
          {/* Progress Timeline Slider */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <span style={{ fontSize: '0.72rem', color: '#38bdf8', fontFamily: 'monospace', fontWeight: 700, minWidth: '38px' }}>
              {formatTime(currentTime)}
            </span>
            <input
              type="range"
              min="0"
              max={duration || 100}
              step="0.1"
              value={currentTime}
              onChange={handleSeek}
              style={{
                flex: 1,
                cursor: 'pointer',
                accentColor: '#38bdf8',
                height: '5px'
              }}
            />
            <span style={{ fontSize: '0.72rem', color: '#94a3b8', fontFamily: 'monospace', minWidth: '38px' }}>
              {formatTime(duration)}
            </span>
          </div>

          {/* Control Buttons Row */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
            {/* Left Controls: Play/Pause, Restart, Volume */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
              <button
                type="button"
                onClick={togglePlay}
                className="btn btn-primary btn-sm"
                style={{
                  fontSize: '0.74rem',
                  padding: '0.3rem 0.65rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  background: isPlaying ? 'rgba(56, 189, 248, 0.2)' : 'linear-gradient(135deg, #00f2fe 0%, #38bdf8 100%)',
                  color: isPlaying ? '#38bdf8' : '#030712',
                  border: isPlaying ? '1px solid #38bdf8' : 'none'
                }}
              >
                {isPlaying ? <Pause size={13} /> : <Play size={13} fill={isPlaying ? 'none' : '#030712'} />}
                <span>{isPlaying ? 'Pause' : 'Play'}</span>
              </button>

              <button
                type="button"
                onClick={handleRestart}
                className="btn btn-ghost btn-sm"
                title="Restart from start"
                style={{ fontSize: '0.74rem', padding: '0.3rem 0.5rem', color: '#94a3b8' }}
              >
                <RotateCcw size={13} />
              </button>

              <button
                type="button"
                onClick={toggleMute}
                className="btn btn-ghost btn-sm"
                title={isMuted ? 'Unmute' : 'Mute'}
                style={{ fontSize: '0.74rem', padding: '0.3rem 0.5rem', color: isMuted ? '#f87171' : '#94a3b8' }}
              >
                {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
              </button>
            </div>

            {/* Right Controls: Playback Speeds & Fullscreen */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
              <span style={{ fontSize: '0.68rem', color: '#64748b', fontWeight: 600 }}>Speed:</span>
              {[1, 1.25, 1.5].map((speed) => (
                <button
                  key={speed}
                  type="button"
                  onClick={() => handleSpeedChange(speed)}
                  className={`btn btn-sm ${playbackSpeed === speed ? 'btn-primary' : 'btn-ghost'}`}
                  style={{
                    fontSize: '0.68rem',
                    padding: '0.15rem 0.45rem',
                    borderRadius: '4px',
                    fontWeight: 700,
                    minWidth: '32px'
                  }}
                >
                  {speed}x
                </button>
              ))}

              <button
                type="button"
                onClick={handleFullscreen}
                className="btn btn-ghost btn-sm"
                title="Toggle Fullscreen"
                style={{ fontSize: '0.74rem', padding: '0.3rem 0.5rem', color: '#94a3b8' }}
              >
                <Maximize size={14} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 3 Step Workflow Explanation Cards */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
        gap: '0.75rem',
        marginTop: '0.25rem'
      }}>
        <div style={{
          background: 'rgba(15, 23, 42, 0.65)',
          border: '1px solid rgba(56, 189, 248, 0.2)',
          borderRadius: '10px',
          padding: '0.75rem 0.85rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.35rem'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#38bdf8', fontSize: '0.78rem', fontWeight: 800 }}>
            <FileText size={14} />
            <span>1. Target Job Input</span>
          </div>
          <p style={{ fontSize: '0.73rem', color: '#94a3b8', margin: 0, lineHeight: 1.4 }}>
            Paste raw job requirements, title, or skills directly from LinkedIn, Google, or company career portals.
          </p>
        </div>

        <div style={{
          background: 'rgba(15, 23, 42, 0.65)',
          border: '1px solid rgba(56, 189, 248, 0.2)',
          borderRadius: '10px',
          padding: '0.75rem 0.85rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.35rem'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#34d399', fontSize: '0.78rem', fontWeight: 800 }}>
            <CheckCircle2 size={14} />
            <span>2. Keyword Extraction</span>
          </div>
          <p style={{ fontSize: '0.73rem', color: '#94a3b8', margin: 0, lineHeight: 1.4 }}>
            AI extracts required technical competencies, tools, and methodologies with instant match tagging.
          </p>
        </div>

        <div style={{
          background: 'rgba(15, 23, 42, 0.65)',
          border: '1px solid rgba(56, 189, 248, 0.2)',
          borderRadius: '10px',
          padding: '0.75rem 0.85rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.35rem'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#a855f7', fontSize: '0.78rem', fontWeight: 800 }}>
            <Target size={14} />
            <span>3. Live Resume Alignment</span>
          </div>
          <p style={{ fontSize: '0.73rem', color: '#94a3b8', margin: 0, lineHeight: 1.4 }}>
            Headline, summary, and experience bullet points reflect high-impact phrasing while preserving evidence integrity.
          </p>
        </div>
      </div>
    </div>
  );
};
