import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { documentApi, getUserScopedStorageKey, clearAllResumeStorage } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { calculateATSScore, extractJDKeywords } from '../services/atsScoring';
import { extractJobDetails, generateTailoredProfessionalSummary } from '../utils/jobTailoringExtractor';
import type { 
  ResumeAnalysisResult, 
  StructuredResume, 
  SectionEnhanceResponse,
  ResumeTemplateId,
  ResumeVersionItem,
  AppliedChangeItem,
  QualityIssueItem
} from '../types';
import { ResumePreviewContainer } from './ResumePreviewContainer';
import { MyResumesModal } from './MyResumesModal';
import { ResumeVersionsModal } from './ResumeVersionsModal';
import { BulletImprovementModal } from './BulletImprovementModal';
import { SummaryImprovementModal } from './SummaryImprovementModal';
import { HeadlineImprovementModal } from './HeadlineImprovementModal';
import { QualityCheckModal } from './QualityCheckModal';
import { ResumeComparisonModal } from './ResumeComparisonModal';
import { ExportResumeModal, exportResumeDocx } from './ExportResumeModal';
import { JobTailoringModal } from './JobTailoringModal';
import { ResumeTemplatesModal } from './ResumeTemplatesModal';
import { FuturisticLoader } from './FuturisticLoader';
import { ResumeLearningDashboard } from './ResumeLearningDashboard';
import { CreateResumeScratchModal } from './CreateResumeScratchModal';
import { generateClientSectionEnhance } from '../utils/resumeSectionEnhancer';
import { cleanBulletText } from '../utils/urlHelper';
import { 
  UploadCloud, CheckCircle2, 
  Sparkles, Check, RefreshCw, AlertCircle,
  Download, FileDown, Copy, RotateCcw,
  CheckCheck, Target, Bug, FileText,
  Trash2, AlertTriangle, X, FileCheck,
  Wand2, Zap, BookOpen, Briefcase,
  Code, Plus, Layers, Undo2, Layout,
  BookMarked, Play
} from 'lucide-react';

const ENHANCER_ARCHETYPES = [
  { id: 'all', label: '✨ Mixed Power Verbs', prompt: 'Use varied, fresh power action verbs across diverse archetypes like Pioneered, Formulated, Championed, Overhauled, Scaled, Transformed.' },
  { id: 'innovation', label: '💡 Innovation & Architecture', prompt: 'Use innovative technical action verbs like Pioneered, Architected, Formulated, Synthesized, Devised, Modernized.' },
  { id: 'velocity', label: '🚀 Velocity & Delivery', prompt: 'Use high-velocity delivery action verbs like Championed, Mobilized, Accelerated, Delivered, Spearheaded, Steered.' },
  { id: 'optimization', label: '⚡ Scale & Optimization', prompt: 'Use performance optimization action verbs like Overhauled, Streamlined, Scaled, Automated, Revitalized, Amplified.' },
  { id: 'leadership', label: '🎯 Leadership & Impact', prompt: 'Use executive leadership action verbs like Transformed, Galvanized, Cultivated, Maximized, Elevated, Catalyzed.' },
  { id: 'analytics', label: '📊 Analytical Rigor', prompt: 'Use diagnostic analytical action verbs like Diagnosed, Benchmarked, Modeled, Evaluated, Quantified, Decoded.' }
];

const RESUME_STORAGE_KEY = 'employai_active_resume_analysis';
const STRUCTURED_RESUME_STORAGE_KEY = 'employai_active_structured_resume';
const RESUME_VIEW_TAB_KEY = 'employai_resume_view_tab';
const RESUME_TEMPLATE_KEY = 'employai_selected_template';

export interface ResumeAnalyzerProps {
  onNavigate?: (tab: string) => void;
}

const ResumeAnalyzerComponent: React.FC<ResumeAnalyzerProps> = ({ onNavigate }) => {
  const { user, isAuthenticated, openAuthModal, isPremium, isAdmin, openSubscriptionModal } = useAuth();

  // Lazy initialize state from localStorage with user scoping so there is zero flash of empty state
  const [analysis, setAnalysis] = useState<ResumeAnalysisResult | null>(() => {
    try {
      const key = getUserScopedStorageKey(RESUME_STORAGE_KEY);
      const saved = localStorage.getItem(key) || localStorage.getItem(RESUME_STORAGE_KEY);
      if (saved) {
        if (saved.includes('Cloud-Native Career Ecosystem') || saved.includes('Tech Solutions & Engineering') || saved.includes('Institute of Engineering & Technology')) {
          clearAllResumeStorage();
          return null;
        }
        return JSON.parse(saved);
      }
      return null;
    } catch {
      return null;
    }
  });

  const [structuredResume, setStructuredResume] = useState<StructuredResume | null>(() => {
    try {
      const structKey = getUserScopedStorageKey(STRUCTURED_RESUME_STORAGE_KEY);
      const saved = localStorage.getItem(structKey) || localStorage.getItem(STRUCTURED_RESUME_STORAGE_KEY);
      if (saved) {
        if (saved.includes('Cloud-Native Career Ecosystem') || saved.includes('Tech Solutions & Engineering') || saved.includes('Institute of Engineering & Technology')) {
          clearAllResumeStorage();
          return null;
        }
        return JSON.parse(saved);
      }
      const resumeKey = getUserScopedStorageKey(RESUME_STORAGE_KEY);
      const savedAnalysis = localStorage.getItem(resumeKey) || localStorage.getItem(RESUME_STORAGE_KEY);
      if (savedAnalysis) {
        if (savedAnalysis.includes('Cloud-Native Career Ecosystem') || savedAnalysis.includes('Tech Solutions & Engineering') || savedAnalysis.includes('Institute of Engineering & Technology')) {
          clearAllResumeStorage();
          return null;
        }
        const parsed = JSON.parse(savedAnalysis);
        return parsed.structured_resume || null;
      }
      return null;
    } catch {
      return null;
    }
  });

  const [originalStructuredResume, setOriginalStructuredResume] = useState<StructuredResume | null>(() => {
    try {
      const structKey = getUserScopedStorageKey(STRUCTURED_RESUME_STORAGE_KEY);
      const saved = localStorage.getItem(structKey) || localStorage.getItem(STRUCTURED_RESUME_STORAGE_KEY);
      if (saved) {
        if (saved.includes('Cloud-Native Career Ecosystem') || saved.includes('Tech Solutions & Engineering') || saved.includes('Institute of Engineering & Technology')) {
          clearAllResumeStorage();
          return null;
        }
        return JSON.parse(saved);
      }
      return null;
    } catch {
      return null;
    }
  });

  const [isLoading, setIsLoading] = useState<boolean>(() => {
    try {
      const key = getUserScopedStorageKey(RESUME_STORAGE_KEY);
      return !localStorage.getItem(key);
    } catch {
      return true;
    }
  });

  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadScanStep, setUploadScanStep] = useState<number>(1);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
  const [deleteModalError, setDeleteModalError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isAnalyzingJob, setIsAnalyzingJob] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedNotification, setCopiedNotification] = useState<boolean>(false);
  
  // Template & Customization State
  const [selectedTemplate, setSelectedTemplate] = useState<ResumeTemplateId>(() => {
    try {
      const saved = localStorage.getItem(RESUME_TEMPLATE_KEY);
      return (saved as ResumeTemplateId) || 'ats_classic';
    } catch {
      return 'ats_classic';
    }
  });

  const handleTemplateChange = (tmpl: ResumeTemplateId) => {
    setSelectedTemplate(tmpl);
    try {
      localStorage.setItem(RESUME_TEMPLATE_KEY, tmpl);
    } catch {}
  };

  const [showTemplatesModal, setShowTemplatesModal] = useState<boolean>(false);

  // Modal Triggers
  const [showMyResumesModal, setShowMyResumesModal] = useState<boolean>(false);
  const [showVersionsModal, setShowVersionsModal] = useState<boolean>(false);
  const [activeVersionId, setActiveVersionId] = useState<string | null>(null);

  // Bullet Enhancer State
  const [bulletImproveModalOpen, setBulletImproveModalOpen] = useState<boolean>(false);
  const [bulletImproveData, setBulletImproveData] = useState<{
    bullet: string;
    roleOrProject?: string;
    targetDomain?: string;
    onApply?: (newBullet: string) => void;
  } | null>(null);

  // Summary Enhancer State
  const [showSummaryImproveModal, setShowSummaryImproveModal] = useState<boolean>(false);

  // Headline Enhancer State
  const [showHeadlineImproveModal, setShowHeadlineImproveModal] = useState<boolean>(false);

  // Quality Check State
  const [showQualityModal, setShowQualityModal] = useState<boolean>(false);

  // Comparison State & Change Tracking
  const [showComparisonModal, setShowComparisonModal] = useState<boolean>(false);
  const [appliedChanges, setAppliedChanges] = useState<AppliedChangeItem[]>([]);

  // Export Modal State
  const [showExportModal, setShowExportModal] = useState<boolean>(false);

  // Job Tailoring Studio Modal State (Unified workspace & video tabs)
  const [showJobTailoringModal, setShowJobTailoringModal] = useState<boolean>(false);
  const [tailoringModalTab, setTailoringModalTab] = useState<'workspace' | 'video'>('workspace');

  const openTailoringModal = (tab: 'workspace' | 'video' = 'workspace') => {
    if (!isPremium && !isAdmin) {
      openSubscriptionModal();
      return;
    }
    setTailoringModalTab(tab);
    setShowJobTailoringModal(true);
  };

  // Create Resume From Scratch Modal State
  const [showCreateScratchModal, setShowCreateScratchModal] = useState<boolean>(false);

  // View Controls
  const [viewTab, setViewTab] = useState<'split' | 'document' | 'job_match' | 'inspector' | 'learning'>(() => {
    try {
      const saved = localStorage.getItem(RESUME_VIEW_TAB_KEY);
      return (saved as any) || 'split';
    } catch {
      return 'split';
    }
  });

  const handleViewTabChange = (tab: 'split' | 'document' | 'job_match' | 'inspector' | 'learning') => {
    setViewTab(tab);
    try {
      localStorage.setItem(RESUME_VIEW_TAB_KEY, tab);
    } catch {}
  };

  const [sectionAuditTab, setSectionAuditTab] = useState<'all' | 'skill_gaps' | 'experience' | 'projects' | 'summary' | 'improvements'>('all');

  // Change Tracking History for Per-Item Revert
  const [editHistory, setEditHistory] = useState<Array<{ id: string; originalText: string; currentText: string; section: string }>>([]);

  // Raw file stream for authentic canvas rendering
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [activeFileBlob, setActiveFileBlob] = useState<Blob | null>(null);

  // Target Job Description State
  const [targetJobTitle, setTargetJobTitle] = useState<string>('');
  const [targetJobDesc, setTargetJobDesc] = useState<string>('');

  // Interactive LLM Section Enhancer State
  const [enhancerModalOpen, setEnhancerModalOpen] = useState<boolean>(false);
  const [enhancerSection, setEnhancerSection] = useState<'experience' | 'projects' | 'summary' | 'skills'>('experience');
  const [enhancerItemId, setEnhancerItemId] = useState<string | null>(null);
  const [enhancerOriginalContent, setEnhancerOriginalContent] = useState<any>('');
  const [enhancerInstruction, setEnhancerInstruction] = useState<string>('');
  const [enhancerSelectedVariation, setEnhancerSelectedVariation] = useState<string>('');
  const [enhancerCustomPrompt, setEnhancerCustomPrompt] = useState<string>('');
  const [enhancerIsLoading, setEnhancerIsLoading] = useState<boolean>(false);
  const [enhancerResponse, setEnhancerResponse] = useState<SectionEnhanceResponse | null>(null);
  const [enhancerError, setEnhancerError] = useState<string | null>(null);
  const [enhancerSelectedArchetype, setEnhancerSelectedArchetype] = useState<string>('all');
  const [enhancerRegenCount, setEnhancerRegenCount] = useState<number>(0);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const lastLoadedUserIdRef = useRef<string | null | undefined>(undefined);

  // Real-time Dynamic ATS Score derived live from current structured resume and target job description
  const dynamicATS = useMemo(() => {
    return calculateATSScore(
      structuredResume, 
      analysis?.resume_quality_score || 72,
      targetJobDesc,
      targetJobTitle
    );
  }, [structuredResume, analysis?.resume_quality_score, targetJobDesc, targetJobTitle]);

  // Initialize structured resume from analysis result
  const syncResumeState = useCallback((res: ResumeAnalysisResult, explicitUserId?: string | null) => {
    setAnalysis(res);

    let struct: StructuredResume;
    if (res.structured_resume) {
      struct = JSON.parse(JSON.stringify(res.structured_resume));
      if (!struct.personal_info) {
        struct.personal_info = {};
      }
      if (!struct.portfolio) {
        struct.portfolio = [];
      }
      if (struct.personal_info.headline && !struct.headline) {
        struct.headline = struct.personal_info.headline;
      }
      if (struct.headline && !struct.personal_info.headline) {
        struct.personal_info.headline = struct.headline;
      }
      if (struct.personal_info.title && !struct.title) {
        struct.title = struct.personal_info.title;
      }
    } else {
      const skills = res.extracted_skills || [];
      struct = {
        personal_info: {
          full_name: undefined,
          headline: undefined,
          title: undefined,
          email: undefined,
          phone: undefined,
          location: undefined,
          linkedin: undefined,
          github: undefined,
          leetcode: undefined,
          codeforces: undefined,
          codechef: undefined,
          hackerrank: undefined,
          portfolio: undefined,
          links: res.detected_links || [],
          summary: undefined
        },
        summary: undefined,
        skills: skills,
        technical_skills: {},
        experience: (res.extracted_experience || []).map((e, idx) => ({
          id: `exp-${idx + 1}`,
          company: e.company_or_org,
          role: e.role,
          duration: e.duration,
          bullets: e.highlights || []
        })),
        projects: (res.extracted_projects || []).map((p, idx) => ({
          id: `proj-${idx + 1}`,
          title: p.title,
          role_or_tech: p.role_or_tech,
          description: p.description,
          technologies: p.key_technologies || [],
          url: (p as any).url,
          code_url: (p as any).code_url,
          links: (p as any).links || [],
          bullets: [p.description].filter(Boolean) as string[]
        })),
        portfolio: [],
        education: [],
        certifications: []
      };
    }

    setStructuredResume(struct);
    setOriginalStructuredResume(JSON.parse(JSON.stringify(struct)));
    
    const effectiveUserId = explicitUserId !== undefined ? explicitUserId : (user?.id || null);
    const scopedResumeKey = effectiveUserId ? `${RESUME_STORAGE_KEY}_${effectiveUserId}` : `${RESUME_STORAGE_KEY}_guest`;
    const scopedStructKey = effectiveUserId ? `${STRUCTURED_RESUME_STORAGE_KEY}_${effectiveUserId}` : `${STRUCTURED_RESUME_STORAGE_KEY}_guest`;

    try {
      localStorage.setItem(scopedStructKey, JSON.stringify(struct));
      localStorage.setItem(scopedResumeKey, JSON.stringify(res));
      localStorage.setItem(STRUCTURED_RESUME_STORAGE_KEY, JSON.stringify(struct));
      localStorage.setItem(RESUME_STORAGE_KEY, JSON.stringify(res));
    } catch {}
    setEditHistory([]);

    // Dispatch global sync events so all views (App, overview, jobs portal) update in real time
    window.dispatchEvent(new CustomEvent('employai:resume-updated', { detail: res }));
    window.dispatchEvent(new Event('storage'));
  }, [user?.id]);

  const syncAndPersistResume = useCallback((updated: StructuredResume, message?: string) => {
    const fresh: StructuredResume = JSON.parse(JSON.stringify(updated));
    setStructuredResume(fresh);
    
    const effectiveUserId = user?.id || null;
    const scopedResumeKey = effectiveUserId ? `${RESUME_STORAGE_KEY}_${effectiveUserId}` : `${RESUME_STORAGE_KEY}_guest`;
    const scopedStructKey = effectiveUserId ? `${STRUCTURED_RESUME_STORAGE_KEY}_${effectiveUserId}` : `${STRUCTURED_RESUME_STORAGE_KEY}_guest`;

    try {
      localStorage.setItem(scopedStructKey, JSON.stringify(fresh));
      localStorage.setItem(STRUCTURED_RESUME_STORAGE_KEY, JSON.stringify(fresh));
      setAnalysis(prev => {
        const next: ResumeAnalysisResult = prev ? {
          ...prev,
          structured_resume: fresh,
          extracted_skills: fresh.skills || []
        } : {
          id: `local-${Date.now()}`,
          filename: 'My_Resume.pdf',
          detected_domain: 'General',
          resume_quality_score: 75,
          score_breakdown: { structure: 80, content_impact: 75, skill_density: 75, formatting_clarity: 80, overall_quality: 75 },
          strengths: [],
          weaknesses: [],
          extracted_skills: fresh.skills || [],
          extracted_projects: [],
          extracted_experience: [],
          improvements: [],
          improvement_suggestions: [],
          structured_resume: fresh,
          created_at: new Date().toISOString()
        };
        try {
          localStorage.setItem(scopedResumeKey, JSON.stringify(next));
          localStorage.setItem(RESUME_STORAGE_KEY, JSON.stringify(next));
        } catch {}

        // Dispatch global sync events so all views (App, Jobs & Internships portal, overview, interview) update immediately
        window.dispatchEvent(new CustomEvent('employai:resume-updated', { detail: next }));
        window.dispatchEvent(new Event('storage'));

        return next;
      });
    } catch {}

    if (message) {
      setToastMessage(message);
      setTimeout(() => setToastMessage(null), 3500);
    }

    // Persist to backend database so matching and jobs engines reflect genuine additions and removals immediately
    if (isAuthenticated) {
      documentApi.syncStructuredResume(fresh).catch(err => {
        console.warn('Backend sync structured resume notice:', err);
      });
    }
  }, [user?.id, isAuthenticated]);

  const handleUpdateStructuredResume = useCallback((updated: StructuredResume) => {
    syncAndPersistResume(updated, 'Resume data updated and ATS score synchronized.');
  }, [syncAndPersistResume]);

  const loadLatestAnalysis = useCallback(async (forcedUserId?: string | null) => {
    const effectiveUserId = forcedUserId !== undefined ? forcedUserId : (user?.id || null);
    const isAuth = !!effectiveUserId;
    const scopedResumeKey = effectiveUserId ? `${RESUME_STORAGE_KEY}_${effectiveUserId}` : `${RESUME_STORAGE_KEY}_guest`;
    const scopedStructKey = effectiveUserId ? `${STRUCTURED_RESUME_STORAGE_KEY}_${effectiveUserId}` : `${STRUCTURED_RESUME_STORAGE_KEY}_guest`;

    const cachedAnalysisStr = localStorage.getItem(scopedResumeKey) || localStorage.getItem(RESUME_STORAGE_KEY);
    const cachedStructStr = localStorage.getItem(scopedStructKey) || localStorage.getItem(STRUCTURED_RESUME_STORAGE_KEY);

    if ((cachedAnalysisStr && (cachedAnalysisStr.includes('Cloud-Native Career Ecosystem') || cachedAnalysisStr.includes('Tech Solutions & Engineering') || cachedAnalysisStr.includes('Institute of Engineering & Technology'))) ||
        (cachedStructStr && (cachedStructStr.includes('Cloud-Native Career Ecosystem') || cachedStructStr.includes('Tech Solutions & Engineering') || cachedStructStr.includes('Institute of Engineering & Technology')))) {
      clearAllResumeStorage();
      setAnalysis(null);
      setStructuredResume(null);
      setOriginalStructuredResume(null);
      setUploadedFile(null);
      setActiveFileBlob(null);
      setIsLoading(false);
      return;
    }

    if (!isAuth) {
      if (cachedAnalysisStr) {
        try {
          const parsed = JSON.parse(cachedAnalysisStr);
          if (cachedStructStr) {
            parsed.structured_resume = JSON.parse(cachedStructStr);
          }
          syncResumeState(parsed, effectiveUserId);
        } catch {}
      } else {
        setAnalysis(null);
        setStructuredResume(null);
        setOriginalStructuredResume(null);
        setUploadedFile(null);
        setActiveFileBlob(null);
      }
      setIsLoading(false);
      return;
    }

    if (!cachedAnalysisStr) {
      setIsLoading(true);
    }
    setError(null);
    try {
      const res = await documentApi.getLatestAnalysis();
      if (!res) {
        if (cachedAnalysisStr) {
          try {
            const parsed = JSON.parse(cachedAnalysisStr);
            if (cachedStructStr) parsed.structured_resume = JSON.parse(cachedStructStr);
            syncResumeState(parsed, effectiveUserId);
          } catch {}
        }
        setIsLoading(false);
        return;
      }
      if (cachedStructStr && res.structured_resume) {
        try {
          const cached = JSON.parse(cachedStructStr);
          if (cachedAnalysisStr) {
            const prevAnalysis = JSON.parse(cachedAnalysisStr);
            if (prevAnalysis?.id === res.id || prevAnalysis?.document_id === res.document_id) {
              res.structured_resume = cached;
            }
          }
        } catch {}
      }
      syncResumeState(res, effectiveUserId);

      if (res.is_scratch) {
        setUploadedFile(null);
        setActiveFileBlob(null);
      } else {
        try {
          const { blob } = await documentApi.getActiveResumeFileBlob();
          setActiveFileBlob(blob);
        } catch (e) {
          console.warn('Could not preload active resume binary file:', e);
          setActiveFileBlob(null);
        }
      }
    } catch (err: any) {
      if (cachedAnalysisStr) {
        try {
          const parsed = JSON.parse(cachedAnalysisStr);
          if (cachedStructStr) {
            parsed.structured_resume = JSON.parse(cachedStructStr);
          }
          syncResumeState(parsed, effectiveUserId);
        } catch {}
      } else {
        setAnalysis(null);
        setStructuredResume(null);
        setOriginalStructuredResume(null);
        setUploadedFile(null);
        setActiveFileBlob(null);
      }
    } finally {
      setIsLoading(false);
    }
  }, [user?.id, syncResumeState]);

  // Load or re-load analysis whenever active user changes
  useEffect(() => {
    const currentUserId = user?.id || null;
    if (lastLoadedUserIdRef.current !== currentUserId) {
      lastLoadedUserIdRef.current = currentUserId;
      setUploadedFile(null);
      setActiveFileBlob(null);
      loadLatestAnalysis(currentUserId);
    }
  }, [user?.id, loadLatestAnalysis]);

  // Listen to user switch events (e.g. login/register/logout)
  useEffect(() => {
    const handleUserSwitch = (e: any) => {
      const newUser = e.detail;
      const newUserId = newUser?.id || null;
      lastLoadedUserIdRef.current = newUserId;
      setUploadedFile(null);
      setActiveFileBlob(null);
      loadLatestAnalysis(newUserId);
    };
    window.addEventListener('employai:user-switched', handleUserSwitch);
    return () => {
      window.removeEventListener('employai:user-switched', handleUserSwitch);
    };
  }, [loadLatestAnalysis]);

  // Synchronize state when active resume is deleted anywhere in the app
  useEffect(() => {
    const handleResumeUpdated = (e: any) => {
      if (e?.detail === null) {
        setAnalysis(null);
        setStructuredResume(null);
        setOriginalStructuredResume(null);
        setUploadedFile(null);
        setActiveFileBlob(null);
        setTargetJobTitle('');
        setTargetJobDesc('');
      }
    };
    window.addEventListener('employai:resume-updated', handleResumeUpdated);
    return () => {
      window.removeEventListener('employai:resume-updated', handleResumeUpdated);
    };
  }, []);

  // Keep localStorage automatically synchronized with any edits to structuredResume
  useEffect(() => {
    if (structuredResume) {
      const effectiveUserId = user?.id || null;
      const scopedKey = effectiveUserId ? `${STRUCTURED_RESUME_STORAGE_KEY}_${effectiveUserId}` : `${STRUCTURED_RESUME_STORAGE_KEY}_guest`;
      try {
        localStorage.setItem(scopedKey, JSON.stringify(structuredResume));
        if (!effectiveUserId) {
          localStorage.setItem(STRUCTURED_RESUME_STORAGE_KEY, JSON.stringify(structuredResume));
        }
      } catch {}
    }
  }, [structuredResume, user?.id]);

  // Keep localStorage automatically synchronized with any edits to analysis
  useEffect(() => {
    if (analysis) {
      const effectiveUserId = user?.id || null;
      const scopedKey = effectiveUserId ? `${RESUME_STORAGE_KEY}_${effectiveUserId}` : `${RESUME_STORAGE_KEY}_guest`;
      try {
        localStorage.setItem(scopedKey, JSON.stringify(analysis));
        if (!effectiveUserId) {
          localStorage.setItem(RESUME_STORAGE_KEY, JSON.stringify(analysis));
        }
      } catch {}
    }
  }, [analysis, user?.id]);

  const processFileUpload = async (file: File) => {
    if (!isAuthenticated) {
      openAuthModal('login', 'student');
      return;
    }

    setIsUploading(true);
    setUploadScanStep(1);
    setError(null);
    setUploadedFile(file);
    setActiveFileBlob(file);

    const stepTimer1 = setTimeout(() => setUploadScanStep(2), 600);
    const stepTimer2 = setTimeout(() => setUploadScanStep(3), 1300);
    const stepTimer3 = setTimeout(() => setUploadScanStep(4), 2100);
    const stepTimer4 = setTimeout(() => setUploadScanStep(5), 2900);

    try {
      const result = await documentApi.uploadResume(file, targetJobDesc || undefined);
      syncResumeState(result);
      handleViewTabChange('split');
      setToastMessage(`Resume "${file.name}" scanned and verified!`);
      setTimeout(() => setToastMessage(null), 4000);
    } catch (err: any) {
      setError(err?.message || 'Failed to upload and analyze document. Please verify file format.');
    } finally {
      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);
      clearTimeout(stepTimer3);
      clearTimeout(stepTimer4);
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleFileInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    await processFileUpload(files[0]);
  };

  const handleFileDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (!files || files.length === 0) return;
    await processFileUpload(files[0]);
  };

  const handleCreateScratchResume = async (newStructuredResume: StructuredResume, filename?: string) => {
    setIsLoading(true);
    setError(null);
    setUploadedFile(null);
    setActiveFileBlob(null);
    try {
      if (isAuthenticated) {
        const result = await documentApi.createResumeFromScratch({
          title: filename || `${newStructuredResume.personal_info?.full_name || 'My'}_Resume.pdf`,
          structured_resume: newStructuredResume,
          target_job_description: targetJobDesc || undefined
        });
        syncResumeState(result);
      } else {
        const ats = calculateATSScore(newStructuredResume, 85);
        const candidateName = (newStructuredResume.personal_info?.full_name || 'My').trim().replace(/\s+/g, '_');
        const dummyResult: ResumeAnalysisResult = {
          id: `scratch-${Date.now()}`,
          filename: filename || `${candidateName}_Resume.pdf`,
          detected_domain: 'Computer Science & Engineering',
          resume_quality_score: ats.overall_score || 85,
          score_breakdown: ats.score_breakdown,
          strengths: ['Structured sections with clear hierarchy', 'Core technical skills and quantified projects present'],
          weaknesses: [],
          extracted_skills: newStructuredResume.skills || [],
          extracted_projects: (newStructuredResume.projects || []).map(p => ({
            title: p.title,
            role_or_tech: p.role_or_tech,
            description: p.description || '',
            key_technologies: p.technologies || [],
            url: p.url,
            code_url: p.code_url
          })),
          extracted_experience: (newStructuredResume.experience || []).map(e => ({
            company_or_org: e.company,
            role: e.role,
            duration: e.duration,
            highlights: e.bullets || []
          })),
          improvements: [],
          structured_resume: newStructuredResume,
          created_at: new Date().toISOString(),
          is_scratch: true,
          file_url: undefined,
          detected_links: []
        };
        syncResumeState(dummyResult);
      }
      handleViewTabChange('split');
      setToastMessage('Resume successfully created from scratch! Live ATS auditing and template customization are now active.');
      setTimeout(() => setToastMessage(null), 4000);
    } catch (err: any) {
      console.warn('Backend save fallback for scratch resume:', err);
      const ats = calculateATSScore(newStructuredResume, 85);
      const candidateName = (newStructuredResume.personal_info?.full_name || 'My').trim().replace(/\s+/g, '_');
      const dummyResult: ResumeAnalysisResult = {
        id: `scratch-${Date.now()}`,
        filename: filename || `${candidateName}_Resume.pdf`,
        detected_domain: 'Computer Science & Engineering',
        resume_quality_score: ats.overall_score || 85,
        score_breakdown: ats.score_breakdown,
        strengths: ['Structured sections with clear hierarchy', 'Skills and project metrics present'],
        weaknesses: [],
        extracted_skills: newStructuredResume.skills || [],
        extracted_projects: (newStructuredResume.projects || []).map(p => ({
          title: p.title,
          role_or_tech: p.role_or_tech,
          description: p.description || '',
          key_technologies: p.technologies || [],
          url: p.url,
          code_url: p.code_url
        })),
        extracted_experience: (newStructuredResume.experience || []).map(e => ({
          company_or_org: e.company,
          role: e.role,
          duration: e.duration,
          highlights: e.bullets || []
        })),
        improvements: [],
        structured_resume: newStructuredResume,
        created_at: new Date().toISOString(),
        is_scratch: true,
        file_url: undefined,
        detected_links: []
      };
      syncResumeState(dummyResult);
      handleViewTabChange('split');
      setToastMessage('Resume created and loaded into AI Resume Studio!');
      setTimeout(() => setToastMessage(null), 4000);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteResume = async () => {
    setIsDeleting(true);
    setDeleteModalError(null);
    setError(null);
    try {
      try {
        await documentApi.deleteActiveResume();
      } catch (apiErr: any) {
        console.warn('Backend delete resume notice (proceeding with local purge):', apiErr);
      }
      setAnalysis(null);
      setStructuredResume(null);
      setOriginalStructuredResume(null);
      setUploadedFile(null);
      setActiveFileBlob(null);
      setTargetJobTitle('');
      setTargetJobDesc('');

      const effectiveUserId = user?.id || null;
      const scopedResumeKey = effectiveUserId ? `${RESUME_STORAGE_KEY}_${effectiveUserId}` : `${RESUME_STORAGE_KEY}_guest`;
      const scopedStructKey = effectiveUserId ? `${STRUCTURED_RESUME_STORAGE_KEY}_${effectiveUserId}` : `${STRUCTURED_RESUME_STORAGE_KEY}_guest`;

      clearAllResumeStorage();
      try {
        localStorage.removeItem(RESUME_STORAGE_KEY);
        localStorage.removeItem(STRUCTURED_RESUME_STORAGE_KEY);
        localStorage.removeItem(scopedResumeKey);
        localStorage.removeItem(scopedStructKey);
        localStorage.removeItem(RESUME_VIEW_TAB_KEY);
        localStorage.removeItem(RESUME_TEMPLATE_KEY);
      } catch {}

      // Dispatch global sync events so other views (App, overview, etc.) update immediately
      window.dispatchEvent(new CustomEvent('employai:resume-updated', { detail: null }));
      window.dispatchEvent(new Event('storage'));

      setShowDeleteModal(false);
      setToastMessage('Active resume and associated analysis removed.');
      setTimeout(() => setToastMessage(null), 4000);
    } catch (err: any) {
      setDeleteModalError(err?.message || 'Failed to delete active resume. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  // -------------------------------------------------------------
  // MY RESUMES & VERSIONING HANDLERS

  const handleOpenSavedResume = async (docId: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await documentApi.openResume(docId);
      syncResumeState(res);
      if (res.is_scratch) {
        setUploadedFile(null);
        setActiveFileBlob(null);
      } else {
        try {
          const { blob } = await documentApi.getActiveResumeFileBlob();
          setActiveFileBlob(blob);
          setUploadedFile(null);
        } catch {
          setActiveFileBlob(null);
        }
      }
      setToastMessage(`Opened resume: ${res.filename}`);
      setTimeout(() => setToastMessage(null), 3500);
    } catch (err: any) {
      setError(err?.message || 'Failed to load saved resume.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSwitchVersion = (ver: ResumeVersionItem) => {
    if (ver.structured_resume) {
      setStructuredResume(JSON.parse(JSON.stringify(ver.structured_resume)));
      setActiveVersionId(ver.version_id);
      setToastMessage(`Switched to version: ${ver.version_name}`);
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  const handleSaveNewVersion = async (versionName: string, targetJob?: string) => {
    if (!analysis?.document_id || !structuredResume) return;
    const newVer = await documentApi.createResumeVersion(analysis.document_id, {
      version_name: versionName,
      target_job: targetJob,
      structured_resume: structuredResume
    });
    setActiveVersionId(newVer.version_id);
    setToastMessage(`Saved version "${versionName}" successfully!`);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleApplyTailoredResume = (
    tailoredResume: StructuredResume,
    targetJob: string,
    _atsScore: number
  ) => {
    syncAndPersistResume(tailoredResume);
    if (targetJob) setTargetJobTitle(targetJob);
    if (_atsScore && analysis) {
      setAnalysis(prev => prev ? {
        ...prev,
        resume_quality_score: Math.max(prev.resume_quality_score || 0, _atsScore)
      } : null);
    }
    setViewTab('split');
    setToastMessage(`✨ Applied job-specific tailored resume for "${targetJob}"! Live ATS score updated to ${_atsScore}/100.`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleSaveTailoredVersionAsNew = async (
    versionName: string,
    targetJob: string,
    tailoredResume: StructuredResume,
    atsScore: number
  ) => {
    if (!analysis?.document_id) return;
    const newVer = await documentApi.saveTailoredResumeVersion(analysis.document_id, {
      version_name: versionName,
      target_job: targetJob,
      structured_resume: tailoredResume,
      job_description: targetJobDesc || undefined,
      ats_score: atsScore
    });
    setActiveVersionId(newVer.version_id);
    setToastMessage(`Saved job-tailored version "${versionName}"!`);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // -------------------------------------------------------------
  // TARGETED AI ENHANCERS HANDLERS
  // -------------------------------------------------------------

  const handleOpenBulletEnhancer = (
    bullet: string,
    roleOrProject?: string,
    targetDomain?: string,
    onApplyCallback?: (newBullet: string) => void
  ) => {
    setBulletImproveData({
      bullet,
      roleOrProject,
      targetDomain: targetDomain || analysis?.detected_domain,
      onApply: onApplyCallback
    });
    setBulletImproveModalOpen(true);
  };

  const handleApplyBulletImprovement = (newBullet: string, rationale?: string) => {
    if (bulletImproveData?.onApply) {
      bulletImproveData.onApply(newBullet);
    } else if (structuredResume) {
      const updated: StructuredResume = JSON.parse(JSON.stringify(structuredResume));
      const orig = bulletImproveData?.bullet || '';
      let replaced = false;
      (updated.experience || []).forEach(exp => {
        exp.bullets = (exp.bullets || []).map(b => {
          if (b === orig || (orig && b.includes(orig.slice(0, 25)))) {
            replaced = true;
            return newBullet;
          }
          return b;
        });
      });
      if (!replaced) {
        (updated.projects || []).forEach(proj => {
          proj.bullets = (proj.bullets || []).map(b => {
            if (b === orig || (orig && b.includes(orig.slice(0, 25)))) {
              replaced = true;
              return newBullet;
            }
            return b;
          });
        });
      }
      syncAndPersistResume(updated, 'Bullet improvement applied! (+1 ATS Lift)');
    }

    const changeItem: AppliedChangeItem = {
      id: `change-${Date.now()}`,
      timestamp: new Date().toISOString(),
      description: rationale || 'AI Bullet STAR optimization',
      section: 'experience',
      originalText: bulletImproveData?.bullet || '',
      newText: newBullet
    };
    setAppliedChanges(prev => [changeItem, ...prev]);
  };

  const handleOpenSummaryEnhancer = () => {
    setShowSummaryImproveModal(true);
  };

  const handleApplySummaryImprovement = (newSummary: string) => {
    if (!structuredResume) return;
    const oldSummary = structuredResume.summary || structuredResume.personal_info?.summary || '';
    const updated: StructuredResume = {
      ...structuredResume,
      summary: newSummary,
      personal_info: {
        ...(structuredResume.personal_info || {}),
        summary: newSummary
      }
    };
    syncAndPersistResume(updated, 'Professional Summary updated!');
    const changeItem: AppliedChangeItem = {
      id: `change-${Date.now()}`,
      timestamp: new Date().toISOString(),
      description: 'AI Summary optimization',
      section: 'summary',
      originalText: oldSummary,
      newText: newSummary
    };
    setAppliedChanges(prev => [changeItem, ...prev]);
  };

  const handleOpenHeadlineEnhancer = () => {
    setShowHeadlineImproveModal(true);
  };

  const handleApplyHeadline = (newHeadline: string) => {
    if (!structuredResume) return;
    const oldHeadline = structuredResume.personal_info?.headline || structuredResume.headline || '';
    const updated: StructuredResume = {
      ...structuredResume,
      headline: newHeadline,
      title: newHeadline,
      personal_info: {
        ...(structuredResume.personal_info || {}),
        headline: newHeadline,
        title: newHeadline
      }
    };
    syncAndPersistResume(updated, 'Professional Headline updated!');
    const changeItem: AppliedChangeItem = {
      id: `change-${Date.now()}`,
      timestamp: new Date().toISOString(),
      description: 'AI Headline generation',
      section: 'headline',
      originalText: oldHeadline,
      newText: newHeadline
    };
    setAppliedChanges(prev => [changeItem, ...prev]);
  };

  const handleQualityApplyFix = (issue: QualityIssueItem) => {
    if (!structuredResume || !issue.suggested_fix) return;
    const updated: StructuredResume = JSON.parse(JSON.stringify(structuredResume));
    let applied = false;

    (updated.experience || []).forEach(exp => {
      exp.bullets = (exp.bullets || []).map(b => {
        if (issue.snippet && b.includes(issue.snippet)) {
          applied = true;
          return issue.suggested_fix!;
        }
        return b;
      });
    });

    if (!applied) {
      (updated.projects || []).forEach(proj => {
        proj.bullets = (proj.bullets || []).map(b => {
          if (issue.snippet && b.includes(issue.snippet)) {
            applied = true;
            return issue.suggested_fix!;
          }
          return b;
        });
      });
    }

    if (applied) {
      syncAndPersistResume(updated, `Applied fix for: ${issue.issue_title}`);
      const changeItem: AppliedChangeItem = {
        id: `change-${Date.now()}`,
        timestamp: new Date().toISOString(),
        description: `Quality check fix: ${issue.issue_title}`,
        section: 'general',
        originalText: issue.snippet,
        newText: issue.suggested_fix
      };
      setAppliedChanges(prev => [changeItem, ...prev]);
    }
  };

  const handleUndoChange = (changeId: string) => {
    const item = appliedChanges.find(c => c.id === changeId);
    if (!item || !structuredResume) return;

    const updated: StructuredResume = JSON.parse(JSON.stringify(structuredResume));

    if (item.section === 'summary') {
      updated.summary = item.originalText;
      if (updated.personal_info) updated.personal_info.summary = item.originalText;
    } else if (item.section === 'headline') {
      updated.headline = item.originalText;
      if (updated.personal_info) updated.personal_info.headline = item.originalText;
    } else {
      (updated.experience || []).forEach(exp => {
        exp.bullets = (exp.bullets || []).map(b => (b === item.newText ? item.originalText : b));
      });
      (updated.projects || []).forEach(proj => {
        proj.bullets = (proj.bullets || []).map(b => (b === item.newText ? item.originalText : b));
      });
    }

    syncAndPersistResume(updated, `Reverted change: ${item.description}`);
    setAppliedChanges(prev => prev.filter(c => c.id !== changeId));
  };

  const handleRevertAllBaseline = () => {
    if (!originalStructuredResume) return;
    syncAndPersistResume(JSON.parse(JSON.stringify(originalStructuredResume)), 'Restored original baseline resume.');
    setAppliedChanges([]);
    setEditHistory([]);
    setToastMessage('Reset resume back to original uploaded baseline.');
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleAnalyzeJobDescription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetJobDesc.trim()) return;

    setIsAnalyzingJob(true);
    setError(null);
    try {
      const updated = await documentApi.analyzeWithJobDescription(targetJobDesc, targetJobTitle);
      syncResumeState(updated);
      setViewTab('job_match');
    } catch (err: any) {
      setError(err?.message || 'Job description evaluation failed. Please try again.');
    } finally {
      setIsAnalyzingJob(false);
    }
  };

  const handleDirectAutoTailor = async () => {
    if (!targetJobDesc.trim()) {
      setError('Please paste a job description first.');
      return;
    }
    setIsAnalyzingJob(true);
    setError(null);
    try {
      // 1. Request tailored recommendation from API
      const result = await documentApi.tailorResumeToJob({
        document_id: analysis?.document_id,
        job_description: targetJobDesc,
        structured_resume: structuredResume
      });

      // 2. Extract detailed JD structure (skills, experience, qualities, work)
      const jdKeywords = extractJDKeywords(targetJobDesc, targetJobTitle || result.target_job_title);
      const jobDetails = extractJobDetails(targetJobDesc, targetJobTitle || result.target_job_title);
      const effectiveTitle = result.target_job_title || targetJobTitle.trim() || jobDetails.targetJobTitle || jdKeywords.targetJobTitle || 'Target Professional';

      // 3. Clone structured resume
      const updatedStruct: StructuredResume = result.tailored_structured_resume 
        ? JSON.parse(JSON.stringify(result.tailored_structured_resume))
        : JSON.parse(JSON.stringify(structuredResume || {}));

      // 4. Merge all relevant JD skills & technical keywords into Skills section
      const existingSkills = new Set((updatedStruct.skills || []).map(s => s.toLowerCase()));
      const skillsToAdd: string[] = [];
      const candidateSkills = [
        ...(result.added_skills || []),
        ...(result.job_parsed?.required_skills || []),
        ...jobDetails.skills,
        ...jdKeywords.keywords
      ];
      (result.missing_skills || []).forEach(m => {
        const sName = typeof m === 'string' ? m : m?.requirement || (m as any)?.skill || '';
        if (sName) candidateSkills.push(sName);
      });

      candidateSkills.forEach(s => {
        if (s && !existingSkills.has(s.toLowerCase())) {
          existingSkills.add(s.toLowerCase());
          skillsToAdd.push(s);
        }
      });
      if (skillsToAdd.length > 0) {
        updatedStruct.skills = [...(updatedStruct.skills || []), ...skillsToAdd];
      }

      // 5. Add and enrich Experience with JD action verbs, responsibilities & tools
      if (!updatedStruct.experience) {
        updatedStruct.experience = [];
      }
      const topTech = (jobDetails.skills.length > 0 ? jobDetails.skills : jdKeywords.keywords).slice(0, 4).join(', ') || 'modern frameworks & tools';
      const primaryAction = jdKeywords.actionVerbs[0] || 'Architected';
      const secondaryAction = jdKeywords.actionVerbs[1] || 'Engineered';

      if (updatedStruct.experience.length > 0) {
        // Candidate has existing experience: enrich first experience entry with tailored JD responsibility & metrics
        const firstExp = updatedStruct.experience[0];
        const currentBullets = firstExp.bullets || [];
        const hasTailoredBullet = currentBullets.some((b: string) =>
          b.toLowerCase().includes(primaryAction.toLowerCase()) ||
          b.toLowerCase().includes(effectiveTitle.toLowerCase())
        );

        if (!hasTailoredBullet) {
          const tailoredBullet1 = `${primaryAction} and deployed scalable initiatives utilizing ${topTech}, delivering 28% higher efficiency and cross-functional alignment with ${effectiveTitle} objectives.`;
          const tailoredBullet2 = `${secondaryAction} mission-critical workflows with automated verification, reducing operational latency and maintaining high-availability enterprise standards.`;
          
          firstExp.bullets = [tailoredBullet1, ...currentBullets];
          if (firstExp.bullets.length < 4) firstExp.bullets.push(tailoredBullet2);
        }
      } else {
        // Candidate has no experience: generate a comprehensive target role experience entry
        const starterBullets = [
          `${primaryAction} and scaled enterprise-grade initiatives utilizing ${topTech}, optimizing delivery cycles by 30% and exceeding stakeholder SLAs.`,
          `${secondaryAction} end-to-end architectures adhering to high-availability patterns, automated CI/CD pipelines, and industry best practices.`,
          `Spearheaded cross-functional technical execution for core ${effectiveTitle} responsibilities, ensuring seamless system integration and data integrity.`
        ];
        updatedStruct.experience = [{
          role: effectiveTitle,
          company: 'Professional & Client Solutions',
          location: 'Remote / Hybrid',
          duration: '2023 - Present',
          bullets: starterBullets
        }];
      }

      // 6. Update Headline with target role and core skill keywords
      const headlineSkills = (updatedStruct.skills || []).slice(0, 4).join(' • ');
      updatedStruct.headline = `${effectiveTitle} | ${headlineSkills || 'Core Competencies'}`;
      if (!updatedStruct.personal_info) updatedStruct.personal_info = {};
      updatedStruct.personal_info.headline = updatedStruct.headline;
      updatedStruct.personal_info.title = effectiveTitle;

      // 7. Update Professional Summary synthesizing Experience, Qualities, Work, and Skills
      const richTailoredSummary = generateTailoredProfessionalSummary({
        jobTitle: effectiveTitle,
        skills: updatedStruct.skills || [],
        experienceDetails: jobDetails.experienceDetails,
        qualities: jobDetails.qualities,
        workResponsibilities: jobDetails.workResponsibilities,
        existingSummary: updatedStruct.summary || updatedStruct.personal_info?.summary
      });
      updatedStruct.summary = richTailoredSummary;
      updatedStruct.personal_info.summary = richTailoredSummary;

      // 8. Examine ATS score accordingly against the target job description
      const atsEvaluation = calculateATSScore(
        updatedStruct,
        analysis?.resume_quality_score || 78,
        targetJobDesc,
        effectiveTitle
      );

      if (analysis) {
        setAnalysis(prev => prev ? {
          ...prev,
          resume_quality_score: Math.max(prev.resume_quality_score || 0, atsEvaluation.overall_score),
          score_breakdown: atsEvaluation.score_breakdown
        } : null);
      }

      // 9. Update application state and notify user
      syncAndPersistResume(updatedStruct);
      setTargetJobTitle(effectiveTitle);
      setViewTab('split');
      setToastMessage(`✨ Tailored resume for "${effectiveTitle}"! Added ${skillsToAdd.length} skills to Skills section and enriched Summary with target experience, qualities & work scope (ATS: ${atsEvaluation.overall_score}/100).`);
      setTimeout(() => setToastMessage(null), 5000);
    } catch (err: any) {
      setError(err?.message || 'Failed to auto-tailor resume. Please try again.');
    } finally {
      setIsAnalyzingJob(false);
    }
  };


  const handleOpenEnhancer = async (
    section: 'experience' | 'projects' | 'summary' | 'skills',
    itemId: string | null,
    content: any,
    defaultInstruction?: string
  ) => {
    setEnhancerSection(section);
    setEnhancerItemId(itemId);
    setEnhancerOriginalContent(content);
    setEnhancerInstruction(defaultInstruction || 'Make it quantifiable with STAR method and diverse power action verbs.');
    setEnhancerCustomPrompt('');
    setEnhancerSelectedArchetype('all');
    setEnhancerRegenCount(0);
    setEnhancerModalOpen(true);
    setEnhancerIsLoading(true);
    setEnhancerError(null);
    setEnhancerResponse(null);

    try {
      const res = await documentApi.enhanceSection({
        section,
        item_id: itemId || undefined,
        current_content: content,
        target_domain: analysis?.detected_domain || 'General Professional',
        target_role: targetJobTitle || undefined,
        instruction: defaultInstruction
      });
      setEnhancerResponse(res);
      setEnhancerSelectedVariation(res.enhanced_content || res.suggested_bullets?.[0] || '');
    } catch (err: any) {
      console.warn('Backend enhancer failed, generating client-side STAR suggestions:', err);
      const fallback = generateClientSectionEnhance({
        section,
        item_id: itemId || undefined,
        current_content: content,
        target_domain: analysis?.detected_domain || 'General Professional',
        target_role: targetJobTitle || undefined,
        instruction: defaultInstruction
      });
      setEnhancerResponse(fallback);
      setEnhancerSelectedVariation(fallback.enhanced_content || fallback.suggested_bullets?.[0] || '');
    } finally {
      setEnhancerIsLoading(false);
    }
  };

  const handleRegenerateEnhancement = async (overrideArchetype?: string) => {
    if (!enhancerSection) return;
    const archId = overrideArchetype || enhancerSelectedArchetype;
    if (overrideArchetype) {
      setEnhancerSelectedArchetype(overrideArchetype);
    }
    const nextCount = enhancerRegenCount + 1;
    setEnhancerRegenCount(nextCount);
    setEnhancerIsLoading(true);
    setEnhancerError(null);

    const archetypeObj = ENHANCER_ARCHETYPES.find(a => a.id === archId);
    const combinedInstruction = [
      enhancerCustomPrompt || enhancerInstruction,
      archetypeObj && archetypeObj.id !== 'all' ? `Style Focus: ${archetypeObj.prompt}` : `Use varied, fresh power action verbs across diverse archetypes (Cycle #${nextCount}).`
    ].filter(Boolean).join(' | ');

    try {
      const res = await documentApi.enhanceSection({
        section: enhancerSection,
        item_id: enhancerItemId || undefined,
        current_content: enhancerOriginalContent,
        target_domain: analysis?.detected_domain || 'General Professional',
        target_role: targetJobTitle || undefined,
        instruction: combinedInstruction
      });
      setEnhancerResponse(res);
      setEnhancerSelectedVariation(res.enhanced_content || res.suggested_bullets?.[0] || '');
    } catch (err: any) {
      console.warn('Backend enhancer failed, generating client-side STAR suggestions:', err);
      const fallback = generateClientSectionEnhance({
        section: enhancerSection,
        item_id: enhancerItemId || undefined,
        current_content: enhancerOriginalContent,
        target_domain: analysis?.detected_domain || 'General Professional',
        target_role: targetJobTitle || undefined,
        instruction: combinedInstruction
      });
      setEnhancerResponse(fallback);
      setEnhancerSelectedVariation(fallback.enhanced_content || fallback.suggested_bullets?.[0] || '');
    } finally {
      setEnhancerIsLoading(false);
    }
  };

  const handleApplyEnhancement = (contentToApply: string) => {
    if (!structuredResume || !contentToApply.trim()) return;
    const updated: StructuredResume = JSON.parse(JSON.stringify(structuredResume));

    const historyId = `edit-${Date.now()}`;
    const originalText = typeof enhancerOriginalContent === 'string' ? enhancerOriginalContent : '';

    if (enhancerSection === 'summary') {
      updated.summary = contentToApply;
      if (updated.personal_info) updated.personal_info.summary = contentToApply;
      setEditHistory(prev => [{ id: historyId, originalText, currentText: contentToApply, section: 'summary' }, ...prev]);
    } else if (enhancerSection === 'skills') {
      if (!updated.skills.includes(contentToApply)) {
        updated.skills = [...updated.skills, contentToApply];
      }
    } else if (enhancerSection === 'experience') {
      let replaced = false;
      (updated.experience || []).forEach(exp => {
        if (enhancerItemId && (exp.id === enhancerItemId || exp.company === enhancerItemId)) {
          exp.bullets = (exp.bullets || []).map(b => {
            if (b === enhancerOriginalContent || (originalText && b.trim() === originalText.trim())) {
              replaced = true;
              return contentToApply;
            }
            return b;
          });
          if (!replaced && exp.bullets.length === 0) {
            exp.bullets = [contentToApply];
            replaced = true;
          }
        } else if (!replaced) {
          exp.bullets = (exp.bullets || []).map(b => {
            if (b === enhancerOriginalContent || (originalText && b.trim() === originalText.trim()) || (originalText && b.includes(originalText.slice(0, 20)))) {
              replaced = true;
              return contentToApply;
            }
            return b;
          });
        }
      });
      if (!replaced && (updated.experience || []).length > 0 && updated.experience[0].bullets?.length > 0) {
        updated.experience[0].bullets[0] = contentToApply;
      }
      setEditHistory(prev => [{ id: historyId, originalText, currentText: contentToApply, section: 'experience' }, ...prev]);
    } else if (enhancerSection === 'projects') {
      let replaced = false;
      (updated.projects || []).forEach(proj => {
        if (enhancerItemId && (proj.id === enhancerItemId || proj.title === enhancerItemId)) {
          proj.bullets = (proj.bullets || []).map(b => {
            if (b === enhancerOriginalContent || (originalText && b.trim() === originalText.trim())) {
              replaced = true;
              return contentToApply;
            }
            return b;
          });
          if (proj.description === enhancerOriginalContent || (originalText && proj.description?.trim() === originalText.trim())) {
            proj.description = contentToApply;
            replaced = true;
          }
          if (proj.bullets.length === 0 && !replaced) {
            proj.bullets = [contentToApply];
            replaced = true;
          }
        } else if (!replaced) {
          proj.bullets = (proj.bullets || []).map(b => {
            if (b === enhancerOriginalContent || (originalText && b.trim() === originalText.trim()) || (originalText && b.includes(originalText.slice(0, 20)))) {
              replaced = true;
              return contentToApply;
            }
            return b;
          });
          if (!replaced && (proj.description === enhancerOriginalContent || (originalText && proj.description?.trim() === originalText.trim()))) {
            replaced = true;
            proj.description = contentToApply;
          }
        }
      });
      if (!replaced && (updated.projects || []).length > 0 && updated.projects[0].bullets?.length > 0) {
        updated.projects[0].bullets[0] = contentToApply;
      }
      setEditHistory(prev => [{ id: historyId, originalText, currentText: contentToApply, section: 'projects' }, ...prev]);
    }

    setEnhancerModalOpen(false);
    syncAndPersistResume(updated, `Enhanced ${enhancerSection} with high-impact STAR wording! Resume updated in real-time.`);
  };

  const handleAddSkillFromGap = (skillName: string) => {
    if (!structuredResume) return;
    const cleanTarget = skillName.trim();
    if (!cleanTarget) return;
    if ((structuredResume.skills || []).some(s => s.trim().toLowerCase() === cleanTarget.toLowerCase())) {
      setToastMessage(`"${cleanTarget}" is already in your skills list.`);
      setTimeout(() => setToastMessage(null), 3000);
      return;
    }
    const updated = {
      ...structuredResume,
      skills: [...(structuredResume.skills || []), cleanTarget]
    };

    if (analysis) {
      const updatedAnalysis = { ...analysis };
      if (updatedAnalysis.extracted_skills && !updatedAnalysis.extracted_skills.some(s => s.trim().toLowerCase() === cleanTarget.toLowerCase())) {
        updatedAnalysis.extracted_skills = [...updatedAnalysis.extracted_skills, cleanTarget];
      }
      setAnalysis(updatedAnalysis);
    }

    syncAndPersistResume(updated, `Added "${cleanTarget}" to resume! Real-time ATS Skill Density lifted (+1 ATS).`);
  };

  const handleRemoveSkill = (skillName: string) => {
    if (!structuredResume) return;
    const cleanTarget = skillName.trim().toLowerCase();
    const updated = {
      ...structuredResume,
      skills: (structuredResume.skills || []).filter(s => s.trim().toLowerCase() !== cleanTarget)
    };
    if (analysis) {
      const updatedAnalysis = { ...analysis };
      if (updatedAnalysis.extracted_skills) {
        updatedAnalysis.extracted_skills = updatedAnalysis.extracted_skills.filter(s => s.trim().toLowerCase() !== cleanTarget);
      }
      setAnalysis(updatedAnalysis);
    }
    syncAndPersistResume(updated, `Removed "${skillName}" from resume.`);
  };


  const handleApplyImprovement = (index: number) => {
    if (!analysis || !structuredResume) return;
    const updatedAnalysis = { ...analysis };
    const list = updatedAnalysis.improvements || updatedAnalysis.improvement_suggestions || [];
    const imp = list[index];

    if (imp && !imp.is_applied) {
      imp.is_applied = true;
      setAnalysis(updatedAnalysis);

      const updatedResume = { ...structuredResume };
      let replaced = false;
      const targetImproved = imp.suggested_bullet || imp.improved_bullet || '';
      const orig = imp.original_bullet.trim();

      (updatedResume.experience || []).forEach(exp => {
        exp.bullets = (exp.bullets || []).map(b => {
          if (b.trim().toLowerCase() === orig.toLowerCase() || b.includes(orig.slice(0, 20))) {
            replaced = true;
            return targetImproved;
          }
          return b;
        });
      });

      if (!replaced) {
        (updatedResume.projects || []).forEach(proj => {
          proj.bullets = (proj.bullets || []).map(b => {
            if (b.trim().toLowerCase() === orig.toLowerCase() || b.includes(orig.slice(0, 20))) {
              replaced = true;
              return targetImproved;
            }
            return b;
          });
        });
      }

      if (!replaced) {
        if (imp.section.toLowerCase().includes('project') && (updatedResume.projects || []).length > 0 && updatedResume.projects[0].bullets?.length > 0) {
          updatedResume.projects[0].bullets[0] = targetImproved;
        } else if ((updatedResume.experience || []).length > 0 && updatedResume.experience[0].bullets?.length > 0) {
          updatedResume.experience[0].bullets[0] = targetImproved;
        }
      }

      syncAndPersistResume(updatedResume, `Applied STAR improvement (+1 ATS)!`);
    }
  };

  const handleRevertSingleImprovement = (index: number) => {
    if (!analysis || !structuredResume) return;
    const updatedAnalysis = { ...analysis };
    const list = updatedAnalysis.improvements || updatedAnalysis.improvement_suggestions || [];
    const imp = list[index];

    if (imp && imp.is_applied) {
      imp.is_applied = false;
      setAnalysis(updatedAnalysis);

      const updatedResume = { ...structuredResume };
      const targetImproved = (imp.suggested_bullet || imp.improved_bullet || '').trim();
      const orig = imp.original_bullet;

      (updatedResume.experience || []).forEach(exp => {
        exp.bullets = (exp.bullets || []).map(b => (b.trim() === targetImproved ? orig : b));
      });

      (updatedResume.projects || []).forEach(proj => {
        proj.bullets = (proj.bullets || []).map(b => (b.trim() === targetImproved ? orig : b));
      });

      syncAndPersistResume(updatedResume, `Reverted bullet back to original phrasing.`);
    }
  };

  const isBulletOptimized = useCallback((bullet: string): boolean => {
    if (!bullet) return false;
    const inImprovements = (analysis?.improvements || analysis?.improvement_suggestions || []).some(
      imp => imp.is_applied && (imp.suggested_bullet === bullet || imp.improved_bullet === bullet)
    );
    if (inImprovements) return true;
    const inHistory = (editHistory || []).some(
      h => h.currentText === bullet || (bullet.includes(h.currentText) && h.currentText.length > 10)
    );
    return inHistory;
  }, [analysis, editHistory]);

  const handleRevertBullet = useCallback((
    section: 'experience' | 'projects' | 'portfolio' | 'summary',
    itemId: string | null,
    currentBullet: string
  ) => {
    if (!structuredResume) return;

    let originalText: string | null = null;

    // 1. Check editHistory
    const histIdx = editHistory.findIndex(
      h => h.currentText === currentBullet || (currentBullet && currentBullet.includes(h.currentText) && h.currentText.length > 10)
    );
    if (histIdx !== -1) {
      originalText = editHistory[histIdx].originalText;
      setEditHistory(prev => prev.filter((_, i) => i !== histIdx));
    }

    // 2. Check improvements
    if (analysis) {
      const updatedAnalysis = { ...analysis };
      const list = updatedAnalysis.improvements || updatedAnalysis.improvement_suggestions || [];
      const imp = list.find(
        i => i.is_applied && (i.suggested_bullet === currentBullet || i.improved_bullet === currentBullet || (currentBullet && currentBullet.includes(i.suggested_bullet || i.improved_bullet || '___nonexistent___')))
      );
      if (imp) {
        imp.is_applied = false;
        if (!originalText) originalText = imp.original_bullet;
        setAnalysis(updatedAnalysis);
      }
    }

    // 3. Check originalStructuredResume baseline
    if (!originalText && originalStructuredResume) {
      if (section === 'experience') {
        const origExp = (originalStructuredResume.experience || []).find(e => itemId && (e.id === itemId || e.company === itemId));
        if (origExp && origExp.bullets && origExp.bullets.length > 0) {
          originalText = origExp.bullets[0];
        }
      } else if (section === 'projects') {
        const origProj = (originalStructuredResume.projects || []).find(p => itemId && (p.id === itemId || p.title === itemId));
        if (origProj && origProj.bullets && origProj.bullets.length > 0) {
          originalText = origProj.bullets[0];
        }
      } else if (section === 'portfolio') {
        const origPort = (originalStructuredResume.portfolio || []).find(p => itemId && (p.id === itemId || p.title === itemId));
        if (origPort && origPort.bullets && origPort.bullets.length > 0) {
          originalText = origPort.bullets[0];
        }
      }
    }

    if (!originalText) {
      originalText = currentBullet;
    }

    const updated: StructuredResume = JSON.parse(JSON.stringify(structuredResume));

    if (section === 'experience') {
      (updated.experience || []).forEach(exp => {
        if (!itemId || exp.id === itemId || exp.company === itemId) {
          exp.bullets = (exp.bullets || []).map(b => (b === currentBullet ? originalText! : b));
        }
      });
    } else if (section === 'projects') {
      (updated.projects || []).forEach(proj => {
        if (!itemId || proj.id === itemId || proj.title === itemId) {
          proj.bullets = (proj.bullets || []).map(b => (b === currentBullet ? originalText! : b));
          if (proj.description === currentBullet) {
            proj.description = originalText!;
          }
        }
      });
    } else if (section === 'portfolio') {
      (updated.portfolio || []).forEach(port => {
        if (!itemId || port.id === itemId || port.title === itemId) {
          port.bullets = (port.bullets || []).map(b => (b === currentBullet ? originalText! : b));
          if (port.description === currentBullet) {
            port.description = originalText!;
          }
        }
      });
    }

    setStructuredResume(updated);
    setToastMessage('Removed AI suggestion and restored original phrasing.');
    setTimeout(() => setToastMessage(null), 3000);
  }, [structuredResume, editHistory, analysis, originalStructuredResume]);

  const handleRevertSummary = useCallback(() => {
    if (!structuredResume) return;

    let origSummary = '';
    const histIdx = editHistory.findIndex(h => h.section === 'summary');
    if (histIdx !== -1) {
      origSummary = editHistory[histIdx].originalText;
      setEditHistory(prev => prev.filter((_, i) => i !== histIdx));
    } else if (originalStructuredResume) {
      origSummary = originalStructuredResume.summary || originalStructuredResume.personal_info?.summary || '';
    }

    const updated: StructuredResume = JSON.parse(JSON.stringify(structuredResume));
    updated.summary = origSummary || undefined;
    if (updated.personal_info) {
      updated.personal_info.summary = origSummary || undefined;
    }

    setStructuredResume(updated);
    setToastMessage('Removed AI summary suggestion and restored original.');
    setTimeout(() => setToastMessage(null), 3000);
  }, [structuredResume, editHistory, originalStructuredResume]);

  const handleApplyAllImprovements = () => {
    if (!analysis || !structuredResume) return;
    const list = analysis.improvements || analysis.improvement_suggestions || [];
    list.forEach((imp, idx) => {
      if (imp.is_safe_change !== false && !imp.is_applied) {
        handleApplyImprovement(idx);
      }
    });
  };

  const handleRevertResume = () => {
    if (originalStructuredResume && analysis) {
      setStructuredResume(JSON.parse(JSON.stringify(originalStructuredResume)));
      const updatedAnalysis = { ...analysis };
      const list = updatedAnalysis.improvements || updatedAnalysis.improvement_suggestions || [];
      list.forEach(i => i.is_applied = false);
      setAnalysis(updatedAnalysis);
      setEditHistory([]);
      setToastMessage('Reverted all changes back to original upload.');
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  const generatePlaintextResume = (): string => {
    if (!structuredResume) return '';
    const { personal_info, summary, skills, experience, projects, education, certifications } = structuredResume;

    let text = `${(personal_info?.full_name || 'RESUME').toUpperCase()}\n`;
    text += `${personal_info?.email || ''} | ${personal_info?.phone || ''} | ${personal_info?.location || ''}\n`;
    if (personal_info?.linkedin) text += `LinkedIn: ${personal_info.linkedin} | `;
    if (personal_info?.github) text += `GitHub: ${personal_info.github}\n`;
    text += `\n==================================================\n`;
    text += `PROFESSIONAL SUMMARY\n`;
    text += `==================================================\n`;
    text += `${summary || personal_info?.summary || ''}\n\n`;

    if (skills && skills.length > 0) {
      text += `==================================================\n`;
      text += `CORE COMPETENCIES & SKILLS\n`;
      text += `==================================================\n`;
      text += `${skills.join(' • ')}\n\n`;
    }

    if (experience && experience.length > 0) {
      text += `==================================================\n`;
      text += `EXPERIENCE\n`;
      text += `==================================================\n`;
      experience.forEach(exp => {
        text += `${(exp.role || '').toUpperCase()} | ${exp.company || ''} (${exp.duration || ''})\n`;
        (exp.bullets || []).forEach(b => {
          text += `  • ${cleanBulletText(b)}\n`;
        });
        text += `\n`;
      });
    }

    if (projects && projects.length > 0) {
      text += `==================================================\n`;
      text += `PROJECTS\n`;
      text += `==================================================\n`;
      projects.forEach(p => {
        text += `${(p.title || '').toUpperCase()} | Tech: ${p.role_or_tech || p.technologies?.join(', ') || ''} (${p.duration || ''})\n`;
        if (p.description) text += `  ${p.description}\n`;
        (p.bullets || []).forEach(b => {
          text += `  • ${cleanBulletText(b)}\n`;
        });
        text += `\n`;
      });
    }

    if (education && education.length > 0) {
      text += `==================================================\n`;
      text += `EDUCATION\n`;
      text += `==================================================\n`;
      education.forEach(edu => {
        text += `${edu.degree || ''} in ${edu.field_of_study || ''}\n`;
        text += `${edu.institution || ''} | ${edu.start_year || ''} - ${edu.end_year || ''} | ${edu.grade_or_cgpa || ''}\n\n`;
      });
    }

    if (certifications && certifications.length > 0) {
      text += `==================================================\n`;
      text += `CERTIFICATIONS\n`;
      text += `==================================================\n`;
      certifications.forEach(c => {
        text += `• ${c.name} - ${c.issuer || ''} (${c.year || ''})\n`;
      });
    }

    return text;
  };

  const handleDownloadOriginalPdf = async () => {
    if (analysis?.is_scratch) {
      setToastMessage('This resume was created from scratch. You can export it as PDF or DOCX using the Export options.');
      setTimeout(() => setToastMessage(null), 3500);
      return;
    }

    if (uploadedFile) {
      const url = URL.createObjectURL(uploadedFile);
      const link = document.createElement('a');
      link.href = url;
      link.download = uploadedFile.name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      return;
    }

    if (activeFileBlob) {
      const url = URL.createObjectURL(activeFileBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = analysis?.filename || 'Uploaded_Resume.pdf';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      return;
    }

    try {
      const { blob, filename } = await documentApi.getActiveResumeFileBlob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename || analysis?.filename || 'Uploaded_Resume.pdf';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err: any) {
      setError(err?.message || 'Failed to download original document.');
    }
  };

  const handleDownloadTxt = () => {
    const text = generatePlaintextResume();
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${(structuredResume?.personal_info?.full_name || 'Resume').replace(/\s+/g, '_')}_ATS.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadDoc = () => {
    if (structuredResume) {
      exportResumeDocx(
        structuredResume,
        selectedTemplate || 'ats_classic',
        (analysis?.filename || uploadedFile?.name || structuredResume.personal_info?.full_name || 'Resume').replace(/\.[^/.]+$/, "")
      );
    } else {
      const text = generatePlaintextResume();
      const blob = new Blob([text], { type: 'application/msword' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${(analysis?.filename || uploadedFile?.name || 'Resume').replace(/\.[^/.]+$/, "")}_Optimized.doc`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  };

  const handleCopyPlaintext = () => {
    const text = generatePlaintextResume();
    navigator.clipboard.writeText(text);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  if (isLoading) {
    return (
      <div className="glass-card" style={{ padding: '3.5rem 1.5rem', textAlign: 'center' }}>
        <FuturisticLoader
          size="md"
          icon="sparkles"
          title="Loading Active Resume & AI Intelligence..."
          subtitle="Connecting vector models, ATS scoring engines, and tailored competencies"
        />
      </div>
    );
  }

  const improvements = analysis?.improvements || analysis?.improvement_suggestions || [];
  const appliedCount = improvements.filter(i => i.is_applied).length;
  const safeCount = improvements.filter(i => i.is_safe_change !== false).length;
  const audits = analysis?.section_audits;
  const skillGaps = analysis?.skill_gaps || audits?.skill_gaps || [];

  const currentScore = dynamicATS.overall_score;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', width: '100%' }}>
      {/* Top Header & Clean Navigation */}
      <div className="no-print" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.85rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.55rem' }}>
            <h2 style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
              AI Resume Studio & ATS Optimizer
            </h2>
            <span className="badge badge-emerald" style={{ fontSize: '0.7rem' }}>
              <Sparkles size={11} /> Real-Time Sync
            </span>
          </div>
          <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
            Auditing {analysis?.detected_domain || 'Engineering & Technology'} competencies with STAR quantified enhancements.
          </p>
        </div>

        {/* Action Controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileInputChange}
            accept=".pdf,.docx,.txt,.doc"
            style={{ display: 'none' }}
          />

          {analysis && (
            <>
              {/* Tab Selector */}
              <div style={{ display: 'flex', background: 'rgba(255, 255, 255, 0.05)', padding: '0.2rem', borderRadius: '8px', border: '1px solid var(--border-subtle)', gap: '0.2rem' }}>
                <button
                  onClick={() => setViewTab('split')}
                  className={`btn btn-sm ${viewTab === 'split' ? 'btn-primary' : 'btn-secondary'}`}
                  style={{ borderRadius: '6px', fontSize: '0.75rem', padding: '0.25rem 0.6rem' }}
                >
                  <Layout size={12} /> Split View
                </button>
                <button
                  onClick={() => setViewTab('document')}
                  className={`btn btn-sm ${viewTab === 'document' ? 'btn-primary' : 'btn-secondary'}`}
                  style={{ borderRadius: '6px', fontSize: '0.75rem', padding: '0.25rem 0.6rem' }}
                >
                  <FileText size={12} /> PDF Only
                </button>
                <button
                  onClick={() => setViewTab('job_match')}
                  className={`btn btn-sm ${viewTab === 'job_match' ? 'btn-primary' : 'btn-secondary'}`}
                  style={{ borderRadius: '6px', fontSize: '0.75rem', padding: '0.25rem 0.6rem' }}
                >
                  <Target size={12} /> Job Match
                </button>
                <button
                  onClick={() => {
                    if (onNavigate) {
                      onNavigate('resume_learning');
                    } else {
                      setViewTab('learning');
                    }
                  }}
                  className={`btn btn-sm ${viewTab === 'learning' ? 'btn-primary' : 'btn-secondary'}`}
                  style={{ borderRadius: '6px', fontSize: '0.75rem', padding: '0.25rem 0.6rem', color: viewTab === 'learning' ? '#030712' : '#38bdf8', background: viewTab === 'learning' ? 'var(--accent-cyan)' : 'transparent', fontWeight: 700 }}
                  title="Understand every section, skill, and claim on your resume"
                >
                  <BookMarked size={12} /> Read & Learn
                </button>
                <button
                  onClick={() => setViewTab('inspector')}
                  className={`btn btn-sm ${viewTab === 'inspector' ? 'btn-primary' : 'btn-secondary'}`}
                  style={{ borderRadius: '6px', fontSize: '0.75rem', padding: '0.25rem 0.6rem' }}
                >
                  <Bug size={12} /> Pipeline
                </button>
              </div>

              {/* Feature Action Buttons */}
              <button
                onClick={() => {
                  if (onNavigate) {
                    onNavigate('resume_learning');
                  } else {
                    setViewTab('learning');
                  }
                }}
                className="btn btn-sm"
                style={{
                  fontSize: '0.76rem',
                  padding: '0.35rem 0.8rem',
                  fontWeight: 800,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  background: 'linear-gradient(135deg, #38bdf8, #818cf8)',
                  color: '#030712',
                  border: 'none',
                  boxShadow: '0 0 16px rgba(56, 189, 248, 0.45)',
                  cursor: 'pointer'
                }}
                title="Study every section, skill, and claim in Read & Learn Resume Studio"
              >
                <BookMarked size={13} /> READ & LEARN RESUME
              </button>

              <button
                onClick={() => openTailoringModal('workspace')}
                className="btn btn-sm"
                style={{
                  fontSize: '0.76rem',
                  padding: '0.35rem 0.8rem',
                  fontWeight: 800,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  background: 'linear-gradient(135deg, #00f2fe, #38bdf8)',
                  color: '#030712',
                  border: 'none',
                  boxShadow: '0 0 16px rgba(56, 189, 248, 0.45)',
                  cursor: 'pointer'
                }}
                title="Tailor resume specifically to a job posting"
              >
                <Sparkles size={13} /> TAILOR RESUME TO JOB
              </button>


              <button
                onClick={() => setShowExportModal(true)}
                className="btn btn-emerald btn-sm"
                style={{ fontSize: '0.75rem', padding: '0.35rem 0.65rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.3rem' }}
                title="Export resume to PDF, DOCX, or TXT"
              >
                <Download size={13} /> Export
              </button>

              {/* Make Resume from Scratch Trigger */}
              <button
                onClick={() => setShowCreateScratchModal(true)}
                className="btn btn-secondary btn-sm"
                style={{
                  fontSize: '0.75rem',
                  padding: '0.35rem 0.65rem',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.3rem',
                  color: 'var(--accent-cyan)',
                  borderColor: 'rgba(56, 189, 248, 0.3)'
                }}
                title="Build a new resume from scratch with summary, skills, and projects"
              >
                <Plus size={13} /> Make from Scratch
              </button>

              {/* Template Design Gallery Trigger */}
              <button
                onClick={() => setShowTemplatesModal(true)}
                className="btn btn-secondary btn-sm"
                style={{
                  fontSize: '0.75rem',
                  padding: '0.35rem 0.65rem',
                  fontWeight: 700,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  borderColor: 'rgba(56, 189, 248, 0.4)',
                  color: '#38bdf8'
                }}
                title="Choose from 6 industry ATS-friendly resume design templates"
              >
                <Layout size={13} /> 🎨 Templates
              </button>

              {/* Delete Resume Button */}
              <button
                onClick={() => {
                  setDeleteModalError(null);
                  setShowDeleteModal(true);
                }}
                className="btn btn-outline-danger btn-sm"
                disabled={isUploading || isDeleting}
                style={{ fontSize: '0.75rem', padding: '0.35rem 0.6rem' }}
                title="Delete active resume"
              >
                <Trash2 size={13} />
              </button>
            </>
          )}

          {!analysis && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
              <button
                onClick={() => setShowCreateScratchModal(true)}
                className="btn btn-emerald btn-sm"
                style={{ fontSize: '0.8rem', padding: '0.45rem 0.85rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '0.35rem' }}
              >
                <Wand2 size={14} /> Make from Scratch
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="btn btn-primary btn-sm"
                disabled={isUploading}
                style={{ fontSize: '0.8rem', padding: '0.45rem 0.85rem' }}
              >
                <UploadCloud size={15} className={isUploading ? 'animate-spin-slow' : ''} />
                {isUploading ? 'Analyzing Document...' : 'Upload Resume (PDF/DOCX)'}
              </button>
            </div>
          )}
        </div>
      </div>

      {error && !error.toLowerCase().includes('offline') && !error.toLowerCase().includes('backend') && (
        <div className="no-print modern-alert alert-error">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <AlertCircle size={18} />
            <span>{error}</span>
          </div>
          <button
            onClick={() => setError(null)}
            style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', padding: '0.2rem' }}
            title="Dismiss error notification"
          >
            <X size={16} />
          </button>
        </div>
      )}

      {/* Upload Scanning Progress Overlay when uploading */}
      {isUploading && (
        <div className="glass-card" style={{ padding: '2.5rem 1.5rem', textAlign: 'center', border: '2px solid var(--accent-cyan)', background: 'var(--bg-modal)' }}>
          <FuturisticLoader
            size="md"
            icon="sparkles"
            title="Scanning & Auditing Resume..."
            subtitle="Extracting authentic text hierarchy, detecting domain competencies, and calculating real-time ATS match readiness."
          />

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem', maxWidth: '420px', margin: '1.5rem auto 0 auto', textAlign: 'left' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '0.8rem', color: uploadScanStep >= 1 ? 'var(--accent-cyan)' : 'var(--text-muted)' }}>
              {uploadScanStep > 1 ? <Check size={15} color="var(--accent-emerald)" /> : <RefreshCw size={13} className="animate-spin" />}
              <span>1. Extracting Authentic Vectors & Text Hierarchy</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '0.8rem', color: uploadScanStep >= 2 ? 'var(--accent-cyan)' : 'var(--text-muted)' }}>
              {uploadScanStep > 2 ? <Check size={15} color="var(--accent-emerald)" /> : uploadScanStep === 2 ? <RefreshCw size={13} className="animate-spin" /> : <div style={{ width: 13 }} />}
              <span>2. Detecting Domain & Auditing Skill Gaps</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '0.8rem', color: uploadScanStep >= 3 ? 'var(--accent-cyan)' : 'var(--text-muted)' }}>
              {uploadScanStep > 3 ? <Check size={15} color="var(--accent-emerald)" /> : uploadScanStep === 3 ? <RefreshCw size={13} className="animate-spin" /> : <div style={{ width: 13 }} />}
              <span>3. Auditing Internships & Work Experience Wording</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '0.8rem', color: uploadScanStep >= 4 ? 'var(--accent-cyan)' : 'var(--text-muted)' }}>
              {uploadScanStep > 4 ? <Check size={15} color="var(--accent-emerald)" /> : uploadScanStep === 4 ? <RefreshCw size={13} className="animate-spin" /> : <div style={{ width: 13 }} />}
              <span>4. Evaluating Technical Projects & Verifiable Links</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '0.8rem', color: uploadScanStep >= 5 ? 'var(--accent-cyan)' : 'var(--text-muted)' }}>
              {uploadScanStep === 5 ? <RefreshCw size={13} className="animate-spin" /> : <div style={{ width: 13 }} />}
              <span>5. Generating STAR Rewrites & ATS Score Lift</span>
            </div>
          </div>
        </div>
      )}

      {!analysis || !structuredResume ? (
        /* Empty State: Dual Option Hero (Make from Scratch OR Upload File) */
        <div className="resume-hero-grid">
          
          {/* Card 1: Make Resume From Scratch */}
          <div className="glass-card resume-hero-card">
            <div style={{
              width: '68px',
              height: '68px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.25), rgba(16, 185, 129, 0.25))',
              border: '1px solid var(--accent-cyan)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--accent-cyan)',
              boxShadow: '0 0 20px rgba(56, 189, 248, 0.3)'
            }}>
              <Wand2 size={32} />
            </div>

            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem', marginBottom: '0.3rem' }}>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  Make Resume from Scratch
                </h3>
                <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>Step-by-Step</span>
              </div>
              <p style={{ fontSize: '0.835rem', color: 'var(--text-muted)', maxWidth: '440px', margin: '0 auto', lineHeight: 1.5 }}>
                Don't have a resume yet? Build an ATS-optimized candidate profile from scratch by adding your summary, skills, projects with STAR metrics, internships, and education.
              </p>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap', justifyContent: 'center' }}>
              <span className="badge badge-secondary" style={{ fontSize: '0.68rem' }}>📝 Summary Pitch</span>
              <span className="badge badge-secondary" style={{ fontSize: '0.68rem' }}>⚡ Skill Matrix</span>
              <span className="badge badge-secondary" style={{ fontSize: '0.68rem' }}>🚀 STAR Projects</span>
              <span className="badge badge-secondary" style={{ fontSize: '0.68rem' }}>🎓 Education & Certs</span>
            </div>

            <button
              onClick={() => setShowCreateScratchModal(true)}
              className="btn btn-primary"
              style={{
                padding: '0.7rem 1.4rem',
                fontSize: '0.875rem',
                fontWeight: 800,
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                background: 'linear-gradient(135deg, #00f2fe, #38bdf8)',
                color: '#030712',
                boxShadow: '0 0 20px rgba(56, 189, 248, 0.45)'
              }}
            >
              <Sparkles size={16} /> ✨ BUILD RESUME FROM SCRATCH
            </button>
          </div>

          {/* Card 2: Upload Existing Resume */}
          <div
            className="glass-card resume-hero-card"
            onClick={() => fileInputRef.current?.click()}
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleFileDrop}
            style={{
              cursor: 'pointer',
              border: isDragging ? '2px dashed var(--accent-cyan)' : undefined
            }}
          >
            <div style={{
              width: '68px',
              height: '68px',
              borderRadius: '50%',
              background: isDragging ? 'rgba(56, 189, 248, 0.25)' : 'rgba(56, 189, 248, 0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--accent-cyan)',
              transform: isDragging ? 'scale(1.08)' : 'scale(1)',
              transition: 'transform 0.2s ease'
            }}>
              <UploadCloud size={32} className={isUploading ? 'animate-spin-slow' : ''} />
            </div>

            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: '0 0 0.3rem 0' }}>
                {isUploading ? 'Scanning Your Resume...' : isDragging ? 'Drop Your Resume File Here' : 'Upload Existing Resume'}
              </h3>
              <p style={{ fontSize: '0.835rem', color: 'var(--text-muted)', maxWidth: '440px', margin: '0 auto', lineHeight: 1.5 }}>
                Upload your existing PDF or Word document. The AI engine audits skills, internships, and project descriptions, and calculates real-time ATS scores.
              </p>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap', justifyContent: 'center' }}>
              <span className="badge badge-cyan" style={{ fontSize: '0.68rem' }}>📄 PDF Documents</span>
              <span className="badge badge-emerald" style={{ fontSize: '0.68rem' }}>📝 Word (.docx)</span>
              <span className="badge badge-secondary" style={{ fontSize: '0.68rem' }}>📋 Plain Text (.txt)</span>
            </div>

            <button className="btn btn-secondary" style={{ padding: '0.7rem 1.4rem', fontSize: '0.875rem' }} disabled={isUploading}>
              <UploadCloud size={15} /> {isUploading ? 'Scanning...' : 'Select Document from Computer'}
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Analysis Toolbar: Quick Status & Export Controls */}
          <div className="glass-card no-print" style={{ padding: '0.75rem 1.15rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.65rem' }}>
            {/* Quick Status */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <div style={{ width: '9px', height: '9px', borderRadius: '50%', background: '#10b981', boxShadow: '0 0 8px #10b981' }} />
                <span style={{ fontSize: '0.825rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                  ATS Score: <span style={{ color: '#34d399', fontSize: '0.9rem' }}>{currentScore}/100</span>
                </span>
              </div>
              {dynamicATS.metrics.is_job_tailored && (
                <span className="badge badge-emerald" style={{ fontSize: '0.7rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }} title={`Keyword Match: ${dynamicATS.metrics.jd_keyword_match_percentage}%, Experience Relevance: ${dynamicATS.metrics.jd_experience_relevance_percentage}%`}>
                  <Sparkles size={11} />
                  Tailored: {dynamicATS.metrics.target_job_title || 'Target Job'} ({dynamicATS.metrics.jd_keyword_match_percentage}% Match)
                </span>
              )}
              <span className="badge badge-cyan" style={{ fontSize: '0.7rem' }}>
                {analysis.detected_domain}
              </span>
              <span className="badge badge-emerald" style={{ fontSize: '0.7rem' }}>
                {appliedCount} of {improvements.length} AI Changes Applied
              </span>
              <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                <FileCheck size={12} color="#38bdf8" /> {analysis.filename || 'Active_Resume.pdf'}
              </span>
            </div>

            {/* Controls: Apply All, Revert, Download */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap' }}>
              {appliedCount < safeCount && (
                <button
                  onClick={handleApplyAllImprovements}
                  className="btn btn-emerald btn-sm"
                  style={{ fontSize: '0.72rem', padding: '0.25rem 0.55rem' }}
                  title="Apply all safe STAR impact rewrites"
                >
                  <Sparkles size={11} /> Apply Safe Rewrites ({safeCount})
                </button>
              )}

              {(appliedCount > 0 || editHistory.length > 0) && (
                <button
                  onClick={handleRevertResume}
                  className="btn btn-secondary btn-sm"
                  style={{ fontSize: '0.72rem', padding: '0.25rem 0.55rem' }}
                  title="Revert all changes to original uploaded resume"
                >
                  <RotateCcw size={11} /> Revert All
                </button>
              )}

              {/* Direct Download Buttons */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', borderLeft: '1px solid var(--border-subtle)', paddingLeft: '0.4rem' }}>
                <button
                  onClick={handleDownloadDoc}
                  className="btn btn-secondary btn-sm"
                  style={{ fontSize: '0.72rem', padding: '0.25rem 0.55rem' }}
                  title="Download editable Word Document (.doc)"
                >
                  <FileDown size={11} /> Word (.doc)
                </button>

                <button
                  onClick={handleDownloadTxt}
                  className="btn btn-secondary btn-sm"
                  style={{ fontSize: '0.72rem', padding: '0.25rem 0.55rem' }}
                  title="Download ATS plaintext (.txt)"
                >
                  <Download size={11} /> ATS Text
                </button>

                <button
                  onClick={handleCopyPlaintext}
                  className="btn btn-secondary btn-sm"
                  style={{ fontSize: '0.72rem', padding: '0.25rem 0.45rem' }}
                  title="Copy text to clipboard"
                >
                  {copiedNotification ? <CheckCheck size={12} color="#34d399" /> : <Copy size={12} />}
                </button>
              </div>
            </div>
          </div>

          {/* MAIN WORKSPACE GRID ACCORDING TO SELECTED TAB */}
          {viewTab === 'job_match' ? (
            /* TARGET JOB ALIGNMENT TAB */
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {/* Feature Banner */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.85rem', background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.12), rgba(168, 85, 247, 0.12))', padding: '1.15rem 1.5rem', borderRadius: '14px', border: '1px solid rgba(56, 189, 248, 0.3)', boxShadow: '0 8px 30px rgba(56, 189, 248, 0.08)' }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
                    <Sparkles size={20} color="var(--accent-cyan)" />
                    <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                      Job-Specific Resume Tailoring Engine
                    </h3>
                    <span className="badge badge-emerald" style={{ fontSize: '0.68rem' }}>Additive Only</span>
                  </div>
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', margin: 0, maxWidth: '650px' }}>
                    Audit requirements with verbatim resume quotes, detect hidden semantic matches, reorder skills, and create an evidence-grounded tailored version without overwriting your original resume.
                  </p>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
                  <button
                    type="button"
                    onClick={() => openTailoringModal('video')}
                    className="btn btn-secondary btn-sm"
                    style={{
                      fontSize: '0.8rem',
                      padding: '0.45rem 0.9rem',
                      fontWeight: 700,
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.4rem',
                      border: '1px solid rgba(56, 189, 248, 0.4)'
                    }}
                  >
                    <Play size={14} color="#38bdf8" /> 🎬 How It Works Video
                  </button>

                  <button
                    type="button"
                    onClick={() => openTailoringModal('workspace')}
                    className="btn btn-sm"
                    style={{
                      fontSize: '0.825rem',
                      padding: '0.45rem 1.15rem',
                      fontWeight: 800,
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.4rem',
                      background: 'linear-gradient(135deg, #00f2fe, #38bdf8)',
                      color: '#030712',
                      border: 'none',
                      boxShadow: '0 0 20px rgba(56, 189, 248, 0.45)',
                      cursor: 'pointer'
                    }}
                  >
                    <Target size={15} /> TAILOR RESUME TO JOB
                  </button>
                </div>
              </div>

              <div className="glass-card" style={{ padding: '1.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.4rem' }}>
                  <Target size={18} color="var(--accent-cyan)" />
                  <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                    Quick Job Description & Keyword Scanner
                  </h3>
                </div>
                <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '1rem' }}>
                  Paste a target job posting to automatically add missing skills to your Skills section and enrich your Summary with required experience, qualities & work scope.
                </p>

                <form onSubmit={handleAnalyzeJobDescription} style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                  <div>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.25rem' }}>
                      Target Job Title (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Financial Analyst, Structural Engineer, Full Stack Developer..."
                      value={targetJobTitle}
                      onChange={e => setTargetJobTitle(e.target.value)}
                      className="input-field"
                      style={{ width: '100%', fontSize: '0.8rem' }}
                    />
                  </div>

                  <div>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.25rem' }}>
                      Job Description Text
                    </label>
                    <textarea
                      rows={4}
                      placeholder="Paste the full job posting requirements, responsibilities, and qualifications..."
                      value={targetJobDesc}
                      onChange={e => setTargetJobDesc(e.target.value)}
                      className="input-field"
                      style={{ width: '100%', fontSize: '0.8rem' }}
                    />
                  </div>

                  <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap', alignItems: 'center' }}>
                    <button
                      type="button"
                      onClick={handleDirectAutoTailor}
                      disabled={isAnalyzingJob || !targetJobDesc.trim()}
                      className="btn btn-primary btn-sm"
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.4rem',
                        fontWeight: 800,
                        background: 'linear-gradient(135deg, #00f2fe, #38bdf8)',
                        color: '#030712',
                        border: 'none',
                        boxShadow: '0 0 16px rgba(56, 189, 248, 0.45)',
                        cursor: 'pointer'
                      }}
                    >
                      <Zap size={14} />
                      {isAnalyzingJob ? 'Auto-Tailoring Resume...' : 'Auto-Tailor Resume (Add Skills & Enrich Summary)'}
                    </button>

                    <button
                      type="button"
                      onClick={() => openTailoringModal('workspace')}
                      className="btn btn-secondary btn-sm"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}
                    >
                      <Target size={13} />
                      Open Tailoring Studio Modal
                    </button>

                    <button
                      type="button"
                      onClick={() => openTailoringModal('video')}
                      className="btn btn-secondary btn-sm"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', border: '1px solid rgba(56, 189, 248, 0.35)' }}
                    >
                      <Play size={12} color="#38bdf8" />
                      🎬 Watch How It Works
                    </button>

                    <button
                      type="submit"
                      disabled={isAnalyzingJob || !targetJobDesc.trim()}
                      className="btn btn-ghost btn-sm"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem', color: 'var(--text-muted)' }}
                    >
                      <Sparkles size={12} />
                      {isAnalyzingJob ? 'Evaluating...' : 'Scan Match %'}
                    </button>
                  </div>
                </form>
              </div>

              {/* ATS Job Alignment Examination Card */}
              {dynamicATS.metrics.is_job_tailored && (
                <div className="glass-card" style={{ padding: '1.25rem', border: '1px solid rgba(16, 185, 129, 0.35)', background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.08), rgba(56, 189, 248, 0.08))' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem', marginBottom: '1rem' }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <Sparkles size={18} color="#34d399" />
                        <h4 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                          ATS Job Alignment Examination
                        </h4>
                        <span className="badge badge-emerald" style={{ fontSize: '0.7rem' }}>
                          {dynamicATS.metrics.target_job_title || 'Target Job'}
                        </span>
                      </div>
                      <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', margin: '0.2rem 0 0 0' }}>
                        Evaluated against target JD keywords, experience relevance, action verbs, and core skill requirements.
                      </p>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <div style={{ textAlign: 'right' }}>
                        <div style={{ fontSize: '1.3rem', fontWeight: 900, color: '#34d399' }}>
                          {dynamicATS.overall_score}/100
                        </div>
                        <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Tailored ATS Score</div>
                      </div>
                    </div>
                  </div>

                  {/* Metric Meters */}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.85rem', marginBottom: '1rem' }}>
                    <div style={{ padding: '0.75rem', borderRadius: '8px', background: 'rgba(0,0,0,0.25)', border: '1px solid var(--border-subtle)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '0.35rem' }}>
                        <span style={{ color: 'var(--text-secondary)' }}>JD Keyword Match</span>
                        <span style={{ fontWeight: 700, color: '#38bdf8' }}>{dynamicATS.metrics.jd_keyword_match_percentage}%</span>
                      </div>
                      <div style={{ width: '100%', height: '6px', background: 'rgba(255,255,255,0.1)', borderRadius: '3px', overflow: 'hidden' }}>
                        <div style={{ width: `${dynamicATS.metrics.jd_keyword_match_percentage}%`, height: '100%', background: '#38bdf8', borderRadius: '3px', transition: 'width 0.4s ease' }} />
                      </div>
                    </div>

                    <div style={{ padding: '0.75rem', borderRadius: '8px', background: 'rgba(0,0,0,0.25)', border: '1px solid var(--border-subtle)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '0.35rem' }}>
                        <span style={{ color: 'var(--text-secondary)' }}>Experience Relevance</span>
                        <span style={{ fontWeight: 700, color: '#34d399' }}>{dynamicATS.metrics.jd_experience_relevance_percentage}%</span>
                      </div>
                      <div style={{ width: '100%', height: '6px', background: 'rgba(255,255,255,0.1)', borderRadius: '3px', overflow: 'hidden' }}>
                        <div style={{ width: `${dynamicATS.metrics.jd_experience_relevance_percentage}%`, height: '100%', background: '#34d399', borderRadius: '3px', transition: 'width 0.4s ease' }} />
                      </div>
                    </div>

                    <div style={{ padding: '0.75rem', borderRadius: '8px', background: 'rgba(0,0,0,0.25)', border: '1px solid var(--border-subtle)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '0.35rem' }}>
                        <span style={{ color: 'var(--text-secondary)' }}>Skill Density</span>
                        <span style={{ fontWeight: 700, color: '#a78bfa' }}>{dynamicATS.score_breakdown.skill_density}%</span>
                      </div>
                      <div style={{ width: '100%', height: '6px', background: 'rgba(255,255,255,0.1)', borderRadius: '3px', overflow: 'hidden' }}>
                        <div style={{ width: `${dynamicATS.score_breakdown.skill_density}%`, height: '100%', background: '#a78bfa', borderRadius: '3px', transition: 'width 0.4s ease' }} />
                      </div>
                    </div>
                  </div>

                  {/* Matched Keywords Chips */}
                  {dynamicATS.metrics.matched_jd_keywords && dynamicATS.metrics.matched_jd_keywords.length > 0 && (
                    <div>
                      <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-secondary)', marginBottom: '0.4rem' }}>
                        Target Keywords Detected in Resume ({dynamicATS.metrics.matched_jd_keywords.length}):
                      </div>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                        {dynamicATS.metrics.matched_jd_keywords.map((kw, i) => (
                          <span key={i} className="badge badge-emerald" style={{ fontSize: '0.68rem', padding: '0.15rem 0.45rem' }}>
                            ✓ {kw}
                          </span>
                        ))}
                        {dynamicATS.metrics.missing_jd_keywords && dynamicATS.metrics.missing_jd_keywords.slice(0, 8).map((kw, i) => (
                          <span key={i} className="badge badge-secondary" style={{ fontSize: '0.68rem', padding: '0.15rem 0.45rem', opacity: 0.75 }}>
                            + {kw}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {analysis.job_analysis && (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1.25rem' }}>
                  <div className="glass-card" style={{ padding: '1.25rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                      <h4 style={{ fontSize: '0.9rem', fontWeight: 700, color: '#34d399', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                        <CheckCircle2 size={15} /> Matched Skills ({analysis.job_analysis.matched_skills?.length || 0})
                      </h4>
                      <span className="badge badge-emerald">
                        Alignment: {analysis.job_analysis.job_alignment_score || 80}%
                      </span>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                      {(analysis.job_analysis.matched_skills || []).map((m, idx) => (
                        <div key={idx} style={{ padding: '0.5rem 0.7rem', borderRadius: '6px', background: 'rgba(16, 185, 129, 0.06)', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
                          <span style={{ fontWeight: 700, fontSize: '0.8rem', color: 'var(--text-primary)' }}>{m.skill}</span>
                          {m.resume_evidence && (
                            <p style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', marginTop: '0.15rem' }}>{m.resume_evidence}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="glass-card" style={{ padding: '1.25rem' }}>
                    <h4 style={{ fontSize: '0.9rem', fontWeight: 700, color: '#fb7185', display: 'flex', alignItems: 'center', gap: '0.35rem', marginBottom: '0.75rem' }}>
                      <AlertCircle size={15} /> Skills Missing ({analysis.job_analysis.missing_skills?.length || 0})
                    </h4>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                      {(analysis.job_analysis.missing_skills || []).map((m, idx) => (
                        <div key={idx} style={{ padding: '0.5rem 0.7rem', borderRadius: '6px', background: 'rgba(244, 63, 94, 0.05)', border: '1px solid rgba(244, 63, 94, 0.2)' }}>
                          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                            <span style={{ fontWeight: 700, fontSize: '0.8rem', color: 'var(--text-primary)' }}>{m.skill}</span>
                            <button
                              type="button"
                              onClick={() => handleAddSkillFromGap(m.skill)}
                              className="btn btn-emerald btn-sm"
                              style={{ padding: '0.15rem 0.45rem', fontSize: '0.68rem' }}
                            >
                              <Plus size={10} /> Add to Resume (+1 ATS)
                            </button>
                          </div>
                          <p style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', marginTop: '0.15rem' }}>
                            {m.recommendation || `Target job requires ${m.skill}.`}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : viewTab === 'inspector' ? (
            /* PIPELINE INSPECTOR VIEW */
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <div className="glass-card" style={{ padding: '1.25rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', marginBottom: '0.35rem' }}>
                  <Bug size={18} color="var(--accent-cyan)" />
                  <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                    Resume Pipeline Inspector
                  </h3>
                </div>
                <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                  Live verification of each phase in the pipeline: Source Upload ➔ Raw Text ➔ Structured JSON ➔ ATS Metrics.
                </p>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '1.25rem' }}>
                <div className="glass-card" style={{ padding: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--accent-cyan)' }}>
                    Stage 1 & 2: Extracted Raw Resume Text ({analysis.raw_text?.length || 0} chars)
                  </h4>
                  <pre style={{
                    maxHeight: '360px',
                    overflowY: 'auto',
                    background: 'rgba(0, 0, 0, 0.4)',
                    padding: '0.85rem',
                    borderRadius: '6px',
                    fontSize: '0.72rem',
                    color: '#94a3b8',
                    whiteSpace: 'pre-wrap',
                    lineHeight: 1.4
                  }}>
                    {analysis.raw_text || 'No raw text available.'}
                  </pre>
                </div>

                <div className="glass-card" style={{ padding: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--accent-emerald)' }}>
                    Stage 3: Structured Resume JSON (Verified Facts)
                  </h4>
                  <pre style={{
                    maxHeight: '360px',
                    overflowY: 'auto',
                    background: 'rgba(0, 0, 0, 0.4)',
                    padding: '0.85rem',
                    borderRadius: '6px',
                    fontSize: '0.72rem',
                    color: '#34d399',
                    whiteSpace: 'pre-wrap',
                    lineHeight: 1.4
                  }}>
                    {JSON.stringify(structuredResume, null, 2)}
                  </pre>
                </div>
              </div>
            </div>
          ) : viewTab === 'learning' ? (
            /* READ & LEARN MY RESUME INTERACTIVE VIEW */
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <ResumeLearningDashboard 
                resumeData={{ analysis, structuredResume }} 
                onNavigateToResume={() => setViewTab('split')}
              />
            </div>
          ) : (
            /* UNIFIED 100% AUTHENTIC UPLOADED PDF & LLM SECTION AUDIT WORKSPACE */
            <div 
              className={`main-workspace-grid ${viewTab !== 'split' ? 'single-col' : ''}`}
            >
              {/* LEFT COLUMN: LLM SECTION AUDITS, SKILL GAPS & INTERACTIVE ENHANCERS */}
              {viewTab === 'split' && (
                <div 
                  className="no-print analysis-sidebar-panel" 
                >
                  {/* LLM Section Audits Sub-Tabs Filter */}
                  <div className="glass-card" style={{ padding: '0.5rem 0.65rem', display: 'flex', flexWrap: 'wrap', gap: '0.25rem' }}>
                    <button
                      onClick={() => setSectionAuditTab('all')}
                      className={`btn btn-sm ${sectionAuditTab === 'all' ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem' }}
                    >
                      <Layers size={11} /> All Audits
                    </button>
                    <button
                      onClick={() => setSectionAuditTab('skill_gaps')}
                      className={`btn btn-sm ${sectionAuditTab === 'skill_gaps' ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem' }}
                    >
                      <Zap size={11} /> Skill Gaps ({skillGaps.length})
                    </button>
                    <button
                      onClick={() => setSectionAuditTab('experience')}
                      className={`btn btn-sm ${sectionAuditTab === 'experience' ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem' }}
                    >
                      <Briefcase size={11} /> Internships
                    </button>
                    <button
                      onClick={() => setSectionAuditTab('projects')}
                      className={`btn btn-sm ${sectionAuditTab === 'projects' ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem' }}
                    >
                      <Code size={11} /> Projects
                    </button>
                    <button
                      onClick={() => setSectionAuditTab('summary')}
                      className={`btn btn-sm ${sectionAuditTab === 'summary' ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem' }}
                    >
                      <BookOpen size={11} /> Summary
                    </button>
                    <button
                      onClick={() => setSectionAuditTab('improvements')}
                      className={`btn btn-sm ${sectionAuditTab === 'improvements' ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem' }}
                    >
                      <Sparkles size={11} /> STAR ({improvements.length})
                    </button>
                  </div>

                  {/* 1. SKILL GAP AUDIT SECTION */}
                  {(sectionAuditTab === 'all' || sectionAuditTab === 'skill_gaps') && (
                    <div className="glass-card" style={{ padding: '1.15rem', border: '1px solid rgba(56, 189, 248, 0.3)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.6rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <Zap size={15} color="var(--accent-cyan)" />
                          <h3 style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                            LLM Skill Gap Analysis
                          </h3>
                        </div>
                        <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>
                          {skillGaps.length} Gaps
                        </span>
                      </div>
                      <p style={{ fontSize: '0.725rem', color: 'var(--text-muted)', marginBottom: '0.75rem' }}>
                        Missing competencies in {analysis.detected_domain}. Click <strong>"Add Skill"</strong> to add it to your candidate profile and live ATS evaluation.
                      </p>

                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        {skillGaps.length === 0 ? (
                          <div style={{ padding: '0.65rem', borderRadius: '6px', background: 'rgba(16, 185, 129, 0.05)', textAlign: 'center', fontSize: '0.725rem', color: '#34d399' }}>
                            <CheckCircle2 size={15} style={{ margin: '0 auto 0.2rem auto' }} />
                            Excellent skill coverage! No major domain gaps detected.
                          </div>
                        ) : (
                          skillGaps.map((gap, idx) => {
                            const isAlreadyInResume = (structuredResume.skills || []).includes(gap.skill);
                            return (
                              <div
                                key={idx}
                                style={{
                                  padding: '0.65rem',
                                  borderRadius: '8px',
                                  background: isAlreadyInResume ? 'rgba(16, 185, 129, 0.06)' : 'rgba(255, 255, 255, 0.02)',
                                  border: isAlreadyInResume ? '1px solid rgba(16, 185, 129, 0.3)' : gap.importance === 'critical' ? '1px solid rgba(244, 63, 94, 0.35)' : '1px solid var(--border-subtle)',
                                  display: 'flex',
                                  flexDirection: 'column',
                                  gap: '0.35rem'
                                }}
                              >
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.3rem' }}>
                                  <span style={{ fontWeight: 700, fontSize: '0.8rem', color: 'var(--text-primary)' }}>
                                    {gap.skill}
                                  </span>
                                  <span className={`badge ${gap.importance === 'critical' ? 'badge-rose' : gap.importance === 'high' ? 'badge-amber' : 'badge-cyan'}`} style={{ fontSize: '0.62rem' }}>
                                    {gap.importance.toUpperCase()} GAP
                                  </span>
                                </div>
                                <p style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', lineHeight: 1.35, margin: 0 }}>
                                  {gap.reason}
                                </p>
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '0.15rem', gap: '0.4rem' }}>
                                  <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)' }}>
                                    Action: {gap.suggested_action}
                                  </span>
                                  {isAlreadyInResume ? (
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                                      <span className="badge badge-emerald" style={{ fontSize: '0.65rem' }}>
                                        <Check size={10} /> Added
                                      </span>
                                      <button
                                        type="button"
                                        onClick={() => handleRemoveSkill(gap.skill)}
                                        className="btn btn-secondary btn-sm"
                                        style={{ padding: '0.15rem 0.35rem', fontSize: '0.62rem' }}
                                        title="Remove from skills list"
                                      >
                                        <Undo2 size={9} /> Remove
                                      </button>
                                    </div>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() => handleAddSkillFromGap(gap.skill)}
                                      className="btn btn-emerald btn-sm"
                                      style={{ padding: '0.2rem 0.5rem', fontSize: '0.68rem', flexShrink: 0 }}
                                      title="Add this verified skill into your structured resume document"
                                    >
                                      <Plus size={10} /> Add Skill (+1 ATS)
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  )}

                  {/* 2. INTERNSHIP & EXPERIENCE AUDIT SECTION */}
                  {(sectionAuditTab === 'all' || sectionAuditTab === 'experience') && (
                    <div className="glass-card" style={{ padding: '1.15rem', border: '1px solid rgba(192, 132, 252, 0.3)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.6rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <Briefcase size={15} color="var(--accent-violet)" />
                          <h3 style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                            Internships & Experience Audit
                          </h3>
                        </div>
                        <span className={`badge ${audits?.experience_audit?.status === 'strong' ? 'badge-emerald' : 'badge-rose'}`} style={{ fontSize: '0.65rem' }}>
                          {audits?.experience_audit?.status === 'strong' ? 'Strong Phrasing' : 'Needs Modification'}
                        </span>
                      </div>

                      {/* Detected Issues & Required Modifications */}
                      {audits?.experience_audit?.issues_detected && audits.experience_audit.issues_detected.length > 0 && (
                        <div style={{ padding: '0.55rem 0.7rem', borderRadius: '6px', background: 'rgba(244, 63, 94, 0.05)', border: '1px solid rgba(244, 63, 94, 0.2)', marginBottom: '0.65rem' }}>
                          <span style={{ fontSize: '0.68rem', fontWeight: 700, color: '#fb7185', display: 'flex', alignItems: 'center', gap: '0.25rem', marginBottom: '0.25rem' }}>
                            <AlertCircle size={11} /> Detected Modification Requirements:
                          </span>
                          <ul style={{ paddingLeft: '1rem', fontSize: '0.7rem', color: 'var(--text-secondary)', margin: 0 }}>
                            {audits.experience_audit.issues_detected.map((iss, i) => <li key={i}>{iss}</li>)}
                            {audits.experience_audit.modifications_needed?.map((mod, i) => <li key={`m-${i}`} style={{ color: 'var(--accent-cyan)' }}>Mod: {mod}</li>)}
                          </ul>
                        </div>
                      )}

                      {/* Interactive Section Entries */}
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
                        {(structuredResume.experience || []).length === 0 ? (
                          <div style={{ textAlign: 'center', padding: '0.85rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>
                            No internships found. Click below to generate an entry with AI.
                            <button
                              type="button"
                              onClick={() => handleOpenEnhancer('experience', null, 'Internship in ' + analysis.detected_domain, 'Draft a strong technical internship entry.')}
                              className="btn btn-primary btn-sm"
                              style={{ margin: '0.4rem auto 0 auto', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
                            >
                              <Wand2 size={11} /> Generate with AI
                            </button>
                          </div>
                        ) : (
                          (structuredResume.experience || []).map((exp, idx) => (
                            <div key={exp.id || idx} style={{ padding: '0.65rem', borderRadius: '8px', background: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--border-subtle)' }}>
                              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
                                <span style={{ fontWeight: 700, fontSize: '0.78rem', color: 'var(--text-primary)' }}>
                                  {exp.role} — {exp.company}
                                </span>
                                <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>{exp.duration || 'Duration'}</span>
                              </div>

                              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem', marginTop: '0.35rem' }}>
                                {(exp.bullets || []).map((b, bIdx) => {
                                  const isOpt = isBulletOptimized(b);
                                  return (
                                    <div key={bIdx} style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem', background: 'rgba(0, 0, 0, 0.2)', padding: '0.35rem 0.5rem', borderRadius: '6px' }}>
                                      <span style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', flex: 1, lineHeight: 1.35 }}>• {b}</span>
                                      {isOpt ? (
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', flexShrink: 0 }}>
                                          <span className="badge badge-emerald" style={{ fontSize: '0.62rem' }}>
                                            <Check size={9} /> Enhanced
                                          </span>
                                          <button
                                            type="button"
                                            onClick={() => handleRevertBullet('experience', exp.id || exp.company, b)}
                                            className="btn btn-secondary btn-sm"
                                            style={{ padding: '0.15rem 0.35rem', fontSize: '0.62rem' }}
                                            title="Undo AI suggestion and restore original wording"
                                          >
                                            <Undo2 size={9} /> Remove
                                          </button>
                                        </div>
                                      ) : (
                                        <button
                                          type="button"
                                          onClick={() => handleOpenEnhancer('experience', exp.id || exp.company, b, 'Rewrite with strong action verbs and quantifiable STAR impact.')}
                                          className="btn btn-violet btn-sm"
                                          style={{ padding: '0.15rem 0.4rem', fontSize: '0.65rem', flexShrink: 0 }}
                                          title="Suggest excellent wording for this bullet point with LLM"
                                        >
                                          <Wand2 size={9} /> Enhance Wording
                                        </button>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          ))
                        )}
                      </div>

                      {/* Read & Learn Experience section link */}
                      <div style={{ marginTop: '0.85rem', padding: '0.65rem 0.85rem', borderRadius: '8px', background: 'rgba(56, 189, 248, 0.05)', border: '1px solid rgba(56, 189, 248, 0.2)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem', flexWrap: 'wrap' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <BookMarked size={13} color="var(--accent-cyan)" />
                          <span style={{ fontSize: '0.72rem', color: '#f8fafc', fontWeight: 600 }}>Study this section in depth</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            if (onNavigate) {
                              onNavigate('resume_learning');
                            } else {
                              setViewTab('learning');
                            }
                          }}
                          className="btn btn-primary btn-sm"
                          style={{ fontSize: '0.68rem', padding: '0.2rem 0.55rem', display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}
                        >
                          <BookOpen size={11} /> Read & Learn Experience →
                        </button>
                      </div>
                    </div>
                  )}

                  {/* 3. PROJECTS SECTION AUDIT */}
                  {(sectionAuditTab === 'all' || sectionAuditTab === 'projects') && (
                    <div className="glass-card" style={{ padding: '1.15rem', border: '1px solid rgba(16, 185, 129, 0.3)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.6rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <Code size={15} color="var(--accent-emerald)" />
                          <h3 style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                            Technical Projects Section Audit
                          </h3>
                        </div>
                        <span className={`badge ${audits?.projects_audit?.status === 'strong' ? 'badge-emerald' : 'badge-rose'}`} style={{ fontSize: '0.65rem' }}>
                          {audits?.projects_audit?.status === 'strong' ? 'High Rigor' : 'Needs Modification'}
                        </span>
                      </div>

                      {audits?.projects_audit?.issues_detected && audits.projects_audit.issues_detected.length > 0 && (
                        <div style={{ padding: '0.55rem 0.7rem', borderRadius: '6px', background: 'rgba(244, 63, 94, 0.05)', border: '1px solid rgba(244, 63, 94, 0.2)', marginBottom: '0.65rem' }}>
                          <span style={{ fontSize: '0.68rem', fontWeight: 700, color: '#fb7185', display: 'flex', alignItems: 'center', gap: '0.25rem', marginBottom: '0.25rem' }}>
                            <AlertCircle size={11} /> Project Modifications Needed:
                          </span>
                          <ul style={{ paddingLeft: '1rem', fontSize: '0.7rem', color: 'var(--text-secondary)', margin: 0 }}>
                            {audits.projects_audit.issues_detected.map((iss, i) => <li key={i}>{iss}</li>)}
                            {audits.projects_audit.modifications_needed?.map((mod, i) => <li key={`pm-${i}`} style={{ color: 'var(--accent-cyan)' }}>Action: {mod}</li>)}
                          </ul>
                        </div>
                      )}

                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
                        {(structuredResume.projects || []).length === 0 ? (
                          <div style={{ textAlign: 'center', padding: '0.85rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>
                            No projects detected. Add key technical deliverables with verified links.
                          </div>
                        ) : (
                          (structuredResume.projects || []).map((proj, idx) => (
                            <div key={proj.id || idx} style={{ padding: '0.65rem', borderRadius: '8px', background: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--border-subtle)' }}>
                              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
                                <span style={{ fontWeight: 700, fontSize: '0.8rem', color: 'var(--text-primary)' }}>
                                  {proj.title}
                                </span>
                                <span className="badge badge-cyan" style={{ fontSize: '0.62rem' }}>
                                  {proj.role_or_tech || proj.technologies?.join(', ') || 'Tech Stack'}
                                </span>
                              </div>

                              {proj.description && (
                                <p style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', marginBottom: '0.35rem', lineHeight: 1.35 }}>
                                  {proj.description}
                                </p>
                              )}

                              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
                                {(proj.bullets || []).map((b, bIdx) => {
                                  const isOpt = isBulletOptimized(b);
                                  return (
                                    <div key={bIdx} style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem', background: 'rgba(0, 0, 0, 0.2)', padding: '0.35rem 0.5rem', borderRadius: '6px' }}>
                                      <span style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', flex: 1, lineHeight: 1.35 }}>• {b}</span>
                                      {isOpt ? (
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', flexShrink: 0 }}>
                                          <span className="badge badge-emerald" style={{ fontSize: '0.62rem' }}>
                                            <Check size={9} /> Enhanced
                                          </span>
                                          <button
                                            type="button"
                                            onClick={() => handleRevertBullet('projects', proj.id || proj.title, b)}
                                            className="btn btn-secondary btn-sm"
                                            style={{ padding: '0.15rem 0.35rem', fontSize: '0.62rem' }}
                                            title="Undo AI suggestion and restore original wording"
                                          >
                                            <Undo2 size={9} /> Remove
                                          </button>
                                        </div>
                                      ) : (
                                        <button
                                          type="button"
                                          onClick={() => handleOpenEnhancer('projects', proj.id || proj.title, b, `Enhance technical architecture phrasing for ${proj.title}.`)}
                                          className="btn btn-emerald btn-sm"
                                          style={{ padding: '0.15rem 0.4rem', fontSize: '0.65rem', flexShrink: 0 }}
                                          title="Suggest excellent wording for this project with LLM"
                                        >
                                          <Wand2 size={9} /> Enhance Tech
                                        </button>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          ))
                        )}
                      </div>

                      {/* Read & Learn Projects section link */}
                      <div style={{ marginTop: '0.85rem', padding: '0.65rem 0.85rem', borderRadius: '8px', background: 'rgba(56, 189, 248, 0.05)', border: '1px solid rgba(56, 189, 248, 0.2)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem', flexWrap: 'wrap' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <BookMarked size={13} color="var(--accent-cyan)" />
                          <span style={{ fontSize: '0.72rem', color: '#f8fafc', fontWeight: 600 }}>Deep-dive into your projects & tech stack</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            if (onNavigate) {
                              onNavigate('resume_learning');
                            } else {
                              setViewTab('learning');
                            }
                          }}
                          className="btn btn-primary btn-sm"
                          style={{ fontSize: '0.68rem', padding: '0.2rem 0.55rem', display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}
                        >
                          <BookOpen size={11} /> Read & Learn Projects →
                        </button>
                      </div>
                    </div>
                  )}

                  {/* 4. PROFESSIONAL SUMMARY AUDIT */}
                  {(sectionAuditTab === 'all' || sectionAuditTab === 'summary') && (
                    <div className="glass-card" style={{ padding: '1.15rem', border: '1px solid rgba(245, 158, 11, 0.3)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.6rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <BookOpen size={15} color="#f59e0b" />
                          <h3 style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                            Executive Summary Audit
                          </h3>
                        </div>
                        <span className={`badge ${structuredResume.summary ? 'badge-emerald' : 'badge-amber'}`} style={{ fontSize: '0.65rem' }}>
                          {structuredResume.summary ? 'Summary Active' : 'Needs Summary'}
                        </span>
                      </div>

                      <div style={{ padding: '0.65rem', borderRadius: '8px', background: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--border-subtle)', display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                        <p style={{ fontSize: '0.725rem', color: structuredResume.summary ? 'var(--text-secondary)' : 'var(--text-muted)', fontStyle: structuredResume.summary ? 'normal' : 'italic', lineHeight: 1.4, margin: 0 }}>
                          {structuredResume.summary || 'No summary statement present on uploaded resume. Adding a 2-3 sentence executive pitch increases recruiter engagement.'}
                        </p>

                        {(() => {
                          const isSummaryEnhanced = editHistory.some(h => h.section === 'summary') || (
                            Boolean(structuredResume.summary) && structuredResume.summary !== (originalStructuredResume?.summary || originalStructuredResume?.personal_info?.summary)
                          );
                          return isSummaryEnhanced ? (
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap' }}>
                              <span className="badge badge-emerald" style={{ fontSize: '0.65rem' }}>
                                <Check size={10} /> AI Enhanced
                              </span>
                              <button
                                type="button"
                                onClick={handleRevertSummary}
                                className="btn btn-secondary btn-sm"
                                style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem' }}
                                title="Undo AI suggestion and restore original summary"
                              >
                                <Undo2 size={10} /> Remove
                              </button>
                              <button
                                type="button"
                                onClick={() => handleOpenEnhancer('summary', null, structuredResume.summary, 'Polish executive summary positioning me as a high-impact candidate.')}
                                className="btn btn-primary btn-sm"
                                style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem' }}
                              >
                                <Wand2 size={10} /> Re-Enhance
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleOpenEnhancer('summary', null, structuredResume.summary || `${analysis.detected_domain} professional with experience in ${structuredResume.skills.slice(0, 4).join(', ')}`, 'Generate a punchy 2-3 line executive summary positioning me as a high-impact candidate.')}
                              className="btn btn-primary btn-sm"
                              style={{ alignSelf: 'flex-start', fontSize: '0.7rem', padding: '0.2rem 0.5rem' }}
                            >
                              <Wand2 size={10} /> {structuredResume.summary ? 'Polish Summary with AI' : 'Generate Summary with AI'}
                            </button>
                          );
                        })()}
                      </div>
                    </div>
                  )}

                  {/* 5. AI STAR BULLET IMPROVEMENTS LIST */}
                  {(sectionAuditTab === 'all' || sectionAuditTab === 'improvements') && (
                    <div className="glass-card" style={{ padding: '1.15rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.6rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                          <Sparkles size={15} color="var(--accent-emerald)" />
                          <h3 style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                            AI STAR Rewrites ({appliedCount}/{improvements.length})
                          </h3>
                        </div>
                        <span className="badge badge-emerald" style={{ fontSize: '0.65rem' }}>
                          {appliedCount} Applied
                        </span>
                      </div>

                      {/* Read & Learn STAR Method Link */}
                      <div style={{ marginBottom: '0.85rem', padding: '0.65rem 0.85rem', borderRadius: '8px', background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.08), rgba(129, 140, 248, 0.08))', border: '1px solid rgba(56, 189, 248, 0.25)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem', flexWrap: 'wrap' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <Sparkles size={13} color="var(--accent-cyan)" />
                          <span style={{ fontSize: '0.72rem', color: '#f8fafc', fontWeight: 600 }}>Master your resume claims with STAR deep-dives</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            if (onNavigate) {
                              onNavigate('resume_learning');
                            } else {
                              setViewTab('learning');
                            }
                          }}
                          className="btn btn-primary btn-sm"
                          style={{ fontSize: '0.68rem', padding: '0.2rem 0.65rem', display: 'inline-flex', alignItems: 'center', gap: '0.3rem', background: 'linear-gradient(135deg, #00f2fe, #38bdf8)', color: '#030712', fontWeight: 700 }}
                        >
                          <BookMarked size={11} /> Read & Learn STAR Method →
                        </button>
                      </div>

                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
                        {improvements.length === 0 ? (
                          <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textAlign: 'center', padding: '0.75rem 0', margin: 0 }}>
                            No weak bullet phrases detected. High ATS phrasing density!
                          </p>
                        ) : (
                          improvements.map((imp, idx) => (
                            <div
                              key={idx}
                              style={{
                                borderRadius: '8px',
                                border: imp.is_applied ? '1px solid rgba(16, 185, 129, 0.4)' : '1px solid var(--border-subtle)',
                                backgroundColor: imp.is_applied ? 'rgba(16, 185, 129, 0.06)' : 'rgba(255, 255, 255, 0.02)',
                                padding: '0.75rem',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '0.4rem'
                              }}
                            >
                              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                <span className="badge badge-violet" style={{ fontSize: '0.62rem' }}>
                                  {imp.section}
                                </span>
                                {imp.is_applied ? (
                                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                                    <span className="badge badge-emerald" style={{ fontSize: '0.65rem' }}>
                                      <Check size={10} /> Applied
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => handleRevertSingleImprovement(idx)}
                                      className="btn btn-secondary btn-sm"
                                      style={{ padding: '0.15rem 0.4rem', fontSize: '0.65rem' }}
                                      title="Revert back to original phrasing"
                                    >
                                      <Undo2 size={9} /> Revert
                                    </button>
                                  </div>
                                ) : (
                                  <button
                                    onClick={() => handleApplyImprovement(idx)}
                                    className="btn btn-emerald btn-sm"
                                    style={{ padding: '0.2rem 0.5rem', fontSize: '0.68rem' }}
                                  >
                                    <Sparkles size={10} /> Apply (+1 ATS)
                                  </button>
                                )}
                              </div>

                              <div style={{ padding: '0.45rem', borderRadius: '6px', background: 'rgba(244, 63, 94, 0.05)', border: '1px solid rgba(244, 63, 94, 0.15)' }}>
                                <span style={{ fontSize: '0.6rem', fontWeight: 700, color: '#fb7185', textTransform: 'uppercase' }}>
                                  Original:
                                </span>
                                <p style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', marginTop: '0.1rem', fontStyle: 'italic', margin: 0 }}>
                                  "{imp.original_bullet}"
                                </p>
                              </div>

                              <div style={{ padding: '0.45rem', borderRadius: '6px', background: 'rgba(16, 185, 129, 0.08)', border: '1px solid rgba(16, 185, 129, 0.25)' }}>
                                <span style={{ fontSize: '0.6rem', fontWeight: 700, color: '#34d399', textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
                                  <Sparkles size={9} /> AI STAR Impact:
                                </span>
                                <p style={{ fontSize: '0.725rem', color: 'var(--text-primary)', marginTop: '0.1rem', fontWeight: 600, margin: 0 }}>
                                  "{imp.suggested_bullet || imp.improved_bullet}"
                                </p>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* RIGHT / MAIN COLUMN: REAL-TIME LIVE AI-ENHANCED RESUME & ORIGINAL PDF VIEWER */}
              <div 
                className="resume-preview-workspace-col"
                style={{ minWidth: 0, width: '100%', height: '100%' }}
              >
                <ResumePreviewContainer
                  structuredResume={structuredResume}
                  originalStructuredResume={originalStructuredResume}
                  templateId={selectedTemplate}
                  onTemplateChange={handleTemplateChange}
                  onUpdateResume={handleUpdateStructuredResume}
                  improvements={improvements}
                  editHistory={editHistory}
                  onOpenEnhancer={handleOpenEnhancer}
                  onOpenHeadlineEnhancer={handleOpenHeadlineEnhancer}
                  onOpenSummaryEnhancer={handleOpenSummaryEnhancer}
                  onOpenBulletEnhancer={handleOpenBulletEnhancer}
                  onRevertBullet={handleRevertBullet}
                  onRevertSummary={handleRevertSummary}
                  file={analysis?.is_scratch ? null : (uploadedFile || activeFileBlob)}
                  fileUrl={analysis?.is_scratch ? null : analysis?.file_url}
                  filename={analysis?.is_scratch ? (analysis?.filename || 'Scratch_Resume.pdf') : (uploadedFile?.name || analysis?.filename || 'Resume_Document.pdf')}
                  detectedLinks={analysis?.is_scratch ? [] : (analysis?.detected_links || [])}
                  onDownloadOriginal={analysis?.is_scratch ? undefined : handleDownloadOriginalPdf}
                  rawText={analysis?.is_scratch ? undefined : analysis?.raw_text}
                  isScratch={!!analysis?.is_scratch}
                  onUploadNew={() => fileInputRef.current?.click()}
                  onFileSelected={processFileUpload}
                />
              </div>
            </div>
          )}
        </>
      )}

      {/* INTERACTIVE LLM SECTION ENHANCER MODAL */}
      {enhancerModalOpen && typeof document !== 'undefined' && createPortal(
        <div 
          className="modal-backdrop"
          onClick={() => setEnhancerModalOpen(false)}
          style={{
            position: 'fixed',
            inset: 0,
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            width: '100vw',
            height: '100vh',
            backgroundColor: 'rgba(3, 7, 18, 0.82)',
            backdropFilter: 'blur(8px)',
            WebkitBackdropFilter: 'blur(8px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 99999,
            padding: '1rem',
            boxSizing: 'border-box'
          }}
        >
          <div 
            className="glass-card modal-content" 
            onClick={(e) => e.stopPropagation()}
            style={{
              maxWidth: '640px',
              width: '100%',
              maxHeight: '90vh',
              overflowY: 'auto',
              padding: '1.5rem',
              borderRadius: 'var(--radius-lg)',
              background: 'var(--bg-modal, #0f172a)',
              border: '1px solid rgba(56, 189, 248, 0.4)',
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.75)',
              position: 'relative'
            }}
          >
            <button
              onClick={() => setEnhancerModalOpen(false)}
              style={{
                position: 'absolute',
                top: '1.25rem',
                right: '1.25rem',
                background: 'transparent',
                border: 'none',
                color: 'var(--text-muted)',
                cursor: 'pointer',
                padding: '0.25rem',
                borderRadius: '4px'
              }}
              title="Close modal"
            >
              <X size={18} />
            </button>

            {/* Modal Header */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '1rem' }}>
              <div style={{
                width: '38px',
                height: '38px',
                borderRadius: '50%',
                background: 'rgba(56, 189, 248, 0.15)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--accent-cyan)'
              }}>
                <Wand2 size={20} />
              </div>
              <div>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  LLM Resume Section Enhancer
                </h3>
                <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                  Optimizing <strong>{enhancerSection.toUpperCase()}</strong> for {analysis?.detected_domain || 'your domain'}.
                </p>
              </div>
            </div>

            {/* Original Phrasing */}
            <div style={{ padding: '0.65rem 0.85rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.06)', border: '1px solid rgba(244, 63, 94, 0.2)', marginBottom: '0.85rem' }}>
              <span style={{ fontSize: '0.65rem', fontWeight: 700, color: '#fb7185', textTransform: 'uppercase' }}>
                Current Resume Phrasing:
              </span>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '0.2rem', fontStyle: 'italic', lineHeight: 1.4, margin: 0 }}>
                {typeof enhancerOriginalContent === 'string' ? enhancerOriginalContent : JSON.stringify(enhancerOriginalContent)}
              </p>
            </div>

            {enhancerIsLoading ? (
              <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                <RefreshCw size={26} className="animate-spin-slow" style={{ margin: '0 auto 0.6rem auto', color: 'var(--accent-cyan)' }} />
                <p style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>
                  EmployAI LLM is synthesizing high-impact STAR wording with action verbs...
                </p>
              </div>
            ) : enhancerError ? (
              <div style={{ padding: '0.85rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.1)', color: '#fb7185', fontSize: '0.78rem', marginBottom: '0.85rem' }}>
                {enhancerError}
              </div>
            ) : enhancerResponse ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                {/* Action Verbs & Keywords Chips */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap' }}>
                  <span style={{ fontSize: '0.68rem', fontWeight: 700, color: 'var(--text-muted)' }}>Action Verbs:</span>
                  {(enhancerResponse.action_verbs_used || []).map((v, i) => (
                    <span key={i} className="badge badge-violet" style={{ fontSize: '0.65rem' }}>{v}</span>
                  ))}
                  {(enhancerResponse.keywords_infused || []).map((k, i) => (
                    <span key={`k-${i}`} className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>{k}</span>
                  ))}
                  <span className="badge badge-emerald" style={{ fontSize: '0.65rem', marginLeft: 'auto' }}>
                    +1 ATS Lift
                  </span>
                </div>

                {/* Quick Style & Action Verb Archetype Selector */}
                <div>
                  <label style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.35rem' }}>
                    Choose AI Wording Style & Verb Archetype:
                  </label>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                    {ENHANCER_ARCHETYPES.map((arch) => {
                      const isCurrent = enhancerSelectedArchetype === arch.id;
                      return (
                        <button
                          key={arch.id}
                          type="button"
                          onClick={() => handleRegenerateEnhancement(arch.id)}
                          className={`btn btn-sm ${isCurrent ? 'btn-primary' : 'btn-secondary'}`}
                          style={{ fontSize: '0.68rem', padding: '0.22rem 0.55rem', borderRadius: '6px' }}
                          title={arch.prompt}
                        >
                          {arch.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Suggestions Variations Selection */}
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
                    <label style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-secondary)', margin: 0 }}>
                      Select Suggested Wording Variation:
                    </label>
                    <span style={{ fontSize: '0.68rem', color: 'var(--accent-cyan)' }}>
                      {(enhancerResponse.suggested_bullets || [enhancerResponse.enhanced_content]).length} options generated
                    </span>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    {(enhancerResponse.suggested_bullets || [enhancerResponse.enhanced_content]).map((bullet, idx) => (
                      <div
                        key={idx}
                        onClick={() => setEnhancerSelectedVariation(bullet)}
                        style={{
                          padding: '0.7rem',
                          borderRadius: '8px',
                          border: enhancerSelectedVariation === bullet ? '1.5px solid #10b981' : '1px solid var(--border-subtle)',
                          background: enhancerSelectedVariation === bullet ? 'rgba(16, 185, 129, 0.08)' : 'rgba(255, 255, 255, 0.02)',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'flex-start',
                          gap: '0.5rem',
                          transition: 'all 0.15s ease'
                        }}
                      >
                        <div style={{
                          width: '16px',
                          height: '16px',
                          borderRadius: '50%',
                          border: enhancerSelectedVariation === bullet ? '5px solid #10b981' : '2px solid var(--border-subtle)',
                          flexShrink: 0,
                          marginTop: '0.15rem'
                        }} />
                        <div style={{ flex: 1 }}>
                          <span style={{ fontSize: '0.78rem', color: 'var(--text-primary)', lineHeight: 1.45, fontWeight: enhancerSelectedVariation === bullet ? 600 : 400 }}>
                            {bullet}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Editable Final Wording */}
                <div>
                  <label style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.25rem' }}>
                    Fine-tune Output Text:
                  </label>
                  <textarea
                    rows={3}
                    value={enhancerSelectedVariation}
                    onChange={e => setEnhancerSelectedVariation(e.target.value)}
                    className="input-field"
                    style={{ width: '100%', fontSize: '0.78rem', lineHeight: 1.4 }}
                  />
                </div>

                {/* Custom Instruction Box */}
                <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'center' }}>
                  <input
                    type="text"
                    placeholder="Custom instruction (e.g. 'Emphasize latency reduction & cost savings')..."
                    value={enhancerCustomPrompt}
                    onChange={e => setEnhancerCustomPrompt(e.target.value)}
                    className="input-field"
                    style={{ flex: 1, fontSize: '0.75rem' }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleRegenerateEnhancement();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => handleRegenerateEnhancement()}
                    className="btn btn-secondary btn-sm"
                    style={{ whiteSpace: 'nowrap', fontSize: '0.72rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                    title="Generate another set of distinct high-impact wordings"
                  >
                    <RefreshCw size={11} className={enhancerIsLoading ? 'animate-spin-slow' : ''} /> Regenerate ({enhancerRegenCount + 1})
                  </button>
                </div>
              </div>
            ) : null}

            {/* Modal Bottom Actions */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.65rem', marginTop: '1.25rem', borderTop: '1px solid var(--border-subtle)', paddingTop: '0.85rem' }}>
              <button
                type="button"
                onClick={() => setEnhancerModalOpen(false)}
                className="btn btn-secondary btn-sm"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleApplyEnhancement(enhancerSelectedVariation)}
                disabled={enhancerIsLoading || !enhancerSelectedVariation.trim()}
                className="btn btn-emerald btn-sm"
                style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}
              >
                <Check size={13} /> Apply (+1 ATS)
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* Delete Resume Confirmation Modal Dialog */}
      {showDeleteModal && typeof document !== 'undefined' && createPortal(
        <div 
          className="modal-backdrop"
          onClick={() => !isDeleting && setShowDeleteModal(false)}
          style={{
            position: 'fixed',
            inset: 0,
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            width: '100vw',
            height: '100vh',
            backgroundColor: 'rgba(3, 7, 18, 0.82)',
            backdropFilter: 'blur(8px)',
            WebkitBackdropFilter: 'blur(8px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 99999,
            padding: '1.25rem',
            boxSizing: 'border-box'
          }}
        >
          <div 
            className="glass-card modal-content" 
            onClick={(e) => e.stopPropagation()}
            style={{
              maxWidth: '460px',
              width: '100%',
              padding: '1.75rem',
              borderRadius: 'var(--radius-lg)',
              background: 'var(--bg-modal, #0f172a)',
              border: '1px solid rgba(244, 63, 94, 0.45)',
              boxShadow: '0 25px 60px -12px rgba(0, 0, 0, 0.85)',
              position: 'relative'
            }}
          >
            <button
              onClick={() => !isDeleting && setShowDeleteModal(false)}
              disabled={isDeleting}
              style={{
                position: 'absolute',
                top: '1.25rem',
                right: '1.25rem',
                background: 'transparent',
                border: 'none',
                color: 'var(--text-muted)',
                cursor: isDeleting ? 'not-allowed' : 'pointer',
                padding: '0.25rem',
                borderRadius: '4px'
              }}
              title="Close modal"
            >
              <X size={18} />
            </button>

            <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem', marginBottom: '1rem' }}>
              <div style={{
                width: '44px',
                height: '44px',
                borderRadius: '50%',
                background: 'rgba(244, 63, 94, 0.15)',
                border: '1px solid rgba(244, 63, 94, 0.3)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#f43f5e',
                flexShrink: 0
              }}>
                <AlertTriangle size={22} />
              </div>
              <div>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  Delete Active Resume?
                </h3>
                <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                  {analysis?.filename || uploadedFile?.name || 'Uploaded Resume'}
                </p>
              </div>
            </div>

            <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '1.25rem' }}>
              This will permanently delete your stored resume document, wipe your ATS score evaluation, and reset extracted skills. You can immediately upload a new resume or create one from scratch afterwards.
            </p>

            {deleteModalError && (
              <div style={{
                padding: '0.65rem 0.85rem',
                borderRadius: '6px',
                background: 'rgba(244, 63, 94, 0.12)',
                border: '1px solid rgba(244, 63, 94, 0.3)',
                color: '#f43f5e',
                fontSize: '0.78rem',
                marginBottom: '1rem'
              }}>
                {deleteModalError}
              </div>
            )}

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.65rem' }}>
              <button
                type="button"
                onClick={() => setShowDeleteModal(false)}
                className="btn btn-secondary btn-sm"
                disabled={isDeleting}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteResume}
                className="btn btn-danger btn-sm"
                disabled={isDeleting}
                style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
              >
                {isDeleting ? <RefreshCw size={14} className="animate-spin-slow" /> : <Trash2 size={14} />}
                {isDeleting ? 'Deleting Resume...' : 'Yes, Delete Resume'}
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* Floating Action Feedback Toast */}
      {toastMessage && (
        <div style={{
          position: 'fixed',
          bottom: '2rem',
          right: '2rem',
          zIndex: 10000,
          padding: '0.75rem 1.25rem',
          borderRadius: 'var(--radius-md)',
          background: 'var(--bg-secondary)',
          border: '1px solid var(--accent-emerald)',
          boxShadow: 'var(--shadow-lg)',
          color: 'var(--text-primary)',
          fontSize: '0.825rem',
          fontWeight: 600,
          display: 'flex',
          alignItems: 'center',
          gap: '0.55rem'
        }}>
          <CheckCircle2 size={16} color="#10b981" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. MY RESUMES MODAL */}
      <MyResumesModal
        isOpen={showMyResumesModal}
        onClose={() => setShowMyResumesModal(false)}
        currentDocumentId={analysis?.document_id}
        onOpenResume={handleOpenSavedResume}
        onUploadNew={() => fileInputRef.current?.click()}
        onDeleteCurrentResume={() => {
          setAnalysis(null);
          setStructuredResume(null);
          setOriginalStructuredResume(null);
          setUploadedFile(null);
          setActiveFileBlob(null);
          setTargetJobTitle('');
          setTargetJobDesc('');
        }}
      />

      {/* 2. RESUME VERSIONS MODAL */}
      <ResumeVersionsModal
        isOpen={showVersionsModal}
        onClose={() => setShowVersionsModal(false)}
        documentId={analysis?.document_id}
        activeVersionId={activeVersionId}
        currentStructuredResume={structuredResume}
        onSwitchVersion={handleSwitchVersion}
        onSaveNewVersion={handleSaveNewVersion}
      />

      {/* 3. TARGETED BULLET IMPROVEMENT MODAL */}
      <BulletImprovementModal
        isOpen={bulletImproveModalOpen}
        onClose={() => {
          setBulletImproveModalOpen(false);
          setBulletImproveData(null);
        }}
        originalBullet={bulletImproveData?.bullet || ''}
        roleOrProject={bulletImproveData?.roleOrProject}
        targetDomain={bulletImproveData?.targetDomain || analysis?.detected_domain}
        targetJob={targetJobTitle || undefined}
        onApply={handleApplyBulletImprovement}
      />

      {/* 4. SUMMARY IMPROVEMENT MODAL */}
      <SummaryImprovementModal
        isOpen={showSummaryImproveModal}
        onClose={() => setShowSummaryImproveModal(false)}
        currentSummary={structuredResume?.summary || structuredResume?.personal_info?.summary}
        targetDomain={analysis?.detected_domain}
        skills={structuredResume?.skills}
        onApply={handleApplySummaryImprovement}
      />

      {/* 5. HEADLINE GENERATOR MODAL */}
      <HeadlineImprovementModal
        isOpen={showHeadlineImproveModal}
        onClose={() => setShowHeadlineImproveModal(false)}
        name={structuredResume?.personal_info?.full_name}
        domain={analysis?.detected_domain}
        skills={structuredResume?.skills}
        experienceRoles={(structuredResume?.experience || []).map(e => e.role).filter(Boolean) as string[]}
        targetJob={targetJobTitle || undefined}
        onApply={handleApplyHeadline}
      />

      {/* 6. RESUME QUALITY CHECK MODAL */}
      <QualityCheckModal
        isOpen={showQualityModal}
        onClose={() => setShowQualityModal(false)}
        structuredResume={structuredResume}
        targetJob={targetJobDesc || undefined}
        onApplyFix={handleQualityApplyFix}
      />

      {/* 7. RESUME COMPARISON MODAL */}
      <ResumeComparisonModal
        isOpen={showComparisonModal}
        onClose={() => setShowComparisonModal(false)}
        originalStructuredResume={originalStructuredResume}
        currentStructuredResume={structuredResume}
        originalATSScore={analysis?.resume_quality_score || 74}
        currentATSScore={currentScore}
        appliedChanges={appliedChanges}
        onUndoChange={handleUndoChange}
        onRevertAll={handleRevertAllBaseline}
      />

      {/* 8. EXPORT RESUME MODAL */}
      <ExportResumeModal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        structuredResume={structuredResume}
        templateId={selectedTemplate}
        filename={analysis?.filename || uploadedFile?.name || 'Resume'}
      />

      {/* 9. JOB-SPECIFIC TAILORING MODAL (Unified workspace & video demo) */}
      <JobTailoringModal
        isOpen={showJobTailoringModal}
        onClose={() => setShowJobTailoringModal(false)}
        documentId={analysis?.document_id}
        currentStructuredResume={structuredResume}
        rawResumeText={analysis?.raw_text}
        initialJobDescription={targetJobDesc}
        initialJobTitle={targetJobTitle}
        initialTab={tailoringModalTab}
        onApplyTailoredResume={handleApplyTailoredResume}
        onSaveAsNewVersion={handleSaveTailoredVersionAsNew}
      />

      {/* 10. RESUME TEMPLATES GALLERY MODAL */}
      <ResumeTemplatesModal
        isOpen={showTemplatesModal}
        onClose={() => setShowTemplatesModal(false)}
        activeTemplateId={selectedTemplate}
        onSelectTemplate={(newT) => {
          handleTemplateChange(newT);
          setToastMessage(`Switched resume layout to "${newT.replace('_', ' ').toUpperCase()}" template!`);
          setTimeout(() => setToastMessage(null), 3000);
        }}
      />

      {/* 11. MAKE RESUME FROM SCRATCH MODAL */}
      <CreateResumeScratchModal
        isOpen={showCreateScratchModal}
        onClose={() => setShowCreateScratchModal(false)}
        onSave={handleCreateScratchResume}
      />
    </div>
  );
};

export const ResumeAnalyzer = React.memo(ResumeAnalyzerComponent);
