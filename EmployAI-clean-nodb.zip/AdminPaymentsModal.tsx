import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { paymentsApi } from '../services/api';
import type { PaymentItem } from '../types';
import { 
  X, ShieldCheck, Search, RefreshCw, UserCheck
} from 'lucide-react';

export interface AdminPaymentsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminPaymentsModal: React.FC<AdminPaymentsModalProps> = ({ isOpen, onClose }) => {
  const { user, isAdmin } = useAuth();

  const [payments, setPayments] = useState<PaymentItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  // Manual grant state
  const [grantEmail, setGrantEmail] = useState<string>('');
  const [grantMessage, setGrantMessage] = useState<string | null>(null);

  const loadPayments = async () => {
    try {
      setIsLoading(true);
      const list = await paymentsApi.adminGetAllPayments();
      setPayments(list);
    } catch (err: any) {
      console.warn('Failed to load payments:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && isAdmin) {
      loadPayments();
    }
  }, [isOpen, isAdmin]);

  if (!isOpen || !isAdmin) return null;

  const handleVerify = async (paymentId: string) => {
    try {
      setActionLoadingId(paymentId);
      await paymentsApi.adminVerifyPayment(paymentId);
      await loadPayments();
    } catch (err: any) {
      alert(err?.message || 'Failed to verify payment');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleReject = async (paymentId: string) => {
    if (!confirm('Are you sure you want to reject this payment submission?')) return;
    try {
      setActionLoadingId(paymentId);
      await paymentsApi.adminRejectPayment(paymentId, 'Rejected by Administrator');
      await loadPayments();
    } catch (err: any) {
      alert(err?.message || 'Failed to reject payment');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleManualGrant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!grantEmail.trim()) return;
    try {
      await paymentsApi.adminGrantPremium(grantEmail.trim(), true);
      setGrantMessage(`Granted premium access to ${grantEmail}`);
      setGrantEmail('');
      setTimeout(() => setGrantMessage(null), 3000);
      await loadPayments();
    } catch (err: any) {
      alert(err?.message || 'Failed to grant premium access');
    }
  };

  const filteredPayments = payments.filter(p => {
    const matchesSearch = 
      (p.user_email || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.user_name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.utr_number || '').toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterStatus === 'all' || p.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const totalCollected = payments.filter(p => p.status === 'verified').length * 50;
  const pendingCount = payments.filter(p => p.status === 'pending').length;
  const verifiedCount = payments.filter(p => p.status === 'verified').length;

  return (
    <div 
      className="modal-overlay" 
      onClick={onClose}
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(5, 10, 24, 0.88)',
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999,
        padding: '1rem'
      }}
    >
      <div 
        className="glass-card" 
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: '1000px',
          maxHeight: '92vh',
          overflowY: 'auto',
          background: 'linear-gradient(145deg, #0c1424, #060a14)',
          borderRadius: '24px',
          border: '1px solid rgba(56, 189, 248, 0.35)',
          boxShadow: '0 25px 60px -15px rgba(0, 0, 0, 0.8)',
          position: 'relative',
          padding: '2rem'
        }}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          type="button"
          aria-label="Close"
          style={{
            position: 'absolute',
            top: '1.25rem',
            right: '1.25rem',
            background: 'rgba(255, 255, 255, 0.06)',
            border: '1px solid var(--border-subtle)',
            color: 'var(--text-secondary)',
            borderRadius: '50%',
            width: '36px',
            height: '36px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            zIndex: 10
          }}
        >
          <X size={18} />
        </button>

        {/* Modal Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
              <span className="badge badge-purple" style={{ fontSize: '0.72rem', fontWeight: 800 }}>
                <ShieldCheck size={13} /> Master Admin Portal
              </span>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                Logged in as <strong style={{ color: 'var(--accent-cyan)' }}>{user?.email}</strong>
              </span>
            </div>
            <h2 style={{ fontSize: '1.6rem', fontWeight: 900, color: 'var(--text-primary)', margin: 0 }}>
              UPI Payments & Subscription Verifications
            </h2>
          </div>

          <button
            onClick={loadPayments}
            className="btn btn-outline-cyan btn-sm"
            style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.8rem' }}
          >
            <RefreshCw size={14} className={isLoading ? 'spin' : ''} /> Refresh List
          </button>
        </div>

        {/* Statistics Cards */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
          gap: '1rem',
          marginBottom: '1.5rem'
        }}>
          <div style={{ padding: '1rem', borderRadius: '14px', background: 'rgba(56, 189, 248, 0.08)', border: '1px solid rgba(56, 189, 248, 0.2)' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>Total Verified</span>
            <div style={{ fontSize: '1.5rem', fontWeight: 900, color: 'var(--accent-cyan)' }}>{verifiedCount}</div>
          </div>
          <div style={{ padding: '1rem', borderRadius: '14px', background: 'rgba(234, 179, 8, 0.08)', border: '1px solid rgba(234, 179, 8, 0.2)' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>Pending Verification</span>
            <div style={{ fontSize: '1.5rem', fontWeight: 900, color: '#facc15' }}>{pendingCount}</div>
          </div>
          <div style={{ padding: '1rem', borderRadius: '14px', background: 'rgba(16, 185, 129, 0.08)', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>Total Revenue</span>
            <div style={{ fontSize: '1.5rem', fontWeight: 900, color: 'var(--accent-emerald)' }}>₹{totalCollected}</div>
          </div>
          <div style={{ padding: '1rem', borderRadius: '14px', background: 'rgba(168, 85, 247, 0.08)', border: '1px solid rgba(168, 85, 247, 0.2)' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>Total Submissions</span>
            <div style={{ fontSize: '1.5rem', fontWeight: 900, color: 'var(--accent-purple)' }}>{payments.length}</div>
          </div>
        </div>

        {/* Quick Manual Grant Form */}
        <div style={{ padding: '1rem 1.25rem', borderRadius: '14px', background: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--border-subtle)', marginBottom: '1.5rem' }}>
          <div style={{ fontSize: '0.825rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.5rem' }}>
            Instant Access Tool: Grant Premium Access by Email
          </div>
          <form onSubmit={handleManualGrant} style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
            <input
              type="email"
              required
              placeholder="candidate@university.edu"
              value={grantEmail}
              onChange={(e) => setGrantEmail(e.target.value)}
              style={{
                flex: 1,
                minWidth: '220px',
                padding: '0.55rem 0.85rem',
                borderRadius: '8px',
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border-subtle)',
                color: 'var(--text-primary)',
                fontSize: '0.85rem',
                outline: 'none'
              }}
            />
            <button type="submit" className="btn btn-primary btn-sm" style={{ fontWeight: 700 }}>
              <UserCheck size={14} /> Grant Lifetime PRO Access
            </button>
          </form>
          {grantMessage && (
            <div style={{ fontSize: '0.75rem', color: 'var(--accent-emerald)', marginTop: '0.4rem', fontWeight: 600 }}>
              ✓ {grantMessage}
            </div>
          )}
        </div>

        {/* Filters & Search */}
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', marginBottom: '1rem' }}>
          <div style={{ position: 'relative', flex: 1, minWidth: '220px' }}>
            <Search size={15} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              type="text"
              placeholder="Search by email, candidate name, or UTR number..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                width: '100%',
                padding: '0.55rem 0.85rem 0.55rem 2.25rem',
                borderRadius: '8px',
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border-subtle)',
                color: 'var(--text-primary)',
                fontSize: '0.825rem',
                outline: 'none',
                boxSizing: 'border-box'
              }}
            />
          </div>

          <div style={{ display: 'flex', gap: '0.4rem' }}>
            {['all', 'pending', 'verified', 'rejected'].map(st => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                style={{
                  padding: '0.45rem 0.85rem',
                  borderRadius: '8px',
                  border: filterStatus === st ? '1px solid var(--accent-cyan)' : '1px solid var(--border-subtle)',
                  background: filterStatus === st ? 'rgba(56, 189, 248, 0.15)' : 'transparent',
                  color: filterStatus === st ? 'var(--accent-cyan)' : 'var(--text-secondary)',
                  fontSize: '0.75rem',
                  fontWeight: 700,
                  textTransform: 'capitalize',
                  cursor: 'pointer'
                }}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Payments Table */}
        <div style={{ borderRadius: '12px', border: '1px solid var(--border-subtle)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.8rem' }}>
            <thead>
              <tr style={{ background: 'rgba(255, 255, 255, 0.04)', borderBottom: '1px solid var(--border-subtle)' }}>
                <th style={{ padding: '0.75rem 1rem', color: 'var(--text-secondary)', fontWeight: 700 }}>User / Candidate</th>
                <th style={{ padding: '0.75rem 1rem', color: 'var(--text-secondary)', fontWeight: 700 }}>UTR Number</th>
                <th style={{ padding: '0.75rem 1rem', color: 'var(--text-secondary)', fontWeight: 700 }}>App & Amount</th>
                <th style={{ padding: '0.75rem 1rem', color: 'var(--text-secondary)', fontWeight: 700 }}>Submitted Date</th>
                <th style={{ padding: '0.75rem 1rem', color: 'var(--text-secondary)', fontWeight: 700 }}>Status</th>
                <th style={{ padding: '0.75rem 1rem', color: 'var(--text-secondary)', fontWeight: 700, textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan={6} style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                    No payment submissions match current filters.
                  </td>
                </tr>
              ) : (
                filteredPayments.map((p) => (
                  <tr key={p.id} style={{ borderBottom: '1px solid var(--border-subtle)', background: 'rgba(255, 255, 255, 0.01)' }}>
                    <td style={{ padding: '0.75rem 1rem' }}>
                      <strong style={{ color: 'var(--text-primary)', display: 'block' }}>{p.payer_name || p.user_name || 'Candidate'}</strong>
                      <span style={{ fontSize: '0.72rem', color: 'var(--accent-cyan)' }}>{p.user_email}</span>
                    </td>
                    <td style={{ padding: '0.75rem 1rem' }}>
                      <code style={{ background: 'rgba(0, 0, 0, 0.3)', padding: '0.2rem 0.4rem', borderRadius: '4px', color: '#e2e8f0', fontWeight: 700 }}>
                        {p.utr_number}
                      </code>
                    </td>
                    <td style={{ padding: '0.75rem 1rem' }}>
                      <span style={{ color: 'var(--text-secondary)', display: 'block' }}>{p.payment_app || 'PhonePe'}</span>
                      <strong style={{ color: 'var(--accent-emerald)' }}>₹{p.amount}</strong>
                    </td>
                    <td style={{ padding: '0.75rem 1rem', color: 'var(--text-muted)' }}>
                      {new Date(p.created_at).toLocaleDateString()} {new Date(p.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td style={{ padding: '0.75rem 1rem' }}>
                      <span className={`badge ${
                        p.status === 'verified' ? 'badge-emerald' : p.status === 'pending' ? 'badge-cyan' : 'badge-purple'
                      }`} style={{ textTransform: 'capitalize' }}>
                        {p.status}
                      </span>
                    </td>
                    <td style={{ padding: '0.75rem 1rem', textAlign: 'right' }}>
                      {p.status === 'pending' ? (
                        <div style={{ display: 'inline-flex', gap: '0.4rem' }}>
                          <button
                            onClick={() => handleVerify(p.id)}
                            disabled={actionLoadingId === p.id}
                            className="btn btn-emerald btn-sm"
                            style={{ fontSize: '0.72rem', padding: '0.35rem 0.65rem' }}
                          >
                            Approve & Unlock
                          </button>
                          <button
                            onClick={() => handleReject(p.id)}
                            disabled={actionLoadingId === p.id}
                            className="btn btn-outline-cyan btn-sm"
                            style={{ fontSize: '0.72rem', padding: '0.35rem 0.65rem', borderColor: '#ef4444', color: '#ef4444' }}
                          >
                            Reject
                          </button>
                        </div>
                      ) : p.status === 'verified' ? (
                        <span style={{ color: 'var(--accent-emerald)', fontSize: '0.75rem', fontWeight: 700 }}>
                          ✓ Active PRO
                        </span>
                      ) : (
                        <span style={{ color: '#ef4444', fontSize: '0.75rem', fontWeight: 600 }}>
                          Rejected
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminPaymentsModal;
