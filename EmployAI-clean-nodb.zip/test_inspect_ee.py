import urllib.request
import json
import re

with open(r'src/utils/coreEngineeringYouTubeData.ts', 'r', encoding='utf-8') as f:
    content = f.read()

ee_keys = ['ee-embedded', 'ee-vlsi', 'ee-pcb', 'ee-powerelec', 'ee-matlab', 'ee-evbms']

for key in ee_keys:
    pos = content.find(f"'{key}':")
    if pos == -1:
        print(f"MISSING {key}")
        continue
    # find where next track starts (look for 4 spaces + 'something': { )
    next_pos = content.find("  '", pos + 10)
    if next_pos == -1:
        next_pos = pos + 4500
    block = content[pos:next_pos]
    
    print("=" * 60)
    print(f"TRACK: {key}")
    print("=" * 60)
    
    # find each phase 0, 1, 2, 3, 4
    for phase_idx in range(5):
        m = re.search(r'\b' + str(phase_idx) + r':\s*\[\{(.*?)\}\]', block, re.DOTALL)
        if m:
            pblock = m.group(1)
            title = re.search(r'title:\s*["\']([^"\']+)["\']', pblock)
            yt = re.search(r'youtube_video_id:\s*["\']([^"\']+)["\']', pblock)
            fb = re.search(r'fallback_video_id:\s*["\']([^"\']+)["\']', pblock)
            ch = re.search(r'channel_name:\s*["\']([^"\']+)["\']', pblock)
            t_str = title.group(1) if title else "NO TITLE"
            y_str = yt.group(1) if yt else "NO YT"
            f_str = fb.group(1) if fb else "NO FB"
            c_str = ch.group(1) if ch else "NO CH"
            
            # Fetch actual YouTube video title via oembed
            real_title = "ERROR"
            real_channel = ""
            try:
                url = f"https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v={y_str}&format=json"
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                res = urllib.request.urlopen(req)
                d = json.loads(res.read().decode('utf-8'))
                real_title = d.get('title', '')
                real_channel = d.get('author_name', '')
            except Exception as e:
                real_title = f"FAILED: {e}"
                
            real_title = real_title.encode('ascii', 'replace').decode('ascii')
            real_channel = real_channel.encode('ascii', 'replace').decode('ascii')
            print(f"Phase {phase_idx}:")
            print(f"  Curated Title: {t_str}")
            print(f"  Video ID:      {y_str} (Fallback: {f_str})")
            print(f"  Curated Ch:    {c_str}")
            print(f"  Actual YT:     {real_title} (by {real_channel})")
            print()
