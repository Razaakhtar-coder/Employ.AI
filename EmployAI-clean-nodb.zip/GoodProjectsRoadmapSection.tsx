import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  FolderGit2, Sparkles, CheckCircle2, Circle, 
  Copy, Check, ArrowRight, ArrowUp,
  Terminal, Shield, 
  HelpCircle, Lightbulb, Zap, 
  ChevronDown, ChevronUp, Search, Award
} from 'lucide-react';
import { 
  generateProjectsForCoDomain, 
  type GoodProject, 
  type ProjectTier 
} from '../utils/domainProjectData';
import { getRoleProTipLabel } from '../utils/domainCoDomainIntelligence';
import type { CoDomainDefinition } from '../utils/domainRoadmapData';

interface GoodProjectsRoadmapSectionProps {
  activeStream: string;
  selectedCoDomain: string;
  onSelectCoDomain?: (coDomainName: string, stream: string) => void;
  availableCoDomains?: CoDomainDefinition[];
  onScrollToPlacementRoadmap?: () => void;
}

export const GoodProjectsRoadmapSection: React.FC<GoodProjectsRoadmapSectionProps> = ({
  activeStream,
  selectedCoDomain,
  onSelectCoDomain,
  availableCoDomains = [],
  onScrollToPlacementRoadmap
}) => {
  // Active Project Selection
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const [selectedTierFilter, setSelectedTierFilter] = useState<'all' | ProjectTier>('all');
  const [projectSearchQuery, setProjectSearchQuery] = useState<string>('');
  
  // Completed Task Tracking via LocalStorage
  const [completedTasks, setCompletedTasks] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('employai_project_completed_tasks');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {};
  });

  // Step Expand/Collapse State per Project
  const [expandedSteps, setExpandedSteps] = useState<Record<number, boolean>>({
    0: true, 1: true, 2: true, 3: true, 4: true
  });

  // Copy Feedback Toast
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  }, []);

  // Generate Projects dynamically for the selected stream and co-domain
  const projects: GoodProject[] = useMemo(() => {
    return generateProjectsForCoDomain(selectedCoDomain, activeStream);
  }, [selectedCoDomain, activeStream]);

  // Set default selected project when list changes
  useEffect(() => {
    if (projects.length > 0) {
      const currentExists = projects.some(p => p.id === selectedProjectId);
      if (!currentExists) {
        setSelectedProjectId(projects[0].id);
      }
    }
  }, [projects, selectedProjectId]);

  // Active Project Object
  const activeProject = useMemo(() => {
    return projects.find(p => p.id === selectedProjectId) || projects[0] || null;
  }, [projects, selectedProjectId]);

  // Filtered Projects for Cards Grid
  const filteredProjects = useMemo(() => {
    return projects.filter(p => {
      const matchesTier = selectedTierFilter === 'all' || p.tier === selectedTierFilter;
      const q = projectSearchQuery.toLowerCase().trim();
      if (!q) return matchesTier;

      const techMatch = Object.values(p.techStack).some(arr => 
        arr?.some(t => t.toLowerCase().includes(q))
      );
      const titleMatch = p.title.toLowerCase().includes(q);
      const taglineMatch = p.tagline.toLowerCase().includes(q);
      const descMatch = p.description.toLowerCase().includes(q);

      return matchesTier && (titleMatch || taglineMatch || descMatch || techMatch);
    });
  }, [projects, selectedTierFilter, projectSearchQuery]);

  // Task Toggle Handler
  const handleToggleTask = useCallback((taskId: string) => {
    setCompletedTasks(prev => {
      const updated = { ...prev, [taskId]: !prev[taskId] };
      try {
        localStorage.setItem('employai_project_completed_tasks', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  }, []);

  // Compute Project Progress Stats
  const getProjectStats = useCallback((project: GoodProject) => {
    let totalTasks = 0;
    let doneTasks = 0;

    project.buildRoadmap.forEach(step => {
      step.tasks.forEach(task => {
        totalTasks += 1;
        if (completedTasks[task.id]) {
          doneTasks += 1;
        }
      });
    });

    const completionPct = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;
    return { totalTasks, doneTasks, completionPct };
  }, [completedTasks]);

  // Copy Helper
  const handleCopyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    showToast(`Copied ${label} to clipboard!`);
  };

  // Toggle step expansion
  const toggleStepExpand = (stepIdx: number) => {
    setExpandedSteps(prev => ({ ...prev, [stepIdx]: !prev[stepIdx] }));
  };

  const activeProjectStats = useMemo(() => {
    if (!activeProject) return { totalTasks: 0, doneTasks: 0, completionPct: 0 };
    return getProjectStats(activeProject);
  }, [activeProject, getProjectStats]);

  const tierColors: Record<ProjectTier, { text: string; bg: string; border: string; glow: string }> = {
    foundational: { text: '#00f2fe', bg: 'rgba(0, 242, 254, 0.1)', border: 'rgba(0, 242, 254, 0.35)', glow: '0 0 16px rgba(0, 242, 254, 0.2)' },
    applied: { text: '#38bdf8', bg: 'rgba(56, 189, 248, 0.1)', border: 'rgba(56, 189, 248, 0.35)', glow: '0 0 16px rgba(56, 189, 248, 0.2)' },
    scalable: { text: '#a855f7', bg: 'rgba(168, 85, 247, 0.1)', border: 'rgba(168, 85, 247, 0.35)', glow: '0 0 16px rgba(168, 85, 247, 0.2)' },
    flagship: { text: '#10b981', bg: 'rgba(16, 185, 129, 0.1)', border: 'rgba(16, 185, 129, 0.35)', glow: '0 0 16px rgba(16, 185, 129, 0.2)' }
  };

  return (
    <div id="good-projects-section" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', marginTop: '1.5rem', scrollMarginTop: '80px' }}>
      {/* Toast Notification */}
      {toastMsg && (
        <div style={{
          position: 'fixed',
          top: '1.5rem',
          right: '1.5rem',
          zIndex: 99999,
          background: 'var(--bg-modal)',
          color: 'var(--text-primary)',
          border: '1.5px solid var(--accent-cyan)',
          padding: '0.75rem 1.25rem',
          borderRadius: '10px',
          boxShadow: 'var(--shadow-modal)',
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          fontSize: '0.85rem',
          fontWeight: 700
        }}>
          <Check size={16} color="var(--accent-emerald)" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Section Header Banner */}
      <div 
        className="glass-card" 
        style={{ 
          padding: '1.5rem 1.75rem', 
          borderRadius: '14px',
          background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.08) 0%, rgba(168, 85, 247, 0.08) 50%, rgba(16, 185, 129, 0.05) 100%)',
          border: '1.5px solid rgba(56, 189, 248, 0.35)',
          display: 'flex',
          flexDirection: 'column',
          gap: '1rem'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap', marginBottom: '0.4rem' }}>
              <div style={{
                width: '38px',
                height: '38px',
                borderRadius: '10px',
                background: 'linear-gradient(135deg, #0284c7 0%, #38bdf8 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: 'var(--glow-cyan)'
              }}>
                <FolderGit2 size={22} color="#ffffff" />
              </div>
              <h2 style={{ fontSize: '1.45rem', fontWeight: 900, color: 'var(--text-primary)', margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                Industry-Grade Good Projects & Build Roadmaps
              </h2>
              <span className="badge badge-cyan" style={{ fontSize: '0.72rem', fontWeight: 800 }}>
                <Sparkles size={12} /> Tailored for: {selectedCoDomain}
              </span>
              <span className="badge badge-purple" style={{ fontSize: '0.72rem', fontWeight: 700 }}>
                {activeStream}
              </span>

              {availableCoDomains.length > 0 && onSelectCoDomain && (
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}>
                  <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)', fontWeight: 600 }}>Switch Co-Domain:</span>
                  <select
                    value={selectedCoDomain}
                    onChange={(e) => onSelectCoDomain(e.target.value, activeStream)}
                    style={{
                      fontSize: '0.72rem',
                      fontWeight: 700,
                      padding: '0.2rem 0.5rem',
                      borderRadius: '6px',
                      background: 'var(--bg-glass)',
                      color: 'var(--accent-cyan)',
                      border: '1px solid var(--border-subtle)',
                      outline: 'none',
                      cursor: 'pointer'
                    }}
                  >
                    {availableCoDomains.map(cd => (
                      <option key={cd.id} value={cd.name} style={{ background: 'var(--bg-card)', color: 'var(--text-primary)' }}>
                        {cd.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', margin: 0, maxWidth: '850px', lineHeight: 1.5 }}>
              Curated, production-grade projects designed to prove genuine engineering competency to hiring managers and recruiters. 
              Each project features a complete 5-step build roadmap, architecture blueprint, STAR resume bullet point, and technical interview questions.
            </p>
          </div>

          {/* Quick Jump Back to Placement Syllabus */}
          {onScrollToPlacementRoadmap && (
            <button
              type="button"
              onClick={onScrollToPlacementRoadmap}
              className="btn btn-secondary btn-sm"
              style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700, borderRadius: '8px' }}
            >
              <ArrowUp size={14} color="var(--accent-cyan)" /> Back to Placement Syllabus
            </button>
          )}
        </div>

        {/* Global Filter Bar for Projects */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '0.75rem',
          borderTop: '1px solid var(--border-subtle)',
          paddingTop: '0.85rem'
        }}>
          {/* Tier Tabs */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', marginRight: '0.3rem' }}>
              Project Tiers:
            </span>
            {[
              { id: 'all', label: `All Projects (${projects.length})` },
              { id: 'foundational', label: '🏁 Foundational Core' },
              { id: 'applied', label: '⚡ Applied SaaS/MVP' },
              { id: 'scalable', label: '🔬 Scalable Systems' },
              { id: 'flagship', label: '🚀 Flagship Capstone' }
            ].map(tab => {
              const isSelected = selectedTierFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setSelectedTierFilter(tab.id as any)}
                  className={isSelected ? 'btn btn-primary btn-sm' : 'btn btn-secondary btn-sm'}
                  style={{
                    fontSize: '0.73rem',
                    padding: '0.28rem 0.65rem',
                    borderRadius: '6px',
                    fontWeight: isSelected ? 800 : 500
                  }}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Search Bar within Projects */}
          <div style={{ position: 'relative', minWidth: '240px' }}>
            <Search size={13} style={{ position: 'absolute', left: '0.65rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              type="text"
              placeholder="Search tech stack, title, features..."
              value={projectSearchQuery}
              onChange={(e) => setProjectSearchQuery(e.target.value)}
              style={{
                width: '100%',
                padding: '0.35rem 0.5rem 0.35rem 1.9rem',
                fontSize: '0.75rem',
                borderRadius: '6px',
                background: 'var(--bg-glass)',
                border: '1px solid var(--border-subtle)',
                color: 'var(--text-primary)',
                outline: 'none'
              }}
            />
          </div>
        </div>
      </div>

      {/* Project Cards Grid Showcase */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: '1rem'
      }}>
        {filteredProjects.map((project) => {
          const isSelected = activeProject?.id === project.id;
          const stats = getProjectStats(project);
          const tColor = tierColors[project.tier] || tierColors.foundational;

          return (
            <div
              key={project.id}
              onClick={() => {
                setSelectedProjectId(project.id);
                const el = document.getElementById('active-project-roadmap-view');
                if (el) {
                  el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
              }}
              className="glass-card"
              style={{
                padding: '1.25rem',
                borderRadius: '12px',
                border: isSelected ? `2px solid ${tColor.text}` : '1px solid var(--border-subtle)',
                background: isSelected ? 'var(--bg-card-hover)' : 'var(--bg-card)',
                boxShadow: isSelected ? tColor.glow : 'var(--shadow-sm)',
                cursor: 'pointer',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                gap: '0.85rem',
                transition: 'all 0.2s ease',
                position: 'relative',
                overflow: 'hidden'
              }}
              onMouseEnter={(e) => {
                if (!isSelected) {
                  e.currentTarget.style.borderColor = tColor.text;
                  e.currentTarget.style.transform = 'translateY(-2px)';
                }
              }}
              onMouseLeave={(e) => {
                if (!isSelected) {
                  e.currentTarget.style.borderColor = 'var(--border-subtle)';
                  e.currentTarget.style.transform = 'translateY(0)';
                }
              }}
            >
              {/* Top Row: Tier Badge & Difficulty */}
              <div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.6rem' }}>
                  <span style={{
                    fontSize: '0.68rem',
                    fontWeight: 800,
                    padding: '0.2rem 0.55rem',
                    borderRadius: '6px',
                    background: tColor.bg,
                    color: tColor.text,
                    border: `1px solid ${tColor.border}`
                  }}>
                    {project.tierLabel}
                  </span>
                  <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)', fontWeight: 600 }}>
                    ⏱️ {project.estimatedDuration}
                  </span>
                </div>

                <h3 style={{
                  fontSize: '1rem',
                  fontWeight: 800,
                  color: 'var(--text-primary)',
                  margin: '0 0 0.35rem 0',
                  lineHeight: 1.35
                }}>
                  {project.title}
                </h3>

                <p style={{
                  fontSize: '0.78rem',
                  color: 'var(--text-secondary)',
                  margin: '0 0 0.65rem 0',
                  lineHeight: 1.45
                }}>
                  {project.tagline}
                </p>

                {/* Tech Stack Chips */}
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem', marginBottom: '0.75rem' }}>
                  {Object.values(project.techStack).flat().slice(0, 4).map((tech, idx) => (
                    <span 
                      key={idx}
                      style={{
                        fontSize: '0.67rem',
                        padding: '0.15rem 0.45rem',
                        borderRadius: '4px',
                        background: 'rgba(255, 255, 255, 0.05)',
                        border: '1px solid var(--border-subtle)',
                        color: 'var(--text-secondary)'
                      }}
                    >
                      {tech}
                    </span>
                  ))}
                  {(Object.values(project.techStack).flat().length > 4) && (
                    <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)', alignSelf: 'center' }}>
                      +{Object.values(project.techStack).flat().length - 4} more
                    </span>
                  )}
                </div>
              </div>

              {/* Bottom Row: Build Roadmap Progress & Action Button */}
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.7rem', marginBottom: '0.3rem' }}>
                  <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>
                    Build Progress: {stats.doneTasks}/{stats.totalTasks} Tasks
                  </span>
                  <span style={{ fontWeight: 800, color: tColor.text }}>
                    {stats.completionPct}%
                  </span>
                </div>

                <div style={{ width: '100%', height: '5px', background: 'var(--border-subtle)', borderRadius: '3px', overflow: 'hidden', marginBottom: '0.75rem' }}>
                  <div style={{ width: `${stats.completionPct}%`, height: '100%', background: tColor.text, transition: 'width 0.3s ease' }} />
                </div>

                <button
                  type="button"
                  style={{
                    width: '100%',
                    padding: '0.45rem 0.75rem',
                    borderRadius: '8px',
                    fontSize: '0.75rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '0.4rem',
                    background: isSelected ? tColor.bg : 'var(--bg-tertiary)',
                    color: isSelected ? tColor.text : 'var(--text-primary)',
                    border: isSelected ? `1px solid ${tColor.border}` : '1px solid var(--border-subtle)',
                    transition: 'all 0.15s ease'
                  }}
                >
                  {isSelected ? (
                    <>
                      <CheckCircle2 size={13} color={tColor.text} /> Viewing Build Roadmap
                    </>
                  ) : (
                    <>
                      View Step-by-Step Roadmap <ArrowRight size={13} />
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredProjects.length === 0 && (
        <div className="glass-card" style={{ padding: '2.5rem', textAlign: 'center' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', margin: 0 }}>
            No projects matched your filter. Try adjusting your search query or selecting "All Projects".
          </p>
        </div>
      )}

      {/* ==================================================================== */}
      {/* DETAILED STEP-BY-STEP BUILD ROADMAP FOR ACTIVE SELECTED PROJECT      */}
      {/* ==================================================================== */}
      {activeProject && (
        <div 
          id="active-project-roadmap-view" 
          style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', marginTop: '0.5rem', scrollMarginTop: '80px' }}
        >
          {/* Active Project Hero Banner */}
          <div 
            className="role-hero-banner"
            style={{
              padding: '1.5rem 1.75rem',
              borderRadius: '14px',
              background: 'var(--grad-banner)',
              border: `1.5px solid ${tierColors[activeProject.tier]?.border || 'var(--border-glass)'}`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              gap: '1.25rem'
            }}
          >
            <div style={{ maxWidth: '780px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '0.35rem' }}>
                <span className="badge" style={{
                  background: tierColors[activeProject.tier]?.bg,
                  color: tierColors[activeProject.tier]?.text,
                  border: `1px solid ${tierColors[activeProject.tier]?.border}`,
                  fontSize: '0.72rem',
                  fontWeight: 800
                }}>
                  {activeProject.tierLabel}
                </span>
                <span className="badge badge-cyan" style={{ fontSize: '0.7rem' }}>
                  <Award size={11} /> {activeProject.difficulty}
                </span>
                <span className="badge badge-emerald" style={{ fontSize: '0.7rem' }}>
                  <Zap size={11} /> ~{activeProject.totalEstimatedHours} Hours Total
                </span>
              </div>

              <h3 style={{ fontSize: '1.35rem', fontWeight: 900, color: 'var(--text-primary)', margin: '0 0 0.35rem 0' }}>
                {activeProject.title}
              </h3>

              <p style={{ fontSize: '0.84rem', color: 'var(--text-secondary)', margin: '0 0 0.65rem 0', lineHeight: 1.5 }}>
                {activeProject.description}
              </p>

              {/* Recruiter Appeal Box */}
              <div style={{
                padding: '0.65rem 0.9rem',
                borderRadius: '8px',
                background: 'rgba(56, 189, 248, 0.08)',
                border: '1px solid rgba(56, 189, 248, 0.25)',
                display: 'flex',
                alignItems: 'flex-start',
                gap: '0.5rem'
              }}>
                <Sparkles size={15} color="var(--accent-cyan)" style={{ flexShrink: 0, marginTop: '2px' }} />
                <div style={{ fontSize: '0.76rem', color: 'var(--text-primary)', lineHeight: 1.45 }}>
                  <strong style={{ color: 'var(--accent-cyan)' }}>Why Recruiters Love This:</strong> {activeProject.recruiterAppeal}
                </div>
              </div>
            </div>

            {/* Quick Action Box & Progress Widget */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', minWidth: '220px' }}>
              <div className="banner-stat-box" style={{ padding: '0.75rem 1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.25rem' }}>
                  <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase' }}>Build Progress</span>
                  <span style={{ fontSize: '1rem', fontWeight: 900, color: tierColors[activeProject.tier]?.text }}>
                    {activeProjectStats.completionPct}%
                  </span>
                </div>
                <div style={{ width: '100%', height: '6px', background: 'rgba(255,255,255,0.08)', borderRadius: '3px', overflow: 'hidden' }}>
                  <div style={{ width: `${activeProjectStats.completionPct}%`, height: '100%', background: tierColors[activeProject.tier]?.text, transition: 'width 0.3s ease' }} />
                </div>
                <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)', marginTop: '0.35rem', display: 'block' }}>
                  {activeProjectStats.doneTasks} of {activeProjectStats.totalTasks} build milestones checked
                </span>
              </div>

              <button
                type="button"
                onClick={() => handleCopyText(activeProject.resumeStarBullet, 'STAR resume bullet')}
                className="btn btn-outline-cyan btn-sm"
                style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem', fontWeight: 700, borderRadius: '8px' }}
              >
                <Copy size={13} /> Copy STAR Resume Bullet
              </button>
            </div>
          </div>



          {/* ================================================================ */}
          {/* 5-STEP ROADMAP TIMELINE TO BUILD THIS EXACT PROJECT              */}
          {/* ================================================================ */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
              <div>
                <h4 style={{ fontSize: '1.15rem', fontWeight: 900, color: 'var(--text-primary)', margin: 0, display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
                  <Terminal size={19} color="var(--accent-cyan)" />
                  Step-by-Step Technical Roadmap to Build This Project
                </h4>
                <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
                  Follow these 5 progressive engineering milestones to construct {activeProject.title} from initial architecture to live production deployment.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  const allExpanded = Object.values(expandedSteps).every(Boolean);
                  const nextState: Record<number, boolean> = {};
                  [0, 1, 2, 3, 4].forEach(idx => { nextState[idx] = !allExpanded; });
                  setExpandedSteps(nextState);
                }}
                className="btn btn-ghost btn-sm"
                style={{ fontSize: '0.72rem', color: 'var(--accent-cyan)', fontWeight: 700 }}
              >
                {Object.values(expandedSteps).every(Boolean) ? 'Collapse All Steps' : 'Expand All Steps'}
              </button>
            </div>

            {/* The 5 Phased Milestone Cards */}
            {activeProject.buildRoadmap.map((step, sIdx) => {
              const isExpanded = expandedSteps[sIdx] !== false;
              const stepColors = ['#00f2fe', '#38bdf8', '#818cf8', '#a855f7', '#10b981'];
              const color = stepColors[sIdx % stepColors.length];

              const stepCompletedTasks = step.tasks.filter(t => completedTasks[t.id]).length;
              const stepTotalTasks = step.tasks.length;
              const isStepDone = stepTotalTasks > 0 && stepCompletedTasks === stepTotalTasks;

              return (
                <div
                  key={sIdx}
                  className="sprint-milestone-card"
                  style={{
                    borderLeft: `4px solid ${color}`,
                    boxShadow: isExpanded ? `0 8px 30px rgba(0,0,0,0.15), inset 0 0 15px ${color}11` : 'var(--shadow-sm)'
                  }}
                >
                  {/* Step Header */}
                  <div
                    style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer', marginBottom: isExpanded ? '0.75rem' : 0 }}
                    onClick={() => toggleStepExpand(sIdx)}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
                      <span className="badge" style={{ background: `${color}18`, color: color, fontSize: '0.75rem', fontWeight: 800, border: `1px solid ${color}44` }}>
                        Step {step.stepNumber}: {step.phaseName}
                      </span>
                      <h4 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                        {step.title}
                      </h4>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      {isStepDone ? (
                        <span className="badge badge-emerald" style={{ fontSize: '0.72rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                          <CheckCircle2 size={13} /> Step Complete
                        </span>
                      ) : (
                        <span style={{ fontSize: '0.74rem', fontWeight: 700, color: color }}>
                          {stepCompletedTasks}/{stepTotalTasks} Tasks • ~{step.estimatedHours} hrs
                        </span>
                      )}
                      <button
                        type="button"
                        style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', display: 'flex', alignItems: 'center' }}
                      >
                        {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Step Body */}
                  {isExpanded && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem', marginTop: '0.5rem' }}>
                      {/* Step Focus & Deliverable */}
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '0.75rem' }}>
                        <div style={{ padding: '0.65rem 0.85rem', borderRadius: '8px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)' }}>
                          <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', display: 'block', marginBottom: '0.2rem' }}>
                            🎯 Engineering Focus:
                          </span>
                          <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.45 }}>
                            {step.focus}
                          </p>
                        </div>

                        <div style={{ padding: '0.65rem 0.85rem', borderRadius: '8px', background: 'rgba(16, 185, 129, 0.08)', border: '1px solid rgba(16, 185, 129, 0.25)' }}>
                          <span style={{ fontSize: '0.68rem', color: 'var(--accent-emerald)', fontWeight: 700, textTransform: 'uppercase', display: 'block', marginBottom: '0.2rem' }}>
                            📦 Concrete Milestone Deliverable:
                          </span>
                          <p style={{ fontSize: '0.78rem', color: 'var(--text-primary)', fontWeight: 600, margin: 0, lineHeight: 1.45 }}>
                            {step.deliverable}
                          </p>
                        </div>
                      </div>

                      {/* Actionable Tasks Checklist */}
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.45rem' }}>
                        <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                          Actionable Build Checklist (Click to Complete & Track Progress):
                        </span>
                        {step.tasks.map((task) => {
                          const isDone = !!completedTasks[task.id];
                          return (
                            <div
                              key={task.id}
                              onClick={() => handleToggleTask(task.id)}
                              className={`roadmap-task-item ${isDone ? 'completed' : ''}`}
                              style={{
                                cursor: 'pointer',
                                transition: 'all 0.15s ease'
                              }}
                            >
                              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.65rem' }}>
                                <div style={{ marginTop: '2px' }}>
                                  {isDone ? (
                                    <CheckCircle2 size={17} color="var(--accent-emerald)" />
                                  ) : (
                                    <Circle size={17} color="var(--text-muted)" />
                                  )}
                                </div>
                                <div>
                                  <span style={{
                                    fontSize: '0.82rem',
                                    fontWeight: 700,
                                    color: isDone ? 'var(--accent-emerald)' : 'var(--text-primary)',
                                    textDecoration: isDone ? 'line-through' : 'none'
                                  }}>
                                    {task.title}
                                  </span>
                                  <p style={{ fontSize: '0.74rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0', lineHeight: 1.4 }}>
                                    {task.description}
                                  </p>
                                </div>
                              </div>
                              <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600, flexShrink: 0 }}>
                                ~{task.estimatedHours} hrs
                              </span>
                            </div>
                          );
                        })}
                      </div>

                      {/* Pro Tips & Pitfalls */}
                      {(step.proTips?.length > 0 || step.pitfallsToAvoid?.length > 0) && (
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '0.65rem' }}>
                          {step.proTips && step.proTips.length > 0 && (
                            <div className="protip-box" style={{ margin: 0 }}>
                              <span style={{ fontSize: '0.68rem', fontWeight: 800, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: '0.3rem', marginBottom: '0.25rem' }}>
                                <Lightbulb size={12} color="var(--accent-amber)" /> {getRoleProTipLabel(activeProject?.stream || activeStream, activeProject?.coDomainName || selectedCoDomain)}:
                              </span>
                              <div style={{ fontSize: '0.76rem', color: 'inherit', lineHeight: 1.45 }}>
                                {step.proTips.map((tip, tIdx) => (
                                  <div key={tIdx} style={{ marginTop: tIdx > 0 ? '0.35rem' : 0 }}>{tip}</div>
                                ))}
                              </div>
                            </div>
                          )}

                          {step.pitfallsToAvoid && step.pitfallsToAvoid.length > 0 && (
                            <div style={{
                              padding: '0.65rem 0.85rem',
                              borderRadius: '8px',
                              background: 'rgba(244, 63, 94, 0.06)',
                              border: '1px solid rgba(244, 63, 94, 0.25)',
                              color: '#fb7185'
                            }}>
                              <span style={{ fontSize: '0.68rem', fontWeight: 800, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: '0.3rem', marginBottom: '0.25rem' }}>
                                <Shield size={12} color="#fb7185" /> Critical Pitfall to Avoid:
                              </span>
                              <div style={{ fontSize: '0.76rem', color: 'inherit', lineHeight: 1.45 }}>
                                {step.pitfallsToAvoid.map((pitfall, pIdx) => (
                                  <div key={pIdx} style={{ marginTop: pIdx > 0 ? '0.35rem' : 0 }}>{pitfall}</div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* ================================================================ */}
          {/* RESUME STAR BULLET POINT & RECRUITER PACK                        */}
          {/* ================================================================ */}
          <div className="glass-card" style={{ padding: '1.5rem', border: '1.5px solid rgba(168, 85, 247, 0.35)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem', flexWrap: 'wrap', gap: '0.5rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Award size={19} color="var(--accent-purple)" />
                <h4 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  Resume Ready STAR Bullet Formula
                </h4>
              </div>
              <button
                type="button"
                onClick={() => handleCopyText(activeProject.resumeStarBullet, 'STAR resume bullet')}
                className="btn btn-primary btn-sm"
                style={{ fontSize: '0.72rem', display: 'inline-flex', alignItems: 'center', gap: '0.35rem', fontWeight: 700 }}
              >
                <Copy size={13} /> Copy Formatted Bullet
              </button>
            </div>

            <div style={{ padding: '1rem 1.15rem', background: 'rgba(255, 255, 255, 0.02)', borderRadius: '10px', border: '1px solid var(--border-subtle)', marginBottom: '1.25rem' }}>
              <span style={{ fontSize: '0.7rem', color: 'var(--accent-purple)', fontWeight: 800, textTransform: 'uppercase', display: 'block', marginBottom: '0.35rem' }}>
                Situation • Task • Action • Result (STAR):
              </span>
              <p style={{ fontSize: '0.86rem', color: 'var(--text-primary)', margin: 0, lineHeight: 1.55, fontWeight: 500 }}>
                "{activeProject.resumeStarBullet}"
              </p>
            </div>

            {/* Technical Interview Questions & Answers asked for this Project */}
            {activeProject.interviewQuestions && activeProject.interviewQuestions.length > 0 && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                <span style={{ fontSize: '0.72rem', fontWeight: 800, color: 'var(--accent-cyan)', textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                  <HelpCircle size={14} color="var(--accent-cyan)" /> Technical Interview Questions Asked on This Project:
                </span>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '0.75rem' }}>
                  {activeProject.interviewQuestions.map((qa, qIdx) => (
                    <div 
                      key={qIdx}
                      style={{
                        padding: '0.85rem 1rem',
                        borderRadius: '10px',
                        background: 'var(--bg-tertiary)',
                        border: '1px solid var(--border-subtle)',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '0.45rem'
                      }}
                    >
                      <div style={{ fontSize: '0.82rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                        Q{qIdx + 1}: {qa.question}
                      </div>
                      <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                        <strong style={{ color: 'var(--accent-amber)' }}>Interviewer Intent:</strong> {qa.recruiterIntent}
                      </div>
                      <div style={{ fontSize: '0.76rem', color: 'var(--text-secondary)', lineHeight: 1.45, borderTop: '1px solid var(--border-subtle)', paddingTop: '0.4rem' }}>
                        <strong style={{ color: 'var(--accent-emerald)' }}>Winning Answer Strategy:</strong> {qa.answerStrategy}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
