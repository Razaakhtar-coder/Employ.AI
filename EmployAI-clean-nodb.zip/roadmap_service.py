from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.models.matching import Role, SkillGap, LearningRoadmap
from app.models.profile import StudentProfile
from app.schemas.roadmap import LearningRoadmapResponse, RoadmapMilestone, RoadmapTask
from app.services.matching_service import MatchingService


class RoadmapService:
    @staticmethod
    def _build_domain_milestones(role: Role, missing_skill_names: List[str]) -> List[RoadmapMilestone]:
        """Construct a structured, beginner-to-advanced 6-week curriculum tailored to the specific role and field."""
        domain_lower = (role.domain or "").lower()
        title_lower = (role.title or "").lower()

        # 1. Aviation & Commercial Pilot
        if "pilot" in title_lower or "aviation" in domain_lower:
            return [
                RoadmapMilestone(
                    week_range="Week 1",
                    week_number=1,
                    focus_skill="Aviation Ground School: Air Regulations & Air Law",
                    goal="Master civil aviation rules of the air, airspace classifications, and DGCA/FAA legal compliance.",
                    how_to_achieve="Step 1: Study DGCA CAR Section 7 & ICAO Annex 2 rules of the air.\nStep 2: Understand ATS airspace classifications, minimum safe altitudes, and VFR/IFR cruising levels.\nStep 3: Learn standard aeronautical radio communication phraseology and transponder squawk codes.\nStep 4: Complete foundational Air Law chapter quizzes with 90%+ pass rate.",
                    recommended_tools=["ICAO Annex 2/11 Documentation", "DGCA CAR Portal", "Aviation Radio Phraseology Simulator"],
                    pro_tips=["Always memorize emergency squawk codes (7500, 7600, 7700) as second nature.", "Understand Pilot-in-Command (PIC) legal authority vs ATC instructions."],
                    checkpoint_criteria=["Can you explain right-of-way rules for converging and overtaking aircraft?", "Do you know the entry requirements for controlled Class C and D airspaces?"],
                    topics=[
                        "DGCA / FAA Air Regulations and Air Traffic Service (ATS) airspace classifications",
                        "Altimetry, International Standard Atmosphere (ISA) & Q-codes (QNH, QFE, QNE)",
                        "Air traffic communication phraseology and standard readback procedures",
                        "Aircraft documents and airworthiness certificate verification"
                    ],
                    practical_project="Airspace & Air Law Compliance Brief: Draft a complete airspace transit plan across Class C, D, and G airspaces.",
                    deliverable="Air Law Navigation Briefing Document with verified squawk and frequency assignments.",
                    tasks=[
                        RoadmapTask(id="task-p1-1", title="Study DGCA CAR Section 7 & ICAO Annex 2", description="Complete foundational Air Law modules and quiz.", resource_type="documentation", estimated_hours=8, is_completed=True),
                        RoadmapTask(id="task-p1-2", title="Master altimeter pressure settings & Q-codes", description="Calculate true altitude, pressure altitude, and density altitude.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 2",
                    week_number=2,
                    focus_skill="Aviation Meteorology & Weather Hazard Analysis",
                    goal="Decode live meteorological reports (METAR/TAF), recognize atmospheric hazards, and perform crosswind runway calculations.",
                    how_to_achieve="Step 1: Master the anatomy of METAR and TAF reports including wind shear and trend indicators.\nStep 2: Study frontal systems, jet streams, icing conditions, and convective thunderstorms.\nStep 3: Use trigonometry and wind component tables to compute crosswind and headwind vectors.\nStep 4: Formulate GO/NO-GO weather decisions based on meteorological minima.",
                    recommended_tools=["NOAA Aviation Weather Center", "Live METAR/TAF Airport Decoders", "Wind Vector Resolvers"],
                    pro_tips=["Never penetrate a thunderstorm cell within 20 nautical miles due to severe turbulence.", "Density altitude directly degrades takeoff roll and climb gradient."],
                    checkpoint_criteria=["Can you decode a complex SPECI METAR report with RVR in under 30 seconds?", "How do you identify structural icing risks?"],
                    topics=[
                        "METAR, SPECI, TAF, SIGMET, and AIRMET report decoding and interpretation",
                        "Atmospheric pressure systems: Cyclones, anticyclones, cold/warm fronts, and inversions",
                        "Aviation weather hazards: Microbursts, wind shear, CAT, and structural icing",
                        "Runway crosswind limit calculations and density altitude engine performance penalties"
                    ],
                    practical_project="Live Cross-Country Weather Decision Matrix: Analyze 10 airport weather reports and compile an operational briefing.",
                    deliverable="Weather Briefing Log with Go/No-Go Decision Matrix and Diversion Runway Calculations.",
                    tasks=[
                        RoadmapTask(id="task-p2-1", title="Decode 10 live international airport METAR & TAF reports", description="Annotate cloud base, visibility, dew point, and wind components.", resource_type="practice_project", estimated_hours=8, is_completed=False),
                        RoadmapTask(id="task-p2-2", title="Run crosswind runway component computations", description="Determine maximum crosswind adherence for cross-runway landings.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 3",
                    week_number=3,
                    focus_skill="Instrument Flight Rules (IFR) & Radio Navigation (VOR/ILS/GNSS)",
                    goal="Navigate aircraft precisely without visual ground references using VOR radials, ILS localizer/glide slopes, and GPS RNAV.",
                    how_to_achieve="Step 1: Understand VHF Omnidirectional Range (VOR) radial interception and DME distance tracking.\nStep 2: Master Instrument Landing System (ILS) Category I/II approach mechanics.\nStep 3: Study RNAV (GNSS) approach waypoints (IAF, IF, FAF, MAPt) and Decision Altitudes.\nStep 4: Practice instrument scan techniques on flight simulator.",
                    recommended_tools=["X-Plane 12 / Microsoft Flight Simulator", "Jeppesen Navigation Charts", "VOR Interception Simulators"],
                    pro_tips=["In ILS approaches, make small corrections (1-2 degrees heading, 100 fpm pitch).", "Always verify Morse code audio ident for ground beacons."],
                    checkpoint_criteria=["Can you execute a direct, parallel, or teardrop holding pattern entry correctly?", "What is the difference between Decision Altitude (DA) and Minimum Descent Altitude (MDA)?"],
                    topics=[
                        "VOR radial interception, tracking, and cone of confusion handling",
                        "Instrument Landing System (ILS): Localizer VHF and Glide Path UHF frequencies",
                        "RNAV (GNSS) approach design, RNP performance standards, and LNAV/VNAV minima",
                        "Standard Instrument Departures (SID) and Standard Terminal Arrival Routes (STAR) chart navigation"
                    ],
                    practical_project="IFR Flight Route Simulation: Plan and fly a multi-leg IFR route connecting two major international hubs.",
                    deliverable="Complete IFR NavLog with Fuel Burn Reserves, Minimum Enroute Altitudes, and Jeppesen Plates.",
                    tasks=[
                        RoadmapTask(id="task-p3-1", title="Execute VOR radial intercept & holding pattern entry", description="Practice holding patterns (Direct, Teardrop, Parallel) in simulator.", resource_type="practice_project", estimated_hours=10, is_completed=False),
                        RoadmapTask(id="task-p3-2", title="Annotate Jeppesen SID/STAR approach plates", description="Mark transition altitudes, speed restrictions, and missed approach procedures.", resource_type="documentation", estimated_hours=6, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 4",
                    week_number=4,
                    focus_skill="Flight Management Systems (FMS), Weight & Balance and Jet Aerodynamics",
                    goal="Program the FMS computer, calculate aircraft center of gravity (CG), and manage multi-engine jet aerodynamic limits.",
                    how_to_achieve="Step 1: Learn FMS MCDU initialization (POS INIT, FLIGHT PLAN, PERF INIT) and route waypoint entry.\nStep 2: Calculate aircraft Zero Fuel Weight (ZFW), Takeoff Weight (TOW), and verify CG limits.\nStep 3: Study high-altitude jet aerodynamics: Mach number, Critical Mach, and shock wave stall.\nStep 4: Compute takeoff V-speeds (V1 Decision Speed, VR Rotate Speed, V2 Safety Speed).",
                    recommended_tools=["A320/B737 MCDU Web Simulator", "Weight & Balance Loadsheet Calculators", "Performance Speed Tables"],
                    pro_tips=["Never rotate the aircraft prior to VR to prevent tail strike or stall.", "An aft CG improves fuel efficiency but decreases longitudinal static stability."],
                    checkpoint_criteria=["What is the consequence of exceeding Maximum Takeoff Weight during climb gradient requirements?", "How does high temperature affect V1 decision speed?"],
                    topics=[
                        "FMS MCDU programming, flight plan route loading, and lateral/vertical navigation",
                        "Aircraft Weight & Balance: Index, CG percentage MAC, structural and performance limits",
                        "Transonic aerodynamics: Mach tuck, transonic shock stall, and buffet boundary limits",
                        "Takeoff performance calculations: TORA, TODA, ASDA, and climb gradients"
                    ],
                    practical_project="Commercial Jet Loadsheet & Performance Calculation: Produce a certified weight & balance manifest for 180 passengers.",
                    deliverable="Complete Load & Trim Sheet with Verified Center of Gravity Trim Settings and V-Speeds.",
                    tasks=[
                        RoadmapTask(id="task-p4-1", title="Program complete FMS route on MCDU simulator", description="Configure SID, airways, STAR, cost index, and step climbs.", resource_type="practice_project", estimated_hours=8, is_completed=False),
                        RoadmapTask(id="task-p4-2", title="Compute balanced field takeoff performance", description="Calculate V1, VR, V2, and stopway margins for wet and dry runways.", resource_type="practice_project", estimated_hours=8, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 5",
                    week_number=5,
                    focus_skill="Multi-Crew Cooperation (MCC) & Emergency Procedures",
                    goal="Develop airline-level Crew Resource Management (CRM), emergency checklist discipline, and abnormal situation handling.",
                    how_to_achieve="Step 1: Understand Pilot Flying (PF) vs. Pilot Monitoring (PM) communication protocols and sterile cockpit rules.\nStep 2: Practice standard callouts and Quick Reference Handbook (QRH) non-normal checklists.\nStep 3: Execute emergency descent, engine fire, and single-engine divert procedures in simulator.\nStep 4: Master Threat and Error Management (TEM) framework.",
                    recommended_tools=["Quick Reference Handbook (QRH)", "MCC Checklist Flow Simulators", "Emergency Descent Scenarios"],
                    pro_tips=["Aviate, Navigate, Communicate—always fly the airplane first.", "Use the DODAR framework during in-flight decision-making."],
                    checkpoint_criteria=["How do you manage an engine failure occurring at V1 vs. after V1?", "What are the immediate memory items for rapid cabin depressurization?"],
                    topics=[
                        "Crew Resource Management (CRM): Leadership, situational awareness, and assertive communication",
                        "Threat & Error Management (TEM): Latent threats, active errors, and undesired aircraft states",
                        "Emergency response: Engine failure on takeoff, engine fire, emergency descent, and go-around",
                        "Standard Operating Procedures (SOP): Cross-cockpit verification and checklist execution"
                    ],
                    practical_project="Comprehensive MCC Flight Scenario: Execute an emergency descent and single-engine divert procedure in simulator.",
                    deliverable="Recorded Simulator Flight Video & Emergency Checklist Execution Debrief.",
                    tasks=[
                        RoadmapTask(id="task-p5-1", title="Execute abnormal emergency response procedures", description="Practice engine failure after V1 decision speed and go-around protocols.", resource_type="practice_project", estimated_hours=10, is_completed=False),
                        RoadmapTask(id="task-p5-2", title="Demonstrate CRM communication & standard callouts", description="Record standard SOP callout flow from startup to cruise.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 6",
                    week_number=6,
                    focus_skill="Airline Assessment Preparation & Technical Pilot Interview",
                    goal="Prepare for airline cadet / first officer technical screenings, COMPASS aptitude tests, and simulator assessments.",
                    how_to_achieve="Step 1: Practice 200+ technical aviation screening questions covering aerodynamics, meteorology, and air law.\nStep 2: Train psychomotor coordination and spatial orientation for COMPASS/PILAPT tests.\nStep 3: Structure your aviation logbook and CV emphasizing simulator hours and clean checkrides.\nStep 4: Complete mock airline panel interviews focusing on safety culture.",
                    recommended_tools=["Airline Technical Exam Question Banks", "COMPASS Test Prep Tools", "Employ.AI Aviation Profile"],
                    pro_tips=["When asked situational questions in airline interviews, always anchor answers in SOP and safety.", "Keep your pilot logbook spotless with certified endorsements."],
                    checkpoint_criteria=["Can you score 90%+ on comprehensive airline technical screening mock tests?", "Is your Employ.AI pilot profile verified with all ratings?"],
                    topics=[
                        "Airline technical question bank: Aerodynamics, jet performance, systems, and DGCA CPL exams",
                        "Psychomotor & spatial awareness assessment preparation",
                        "Employ.AI Pilot Profile Hardening: Logbook verification and aviation CV structuring",
                        "Airline HR & Captain panel interview preparation: Safety mindset and situational questions"
                    ],
                    practical_project="Airline Cadet Interview Simulation: Complete a 50-question airline technical screening assessment.",
                    deliverable="Verified Employ.AI Aviation Profile & Published Flight Portfolio.",
                    tasks=[
                        RoadmapTask(id="task-p6-1", title="Complete airline technical mock evaluation", description="Score 85%+ on technical aeronautical knowledge assessment.", resource_type="practice_project", estimated_hours=8, is_completed=False),
                        RoadmapTask(id="task-p6-2", title="Sync verified logbook to Employ.AI profile", description="Link simulator recordings and certifications for recruiter visibility.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                )
            ]

        # 2. Computer Science & Software Engineering
        if "computer science" in domain_lower or "software" in title_lower or "fullstack" in title_lower or "backend" in title_lower or "developer" in title_lower:
            return [
                RoadmapMilestone(
                    week_range="Week 1",
                    week_number=1,
                    focus_skill="Core Algorithms, Data Structures & TypeScript/Python Fundamentals",
                    goal="Build robust algorithmic foundations, clean object-oriented architecture, and asynchronous programming habits.",
                    how_to_achieve="Step 1: Study time & space complexity analysis (Big-O) for array, hash table, and tree operations.\nStep 2: Implement core data structures (Hash Map, LRU Cache, BST) with zero external dependencies.\nStep 3: Configure strict TypeScript compiler options and write clean Python type hints.\nStep 4: Set up professional Git conventions (Conventional Commits, feature branch PR workflows).",
                    recommended_tools=["VS Code", "Node.js 20+ & TypeScript 5+", "Python 3.12 & pytest", "Git & GitHub CLI"],
                    pro_tips=["Always verify edge cases in algorithms: empty arrays, single elements, and circular references.", "Write unit tests before writing complex business logic."],
                    checkpoint_criteria=["Can you explain Big-O notation with concrete code examples?", "Can you build an in-memory LRU Cache with O(1) operations?"],
                    topics=[
                        "Time & Space Complexity analysis (Big-O notation) and memory management",
                        "Data Structures: Hash tables, binary search trees, heaps, graphs, and dynamic arrays",
                        "Modern Python 3.12 (Type hints, generators, asyncio) & TypeScript 5+ strict type systems",
                        "Git workflows: Branching strategies, interactive rebase, and code review etiquette"
                    ],
                    practical_project="High-Performance In-Memory Cache: Implement LRU cache with TTL and inverted index in TypeScript/Python.",
                    deliverable="Production-tested GitHub repository with 95%+ unit test coverage using pytest / vitest.",
                    tasks=[
                        RoadmapTask(id="task-cs1-1", title="Implement core data structures with zero external dependencies", description="Build LRU Cache, Binary Search Tree, and Graph BFS/DFS.", resource_type="practice_project", estimated_hours=10, is_completed=True),
                        RoadmapTask(id="task-cs1-2", title="Configure strict TypeScript development toolchain", description="Set up ESLint, Prettier, strict tsconfig, and automated pre-commit git hooks.", resource_type="documentation", estimated_hours=6, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 2",
                    week_number=2,
                    focus_skill="Relational Database Modeling & Asynchronous Backend REST APIs",
                    goal="Design normalized PostgreSQL schemas, optimize indexes, and build high-throughput asynchronous REST APIs in FastAPI / Express.",
                    how_to_achieve="Step 1: Design 3NF normalized relational database schemas with primary keys and foreign keys.\nStep 2: Build RESTful API endpoints using FastAPI with Pydantic validation models.\nStep 3: Implement JWT authentication, bcrypt password hashing, and RBAC permissions.\nStep 4: Profile SQL execution plans with EXPLAIN ANALYZE and implement B-tree composite indexes.",
                    recommended_tools=["PostgreSQL 16", "FastAPI & SQLAlchemy", "pgAdmin / DBeaver", "Postman / Bruno"],
                    pro_tips=["Never store plain-text passwords; always use bcrypt with high salt rounds.", "Avoid the N+1 query problem by utilizing eager loading in ORMs."],
                    checkpoint_criteria=["Can you explain ACID transactions under high concurrency?", "How do you secure API endpoints against SQL injection and CSRF?"],
                    topics=[
                        "Relational database architecture: 3NF normalization, foreign key cascades, and ACID transactions",
                        "FastAPI asynchronous async/await pipelines, dependency injection, and Pydantic validation",
                        "Authentication & Security: JWT tokens, refresh token rotation, bcrypt hashing, and CORS policies",
                        "Query performance tuning: EXPLAIN ANALYZE, B-tree indexes, connection pooling, and migrations"
                    ],
                    practical_project="Authenticated Multi-Tenant REST API: Build a secure RESTful service with role-based permissions and PostgreSQL.",
                    deliverable="Working Backend API with Automated Migrations, Swagger OpenAPI Docs, and Integration Tests.",
                    tasks=[
                        RoadmapTask(id="task-cs2-1", title="Build and secure FastAPI REST API", description="Implement JWT login, signup, user roles, and database CRUD operations.", resource_type="practice_project", estimated_hours=12, is_completed=False),
                        RoadmapTask(id="task-cs2-2", title="Write automated API endpoint integration test suite", description="Validate authorization headers, schema validation errors, and DB rollbacks.", resource_type="practice_project", estimated_hours=8, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 3",
                    week_number=3,
                    focus_skill="Modern Frontend Architecture: React, State Management & Design Systems",
                    goal="Architect responsive, accessible, and high-performance user interfaces in React 19 / Vite using modern design systems.",
                    how_to_achieve="Step 1: Master React 19 component lifecycle, custom hooks, and memoization.\nStep 2: Implement scalable global state management (Context API / Zustand) with type safety.\nStep 3: Build a custom responsive design system with CSS tokens, dark mode, and glassmorphism.\nStep 4: Optimize client performance (code splitting, lazy loading, and virtualized lists).",
                    recommended_tools=["React 19 & Vite", "Zustand / TanStack Query", "Lucide Icons", "Chrome DevTools Lighthouse"],
                    pro_tips=["Avoid unnecessary re-renders by colocating state close to where it is consumed.", "Always test your UI on mobile breakpoints (375px)."],
                    checkpoint_criteria=["How does React reconcile virtual DOM differences?", "Can you implement optimistic UI updates for instant feedback?"],
                    topics=[
                        "React component architecture, custom hooks design, and immutable state updates",
                        "Global state management with Zustand and server-state caching with TanStack Query",
                        "Modern CSS architecture: Design tokens, CSS variables, glassmorphism, and animations",
                        "Frontend performance: Core Web Vitals, code splitting, memoization, and bundle size reduction"
                    ],
                    practical_project="Dynamic Analytics Dashboard: Build an interactive frontend with live data filtering, charts, and dark mode.",
                    deliverable="Responsive React Application with Smooth 60fps Micro-Animations and 95+ Lighthouse Score.",
                    tasks=[
                        RoadmapTask(id="task-cs3-1", title="Develop responsive dashboard with reusable UI components", description="Create accessible buttons, cards, modals, and data tables.", resource_type="practice_project", estimated_hours=12, is_completed=False),
                        RoadmapTask(id="task-cs3-2", title="Implement custom state hooks and API client layer", description="Connect frontend seamlessly to backend API with error boundary handling.", resource_type="practice_project", estimated_hours=8, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 4",
                    week_number=4,
                    focus_skill="Containerization, Redis Caching & Cloud Infrastructure (Docker & AWS)",
                    goal="Containerize fullstack applications with multi-stage Dockerfiles, integrate Redis caching, and set up cloud CI/CD.",
                    how_to_achieve="Step 1: Write optimized multi-stage Dockerfiles for frontend and backend to minimize image size.\nStep 2: Configure docker-compose.yml orchestrating Frontend, Backend, PostgreSQL, and Redis.\nStep 3: Integrate Redis for high-speed session caching, rate limiting, and job queuing.\nStep 4: Set up GitHub Actions CI/CD workflows for automated testing and deployment.",
                    recommended_tools=["Docker & Docker Compose", "Redis 7", "GitHub Actions", "AWS EC2 / Render / Vercel"],
                    pro_tips=["Use alpine or distroless base images to minimize Docker image vulnerabilities.", "Always set a Time-To-Live (TTL) on Redis cache keys to prevent memory leaks."],
                    checkpoint_criteria=["What is the benefit of multi-stage Docker builds?", "How do you prevent cache stampede in distributed systems?"],
                    topics=[
                        "Docker containerization: Layers, caching, non-root user security, and multi-stage builds",
                        "Docker Compose multi-container orchestration and environment variable secret injection",
                        "Redis caching patterns: Cache-Aside, Write-Through, and rate limiting algorithms",
                        "GitHub Actions automated CI/CD pipeline automation with artifact caching"
                    ],
                    practical_project="Containerized Microservices Cluster: Build a multi-container fullstack app with Redis cache and CI pipeline.",
                    deliverable="Production Docker Compose Setup with Automated GitHub Actions CI Testing Matrix.",
                    tasks=[
                        RoadmapTask(id="task-cs4-1", title="Author multi-stage Dockerfiles & docker-compose.yml", description="Build and verify local multi-container stack running on isolated networks.", resource_type="practice_project", estimated_hours=10, is_completed=False),
                        RoadmapTask(id="task-cs4-2", title="Integrate Redis caching and rate limiting middleware", description="Demonstrate 10x API latency speedup on cached endpoints.", resource_type="practice_project", estimated_hours=8, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 5",
                    week_number=5,
                    focus_skill="Scalable Fullstack SaaS Capstone Project",
                    goal="Synthesize algorithms, backend APIs, modern UI, and cloud containers into a flagship fullstack portfolio capstone project.",
                    how_to_achieve="Step 1: Plan architecture, data models, and feature PRD for an innovative fullstack product.\nStep 2: Implement full end-to-end features with authentication, database CRUD, real-time updates, and responsive UI.\nStep 3: Deploy the live web application to public cloud with SSL/HTTPS certificates.\nStep 4: Write professional GitHub documentation with architecture diagrams and setup instructions.",
                    recommended_tools=["Full Modern Stack (React + FastAPI + Postgres + Redis)", "Cloud Hosting (AWS/Render/Vercel)", "Mermaid Diagrams"],
                    pro_tips=["A deployed live URL with test credentials gets 5x more recruiter interest than a dead repo.", "Include an architecture diagram and quantified performance metrics."],
                    checkpoint_criteria=["Is your capstone project live and accessible on a public HTTPS URL?", "Does the repository have clean commit history, README, and unit tests?"],
                    topics=[
                        "Full-lifecycle software engineering: Conception, architecture, development, testing, and deployment",
                        "High-availability cloud deployment with automated zero-downtime rolling updates",
                        "Comprehensive technical authoring: README, Swagger API specs, and architecture flowcharts",
                        "Quantifying project metrics: Latency reduction, throughput, user capacity, and test coverage"
                    ],
                    practical_project="Flagship Fullstack SaaS Application: Deploy an enterprise-ready application live on cloud infrastructure.",
                    deliverable="Live HTTPS Deployed URL + Public GitHub Repository with Comprehensive Architecture Readme.",
                    tasks=[
                        RoadmapTask(id="task-cs5-1", title="Build and deploy flagship fullstack capstone application", description="Deploy live application with custom domain and database backup automation.", resource_type="practice_project", estimated_hours=14, is_completed=False),
                        RoadmapTask(id="task-cs5-2", title="Record a 90-second technical walkthrough video", description="Explain architectural decisions, trade-offs, and showcase key features.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 6",
                    week_number=6,
                    focus_skill="System Design Interview Mastery & Employ.AI Placement Readiness",
                    goal="Master scalable system design interview questions, align your resume with ATS keywords, and secure software engineering offers.",
                    how_to_achieve="Step 1: Practice high-level distributed system design (Designing URL Shortener, Twitter Feed, or Ride Sharing).\nStep 2: Master system design fundamentals: load balancers, database sharding, CAP theorem, and CDN caching.\nStep 3: Align your resume on Employ.AI ATS Scanner, formulating STAR impact bullets.\nStep 4: Apply to top matched software engineering openings on the Employ.AI Opportunities Portal.",
                    recommended_tools=["Employ.AI Resume ATS Optimizer", "Excalidraw System Design Tool", "LeetCode / HackerRank", "Employ.AI Opportunities Portal"],
                    pro_tips=["In system design interviews, always clarify requirements and scale (QPS, storage) before designing.", "Use STAR bullet format on your resume with quantified metrics."],
                    checkpoint_criteria=["Can you design a distributed cache system handling 100,000 requests/sec with fault tolerance?", "Is your Employ.AI profile at 90%+ ATS match score?"],
                    topics=[
                        "System design fundamentals: Load balancing, consistent hashing, database replication, and sharding",
                        "CAP Theorem trade-offs, eventual consistency, message queues (Kafka/RabbitMQ), and microservices",
                        "Employ.AI Profile Hardening: Synchronizing verified project commits and ATS resume optimization",
                        "Technical behavioral interview mastery, salary negotiation strategies, and offer evaluation"
                    ],
                    practical_project="System Architecture Whitepaper & Placement Campaign: Author a distributed system RFC and apply to 10 matched roles.",
                    deliverable="Verified Employ.AI Software Engineer Profile with 95%+ Match Score and Active Applications.",
                    tasks=[
                        RoadmapTask(id="task-cs6-1", title="Complete comprehensive system design mock interview", description="Design a distributed notifications service with rate limiting and retry queues.", resource_type="practice_project", estimated_hours=8, is_completed=False),
                        RoadmapTask(id="task-cs6-2", title="Tailor and sync resume ATS score to 90%+", description="Incorporate verified project metrics and submit applications via portal.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                )
            ]

        # 3. Clinical Medicine & MBBS
        if "mbbs" in domain_lower or "medicine" in domain_lower or "clinical" in title_lower or "medical" in title_lower:
            return [
                RoadmapMilestone(
                    week_range="Week 1",
                    week_number=1,
                    focus_skill="Clinical History Taking & Systemic Physical Examination",
                    goal="Master systematic patient communication, differential diagnoses, and diagnostic triage.",
                    how_to_achieve="Step 1: Follow standard OSCE checklists for cardiovascular, respiratory, and abdominal examination.\nStep 2: Take structured patient histories identifying primary chief complaints and red flags.\nStep 3: Formulate initial differential diagnoses based on clinical signs.\nStep 4: Practice clinical case presentations.",
                    recommended_tools=["Osmosis Medical Library", "Geeky Medics OSCE Guides", "Diagnostic Examination Checklists"],
                    pro_tips=["Never rush the patient history—over 80% of diagnoses are established during history taking.", "Always adhere to patient confidentiality and informed consent."],
                    checkpoint_criteria=["Can you perform a complete cranial nerve examination within 8 minutes?", "Can you identify acute peritoneal irritation signs?"],
                    topics=[
                        "Systemic physical examination: Cardiovascular, respiratory, abdominal, and neurological systems",
                        "Patient history taking, symptom chronologies, and emergency red-flag identification",
                        "Differential diagnosis generation and evidence-based probability ranking",
                        "Informed consent protocols and medical communication ethics"
                    ],
                    practical_project="Comprehensive Clinical Case Workup: Author a 10-patient structured differential diagnosis logbook.",
                    deliverable="Verified Clinical Bedside Portfolio with Documented Differential Diagnoses.",
                    tasks=[
                        RoadmapTask(id="task-med1-1", title="Complete systemic examination OSCE checklists", description="Practice physical examination flows on cardiovascular and respiratory systems.", resource_type="practice_project", estimated_hours=10, is_completed=True),
                        RoadmapTask(id="task-med1-2", title="Master patient history taking protocols", description="Document 5 structured clinical histories with differential diagnoses.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 2",
                    week_number=2,
                    focus_skill="Radiology & Laboratory Diagnostic Interpretation",
                    goal="Accurately interpret Chest X-Rays, Non-Contrast CT Scans, 12-Lead ECGs, and arterial blood gases (ABG).",
                    how_to_achieve="Step 1: Master the ABCDE systematic approach for reading Chest X-Rays.\nStep 2: Interpret 12-lead ECGs for ST-elevation myocardial infarctions (STEMI) and arrhythmias.\nStep 3: Analyze CBC, metabolic panels, and ABG acidosis/alkalosis compensation.\nStep 4: Correlate imaging findings with patient clinical presentations.",
                    recommended_tools=["Radiopaedia Case Library", "Medscape Clinical Reference", "ECG Waveform Interpreters"],
                    pro_tips=["Always check patient identity, date, and technical adequacy before reading any radiograph.", "Systematically calculate the electrical axis and QTc on ECGs."],
                    checkpoint_criteria=["Can you identify tension pneumothorax or acute intracranial hemorrhage on CT scans?", "Can you diagnose metabolic acidosis with high anion gap?"],
                    topics=[
                        "Systematic Chest X-Ray interpretation: Pneumothorax, consolidations, and pleural effusions",
                        "12-Lead ECG interpretation: Axis deviation, bundle branch blocks, ischemia, and STEMI",
                        "Arterial Blood Gas (ABG) analysis: Respiratory vs metabolic acidosis/alkalosis compensation",
                        "Biomarkers & Lab Panels: Troponin, D-Dimer, CRP, renal panels, and liver function diagnostics"
                    ],
                    practical_project="Radiographic & Diagnostic Dossier: Interpret 25 verified clinical radiology and ECG cases.",
                    deliverable="Annotated Diagnostic Interpretation Logbook with Clinical Correlations.",
                    tasks=[
                        RoadmapTask(id="task-med2-1", title="Interpret 20 verified Chest X-Rays & CT scans", description="Annotate pathologies adhering to standardized ABCDE reporting guidelines.", resource_type="practice_project", estimated_hours=10, is_completed=False),
                        RoadmapTask(id="task-med2-2", title="Analyze 15 abnormal 12-lead ECG strips", description="Identify arrhythmias, axis deviations, and acute coronary syndromes.", resource_type="practice_project", estimated_hours=8, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 3",
                    week_number=3,
                    focus_skill="Evidence-Based Therapeutics & Pharmacology",
                    goal="Formulate rational drug prescriptions, manage antibiotic stewardship, and calculate critical dosing regimens.",
                    how_to_achieve="Step 1: Learn first-line therapeutic guidelines for hypertension, diabetes, sepsis, and heart failure.\nStep 2: Calculate emergency drug dosages (epinephrine, adenosine, dopamine infusions).\nStep 3: Verify drug-drug interactions and contraindications using Medscape/UpToDate.\nStep 4: Practice rational prescription writing avoiding polypharmacy.",
                    recommended_tools=["UpToDate Clinical Decision Portal", "Medscape Drug Interaction Checker", "Rational Prescription Guidelines"],
                    pro_tips=["Always adjust antibiotic dosages for patients with impaired creatinine clearance (eGFR).", "Double check pediatric and emergency resuscitation drug calculations."],
                    checkpoint_criteria=["Can you calculate a weight-based pediatric antibiotic dose accurately?", "What are the contraindications for beta-blockers in acute decompensated heart failure?"],
                    topics=[
                        "Pharmacokinetics, pharmacodynamics, and therapeutic drug monitoring (TDM)",
                        "Antibiotic stewardship: Empiric therapy vs culture-directed sensitivities",
                        "Cardiovascular & endocrine therapeutics: Statins, ACEi/ARBs, SGLT2i, and insulin titration",
                        "Adverse drug reactions (ADR) reporting and drug-drug interaction prevention"
                    ],
                    practical_project="Therapeutic Regimen Audit: Draft evidence-based treatment plans for 5 complex multi-morbidity cases.",
                    deliverable="Comprehensive Pharmacotherapy Brief with Documented Renal/Hepatic Dosing Adjustments.",
                    tasks=[
                        RoadmapTask(id="task-med3-1", title="Audit 10 complex multi-morbidity drug charts", description="Check for polypharmacy, adverse interactions, and dose calibrations.", resource_type="practice_project", estimated_hours=10, is_completed=False),
                        RoadmapTask(id="task-med3-2", title="Formulate empiric antibiotic protocols", description="Align regimens with hospital antimicrobial stewardship guidelines.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 4",
                    week_number=4,
                    focus_skill="Emergency Resuscitation & Acute Trauma Protocols (BLS/ACLS/ATLS)",
                    goal="Execute rapid patient triage, lead cardiac arrest resuscitation algorithms, and manage acute hypovolemic shock.",
                    how_to_achieve="Step 1: Master AHA BLS & ACLS algorithms for shockable (VF/pVT) and non-shockable (PEA/Asystole) rhythms.\nStep 2: Follow ATLS primary and secondary survey protocols for polytrauma victims.\nStep 3: Practice airway management, needle thoracostomy, and central vascular access in simulation.\nStep 4: Master post-resuscitation targeted temperature management and vasopressor titration.",
                    recommended_tools=["AHA ACLS Algorithms", "ATLS Trauma Protocols", "Clinical Simulation Mannequins"],
                    pro_tips=["High-quality chest compressions with minimal interruptions are the single most effective CPR intervention.", "Treat reversible causes (5 Hs and 5 Ts) during cardiac arrest."],
                    checkpoint_criteria=["Can you lead a simulated ACLS Megacode cardiac arrest scenario seamlessly?", "What is the initial fluid resuscitation protocol for hemorrhagic shock?"],
                    topics=[
                        "Advanced Cardiovascular Life Support (ACLS): Shockable vs non-shockable cardiac arrest protocols",
                        "Advanced Trauma Life Support (ATLS): Primary survey (ABCDE), FAST ultrasound, and hemorrhage control",
                        "Acute emergency management: Anaphylaxis, hypertensive crisis, acute pulmonary edema, and stroke thrombolysis",
                        "Airway management: Bag-valve-mask ventilation, endotracheal intubation, and emergency cricothyroidotomy"
                    ],
                    practical_project="Emergency Trauma & ACLS Megacode Simulation: Execute simulated cardiac arrest and polytrauma scenarios.",
                    deliverable="Recorded Resuscitation Simulation Debrief & Trauma Survey Documentation.",
                    tasks=[
                        RoadmapTask(id="task-med4-1", title="Lead simulated ACLS Megacode resuscitation", description="Manage ventricular fibrillation, team coordination, and drug timing.", resource_type="practice_project", estimated_hours=10, is_completed=False),
                        RoadmapTask(id="task-med4-2", title="Execute ATLS polytrauma primary survey drill", description="Demonstrate rapid cervical spine stabilization, FAST scan, and shock management.", resource_type="practice_project", estimated_hours=8, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 5",
                    week_number=5,
                    focus_skill="Flagship Clinical Case Audit & Multi-Disciplinary Management",
                    goal="Synthesize clinical examination, diagnostics, evidence-based therapy, and surgical indications into a flagship clinical case portfolio.",
                    how_to_achieve="Step 1: Conduct an in-depth audit of a complex hospital inpatient case from admission to discharge.\nStep 2: Synthesize multi-disciplinary team (MDT) decisions across cardiology, nephrology, and surgery.\nStep 3: Write a structured clinical case report formatted to BMJ Case Reports standards.\nStep 4: Present findings at clinical grand rounds.",
                    recommended_tools=["BMJ Case Reports Guidelines", "NCBI PubMed Central Archive", "Employ.AI Clinical Portfolio"],
                    pro_tips=["A thoroughly documented case report with diagnostic images demonstrates high clinical maturity to recruiters.", "Always highlight learning points that impact clinical practice."],
                    checkpoint_criteria=["Is your clinical case report fully formatted with anonymized consent and verified citations?", "Does the management plan adhere strictly to current clinical guidelines?"],
                    topics=[
                        "Multi-system disease management and multi-disciplinary team (MDT) coordination",
                        "Clinical governance, morbidity & mortality reviews, and patient safety auditing",
                        "Authoring publishable medical case studies adhering to CARE reporting guidelines",
                        "Presentation and defense of clinical management choices under senior consultant scrutiny"
                    ],
                    practical_project="Flagship Clinical Inpatient Audit: Author a publishable CARE-compliant clinical case report with complete workup.",
                    deliverable="Published Clinical Case Study Report + Grand Rounds Presentation Deck.",
                    tasks=[
                        RoadmapTask(id="task-med5-1", title="Author comprehensive clinical case report", description="Document patient history, diagnostic findings, therapeutic rationale, and outcome.", resource_type="practice_project", estimated_hours=14, is_completed=False),
                        RoadmapTask(id="task-med5-2", title="Conduct clinical safety and governance audit", description="Evaluate hospital adherence to sepsis bundles and infection control standards.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 6",
                    week_number=6,
                    focus_skill="Residency Interview Mastery & Clinical Licensing Readiness",
                    goal="Pass residency entrance technical interviews, master clinical viva scenarios, and secure top medical officer appointments.",
                    how_to_achieve="Step 1: Practice 150+ high-yield clinical vignette questions covering acute emergencies and diagnostics.\nStep 2: Prepare for clinical panel interviews focusing on ethical dilemmas, medical errors, and patient communication.\nStep 3: Align your medical CV and portfolio on Employ.AI with verified certifications and clinical logs.\nStep 4: Apply to top matched healthcare openings on the Employ.AI Opportunities Portal.",
                    recommended_tools=["Amboss Medical Question Bank", "Employ.AI Medical CV Studio", "Clinical Viva Simulators"],
                    pro_tips=["When discussing medical ethics, structure your answer around Autonomy, Beneficence, Non-Maleficence, and Justice.", "Keep your clinical logbook certified by attending consultants."],
                    checkpoint_criteria=["Can you score 85%+ on comprehensive clinical vignette mock screenings?", "Is your Employ.AI medical profile verified with clinical credentials?"],
                    topics=[
                        "High-yield residency screening question bank: Clinical vignettes, ECG/imaging spots, and emergencies",
                        "Medical ethics interview scenarios: Breaking bad news (SPIKES protocol) and managing medical errors",
                        "Employ.AI Medical Profile Hardening: Logbook verification and medical CV structuring",
                        "Residency & Hospital panel interviews: Communication skills, teamwork, and leadership"
                    ],
                    practical_project="Residency Clinical Screening Simulation: Complete a 50-question clinical vignette mock screening.",
                    deliverable="Verified Employ.AI Resident Medical Officer Profile with 95%+ Placement Readiness Score.",
                    tasks=[
                        RoadmapTask(id="task-med6-1", title="Complete comprehensive clinical vignette evaluation", description="Score 85%+ on multi-specialty clinical reasoning mock assessment.", resource_type="practice_project", estimated_hours=8, is_completed=False),
                        RoadmapTask(id="task-med6-2", title="Sync verified clinical logbook to Employ.AI profile", description="Upload clinical certifications and apply to matched medical roles.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                )
            ]

        # 4. Corporate Law & Legal Studies (BA LLB)
        if "law" in domain_lower or "llb" in domain_lower or "legal" in title_lower:
            return [
                RoadmapMilestone(
                    week_range="Week 1",
                    week_number=1,
                    focus_skill="Commercial Contract Drafting & Clause Mechanics",
                    goal="Draft enforceable commercial agreements (NDAs, MSAs, SLAs) with standard risk allocation clauses.",
                    how_to_achieve="Step 1: Understand contract formation, consideration, and validity under the Indian Contract Act.\nStep 2: Draft Master Service Agreements (MSAs) with representations & warranties, indemnity, and limitation of liability.\nStep 3: Redline agreements identifying commercial risks and one-sided liabilities.\nStep 4: Practice drafting dispute resolution and governing law clauses.",
                    recommended_tools=["SCC Online Knowledge Portal", "Standard MSA Templates", "Contract Redlining Tools"],
                    pro_tips=["Always define indemnifiable events precisely and cap liability to a multiple of contract fees.", "Never leave dispute resolution clauses ambiguous."],
                    checkpoint_criteria=["Can you redline an aggressive limitation of liability clause to protect your client?", "What distinguishes indemnity from damages for breach of contract?"],
                    topics=[
                        "Commercial contract architecture: Recitals, covenants, representations, warranties, and boilerplate",
                        "Risk allocation clauses: Indemnity, limitation of liability, consequential damages, and liquidated damages",
                        "Termination mechanics: Termination for cause vs convenience, cure periods, and survival provisions",
                        "Dispute resolution clauses: Multi-tier escalation, seated arbitration, and jurisdiction"
                    ],
                    practical_project="Commercial Contract Drafting Suite: Author an end-to-end B2B Master Service Agreement and mutual NDA.",
                    deliverable="Clean & Redlined Master Service Agreement Package with Clause Commentary.",
                    tasks=[
                        RoadmapTask(id="task-law1-1", title="Draft mutual B2B non-disclosure agreement", description="Include strict definition of confidential information, carve-outs, and return obligations.", resource_type="practice_project", estimated_hours=8, is_completed=True),
                        RoadmapTask(id="task-law1-2", title="Redline high-risk commercial MSA contract", description="Negotiate indemnities, IP assignment, and liability caps for a corporate client.", resource_type="practice_project", estimated_hours=8, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 2",
                    week_number=2,
                    focus_skill="Data Privacy Law & Regulatory Compliance (DPDP Act & GDPR)",
                    goal="Implement statutory compliance under the DPDP Act 2023 and GDPR for corporate data fiduciaries.",
                    how_to_achieve="Step 1: Study the provisions of the Digital Personal Data Protection (DPDP) Act 2023.\nStep 2: Draft data processing agreements (DPAs) and consumer privacy notices.\nStep 3: Conduct a Data Protection Impact Assessment (DPIA) identifying high-risk data flows.\nStep 4: Formulate data breach notification protocols and cross-border transfer rules.",
                    recommended_tools=["IAPP Privacy Knowledge Portal", "MeitY DPDP Statutory Portal", "DPIA Assessment Templates"],
                    pro_tips=["Consent under DPDP must be free, specific, informed, unconditional, and unambiguous.", "Implement clear data retention schedules to comply with purpose limitation."],
                    checkpoint_criteria=["What are the statutory duties of a Significant Data Fiduciary (SDF)?", "How do penalties under the DPDP Act compare to GDPR?"],
                    topics=[
                        "DPDP Act 2023 statutory principles: Notice, consent, data principal rights, and penalties",
                        "GDPR vs DPDP Act comparative analysis: Legal bases, legitimate uses, and cross-border transfer rules",
                        "Data Protection Impact Assessments (DPIA) and privacy-by-design audits",
                        "Drafting Data Processing Addendums (DPA) and vendor compliance contracts"
                    ],
                    practical_project="Corporate Privacy Compliance Audit: Author a complete DPDP Act compliance audit and consumer privacy policy.",
                    deliverable="Statutory Data Protection Policy & Vendor DPA Addendum Package.",
                    tasks=[
                        RoadmapTask(id="task-law2-1", title="Draft DPDP Act compliant privacy notice", description="Include purpose specifications, consent withdrawal mechanics, and grievance redressal.", resource_type="practice_project", estimated_hours=8, is_completed=False),
                        RoadmapTask(id="task-law2-2", title="Execute vendor data protection audit", description="Draft Data Processing Addendum with standard contractual clauses.", resource_type="practice_project", estimated_hours=8, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 3",
                    week_number=3,
                    focus_skill="Corporate Governance, M&A Due Diligence & Companies Act",
                    goal="Execute legal due diligence audits for M&A deals, draft SHA/SSA term sheets, and manage Companies Act filings.",
                    how_to_achieve="Step 1: Understand Companies Act 2013 provisions on director duties, board meetings, and share capital.\nStep 2: Review target company documentation across corporate, regulatory, labor, and IP records.\nStep 3: Author a Red-Flag Legal Due Diligence Report identifying deal-breaker liabilities.\nStep 4: Draft key clauses of Shareholders' Agreements (SHA) including ROFO, ROFR, drag-along, and tag-along rights.",
                    recommended_tools=["Manupatra Fast Legal Database", "Due Diligence Checklists", "MCA E-Filing Knowledge Base"],
                    pro_tips=["Always scrutinize regulatory licenses and pending litigation for unquantified contingent liabilities.", "Tag-along and drag-along rights must align with founder dilution thresholds."],
                    checkpoint_criteria=["Can you structure a tag-along right clause protect minority investors?", "What are the essential elements of an M&A Red-Flag Due Diligence Memo?"],
                    topics=[
                        "M&A Due Diligence methodology: Corporate records, material contracts, regulatory licenses, and litigation",
                        "Shareholders' Agreements (SHA) & Share Subscription Agreements (SSA) mechanics",
                        "Investor protection clauses: Anti-dilution, liquidation preference, affirmative voting items, and exit rights",
                        "Companies Act 2013 statutory compliance, board resolutions, and ROC annual filings"
                    ],
                    practical_project="M&A Deal Legal Due Diligence Memo: Conduct a mock due diligence audit of an early-stage enterprise.",
                    deliverable="Executive Legal Due Diligence Report with Risk Mitigation Strategies.",
                    tasks=[
                        RoadmapTask(id="task-law3-1", title="Author M&A red-flag due diligence audit", description="Evaluate corporate compliance, IP assignment, and regulatory risk across 20 target documents.", resource_type="practice_project", estimated_hours=10, is_completed=False),
                        RoadmapTask(id="task-law3-2", title="Draft Shareholders' Agreement investor protection clauses", description="Formulate anti-dilution, affirmative voting, and ROFR clauses.", resource_type="practice_project", estimated_hours=8, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 4",
                    week_number=4,
                    focus_skill="Dispute Resolution, Commercial Arbitration & Court Pleadings",
                    goal="Draft commercial court pleadings, interim applications (Section 9/11 petitions), and arbitration statements of claim.",
                    how_to_achieve="Step 1: Study the Arbitration and Conciliation Act 1996 and Commercial Courts Act 2015.\nStep 2: Draft a Notice of Dispute and Section 21 Invocation of Arbitration.\nStep 3: Author an application for interim measures under Section 9 and appointment of arbitrator under Section 11.\nStep 4: Draft a comprehensive Statement of Claim with prayer for relief and damages.",
                    recommended_tools=["SCC Online Case Search", "Arbitration Act Commentary", "Pleading Formats Repository"],
                    pro_tips=["Always comply strictly with Section 12A pre-institution mediation requirements under Commercial Courts Act.", "Clearly articulate the cause of action and quantify claims with documentary proof."],
                    checkpoint_criteria=["How do you challenge an arbitral award under Section 34 of the Arbitration Act?", "What grounds justify interim relief under Section 9?"],
                    topics=[
                        "Arbitration and Conciliation Act 1996: Arbitral tribunal jurisdiction, seat vs venue, and enforcement",
                        "Drafting arbitral pleadings: Notice of arbitration, Statement of Claim, Statement of Defense, and counterclaims",
                        "Interim relief under Section 9 vs Section 17: Balancing convenience and irreparable injury",
                        "Section 34 challenge grounds: Patent illegality, public policy of India, and fundamental policy"
                    ],
                    practical_project="Commercial Dispute Pleading Package: Draft a Section 9 interim relief petition and Statement of Claim.",
                    deliverable="Verified Court Pleading Brief with Index of Precedents and Affidavits.",
                    tasks=[
                        RoadmapTask(id="task-law4-1", title="Draft Section 9 petition for interim injunction", description="Argue prima facie case, balance of convenience, and irreparable harm before Commercial Court.", resource_type="practice_project", estimated_hours=10, is_completed=False),
                        RoadmapTask(id="task-law4-2", title="Author Section 21 notice of arbitration", description="Specify dispute details, contractual basis, and nominated arbitrator panel.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 5",
                    week_number=5,
                    focus_skill="Flagship Legal Advisory Whitepaper & Published Brief",
                    goal="Synthesize contract drafting, statutory compliance, and dispute strategy into a flagship legal advisory case portfolio.",
                    how_to_achieve="Step 1: Select an emerging legal frontier (AI governance, FinTech lending, cross-border privacy, or renewable energy M&A).\nStep 2: Author a comprehensive 15-page legal advisory whitepaper analyzing statutory ambiguities.\nStep 3: Provide actionable contract clauses and risk mitigation recommendations for corporate clients.\nStep 4: Publish your legal brief on SCC Online / LiveLaw / LinkedIn.",
                    recommended_tools=["SCC Online Legal Research", "Manupatra Law Publisher", "Employ.AI Legal Portfolio"],
                    pro_tips=["A published legal research paper with novel analysis gets 5x more law firm interview callbacks.", "Structure your arguments logically with IRAC: Issue, Rule, Application, Conclusion."],
                    checkpoint_criteria=["Is your legal advisory brief fully substantiated with current Supreme Court precedents?", "Does the analysis provide practical solutions for corporate legal teams?"],
                    topics=[
                        "Emerging corporate legal issues: FinTech digital lending, AI intellectual property, and DPDP rules",
                        "Advanced statutory interpretation: Purposive construction, legislative intent, and landmark judgments",
                        "Authoring publishable legal commentary and client advisory memorandums",
                        "Packaging legal portfolios for Tier 1 corporate law firm and in-house counsel recruitment"
                    ],
                    practical_project="Flagship Corporate Legal Advisory Brief: Author a comprehensive legal brief on FinTech / DPDP compliance.",
                    deliverable="Published Legal Research Whitepaper + Clause Advisory Annexures.",
                    tasks=[
                        RoadmapTask(id="task-law5-1", title="Author comprehensive corporate legal whitepaper", description="Deliver 15-page deep dive into emerging statutory compliance and risk allocation.", resource_type="practice_project", estimated_hours=14, is_completed=False),
                        RoadmapTask(id="task-law5-2", title="Publish and syndicate legal brief to portfolio", description="Link verified publications to Employ.AI candidate profile for recruiter visibility.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                ),
                RoadmapMilestone(
                    week_range="Week 6",
                    week_number=6,
                    focus_skill="Law Firm Technical Screening & Placement Readiness",
                    goal="Pass Tier 1 corporate law firm technical screening rounds, moot drills, and secure associate appointments.",
                    how_to_achieve="Step 1: Practice 150+ corporate law technical questions on contract interpretation, Companies Act, and arbitration.\nStep 2: Complete mock technical problem-solving rounds analyzing hypothetical transaction bottlenecks.\nStep 3: Align your legal CV on Employ.AI ATS Scanner, highlighting verified drafting deliverables.\nStep 4: Apply to top matched law firms on the Employ.AI Opportunities Portal.",
                    recommended_tools=["LiveLaw Interview Question Banks", "Employ.AI Legal CV Studio", "Moot Court Problem Repositories"],
                    pro_tips=["When answering hypothetical contract questions, always start by identifying the risk allocation and standard clause remedies.", "Highlight real drafting experience with specific clause examples."],
                    checkpoint_criteria=["Can you score 85%+ on law firm technical mock evaluations?", "Is your Employ.AI legal profile at 90%+ ATS match score?"],
                    topics=[
                        "Tier 1 law firm technical question bank: Contract drafting, indemnity nuances, Companies Act, and DPDP",
                        "Hypothetical deal screening drills: Resolving deadlock clauses, breach of warranty, and hostile exits",
                        "Employ.AI Legal Profile Hardening: Synchronizing verified briefs and CV optimization",
                        "HR and partner panel interview mastery: Commercial mindset, attention to detail, and work ethic"
                    ],
                    practical_project="Corporate Law Firm Interview Simulation: Complete a 50-question commercial law technical evaluation.",
                    deliverable="Verified Employ.AI Legal Associate Profile with 95%+ Match Score and Active Applications.",
                    tasks=[
                        RoadmapTask(id="task-law6-1", title="Complete comprehensive law firm technical screening", description="Score 85%+ on contract negotiation and statutory interpretation assessment.", resource_type="practice_project", estimated_hours=8, is_completed=False),
                        RoadmapTask(id="task-law6-2", title="Tailor and sync legal resume to 90%+ ATS match", description="Upload verified contract deliverables and submit applications via portal.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                    ]
                )
            ]

        # 5. Generic Multi-Discipline 6-Week Blueprint for All Other Careers
        primary_gap = missing_skill_names[0] if missing_skill_names else (role.skills[0].skill_name if role.skills else "Core Domain Principles")
        secondary_gap = missing_skill_names[1] if len(missing_skill_names) > 1 else (role.skills[1].skill_name if len(role.skills) > 1 else "Applied Industry Tooling")
        tertiary_gap = missing_skill_names[2] if len(missing_skill_names) > 2 else (role.skills[2].skill_name if len(role.skills) > 2 else "Advanced System Standards")

        return [
            RoadmapMilestone(
                week_range="Week 1",
                week_number=1,
                focus_skill=f"Foundational Principles & Core Specifications: {primary_gap}",
                goal=f"Master fundamental theory, terminology, standard specifications, and environment setup for {role.title}.",
                how_to_achieve=f"Step 1: Study fundamental theoretical frameworks and core terminology of {primary_gap}.\nStep 2: Install and configure industry-standard software, toolchains, or documentation environments.\nStep 3: Solve introductory problem sets, analyze standard test cases, and establish diagnostic checklists.\nStep 4: Verify calculations against established academic and industry standards.",
                recommended_tools=[f"Standard {role.domain} Tooling", "Core Documentation", "Verification Checklists"],
                pro_tips=[f"Focus on mastering first principles in {primary_gap} before moving to automated tools.", "Document every assumption used in introductory calculations."],
                checkpoint_criteria=[f"Can you explain the core operational mechanisms governing {primary_gap}?", "Are your reference datasets and tools fully calibrated?"],
                topics=[
                    f"Core theoretical foundations and domain specifications of {primary_gap}",
                    f"Industry terminology, standard operating procedures, and safety/quality guidelines in {role.domain}",
                    "Environment setup, navigation shortcuts, and parameter definitions",
                    "Introductory problem solving, baseline calculations, and error verification"
                ],
                practical_project=f"Foundational Diagnostic Exercise: Build a verified introductory artifact validating {primary_gap}.",
                deliverable=f"Documented Practical Methodology & Foundation Report for {primary_gap}.",
                tasks=[
                    RoadmapTask(id="task-gen-1-1", title=f"Study core documentation of {primary_gap}", description="Complete introductory modules and baseline assessment quiz.", resource_type="documentation", estimated_hours=8, is_completed=True),
                    RoadmapTask(id="task-gen-1-2", title=f"Execute introductory problem set in {primary_gap}", description="Implement foundational exercise adhering to standard constraints.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                ]
            ),
            RoadmapMilestone(
                week_range="Week 2",
                week_number=2,
                focus_skill=f"Deep Domain Mechanics & Methodologies: {primary_gap}",
                goal=f"Advance from introductory concepts to intermediate domain analysis, syntax modeling, and parameter optimization in {primary_gap}.",
                how_to_achieve=f"Step 1: Dive into intermediate formulas, edge cases, and standard operational failure modes in {primary_gap}.\nStep 2: Model realistic scenarios with multi-variable constraints and evaluate system trade-offs.\nStep 3: Perform benchmarking against known industry published data.\nStep 4: Refine accuracy, error tolerances, and documentation quality.",
                recommended_tools=[f"Specialized {role.domain} Software", "Benchmark Datasets", "Diagnostic Testing Tools"],
                pro_tips=["Always account for real-world environmental tolerances and safety factors.", "Adopt standardized naming conventions and modular organization."],
                checkpoint_criteria=[f"How do you handle edge cases within {primary_gap}?", "Can you explain the sensitivity of your model parameters?"],
                topics=[
                    f"Intermediate methodologies, equations, and simulation techniques in {primary_gap}",
                    "Edge-case diagnostics, failure mode analysis, and mitigation planning",
                    "Data validation, standard tolerance limits, and quality assurance",
                    "Optimization strategies for cost, speed, efficiency, and compliance"
                ],
                practical_project=f"Intermediate Analysis Model: Build a multi-variable calculation or simulation model for {primary_gap}.",
                deliverable=f"Verified Computational Model & Analysis Report with Parameter Sensitivity Charts.",
                tasks=[
                    RoadmapTask(id="task-gen-2-1", title=f"Develop multi-variable model in {primary_gap}", description="Simulate realistic operational constraints and verify outputs.", resource_type="practice_project", estimated_hours=10, is_completed=False),
                    RoadmapTask(id="task-gen-2-2", title="Perform error diagnostic and tolerance check", description="Document sensitivity analysis across minimum/maximum variance.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                ]
            ),
            RoadmapMilestone(
                week_range="Week 3",
                week_number=3,
                focus_skill=f"Applied Professional Tooling & Simulation: {secondary_gap}",
                goal=f"Master professional industry software, standard workflows, and applied tooling for {secondary_gap}.",
                how_to_achieve=f"Step 1: Learn core UI navigation, commands, and automation pipelines of professional tools in {secondary_gap}.\nStep 2: Execute realistic simulated scenarios reflecting current corporate and engineering practices.\nStep 3: Integrate data flows between foundational models and applied tooling suites.\nStep 4: Verify outputs against industry statutory standards and benchmarks.",
                recommended_tools=[f"Industry Standard {secondary_gap} Suite", "Simulation Engines", "Data Export Tools"],
                pro_tips=["Utilize keyboard shortcuts and automated scripts to accelerate your workflow.", "Always verify units when importing external datasets."],
                checkpoint_criteria=[f"Can you execute end-to-end tasks in the industry tool of {secondary_gap}?", "Are your simulation models verified for convergence?"],
                topics=[
                    f"Professional software architecture, configuration, and execution in {secondary_gap}",
                    "Applied simulation, modeling pipelines, and automated reporting",
                    "Benchmarking against industry standards and statutory performance criteria",
                    "Quality control, cross-tool interoperability, and documentation"
                ],
                practical_project=f"Applied Tooling Simulation: Execute end-to-end simulation or modeling exercise in {secondary_gap}.",
                deliverable=f"Verified Applied Technical Report with Exported Output Artifacts for {secondary_gap}.",
                tasks=[
                    RoadmapTask(id="task-gen-3-1", title=f"Complete application workflow in {secondary_gap}", description="Deliver full simulation scenario adhering to quality guidelines.", resource_type="practice_project", estimated_hours=12, is_completed=False),
                    RoadmapTask(id="task-gen-3-2", title="Validate data integrity and export formats", description="Confirm compliance with industry exchange protocols.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                ]
            ),
            RoadmapMilestone(
                week_range="Week 4",
                week_number=4,
                focus_skill=f"System Integration & Quality Standards: {tertiary_gap}",
                goal=f"Integrate modular competencies into end-to-end workflows, enforce quality assurance, and stress-test performance.",
                how_to_achieve=f"Step 1: Combine {primary_gap} and {secondary_gap} into an integrated system architecture.\nStep 2: Perform stress tests, edge-case evaluations, and regulatory compliance checks.\nStep 3: Optimize throughput, material efficiency, or compliance adherence.\nStep 4: Prepare comprehensive documentation, executive summary, and stakeholder presentations.",
                recommended_tools=["System Integration Suites", "Stress Testing Utilities", "Compliance Checklists"],
                pro_tips=["System integration is where bugs appear—test interfaces early and often.", "Ensure clear separation of concerns across different architectural modules."],
                checkpoint_criteria=["Does your integrated workflow execute with zero critical errors?", "Have you verified adherence to relevant compliance standards?"],
                topics=[
                    "Multi-discipline system integration and end-to-end operational pipelines",
                    "Quality assurance protocols, regulatory compliance, and statutory audit readiness",
                    "Stress testing, performance tuning, and bottleneck mitigation",
                    "Executive presentation, technical documentation, and stakeholder reporting"
                ],
                practical_project="Integrated Subsystem Prototype: Build and stress-test a multi-component solution combining key skills.",
                deliverable="Comprehensive System Integration Audit & Performance Benchmark Report.",
                tasks=[
                    RoadmapTask(id="task-gen-4-1", title=f"Integrate multi-module workflow for {role.title}", description="Connect components and execute end-to-end validation test.", resource_type="practice_project", estimated_hours=10, is_completed=False),
                    RoadmapTask(id="task-gen-4-2", title="Conduct compliance audit and stress analysis", description="Document resilience under 150% peak operating conditions.", resource_type="practice_project", estimated_hours=8, is_completed=False)
                ]
            ),
            RoadmapMilestone(
                week_range="Week 5",
                week_number=5,
                focus_skill=f"Comprehensive Capstone Flagship Project for {role.title}",
                goal=f"Synthesize acquired competencies into a flagship portfolio capstone project targeting {role.title} industry benchmarks.",
                how_to_achieve=f"Step 1: Define project scope, requirements, user constraints, and quantified impact metrics.\nStep 2: Build the end-to-end solution utilizing professional industry best practices.\nStep 3: Validate deliverables through rigorous testing, simulation, or peer review.\nStep 4: Package the capstone with high-quality README, architecture diagrams, or case study PDF.",
                recommended_tools=[f"Full {role.domain} Suite", "Portfolio Publishing Platform", "Diagramming Tools"],
                pro_tips=["Recruiters look for proof of problem-solving—explain challenges faced and overcome.", "Quantify your results with clear metrics (% efficiency, time saved)."],
                checkpoint_criteria=["Is your flagship capstone project completely functional with verified outputs?", "Does your portfolio case study clearly articulate the problem and solution?"],
                topics=[
                    f"Full-lifecycle design, development, simulation, and verification for {role.domain} standards",
                    "Comprehensive technical documentation, user guides, and return on investment (ROI) metrics",
                    "Peer review methodologies, professional design presentation, and code/model quality",
                    "Packaging and publishing case studies for maximum recruiter engagement"
                ],
                practical_project=f"Flagship Capstone Project: End-to-end design, execution, and verification tailored to {role.title}.",
                deliverable="Published GitHub / PDF Portfolio Case Study with Quantified Impact Metrics and Demo.",
                tasks=[
                    RoadmapTask(id="task-gen-5-1", title="Execute and document flagship capstone project", description="Deliver complete problem-solution breakdown, architecture, and outputs.", resource_type="practice_project", estimated_hours=14, is_completed=False),
                    RoadmapTask(id="task-gen-5-2", title="Record a professional project presentation walkthrough", description="Showcase design decisions and quantitative results in a 2-minute demo.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                ]
            ),
            RoadmapMilestone(
                week_range="Week 6",
                week_number=6,
                focus_skill=f"Employ.AI Profile Hardening, ATS Optimization & Placement Readiness",
                goal=f"Submit verified portfolio evidence, pass technical mock screenings, optimize your resume ATS score, and apply for high-match {role.title} positions.",
                how_to_achieve=f"Step 1: Upload and synchronize verified capstone evidence to your Employ.AI Student Profile.\nStep 2: Optimize your resume using the Employ.AI ATS Scanner and STAR Rewriter for {role.title}.\nStep 3: Complete technical and behavioral mock interview evaluations with real-time feedback.\nStep 4: Submit applications directly to verified recruiters on the portal.",
                recommended_tools=["Employ.AI Resume Studio", "ATS Score Optimizer", "Mock Interview Simulator", "Employ.AI Opportunities Portal"],
                pro_tips=[f"Customize your resume summary to directly highlight your capstone project for {role.title}.", "Apply within 24 hours of new job postings on the portal."],
                checkpoint_criteria=[f"Is your resume ATS score above 85% for {role.title}?", "Have you synced all 6 weeks of completed tasks to your profile?"],
                topics=[
                    "Updating Employ.AI verified skills with capstone evidence and credentials",
                    f"Domain-specific interview preparation and technical screening question banks for {role.title}",
                    "ATS resume keyword optimization and STAR impact bullet formula alignment",
                    "Active placement campaign execution: Applying to matched recruiter postings and tracking offers"
                ],
                practical_project=f"Verified Employ.AI Profile & Placement Campaign: Apply to top matched opportunities for {role.title}.",
                deliverable="Verified Employ.AI Candidate Portfolio & Active Applications Tracked on Portal.",
                tasks=[
                    RoadmapTask(id="task-gen-6-1", title="Sync verified capstone to Employ.AI profile", description="Elevate candidate readiness score to maximum placement tier.", resource_type="practice_project", estimated_hours=6, is_completed=False),
                    RoadmapTask(id="task-gen-6-2", title=f"Apply to verified {role.title} job & internship opportunities", description="Submit tailored applications through the Employ.AI Opportunities Portal.", resource_type="practice_project", estimated_hours=6, is_completed=False)
                ]
            )
        ]

    @staticmethod
    def generate_personalized_roadmap(
        db: Session,
        student_profile: StudentProfile,
        target_role_id: str,
        weeks_available: int = 6
    ) -> LearningRoadmapResponse:
        """Generate or retrieve structured upskilling roadmap customized to candidate's exact skill gaps."""
        role = db.query(Role).filter(Role.id == target_role_id).first()
        if not role:
            raise ValueError(f"Role with ID '{target_role_id}' not found.")

        # Compute skill gaps for this role
        gap_eval = MatchingService.calculate_role_match(db, student_profile, role)
        missing_skill_names = [m.skill_name for m in gap_eval.missing_skills]

        # Construct comprehensive beginner-to-advanced 6-week milestones
        milestones = RoadmapService._build_domain_milestones(role, missing_skill_names)
        milestones_json = [m.model_dump() for m in milestones]

        # Check existing
        existing = db.query(LearningRoadmap).filter(
            LearningRoadmap.student_profile_id == student_profile.id,
            LearningRoadmap.target_role_id == role.id
        ).first()

        if not existing:
            roadmap_record = LearningRoadmap(
                student_profile_id=student_profile.id,
                target_role_id=role.id,
                title=f"Personalized 6-Week Roadmap: {role.title}",
                estimated_weeks=weeks_available,
                milestones_json=milestones_json,
                created_at=datetime.now(timezone.utc)
            )
            db.add(roadmap_record)
        else:
            existing.milestones_json = milestones_json
            existing.title = f"Personalized 6-Week Roadmap: {role.title}"
            existing.updated_at = datetime.now(timezone.utc)
            roadmap_record = existing

        db.commit()
        db.refresh(roadmap_record)

        return LearningRoadmapResponse(
            id=roadmap_record.id,
            student_profile_id=student_profile.id,
            target_role_id=role.id,
            target_role_title=role.title,
            target_domain=role.domain,
            title=roadmap_record.title,
            estimated_weeks=roadmap_record.estimated_weeks,
            milestones=milestones,
            created_at=roadmap_record.created_at
        )
