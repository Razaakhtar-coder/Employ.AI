const { spawn } = require('child_process');
const http = require('http');
const path = require('path');

const rootDir = __dirname;
const backendDir = path.join(rootDir, 'backend');
const frontendDir = path.join(rootDir, 'frontend');

console.log('===============================================================');
console.log('  🚀 EmployAI - Unified Fullstack Application Launcher');
console.log('===============================================================');
console.log('[1/2] Starting Python FastAPI Backend on http://127.0.0.1:8000 ...');

// Detect best python interpreter with dependencies
function getPythonLaunchConfig() {
  if (process.platform === 'win32') {
    const candidates = [
      { cmd: 'py', args: ['-3.11', 'run.py'] },
      { cmd: 'python', args: ['run.py'] },
      { cmd: 'py', args: ['run.py'] }
    ];
    for (const cand of candidates) {
      try {
        const testArgs = cand.args.filter(a => a !== 'run.py').concat(['-c', 'import uvicorn']);
        const { execFileSync } = require('child_process');
        execFileSync(cand.cmd, testArgs, { stdio: 'ignore' });
        return cand;
      } catch (e) {}
    }
    return { cmd: 'py', args: ['-3.11', 'run.py'] };
  }
  return { cmd: 'python3', args: ['run.py'] };
}

const isWin = process.platform === 'win32';
const pyConfig = getPythonLaunchConfig();

const backendProcess = spawn(pyConfig.cmd, pyConfig.args, {
  cwd: backendDir,
  stdio: 'inherit',
  shell: true,
  env: {
    ...process.env,
    PYTHONUNBUFFERED: '1',
    PYTHONIOENCODING: 'utf-8'
  }
});

backendProcess.on('error', (err) => {
  console.error('[BACKEND ERROR] Failed to start backend:', err.message);
});

// Function to poll backend health check
function checkBackendHealth(retries = 30, delayMs = 600) {
  return new Promise((resolve) => {
    let attempts = 0;
    const interval = setInterval(() => {
      attempts++;
      const req = http.get('http://127.0.0.1:8000/health', (res) => {
        if (res.statusCode === 200) {
          clearInterval(interval);
          resolve(true);
        }
      });

      req.on('error', () => {
        if (attempts >= retries) {
          clearInterval(interval);
          resolve(false);
        }
      });
      req.setTimeout(500, () => req.abort());
    }, delayMs);
  });
}

console.log('[2/2] Launching Vite React Frontend on http://localhost:5173 ...');

const npmCmd = isWin ? 'npm.cmd' : 'npm';
const frontendProcess = spawn(npmCmd, ['run', 'dev'], {
  cwd: frontendDir,
  stdio: 'inherit',
  shell: true
});

frontendProcess.on('error', (err) => {
  console.error('[FRONTEND ERROR] Failed to start frontend:', err.message);
});

// Graceful cleanup on termination
const cleanup = () => {
  console.log('\n[INFO] Shutting down EmployAI fullstack services...');
  try {
    if (isWin) {
      if (backendProcess.pid) spawn('taskkill', ['/pid', backendProcess.pid, '/f', '/t']);
      if (frontendProcess.pid) spawn('taskkill', ['/pid', frontendProcess.pid, '/f', '/t']);
    } else {
      backendProcess.kill('SIGTERM');
      frontendProcess.kill('SIGTERM');
    }
  } catch (e) {
    // ignore
  }
  process.exit();
};

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);
