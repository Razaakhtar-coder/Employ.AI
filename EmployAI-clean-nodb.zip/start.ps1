Write-Host "===============================================================" -ForegroundColor Cyan
Write-Host "  EmployAI - Starting Backend & Frontend Services" -ForegroundColor Cyan
Write-Host "===============================================================" -ForegroundColor Cyan
Write-Host ""

node run-all.js
