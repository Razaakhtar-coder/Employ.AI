import re
import html
import xml.etree.ElementTree as ET
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting


class WeWorkRemotelyProvider(JobProviderAdapter):
    """
    WeWorkRemotely (WWR) Public Job Feed Adapter.
    Pulls live verified remote listings across Programming, Management & Finance,
    Design, DevOps, Product, and Customer Support.
    """

    FEEDS = [
        "https://weworkremotely.com/categories/remote-programming-jobs.rss",
        "https://weworkremotely.com/categories/remote-management-and-finance-jobs.rss",
        "https://weworkremotely.com/categories/remote-design-jobs.rss",
        "https://weworkremotely.com/categories/remote-devops-sysadmin-jobs.rss"
    ]

    @property
    def name(self) -> str:
        return "WeWorkRemotely"

    @property
    def is_enabled(self) -> bool:
        return True

    def _strip_html(self, raw_html: str) -> str:
        if not raw_html:
            return ""
        clean = re.sub(r"<[^>]+>", " ", raw_html)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    async def _fetch_feed(self, client: httpx.AsyncClient, feed_url: str) -> List[RawJobPosting]:
        postings: List[RawJobPosting] = []
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) EmployAI/1.0",
                "Accept": "application/rss+xml, application/xml, text/xml"
            }
            res = await client.get(feed_url, headers=headers)
            if res.status_code != 200:
                return []

            root = ET.fromstring(res.content)
            channel = root.find("channel")
            if channel is None:
                return []

            for item in channel.findall("item")[:20]:
                title_elem = item.find("title")
                link_elem = item.find("link")
                desc_elem = item.find("description")
                pub_elem = item.find("pubDate")
                guid_elem = item.find("guid")

                raw_title = title_elem.text if title_elem is not None and title_elem.text else ""
                apply_link = link_elem.text if link_elem is not None and link_elem.text else "https://weworkremotely.com"
                raw_desc = self._strip_html(desc_elem.text if desc_elem is not None and desc_elem.text else "")
                pub_date = pub_elem.text if pub_elem is not None and pub_elem.text else "Recently"
                guid = guid_elem.text if guid_elem is not None and guid_elem.text else raw_title

                # WWR titles are often in the form: "CompanyName: RoleTitle"
                company = "Remote Enterprise"
                job_title = raw_title
                if ":" in raw_title:
                    parts = raw_title.split(":", 1)
                    company = parts[0].strip()
                    job_title = parts[1].strip()

                title_lower = job_title.lower()
                desc_lower = raw_desc[:400].lower()

                mapped_type = "full-time"
                exp_level = "entry"

                if "intern" in title_lower or "internship" in title_lower or "trainee" in title_lower:
                    mapped_type = "internship"
                    exp_level = "intern"
                elif "contract" in title_lower or "freelance" in title_lower:
                    mapped_type = "contract"
                elif "part-time" in title_lower or "part time" in title_lower:
                    mapped_type = "part-time"

                if exp_level != "intern":
                    if re.search(r"\b(senior|lead|staff|principal|director|head of)\b", title_lower):
                        exp_level = "senior"
                    elif re.search(r"\b(mid|intermediate|2-4 years)\b", title_lower):
                        exp_level = "mid"

                postings.append(RawJobPosting(
                    source_id=f"wwr-{guid}",
                    source="WeWorkRemotely",
                    title=job_title,
                    company=company,
                    location="Worldwide (Remote)",
                    remote=True,
                    job_type=mapped_type,
                    experience_level=exp_level,
                    description=raw_desc[:2500],
                    required_skills=[],
                    apply_url=apply_link,
                    posted_date=pub_date[:16]
                ))

        except Exception as e:
            print(f"[WARN] Failed fetching WWR feed {feed_url}: {e}")

        return postings

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        all_postings: List[RawJobPosting] = []

        try:
            async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as client:
                for feed_url in self.FEEDS:
                    feed_jobs = await self._fetch_feed(client, feed_url)
                    all_postings.extend(feed_jobs)

            # Filtering
            filtered: List[RawJobPosting] = []
            for p in all_postings:
                if job_type and job_type.lower() != "all" and job_type.lower() not in p.job_type.lower():
                    continue
                if query:
                    q_low = query.lower()
                    if q_low not in p.title.lower() and q_low not in p.company.lower() and q_low not in p.description.lower():
                        continue
                filtered.append(p)

            return filtered

        except Exception as e:
            print(f"[ERROR] WeWorkRemotely fetch_jobs failed: {e}")

        return all_postings
