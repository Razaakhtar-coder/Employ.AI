from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel


class RoadmapTask(BaseModel):
    id: str
    title: str
    description: str
    resource_type: str  # course, documentation, practice_project, certification
    resource_url: Optional[str] = None
    estimated_hours: int
    is_completed: bool = False


class RoadmapMilestone(BaseModel):
    week_range: str  # e.g., "Phase 1: Beginner Fundamentals" or "Week 1"
    week_number: Optional[int] = None
    stage_level: Optional[str] = None  # beginner, intermediate, advanced, projects, placement
    phase_title: Optional[str] = None
    focus_skill: str
    goal: str
    how_to_achieve: Optional[str] = None
    key_action_steps: Optional[List[str]] = None
    recommended_tools: Optional[List[str]] = None
    pro_tips: Optional[List[str]] = None
    checkpoint_criteria: Optional[List[str]] = None
    interview_questions: Optional[List[Dict[str, Any]]] = None
    learning_platforms: Optional[List[Dict[str, Any]]] = None
    youtube_resources: Optional[List[Dict[str, Any]]] = None
    topics: List[str] = []
    practical_project: Optional[str] = None
    suggested_project: Optional[str] = None
    deliverable: Optional[str] = None
    tasks: List[RoadmapTask] = []
    is_completed: Optional[bool] = False


class PlacementIntelligence(BaseModel):
    target_entry_roles: List[str] = []
    ats_keywords: List[str] = []
    star_bullet_examples: List[str] = []
    top_hiring_companies: List[str] = []
    expected_salary_range: Optional[str] = None
    interview_screening_checklist: List[str] = []


class LearningRoadmapResponse(BaseModel):
    id: str
    student_profile_id: str
    target_role_id: str
    target_role_title: str
    target_domain: str
    domain: Optional[str] = None
    title: str
    estimated_weeks: int
    roadmap_type: Optional[str] = "role"
    co_domain_name: Optional[str] = None
    completion_pct: Optional[int] = 0
    placement_destination: Optional[PlacementIntelligence] = None
    milestones: List[RoadmapMilestone]
    created_at: datetime

    class Config:
        from_attributes = True


class RoadmapGenerateRequest(BaseModel):
    target_role_id: str
    weeks_available: Optional[int] = 6
    roadmap_type: Optional[str] = "role"
    co_domain_name: Optional[str] = None

