from typing import Generator, Optional, List
from datetime import datetime, timezone, timedelta
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

from app.core.database import SessionLocal
from app.core.security import decode_access_token
from app.core.exceptions import UnauthorizedException, ForbiddenException
from app.models.user import User

security_bearer = HTTPBearer(auto_error=False)


def get_db() -> Generator[Session, None, None]:
    """Provide a transactional database session per request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


ADMIN_EMAIL = "akhtarrakeeb52@gmail.com"


def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security_bearer),
    db: Session = Depends(get_db)
) -> User:
    """Validate Bearer JWT and return the authenticated User record with live subscription verification."""
    if not credentials:
        raise UnauthorizedException("Authentication token is missing")
    
    token = credentials.credentials
    payload = decode_access_token(token)
    if not payload:
        raise UnauthorizedException("Invalid or expired authentication token")
    
    user_id = payload.get("sub")
    if not user_id:
        raise UnauthorizedException("Malformed token payload")
    
    user = db.query(User).filter(User.id == user_id, User.is_active == True).first()
    if not user:
        # On serverless platforms (e.g. Vercel), the local SQLite database in /tmp may be
        # fresh while the user has a valid, cryptographically signed token.
        token_email = payload.get("email")
        if token_email:
            from app.models.profile import StudentProfile
            from app.core.security import get_password_hash
            norm_email = token_email.strip().lower()
            is_admin = (norm_email == ADMIN_EMAIL.lower())
            role = "admin" if is_admin else (payload.get("role") or "student")
            full_name = payload.get("full_name") or norm_email.split("@")[0]
            is_premium = is_admin or bool(payload.get("is_premium", False))
            user = User(
                id=user_id,
                email=norm_email,
                hashed_password=get_password_hash("serverless_token_session"),
                full_name=full_name,
                role=role,
                auth_provider="email",
                is_active=True,
                is_premium=is_premium
            )
            db.add(user)
            db.flush()
            if role in ["student", "admin"]:
                db.add(StudentProfile(
                    user_id=user.id,
                    institution_name="Technological University",
                    department="Computer Science & Engineering",
                    target_domain="Computer Science",
                    profile_completion_pct=60
                ))
            db.commit()
            db.refresh(user)
        else:
            raise UnauthorizedException("User account not found or deactivated")

    # Strict Admin enforcement: akhtarrakeeb52@gmail.com is always Admin & Lifetime Premium
    if user.email.strip().lower() == ADMIN_EMAIL.lower():
        if user.role != "admin" or not user.is_premium:
            user.role = "admin"
            user.is_premium = True
            user.subscription_plan = "lifetime"
            db.commit()
            db.refresh(user)
    else:
        # Prevent any other email from having admin role
        if user.role == "admin":
            user.role = "student"
            db.commit()
            db.refresh(user)

        # Real-time subscription validity verification for standard users
        if user.is_premium:
            now_utc = datetime.now(timezone.utc)
            valid_until = getattr(user, "subscription_valid_until", None)
            is_lapsed = False

            if valid_until:
                if valid_until.tzinfo is None:
                    valid_until = valid_until.replace(tzinfo=timezone.utc)
                if now_utc > valid_until:
                    is_lapsed = True
            else:
                # If valid_until was not explicitly stamped, check premium_since + 30 days
                base_time = getattr(user, "premium_since", None) or getattr(user, "created_at", None)
                if base_time:
                    if base_time.tzinfo is None:
                        base_time = base_time.replace(tzinfo=timezone.utc)
                    if now_utc > (base_time + timedelta(days=30)):
                        is_lapsed = True

            if is_lapsed:
                user.is_premium = False
                db.commit()
                db.refresh(user)
                try:
                    from app.services.auth_service import AuthService
                    AuthService._save_backup_user(user)
                except Exception:
                    pass
    
    return user


def get_optional_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security_bearer),
    db: Session = Depends(get_db)
) -> Optional[User]:
    """Retrieve user if token is present, else None."""
    if not credentials:
        return None
    try:
        return get_current_user(credentials, db)
    except HTTPException:
        return None


def require_roles(allowed_roles: List[str]):
    """Enforce role-based access control (RBAC)."""
    def role_checker(current_user: User = Depends(get_current_user)) -> User:
        if current_user.email.strip().lower() == ADMIN_EMAIL.lower():
            return current_user
        if current_user.role not in allowed_roles:
            raise ForbiddenException(
                f"Role '{current_user.role}' is not authorized. Required: {', '.join(allowed_roles)}"
            )
        return current_user
    return role_checker


def require_admin_user(current_user: User = Depends(get_current_user)) -> User:
    """Strictly restricts access to the designated admin email akhtarrakeeb52@gmail.com."""
    if current_user.email.strip().lower() != ADMIN_EMAIL.lower():
        raise ForbiddenException("Administrator access restricted strictly to akhtarrakeeb52@gmail.com.")
    return current_user


def require_premium_user(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> User:
    """Enforces active premium subscription (Monthly ₹49 or Annual ₹499) or admin VIP bypass."""
    if current_user.email.strip().lower() == ADMIN_EMAIL.lower():
        return current_user

    # Explicit real-time expiration gate
    now_utc = datetime.now(timezone.utc)
    if getattr(current_user, "subscription_valid_until", None):
        v_dt = current_user.subscription_valid_until
        if v_dt.tzinfo is None:
            v_dt = v_dt.replace(tzinfo=timezone.utc)
        if now_utc > v_dt:
            current_user.is_premium = False
            db.commit()
            db.refresh(current_user)
            try:
                from app.services.auth_service import AuthService
                AuthService._save_backup_user(current_user)
            except Exception:
                pass
            raise ForbiddenException(
                "Your Employ.AI PRO subscription has expired. Please renew your Monthly (₹49) or Annual (₹499) plan to continue."
            )

    if not current_user.is_premium:
        raise ForbiddenException(
            "Premium subscription required (₹49/month or ₹499/year). Please subscribe to Employ.AI PRO to unlock this section."
        )
    return current_user

