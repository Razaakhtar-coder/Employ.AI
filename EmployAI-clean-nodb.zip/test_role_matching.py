import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.services.job_matching_service import JobMatchingService


def test_software_resume_against_mbbs_and_nursing_jobs():
    """
    A software engineer resume must evaluate to exactly 0.0% match against MBBS / Medicine and Nursing jobs.
    """
    sw_ctx = {
        "skills": {"python", "fastapi", "react", "postgresql", "docker", "git", "data structures & algorithms", "typescript"},
        "domain": "Computer Science",
        "department": "Computer Science & Engineering",
        "grad_year": 2025,
        "ats_score": 88.0,
        "cgpa": 8.5,
        "has_resume": True
    }

    # 1. Evaluate against MBBS Doctor role
    score_mbbs, breakdown_mbbs, matched_mbbs, missing_mbbs, meta_mbbs = JobMatchingService.compute_match(
        student_ctx=sw_ctx,
        job_title="Resident Medical Officer (MBBS)",
        job_domain="Healthcare & Medicine",
        job_exp_level="entry",
        required_skills=["Clinical Diagnostics", "Patient Treatment", "Emergency Trauma Care", "Radiology Interpretation", "Medical Ethics"]
    )

    print(f"CS vs MBBS Doctor Match Score: {score_mbbs}%")
    assert score_mbbs == 0.0, f"Expected 0.0% match for CS vs MBBS, got {score_mbbs}%"
    assert len(matched_mbbs) == 0
    assert len(missing_mbbs) == 5

    # 2. Evaluate against Nursing role
    score_nurse, breakdown_nurse, matched_nurse, missing_nurse, meta_nurse = JobMatchingService.compute_match(
        student_ctx=sw_ctx,
        job_title="Clinical ICU Staff Nurse",
        job_domain="Healthcare & Medicine",
        job_exp_level="entry",
        required_skills=["Patient Bedside Care", "ICU Hemodynamic Monitoring", "Vital Signs Assessment", "5 Rights Medication", "Wound Dressing"]
    )

    print(f"CS vs Nursing Match Score: {score_nurse}%")
    assert score_nurse == 0.0, f"Expected 0.0% match for CS vs Nursing, got {score_nurse}%"
    assert len(matched_nurse) == 0
    assert len(missing_nurse) == 5


def test_software_resume_against_civil_and_mechanical():
    """
    A software engineer resume with only CS skills must evaluate to 0.0% match against Civil Engineering jobs.
    """
    sw_ctx = {
        "skills": {"python", "fastapi", "react", "postgresql", "docker", "git", "typescript"},
        "domain": "Computer Science",
        "department": "Computer Science & Engineering",
        "grad_year": 2025,
        "ats_score": 85.0,
        "cgpa": 8.5,
        "has_resume": True
    }

    # Civil Engineering role
    score_civil, breakdown_civil, matched_civil, missing_civil, _ = JobMatchingService.compute_match(
        student_ctx=sw_ctx,
        job_title="Structural Design Engineer (STAAD.Pro)",
        job_domain="Civil",
        job_exp_level="entry",
        required_skills=["STAAD.Pro", "Revit BIM", "RCC Design (IS 456)", "Geotechnical Soil Mechanics", "Quantity Surveying & BOQ"]
    )

    print(f"CS vs Civil Engineer Match Score: {score_civil}%")
    assert score_civil == 0.0, f"Expected 0.0% match for CS vs Civil, got {score_civil}%"
    assert len(matched_civil) == 0


def test_software_resume_against_software_role():
    """
    A software engineer resume matching technical requirements must evaluate to a high match score (> 80%).
    """
    sw_ctx = {
        "skills": {"python", "fastapi", "react", "postgresql", "docker", "git", "data structures & algorithms"},
        "domain": "Computer Science",
        "department": "Computer Science & Engineering",
        "grad_year": 2025,
        "ats_score": 90.0,
        "cgpa": 8.8,
        "has_resume": True
    }

    score_sw, breakdown_sw, matched_sw, missing_sw, _ = JobMatchingService.compute_match(
        student_ctx=sw_ctx,
        job_title="Full Stack Software Engineer",
        job_domain="Computer Science",
        job_exp_level="entry",
        required_skills=["Python", "FastAPI", "React", "PostgreSQL", "Docker", "Git"]
    )

    print(f"CS vs Full Stack Software Engineer Match Score: {score_sw}%")
    assert score_sw >= 80.0, f"Expected >= 80.0% match for CS vs Software Engineer, got {score_sw}%"
    assert len(matched_sw) == 6
    assert len(missing_sw) == 0


def test_civil_resume_against_mbbs_vs_civil_role():
    """
    A Civil Engineer resume must evaluate to 0.0% match for MBBS, and high match for Civil.
    """
    civil_ctx = {
        "skills": {"staad.pro", "revit", "autocad", "rcc design", "geotechnical engineering", "quantity surveying"},
        "domain": "Civil",
        "department": "Civil Engineering",
        "grad_year": 2025,
        "ats_score": 85.0,
        "cgpa": 8.4,
        "has_resume": True
    }

    # 1. Civil vs MBBS -> 0.0%
    score_mbbs, _, matched_mbbs, _, _ = JobMatchingService.compute_match(
        student_ctx=civil_ctx,
        job_title="Resident Medical Officer (MBBS)",
        job_domain="Healthcare & Medicine",
        job_exp_level="entry",
        required_skills=["Clinical Diagnostics", "Patient Treatment", "Emergency Trauma Care"]
    )
    assert score_mbbs == 0.0, f"Expected Civil vs MBBS 0.0%, got {score_mbbs}%"
    assert len(matched_mbbs) == 0

    # 2. Civil vs Civil -> High match
    score_civ, _, matched_civ, _, _ = JobMatchingService.compute_match(
        student_ctx=civil_ctx,
        job_title="Structural Engineer",
        job_domain="Civil",
        job_exp_level="entry",
        required_skills=["STAAD.Pro", "Revit", "RCC Design", "AutoCAD"]
    )
    print(f"Civil vs Structural Engineer Match Score: {score_civ}%")
    assert score_civ >= 75.0, f"Expected Civil vs Structural Engineer >= 75.0%, got {score_civ}%"
    assert len(matched_civ) == 4


if __name__ == "__main__":
    test_software_resume_against_mbbs_and_nursing_jobs()
    test_software_resume_against_civil_and_mechanical()
    test_software_resume_against_software_role()
    test_civil_resume_against_mbbs_vs_civil_role()
    print("[SUCCESS] All Role and Job Matching tests passed successfully!")
