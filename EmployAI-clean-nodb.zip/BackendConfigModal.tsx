import React, { useState, useEffect } from 'react';
import { 
  getApiBaseUrl, setCustomApiUrl, checkBackendHealth, 
  CLOUD_BACKEND_URL, LOCAL_BACKEND_URL,
  type HealthCheckResult 
} from '../services/api';
import { 
  Server, WifiOff, RefreshCw, Check, X, 
  Globe, Zap
} from 'lucide-react';

interface BackendConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnectionSuccess?: () => void;
}

export const BackendConfigModal: React.FC<BackendConfigModalProps> = ({ 
  isOpen, 
  onClose,
  onConnectionSuccess 
}) => {
  const [activeUrl, setActiveUrl] = useState<string>('');
  const [customInput, setCustomInput] = useState<string>('');
  const [isTesting, setIsTesting] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<HealthCheckResult | null>(null);
  const [saveNotice, setSaveNotice] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      const current = getApiBaseUrl();
      setActiveUrl(current);
      setCustomInput(current.startsWith('http') ? current : '');
      setTestResult(null);
      setSaveNotice(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleTestUrl = async (urlToTest: string) => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await checkBackendHealth(urlToTest);
      setTestResult(res);
      if (res.online && onConnectionSuccess) {
        onConnectionSuccess();
      }
    } catch {
      setTestResult({
        online: false,
        message: 'Network request failed. Verify URL and CORS settings.'
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleApplyPreset = async (target: string) => {
    setCustomApiUrl(target);
    setActiveUrl(target);
    setCustomInput(target);
    setSaveNotice(`Connected to: ${target}`);
    setTimeout(() => setSaveNotice(null), 3000);
    await handleTestUrl(target);
  };

  const handleApplyCustom = async () => {
    if (!customInput.trim()) {
      setCustomApiUrl(null);
      const resetted = getApiBaseUrl();
      setActiveUrl(resetted);
      setSaveNotice('Reset to default relative API path (/api/v1)');
      setTimeout(() => setSaveNotice(null), 3000);
      await handleTestUrl(resetted);
      return;
    }
    const clean = customInput.trim();
    setCustomApiUrl(clean);
    setActiveUrl(clean);
    setSaveNotice(`Saved custom backend: ${clean}`);
    setTimeout(() => setSaveNotice(null), 3000);
    await handleTestUrl(clean);
  };

  return (
    <div 
      className="no-print"
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 1200,
        backgroundColor: 'var(--modal-backdrop, rgba(15, 23, 42, 0.75))',
        backdropFilter: 'blur(8px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1rem',
        animation: 'fadeIn 0.2s ease-out'
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        className="glass-card"
        style={{
          width: '100%',
          maxWidth: '560px',
          background: 'var(--bg-modal, #ffffff)',
          border: '1px solid var(--border-glass, #e2e8f0)',
          borderRadius: 'var(--radius-lg, 16px)',
          boxShadow: 'var(--shadow-modal, 0 20px 40px rgba(0,0,0,0.3))',
          padding: '1.75rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '1.25rem',
          maxHeight: '90vh',
          overflowY: 'auto'
        }}
      >
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div 
              style={{
                width: '38px',
                height: '38px',
                borderRadius: '10px',
                background: 'rgba(6, 182, 212, 0.15)',
                color: 'var(--accent-cyan, #0284c7)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}
            >
              <Server size={20} />
            </div>
            <div>
              <h3 style={{ margin: 0, fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                Backend API Connection
              </h3>
              <p style={{ margin: '0.15rem 0 0 0', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                Configure live server endpoint for mobile & desktop production access.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              color: 'var(--text-muted)',
              cursor: 'pointer',
              padding: '0.25rem',
              borderRadius: '6px'
            }}
            title="Close modal"
          >
            <X size={20} />
          </button>
        </div>

        {/* Current Active Status Pill */}
        <div 
          style={{
            padding: '0.75rem 1rem',
            borderRadius: '10px',
            background: 'var(--bg-inset, rgba(0, 0, 0, 0.04))',
            border: '1px solid var(--border-subtle, #e2e8f0)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '0.75rem',
            flexWrap: 'wrap'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', minWidth: 0 }}>
            <div 
              style={{
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                backgroundColor: testResult?.online ? '#10b981' : testResult ? '#ef4444' : '#38bdf8'
              }} 
            />
            <div style={{ minWidth: 0 }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block' }}>
                Active Base Endpoint:
              </span>
              <span 
                style={{ 
                  fontSize: '0.825rem', 
                  fontWeight: 700, 
                  color: 'var(--text-primary)',
                  wordBreak: 'break-all',
                  fontFamily: 'var(--font-mono, monospace)'
                }}
              >
                {activeUrl || '/api/v1 (relative)'}
              </span>
            </div>
          </div>

          <button
            onClick={() => handleTestUrl(activeUrl)}
            disabled={isTesting}
            className="btn btn-secondary btn-sm"
            style={{ fontSize: '0.75rem', padding: '0.35rem 0.65rem' }}
          >
            <RefreshCw size={12} className={isTesting ? 'animate-spin' : ''} />
            {isTesting ? 'Pinging...' : 'Ping Test'}
          </button>
        </div>

        {/* Test Result Feedback */}
        {testResult && (
          <div 
            className={`modern-alert ${testResult.online ? 'alert-info' : 'alert-error'}`}
            style={{ fontSize: '0.8rem', padding: '0.65rem 0.9rem' }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              {testResult.online ? <Check size={16} color="#10b981" /> : <WifiOff size={16} />}
              <span>
                {testResult.online 
                  ? `✓ Connected successfully! Version: ${testResult.version || '1.0.0'}`
                  : testResult.message || 'Server is not responding. Check URL.'
                }
              </span>
            </div>
          </div>
        )}

        {saveNotice && (
          <div 
            style={{
              padding: '0.5rem 0.85rem',
              borderRadius: '8px',
              background: 'rgba(16, 185, 129, 0.12)',
              border: '1px solid rgba(16, 185, 129, 0.3)',
              color: '#059669',
              fontSize: '0.78rem',
              fontWeight: 600
            }}
          >
            ✓ {saveNotice}
          </div>
        )}

        {/* One-Click Presets */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          <span style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-secondary)' }}>
            1-Click Connection Presets:
          </span>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '0.65rem' }}>
            {/* Cloud Render Preset */}
            <button
              onClick={() => handleApplyPreset(CLOUD_BACKEND_URL)}
              className="btn btn-secondary"
              style={{
                textAlign: 'left',
                padding: '0.65rem 0.85rem',
                borderRadius: '10px',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.2rem',
                border: activeUrl === CLOUD_BACKEND_URL ? '1px solid var(--accent-cyan)' : undefined,
                background: activeUrl === CLOUD_BACKEND_URL ? 'rgba(6, 182, 212, 0.1)' : undefined
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
                <span style={{ fontSize: '0.825rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                  <Globe size={13} color="var(--accent-cyan)" /> Cloud (Render)
                </span>
                {activeUrl === CLOUD_BACKEND_URL && <Check size={13} color="var(--accent-cyan)" />}
              </div>
              <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                Global High-Availability Backend
              </span>
            </button>

            {/* Localhost Preset */}
            <button
              onClick={() => handleApplyPreset(LOCAL_BACKEND_URL)}
              className="btn btn-secondary"
              style={{
                textAlign: 'left',
                padding: '0.65rem 0.85rem',
                borderRadius: '10px',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.2rem',
                border: activeUrl === LOCAL_BACKEND_URL ? '1px solid var(--accent-cyan)' : undefined,
                background: activeUrl === LOCAL_BACKEND_URL ? 'rgba(6, 182, 212, 0.1)' : undefined
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
                <span style={{ fontSize: '0.825rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                  <Zap size={13} color="#f59e0b" /> Local Python Server
                </span>
                {activeUrl === LOCAL_BACKEND_URL && <Check size={13} color="var(--accent-cyan)" />}
              </div>
              <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                127.0.0.1:8000 (Local Terminal)
              </span>
            </button>
          </div>
        </div>

        {/* Custom URL Input */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          <label style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-secondary)' }}>
            Custom Backend Domain / URL:
          </label>
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            <input
              type="text"
              placeholder="e.g. https://api.yourdomain.com/api/v1"
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              className="portal-input"
              style={{ flex: '1 1 240px' }}
            />
            <button
              onClick={handleApplyCustom}
              className="btn btn-primary"
              style={{ padding: '0.5rem 1rem', fontSize: '0.8rem', whiteSpace: 'nowrap' }}
            >
              Save & Connect
            </button>
          </div>
          <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>
            Leave blank and click 'Save & Connect' to reset to relative /api/v1 path.
          </span>
        </div>

        {/* Footer Guidance */}
        <div 
          style={{
            fontSize: '0.74rem',
            color: 'var(--text-muted)',
            lineHeight: 1.45,
            borderTop: '1px solid var(--border-subtle)',
            paddingTop: '0.85rem'
          }}
        >
          💡 <strong>Render Cold Starts:</strong> On the free plan, Render spins down servers after 15 min of inactivity. The first request takes ~30-40 seconds to warm up. Once online, subsequent requests respond in &lt;100ms.
        </div>
      </div>
    </div>
  );
};
