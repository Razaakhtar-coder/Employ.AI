from typing import List, Optional, Dict, Any, Tuple
from sqlalchemy.orm import Session
from app.models.taxonomy import Skill, SkillCategory, SkillAlias, Syllabus
from app.schemas.taxonomy import SkillCreate, SyllabusIngestRequest, SyllabusIngestResponse
from app.services.ai_service import AIService


class TaxonomyService:
    @staticmethod
    def get_all_categories(db: Session) -> List[SkillCategory]:
        """Fetch all skill categories."""
        return db.query(SkillCategory).all()

    @staticmethod
    def get_skills_by_domain(db: Session, domain: Optional[str] = None) -> List[Skill]:
        """Fetch skills filtered by domain or all."""
        query = db.query(Skill)
        if domain and domain.lower() != "all":
            query = query.filter(Skill.domain.ilike(f"%{domain}%"))
        return query.all()

    @staticmethod
    def normalize_skill_name(db: Session, raw_name: Any, domain_hint: Optional[str] = None) -> Optional[Skill]:
        """Resolve a raw skill string, dict, or alias into its canonical Skill entity."""
        if raw_name is None:
            return None
        if isinstance(raw_name, dict):
            raw_name = raw_name.get("name") or raw_name.get("skill") or raw_name.get("canonical_name") or ""
        if not isinstance(raw_name, str):
            raw_name = str(raw_name)
        cleaned = raw_name.strip()
        if not cleaned:
            return None

        # 1. Exact match on canonical name
        skill = db.query(Skill).filter(Skill.canonical_name.ilike(cleaned)).first()
        if skill:
            return skill

        # 2. Exact match on alias
        alias = db.query(SkillAlias).filter(SkillAlias.alias.ilike(cleaned)).first()
        if alias and alias.skill:
            return alias.skill

        # 3. Substring fuzzy match
        skill_sub = db.query(Skill).filter(Skill.canonical_name.ilike(f"%{cleaned}%")).first()
        if skill_sub:
            return skill_sub

        return None

    @staticmethod
    def create_skill(db: Session, data: SkillCreate) -> Skill:
        """Create a new canonical skill with associated aliases."""
        slug = data.canonical_name.lower().replace(" ", "-").replace("&", "and").replace(".", "").replace("/", "-")
        skill = Skill(
            canonical_name=data.canonical_name,
            slug=slug,
            domain=data.domain,
            category_id=data.category_id,
            description=data.description,
            is_emerging=data.is_emerging
        )
        db.add(skill)
        db.flush()

        for alias_str in data.aliases:
            if alias_str.strip():
                db.add(SkillAlias(skill_id=skill.id, alias=alias_str.strip(), domain_hint=data.domain))

        db.commit()
        db.refresh(skill)
        return skill

    @staticmethod
    def ingest_syllabus(db: Session, request: SyllabusIngestRequest, user_id: Optional[str] = None) -> SyllabusIngestResponse:
        """Analyze course syllabus with AI and map competencies into the universal taxonomy."""
        ai_res = AIService.analyze_syllabus(request.raw_text, request.department)
        extracted_skills = ai_res.get("extracted_skills", [])

        mapped_canonical = []
        newly_discovered = []

        for raw_s in extracted_skills:
            normalized = TaxonomyService.normalize_skill_name(db, raw_s, domain_hint=request.department)
            if normalized:
                mapped_canonical.append({
                    "raw_term": raw_s,
                    "canonical_name": normalized.canonical_name,
                    "domain": normalized.domain
                })
            else:
                newly_discovered.append(raw_s)

        syllabus_record = Syllabus(
            department=request.department,
            course_code=request.course_code,
            course_name=request.course_name,
            academic_year=request.academic_year,
            raw_text=request.raw_text,
            mapped_skills_json={
                "extracted_skills": extracted_skills,
                "mapped": mapped_canonical,
                "newly_discovered": newly_discovered,
                "alignment_score": ai_res.get("industry_alignment_score", 80.0)
            },
            uploaded_by_user_id=user_id
        )
        db.add(syllabus_record)
        db.commit()
        db.refresh(syllabus_record)

        return SyllabusIngestResponse(
            id=syllabus_record.id,
            department=syllabus_record.department,
            course_code=syllabus_record.course_code,
            course_name=syllabus_record.course_name,
            extracted_skills=extracted_skills,
            mapped_canonical_skills=mapped_canonical,
            newly_discovered_skills=newly_discovered
        )
