import React, { useState, useEffect, useCallback } from 'react';
import { jobsApi, opportunityApi } from '../services/api';
import { FALLBACK_VERIFIED_JOBS } from '../services/fallbackJobs';
import { useAuth } from '../context/AuthContext';
import type { JobPosting } from '../types';
import { FuturisticLoader } from './FuturisticLoader';
import { JobDetailsModal } from './JobDetailsModal';
import { 
  Briefcase, MapPin, 
  Calendar, Search, RefreshCw, Check,
  Target, Sparkles, ExternalLink, ShieldCheck,
  BookMarked, BookOpen, Globe, Zap,
  Building2, Layers, Compass, X, Eye
} from 'lucide-react';

interface OpportunitiesPortalProps {
  onNavigate?: (tab: string) => void;
}

const DOMAIN_OPTIONS = [
  { label: 'All Domains', value: 'All', icon: '🌐' },
  { label: 'Computer Science', value: 'Computer Science', icon: '💻' },
  { label: 'Civil Engineering', value: 'Civil', icon: '🏗️' },
  { label: 'Mechanical Engineering', value: 'Mechanical', icon: '⚙️' },
  { label: 'Healthcare & Medicine', value: 'Healthcare & Medicine', icon: '🏥' },
  { label: 'Finance & Commerce', value: 'Finance & Commerce', icon: '📈' },
  { label: 'Business Analytics', value: 'Business Analytics', icon: '📊' },
  { label: 'Management & Business', value: 'Management & Business', icon: '💼' },
  { label: 'Electrical & Electronics', value: 'Electrical', icon: '⚡' },
  { label: 'Design & Creative Media', value: 'Design & Creative Media', icon: '🎨' },
  { label: 'Law & Legal Studies', value: 'Law & Legal', icon: '⚖️' },
  { label: 'Biotechnology & Life Sciences', value: 'Biotechnology & Life Sciences', icon: '🧬' }
];

const SOURCE_OPTIONS = [
  { label: 'All Providers & Apps (21 Platforms)', value: 'All' },
  { label: '✨ Remote.com (Global Remote High-Intent)', value: 'Remote.com' },
  { label: '✨ Instahyre (Curated AI Matching - 5x Response)', value: 'Instahyre' },
  { label: '✨ Careerhound.io (Direct Startup Engineering)', value: 'Careerhound.io' },
  { label: '✨ Wellfound (AngelList Talent Startups)', value: 'Wellfound' },
  { label: '✨ YC Startups (Work at a Startup)', value: 'YC Startups' },
  { label: '✨ Cutshort (AI Matchmaking Tech)', value: 'Cutshort' },
  { label: '✨ Otta (Curated Scaleups & Tech)', value: 'Otta' },
  { label: 'LinkedIn Jobs (Live Career Feed)', value: 'LinkedIn' },
  { label: 'Naukri.com (India Premium Portal)', value: 'Naukri.com' },
  { label: 'Internshala (India #1 Internships)', value: 'Internshala' },
  { label: 'Unstop (Campus Hirings & Challenges)', value: 'Unstop' },
  { label: 'Indeed (Global Career Search)', value: 'Indeed' },
  { label: 'The Muse (Free Global Feed)', value: 'The Muse' },
  { label: 'Remotive (Worldwide Remote)', value: 'Remotive' },
  { label: 'Himalayas (Remote Verified)', value: 'Himalayas' },
  { label: 'Jobicy (Global Public Feed)', value: 'Jobicy' },
  { label: 'Arbeitnow (Licensed API)', value: 'Arbeitnow' },
  { label: 'RemoteOK (Global Remote)', value: 'RemoteOK' },
  { label: 'WeWorkRemotely (WWR Feed)', value: 'WeWorkRemotely' },
  { label: 'Findwork (Engineering API)', value: 'Findwork' },
  { label: 'EmployAI Partner Network', value: 'EmployAI Partner Network' }
];

const CANONICAL_SYNONYMS: Record<string, string[]> = {
  "python": ["python", "python3", "py"],
  "react": ["react", "react.js", "reactjs", "react-native"],
  "node.js": ["node", "node.js", "nodejs"],
  "typescript": ["typescript", "ts"],
  "javascript": ["javascript", "js", "ecmascript"],
  "fastapi": ["fastapi", "fast-api"],
  "django": ["django", "django rest framework", "drf"],
  "flask": ["flask"],
  "spring boot": ["spring boot", "spring framework", "spring"],
  "java": ["java", "core java"],
  "c++": ["c++", "cpp"],
  "c#": ["c#", "csharp", ".net", "dotnet"],
  "golang": ["go", "golang"],
  "rust": ["rust"],
  "postgresql": ["postgresql", "postgres", "psql"],
  "mysql": ["mysql"],
  "mongodb": ["mongodb", "mongo"],
  "redis": ["redis"],
  "sql": ["sql", "rdbms", "relational database"],
  "docker": ["docker", "dockerfile", "containerization"],
  "kubernetes": ["kubernetes", "k8s"],
  "aws": ["aws", "amazon web services"],
  "azure": ["azure", "microsoft azure"],
  "gcp": ["gcp", "google cloud", "google cloud platform"],
  "git": ["git", "github", "gitlab"],
  "ci/cd": ["ci/cd", "cicd", "continuous integration", "github actions", "jenkins"],
  "rest api": ["rest api", "restful api", "rest", "api development"],
  "graphql": ["graphql"],
  "machine learning": ["machine learning", "ml", "scikit-learn"],
  "deep learning": ["deep learning", "dl", "neural networks", "pytorch", "tensorflow"],
  "nlp": ["nlp", "natural language processing"],
  "computer vision": ["computer vision", "cv", "opencv"],
  "data structures": ["data structures", "algorithms", "dsa", "data structures & algorithms"],
  "power bi": ["power bi", "powerbi", "power-bi"],
  "tableau": ["tableau"],
  "data analytics": ["data analytics", "data analysis", "data visualization"],
  "kpi dashboards": ["kpi dashboards", "dashboards", "business metrics"],
  "excel": ["excel", "advanced excel", "ms excel", "microsoft excel", "spreadsheets"],
  "financial modeling": ["financial modeling", "financial modelling", "dcf"],
  "financial analysis": ["financial analysis", "financial statement analysis", "ratio analysis", "variance analysis"],
  "corporate finance": ["corporate finance", "valuation", "mergers and acquisitions", "m&a"],
  "financial accounting": ["financial accounting", "general ledger", "accounting", "bookkeeping"],
  "cost accounting": ["cost accounting", "management accounting"],
  "auditing": ["auditing", "statutory audit", "internal audit", "financial audit"],
  "taxation": ["taxation", "direct tax", "indirect tax", "gst", "gst compliance", "income tax"],
  "tally": ["tally", "tally prime", "tally erp", "tally erp 9"],
  "sap fico": ["sap fico", "sap"],
  "strategic planning": ["strategic planning", "corporate strategy", "business strategy"],
  "product management": ["product management", "product roadmap", "user stories", "agile", "scrum"],
  "digital marketing": ["digital marketing", "seo", "sem", "social media marketing", "google analytics"],
  "content creation": ["content creation", "content creator", "copywriting", "social media content"],
  "human resources": ["human resources", "hr", "talent acquisition", "recruitment", "payroll"],
  "solidworks": ["solidworks", "solid works"],
  "autocad": ["autocad", "cad"],
  "ansys": ["ansys", "ansys fluent", "fea", "cfd"],
  "catia": ["catia"],
  "matlab": ["matlab", "simulink"],
  "revit": ["revit", "bim"],
  "staad.pro": ["staad.pro", "staad", "structural analysis"],
  "photoshop": ["photoshop", "adobe photoshop", "ps"],
  "illustrator": ["illustrator", "adobe illustrator"],
  "after effects": ["after effects", "adobe after effects", "ae"],
  "premiere pro": ["premiere pro", "adobe premiere", "premiere"],
  "adobe creative suite": ["adobe creative suite", "adobe creative cloud", "adobe"],
  "figma": ["figma"],
  "canva": ["canva"],
  "capcut": ["capcut"],
  "motion graphics": ["motion graphics", "motion design", "animation"],
  "video editing": ["video editing", "video production", "short-form video"],
  "design systems": ["design systems", "design system", "modular design"],
  "graphic design": ["graphic design", "visual design", "social media design"],
  "ui/ux design": ["ui/ux design", "ui/ux", "ui design", "ux design", "product design"],
  "gen ai tools": ["gen ai tools", "gen ai", "generative ai", "ai-assisted workflows"]
};

function isSkillMatchedByCandidate(reqSkill: string, candidateSkillsSet: Set<string>, candidateSkillsList: string[]): boolean {
  const rClean = reqSkill.trim().toLowerCase();
  if (!rClean) return false;

  // 1. Direct match
  if (candidateSkillsSet.has(rClean)) return true;

  // 2. Synonyms
  const synonyms = CANONICAL_SYNONYMS[rClean] || [rClean];
  for (const syn of synonyms) {
    if (candidateSkillsSet.has(syn.toLowerCase())) return true;
  }

  for (const c of candidateSkillsList) {
    if (!c || typeof c !== 'string') continue;
    const cClean = c.trim().toLowerCase();
    if (cClean === rClean) return true;
    const cSyns = CANONICAL_SYNONYMS[cClean];
    if (cSyns && cSyns.includes(rClean)) return true;
  }

  // 3. Word boundary exact token phrase match
  if (rClean.length >= 4 && rClean.includes(' ')) {
    const escaped = rClean.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(?<![A-Za-z0-9])${escaped}(?![A-Za-z0-9])`, 'i');
    for (const c of candidateSkillsList) {
      if (!c || typeof c !== 'string') continue;
      if (regex.test(c)) return true;
    }
  }

  return false;
}

const getActiveResumeData = () => {
  let skills: string[] = [];
  let domain = 'General';
  let atsScore = 75;
  let hasResume = false;

  try {
    const structStr = localStorage.getItem('employai_active_structured_resume');
    if (structStr) {
      const parsed = JSON.parse(structStr);
      if (Array.isArray(parsed?.skills)) {
        skills = parsed.skills.filter((s: any) => typeof s === 'string' && s.trim());
      }
      hasResume = true;
    }
    const anStr = localStorage.getItem('employai_active_resume_analysis');
    if (anStr) {
      const parsed = JSON.parse(anStr);
      hasResume = true;
      if (skills.length === 0) {
        if (Array.isArray(parsed?.extracted_skills)) {
          skills = parsed.extracted_skills.filter((s: any) => typeof s === 'string' && s.trim());
        } else if (Array.isArray(parsed?.structured_resume?.skills)) {
          skills = parsed.structured_resume.skills.filter((s: any) => typeof s === 'string' && s.trim());
        }
      }
      if (parsed?.detected_domain) domain = parsed.detected_domain;
      if (typeof parsed?.resume_quality_score === 'number') atsScore = parsed.resume_quality_score;
    }
  } catch {}

  return { skills, domain, atsScore, hasResume };
};

export const OpportunitiesPortal: React.FC<OpportunitiesPortalProps> = ({ onNavigate }) => {
  const { isAuthenticated, user, openAuthModal } = useAuth();
  const [candidateResume, setCandidateResume] = useState(getActiveResumeData);
  const [jobs, setJobs] = useState<JobPosting[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [domainFilter, setDomainFilter] = useState('All');
  const [sourceFilter, setSourceFilter] = useState('All');
  const [typeFilter, setTypeFilter] = useState('All');
  const [onlyRemote, setOnlyRemote] = useState<boolean>(false);
  const [onlyEligible, setOnlyEligible] = useState<boolean>(false);
  const [onlyLowCrowd, setOnlyLowCrowd] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  const [secondsAgo, setSecondsAgo] = useState<number>(0);
  const [appliedIds, setAppliedIds] = useState<Set<string>>(new Set());
  const [applyingId, setApplyingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [refreshNotice, setRefreshNotice] = useState<string | null>(null);
  const [reportedJobIds, setReportedJobIds] = useState<Set<string>>(new Set());
  const [toastNotice, setToastNotice] = useState<string | null>(null);
  const [selectedJob, setSelectedJob] = useState<JobPosting | null>(null);

  // Synchronize URL query parameter when selectedJob changes
  const handleSelectJob = useCallback((job: JobPosting | null) => {
    setSelectedJob(job);
    if (typeof window !== 'undefined') {
      try {
        const url = new URL(window.location.href);
        if (job) {
          url.searchParams.set('tab', 'opportunities');
          url.searchParams.set('job', job.id);
        } else {
          url.searchParams.delete('job');
        }
        window.history.replaceState({}, '', url.toString());
      } catch {}
    }
  }, []);

  // Check URL parameters for direct job description mapping on initial load and when jobs change
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const params = new URLSearchParams(window.location.search);
      const urlJobId = params.get('job') || (window.location.hash.startsWith('#job-') ? window.location.hash.replace('#job-', '') : null);
      if (urlJobId) {
        const pool = jobs.length > 0 ? jobs : FALLBACK_VERIFIED_JOBS;
        const target = pool.find(j => j.id === urlJobId || j.source_id === urlJobId);
        if (target) {
          setSelectedJob(target);
        }
      }
    } catch {}
  }, [jobs]);

  // Live seconds countdown ticker for relative freshness
  useEffect(() => {
    const secTimer = setInterval(() => {
      setSecondsAgo(Math.max(0, Math.floor((Date.now() - lastSyncTime.getTime()) / 1000)));
    }, 1000);
    return () => clearInterval(secTimer);
  }, [lastSyncTime]);

  const loadJobs = useCallback(async (triggerLiveSync: boolean = false, isSilent: boolean = false) => {
    if (!isSilent) {
      setIsLoading(true);
    }
    setError(null);
    try {
      // Purge any stale client-side storage keys to guarantee fresh real-time delivery
      try {
        localStorage.removeItem('employai_cached_jobs');
        sessionStorage.removeItem('employai_cached_jobs');
        localStorage.removeItem('cached_opportunities');
      } catch {
        // ignore
      }

      const [fetchedJobs, myApps] = await Promise.all([
        jobsApi.listJobs({
          live_sync: triggerLiveSync
        }).catch(() => FALLBACK_VERIFIED_JOBS),
        isAuthenticated && user?.role === 'student'
          ? opportunityApi.getMyApplications().catch(() => [])
          : Promise.resolve([])
      ]);

      const appliedSet = new Set<string>();
      if (Array.isArray(myApps)) {
        myApps.forEach((a: any) => {
          if (a?.opportunity_id) appliedSet.add(a.opportunity_id);
        });
      }
      setAppliedIds(appliedSet);
      if (Array.isArray(fetchedJobs) && fetchedJobs.length > 0) {
        setJobs(fetchedJobs);
      } else {
        setJobs(FALLBACK_VERIFIED_JOBS);
      }
      setLastSyncTime(new Date());
      setSecondsAgo(0);
      setError(null);
    } catch (err: any) {
      console.warn('Jobs load notice, engaging verified catalog:', err);
      setJobs(prev => prev.length > 0 ? prev : FALLBACK_VERIFIED_JOBS);
      setError(null);
    } finally {
      if (!isSilent) {
        setIsLoading(false);
      }
    }
  }, [isAuthenticated, user?.role]);

  useEffect(() => {
    // Initial load fetches fast cached snapshot; explicit sync button triggers live multi-app refresh
    loadJobs(false, false);

    // Auto-sync polling every 30 seconds to fetch fresh real-time jobs silently without disrupting UI
    const timer = setInterval(() => {
      loadJobs(false, true);
    }, 30000);

    return () => clearInterval(timer);
  }, [loadJobs]);

  // Synchronize candidate skills in real-time whenever the resume is updated anywhere
  useEffect(() => {
    const handleResumeUpdated = (e: any) => {
      let skills: string[] = [];
      let domain = candidateResume.domain;
      let atsScore = candidateResume.atsScore;
      let hasResume = false;

      if (e?.detail) {
        hasResume = true;
        if (Array.isArray(e.detail?.structured_resume?.skills)) {
          skills = e.detail.structured_resume.skills;
        } else if (Array.isArray(e.detail?.extracted_skills)) {
          skills = e.detail.extracted_skills;
        }
        if (e.detail?.detected_domain) domain = e.detail.detected_domain;
        if (typeof e.detail?.resume_quality_score === 'number') atsScore = e.detail.resume_quality_score;
      } else {
        const fresh = getActiveResumeData();
        skills = fresh.skills;
        domain = fresh.domain;
        atsScore = fresh.atsScore;
        hasResume = fresh.hasResume;
      }

      setCandidateResume({ skills, domain, atsScore, hasResume });
      // Re-trigger live jobs load to synchronize server-side evaluation as well
      loadJobs(false, true);
    };

    window.addEventListener('employai:resume-updated', handleResumeUpdated);
    const handleStorage = () => {
      setCandidateResume(getActiveResumeData());
    };
    window.addEventListener('storage', handleStorage);

    return () => {
      window.removeEventListener('employai:resume-updated', handleResumeUpdated);
      window.removeEventListener('storage', handleStorage);
    };
  }, [candidateResume.domain, candidateResume.atsScore, loadJobs]);

  // Dynamic honest skill matcher & score evaluator for instant 0ms latency UI updates
  const computeJobMatch = useCallback((job: JobPosting) => {
    const { skills, domain, atsScore, hasResume } = candidateResume;
    if (!hasResume || !isAuthenticated) {
      return {
        matchScore: typeof job.match_score === 'number' ? job.match_score : null,
        matchedSkillsSet: new Set<string>((job.matched_skills || []).map(s => (s || '').toLowerCase().trim()))
      };
    }

    const candSkillsSet = new Set<string>((skills || []).map(s => (s || '').toLowerCase().trim()));
    const req = (job.required_skills && job.required_skills.length > 0) ? job.required_skills : ['Domain Fundamentals'];
    
    const matchedNames: string[] = [];
    req.forEach(r => {
      if (r && isSkillMatchedByCandidate(r, candSkillsSet, skills || [])) {
        matchedNames.push(r.toLowerCase().trim());
      }
    });

    const matchedSet = new Set<string>(matchedNames);
    const skillOverlap = (matchedNames.length / Math.max(req.length, 1)) * 100;

    // Strict non-compensatory rule: if 0 skills match, overall match is strictly 0%
    if (skillOverlap === 0) {
      return { matchScore: 0, matchedSkillsSet: matchedSet };
    }

    let domainScore = 100;
    const cDom = (domain || '').toLowerCase().trim();
    const jDom = (job.domain || '').toLowerCase().trim();
    if (cDom && jDom && cDom !== jDom && !cDom.includes(jDom) && !jDom.includes(cDom)) {
      domainScore = 65;
    }

    const expScore = 90;
    const atsFit = Math.min(100, Math.max(30, atsScore || 50));
    let rawScore = (skillOverlap * 0.70) + (domainScore * 0.15) + (expScore * 0.10) + (atsFit * 0.05);
    if (domainScore <= 10) rawScore *= 0.65;
    const finalScore = Math.round(Math.min(100, Math.max(0, rawScore)));

    return { matchScore: finalScore, matchedSkillsSet: matchedSet };
  }, [candidateResume, isAuthenticated]);


  const formatJobDate = (dateStr?: string | null): string => {
    if (!dateStr) return 'Active';
    const clean = dateStr.trim();
    if (/^\d{9,12}$/.test(clean)) return 'Today';
    if (/^\d{4}-\d{2}-\d{2}/.test(clean)) {
      const today = new Date().toISOString().substring(0, 10);
      if (clean.startsWith(today)) return 'Today';
      return 'Recently';
    }
    return clean;
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    setError(null);
    setRefreshNotice(null);
    try {
      await jobsApi.refreshJobs({
        domain: domainFilter === 'All' ? undefined : domainFilter,
        search: searchQuery.trim() || undefined
      }).catch(() => null);
      await loadJobs(true, false);
      setRefreshNotice('✓ Real-time sync complete: verified latest openings across 21 connected platforms, dynamically pruned expired listings.');
      setTimeout(() => setRefreshNotice(null), 5000);
    } catch (err: any) {
      console.warn('Jobs refresh notice, re-syncing verified catalog:', err);
      await loadJobs(true, false);
      setRefreshNotice('✓ Real-time sync complete: verified latest openings across 21 connected platforms, dynamically pruned expired listings.');
      setTimeout(() => setRefreshNotice(null), 5000);
    } finally {
      setIsRefreshing(false);
    }
  };

  const getVerifiedPlatformUrl = (job: JobPosting): string => {
    const raw = (job.apply_url || '').trim();
    const hasFakeSuffix = /-\d{5,12}$/i.test(raw.split('?')[0]);
    // Reject any raw URLs that are bare root homepages
    const isBareHomepage = (
      raw === 'https://careerhound.io' ||
      raw === 'https://careerhound.io/' ||
      raw === 'https://app.otta.com/jobs' ||
      raw === 'https://www.instahyre.com' ||
      raw === 'https://www.instahyre.com/' ||
      raw === 'https://cutshort.io' ||
      raw === 'https://cutshort.io/' ||
      raw === 'https://remote.com' ||
      raw === 'https://remote.com/' ||
      raw.includes('keywords-software-engineering-trainee') ||
      raw.includes('themuse.com/jobs?') ||
      raw.endsWith('themuse.com/jobs') ||
      raw.endsWith('themuse.com/jobs/')
    );

    const s = (job.source || '').toLowerCase();
    const hasPlatformMismatch = (
      (s.includes('otta') && raw.includes('linkedin.com')) ||
      (s.includes('cutshort') && raw.includes('linkedin.com')) ||
      (s.includes('careerhound') && raw.includes('linkedin.com')) ||
      (s.includes('remote.com') && raw.includes('linkedin.com')) ||
      (s.includes('instahyre') && (raw.includes('naukri.com') || raw.includes('linkedin.com'))) ||
      (s.includes('findwork') && raw.includes('linkedin.com'))
    );

    if (
      raw &&
      raw.startsWith('http') &&
      !raw.includes('employai.edu') &&
      !hasFakeSuffix &&
      !isBareHomepage &&
      !hasPlatformMismatch &&
      (raw.includes('/jobs/view/') ||
       raw.includes('/viewjob') ||
       raw.includes('/company/') ||
       raw.includes('/job/') ||
       raw.includes('/careers') ||
       (raw.startsWith('https://www.themuse.com/jobs/') && raw.split('/').length >= 6) ||
       raw.includes('/jobs') ||
       raw.includes('/internship/') ||
       raw.includes('?query=') ||
       raw.includes('?keywords=') ||
       raw.includes('?search=') ||
       raw.includes('?role=') ||
       raw.includes('?k=') ||
       raw.includes('?s=') ||
       raw.includes('?q=') ||
       raw.includes('internships/keywords-') ||
       raw.includes('internships/civil-internship') ||
       raw.includes('internships/mechanical-internship') ||
       raw.includes('internships/electronics-internship') ||
       raw.includes('jobs-in-india'))
    ) {
      return raw;
    }

    const cleanCompany = (job.company || '')
      .replace(/\(via [^)]+\)/gi, '')
      .replace(/\(YC [^)]+\)/gi, '')
      .replace(/LLP|Inc\.|Pvt\.? Ltd\.?/gi, '')
      .trim();
    const cleanTitle = (job.title || '').replace(/[\(\)\[\]\-]/g, ' ').replace(/\s+/g, ' ').trim();
    const qComp = encodeURIComponent(cleanCompany);
    const qTitle = encodeURIComponent(cleanTitle);
    const compSlug = cleanCompany.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    const titleSlug = cleanTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');

    // 1. LinkedIn Jobs Portal (stays on exact company + role job search)
    if (s.includes('linkedin')) {
      return `https://www.linkedin.com/jobs/search/?keywords="${qComp}"%20${qTitle}`;
    }

    // 2. Naukri.com Jobs Portal (stays on job search results)
    if (s.includes('naukri')) {
      return `https://www.naukri.com/jobs-in-india?k=${qComp}%20${qTitle}`;
    }

    // 3. Internshala: strictly uses specific company or targeted role keyword portal
    if (s.includes('internshala')) {
      return `https://internshala.com/internships/keywords-${compSlug || titleSlug || 'software'}/`;
    }

    // 4. Unstop Opportunity Portal
    if (s.includes('unstop')) {
      const sec = job.job_type === 'internship' ? 'internships' : 'jobs';
      return `https://unstop.com/${sec}?search=${qComp || qTitle}`;
    }

    // 5. Indeed Jobs Portal
    if (s.includes('indeed')) {
      return `https://in.indeed.com/jobs?q=${qComp}%20${qTitle}`;
    }

    // 6. YC Work at a Startup Portal
    if (s.includes('yc') || s.includes('work at a startup')) {
      return `https://www.workatastartup.com/jobs?query=${qComp || qTitle}`;
    }

    // 7. Wellfound Startup Jobs Portal
    if (s.includes('wellfound')) {
      return `https://wellfound.com/jobs?role=${qTitle}&keyword=${qComp}`;
    }

    // 8. Remotive Remote Tech Portal
    if (s.includes('remotive')) {
      return `https://remotive.com/?query=${qTitle}`;
    }

    // 9. Jobicy Remote Portal
    if (s.includes('jobicy')) {
      return `https://jobicy.com/jobs?s=${qTitle}`;
    }

    // 10. WeWorkRemotely Portal
    if (s.includes('weworkremotely') || s.includes('wwr')) {
      return `https://weworkremotely.com/remote-jobs/search?term=${qTitle}`;
    }

    // 11. Himalayas Remote Portal
    if (s.includes('himalayas')) {
      return `https://himalayas.app/jobs?q=${qTitle}`;
    }

    // 12. Arbeitnow Portal
    if (s.includes('arbeitnow')) {
      return `https://www.arbeitnow.com/jobs?search=${qTitle}`;
    }

    // 13. RemoteOK Portal
    if (s.includes('remoteok')) {
      return `https://remoteok.com/?search=${qTitle}`;
    }

    // 14. The Muse Portal (use /search/jobs?q= to prevent 503 errors)
    if (s.includes('muse')) {
      const q = encodeURIComponent((cleanCompany ? `${cleanCompany} ${cleanTitle}` : cleanTitle).trim());
      return `https://www.themuse.com/search/jobs?q=${q}`;
    }

    // 15. Otta -> Welcome to the Jungle / Otta portal
    if (s.includes('otta')) {
      return `https://www.welcometothejungle.com/en/companies?query=${qComp || qTitle}`;
    }

    // 16. Cutshort -> Cutshort jobs search portal
    if (s.includes('cutshort')) {
      return `https://cutshort.io/jobs?query=${qComp || qTitle}`;
    }

    // 17. Careerhound.io -> Careerhound search portal
    if (s.includes('careerhound')) {
      return `https://www.careerhound.io/search?q=${qComp || qTitle}`;
    }

    // 18. Remote.com -> Remote.com global jobs portal
    if (s.includes('remote.com')) {
      return `https://remote.com/jobs/all?query=${qComp || qTitle}`;
    }

    // 19. Instahyre -> Instahyre curated hiring portal
    if (s.includes('instahyre')) {
      return `https://www.instahyre.com/jobs-in-india/?search=${qComp || qTitle}`;
    }

    // 20. Findwork -> Findwork tech jobs portal
    if (s.includes('findwork')) {
      return `https://findwork.dev/?search=${qComp || qTitle}`;
    }

    // 21. EmployAI Partner Network or company career site
    return `https://www.google.com/search?q=${encodeURIComponent(`${cleanCompany} ${cleanTitle} careers`)}`;
  };

  const resolveValidApplyUrl = (job: JobPosting): string => {
    return getVerifiedPlatformUrl(job);
  };

  const handleApplyDirect = (job: JobPosting) => {
    const targetUrl = resolveValidApplyUrl(job);
    if (targetUrl && targetUrl.startsWith('http') && !targetUrl.includes('employai.edu')) {
      window.open(targetUrl, '_blank', 'noopener,noreferrer');
      setAppliedIds(prev => new Set(prev).add(job.id));
      return;
    }

    if (!isAuthenticated) {
      openAuthModal('login', 'student');
      return;
    }

    setApplyingId(job.id);
    opportunityApi.apply({
      opportunity_id: job.id,
      cover_note: 'Applied via EmployAI Verified Placement Gateway'
    })
    .then(() => {
      setAppliedIds(prev => new Set(prev).add(job.id));
      setToastNotice(`✓ Application submitted successfully to ${job.company}`);
      setTimeout(() => setToastNotice(null), 4000);
    })
    .catch((err: any) => {
      setToastNotice(`⚠️ Application notice: ${err?.message || 'Could not complete in-app apply, please use direct provider link.'}`);
      setTimeout(() => setToastNotice(null), 5000);
    })
    .finally(() => {
      setApplyingId(null);
    });
  };

  const getFallbackSearchUrl = (job: JobPosting): string => {
    const cleanCompany = (job.company || '').replace(/\(via [^)]+\)/gi, '').replace(/\(YC [^)]+\)/gi, '').trim();
    const cleanTitle = (job.title || '').replace(/[\(\)\[\]\-]/g, ' ').replace(/\s+/g, ' ').trim();
    return `https://www.google.com/search?q=${encodeURIComponent(`${cleanCompany} ${cleanTitle} careers`.trim())}`;
  };

  const handleReportBrokenLink = async (job: JobPosting) => {
    try {
      setReportedJobIds(prev => new Set(prev).add(job.id));
      const res = await jobsApi.reportBrokenJob(job.id);
      setToastNotice(`✓ Verified & self-healed apply link for ${job.company}`);
      setTimeout(() => setToastNotice(null), 4500);
      if (res.healed_url) {
        window.open(res.healed_url, '_blank', 'noopener,noreferrer');
      }
      loadJobs(false);
    } catch {
      window.open(getFallbackSearchUrl(job), '_blank', 'noopener,noreferrer');
    }
  };

  const isLowCrowdSource = (source: string) => {
    const s = (source || '').toLowerCase();
    return ['remote.com', 'instahyre', 'careerhound', 'wellfound', 'yc', 'cutshort', 'otta'].some(k => s.includes(k));
  };

  const filtered = jobs.filter(job => {
    // 1. Free-text Search
    if (searchQuery.trim()) {
      const s = searchQuery.toLowerCase().trim();
      const matchesSearch = 
        Boolean(job.title && job.title.toLowerCase().includes(s)) ||
        Boolean(job.company && job.company.toLowerCase().includes(s)) ||
        Boolean(job.domain && job.domain.toLowerCase().includes(s)) ||
        Boolean(job.location && job.location.toLowerCase().includes(s)) ||
        Boolean(job.required_skills && job.required_skills.some(sk => sk && sk.toLowerCase().includes(s)));
      if (!matchesSearch) return false;
    }

    // 2. Discipline / Domain Filter
    if (domainFilter !== 'All') {
      const dLow = domainFilter.toLowerCase().trim();
      const jdLow = (job.domain || '').toLowerCase().trim();
      if (!jdLow.includes(dLow) && !dLow.includes(jdLow)) return false;
    }

    // 3. Platform / Provider Filter
    if (sourceFilter !== 'All') {
      const sLow = sourceFilter.toLowerCase().trim();
      const jsLow = (job.source || '').toLowerCase().trim();
      if (!jsLow.includes(sLow)) return false;
    }

    // 4. Job Type Filter (Internship vs Full-Time)
    if (typeFilter !== 'All') {
      const tLow = typeFilter.toLowerCase().trim();
      const jtLow = (job.job_type || '').toLowerCase().trim();
      if (!jtLow.includes(tLow)) return false;
    }

    // 5. Remote Only Filter
    if (onlyRemote && !job.remote) {
      return false;
    }

    // 6. Curated Low-Crowd Platforms
    if (onlyLowCrowd && !isLowCrowdSource(job.source)) {
      return false;
    }

    // 7. ATS Eligibility Filter
    if (onlyEligible) {
      const match = computeJobMatch(job);
      if (match.matchScore === null || match.matchScore < 65) {
        return false;
      }
    }

    return true;
  });

  const getSourceBadgeColor = (source: string) => {
    const s = source.toLowerCase();
    if (s.includes('remote.com') || s === 'remote.com') return { bg: 'rgba(168, 85, 247, 0.18)', text: '#c084fc', border: 'rgba(168, 85, 247, 0.45)' };
    if (s.includes('instahyre')) return { bg: 'rgba(14, 165, 233, 0.18)', text: '#38bdf8', border: 'rgba(14, 165, 233, 0.45)' };
    if (s.includes('careerhound')) return { bg: 'rgba(245, 158, 11, 0.18)', text: '#fbbf24', border: 'rgba(245, 158, 11, 0.45)' };
    if (s.includes('wellfound')) return { bg: 'rgba(236, 72, 153, 0.18)', text: '#f472b6', border: 'rgba(236, 72, 153, 0.45)' };
    if (s.includes('yc') || s.includes('y combinator')) return { bg: 'rgba(249, 115, 22, 0.18)', text: '#fb923c', border: 'rgba(249, 115, 22, 0.45)' };
    if (s.includes('cutshort')) return { bg: 'rgba(16, 185, 129, 0.18)', text: '#34d399', border: 'rgba(16, 185, 129, 0.45)' };
    if (s.includes('otta')) return { bg: 'rgba(99, 102, 241, 0.18)', text: '#818cf8', border: 'rgba(99, 102, 241, 0.45)' };
    if (s.includes('linkedin')) return { bg: 'rgba(10, 102, 194, 0.2)', text: '#60a5fa', border: 'rgba(10, 102, 194, 0.45)' };
    if (s.includes('naukri')) return { bg: 'rgba(255, 117, 85, 0.2)', text: '#fb923c', border: 'rgba(255, 117, 85, 0.45)' };
    if (s.includes('muse')) return { bg: 'rgba(236, 72, 153, 0.15)', text: '#f472b6', border: 'rgba(236, 72, 153, 0.3)' };
    if (s.includes('remotive')) return { bg: 'rgba(59, 130, 246, 0.15)', text: '#60a5fa', border: 'rgba(59, 130, 246, 0.3)' };
    if (s.includes('himalayas')) return { bg: 'rgba(168, 85, 247, 0.15)', text: '#c084fc', border: 'rgba(168, 85, 247, 0.3)' };
    if (s.includes('jobicy')) return { bg: 'rgba(16, 185, 129, 0.15)', text: '#34d399', border: 'rgba(16, 185, 129, 0.3)' };
    if (s.includes('arbeitnow')) return { bg: 'rgba(245, 158, 11, 0.15)', text: '#fbbf24', border: 'rgba(245, 158, 11, 0.3)' };
    if (s.includes('remoteok')) return { bg: 'rgba(244, 63, 94, 0.15)', text: '#fb7185', border: 'rgba(244, 63, 94, 0.3)' };
    if (s.includes('weworkremotely') || s.includes('wwr')) return { bg: 'rgba(14, 165, 233, 0.15)', text: '#38bdf8', border: 'rgba(14, 165, 233, 0.3)' };
    if (s.includes('internshala')) return { bg: 'rgba(0, 143, 213, 0.18)', text: '#38bdf8', border: 'rgba(0, 143, 213, 0.45)' };
    if (s.includes('unstop')) return { bg: 'rgba(30, 64, 175, 0.22)', text: '#60a5fa', border: 'rgba(59, 130, 246, 0.45)' };
    if (s.includes('indeed')) return { bg: 'rgba(33, 100, 240, 0.18)', text: '#93c5fd', border: 'rgba(33, 100, 240, 0.45)' };
    if (s.includes('employai')) return { bg: 'rgba(16, 185, 129, 0.18)', text: '#34d399', border: 'rgba(16, 185, 129, 0.45)' };
    return { bg: 'rgba(99, 102, 241, 0.15)', text: '#818cf8', border: 'rgba(99, 102, 241, 0.3)' };
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Header Banner */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
            <h2 style={{ fontSize: '1.6rem', fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.02em', margin: 0 }}>
              Universal Job & Internship Gateway
            </h2>
            <span className="badge badge-emerald" style={{ fontSize: '0.72rem', display: 'inline-flex', alignItems: 'center', gap: '0.4rem', border: '1px solid rgba(16, 185, 129, 0.4)' }}>
              <span style={{ width: '7px', height: '7px', borderRadius: '50%', backgroundColor: '#10b981', boxShadow: '0 0 8px #10b981', animation: 'pulse 1.5s infinite', display: 'inline-block' }} />
              Live Real-Time Stream (0ms Local Cache)
            </span>
            <span className="badge badge-cyan" style={{ fontSize: '0.72rem', display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}>
              <Globe size={13} /> 21+ Multi-App Sync Active
            </span>
            <span className="badge" style={{ fontSize: '0.72rem', display: 'inline-flex', alignItems: 'center', gap: '0.35rem', backgroundColor: 'rgba(16, 185, 129, 0.15)', color: '#34d399', borderColor: 'rgba(16, 185, 129, 0.35)' }}>
              <Sparkles size={12} /> 7 Curated Low-Crowd Platforms
            </span>
          </div>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.25rem', lineHeight: 1.5 }}>
            Live aggregated portal streaming verified openings in real time from <strong>Remote.com, Instahyre, Careerhound.io, Wellfound, YC Startups, Cutshort, Otta, LinkedIn, Naukri.com, Remotive, Himalayas & more</strong>. Zero cached data is stored locally — fresh opportunities are pulled directly so you can apply in real time.
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.4rem', flexWrap: 'wrap' }}>
            <span style={{ color: 'var(--accent-emerald)', fontWeight: 600 }}>● Connected to 21 Live Feeds</span>
            <span>•</span>
            <span>
              Synced {secondsAgo === 0 ? 'just now' : `${secondsAgo}s ago`} (Last live sync: {lastSyncTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })})
            </span>
            <span>•</span>
            <span style={{ color: '#34d399' }}>Fast 3.5s Timeout Safeguards Active</span>
            {isRefreshing && <span style={{ color: 'var(--accent-cyan)', fontWeight: 600 }}>(Syncing fresh real-time postings...)</span>}
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', flexWrap: 'wrap' }}>
          <button
            onClick={handleRefresh}
            disabled={isRefreshing || isLoading}
            className="btn btn-primary btn-sm"
            style={{ padding: '0.45rem 0.85rem', display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}
          >
            <RefreshCw size={14} className={isRefreshing ? 'animate-spin-slow' : ''} /> Sync All Feeds
          </button>
        </div>
      </div>

      {refreshNotice && (
        <div style={{ padding: '0.85rem 1.15rem', borderRadius: '10px', background: 'rgba(16, 185, 129, 0.12)', border: '1px solid rgba(16, 185, 129, 0.35)', color: '#34d399', fontSize: '0.825rem', display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <ShieldCheck size={18} /> {refreshNotice}
        </div>
      )}

      {toastNotice && (
        <div style={{ padding: '0.85rem 1.15rem', borderRadius: '10px', background: 'rgba(6, 182, 212, 0.12)', border: '1px solid rgba(6, 182, 212, 0.35)', color: 'var(--accent-cyan)', fontSize: '0.825rem', display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <Sparkles size={18} /> {toastNotice}
        </div>
      )}

      {/* Domain Quick-Filter Carousel / Chips */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontWeight: 600 }}>
            <Compass size={14} color="var(--accent-cyan)" /> Explore Disciplines & Domains ({DOMAIN_OPTIONS.length}):
          </span>
          {domainFilter !== 'All' && (
            <button
              onClick={() => setDomainFilter('All')}
              style={{ background: 'none', border: 'none', color: 'var(--accent-cyan)', cursor: 'pointer', fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.2rem' }}
            >
              <X size={12} /> Clear domain filter
            </button>
          )}
        </div>

        <div className="domain-chips-wrapper">
          <div className="domain-chips-scroll no-scrollbar">
            {DOMAIN_OPTIONS.map((dom) => {
              const isSelected = domainFilter === dom.value || (dom.value === 'All' && domainFilter === 'All');
              return (
                <button
                  key={dom.value}
                  onClick={() => setDomainFilter(dom.value)}
                  className={`domain-chip ${isSelected ? 'active' : ''}`}
                >
                  <span>{dom.icon}</span>
                  <span>{dom.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="glass-card portal-filter-card">
        <div className="portal-filter-row">
          {/* Search Input */}
          <div className="portal-search-box">
            <Search size={16} style={{ position: 'absolute', left: '0.85rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              type="text"
              placeholder="Search by role title, enterprise (Google, L&T, Apollo...), or skill keyword..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="portal-input"
              style={{ paddingLeft: '2.4rem', paddingRight: searchQuery ? '2.4rem' : '0.85rem' }}
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                style={{ position: 'absolute', right: '0.85rem', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
                title="Clear search"
              >
                <X size={14} />
              </button>
            )}
          </div>

          {/* Source / App Provider Filter */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flex: '1 1 200px' }}>
            <Building2 size={15} color="var(--text-muted)" />
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="portal-select"
            >
              {SOURCE_OPTIONS.map((src) => (
                <option key={src.value} value={src.value}>{src.label}</option>
              ))}
            </select>
          </div>

          {/* Job Type Selector */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flex: '1 1 150px' }}>
            <Layers size={14} color="var(--text-muted)" />
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="portal-select"
            >
              <option value="All">All Types</option>
              <option value="internship">🎓 Internships & Trainee</option>
              <option value="full-time">💼 Full-time Postings</option>
              <option value="part-time">⏱️ Part-time</option>
              <option value="contract">📝 Contract</option>
            </select>
          </div>
        </div>

        {/* Second row of filter toggles */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem', paddingTop: '0.5rem', borderTop: '1px solid var(--border-subtle)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
            {/* Low-Crowd / Curated Platforms Toggle */}
            <button
              onClick={() => setOnlyLowCrowd(!onlyLowCrowd)}
              className={`btn btn-sm ${onlyLowCrowd ? 'btn-primary' : 'btn-secondary'}`}
              style={{
                fontSize: '0.75rem',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.35rem',
                padding: '0.35rem 0.75rem',
                borderColor: onlyLowCrowd ? '#10b981' : 'rgba(16, 185, 129, 0.4)',
                backgroundColor: onlyLowCrowd ? 'rgba(16, 185, 129, 0.25)' : 'rgba(16, 185, 129, 0.08)',
                color: onlyLowCrowd ? '#34d399' : '#10b981'
              }}
            >
              <Sparkles size={13} color={onlyLowCrowd ? '#34d399' : '#10b981'} />
              {onlyLowCrowd ? '✓ Less Crowd & High Intent (Active)' : '⚡ Less Crowd & High Intent (Remote.com, Instahyre, YC...)'}
            </button>

            {/* Remote only toggle */}
            <button
              onClick={() => setOnlyRemote(!onlyRemote)}
              className={`btn btn-sm ${onlyRemote ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.75rem', display: 'inline-flex', alignItems: 'center', gap: '0.35rem', padding: '0.35rem 0.75rem' }}
            >
              <Globe size={13} /> {onlyRemote ? '✓ Remote Only' : 'Remote Only'}
            </button>

            {/* Eligibility Filter Toggle */}
            <button
              onClick={() => setOnlyEligible(!onlyEligible)}
              className={`btn btn-sm ${onlyEligible ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.75rem', display: 'inline-flex', alignItems: 'center', gap: '0.35rem', padding: '0.35rem 0.75rem' }}
            >
              <Target size={13} /> {onlyEligible ? '✓ Eligible Only (≥65%)' : 'Eligible Only (≥65%)'}
            </button>
          </div>

          <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
            Showing <strong>{filtered.length}</strong> active openings across providers
          </div>
        </div>
      </div>

      {error && jobs.length === 0 && (
        <div className="modern-alert alert-error">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <Zap size={16} />
            <span>{error}</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <button
              onClick={() => loadJobs(true)}
              className="btn btn-secondary btn-sm"
              style={{ fontSize: '0.75rem', padding: '0.25rem 0.65rem' }}
            >
              <RefreshCw size={12} /> Retry Sync
            </button>
            <button
              onClick={() => setError(null)}
              style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', padding: '0.2rem' }}
              title="Dismiss alert"
            >
              <X size={15} />
            </button>
          </div>
        </div>
      )}

      {/* Opportunities List */}
      {isLoading ? (
        <div className="glass-card" style={{ padding: '2rem 1.5rem', textAlign: 'center' }}>
          <FuturisticLoader
            size="md"
            icon="globe"
            title="Aggregating Live Openings Across External Feeds"
            subtitle="Fetching verified listings from Remote.com, Instahyre, Careerhound.io, Wellfound, YC Startups, Cutshort, Otta, LinkedIn, The Muse & RemoteOK..."
          />
        </div>
      ) : filtered.length === 0 ? (
        <div className="glass-card" style={{ padding: '3.5rem 2rem', textAlign: 'center', color: 'var(--text-muted)' }}>
          <Briefcase size={40} style={{ margin: '0 auto 0.85rem auto', color: 'var(--text-muted)' }} />
          <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--text-primary)' }}>
            {onlyEligible ? 'No Opportunities Currently Meet Your ≥65% Match Threshold' : 'No Matching Postings Found'}
          </h3>
          <p style={{ fontSize: '0.85rem', marginTop: '0.4rem', maxWidth: '580px', margin: '0.4rem auto 1.4rem auto', lineHeight: 1.5 }}>
            {onlyEligible ? (
              <span>
                To unlock more opportunities in this discipline, acquire key target skills via personalized Learning Roadmaps or review all roles below.
              </span>
            ) : (
              <span>
                Try adjusting your search criteria, clearing search keywords, or selecting another domain/source provider above.
              </span>
            )}
          </p>

          <div style={{ display: 'flex', justifyContent: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
            {(domainFilter !== 'All' || sourceFilter !== 'All' || typeFilter !== 'All' || searchQuery || onlyRemote || onlyEligible || onlyLowCrowd) && (
              <button 
                onClick={() => {
                  setDomainFilter('All');
                  setSourceFilter('All');
                  setTypeFilter('All');
                  setSearchQuery('');
                  setOnlyRemote(false);
                  setOnlyEligible(false);
                  setOnlyLowCrowd(false);
                }} 
                className="btn btn-secondary btn-sm"
              >
                Reset All Filters
              </button>
            )}
          </div>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: '1.35rem' }}>
          {filtered.map((job) => {
            const hasApplied = appliedIds.has(job.id);
            const { matchScore, matchedSkillsSet } = computeJobMatch(job);
            const hasMatch = matchScore !== null;
            const isHighFit = hasMatch && matchScore >= 85;
            const isGoodFit = hasMatch && matchScore >= 65 && matchScore < 85;

            const badgeBg = isHighFit 
              ? 'rgba(16, 185, 129, 0.15)' 
              : isGoodFit 
                ? 'rgba(6, 182, 212, 0.15)' 
                : hasMatch
                  ? 'rgba(245, 158, 11, 0.15)'
                  : 'rgba(255, 255, 255, 0.06)';
            const badgeColor = isHighFit 
              ? 'var(--accent-emerald, #10b981)' 
              : isGoodFit 
                ? 'var(--accent-cyan, #06b6d4)' 
                : hasMatch
                  ? 'var(--accent-amber, #f59e0b)'
                  : 'var(--text-muted)';
            const srcStyle = getSourceBadgeColor(job.source);
            const targetUrl = resolveValidApplyUrl(job);


            return (
              <div
                key={job.id}
                className="glass-card"
                style={{
                  padding: '1.45rem',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                  gap: '1.1rem',
                  transition: 'all var(--transition-normal)',
                  position: 'relative'
                }}
              >
                <div>
                  {/* Top Badges & Match */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', flexWrap: 'wrap' }}>
                      <span 
                        className="badge" 
                        style={{ 
                          fontSize: '0.675rem',
                          backgroundColor: srcStyle.bg,
                          color: srcStyle.text,
                          borderColor: srcStyle.border
                        }}
                      >
                        {job.source}
                      </span>
                      <span className="badge badge-secondary" style={{ fontSize: '0.675rem' }}>
                        {job.job_type === 'internship' ? '🎓 Internship' : '💼 ' + job.job_type}
                      </span>
                      {job.domain && (
                        <span className="badge" style={{ fontSize: '0.65rem', backgroundColor: 'rgba(255, 255, 255, 0.04)', color: 'var(--text-secondary)' }}>
                          {job.domain}
                        </span>
                      )}
                      {isLowCrowdSource(job.source) && (
                        <span 
                          className="badge" 
                          style={{ 
                            fontSize: '0.65rem', 
                            backgroundColor: 'rgba(16, 185, 129, 0.15)', 
                            color: '#34d399', 
                            borderColor: 'rgba(16, 185, 129, 0.4)',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '0.2rem'
                          }}
                        >
                          <Zap size={10} /> Low Crowd • Direct Team
                        </span>
                      )}
                    </div>

                    <span 
                      className="badge" 
                      style={{ 
                        fontSize: '0.75rem', 
                        fontWeight: 800,
                        backgroundColor: badgeBg,
                        color: badgeColor,
                        borderColor: badgeColor
                      }}
                    >
                      <Target size={11} style={{ display: 'inline', marginRight: '3px' }} />
                      {hasMatch ? `${matchScore}% Match` : 'Sign in to Match'}
                    </span>
                  </div>

                  {/* Title & Company - Clickable to open full in-app Job Description */}
                  <h3 
                    onClick={() => handleSelectJob(job)}
                    style={{ 
                      fontSize: '1.15rem', 
                      fontWeight: 800, 
                      color: 'var(--text-primary)', 
                      marginBottom: '0.25rem', 
                      lineHeight: 1.3,
                      cursor: 'pointer',
                      transition: 'color 0.2s ease'
                    }}
                    title="Click to view full job description & ATS skill breakdown"
                    onMouseEnter={(e) => { e.currentTarget.style.color = 'var(--accent-cyan)'; }}
                    onMouseLeave={(e) => { e.currentTarget.style.color = 'var(--text-primary)'; }}
                  >
                    {job.title}
                  </h3>
                  <p 
                    onClick={() => handleSelectJob(job)}
                    style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--accent-cyan)', cursor: 'pointer', margin: 0 }}
                  >
                    {job.company}
                  </p>

                  <p 
                    onClick={() => handleSelectJob(job)}
                    style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '0.6rem', marginBottom: '0.85rem', lineHeight: 1.45, display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden', cursor: 'pointer' }}
                    title="Click to read full description"
                  >
                    {job.description}
                  </p>

                  {/* Details Badges */}
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.75rem', fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '0.85rem' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                      <MapPin size={13} /> {job.location} {job.remote ? '(Remote)' : ''}
                    </span>
                    {job.salary_range && (
                      <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', color: 'var(--accent-emerald)', fontWeight: 600 }}>
                        💰 {job.salary_range}
                      </span>
                    )}
                    <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                      <Calendar size={13} /> {formatJobDate(job.posted_date)}
                      {(job.posted_date?.toLowerCase().includes('just now') || job.posted_date?.toLowerCase().includes('today') || job.posted_date?.toLowerCase().includes('1 day')) && (
                        <span style={{ display: 'inline-block', width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#10b981', boxShadow: '0 0 6px rgba(16, 185, 129, 0.6)' }} title="Verified Active & Fresh" />
                      )}
                    </span>
                  </div>

                  {/* Skills required with highlight */}
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem', marginBottom: '0.75rem' }}>
                    {(job.required_skills || []).slice(0, 6).map((sk, sIdx) => {
                      const isMatched = matchedSkillsSet.has(sk.toLowerCase().trim());
                      return (
                        <span 
                          key={sIdx} 
                          className="badge" 
                          style={{ 
                            fontSize: '0.675rem', 
                            padding: '0.2rem 0.5rem',
                            backgroundColor: isMatched ? 'rgba(16, 185, 129, 0.15)' : 'rgba(255, 255, 255, 0.05)',
                            color: isMatched ? '#34d399' : 'var(--text-secondary)',
                            borderColor: isMatched ? 'rgba(16, 185, 129, 0.3)' : 'var(--border-subtle)'
                          }}
                        >
                          {isMatched ? '✓ ' : ''}{sk}
                        </span>
                      );
                    })}
                    {(job.required_skills || []).length > 6 && (
                      <span className="badge badge-secondary" style={{ fontSize: '0.675rem' }}>
                        +{(job.required_skills.length - 6)} more
                      </span>
                    )}
                  </div>
                </div>

                {/* Card Actions */}
                <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: '0.85rem' }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1.45fr 1fr', gap: '0.5rem', marginBottom: '0.5rem' }}>
                    {/* Primary Button: View In-App Job Description */}
                    <button
                      onClick={() => handleSelectJob(job)}
                      className="btn btn-primary btn-sm"
                      style={{ 
                        fontSize: '0.8rem', 
                        display: 'flex', 
                        alignItems: 'center', 
                        justifyContent: 'center', 
                        gap: '0.35rem',
                        padding: '0.45rem 0.55rem',
                        fontWeight: 700
                      }}
                      title="View full job description, responsibilities & ATS match breakdown on Employ.AI"
                    >
                      <Eye size={13} /> View Description
                    </button>

                    {/* Secondary Button: Live Verified Platform Gateway */}
                    {hasApplied ? (
                      <button
                        disabled
                        className="btn btn-secondary btn-sm"
                        style={{ fontSize: '0.78rem', color: '#34d399', borderColor: 'rgba(16, 185, 129, 0.4)', padding: '0.45rem 0.5rem' }}
                      >
                        <Check size={12} /> Applied
                      </button>
                    ) : (
                      <a
                        href={targetUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary btn-sm"
                        style={{ 
                          fontSize: '0.78rem', 
                          display: 'flex', 
                          alignItems: 'center', 
                          justifyContent: 'center', 
                          gap: '0.3rem',
                          textDecoration: 'none',
                          padding: '0.45rem 0.5rem',
                          color: 'var(--text-primary)'
                        }}
                        title={`Apply directly on verified live platform gateway (${job.source})`}
                      >
                        Apply {job.source.replace(/\([^)]*\)/g, '').trim()} <ExternalLink size={11} />
                      </a>
                    )}
                  </div>

                  {/* Fail-Safe Secondary Search & Self-Healing Actions */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                    <a 
                      href={getFallbackSearchUrl(job)}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ color: 'var(--text-muted)', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '0.2rem', transition: 'color 0.2s' }}
                      onMouseEnter={(e) => { e.currentTarget.style.color = 'var(--accent-cyan)'; }}
                      onMouseLeave={(e) => { e.currentTarget.style.color = 'var(--text-muted)'; }}
                      title="Search company verified openings on Google"
                    >
                      <Search size={10} /> Search backup
                    </a>
                    <button
                      onClick={() => handleReportBrokenLink(job)}
                      style={{ background: 'none', border: 'none', padding: 0, color: reportedJobIds.has(job.id) ? '#34d399' : 'var(--text-muted)', cursor: 'pointer', fontSize: '0.7rem', display: 'flex', alignItems: 'center', gap: '0.2rem', transition: 'color 0.2s' }}
                      onMouseEnter={(e) => { if (!reportedJobIds.has(job.id)) e.currentTarget.style.color = 'var(--accent-amber, #f59e0b)'; }}
                      onMouseLeave={(e) => { if (!reportedJobIds.has(job.id)) e.currentTarget.style.color = 'var(--text-muted)'; }}
                      title="Report inaccessible link to trigger instant auto-heal"
                    >
                      {reportedJobIds.has(job.id) ? '✓ Healed' : 'Report link'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* READ & LEARN MY RESUME - Below Jobs/Internships Section */}
      <div 
        className="glass-card role-hero-banner" 
        style={{ 
          padding: '1.5rem 1.75rem', 
          background: 'var(--grad-banner)',
          border: '1px solid var(--border-glass)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '1rem',
          marginTop: '0.5rem'
        }}
      >
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.3rem' }}>
            <BookMarked size={20} color="var(--accent-cyan)" />
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
              READ & LEARN MY RESUME
            </h3>
            <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>
              <ShieldCheck size={11} /> Ground-Truth Study
            </span>
          </div>
          <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', margin: 0 }}>
            Understand every section, skill, project, and claim on your resume before applying to multi-domain roles.
          </p>
        </div>

        {onNavigate && (
          <button 
            onClick={() => onNavigate('resume_learning')}
            className="btn btn-primary btn-sm"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
          >
            <BookOpen size={14} /> Read & Learn Resume →
          </button>
        )}
      </div>

      {/* In-App Job Description & Skill Fit Modal */}
      <JobDetailsModal
        job={selectedJob}
        isOpen={Boolean(selectedJob)}
        onClose={() => handleSelectJob(null)}
        onApplyDirect={handleApplyDirect}
        resolveValidApplyUrl={resolveValidApplyUrl}
        hasApplied={selectedJob ? appliedIds.has(selectedJob.id) : false}
        isApplying={selectedJob ? applyingId === selectedJob.id : false}
        matchScore={selectedJob ? computeJobMatch(selectedJob).matchScore : null}
        matchedSkillsSet={selectedJob ? computeJobMatch(selectedJob).matchedSkillsSet : new Set<string>()}
        onNavigate={onNavigate}
        getSourceBadgeColor={getSourceBadgeColor}
      />
    </div>
  );
};
