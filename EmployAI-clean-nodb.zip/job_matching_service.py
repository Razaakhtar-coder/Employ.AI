import re
from typing import List, Dict, Any, Optional, Tuple, Set
from sqlalchemy.orm import Session
from app.models.profile import StudentProfile
from app.models.taxonomy import StudentSkill, Skill
from app.models.document import AnalysisResult
from app.models.job import JobPosting, UserJobMatch
from app.schemas.job import (
    JobScoreBreakdown, JobSkillItem, JobExplainResponse,
    ManualJobMatchResponse, JobPostingResponse
)
from app.services.job_normalization_service import JobNormalizationService


class JobMatchingService:
    """
    Deterministic, Honest AI Matching Engine for Job & Internship Postings.
    Guarantees authentic match percentages reflecting the candidate's genuine resume skills,
    domain specialization, and seniority without hallucinated scores or false substring positives.
    """

    # Comprehensive dictionary of canonical skill equivalents and aliases
    CANONICAL_SYNONYMS: Dict[str, Set[str]] = {
        "python": {"python", "python3", "py"},
        "react": {"react", "react.js", "reactjs", "react-native"},
        "node.js": {"node", "node.js", "nodejs"},
        "typescript": {"typescript", "ts"},
        "javascript": {"javascript", "js", "ecmascript"},
        "fastapi": {"fastapi", "fast-api"},
        "django": {"django", "django rest framework", "drf"},
        "flask": {"flask"},
        "spring boot": {"spring boot", "spring framework", "spring"},
        "java": {"java", "core java"},
        "c++": {"c++", "cpp"},
        "c#": {"c#", "csharp", ".net", "dotnet"},
        "golang": {"go", "golang"},
        "rust": {"rust"},
        "postgresql": {"postgresql", "postgres", "psql"},
        "mysql": {"mysql"},
        "mongodb": {"mongodb", "mongo"},
        "redis": {"redis"},
        "sql": {"sql", "rdbms", "relational database"},
        "docker": {"docker", "dockerfile", "containerization"},
        "kubernetes": {"kubernetes", "k8s"},
        "aws": {"aws", "amazon web services"},
        "azure": {"azure", "microsoft azure"},
        "gcp": {"gcp", "google cloud", "google cloud platform"},
        "git": {"git", "github", "gitlab"},
        "ci/cd": {"ci/cd", "cicd", "continuous integration", "github actions", "jenkins"},
        "rest api": {"rest api", "restful api", "rest", "api development"},
        "graphql": {"graphql"},
        "machine learning": {"machine learning", "ml", "scikit-learn"},
        "deep learning": {"deep learning", "dl", "neural networks", "pytorch", "tensorflow"},
        "nlp": {"nlp", "natural language processing"},
        "computer vision": {"computer vision", "cv", "opencv"},
        "data structures": {"data structures", "algorithms", "dsa", "data structures & algorithms"},
        "power bi": {"power bi", "powerbi", "power-bi"},
        "tableau": {"tableau"},
        "data analytics": {"data analytics", "data analysis", "data visualization"},
        "kpi dashboards": {"kpi dashboards", "dashboards", "business metrics"},
        "excel": {"excel", "advanced excel", "ms excel", "microsoft excel", "spreadsheets"},
        "financial modeling": {"financial modeling", "financial modelling", "dcf"},
        "financial analysis": {"financial analysis", "financial statement analysis", "ratio analysis", "variance analysis"},
        "corporate finance": {"corporate finance", "valuation", "mergers and acquisitions", "m&a"},
        "financial accounting": {"financial accounting", "general ledger", "accounting", "bookkeeping"},
        "cost accounting": {"cost accounting", "management accounting"},
        "auditing": {"auditing", "statutory audit", "internal audit", "financial audit"},
        "taxation": {"taxation", "direct tax", "indirect tax", "gst", "gst compliance", "income tax"},
        "tally": {"tally", "tally prime", "tally erp", "tally erp 9"},
        "sap fico": {"sap fico", "sap"},
        "strategic planning": {"strategic planning", "corporate strategy", "business strategy"},
        "product management": {"product management", "product roadmap", "user stories", "agile", "scrum"},
        "digital marketing": {"digital marketing", "seo", "sem", "social media marketing", "google analytics"},
        "human resources": {"human resources", "hr", "talent acquisition", "recruitment", "payroll"},
        "solidworks": {"solidworks", "solid works"},
        "autocad": {"autocad", "cad"},
        "ansys": {"ansys", "ansys fluent", "fea", "cfd"},
        "catia": {"catia"},
        "matlab": {"matlab", "simulink"},
        "revit": {"revit", "bim"},
        "staad.pro": {"staad.pro", "staad", "structural analysis"},
        "photoshop": {"photoshop", "adobe photoshop", "ps"},
        "illustrator": {"illustrator", "adobe illustrator"},
        "after effects": {"after effects", "adobe after effects", "ae"},
        "premiere pro": {"premiere pro", "adobe premiere", "premiere"},
        "adobe creative suite": {"adobe creative suite", "adobe creative cloud", "adobe"},
        "figma": {"figma"},
        "canva": {"canva"},
        "capcut": {"capcut"},
        "motion graphics": {"motion graphics", "motion design", "animation"},
        "video editing": {"video editing", "video production", "short-form video"},
        "design systems": {"design systems", "design system", "modular design"},
        "graphic design": {"graphic design", "visual design", "social media design"},
        "ui/ux design": {"ui/ux design", "ui/ux", "ui design", "ux design", "product design"},
        "gen ai tools": {"gen ai tools", "gen ai", "generative ai", "ai-assisted workflows"}
    }

    # Strict domain category clusters
    DOMAIN_AFFINITY_GROUPS: Dict[str, Set[str]] = {
        "Design & Creative Media": {"design & creative media", "design", "graphic design", "visual communication", "multimedia", "fine arts", "animation", "ui/ux design", "creative media"},
        "Computer Science": {"computer science", "information technology", "software engineering", "computer applications", "data science", "cybersecurity", "ai/ml"},
        "Finance & Commerce": {"finance & commerce", "finance", "banking & finance", "commerce", "accounting", "chartered accountancy", "b.com", "m.com"},
        "Business Analytics": {"business analytics", "data analytics", "business intelligence", "product analytics", "business analysis"},
        "Management & Business": {"management & business", "management", "business administration", "mba", "bba", "marketing", "human resources", "operations & supply chain", "sales"},
        "Mechanical": {"mechanical", "mechanical engineering", "aerospace engineering", "automotive engineering", "production engineering", "mechatronics"},
        "Electrical": {"electrical", "electrical & electronics", "electronics & communication", "embedded systems", "vlsi", "instrumentation"},
        "Civil": {"civil", "civil engineering", "structural engineering", "construction management"},
        "Law & Legal": {"law & legal", "corporate law", "legal studies", "llb", "ba llb"},
        "Healthcare & Medicine": {"healthcare & medicine", "pharmacy", "medicine", "nursing", "clinical research", "mbbs", "b.pharm"}
    }

    @classmethod
    def check_skill_match(cls, req_skill: str, candidate_skills: Set[str]) -> bool:
        """
        Determines whether a required job skill is genuinely matched by the candidate.
        Uses exact normalization and canonical synonym sets to strictly prevent false substring positives.
        """
        r_clean = req_skill.strip().lower()
        if not r_clean:
            return False

        # 1. Exact match
        if r_clean in candidate_skills:
            return True

        # 2. Canonical synonym match
        r_syns = cls.CANONICAL_SYNONYMS.get(r_clean, {r_clean})
        for cand_s in candidate_skills:
            c_clean = cand_s.strip().lower()
            c_syns = cls.CANONICAL_SYNONYMS.get(c_clean, {c_clean})
            if r_syns.intersection(c_syns) or r_clean == c_clean:
                return True

        # 3. Word-boundary exact token phrase match (Only for multi-word phrases with >= 4 letters)
        if len(r_clean) >= 4 and " " in r_clean:
            pattern = r"(?<![A-Za-z0-9])" + re.escape(r_clean) + r"(?![A-Za-z0-9])"
            for cand_s in candidate_skills:
                if re.search(pattern, cand_s.lower()):
                    return True

        return False

    @classmethod
    def calculate_domain_fit(cls, candidate_domain: str, job_domain: str) -> Tuple[float, str]:
        """Calculates honest domain compatibility between candidate's discipline and the target job."""
        c_low = candidate_domain.strip().lower()
        j_low = job_domain.strip().lower()

        # Check exact or affinity group match
        job_cluster = cls.DOMAIN_AFFINITY_GROUPS.get(job_domain, {j_low})
        if any(alias in c_low or c_low in alias for alias in job_cluster):
            return 100.0, f"Direct disciplinary alignment ({job_domain})."

        # Adjacent/complementary domains
        business_domains = {"management & business", "finance & commerce", "business analytics", "management", "commerce", "finance"}
        if c_low in business_domains and j_low in business_domains:
            return 75.0, f"Strong business & commercial domain affinity ({job_domain})."

        tech_data_domains = {"computer science", "business analytics", "data science"}
        if c_low in tech_data_domains and j_low in tech_data_domains:
            return 70.0, f"Technical & data analytical domain relevance ({job_domain})."

        engineering_domains = {"mechanical", "electrical", "civil"}
        if any(e in c_low for e in engineering_domains) and any(e in j_low for e in engineering_domains):
            return 45.0, f"Cross-disciplinary engineering foundation ({job_domain})."

        # Complete divergence (e.g., MBA / Commerce vs Software Engineering / Mechanical)
        return 5.0, f"Distinct discipline transition ({job_domain})."

    @classmethod
    def extract_student_context(
        cls,
        db: Session,
        student_profile: Optional[StudentProfile]
    ) -> Dict[str, Any]:
        """
        Gathers genuine candidate context from the database, prioritizing the latest uploaded resume.
        """
        if not student_profile:
            latest_analysis = db.query(AnalysisResult).order_by(AnalysisResult.created_at.desc()).first()
            if latest_analysis:
                skill_names: Set[str] = set()
                if latest_analysis.extracted_skills_json:
                    for s in latest_analysis.extracted_skills_json:
                        if isinstance(s, str) and s.strip():
                            skill_names.add(s.strip().lower())
                return {
                    "skills": skill_names,
                    "domain": latest_analysis.detected_domain or "Computer Science",
                    "department": latest_analysis.detected_domain or "Computer Science",
                    "grad_year": 2025,
                    "ats_score": latest_analysis.resume_quality_score or 75.0,
                    "cgpa": 8.0,
                    "has_resume": True
                }
            return {
                "skills": set(),
                "domain": "General",
                "department": "General",
                "grad_year": 2025,
                "ats_score": 50.0,
                "cgpa": 8.0,
                "has_resume": False
            }

        skill_names: Set[str] = set()

        # 1. Check latest uploaded resume analysis first (Ground Truth)
        latest_analysis = db.query(AnalysisResult).filter(
            AnalysisResult.student_profile_id == student_profile.id
        ).order_by(AnalysisResult.created_at.desc()).first()

        if not latest_analysis:
            latest_analysis = db.query(AnalysisResult).order_by(AnalysisResult.created_at.desc()).first()

        ats_score = 50.0
        detected_domain = None
        has_resume = False

        if latest_analysis:
            has_resume = True
            ats_score = latest_analysis.resume_quality_score or 75.0
            detected_domain = latest_analysis.detected_domain
            if latest_analysis.extracted_skills_json:
                for s in latest_analysis.extracted_skills_json:
                    if isinstance(s, str) and s.strip():
                        skill_names.add(s.strip().lower())

        # 2. Check verified StudentSkill records
        student_skills = db.query(StudentSkill).filter(StudentSkill.student_profile_id == student_profile.id).all()
        resume_skills_lower = {s.strip().lower() for s in (latest_analysis.extracted_skills_json or []) if isinstance(s, str)} if (has_resume and latest_analysis) else set()
        for ss in student_skills:
            sk = db.query(Skill).filter(Skill.id == ss.skill_id).first()
            if sk:
                c_name = sk.canonical_name.strip().lower()
                if ss.source == "resume" and has_resume:
                    if c_name not in resume_skills_lower and not any(cls.check_skill_match(c_name, {rs}) for rs in resume_skills_lower):
                        continue
                skill_names.add(c_name)

        # Domain hierarchy: Latest Resume Detected Domain -> Student Profile Target Domain -> Department -> General
        candidate_domain = (
            detected_domain or 
            student_profile.target_domain or 
            student_profile.department or 
            "General Professional"
        )

        return {
            "skills": skill_names,
            "domain": candidate_domain,
            "department": student_profile.department or candidate_domain,
            "grad_year": student_profile.graduation_year or 2025,
            "ats_score": ats_score,
            "cgpa": student_profile.cgpa or 8.0,
            "has_resume": has_resume
        }

    @classmethod
    def compute_match(
        cls,
        student_ctx: Dict[str, Any],
        job_title: str,
        job_domain: str,
        job_exp_level: str,
        required_skills: List[str]
    ) -> Tuple[float, JobScoreBreakdown, List[JobSkillItem], List[JobSkillItem], Dict[str, Any]]:
        """
        Computes an honest, non-compensatory compatibility score (0-100) and explainability payload.
        """
        student_skills = student_ctx.get("skills", set())
        candidate_domain = student_ctx.get("domain", "General")
        ats_score = float(student_ctx.get("ats_score", 50.0))
        has_resume = bool(student_ctx.get("has_resume", len(student_skills) > 0))

        matched_items: List[JobSkillItem] = []
        missing_items: List[JobSkillItem] = []

        if not required_skills:
            required_skills = ["Domain Fundamentals"]

        # 1. Skill Overlap Calculation (Gated & Non-Compensatory)
        for s in required_skills:
            s_clean = s.strip()
            if not s_clean:
                continue

            if cls.check_skill_match(s_clean, student_skills):
                matched_items.append(JobSkillItem(
                    skill_name=s_clean,
                    is_matched=True,
                    is_required=True,
                    importance="high"
                ))
            else:
                missing_items.append(JobSkillItem(
                    skill_name=s_clean,
                    is_matched=False,
                    is_required=True,
                    importance="high",
                    recommendation=f"Acquire verified practical experience with {s_clean}."
                ))

        total_req = len(matched_items) + len(missing_items)
        skill_overlap_score = round((len(matched_items) / max(total_req, 1)) * 100.0, 1)

        # 2. Experience Fit Assessment (10% weight)
        grad_year = int(student_ctx.get("grad_year", 2025) or 2025)
        cand_exp_years = max(0, 2026 - grad_year)

        if job_exp_level == "senior":
            if cand_exp_years >= 4:
                exp_score = 95.0
                exp_assessment = "Your industry tenure aligns with this senior role."
            elif cand_exp_years >= 2:
                exp_score = 60.0
                exp_assessment = "Senior role, but your experience provides viable candidacy."
            else:
                exp_score = 15.0
                exp_assessment = "Senior/lead role requiring extensive past domain tenure."
        elif job_exp_level == "mid":
            if cand_exp_years >= 2:
                exp_score = 95.0
                exp_assessment = "Direct experience match for mid-level position."
            else:
                exp_score = 65.0
                exp_assessment = "Requires 2–4 years intermediate industry experience."
        elif job_exp_level == "intern":
            exp_score = 95.0
            exp_assessment = "Targeted for student interns & trainees."
        else:
            exp_score = 90.0
            exp_assessment = "Targeted for entry-level graduates."

        # 3. Domain Compatibility Calculation (15% weight)
        domain_score, domain_assessment = cls.calculate_domain_fit(candidate_domain, job_domain)

        # 4. ATS Readiness Fit (5% weight)
        ats_fit_score = min(100.0, max(30.0, ats_score))

        # 5. Composite Non-Compensatory Formula
        if not has_resume or len(student_skills) == 0:
            # Candidate has not uploaded a resume: match is 0
            overall_match = 0.0
        elif skill_overlap_score == 0:
            # Strict Non-Compensatory Gate: If 0 technical/core skills match, score is strictly 0.0%
            overall_match = 0.0
        else:
            # Weighted multi-factor score: 70% Skill Overlap, 15% Domain, 10% Seniority, 5% ATS
            raw_score = (
                (skill_overlap_score * 0.70) +
                (domain_score * 0.15) +
                (exp_score * 0.10) +
                (ats_fit_score * 0.05)
            )

            # Apply divergence penalty if attempting to cross into completely unrelated disciplines
            if domain_score <= 10.0:
                raw_score *= 0.65

            overall_match = round(min(100.0, max(0.0, raw_score)), 1)

        breakdown = JobScoreBreakdown(
            skill_overlap_score=skill_overlap_score,
            experience_fit_score=exp_score,
            domain_fit_score=domain_score,
            ats_readiness_score=round(ats_fit_score, 1),
            overall_match=overall_match
        )

        # 6. Explainability Generation
        why_matches: List[str] = []
        if len(matched_items) > 0:
            why_matches.append(f"Demonstrated verified proficiency in {len(matched_items)}/{total_req} required skills: {', '.join([m.skill_name for m in matched_items[:3]])}.")
        else:
            why_matches.append("No direct skill overlap detected between your resume and this role's specifications.")

        why_matches.append(domain_assessment)
        if exp_score >= 85:
            why_matches.append(exp_assessment)

        missing_critical = [m.skill_name for m in missing_items[:3]]
        action_plan = [
            f"Add verified portfolio deliverables or certifications for '{m.skill_name}'." for m in missing_items[:2]
        ]
        if not action_plan:
            action_plan.append("Your skills satisfy all primary specifications. Tailor your resume summary and apply.")

        if overall_match >= 85:
            fit_text = "Strong High-Fit match"
        elif overall_match >= 65:
            fit_text = "Good compatibility match"
        else:
            fit_text = "Significant skill gap"

        summary_narrative = (
            f"Candidate exhibits a {overall_match}% compatibility score ({fit_text}) for '{job_title}'. "
            f"Matches {len(matched_items)} of {total_req} required technical criteria. "
            f"{'Bridging key gaps in ' + ', '.join(missing_critical) + ' is necessary to meet minimum eligibility.' if missing_critical else 'Candidate meets all baseline specifications.'}"
        )

        explainability_meta = {
            "summary": summary_narrative,
            "why_matches": why_matches,
            "missing_critical_gaps": missing_critical,
            "recommended_action_plan": action_plan,
            "experience_assessment": exp_assessment,
            "domain_assessment": domain_assessment
        }

        return overall_match, breakdown, matched_items, missing_items, explainability_meta

    @classmethod
    def evaluate_job_posting(
        cls,
        db: Session,
        job: JobPosting,
        student_profile: Optional[StudentProfile]
    ) -> JobPostingResponse:
        """Evaluates a JobPosting entity against the student's genuine resume and returns JobPostingResponse."""
        req_skills = job.required_skills_json or []

        student_ctx = cls.extract_student_context(db, student_profile)
        has_resume = student_ctx.get("has_resume", False)

        if student_profile and has_resume:
            score, breakdown, matched, missing, _ = cls.compute_match(
                student_ctx=student_ctx,
                job_title=job.title,
                job_domain=job.domain,
                job_exp_level=job.experience_level,
                required_skills=req_skills
            )
            badge = "High Fit" if score >= 85 else ("Good Fit" if score >= 65 else "Skill Gap")
            is_eligible = score >= 65.0
            matched_names = [m.skill_name for m in matched]
            missing_names = [m.skill_name for m in missing]
        else:
            # Unauthenticated or no resume uploaded
            score = 0.0
            badge = "Upload Resume to Match"
            is_eligible = False
            matched_names = []
            missing_names = req_skills

        return JobPostingResponse(
            id=job.id,
            source_id=job.source_id,
            source=job.source,
            title=job.title,
            company=job.company,
            location=job.location,
            remote=job.remote,
            job_type=job.job_type,
            experience_level=job.experience_level,
            domain=job.domain,
            description=job.description,
            required_skills=req_skills,
            apply_url=job.apply_url,
            salary_range=job.salary_range,
            posted_date=job.posted_date,
            last_refreshed_at=job.last_refreshed_at,
            created_at=job.created_at,
            match_score=score if has_resume else None,
            match_badge=badge,
            matched_skills=matched_names,
            missing_skills=missing_names,
            is_eligible=is_eligible
        )

    @classmethod
    def get_job_explanation(
        cls,
        db: Session,
        job: JobPosting,
        student_profile: Optional[StudentProfile]
    ) -> JobExplainResponse:
        """Returns comprehensive explainability report for a specific job posting."""
        student_ctx = cls.extract_student_context(db, student_profile)
        req_skills = job.required_skills_json or []

        score, breakdown, matched, missing, meta = cls.compute_match(
            student_ctx=student_ctx,
            job_title=job.title,
            job_domain=job.domain,
            job_exp_level=job.experience_level,
            required_skills=req_skills
        )

        return JobExplainResponse(
            job_id=job.id,
            title=job.title,
            company=job.company,
            source=job.source,
            match_score=score,
            breakdown=breakdown,
            matched_skills=matched,
            missing_skills=missing,
            summary=meta["summary"],
            why_matches=meta["why_matches"],
            missing_critical_gaps=meta["missing_critical_gaps"],
            recommended_action_plan=meta["recommended_action_plan"],
            experience_assessment=meta["experience_assessment"],
            domain_assessment=meta["domain_assessment"]
        )

    @classmethod
    def match_manual_text(
        cls,
        db: Session,
        raw_text: str,
        title: Optional[str],
        company: Optional[str],
        student_profile: Optional[StudentProfile]
    ) -> ManualJobMatchResponse:
        """Parses and computes instant explainable matching for raw pasted job description or URL content."""
        extracted_skills = JobNormalizationService.extract_required_skills(raw_text)
        exp_level = JobNormalizationService.determine_experience_level(title or "Custom Role", raw_text)
        domain = JobNormalizationService.classify_domain(title or "Professional", raw_text, extracted_skills)
        job_title = title or "Custom Job Posting"
        company_name = company or "Target Employer"

        student_ctx = cls.extract_student_context(db, student_profile)
        score, breakdown, matched, missing, meta = cls.compute_match(
            student_ctx=student_ctx,
            job_title=job_title,
            job_domain=domain,
            job_exp_level=exp_level,
            required_skills=extracted_skills
        )

        return ManualJobMatchResponse(
            title=job_title,
            company=company_name,
            domain=domain,
            extracted_skills=extracted_skills,
            experience_level=exp_level,
            match_score=score,
            breakdown=breakdown,
            matched_skills=matched,
            missing_skills=missing,
            summary=meta["summary"],
            why_matches=meta["why_matches"],
            missing_critical_gaps=meta["missing_critical_gaps"],
            recommended_action_plan=meta["recommended_action_plan"]
        )
