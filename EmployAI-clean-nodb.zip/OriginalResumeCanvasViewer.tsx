import React, { useState, useEffect, useRef, useCallback } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import type { ResumeLinkItem } from '../types';
import { 
  ZoomIn, ZoomOut, Maximize2, Download, 
  ChevronLeft, ChevronRight, ExternalLink,
  Copy, Check, ShieldCheck, 
  AlertCircle, X,
  FileText, UploadCloud, Sparkles, Eye, FileCode
} from 'lucide-react';
import { sanitizeAndFormatUrl, handleSafeLinkClick } from '../utils/urlHelper';
import { FuturisticLoader } from './FuturisticLoader';
import './ResumePreview.css';

// Configure local PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

export interface OriginalResumeCanvasViewerProps {
  file?: File | Blob | null;
  fileUrl?: string | null;
  filename?: string;
  detectedLinks?: ResumeLinkItem[];
  onDownloadOriginal?: () => void;
  rawText?: string;
  isScratch?: boolean;
  onUploadClick?: () => void;
  onFileSelected?: (file: File) => void;
}

interface PageLinkAnnotation {
  id: string;
  url: string;
  left: number;
  top: number;
  width: number;
  height: number;
  type?: string;
  label?: string;
}

const getLinkType = (url: string): string => {
  const u = url.toLowerCase();
  if (u.includes('linkedin.com')) return 'linkedin';
  if (u.includes('github.com')) return 'github';
  if (u.includes('leetcode.com')) return 'leetcode';
  if (u.includes('codeforces.com')) return 'codeforces';
  if (u.includes('codechef.com')) return 'codechef';
  if (u.includes('hackerrank.com')) return 'hackerrank';
  if (u.includes('kaggle.com')) return 'kaggle';
  if (u.startsWith('mailto:')) return 'email';
  if (u.includes('portfolio') || u.includes('.dev') || u.includes('.io') || u.includes('.me')) return 'portfolio';
  return 'other';
};

const getLinkIcon = (type: string) => {
  switch (type) {
    case 'linkedin': return '💼';
    case 'github': return '🐙';
    case 'leetcode': return '⚡';
    case 'codeforces':
    case 'codechef':
    case 'hackerrank': return '💻';
    case 'kaggle': return '📊';
    case 'email': return '✉️';
    case 'portfolio': return '🌐';
    default: return '🔗';
  }
};

interface OriginalPdfPageCanvasProps {
  pdfDoc: any;
  pageNum: number;
  zoom: number;
  baseWidth: number;
  baseHeight: number;
}

/**
 * High-performance, crash-proof PDF Page Canvas.
 * - Key is stable across zoom changes (never remounts or leaks memory).
 * - Instant CSS scaling provides 60fps responsive zoom immediately.
 * - Debounces PDF.js vector rasterization so fast clicking doesn't block CPU.
 * - Caps DPR at 2.0 to prevent multi-megapixel memory spikes.
 */
const OriginalPdfPageCanvas: React.FC<OriginalPdfPageCanvasProps> = React.memo(({
  pdfDoc,
  pageNum,
  zoom,
  baseWidth,
  baseHeight
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const renderTaskRef = useRef<any>(null);
  const [pageAnnotations, setPageAnnotations] = useState<PageLinkAnnotation[]>([]);

  useEffect(() => {
    let isCancelled = false;
    let debounceTimer: any = null;

    const renderPage = async () => {
      if (!pdfDoc || !canvasRef.current) return;

      try {
        if (renderTaskRef.current) {
          try {
            renderTaskRef.current.cancel();
          } catch {}
          renderTaskRef.current = null;
        }

        const page = await pdfDoc.getPage(pageNum);
        if (isCancelled) return;

        const viewport = page.getViewport({ scale: zoom });
        const canvas = canvasRef.current;
        if (!canvas) return;

        // Cap DPR at 2.0 to protect GPU memory and prevent tab freezes
        const dpr = Math.min(window.devicePixelRatio || 1.5, 2.0);
        const targetWidth = Math.max(1, Math.floor(viewport.width * dpr));
        const targetHeight = Math.max(1, Math.floor(viewport.height * dpr));

        if (canvas.width !== targetWidth || canvas.height !== targetHeight) {
          canvas.width = targetWidth;
          canvas.height = targetHeight;
        }

        canvas.style.width = '100%';
        canvas.style.height = '100%';

        const ctx = canvas.getContext('2d', { alpha: false });
        if (!ctx) return;

        ctx.save();
        ctx.scale(dpr, dpr);

        const renderContext = {
          canvasContext: ctx,
          viewport: viewport,
        };

        const task = page.render(renderContext);
        renderTaskRef.current = task;
        await task.promise;
        ctx.restore();

        // Extract clickable link annotations safely
        try {
          const annotations = await page.getAnnotations();
          if (!isCancelled && annotations && annotations.length > 0) {
            const extractedLinks: PageLinkAnnotation[] = [];
            for (let i = 0; i < annotations.length; i++) {
              const annot = annotations[i];
              if (annot.subtype === 'Link') {
                let targetUrl = annot.url || '';
                if (!targetUrl && annot.dest) {
                  targetUrl = typeof annot.dest === 'string' ? annot.dest : '';
                }

                if (targetUrl && annot.rect) {
                  const viewRect = viewport.convertToViewportRectangle(annot.rect);
                  const left = Math.min(viewRect[0], viewRect[2]);
                  const top = Math.min(viewRect[1], viewRect[3]);
                  const width = Math.abs(viewRect[0] - viewRect[2]);
                  const height = Math.abs(viewRect[1] - viewRect[3]);

                  if (width > 0 && height > 0) {
                    extractedLinks.push({
                      id: `annot-${pageNum}-${i}`,
                      url: targetUrl.startsWith('http') || targetUrl.startsWith('mailto:') || targetUrl.startsWith('tel:') ? targetUrl : `https://${targetUrl}`,
                      left,
                      top,
                      width,
                      height,
                      type: getLinkType(targetUrl),
                      label: targetUrl
                    });
                  }
                }
              }
            }
            setPageAnnotations(extractedLinks);
          }
        } catch {}
      } catch (err: any) {
        if (err?.name !== 'RenderingCancelledException') {
          console.warn(`[OriginalResumeCanvasViewer] Page ${pageNum} render notice:`, err);
        }
      }
    };

    // Debounce vector rasterization by 50ms to allow smooth rapid zooming
    debounceTimer = setTimeout(() => {
      renderPage();
    }, 50);

    return () => {
      isCancelled = true;
      if (debounceTimer) clearTimeout(debounceTimer);
      if (renderTaskRef.current) {
        try {
          renderTaskRef.current.cancel();
        } catch {}
        renderTaskRef.current = null;
      }
    };
  }, [pdfDoc, pageNum, zoom]);

  const targetWidth = Math.round(baseWidth * zoom);
  const targetHeight = Math.round(baseHeight * zoom);

  return (
    <div 
      id={`original-pdf-page-${pageNum}`}
      data-page-num={pageNum}
      className="original-pdf-canvas-wrapper"
      style={{
        position: 'relative',
        width: `${targetWidth}px`,
        height: `${targetHeight}px`,
        maxWidth: '100%',
        margin: '0 auto 1.5rem auto',
        boxShadow: '0 12px 40px -6px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.08)',
        borderRadius: '4px',
        backgroundColor: '#ffffff',
        transition: 'width 0.15s ease-out, height 0.15s ease-out',
        touchAction: 'pan-y pan-x'
      }}
    >
      <canvas 
        ref={canvasRef} 
        className="original-pdf-canvas"
        style={{
          display: 'block',
          width: '100%',
          height: '100%',
          borderRadius: '4px',
          touchAction: 'pan-y pan-x'
        }}
      />

      {/* Clickable Link Annotations Layer */}
      {pageAnnotations.length > 0 && (
        <div 
          className="pdf-clickable-annotations-layer"
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            pointerEvents: 'none',
            zIndex: 5
          }}
        >
          {pageAnnotations.map((annot) => (
            <a
              key={annot.id}
              href={sanitizeAndFormatUrl(annot.url)}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => handleSafeLinkClick(e, annot.url)}
              className="pdf-link-annotation-anchor"
              style={{
                position: 'absolute',
                left: `${annot.left}px`,
                top: `${annot.top}px`,
                width: `${annot.width}px`,
                height: `${annot.height}px`,
                pointerEvents: 'auto',
                cursor: 'pointer'
              }}
              title={`Open link: ${annot.url}`}
            >
              <span className="pdf-link-annotation-glow" />
            </a>
          ))}
        </div>
      )}
    </div>
  );
});

export const OriginalResumeCanvasViewer: React.FC<OriginalResumeCanvasViewerProps> = ({
  file,
  fileUrl,
  filename = 'Uploaded_Resume.pdf',
  detectedLinks = [],
  onDownloadOriginal,
  rawText,
  isScratch = false,
  onUploadClick,
  onFileSelected
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const deskScrollRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [pdfDoc, setPdfDoc] = useState<any>(null);
  const [numPages, setNumPages] = useState<number>(1);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [zoom, setZoom] = useState<number>(1.0);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [renderError, setRenderError] = useState<string | null>(null);
  const [pageBaseDim, setPageBaseDim] = useState<{ width: number; height: number }>({ width: 794, height: 1123 });
  const [isPdf, setIsPdf] = useState<boolean>(true);
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'canvas' | 'native'>('canvas');
  const [isDraggingOver, setIsDraggingOver] = useState<boolean>(false);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const [showLinksModal, setShowLinksModal] = useState<boolean>(false);

  // Generate safe blob URL for native PDF preview & download
  useEffect(() => {
    if (file instanceof Blob) {
      const url = URL.createObjectURL(file);
      setBlobUrl(url);
      return () => {
        URL.revokeObjectURL(url);
      };
    } else if (fileUrl) {
      setBlobUrl(fileUrl);
    } else {
      setBlobUrl(null);
    }
  }, [file, fileUrl]);

  // Load and parse PDF Document
  const loadPdfDocument = useCallback(async () => {
    if (isScratch || (!file && !fileUrl)) {
      setIsLoading(false);
      setPdfDoc(null);
      setRenderError(null);
      return;
    }

    setIsLoading(true);
    setRenderError(null);

    try {
      let docData: ArrayBuffer | null = null;

      if (file) {
        docData = await file.arrayBuffer();
      } else if (fileUrl) {
        const token = localStorage.getItem('employai_token');
        const headers: Record<string, string> = {};
        if (token) headers['Authorization'] = `Bearer ${token}`;
        const res = await fetch(fileUrl, { headers });
        if (!res.ok) throw new Error(`Failed to load document (${res.statusText})`);
        docData = await res.arrayBuffer();
      }

      if (!docData || docData.byteLength === 0) {
        throw new Error('No valid document binary stream available.');
      }

      // Check for valid PDF (%PDF header)
      const headerBytes = new Uint8Array(docData.slice(0, 5));
      const headerStr = String.fromCharCode(...headerBytes);
      if (!headerStr.startsWith('%PDF')) {
        setIsPdf(false);
        setPdfDoc(null);
        setIsLoading(false);
        return;
      }

      setIsPdf(true);
      const loadingTask = pdfjsLib.getDocument({ data: docData });
      const loadedDoc = await loadingTask.promise;
      setPdfDoc(loadedDoc);
      setNumPages(loadedDoc.numPages);
      setCurrentPage(1);

      // Measure unscaled dimensions of Page 1 once
      try {
        const p1 = await loadedDoc.getPage(1);
        const vp = p1.getViewport({ scale: 1.0 });
        if (vp.width && vp.height) {
          setPageBaseDim({ width: Math.round(vp.width), height: Math.round(vp.height) });
        }
      } catch {}
    } catch (err: any) {
      console.warn('[OriginalResumeCanvasViewer] PDF render notice:', err);
      setRenderError(err?.message || 'Unable to parse document binary.');
    } finally {
      setIsLoading(false);
    }
  }, [file, fileUrl, isScratch]);

  useEffect(() => {
    loadPdfDocument();
  }, [loadPdfDocument]);

  // Stable IntersectionObserver to update page indicator on scroll without re-render loop
  useEffect(() => {
    if (numPages <= 1 || !deskScrollRef.current) return;
    const desk = deskScrollRef.current;
    const observer = new IntersectionObserver((entries) => {
      let bestPage = 0;
      let maxRatio = 0;
      entries.forEach(entry => {
        if (entry.isIntersecting && entry.intersectionRatio > maxRatio) {
          maxRatio = entry.intersectionRatio;
          const pStr = entry.target.getAttribute('data-page-num');
          if (pStr) bestPage = parseInt(pStr, 10);
        }
      });
      if (bestPage && maxRatio > 0.2) {
        setCurrentPage(prev => (prev !== bestPage ? bestPage : prev));
      }
    }, {
      root: desk,
      threshold: [0.2, 0.5]
    });

    const pageCards = desk.querySelectorAll('.original-pdf-canvas-wrapper');
    pageCards.forEach(c => observer.observe(c));

    return () => observer.disconnect();
  }, [numPages, pdfDoc]);

  // Smooth scroll to target page
  const handleScrollToPage = (targetPage: number) => {
    const clamped = Math.max(1, Math.min(numPages, targetPage));
    setCurrentPage(clamped);
    const targetEl = document.getElementById(`original-pdf-page-${clamped}`);
    if (targetEl) {
      targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Safe Fit Width calculation based on measured page 1 width
  const handleFitWidth = () => {
    if (deskScrollRef.current) {
      const containerWidth = deskScrollRef.current.clientWidth - 48;
      const targetScale = Math.min(1.5, Math.max(0.4, containerWidth / (pageBaseDim.width || 794)));
      setZoom(Number(targetScale.toFixed(2)));
    }
  };

  const copyToClipboard = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(url);
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  // Handlers for genuine file upload / replace
  const handleTriggerUpload = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    } else if (onUploadClick) {
      onUploadClick();
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) {
      if (onFileSelected) {
        onFileSelected(selected);
      } else if (onUploadClick) {
        onUploadClick();
      }
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(true);
  };

  const handleDragLeave = () => {
    setIsDraggingOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
    const dropped = e.dataTransfer.files?.[0];
    if (dropped) {
      if (onFileSelected) {
        onFileSelected(dropped);
      } else if (onUploadClick) {
        onUploadClick();
      }
    }
  };

  // All supported zoom presets including 75% and 80%
  const zoomPresets = [0.5, 0.75, 0.8, 0.9, 1.0, 1.25];
  const isNoOriginalData = isScratch || (!file && !fileUrl);
  const isWordOrText = !isPdf && (rawText || file || fileUrl);

  return (
    <div 
      className="resume-preview-container original-canvas-mode" 
      ref={containerRef} 
      id="original-resume-viewer"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      style={{ position: 'relative' }}
    >
      {/* Hidden file input for direct document uploading / replacement */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileInputChange}
        accept=".pdf,.docx,.doc,.txt"
        style={{ display: 'none' }}
      />

      {/* Drag & Drop Overlay */}
      {isDraggingOver && (
        <div style={{
          position: 'absolute',
          inset: 0,
          background: 'rgba(3, 7, 18, 0.85)',
          backdropFilter: 'blur(8px)',
          border: '2px dashed #00f2fe',
          borderRadius: '12px',
          zIndex: 100,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0.85rem',
          color: '#38bdf8'
        }}>
          <UploadCloud size={48} className="animate-bounce" />
          <strong style={{ fontSize: '1.1rem' }}>Drop Document to Upload &amp; Inspect</strong>
          <span style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Supports PDF, Word (.docx), and Plain Text</span>
        </div>
      )}

      {/* 1. Header Toolbar */}
      <div className="resume-preview-toolbar no-print">
        {/* Left: Document Status & Title */}
        <div className="resume-toolbar-group">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
            {isScratch ? (
              <span className="badge" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.75rem', fontWeight: 700, color: '#38bdf8', background: 'rgba(56, 189, 248, 0.12)', border: '1px solid rgba(56, 189, 248, 0.25)', padding: '0.2rem 0.6rem', borderRadius: '6px' }}>
                <Sparkles size={13} color="#38bdf8" /> Created From Scratch
              </span>
            ) : isNoOriginalData ? (
              <span className="badge" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-muted)', background: 'rgba(255, 255, 255, 0.05)', padding: '0.2rem 0.6rem', borderRadius: '6px' }}>
                <FileText size={13} /> No Uploaded File
              </span>
            ) : (
              <span className="badge-original-document" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.75rem', fontWeight: 700, color: '#38bdf8' }}>
                <ShieldCheck size={14} color="#10b981" /> 100% Authentic Uploaded Resume
              </span>
            )}
            <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={filename}>
              {filename}
            </span>
          </div>
        </div>

        {/* Center & Right: Navigation, Zoom & Actions */}
        <div className="resume-toolbar-group" style={{ flexWrap: 'wrap', gap: '0.4rem' }}>
          {isNoOriginalData ? (
            <button
              type="button"
              onClick={handleTriggerUpload}
              className="btn btn-primary btn-sm"
              style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}
            >
              <UploadCloud size={13} /> Upload Original File
            </button>
          ) : (
            <>
              {/* Multi-page Navigation */}
              {isPdf && numPages > 1 && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.2rem', background: 'var(--bg-tertiary)', borderRadius: '6px', border: '1px solid var(--border-subtle)', padding: '0.1rem 0.35rem' }}>
                  <button
                    type="button"
                    onClick={() => handleScrollToPage(currentPage - 1)}
                    disabled={currentPage <= 1}
                    className="resume-zoom-btn"
                    style={{ border: 'none', background: 'transparent', padding: '0.2rem' }}
                    title="Previous Page"
                  >
                    <ChevronLeft size={13} />
                  </button>
                  <span style={{ fontSize: '0.72rem', fontWeight: 700, padding: '0 0.25rem', color: 'var(--text-primary)' }}>
                    Page {currentPage} of {numPages}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleScrollToPage(currentPage + 1)}
                    disabled={currentPage >= numPages}
                    className="resume-zoom-btn"
                    style={{ border: 'none', background: 'transparent', padding: '0.2rem' }}
                    title="Next Page"
                  >
                    <ChevronRight size={13} />
                  </button>
                </div>
              )}

              {/* Detected Links Dropdown Toggle */}
              {detectedLinks.length > 0 && (
                <button
                  type="button"
                  onClick={() => setShowLinksModal(!showLinksModal)}
                  className={`btn btn-sm ${showLinksModal ? 'btn-primary' : 'btn-secondary'}`}
                  style={{ fontSize: '0.72rem', padding: '0.25rem 0.5rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
                  title="View links detected in original resume"
                >
                  <ExternalLink size={12} />
                  <span>Links ({detectedLinks.length})</span>
                </button>
              )}

              {/* View Mode Toggle: Canvas vs Native PDF */}
              {isPdf && blobUrl && (
                <div style={{ display: 'flex', alignItems: 'center', background: 'var(--bg-tertiary)', borderRadius: '6px', border: '1px solid var(--border-subtle)', padding: '0.05rem' }}>
                  <button
                    type="button"
                    onClick={() => setViewMode('canvas')}
                    className={`resume-zoom-btn ${viewMode === 'canvas' ? 'active' : ''}`}
                    style={{ border: 'none', background: viewMode === 'canvas' ? 'rgba(56, 189, 248, 0.2)' : 'transparent', padding: '0.2rem 0.4rem', fontSize: '0.68rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                    title="Interactive Canvas Viewer with verified link anchors"
                  >
                    <Eye size={11} /> Vector
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode('native')}
                    className={`resume-zoom-btn ${viewMode === 'native' ? 'active' : ''}`}
                    style={{ border: 'none', background: viewMode === 'native' ? 'rgba(56, 189, 248, 0.2)' : 'transparent', padding: '0.2rem 0.4rem', fontSize: '0.68rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                    title="Browser Native PDF reader with built-in search and print"
                  >
                    <FileCode size={11} /> Native
                  </button>
                </div>
              )}

              {/* Zoom Out */}
              {viewMode === 'canvas' && (
                <button
                  type="button"
                  onClick={() => setZoom(prev => Math.max(0.4, Number((prev - 0.1).toFixed(2))))}
                  className="resume-zoom-btn"
                  style={{ padding: '0.25rem 0.45rem' }}
                  title="Zoom Out"
                >
                  <ZoomOut size={13} />
                </button>
              )}

              {/* Zoom Presets: 50%, 75%, 80%, 90%, 100%, 125% */}
              {viewMode === 'canvas' && (
                <div style={{ display: 'flex', alignItems: 'center', background: 'var(--bg-tertiary)', borderRadius: '6px', border: '1px solid var(--border-subtle)', padding: '0.05rem' }}>
                  {zoomPresets.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setZoom(preset)}
                      className={`resume-zoom-btn ${zoom === preset ? 'active' : ''}`}
                      style={{ border: 'none', background: zoom === preset ? 'rgba(56, 189, 248, 0.2)' : 'transparent', padding: '0.2rem 0.35rem', fontSize: '0.68rem' }}
                    >
                      {Math.round(preset * 100)}%
                    </button>
                  ))}
                </div>
              )}

              {/* Zoom In */}
              {viewMode === 'canvas' && (
                <button
                  type="button"
                  onClick={() => setZoom(prev => Math.min(1.5, Number((prev + 0.1).toFixed(2))))}
                  className="resume-zoom-btn"
                  style={{ padding: '0.25rem 0.45rem' }}
                  title="Zoom In"
                >
                  <ZoomIn size={13} />
                </button>
              )}

              {/* Fit Width */}
              {viewMode === 'canvas' && (
                <button
                  type="button"
                  onClick={handleFitWidth}
                  className="resume-zoom-btn"
                  title="Fit Document to Screen Width"
                  style={{ fontSize: '0.72rem', padding: '0.25rem 0.5rem' }}
                >
                  <Maximize2 size={12} />
                  <span>Fit Width</span>
                </button>
              )}

              {/* Direct Upload / Replace Document Button */}
              <button
                type="button"
                onClick={handleTriggerUpload}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.72rem', padding: '0.25rem 0.55rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
                title="Upload another document or replace current resume"
              >
                <UploadCloud size={12} /> Replace File
              </button>

              {/* Download Original Document */}
              {(blobUrl || onDownloadOriginal) && (
                <button
                  type="button"
                  onClick={() => {
                    if (onDownloadOriginal) {
                      onDownloadOriginal();
                    } else if (blobUrl) {
                      const a = document.createElement('a');
                      a.href = blobUrl;
                      a.download = filename;
                      a.click();
                    }
                  }}
                  className="btn btn-primary btn-sm"
                  style={{ fontSize: '0.72rem', padding: '0.25rem 0.6rem' }}
                  title="Download exact original uploaded file"
                >
                  <Download size={12} /> Original PDF
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Detected Links Popover */}
      {!isNoOriginalData && showLinksModal && detectedLinks.length > 0 && (
        <div style={{
          background: 'var(--bg-modal)',
          borderBottom: '1px solid var(--border-glass)',
          backdropFilter: 'blur(12px)',
          padding: '0.65rem 1rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.4rem',
          zIndex: 20
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--accent-cyan)' }}>
              Detected Verified Links ({detectedLinks.length}):
            </span>
            <button
              type="button"
              onClick={() => setShowLinksModal(false)}
              style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', padding: '0.1rem' }}
            >
              <X size={14} />
            </button>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem', maxHeight: '120px', overflowY: 'auto' }}>
            {detectedLinks.map((link, idx) => {
              const icon = getLinkIcon(link.type || 'other');
              const isCopied = copiedUrl === link.url;
              return (
                <div
                  key={idx}
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.35rem',
                    padding: '0.2rem 0.5rem',
                    borderRadius: '6px',
                    background: 'rgba(255, 255, 255, 0.05)',
                    border: '1px solid var(--border-subtle)',
                    fontSize: '0.72rem'
                  }}
                >
                  <span>{icon}</span>
                  <a
                    href={sanitizeAndFormatUrl(link.url)}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => handleSafeLinkClick(e, link.url)}
                    style={{ color: '#38bdf8', textDecoration: 'none', fontWeight: 600 }}
                  >
                    {link.label || link.url}
                  </a>
                  <ExternalLink size={10} color="#94a3b8" />
                  <button
                    type="button"
                    onClick={() => copyToClipboard(link.url)}
                    style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', padding: '0.1rem' }}
                    title="Copy URL"
                  >
                    {isCopied ? <Check size={11} color="#10b981" /> : <Copy size={11} />}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Main Document Workspace */}
      <div className="resume-desk-scroll-area" ref={deskScrollRef}>
        {isNoOriginalData ? (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '480px', padding: '3rem 1.5rem' }}>
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '3rem 2.5rem',
              textAlign: 'center',
              maxWidth: '520px',
              margin: 'auto',
              background: 'rgba(15, 23, 42, 0.65)',
              backdropFilter: 'blur(16px)',
              border: '1px dashed rgba(56, 189, 248, 0.25)',
              borderRadius: '16px',
              boxShadow: '0 20px 40px -15px rgba(0, 0, 0, 0.5)'
            }}>
              <div style={{
                width: '64px',
                height: '64px',
                borderRadius: '50%',
                background: 'radial-gradient(circle, rgba(56, 189, 248, 0.18) 0%, rgba(56, 189, 248, 0.04) 70%)',
                border: '1px solid rgba(56, 189, 248, 0.25)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '1.25rem',
                color: 'var(--accent-cyan)'
              }}>
                <FileText size={32} />
              </div>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.5rem' }}>
                No Original Resume Data
              </h3>
              <p style={{ fontSize: '0.85rem', lineHeight: '1.6', color: 'var(--text-secondary)', marginBottom: '1.5rem', maxWidth: '420px' }}>
                {isScratch 
                  ? "This resume was crafted from scratch directly inside Employ.AI's interactive builder. Because it was created without an uploaded document, there is no original document source to display."
                  : "No original document file has been uploaded yet. Upload your PDF or Word resume to inspect the genuine original file."
                }
              </p>
              <button
                type="button"
                onClick={handleTriggerUpload}
                className="btn btn-primary btn-sm"
                style={{ display: 'inline-flex', alignItems: 'center', gap: '0.45rem', padding: '0.5rem 1.25rem', fontSize: '0.82rem', fontWeight: 600 }}
              >
                <UploadCloud size={15} /> Upload Resume Document
              </button>
            </div>
          </div>
        ) : isWordOrText ? (
          /* Authentic Word / Text Document Reading Mode */
          <div style={{ maxWidth: '820px', margin: '2rem auto', padding: '2rem', background: '#ffffff', color: '#0f172a', borderRadius: '8px', boxShadow: '0 10px 30px rgba(0,0,0,0.3)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #e2e8f0', paddingBottom: '1rem', marginBottom: '1.5rem' }}>
              <div>
                <span className="badge badge-cyan" style={{ fontSize: '0.7rem', marginBottom: '0.3rem' }}>
                  Original Word / Text Document
                </span>
                <h3 style={{ fontSize: '1.2rem', fontWeight: 800, margin: 0, color: '#0f172a' }}>{filename}</h3>
              </div>
              <button
                type="button"
                onClick={handleTriggerUpload}
                className="btn btn-secondary btn-sm"
              >
                <UploadCloud size={13} /> Replace Document
              </button>
            </div>
            <div style={{ whiteSpace: 'pre-wrap', lineHeight: 1.7, fontSize: '0.9rem', color: '#334155', fontFamily: 'system-ui, sans-serif' }}>
              {rawText || 'Document content extracted.'}
            </div>
          </div>
        ) : viewMode === 'native' && blobUrl ? (
          /* Browser Native PDF Preview (Embed/Iframe) */
          <div style={{ width: '100%', height: 'calc(100vh - 220px)', minHeight: '650px', padding: '0.5rem' }}>
            <iframe
              src={blobUrl}
              title="Native PDF Preview"
              style={{
                width: '100%',
                height: '100%',
                border: 'none',
                borderRadius: '8px',
                background: '#ffffff'
              }}
            />
          </div>
        ) : (
          /* High-Fidelity Vector Canvas Mode */
          <>
            {isLoading && (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '3.5rem 2rem' }}>
                <FuturisticLoader
                  size="md"
                  icon="sparkles"
                  title="Rendering Original Vector Resume..."
                  subtitle="Calculating precise vector layout and interactive click anchors"
                />
              </div>
            )}

            {renderError && (
              <div style={{ maxWidth: '580px', margin: '2rem auto', background: 'rgba(239, 68, 68, 0.08)', border: '1px solid rgba(239, 68, 68, 0.3)', borderRadius: '8px', padding: '1.25rem', textAlign: 'center' }}>
                <AlertCircle size={24} color="#f87171" style={{ margin: '0 auto 0.5rem auto' }} />
                <h4 style={{ color: '#f87171', margin: '0 0 0.4rem 0', fontSize: '0.95rem' }}>PDF Canvas Notice</h4>
                <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', margin: '0 0 0.8rem 0' }}>{renderError}</p>
                <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'center' }}>
                  <button
                    type="button"
                    onClick={handleTriggerUpload}
                    className="btn btn-primary btn-sm"
                  >
                    <UploadCloud size={13} /> Upload Another File
                  </button>
                  {blobUrl && (
                    <button
                      type="button"
                      onClick={() => setViewMode('native')}
                      className="btn btn-secondary btn-sm"
                    >
                      <Eye size={13} /> View Native PDF
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Continuous Multi-Page Pre-rendered Canvas Container */}
            {!isLoading && !renderError && pdfDoc && (
              <div 
                className="original-pdf-pages-container"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  width: '100%',
                  padding: '1.5rem 0',
                  touchAction: 'pan-y pan-x'
                }}
              >
                {Array.from({ length: numPages }, (_, i) => i + 1).map((pNum) => (
                  <OriginalPdfPageCanvas
                    key={`original-pdf-page-${pNum}`}
                    pdfDoc={pdfDoc}
                    pageNum={pNum}
                    zoom={zoom}
                    baseWidth={pageBaseDim.width}
                    baseHeight={pageBaseDim.height}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default OriginalResumeCanvasViewer;
