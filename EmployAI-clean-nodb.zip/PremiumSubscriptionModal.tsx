import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { useAuth } from '../context/AuthContext';
import { useRazorpay } from '../hooks/useRazorpay';
import type { SubscriptionPlanType } from '../services/api';
import {
  X, CheckCircle, Sparkles,
  AlertCircle, Check, ShieldCheck,
  CreditCard, Calendar
} from 'lucide-react';

export interface PremiumSubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetFeature?: string;
}

export const PremiumSubscriptionModal: React.FC<PremiumSubscriptionModalProps> = ({
  isOpen,
  onClose,
  targetFeature
}) => {
  const { user, checkSubscription } = useAuth();

  // Plan Selection: 'monthly' (₹49 / 30 days) vs 'annual' (₹499 / 365 days)
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlanType>('monthly');

  // -- Razorpay hook state --
  const [rzpSuccess, setRzpSuccess] = useState<string | null>(null);
  const { startPayment, isLoading: rzpLoading, error: rzpError, setError: setRzpError } = useRazorpay({
    targetFeature: targetFeature || 'all',
    planType: selectedPlan,
    onSuccess: async (data) => {
      if (data.is_premium) {
        try {
          confetti({
            particleCount: 100,
            spread: 80,
            origin: { y: 0.5 },
            colors: ['#00f2fe', '#38bdf8', '#10b981', '#fbbf24', '#ffffff']
          });
        } catch {}
        setRzpSuccess(`🎉 Payment verified! Your ${selectedPlan === 'annual' ? 'Annual (365 Days)' : 'Monthly (30 Days)'} PRO access is now active.`);
        await checkSubscription();
        setTimeout(() => onClose(), 2200);
      }
    },
    onDismiss: () => {
      // user closed the Razorpay modal
    },
  });

  if (!isOpen) return null;

  const handleRazorpayPay = async () => {
    setRzpError(null);
    await startPayment(selectedPlan);
  };

  const isAnnual = selectedPlan === 'annual';
  const planPriceDisplay = isAnnual ? '₹499' : '₹49';

  const features = [
    { title: 'AI Mock Interview Simulator', desc: 'Voice AI with STAR scoring & real-time feedback' },
    { title: 'Placement Level Roadmap', desc: 'Personalized multi-week plan with milestones' },
    { title: 'Jobs & Internships Portal', desc: '10+ platforms, fit-scoring, direct apply' },
    { title: 'Tailor to Job AI Panel', desc: 'JD keyword match & ATS score boost (+32%)' },
  ];

  return (
    <div className="pro-modal-overlay" onClick={onClose}>
      <div className="pro-modal-card" onClick={(e) => e.stopPropagation()}>
        {/* Close Button */}
        <button
          onClick={onClose}
          type="button"
          aria-label="Close"
          className="pro-modal-close-btn"
        >
          <X size={18} />
        </button>

        {/* Modal Header */}
        <div style={{ textAlign: 'center', marginBottom: '1.25rem' }}>
          <div className="pro-modal-badge">
            <Sparkles size={14} />
            <span>Employ.AI PRO Membership</span>
          </div>
          <h2 className="pro-modal-title" style={{ fontSize: '1.5rem', marginTop: '0.4rem', marginBottom: '0.35rem' }}>
            {user?.is_expired ? 'Renew Your PRO Subscription' : 'Choose Your Subscription Plan'}
          </h2>
          <p className="pro-modal-subtitle" style={{ fontSize: '0.825rem', maxWidth: '440px', margin: '0 auto' }}>
            {targetFeature
              ? `Unlocking ${targetFeature} requires an active PRO subscription.`
              : 'Unlimited access to all AI career tools, interviews, roadmaps, and portals.'}
          </p>
        </div>

        {/* Expired Subscription Notice */}
        {user?.is_expired && (
          <div style={{
            margin: '0 auto 1.1rem auto',
            maxWidth: '460px',
            width: '100%',
            padding: '0.65rem 1rem',
            borderRadius: '10px',
            background: 'rgba(245, 158, 11, 0.12)',
            border: '1px solid rgba(245, 158, 11, 0.45)',
            color: '#fbbf24',
            fontSize: '0.8rem',
            fontWeight: 700,
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            textAlign: 'left'
          }}>
            <AlertCircle size={18} style={{ flexShrink: 0 }} />
            <span>
              Your previous PRO subscription has expired. Select Monthly (₹49) or Annual (₹499) to renew immediately.
            </span>
          </div>
        )}

        {/* ============================================================== */}
        {/* DUAL PLAN SELECTOR: Monthly (₹49) vs Annual (₹499)            */}
        {/* ============================================================== */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: '0.85rem',
          width: '100%',
          marginBottom: '1.25rem'
        }}>
          {/* Option 1: Monthly Plan */}
          <div
            onClick={() => setSelectedPlan('monthly')}
            style={{
              cursor: 'pointer',
              padding: '1rem',
              borderRadius: '14px',
              border: !isAnnual ? '2px solid var(--accent-cyan)' : '1px solid rgba(255,255,255,0.12)',
              background: !isAnnual
                ? 'linear-gradient(135deg, rgba(56, 189, 248, 0.12), rgba(14, 165, 233, 0.05))'
                : 'rgba(255, 255, 255, 0.03)',
              boxShadow: !isAnnual ? '0 0 18px rgba(56, 189, 248, 0.22)' : 'none',
              transition: 'all 0.2s ease',
              position: 'relative'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
              <span style={{
                fontSize: '0.7rem',
                fontWeight: 800,
                textTransform: 'uppercase',
                letterSpacing: '0.06em',
                color: !isAnnual ? 'var(--accent-cyan)' : 'var(--text-muted)'
              }}>
                Monthly Charge
              </span>
              <span style={{
                fontSize: '0.68rem',
                padding: '0.15rem 0.5rem',
                borderRadius: '999px',
                background: 'rgba(56, 189, 248, 0.15)',
                color: 'var(--accent-cyan)',
                fontWeight: 700
              }}>
                30 Days
              </span>
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.35rem', marginBottom: '0.2rem' }}>
              <span style={{ fontSize: '1.75rem', fontWeight: 900, color: 'var(--text-primary)' }}>₹49</span>
              <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>/ month</span>
            </div>
            <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', margin: 0, lineHeight: 1.35 }}>
              Active for 30 days. Perfect for fast interview preparation and instant job unlocks.
            </p>
          </div>

          {/* Option 2: Annual Plan */}
          <div
            onClick={() => setSelectedPlan('annual')}
            style={{
              cursor: 'pointer',
              padding: '1rem',
              borderRadius: '14px',
              border: isAnnual ? '2px solid #10b981' : '1px solid rgba(255,255,255,0.12)',
              background: isAnnual
                ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.14), rgba(5, 150, 105, 0.06))'
                : 'rgba(255, 255, 255, 0.03)',
              boxShadow: isAnnual ? '0 0 18px rgba(16, 185, 129, 0.25)' : 'none',
              transition: 'all 0.2s ease',
              position: 'relative'
            }}
          >
            <div style={{
              position: 'absolute',
              top: '-10px',
              right: '12px',
              background: 'linear-gradient(135deg, #10b981, #059669)',
              color: '#ffffff',
              fontSize: '0.62rem',
              fontWeight: 800,
              padding: '0.15rem 0.6rem',
              borderRadius: '999px',
              boxShadow: '0 2px 8px rgba(16, 185, 129, 0.4)',
              textTransform: 'uppercase',
              letterSpacing: '0.04em'
            }}>
              ⭐ Best Value · Save 15%
            </div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
              <span style={{
                fontSize: '0.7rem',
                fontWeight: 800,
                textTransform: 'uppercase',
                letterSpacing: '0.06em',
                color: isAnnual ? '#34d399' : 'var(--text-muted)'
              }}>
                Annual Charge
              </span>
              <span style={{
                fontSize: '0.68rem',
                padding: '0.15rem 0.5rem',
                borderRadius: '999px',
                background: 'rgba(16, 185, 129, 0.15)',
                color: '#34d399',
                fontWeight: 700
              }}>
                365 Days
              </span>
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.35rem', marginBottom: '0.2rem' }}>
              <span style={{ fontSize: '1.75rem', fontWeight: 900, color: 'var(--text-primary)' }}>₹499</span>
              <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>/ year</span>
            </div>
            <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', margin: 0, lineHeight: 1.35 }}>
              Full 365 days coverage. Less than ₹42/month for complete placement season success.
            </p>
          </div>
        </div>

        {/* Feature grid */}
        <div className="pro-modal-feature-grid" style={{ marginBottom: '1.25rem' }}>
          {features.map((item, idx) => (
            <div key={idx} className="pro-modal-feature-card">
              <div className="pro-modal-feature-check">
                <Check size={12} strokeWidth={3} />
              </div>
              <div>
                <strong className="pro-modal-feature-title">{item.title}</strong>
                <span className="pro-modal-feature-desc">{item.desc}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Razorpay Checkout Section */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.85rem', width: '100%' }}>
          <div className="pro-modal-checkout-card" style={{ padding: '1.25rem' }}>
            {/* Logo strip */}
            <div className="pro-modal-checkout-header" style={{ marginBottom: '0.85rem' }}>
              <div style={{
                width: '36px', height: '36px', borderRadius: '10px',
                background: 'linear-gradient(135deg, #072654, #3395FF)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.1rem', fontWeight: 900, color: '#fff',
                boxShadow: '0 4px 12px rgba(51, 149, 255, 0.3)'
              }}>R</div>
              <div>
                <div className="pro-modal-checkout-title">Razorpay Official Checkout</div>
                <div className="pro-modal-checkout-subtitle">UPI • Cards • Netbanking • Wallets</div>
              </div>
              <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.72rem', color: '#10b981', fontWeight: 700 }}>
                <ShieldCheck size={14} /> 256-Bit SSL
              </div>
            </div>

            {/* Selected Plan Summary Box */}
            <div className="pro-modal-price-box" style={{ padding: '0.85rem 1rem', marginBottom: '1rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                <span className="pro-modal-price-val">{planPriceDisplay}</span>
                <span style={{ fontSize: '0.9rem', color: 'var(--text-muted)', fontWeight: 600 }}>{isAnnual ? '/ year' : '/ month'}</span>
              </div>
              <div className="pro-modal-price-sub" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem', marginTop: '0.35rem' }}>
                <Calendar size={13} color="var(--accent-cyan)" />
                <span>Validity: <strong>{isAnnual ? '365 Days' : '30 Days'}</strong> · Auto-analyzed access</span>
              </div>
            </div>

            {/* Payment methods chips */}
            <div className="pro-modal-chips-row" style={{ marginBottom: '1rem' }}>
              {['Google Pay', 'PhonePe', 'Paytm', 'UPI QR', 'Visa / RuPay', 'Netbanking'].map((m) => (
                <span key={m} className="pro-modal-chip">{m}</span>
              ))}
            </div>

            {/* Action Button */}
            {rzpSuccess ? (
              <div style={{
                padding: '0.85rem 1rem', borderRadius: '12px',
                background: 'rgba(16,185,129,0.15)', border: '1px solid rgba(16,185,129,0.4)',
                color: '#34d399', display: 'flex', alignItems: 'center', gap: '0.5rem',
                justifyContent: 'center', fontWeight: 700, fontSize: '0.875rem'
              }}>
                <CheckCircle size={18} /> {rzpSuccess}
              </div>
            ) : (
              <button
                type="button"
                id="razorpay-pay-btn"
                onClick={handleRazorpayPay}
                disabled={rzpLoading}
                className={`pro-modal-cta-btn ${rzpLoading ? 'is-loading' : ''}`}
                style={{
                  background: isAnnual
                    ? 'linear-gradient(135deg, #059669 0%, #10b981 50%, #34d399 100%)'
                    : 'linear-gradient(135deg, #072654 0%, #3395FF 50%, #00f2fe 100%)'
                }}
              >
                {rzpLoading ? (
                  <><div className="spinner-border" style={{ width: '18px', height: '18px', borderWidth: '2px' }} /> Initiating Razorpay Gateway...</>
                ) : (
                  <>
                    <CreditCard size={18} />
                    <span>Pay {planPriceDisplay} — Unlock {isAnnual ? 'Annual' : 'Monthly'} PRO</span>
                  </>
                )}
              </button>
            )}

            {rzpError && !rzpSuccess && (
              <div style={{
                marginTop: '0.75rem', padding: '0.65rem 0.85rem', borderRadius: '8px',
                background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.35)',
                color: '#f87171', fontSize: '0.78rem', display: 'flex', alignItems: 'center', gap: '0.45rem'
              }}>
                <AlertCircle size={15} style={{ flexShrink: 0 }} />
                <span>{rzpError}</span>
              </div>
            )}
          </div>

          {/* Security & Expiry Notice */}
          <div style={{ display: 'flex', gap: '1.25rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            {[
              { icon: '🔒', text: 'PCI-DSS 256-bit SSL' },
              { icon: '⏱️', text: isAnnual ? '365 Days Valid' : '30 Days Valid' },
              { icon: '⚡', text: 'Instant Automated Unlock' },
              { icon: '🛡️', text: 'Direct Razorpay Verification' },
            ].map((item) => (
              <span key={item.text} style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                <span>{item.icon}</span> {item.text}
              </span>
            ))}
          </div>
        </div>

        {/* Footer trust bar */}
        <div className="pro-modal-trust-footer" style={{ marginTop: '1rem' }}>
          <ShieldCheck size={14} color="#10b981" />
          <span>
            Employ.AI Automated Subscription Engine • Analyzes time & keeps your PRO active throughout validity
          </span>
        </div>
      </div>
    </div>
  );
};

export default PremiumSubscriptionModal;
