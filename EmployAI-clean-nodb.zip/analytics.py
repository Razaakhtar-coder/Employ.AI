from typing import List, Dict, Any, Optional
from pydantic import BaseModel


class SkillGapAggregate(BaseModel):
    skill_name: str
    domain: str
    students_lacking_count: int
    percentage_lacking: float
    importance: str


class DepartmentReadinessMetric(BaseModel):
    department: str
    total_students: int
    average_cgpa: float
    average_readiness_score: float  # e.g., 78.4%
    top_skill_gaps: List[str]
    placed_or_shortlisted_count: int


class AcademiaDashboardStats(BaseModel):
    institution_name: str
    total_registered_students: int
    active_departments_count: int
    overall_readiness_index: float
    top_demanded_skills: List[Dict[str, Any]]
    critical_department_skill_gaps: List[SkillGapAggregate]
    department_metrics: List[DepartmentReadinessMetric]


class RecruiterDashboardStats(BaseModel):
    company_name: str
    active_job_postings: int
    total_applicants: int
    average_applicant_match_pct: float
    shortlisted_candidates_count: int
