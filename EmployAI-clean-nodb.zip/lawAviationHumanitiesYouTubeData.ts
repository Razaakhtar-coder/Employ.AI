import type { DomainPhaseVideoMap } from './domainYouTubeData';

// ============================================================================
// Law, Aviation, Cabin Crew & Humanities 5-Phase YouTube Registry
// Covers BA LLB, Aviation (Pilot CPL), Cabin Crew & BA Hons (Humanities)
// Phase 0: Foundations & Core Theoretical Principles
// Phase 1: Applied Tooling, Legal Drafting & Specialized Operating Procedures
// Phase 2: Advanced Case Analysis, System Faults & Strategic Governance
// Phase 3: Flagship Capstone, Simulated Court / Cockpit / Field Practicum
// Phase 4: Placement Screening, Chamber / Airline Viva & Technical Hiring
// ============================================================================

export const LAW_AVIATION_HUMANITIES_YOUTUBE_REGISTRY: Record<string, DomainPhaseVideoMap> = {
  // --------------------------------------------------------------------------
  // law-contracts
  // --------------------------------------------------------------------------
  'law-contracts': {
    0: [{
      id: "law-contracts-p0-4sL45k",
      title: "Contract Law Foundations & Formation: Offer, Acceptance, Consideration",
      youtube_video_id: "avFiw2-q1V8",
      youtube_url: "https://www.youtube.com/watch?v=avFiw2-q1V8",
      fallback_video_id: "avFiw2-q1V8",
      search_query: "Contract law foundations offer acceptance consideration masterclass",
      channel_name: "Harvard Law School / Quimbee",
      duration: "52:10",
      difficulty: "Beginner",
      topic_focus: "Contract Law Foundations & Formation",
      key_takeaways: [
        "Essential elements of valid enforceable contracts under Contract Act",
        "Distinction between offer, invitation to treat, and counter-offers",
        "Doctrine of consideration, promissory estoppel, and privity of contract",
        "Void, voidable, and illegal agreements with leading precedent analysis"
      ]
    }],
    1: [{
      id: "law-contracts-p1-3cM-Gq",
      title: "Commercial Contract Drafting & Clause Architecture: MSAs & SLAs",
      youtube_video_id: "DnDiY4aDz08",
      youtube_url: "https://www.youtube.com/watch?v=DnDiY4aDz08",
      fallback_video_id: "DnDiY4aDz08",
      search_query: "Commercial contract drafting masterclass boilerplate clauses MSA SLA",
      channel_name: "Legal Drafting Academy",
      duration: "1:18:40",
      difficulty: "Intermediate",
      topic_focus: "Commercial Contract Drafting & Clause Architecture",
      key_takeaways: [
        "Standard commercial agreement structure: recitals, operative terms, covenants",
        "Drafting representations, warranties, indemnities, and limitation of liability",
        "Termination clauses, material breach triggers, and cure period mechanisms",
        "Boilerplate essentials: severability, governing law, and jurisdiction"
      ]
    }],
    2: [{
      id: "law-contracts-p2-0sNn-q",
      title: "Advanced Contract Negotiation, Redlining & Risk Allocation",
      youtube_video_id: "z7GJ-7_GX-c",
      youtube_url: "https://www.youtube.com/watch?v=z7GJ-7_GX-c",
      fallback_video_id: "z7GJ-7_GX-c",
      search_query: "Contract negotiation redlining risk allocation masterclass",
      channel_name: "Corporate Counsel Review",
      duration: "1:05:22",
      difficulty: "Advanced",
      topic_focus: "Advanced Contract Negotiation, Redlining & Risk Allocation",
      key_takeaways: [
        "Contract redlining workflows using Track Changes in enterprise negotiations",
        "Negotiating uncapped liability vs mutual caps and consequential damages",
        "Indemnity carve-outs for gross negligence and willful misconduct",
        "Escrow and intellectual property assignment covenants in tech MSAs"
      ]
    }],
    3: [{
      id: "law-contracts-p3-rO7Hk_",
      title: "Capstone: End-to-End Enterprise SaaS Master Services Agreement (MSA)",
      youtube_video_id: "i2QA-JFCrj0",
      youtube_url: "https://www.youtube.com/watch?v=i2QA-JFCrj0",
      fallback_video_id: "i2QA-JFCrj0",
      search_query: "Enterprise SaaS MSA contract drafting capstone walk-through",
      channel_name: "Tech GC Academy",
      duration: "1:34:15",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Drafting a complete cross-border SaaS agreement with uptime SLAs and DPA",
        "Data privacy riders, GDPR/DPDP compliance schedules, and audit rights",
        "Mitigating vendor lock-in, data retrieval upon termination, and transition support",
        "Presenting executive risk summaries to C-suite and legal ops"
      ]
    }],
    4: [{
      id: "law-contracts-p4-J5F4t5",
      title: "Corporate Legal Placement & Contract Drafting Viva Interview Prep",
      youtube_video_id: "naUVo4n_8IE",
      youtube_url: "https://www.youtube.com/watch?v=naUVo4n_8IE",
      fallback_video_id: "naUVo4n_8IE",
      search_query: "Corporate legal counsel interview questions contract drafting viva",
      channel_name: "Law School Prep & Top Tier Firms",
      duration: "58:40",
      difficulty: "Placement",
      topic_focus: "Corporate Legal Placement & Contract Drafting Viva Interview Prep",
      key_takeaways: [
        "Walk-through of top tier law firm assessment days and drafting tests",
        "Structuring answers on liquidated damages vs penalties under Section 74",
        "Defending redline positions against seasoned opposing counsel in simulations",
        "Behavioral and ethics questions for in-house legal counsel roles"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // law-corporate
  // --------------------------------------------------------------------------
  'law-corporate': {
    0: [{
      id: "law-corporate-p0-X-5Bv1",
      title: "Companies Act Fundamentals & Corporate Governance Architecture",
      youtube_video_id: "8z0YZZMy8ZY",
      youtube_url: "https://www.youtube.com/watch?v=8z0YZZMy8ZY",
      fallback_video_id: "8z0YZZMy8ZY",
      search_query: "Companies Act corporate governance board meetings director duties",
      channel_name: "ICSI & Corporate Law Institute",
      duration: "1:12:30",
      difficulty: "Beginner",
      topic_focus: "Companies Act Fundamentals & Corporate Governance Architecture",
      key_takeaways: [
        "Separate legal entity doctrine: Salomon v Salomon and lifting corporate veil",
        "Incorporation process, MOA/AOA drafting, and share capital structures",
        "Directors duties under Section 166 and board committee compositions",
        "Annual general meetings (AGM), extraordinary meetings, and shareholder voting"
      ]
    }],
    1: [{
      id: "law-corporate-p1-f9v6N_",
      title: "Shareholder Agreements (SHA/SSA) & Term Sheet Mechanics",
      youtube_video_id: "bCmNuozZHY0",
      youtube_url: "https://www.youtube.com/watch?v=bCmNuozZHY0",
      fallback_video_id: "bCmNuozZHY0",
      search_query: "Shareholders agreement SHA SSA term sheet liquidation preference",
      channel_name: "Venture Law Masterclass",
      duration: "1:24:10",
      difficulty: "Intermediate",
      topic_focus: "Shareholder Agreements (SHA/SSA) & Term Sheet Mechanics",
      key_takeaways: [
        "Decoding term sheets: valuation, pre-emption, and liquidation preferences",
        "Drafting Right of First Refusal (ROFR), Tag-Along, and Drag-Along rights",
        "Affirmative voting matters (AVMs) and reserved investor veto powers",
        "Anti-dilution ratchets: full ratchet vs broad-based weighted average"
      ]
    }],
    2: [{
      id: "law-corporate-p2-7lB8vK",
      title: "SEBI LODR, Insider Trading Regulations (PIT) & Takeover Code",
      youtube_video_id: "ZKnsAg_Eaik",
      youtube_url: "https://www.youtube.com/watch?v=ZKnsAg_Eaik",
      fallback_video_id: "ZKnsAg_Eaik",
      search_query: "SEBI LODR insider trading PIT regulations takeover code compliance",
      channel_name: "Capital Markets Legal Forum",
      duration: "1:16:45",
      difficulty: "Advanced",
      topic_focus: "SEBI LODR, Insider Trading Regulations (PIT) & Takeover Code",
      key_takeaways: [
        "SEBI Listing Obligations and Disclosure Requirements (LODR) governance",
        "Unpublished Price Sensitive Information (UPSI) and Chinese wall protocols",
        "SEBI Prohibition of Insider Trading (PIT) regulations and trading windows",
        "Takeover Code triggers: open offers, creeping acquisitions, and exemptions"
      ]
    }],
    3: [{
      id: "law-corporate-p3-2k8M-v",
      title: "Capstone: Drafting Complete Series A Share Subscription & SHA Package",
      youtube_video_id: "bCmNuozZHY0",
      youtube_url: "https://www.youtube.com/watch?v=bCmNuozZHY0",
      fallback_video_id: "bCmNuozZHY0",
      search_query: "Drafting Series A share subscription shareholders agreement capstone",
      channel_name: "Startup GC Masterclass",
      duration: "1:45:00",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Drafting conditions precedent (CP) and conditions subsequent (CS) checklists",
        "Structuring founder vesting, ESOP pool dilution, and lock-in covenants",
        "Designing dispute resolution waterfalls and exit put/call option mechanics",
        "Conducting closing table signing and MCA e-form filing workflows"
      ]
    }],
    4: [{
      id: "law-corporate-p4-9vQ1mP",
      title: "Corporate Law Associate Placement & Mock M&A Viva Preparation",
      youtube_video_id: "PbpcFEoOVHw",
      youtube_url: "https://www.youtube.com/watch?v=PbpcFEoOVHw",
      fallback_video_id: "PbpcFEoOVHw",
      search_query: "Corporate lawyer interview questions top law firm M&A interview prep",
      channel_name: "Top Tier Law Firm Recruitment",
      duration: "1:02:18",
      difficulty: "Placement",
      topic_focus: "Corporate Law Associate Placement & Mock M&A Viva Preparation",
      key_takeaways: [
        "Technical questions on oppression and mismanagement under Section 241/242",
        "Analyzing landmark NCLAT and Supreme Court corporate governance judgments",
        "Fast-track cross-examination on cross-border FDI norms and Press Note 3",
        "Cracking boutique and Big 4 legal advisory placement interviews"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // law-civil
  // --------------------------------------------------------------------------
  'law-civil': {
    0: [{
      id: "law-civil-p0-8vB4mQ",
      title: "Code of Civil Procedure (CPC) Fundamentals: Jurisdiction & Res Judicata",
      youtube_video_id: "MoIBn6IaULo",
      youtube_url: "https://www.youtube.com/watch?v=MoIBn6IaULo",
      fallback_video_id: "MoIBn6IaULo",
      search_query: "CPC Code of Civil Procedure Section 9 10 11 res judicata masterclass",
      channel_name: "Judiciary Legal Academy",
      duration: "1:15:20",
      difficulty: "Beginner",
      topic_focus: "Code of Civil Procedure (CPC) Fundamentals",
      key_takeaways: [
        "Civil courts jurisdiction under Section 9: inherent and pecuniary limits",
        "Doctrine of Res Sub-Judice (Sec 10) and Res Judicata (Sec 11)",
        "Institution of suits under Section 26 and summons service protocols",
        "Differences between decree, order, judgment, and mesne profits"
      ]
    }],
    1: [{
      id: "law-civil-p1-4mN7vK",
      title: "Pleadings & Court Drafting: Plaints (Order VII) & Written Statements (Order VIII)",
      youtube_video_id: "-lUiFb1tt-I",
      youtube_url: "https://www.youtube.com/watch?v=-lUiFb1tt-I",
      fallback_video_id: "-lUiFb1tt-I",
      search_query: "Plaint drafting Order 7 written statement Order 8 CPC legal drafting",
      channel_name: "Advocate Trial Practice",
      duration: "1:22:15",
      difficulty: "Intermediate",
      topic_focus: "Pleadings & Court Drafting",
      key_takeaways: [
        "Fundamental rules of pleadings under Order VI: facts not law or evidence",
        "Drafting comprehensive plaints: cause of action, valuation, and relief clauses",
        "Drafting Written Statements: specific denials, set-off, and counter-claims",
        "Filing interim injunction applications under Order XXXIX Rules 1 & 2"
      ]
    }],
    2: [{
      id: "law-civil-p2-1qP9mK",
      title: "Trial Procedure, Examination of Witnesses & Section 89 ADR Mandate",
      youtube_video_id: "6sV_e3078Xg",
      youtube_url: "https://www.youtube.com/watch?v=6sV_e3078Xg",
      fallback_video_id: "6sV_e3078Xg",
      search_query: "Civil trial procedure examination in chief cross examination CPC",
      channel_name: "High Court Practice & Procedure",
      duration: "1:10:40",
      difficulty: "Advanced",
      topic_focus: "Trial Procedure, Examination of Witnesses & Section 89 ADR Mandate",
      key_takeaways: [
        "Framing of issues under Order XIV: issues of fact vs issues of law",
        "Affidavit in lieu of examination-in-chief and cross-examination strategies",
        "Production and impounding of documentary evidence under Order XIII",
        "Pre-trial conciliation and mediation mandate under Section 89 CPC"
      ]
    }],
    3: [{
      id: "law-civil-p3-3bV6mP",
      title: "Capstone: Drafting Commercial Suit Plaint, Injunction & Interim Application",
      youtube_video_id: "BKBp8d_PNno",
      youtube_url: "https://www.youtube.com/watch?v=BKBp8d_PNno",
      fallback_video_id: "BKBp8d_PNno",
      search_query: "Commercial court suit plaint drafting injunction capstone project",
      channel_name: "Commercial Court Litigation Clinic",
      duration: "1:36:50",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Drafting under Commercial Courts Act 2015: statement of truth and disclosure",
        "Formulating Urgent Interim Relief applications with balance of convenience tests",
        "Asset discovery, attachment before judgment (Order XXXVIII), and security orders",
        "Execution of decrees under Order XXI: attachment and arrest procedures"
      ]
    }],
    4: [{
      id: "law-civil-p4-7vN2mQ",
      title: "Civil Litigation Associate Placement & Judicial Service Viva Questions",
      youtube_video_id: "U9f8As9z1xI",
      youtube_url: "https://www.youtube.com/watch?v=U9f8As9z1xI",
      fallback_video_id: "U9f8As9z1xI",
      search_query: "Civil litigation interview questions CPC judicial exam viva mock",
      channel_name: "Judicial Exams & Litigation Bar Prep",
      duration: "59:30",
      difficulty: "Placement",
      topic_focus: "Civil Litigation Associate Placement & Judicial Service Viva Questions",
      key_takeaways: [
        "Distinguishing reference, review, and revision under Sections 113, 114, 115",
        "Answering challenging scenarios on amendment of pleadings under Order VI Rule 17",
        "Courtroom etiquette, arguing applications before District and High Courts",
        "Senior Advocate chamber placement interview tactics and legal research tests"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // law-criminal
  // --------------------------------------------------------------------------
  'law-criminal': {
    0: [{
      id: "law-criminal-p0-5mK8vP",
      title: "Bharatiya Nyaya Sanhita (BNS) & Criminal Law Core Foundations",
      youtube_video_id: "ys1BVrTDhD0",
      youtube_url: "https://www.youtube.com/watch?v=ys1BVrTDhD0",
      fallback_video_id: "ys1BVrTDhD0",
      search_query: "Bharatiya Nyaya Sanhita BNS IPC comparison criminal law basics",
      channel_name: "Criminal Jurisprudence Institute",
      duration: "1:18:00",
      difficulty: "Beginner",
      topic_focus: "Bharatiya Nyaya Sanhita (BNS) & Criminal Law Core Foundations",
      key_takeaways: [
        "Elements of crime: Actus Reus, Mens Rea, and general exceptions",
        "Comparative matrix: transition from IPC to Bharatiya Nyaya Sanhita (BNS)",
        "Offences against human body: culpable homicide vs murder definitions",
        "Offences against property: theft, extortion, robbery, and criminal breach of trust"
      ]
    }],
    1: [{
      id: "law-criminal-p1-9qN4vM",
      title: "Bharatiya Nagarik Suraksha Sanhita (BNSS): Arrest, FIR & Investigation",
      youtube_video_id: "lkduMDt6oCE",
      youtube_url: "https://www.youtube.com/watch?v=lkduMDt6oCE",
      fallback_video_id: "lkduMDt6oCE",
      search_query: "BNSS CrPC comparison FIR registration arrest remand zero FIR",
      channel_name: "Criminal Procedure Masterclass",
      duration: "1:26:40",
      difficulty: "Intermediate",
      topic_focus: "Bharatiya Nagarik Suraksha Sanhita (BNSS)",
      key_takeaways: [
        "Registration of FIR, Zero FIR protocols, and e-FIR provisions under BNSS",
        "Arrest guidelines, Section 41A notices, and fundamental rights of accused",
        "Police remand vs judicial remand under Section 167 (BNSS Sec 187)",
        "Search and seizure procedures, panchnama documentation, and charge sheets"
      ]
    }],
    2: [{
      id: "law-criminal-p2-2vB7mK",
      title: "Bail Jurisprudence & Criminal Trial Advocacy: Regular & Anticipatory Bail",
      youtube_video_id: "aBe7Sl0-pSw",
      youtube_url: "https://www.youtube.com/watch?v=aBe7Sl0-pSw",
      fallback_video_id: "aBe7Sl0-pSw",
      search_query: "Bail application drafting anticipatory bail trial advocacy BNSS",
      channel_name: "Criminal Defense Academy",
      duration: "1:14:15",
      difficulty: "Advanced",
      topic_focus: "Bail Jurisprudence & Criminal Trial Advocacy",
      key_takeaways: [
        "Drafting regular bail applications under BNSS Section 480/483",
        "Anticipatory bail jurisprudence and Triple Test criteria (flight risk, tampering)",
        "Bharatiya Sakshya Adhiniyam (BSA): electronic evidence Section 63/65B certificates",
        "Trial stages: framing of charges, discharge applications, and witness examination"
      ]
    }],
    3: [{
      id: "law-criminal-p3-6mQ3vP",
      title: "Capstone: Criminal Defense Brief - Bail Petition, Quashing (Sec 482) & Strategy",
      youtube_video_id: "EsYtRTc-HDA",
      youtube_url: "https://www.youtube.com/watch?v=EsYtRTc-HDA",
      fallback_video_id: "EsYtRTc-HDA",
      search_query: "Drafting bail petition Section 482 quashing petition capstone trial",
      channel_name: "High Court Criminal Defense Clinic",
      duration: "1:38:20",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Drafting Section 482 quashing petition against malicious commercial FIRs",
        "Structuring grounds: lack of prima facie ingredients and abuse of process",
        "Preparing witness cross-examination questions to dismantle prosecution narrative",
        "Simulating bail argument before High Court vacation bench with leading authorities"
      ]
    }],
    4: [{
      id: "law-criminal-p4-1pN8vK",
      title: "Criminal Litigation Chamber Placement & Prosecution Viva Preparation",
      youtube_video_id: "aP86hkyKxJA",
      youtube_url: "https://www.youtube.com/watch?v=aP86hkyKxJA",
      fallback_video_id: "aP86hkyKxJA",
      search_query: "Criminal law interview questions chamber placement mock viva criminal trial",
      channel_name: "Criminal Bar Association Prep",
      duration: "56:45",
      difficulty: "Placement",
      topic_focus: "Criminal Litigation Chamber Placement & Prosecution Viva Preparation",
      key_takeaways: [
        "Differentiating test identification parades, extra-judicial confessions, and dying declarations",
        "Handling high-stress trial court remand hearings and bail arguments",
        "Ethical obligations of defense counsel under Bar Council of India rules",
        "Chamber assessment interviews for premier criminal law practices"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // law-ipr
  // --------------------------------------------------------------------------
  'law-ipr': {
    0: [{
      id: "law-ipr-p0-3vK7mN",
      title: "Intellectual Property Law Foundations: Trademarks, Patents & Copyrights",
      youtube_video_id: "AKLxunQdXGU",
      youtube_url: "https://www.youtube.com/watch?v=AKLxunQdXGU",
      fallback_video_id: "AKLxunQdXGU",
      search_query: "Intellectual property law basics trademark copyright patent WIPO",
      channel_name: "WIPO & National IP Academy",
      duration: "1:08:40",
      difficulty: "Beginner",
      topic_focus: "Intellectual Property Law Foundations",
      key_takeaways: [
        "Economic justification and international IP frameworks: TRIPS, Paris Convention",
        "Trademarks Act 1999: distinctiveness, absolute vs relative grounds of refusal",
        "Copyright Act 1957: originality, author vs owner, moral rights and fair dealing",
        "Patents Act 1970: patentable subject matter, novelty, inventive step, industrial utility"
      ]
    }],
    1: [{
      id: "law-ipr-p1-7qM1vP",
      title: "Trademark Prosecution, Search Reports & Opposition Proceedings",
      youtube_video_id: "A4az4XMoecQ",
      youtube_url: "https://www.youtube.com/watch?v=A4az4XMoecQ",
      fallback_video_id: "A4az4XMoecQ",
      search_query: "Trademark prosecution NICE classification TM opposition counter statement",
      channel_name: "IP Practice Masterclass",
      duration: "1:20:10",
      difficulty: "Intermediate",
      topic_focus: "Trademark Prosecution, Search Reports & Opposition Proceedings",
      key_takeaways: [
        "Conducting clearance searches on the Trade Marks Registry public search portal",
        "Nice Classification analysis (Goods Classes 1-34, Services Classes 35-45)",
        "Drafting responses to Examination Reports addressing Section 9 & 11 objections",
        "Drafting Notice of Opposition (Form TM-O) and Counter-Statement filings"
      ]
    }],
    2: [{
      id: "law-ipr-p2-4mP8vK",
      title: "Patent Drafting, Prior Art Search & Section 3(d) / 3(k) Objections",
      youtube_video_id: "n3P6FsviqDQ",
      youtube_url: "https://www.youtube.com/watch?v=n3P6FsviqDQ",
      fallback_video_id: "n3P6FsviqDQ",
      search_query: "Patent claim drafting prior art patent prosecution Section 3d 3k",
      channel_name: "Patent Attorney Institute",
      duration: "1:27:30",
      difficulty: "Advanced",
      topic_focus: "Patent Drafting, Prior Art Search & Section 3(d) / 3(k) Objections",
      key_takeaways: [
        "Patent prior art searching on Google Patents, Espacenet, and InPASS",
        "Drafting provisional vs complete specifications: background, claims, and abstract",
        "Writing independent and dependent claims to maximize patent coverage",
        "Overcoming Section 3(d) pharmaceutical efficacy and Section 3(k) software objections"
      ]
    }],
    3: [{
      id: "law-ipr-p3-9vN5mQ",
      title: "Capstone: Cease & Desist Drafting & IP Infringement / Passing Off Suit",
      youtube_video_id: "ARd_0TiFPuE",
      youtube_url: "https://www.youtube.com/watch?v=ARd_0TiFPuE",
      fallback_video_id: "ARd_0TiFPuE",
      search_query: "Trademark infringement passing off plaint cease and desist capstone",
      channel_name: "IP Litigation Forum",
      duration: "1:42:00",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Drafting aggressive Cease & Desist legal notice with damages calculation",
        "Drafting commercial plaint for trademark infringement and common law passing off",
        "Drafting ex-parte Anton Piller local commissioner search orders and interim injunctions",
        "Calculating reasonable royalties and punitive damages under Indian precedent"
      ]
    }],
    4: [{
      id: "law-ipr-p4-2kM7vP",
      title: "IP Law Associate Placement & Patent Agent Examination Viva Prep",
      youtube_video_id: "0Lk0fIerXL4",
      youtube_url: "https://www.youtube.com/watch?v=0Lk0fIerXL4",
      fallback_video_id: "0Lk0fIerXL4",
      search_query: "IP lawyer interview questions patent agent exam viva trademark law",
      channel_name: "Premier IP Firms & Bar Training",
      duration: "1:01:10",
      difficulty: "Placement",
      topic_focus: "IP Law Associate Placement & Patent Agent Examination Viva Prep",
      key_takeaways: [
        "Walk-through of trademark opposition hearing simulations before the Registrar",
        "Technical questions on Compulsory Licensing (Sec 84) and Bolar exemptions",
        "Domain name dispute resolution under UDRP and INDRP policies",
        "Recruitment mock interviews for top Tier-1 IPR boutique firms"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // law-research
  // --------------------------------------------------------------------------
  'law-research': {
    0: [{
      id: "law-research-p0-6mN2vP",
      title: "Legal Research Methodologies & Primary vs Secondary Authorities",
      youtube_video_id: "45eJUjzfTy4",
      youtube_url: "https://www.youtube.com/watch?v=45eJUjzfTy4",
      fallback_video_id: "45eJUjzfTy4",
      search_query: "Legal research methodology primary secondary authority citation Bluebook",
      channel_name: "National Law School Legal Writing",
      duration: "50:30",
      difficulty: "Beginner",
      topic_focus: "Legal Research Methodologies & Primary vs Secondary Authorities",
      key_takeaways: [
        "Hierarchy of legal authority: statutory enactments, binding precedents, obiter dicta",
        "Reading judicial decisions: Ratio Decidendi extraction vs Obiter Dicta",
        "Standardized legal citation: Bluebook 21st Edition and ILI citation rules",
        "Locating legislative intent using Parliamentary Standing Committee debates"
      ]
    }],
    1: [{
      id: "law-research-p1-1qP7mK",
      title: "SCC Online & Manupatra Advanced Boolean Query Synthesis",
      youtube_video_id: "QDzIa824f8Y",
      youtube_url: "https://www.youtube.com/watch?v=QDzIa824f8Y",
      fallback_video_id: "QDzIa824f8Y",
      search_query: "SCC Online advanced search boolean operators Manupatra precedent search",
      channel_name: "Legal Tech & Research Institute",
      duration: "1:12:40",
      difficulty: "Intermediate",
      topic_focus: "SCC Online & Manupatra Advanced Boolean Query Synthesis",
      key_takeaways: [
        "Mastering boolean operators (AND, OR, NOT, NEAR/5) for precise case filtering",
        "Using Case Finder, Topic Index, and Words & Phrases modules in SCC Online",
        "Overruled judgments tracking and Shepards/TruePrint verification workflows",
        "Comparative cross-referencing across High Court and Supreme Court benches"
      ]
    }],
    2: [{
      id: "law-research-p2-5vB3mQ",
      title: "Synthesizing Judicial Precedents & Authoring Internal Legal Opinions",
      youtube_video_id: "Io5ttZ0ih9w",
      youtube_url: "https://www.youtube.com/watch?v=Io5ttZ0ih9w",
      fallback_video_id: "Io5ttZ0ih9w",
      search_query: "Legal opinion writing case synthesis internal legal memo drafting",
      channel_name: "Senior Advocates Research Chamber",
      duration: "1:18:25",
      difficulty: "Advanced",
      topic_focus: "Synthesizing Judicial Precedents & Authoring Internal Legal Opinions",
      key_takeaways: [
        "Distinguishing conflicting division bench vs constitution bench authorities",
        "Drafting formal legal opinions: issue, brief answer, facts, analysis, conclusion",
        "Risk calibration: high risk vs legally defensible positions for corporate clients",
        "Synthesizing foreign comparative jurisprudence (UK, US, Commonwealth) in novel issues"
      ]
    }],
    3: [{
      id: "law-research-p3-8mK5vP",
      title: "Capstone: Comprehensive Supreme Court Special Leave Petition (SLP) Research Memo",
      youtube_video_id: "g5N4r04iP-g",
      youtube_url: "https://www.youtube.com/watch?v=g5N4r04iP-g",
      fallback_video_id: "g5N4r04iP-g",
      search_query: "Supreme Court SLP research memo substantial question of law capstone",
      channel_name: "Supreme Court Practice Clinic",
      duration: "1:32:10",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Identifying substantial questions of law under Article 136 of Constitution",
        "Authoring exhaustive 20-page research brief with chronological case compilation",
        "Rebutting respondents anticipated counter-authorities with distinguishing nuances",
        "Presenting senior counsel briefing notes for oral admission hearings"
      ]
    }],
    4: [{
      id: "law-research-p4-3pN9vK",
      title: "Law Firm Knowledge Management & Judicial Clerkship Interview Prep",
      youtube_video_id: "quN_qdBukrg",
      youtube_url: "https://www.youtube.com/watch?v=quN_qdBukrg",
      fallback_video_id: "quN_qdBukrg",
      search_query: "Judicial clerkship interview questions Supreme Court clerk law firm KM test",
      channel_name: "Clerkship & Law Review Guild",
      duration: "55:15",
      difficulty: "Placement",
      topic_focus: "Law Firm Knowledge Management & Judicial Clerkship Interview Prep",
      key_takeaways: [
        "Supreme Court law clerk-cum-research assistant assessment patterns",
        "Speed research exercises: answering complex statutory queries in 30 minutes",
        "Bench memo drafting conventions for High Court and Supreme Court judges",
        "Knowledge Management (KM) and legal innovation roles in corporate firms"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // law-adr
  // --------------------------------------------------------------------------
  'law-adr': {
    0: [{
      id: "law-adr-p0-4vM8mQ",
      title: "Arbitration and Conciliation Act 1996 Core Legal Foundations",
      youtube_video_id: "ANkmEdlvXNU",
      youtube_url: "https://www.youtube.com/watch?v=ANkmEdlvXNU",
      fallback_video_id: "ANkmEdlvXNU",
      search_query: "Arbitration and Conciliation Act 1996 basics Section 7 8 9 CIArb",
      channel_name: "Chartered Institute of Arbitrators (CIArb)",
      duration: "1:10:00",
      difficulty: "Beginner",
      topic_focus: "Arbitration and Conciliation Act 1996 Core Legal Foundations",
      key_takeaways: [
        "Arbitration agreement essentials under Section 7: in writing, intent to arbitrate",
        "Doctrine of Separability and Kompetenz-Kompetenz (arbitrator jurisdiction)",
        "Reference to arbitration under Section 8 and judicial non-intervention (Section 5)",
        "Differences between institutional (SIAC, LCIA, MCIA) and ad-hoc arbitrations"
      ]
    }],
    1: [{
      id: "law-adr-p1-9mK2vP",
      title: "Section 9 Interim Measures & Section 11 Arbitrator Appointment Petitions",
      youtube_video_id: "3sqFMJO7wIU",
      youtube_url: "https://www.youtube.com/watch?v=3sqFMJO7wIU",
      fallback_video_id: "3sqFMJO7wIU",
      search_query: "Section 9 interim relief Section 11 arbitrator appointment High Court arbitration",
      channel_name: "Commercial Arbitration Academy",
      duration: "1:21:30",
      difficulty: "Intermediate",
      topic_focus: "Section 9 Interim Measures & Section 11 Arbitrator Appointment Petitions",
      key_takeaways: [
        "Drafting Section 9 petitions for pre-arbitral preservation of assets and escrow",
        "Section 11(6) petitions before High Court / Supreme Court for tribunal appointment",
        "Tribunal powers to grant interim relief under Section 17 post-amendment",
        "Fifth and Seventh Schedule disclosures: impartiality and conflict of interest"
      ]
    }],
    2: [{
      id: "law-adr-p2-2qP8mN",
      title: "Arbitral Proceedings: Statement of Claim, Defense & Evidentiary Hearings",
      youtube_video_id: "giJR6TNaKC0",
      youtube_url: "https://www.youtube.com/watch?v=giJR6TNaKC0",
      fallback_video_id: "giJR6TNaKC0",
      search_query: "Arbitration hearing statement of claim defense IBA rules of evidence",
      channel_name: "International Arbitration Bar",
      duration: "1:25:50",
      difficulty: "Advanced",
      topic_focus: "Arbitral Proceedings",
      key_takeaways: [
        "Drafting Statement of Claim (SOC) and Statement of Defense & Counterclaim (SOD)",
        "Application of IBA Rules on the Taking of Evidence in Commercial Arbitration",
        "Expert quantum witness reports, cross-examination, and document production (Redfern Schedule)",
        "Drafting arbitral awards: procedural history, reasons, and cost allocation"
      ]
    }],
    3: [{
      id: "law-adr-p3-7vB4mQ",
      title: "Capstone: Setting Aside Arbitral Awards (Sec 34) & Enforcement (Sec 36)",
      youtube_video_id: "WQNsZ1PmGqs",
      youtube_url: "https://www.youtube.com/watch?v=WQNsZ1PmGqs",
      fallback_video_id: "WQNsZ1PmGqs",
      search_query: "Section 34 setting aside award public policy patent illegality capstone",
      channel_name: "Commercial Dispute Resolution Clinic",
      duration: "1:40:15",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Drafting Section 34 petition: narrow grounds of challenge post-2015 amendment",
        "Decoding Public Policy of India and Patent Illegality under Ssangyong & Associate Builders",
        "Section 36 execution of domestic awards and New York Convention foreign awards (Sec 48)",
        "Conducting mock final hearing oral arguments challenging arbitrator award"
      ]
    }],
    4: [{
      id: "law-adr-p4-1mK9vP",
      title: "Arbitration Associate Placement & Vis Moot Advocacy Interview Prep",
      youtube_video_id: "b2594ruUzHI",
      youtube_url: "https://www.youtube.com/watch?v=b2594ruUzHI",
      fallback_video_id: "b2594ruUzHI",
      search_query: "Arbitration lawyer interview questions Vis Moot oral rounds dispute resolution",
      channel_name: "International Dispute Resolution Guild",
      duration: "1:03:40",
      difficulty: "Placement",
      topic_focus: "Arbitration Associate Placement & Vis Moot Advocacy Interview Prep",
      key_takeaways: [
        "Vis International Commercial Arbitration Moot oral round strategies",
        "Challenging emergency arbitrator orders in Indian courts (Amazon v Future jurisprudence)",
        "Structuring answers on anti-arbitration injunctions and third-party funding",
        "Recruitment interviews for dispute resolution teams in leading national firms"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // law-duediligence
  // --------------------------------------------------------------------------
  'law-duediligence': {
    0: [{
      id: "law-duediligence-p0-6qM3vP",
      title: "M&A Due Diligence Fundamentals: Objectives, Scope & RFI Checklists",
      youtube_video_id: "PqkXVgCR_MU",
      youtube_url: "https://www.youtube.com/watch?v=PqkXVgCR_MU",
      fallback_video_id: "PqkXVgCR_MU",
      search_query: "Mergers acquisitions legal due diligence basics RFI checklist VDR",
      channel_name: "Corporate Transactions Academy",
      duration: "58:20",
      difficulty: "Beginner",
      topic_focus: "M&A Due Diligence Fundamentals",
      key_takeaways: [
        "Purpose of legal due diligence in corporate mergers, acquisitions, and private equity",
        "Formulating Request for Information (RFI) questionnaires across corporate pillars",
        "Virtual Data Room (VDR) structure: Ansarada, Datasite, Intralinks setup",
        "Differentiating red-flag reports from exhaustive confirmatory diligence reports"
      ]
    }],
    1: [{
      id: "law-duediligence-p1-3vB9mK",
      title: "Corporate, Regulatory & Real Estate Title Verification Diligence",
      youtube_video_id: "G4riqT-VeGY",
      youtube_url: "https://www.youtube.com/watch?v=G4riqT-VeGY",
      fallback_video_id: "G4riqT-VeGY",
      search_query: "Corporate legal due diligence MCA search title verification real estate",
      channel_name: "M&A Practice Masterclass",
      duration: "1:19:15",
      difficulty: "Intermediate",
      topic_focus: "Corporate, Regulatory & Real Estate Title Verification Diligence",
      key_takeaways: [
        "MCA public search: index of charges, registered office status, director disqualification",
        "Reviewing corporate capitalization tables, historical share issuances, and stamp duty",
        "Real estate title diligence: 30-year search, encumbrance certificates, mutation records",
        "Evaluating environmental, industrial, and municipal licensing compliances"
      ]
    }],
    2: [{
      id: "law-duediligence-p2-8vN2mQ",
      title: "Commercial Contracts, Employment & Litigation Exposure Audit",
      youtube_video_id: "hIVSROAC07I",
      youtube_url: "https://www.youtube.com/watch?v=hIVSROAC07I",
      fallback_video_id: "hIVSROAC07I",
      search_query: "Contract review due diligence change of control material litigation",
      channel_name: "Corporate Counsel Institute",
      duration: "1:24:40",
      difficulty: "Advanced",
      topic_focus: "Commercial Contracts, Employment & Litigation Exposure Audit",
      key_takeaways: [
        "Analyzing customer and vendor MSAs for Change of Control and assignment restrictions",
        "Employment audit: PF/ESIC deductions, standing orders, gratuity liability, keyman exits",
        "Pending litigation assessment: estimating contingent liability and criminal exposure",
        "Intellectual property chain of title and open-source software license audits"
      ]
    }],
    3: [{
      id: "law-duediligence-p3-2mK6vP",
      title: "Capstone: Authoring Comprehensive Red-Flag Diligence Report for PE Acquisition",
      youtube_video_id: "t4mnnymkIIk",
      youtube_url: "https://www.youtube.com/watch?v=t4mnnymkIIk",
      fallback_video_id: "t4mnnymkIIk",
      search_query: "Drafting legal due diligence report red flag issues CP CS escrow capstone",
      channel_name: "Private Equity Legal Clinic",
      duration: "1:37:00",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Compiling findings into an executive Red-Flag Legal Due Diligence Report",
        "Translating diligence issues into Conditions Precedent (CP) and Specific Indemnities",
        "Structuring purchase price adjustments and indemnity holdback escrows",
        "Delivering executive briefing presentation to Private Equity investment committee"
      ]
    }],
    4: [{
      id: "law-duediligence-p4-5pN1vK",
      title: "PE/M&A Legal Associate Placement & Diligence Case Study Interview Prep",
      youtube_video_id: "C6k_M-06l6Y",
      youtube_url: "https://www.youtube.com/watch?v=C6k_M-06l6Y",
      fallback_video_id: "C6k_M-06l6Y",
      search_query: "M&A legal associate interview questions diligence case study corporate lawyer",
      channel_name: "Top Law Firm M&A Recruitment",
      duration: "1:02:10",
      difficulty: "Placement",
      topic_focus: "PE/M&A Legal Associate Placement & Diligence Case Study Interview Prep",
      key_takeaways: [
        "Solving real-time 60-minute VDR document review assessment tests",
        "Explaining warranty breaches vs indemnity claims in transaction agreements",
        "Navigating tough technical questions on Press Note 3, CCI merger control thresholds",
        "Negotiating CP waiver requests under tight closing deal deadlines"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // law-dpdp
  // --------------------------------------------------------------------------
  'law-dpdp': {
    0: [{
      id: "law-dpdp-p0-7vM4mQ",
      title: "Digital Personal Data Protection (DPDP) Act & GDPR Core Architecture",
      youtube_video_id: "1Gh7IsYsNkM",
      youtube_url: "https://www.youtube.com/watch?v=1Gh7IsYsNkM",
      fallback_video_id: "1Gh7IsYsNkM",
      search_query: "DPDP Act 2023 basics GDPR comparison data fiduciary principal",
      channel_name: "Data Privacy Legal Institute",
      duration: "1:06:30",
      difficulty: "Beginner",
      topic_focus: "Digital Personal Data Protection (DPDP) Act & GDPR Core Architecture",
      key_takeaways: [
        "Core concepts: Personal Data, Processing, Data Principal, and Data Fiduciary",
        "Grounds for processing: free, informed, unconditional Consent vs Legitimate Uses",
        "Comparative principles: DPDP Act 2023 vs European GDPR (Article 6 lawful bases)",
        "Rights of Data Principals: access, correction, erasure, and grievance redressal"
      ]
    }],
    1: [{
      id: "law-dpdp-p1-1mK8vP",
      title: "Drafting Data Privacy Notices, Consent Artifacts & Cookie Policies",
      youtube_video_id: "LZavdvNkL_0",
      youtube_url: "https://www.youtube.com/watch?v=LZavdvNkL_0",
      fallback_video_id: "LZavdvNkL_0",
      search_query: "Drafting privacy notice consent management DPDP Act cookie policy",
      channel_name: "Privacy Engineering & Legal Academy",
      duration: "1:17:45",
      difficulty: "Intermediate",
      topic_focus: "Drafting Data Privacy Notices, Consent Artifacts & Cookie Policies",
      key_takeaways: [
        "Drafting compliant privacy notices in multi-lingual formats under DPDP rules",
        "Designing valid itemized consent flows and withdrawal mechanisms",
        "Childrens data protections under Section 9: parental consent and behavioral tracking bans",
        "Website cookie compliance banner architecture and tracker classification"
      ]
    }],
    2: [{
      id: "law-dpdp-p2-4qN7vM",
      title: "Data Protection Officer (DPO) Mandates, DPIA & Breach Notification Protocols",
      youtube_video_id: "rA98j9fjBbI",
      youtube_url: "https://www.youtube.com/watch?v=rA98j9fjBbI",
      fallback_video_id: "rA98j9fjBbI",
      search_query: "Data Protection Officer DPO Significant Data Fiduciary DPIA breach reporting",
      channel_name: "Corporate Privacy Counsel",
      duration: "1:23:10",
      difficulty: "Advanced",
      topic_focus: "Data Protection Officer (DPO) Mandates, DPIA & Breach Notification Protocols",
      key_takeaways: [
        "Significant Data Fiduciary (SDF) obligations: DPO appointment, periodic audits",
        "Conducting Data Protection Impact Assessments (DPIA) on high-risk algorithmic systems",
        "Data breach response timeline: mandatory reporting to Data Protection Board of India",
        "Cross-border data transfer rules: negative list whitelist frameworks"
      ]
    }],
    3: [{
      id: "law-dpdp-p3-9vB2mK",
      title: "Capstone: Enterprise DPDP Compliance Audit & Data Processing Agreement (DPA)",
      youtube_video_id: "FDF7lsqTuQ8",
      youtube_url: "https://www.youtube.com/watch?v=FDF7lsqTuQ8",
      fallback_video_id: "FDF7lsqTuQ8",
      search_query: "Data processing agreement DPA drafting DPDP compliance audit capstone",
      channel_name: "Tech Regulatory Clinic",
      duration: "1:35:40",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Drafting an enterprise Data Processing Agreement (DPA) between controller & processor",
        "Creating comprehensive Record of Processing Activities (ROPA) data map",
        "Conducting gap analysis audit against DPDP Act Section 8 technical security safeguards",
        "Presenting risk remediation roadmap to mitigate statutory penalties up to INR 250 Crores"
      ]
    }],
    4: [{
      id: "law-dpdp-p4-3mP5vN",
      title: "Privacy Counsel Associate Placement & CIPP/E / DPDP Viva Preparation",
      youtube_video_id: "6OvNNJQJixU",
      youtube_url: "https://www.youtube.com/watch?v=6OvNNJQJixU",
      fallback_video_id: "6OvNNJQJixU",
      search_query: "Data privacy lawyer interview questions CIPP exam DPDP viva mock",
      channel_name: "Privacy Bar & Cybersecurity Law Prep",
      duration: "57:50",
      difficulty: "Placement",
      topic_focus: "Privacy Counsel Associate Placement & CIPP/E / DPDP Viva Preparation",
      key_takeaways: [
        "Cracking privacy counsel interview questions for Big Tech and fintech firms",
        "Handling scenario questions on handling regulatory inquiries from the Data Protection Board",
        "Distinguishing anonymized data vs pseudonymized data under legal definitions",
        "Career pathways and certification guidance (CIPP/E, CIPM, CIPT, DSCI DCPLA)"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // law-fintech
  // --------------------------------------------------------------------------
  'law-fintech': {
    0: [{
      id: "law-fintech-p0-5qM8mK",
      title: "FinTech Regulatory Ecosystem & RBI Digital Payment Frameworks",
      youtube_video_id: "wJBkOR8pPDQ",
      youtube_url: "https://www.youtube.com/watch?v=wJBkOR8pPDQ",
      fallback_video_id: "wJBkOR8pPDQ",
      search_query: "FinTech law basics RBI digital payments Payment and Settlement Systems Act",
      channel_name: "Banking & Financial Law Institute",
      duration: "1:11:15",
      difficulty: "Beginner",
      topic_focus: "FinTech Regulatory Ecosystem & RBI Digital Payment Frameworks",
      key_takeaways: [
        "Payment and Settlement Systems Act 2007 (PSSA) regulatory boundaries",
        "Payment Aggregators (PA) vs Payment Gateways (PG) licensing requirements",
        "Prepaid Payment Instruments (PPI) guidelines: wallets, gift cards, KYC tiers",
        "Account Aggregator (AA) framework and consent-driven financial data sharing"
      ]
    }],
    1: [{
      id: "law-fintech-p1-8mK1vP",
      title: "RBI Digital Lending Guidelines (DLG) & First Loss Default Guarantees (FLDG)",
      youtube_video_id: "aDfuAUMhsq4",
      youtube_url: "https://www.youtube.com/watch?v=aDfuAUMhsq4",
      fallback_video_id: "aDfuAUMhsq4",
      search_query: "RBI Digital Lending Guidelines FLDG LSP RE compliance fintech",
      channel_name: "FinTech Legal Masterclass",
      duration: "1:25:30",
      difficulty: "Intermediate",
      topic_focus: "RBI Digital Lending Guidelines (DLG) & First Loss Default Guarantees (FLDG)",
      key_takeaways: [
        "Regulated Entities (RE) vs Lending Service Providers (LSP) legal relationships",
        "Direct fund disbursement mandates: prohibiting pool accounts and pass-throughs",
        "Structuring default loss guarantees under RBI First Loss Default Guarantee (FLDG) 5% cap",
        "Drafting Key Fact Statements (KFS), APR disclosures, and cooling-off period rules"
      ]
    }],
    2: [{
      id: "law-fintech-p2-2vN6mQ",
      title: "PMLA, Anti-Money Laundering (AML) & Video KYC Compliance Architecture",
      youtube_video_id: "Z-CWvL2HdjE",
      youtube_url: "https://www.youtube.com/watch?v=Z-CWvL2HdjE",
      fallback_video_id: "Z-CWvL2HdjE",
      search_query: "PMLA KYC master directions AML compliance suspicious transaction report",
      channel_name: "Financial Crime Legal Forum",
      duration: "1:20:00",
      difficulty: "Advanced",
      topic_focus: "PMLA, Anti-Money Laundering (AML) & Video KYC Compliance Architecture",
      key_takeaways: [
        "Prevention of Money Laundering Act (PMLA) 2002 statutory obligations for reporting entities",
        "RBI Master Directions on KYC: CKYC registry, Video-based Customer Identification (V-CIP)",
        "Filing Suspicious Transaction Reports (STR) and Cash Transaction Reports (CTR) with FIU-IND",
        "Cryptocurrency and Virtual Digital Assets (VDA) reporting under PMLA framework"
      ]
    }],
    3: [{
      id: "law-fintech-p3-6pB9mK",
      title: "Capstone: End-to-End Co-Lending Agreement & Digital Lending Compliance Audit",
      youtube_video_id: "l714UGnzauU",
      youtube_url: "https://www.youtube.com/watch?v=l714UGnzauU",
      fallback_video_id: "l714UGnzauU",
      search_query: "Co-lending agreement drafting RBI digital lending compliance audit capstone",
      channel_name: "FinTech General Counsel Clinic",
      duration: "1:41:10",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Drafting tripartite Co-Lending Agreement between Bank (RE) and NBFC-FinTech (LSP)",
        "Drafting comprehensive escrow waterfall, risk sharing, and loan servicing covenants",
        "Conducting data privacy and cybersecurity compliance review under RBI Master Directions",
        "Drafting audit sign-off memo for RBI inspection and board audit committee"
      ]
    }],
    4: [{
      id: "law-fintech-p4-1mP7vN",
      title: "FinTech & Banking Legal Counsel Placement & Regulatory Viva Prep",
      youtube_video_id: "Lcw9lKkNxfY",
      youtube_url: "https://www.youtube.com/watch?v=Lcw9lKkNxfY",
      fallback_video_id: "Lcw9lKkNxfY",
      search_query: "Fintech legal counsel interview questions banking lawyer viva RBI regulation",
      channel_name: "FinTech Legal Network Recruitment",
      duration: "1:04:30",
      difficulty: "Placement",
      topic_focus: "FinTech & Banking Legal Counsel Placement & Regulatory Viva Prep",
      key_takeaways: [
        "Tackling high-pressure interview cases on regulatory sandbox participation",
        "Explaining recurring mandate e-NACH rules and card tokenization architecture",
        "Interpreting RBI penal action precedents against non-compliant payment entities",
        "Interview strategy for leading FinTech unicorns and Tier-1 banking legal teams"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // av-ifr
  // --------------------------------------------------------------------------
  'av-ifr': {
    0: [{
      id: "av-ifr-p0-3bL8mK",
      title: "Instrument Flight Rules (IFR) Foundations: Cockpit Six-Pack & Gyro Physics",
      youtube_video_id: "giiRLMesFFA",
      youtube_url: "https://www.youtube.com/watch?v=giiRLMesFFA",
      fallback_video_id: "hVsx4XWafXg",
      search_query: "IFR basics instrument flying six pack pitot static instruments",
      channel_name: "Boldmethod & Aviation Theory",
      duration: "54:20",
      difficulty: "Beginner",
      topic_focus: "Instrument Flight Rules (IFR) Foundations",
      key_takeaways: [
        "Pitot-static instruments: airspeed indicator, altimeter, vertical speed indicator",
        "Gyroscopic instruments: attitude indicator, turn coordinator, heading indicator",
        "Spatial disorientation and optical illusions in instrument meteorological conditions (IMC)",
        "Standard rate turns, constant airspeed climbs/descents, and instrument scan patterns"
      ]
    }],
    1: [{
      id: "av-ifr-p1-7qM2vP",
      title: "Jeppesen Instrument Approach Plates: ILS, VOR & RNP Navigation",
      youtube_video_id: "aQViPd5XYk8",
      youtube_url: "https://www.youtube.com/watch?v=aQViPd5XYk8",
      fallback_video_id: "ecoO56yuI7M",
      search_query: "Jeppesen approach plate tutorial ILS VOR RNAV minima briefing",
      channel_name: "Flight Training Concepts",
      duration: "1:18:45",
      difficulty: "Intermediate",
      topic_focus: "Jeppesen Instrument Approach Plates",
      key_takeaways: [
        "Deconstructing Jeppesen 10-9 airport briefing and approach charts",
        "Instrument Landing System (ILS) localizer and glideslope intercept mechanics",
        "Decision Altitude (DA) vs Minimum Descent Altitude (MDA) and RVR requirements",
        "Standard Instrument Departures (SID) and Standard Terminal Arrival Routes (STAR)"
      ]
    }],
    2: [{
      id: "av-ifr-p2-4mP5vK",
      title: "Holding Procedures, En-Route Airways & Missed Approach Protocols",
      youtube_video_id: "hUFobPNQHPc",
      youtube_url: "https://www.youtube.com/watch?v=hUFobPNQHPc",
      fallback_video_id: "5GOvoIJ84SM",
      search_query: "IFR holding patterns direct teardrop parallel entry missed approach procedure",
      channel_name: "Captain Joe / Airline Pilot Academy",
      duration: "1:12:30",
      difficulty: "Advanced",
      topic_focus: "Holding Procedures, En-Route Airways & Missed Approach Protocols",
      key_takeaways: [
        "Holding pattern entry procedures: Direct, Teardrop, and Parallel calculations",
        "Wind correction angles and timing adjustments on inbound holding legs",
        "Executing missed approach procedures at decision altitude in zero visibility",
        "En-route low and high altitude airway chart navigation and minimum safe altitudes"
      ]
    }],
    3: [{
      id: "av-ifr-p3-8vN1mQ",
      title: "Capstone: Full Flight Simulator IFR Flight - Departure, En-Route to CAT II ILS Landing",
      youtube_video_id: "FDt1_UQKVe4",
      youtube_url: "https://www.youtube.com/watch?v=FDt1_UQKVe4",
      fallback_video_id: "67HpHkZWaM8",
      search_query: "Full flight simulator IFR flight plan SID STAR CAT II ILS landing capstone",
      channel_name: "Mentour Pilot Sim Training",
      duration: "1:36:15",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Pre-flight IFR flight plan filing with alternate airport fuel requirements",
        "Executing complex SID departure in heavy rain and IMC conditions",
        "En-route airway tracking and ATC clearance readback protocols",
        "Hand-flying precision CAT II ILS approach down to 100 ft minimums and landing"
      ]
    }],
    4: [{
      id: "av-ifr-p4-2kM4vP",
      title: "Airline Cadet Pilot IFR Simulator Assessment & Technical Viva Preparation",
      youtube_video_id: "JIL1LUcBelA",
      youtube_url: "https://www.youtube.com/watch?v=JIL1LUcBelA",
      fallback_video_id: "akA_shaj_OA",
      search_query: "Airline pilot simulator assessment cadet interview questions IFR viva",
      channel_name: "Airline Pilot Interview Prep",
      duration: "1:02:40",
      difficulty: "Placement",
      topic_focus: "Airline Cadet Pilot IFR Simulator Assessment & Technical Viva Preparation",
      key_takeaways: [
        "Aviation technical questions on altimeter setting errors (QNH vs QFE vs STD)",
        "Simulator assessment profile: raw data flying, engine failure after V1, ILS approach",
        "DODAR and NITS emergency decision-making model articulation in cockpit scenarios",
        "Cracking Indigo, Air India, and Emirates cadet pilot technical panels"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // av-fms
  // --------------------------------------------------------------------------
  'av-fms': {
    0: [{
      id: "av-fms-p0-5mK3vP",
      title: "Flight Management System (FMS / MCDU) Architecture & Core Philosophy",
      youtube_video_id: "4iebAvTybsg",
      youtube_url: "https://www.youtube.com/watch?v=4iebAvTybsg",
      fallback_video_id: "qC3HRRezJo4",
      search_query: "FMS MCDU basics Airbus Boeing flight management computer",
      channel_name: "Airbus & Boeing Flight Crew Training",
      duration: "52:45",
      difficulty: "Beginner",
      topic_focus: "Flight Management System (FMS / MCDU) Architecture & Core Philosophy",
      key_takeaways: [
        "FMS components: FMC computer, Multifunction Control Display Unit (MCDU), navigation database",
        "Philosophy of lateral navigation (LNAV) and vertical navigation (VNAV)",
        "Database validity dates, AIRAC cycles, and nav-aid frequency auto-tuning",
        "MCDU keyboard functions, line select keys (LSK), and page hierarchy"
      ]
    }],
    1: [{
      id: "av-fms-p1-9qN6vM",
      title: "MCDU Route Programming & Performance Initialization (PERF INIT)",
      youtube_video_id: "xMl2pDyKy78",
      youtube_url: "https://www.youtube.com/watch?v=xMl2pDyKy78",
      fallback_video_id: "sbObz4kZphM",
      search_query: "MCDU setup route programming PERF INIT cost index zero fuel weight",
      channel_name: "A320 / B737 Type Rating Prep",
      duration: "1:22:10",
      difficulty: "Intermediate",
      topic_focus: "MCDU Route Programming & Performance Initialization (PERF INIT)",
      key_takeaways: [
        "Step-by-step route entry: origin, destination, airways, and waypoints",
        "Selecting runway, SID, and STAR transitions with altitude and speed constraints",
        "Performance Initialization: Zero Fuel Weight (ZFW), ZFWCG, block fuel entry",
        "Cost Index (CI) calculation and its effect on ECON climb, cruise, and descent speeds"
      ]
    }],
    2: [{
      id: "av-fms-p2-1vB8mK",
      title: "In-Flight FMS Revisions: Direct-To, Offsets, Step Climbs & Fuel Predictions",
      youtube_video_id: "Z2US71UFRAg",
      youtube_url: "https://www.youtube.com/watch?v=Z2US71UFRAg",
      fallback_video_id: "RaLuKMzUnnU",
      search_query: "In flight FMS lateral revision direct to lateral offset step climb VNAV descent",
      channel_name: "Captain Joe Aviation Masterclass",
      duration: "1:15:30",
      difficulty: "Advanced",
      topic_focus: "In-Flight FMS Revisions",
      key_takeaways: [
        "Executing ATC Direct-To waypoints and radial intercepts cleanly in MCDU",
        "Lateral offsets for wake turbulence avoidance and strategic en-route separation",
        "Step climb optimization based on aircraft gross weight reduction during flight",
        "Monitoring Top of Descent (T/D), VNAV descent path profile, and deceleration points"
      ]
    }],
    3: [{
      id: "av-fms-p3-6mQ2vP",
      title: "Capstone: Complete MCDU Programming & RNAV/RNP Approach Execution",
      youtube_video_id: "tG_9AmzwRPI",
      youtube_url: "https://www.youtube.com/watch?v=tG_9AmzwRPI",
      fallback_video_id: "jrFcBLBu6zk",
      search_query: "MCDU flight plan RNP approach performance calculation capstone",
      channel_name: "Type Rating Instructor Simulator Series",
      duration: "1:33:50",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Programming complex mountainous RNAV (RNP) approach with RF legs",
        "Calculating takeoff performance: V1, VR, V2, flex temperature, and trim setting",
        "FMS handling of engine failure on departure: automatic EO SID activation",
        "RNAV approach briefing and autopilot autoflight management to touchdown"
      ]
    }],
    4: [{
      id: "av-fms-p4-4pN9vK",
      title: "Airline Type Rating & FMS Technical Viva Examination Masterclass",
      youtube_video_id: "nrWkP1pcNvE",
      youtube_url: "https://www.youtube.com/watch?v=nrWkP1pcNvE",
      fallback_video_id: "3bQpTI5O8jA",
      search_query: "A320 B737 FMS technical interview questions pilot viva type rating",
      channel_name: "Pilot Assessment & Type Rating Academy",
      duration: "58:15",
      difficulty: "Placement",
      topic_focus: "Airline Type Rating & FMS Technical Viva Examination Masterclass",
      key_takeaways: [
        "Explaining managed vs selected modes in Airbus and LNAV/VNAV vs MCP in Boeing",
        "Handling FMS map drift, dual FMC failure, and raw data reversion procedures",
        "Answering technical questions on required navigation performance (RNP 0.3)",
        "First Officer technical assessment panel questions on autoflight automation"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // av-meteo
  // --------------------------------------------------------------------------
  'av-meteo': {
    0: [{
      id: "av-meteo-p0-2vM7mQ",
      title: "Aviation Meteorology Foundations: Atmosphere, Pressure Systems & Wind",
      youtube_video_id: "6m06-3jN9so",
      youtube_url: "https://www.youtube.com/watch?v=6m06-3jN9so",
      fallback_video_id: "EoHRTKSyidA",
      search_query: "Aviation meteorology atmosphere standard pressure QNH winds aloft",
      channel_name: "Aviation Weather Center & Boldmethod",
      duration: "56:10",
      difficulty: "Beginner",
      topic_focus: "Aviation Meteorology Foundations",
      key_takeaways: [
        "International Standard Atmosphere (ISA): temperature lapse rate and pressure lapse rate",
        "High and low pressure systems, Coriolis force, and geostrophic wind behavior",
        "Pressure altitude, density altitude, and their critical impact on aircraft performance",
        "Sea breeze, mountain valley winds, and katabatic wind phenomena"
      ]
    }],
    1: [{
      id: "av-meteo-p1-7mK3vP",
      title: "METAR, TAF, SPECI & Significant Weather (SIGWX) Chart Decoding",
      youtube_video_id: "nb3gyUVVMlw",
      youtube_url: "https://www.youtube.com/watch?v=nb3gyUVVMlw",
      fallback_video_id: "nr2Sj2NFzwM",
      search_query: "METAR TAF decoding tutorial aviation weather charts SIGWX TEMPO BECMG",
      channel_name: "Flight Training Academy",
      duration: "1:16:30",
      difficulty: "Intermediate",
      topic_focus: "METAR, TAF, SPECI & Significant Weather (SIGWX) Chart Decoding",
      key_takeaways: [
        "Live METAR and SPECI decoding: wind gusts, visibility, runway visual range (RVR)",
        "Decoding Terminal Aerodrome Forecasts (TAF): FM, BECMG, TEMPO, PROB40 indicators",
        "Interpreting High-Level Significant Weather (SIGWX) charts: jet streams and tropopause height",
        "Analyzing upper-air winds and temperature charts for en-route flight planning"
      ]
    }],
    2: [{
      id: "av-meteo-p2-3qN8vM",
      title: "Severe Weather Hazards: Thunderstorms, Microbursts, Icing & CAT",
      youtube_video_id: "8RB1luMdHqA",
      youtube_url: "https://www.youtube.com/watch?v=8RB1luMdHqA",
      fallback_video_id: "xIHFP4oHvds",
      search_query: "Aviation severe weather thunderstorms microburst low level windshear icing CAT",
      channel_name: "Commercial Aviation Safety Institute",
      duration: "1:21:40",
      difficulty: "Advanced",
      topic_focus: "Severe Weather Hazards",
      key_takeaways: [
        "Thunderstorm life cycle: cumulus, mature, and dissipating stages with lightning hazards",
        "Low-Level Windshear and Microburst physics: recognizing airspeed divergence on approach",
        "Aircraft structural icing: rime, clear, and mixed ice accretion and de-icing boot ops",
        "Clear Air Turbulence (CAT) detection near jet streams and mountain waves"
      ]
    }],
    3: [{
      id: "av-meteo-p3-8vB5mK",
      title: "Capstone: Trans-Continental Flight Weather Briefing & In-Flight Severe Hazard Avoidance",
      youtube_video_id: "pF_9l47VEAQ",
      youtube_url: "https://www.youtube.com/watch?v=pF_9l47VEAQ",
      fallback_video_id: "s1-iX4M1Ssc",
      search_query: "Airline dispatcher flight weather briefing airborne radar storm avoidance capstone",
      channel_name: "Airline Operations Center (AOC) Training",
      duration: "1:37:20",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Authoring comprehensive pre-flight weather dossier for cross-country route",
        "Evaluating alternate airport suitability under marginal VMC and IFR conditions",
        "Airborne weather radar tilt and gain management for convective cloud tilt scans",
        "Executing inflight tactical deviations around severe convective squall lines"
      ]
    }],
    4: [{
      id: "av-meteo-p4-1mP6vN",
      title: "Pilot Meteorology DGCA / FAA CPL Exam & Airline Technical Viva Prep",
      youtube_video_id: "bij7075KyKU",
      youtube_url: "https://www.youtube.com/watch?v=bij7075KyKU",
      fallback_video_id: "uaQMYpIK3v4",
      search_query: "DGCA meteorology CPL exam questions pilot technical interview weather viva",
      channel_name: "DGCA Pilot Theory & Airline Recruitment",
      duration: "1:05:00",
      difficulty: "Placement",
      topic_focus: "Pilot Meteorology DGCA / FAA CPL Exam & Airline Technical Viva Prep",
      key_takeaways: [
        "High-probability exam questions on western disturbances, monsoons, and tropical revolving storms",
        "Decoding tricky TAF and SIGMET questions under time pressure",
        "Airline interview scenarios: deciding whether to divert, hold, or continue approach",
        "Cadet pilot technical viva questions on icing, altimetry errors, and windshear escape maneuvers"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // av-crm
  // --------------------------------------------------------------------------
  'av-crm': {
    0: [{
      id: "av-crm-p0-4mN1vP",
      title: "Crew Resource Management (CRM) Core Principles & Human Factors",
      youtube_video_id: "c-8rLmxAyH0",
      youtube_url: "https://www.youtube.com/watch?v=c-8rLmxAyH0",
      fallback_video_id: "mwT3S9W6rGk",
      search_query: "Crew Resource Management CRM human factors pilot situational awareness",
      channel_name: "FAA / EASA Human Factors Series",
      duration: "51:40",
      difficulty: "Beginner",
      topic_focus: "Crew Resource Management (CRM) Core Principles & Human Factors",
      key_takeaways: [
        "History of CRM: from cockpit authoritarianism to modern open communication",
        "The SHELL model: Software, Hardware, Environment, Liveware interactions",
        "Situational awareness: perception, comprehension, and projection of future state",
        "Fatigue, stress, circadian rhythm disruption, and personal risk mitigation"
      ]
    }],
    1: [{
      id: "av-crm-p1-9vK4mQ",
      title: "Standard Operating Procedures (SOPs), Callouts & Sterile Cockpit Rule",
      youtube_video_id: "72Ee59KrQeg",
      youtube_url: "https://www.youtube.com/watch?v=72Ee59KrQeg",
      fallback_video_id: "_oFS7i_OMkI",
      search_query: "Sterile cockpit rule standard callouts SOP pilot monitoring pilot flying",
      channel_name: "Airline Flight Operations Training",
      duration: "1:14:20",
      difficulty: "Intermediate",
      topic_focus: "Standard Operating Procedures (SOPs), Callouts & Sterile Cockpit Rule",
      key_takeaways: [
        "Sterile cockpit rule below 10,000 feet: elimination of non-operational discussions",
        "Division of duties: Pilot Flying (PF) vs Pilot Monitoring (PM) cross-checks",
        "Standard callouts for takeoff, approach, runway alignment, and altitude deviations",
        "Checklist discipline: read-and-do vs challenge-and-response protocols"
      ]
    }],
    2: [{
      id: "av-crm-p2-2qP7mN",
      title: "Threat & Error Management (TEM) & Cockpit Communication Assertiveness",
      youtube_video_id: "cb7E7kjHGYw",
      youtube_url: "https://www.youtube.com/watch?v=cb7E7kjHGYw",
      fallback_video_id: "VYKQ6xTco3E",
      search_query: "Threat and Error Management TEM pilot assertiveness PACE model",
      channel_name: "Flight Safety Foundation",
      duration: "1:19:50",
      difficulty: "Advanced",
      topic_focus: "Threat & Error Management (TEM) & Cockpit Communication Assertiveness",
      key_takeaways: [
        "Threat and Error Management framework: latent threats, active errors, undesired states",
        "Assertiveness escalation using the PACE model (Probe, Alert, Challenge, Emergency)",
        "Two-challenge rule when aircraft trajectory deviates from assigned clearance",
        "Overcoming cockpit authority gradients between seasoned captains and junior first officers"
      ]
    }],
    3: [{
      id: "av-crm-p3-6vB8mK",
      title: "Capstone: High-Stress Emergency Simulation - Engine Flameout & DODAR / NITS Decision",
      youtube_video_id: "nzvcNUkJ6Gg",
      youtube_url: "https://www.youtube.com/watch?v=nzvcNUkJ6Gg",
      fallback_video_id: "47y-sqoMU8o",
      search_query: "Simulator emergency engine failure DODAR NITS briefing cabin crew capstone",
      channel_name: "Mentour Pilot CRM Masterclass",
      duration: "1:34:40",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Applying DODAR structured decision model: Diagnose, Options, Decide, Act, Review",
        "Delivering structured NITS briefing to cabin senior: Nature, Intentions, Time, Special instructions",
        "Managing workload distribution under dual generator failure and severe turbulence",
        "Executing safe forced diversion landing with synchronized emergency services coordination"
      ]
    }],
    4: [{
      id: "av-crm-p4-5mP2vN",
      title: "Airline Pilot Competency-Based CRM Interview & Group Exercise Prep",
      youtube_video_id: "yuD5cVsnaMI",
      youtube_url: "https://www.youtube.com/watch?v=yuD5cVsnaMI",
      fallback_video_id: "SKUTwzBvdPc",
      search_query: "Pilot CRM interview questions group exercise assessment day pilot competency",
      channel_name: "Airline Command Assessment Prep",
      duration: "59:10",
      difficulty: "Placement",
      topic_focus: "Airline Pilot Competency-Based CRM Interview & Group Exercise Prep",
      key_takeaways: [
        "Navigating airline assessment center group exercises without dominating or withdrawing",
        "Answering STAR-format behavioral questions on conflict resolution in the flight deck",
        "Demonstrating emotional intelligence, assertiveness, and psychological safety in teams",
        "Captain command upgrade interview evaluation criteria"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // av-weightbal
  // --------------------------------------------------------------------------
  'av-weightbal': {
    0: [{
      id: "av-weightbal-p0-1vM9mQ",
      title: "Aircraft Weight and Balance Fundamentals: Datum, Arm, Moment & CG",
      youtube_video_id: "hLaQnW40YvA",
      youtube_url: "https://www.youtube.com/watch?v=hLaQnW40YvA",
      fallback_video_id: "BMbI0rmjDVo",
      search_query: "Aircraft weight and balance datum arm moment center of gravity CG",
      channel_name: "Aviation Theory Centre & Boldmethod",
      duration: "53:15",
      difficulty: "Beginner",
      topic_focus: "Aircraft Weight and Balance Fundamentals",
      key_takeaways: [
        "Weight and balance definitions: Reference Datum, Arm, Moment, and Center of Gravity (CG)",
        "Basic Empty Weight, Maximum Zero Fuel Weight (MZFW), Max Takeoff Weight (MTOW)",
        "CG limits: forward CG consequences (heavy stick, higher stall speed) vs aft CG (instability)",
        "Mathematical computation of loaded CG using tabular and moment index methods"
      ]
    }],
    1: [{
      id: "av-weightbal-p1-7mK4vP",
      title: "Commercial Loadsheets, Trim Sheets & %MAC Calculation",
      youtube_video_id: "XxzBpZMp08A",
      youtube_url: "https://www.youtube.com/watch?v=XxzBpZMp08A",
      fallback_video_id: "ffDxrgGyIVM",
      search_query: "Commercial aircraft loadsheet trim sheet MAC mean aerodynamic chord index",
      channel_name: "Flight Operations Ground School",
      duration: "1:18:00",
      difficulty: "Intermediate",
      topic_focus: "Commercial Loadsheets, Trim Sheets & %MAC Calculation",
      key_takeaways: [
        "Understanding Mean Aerodynamic Chord (%MAC) and translating inches to %MAC",
        "Manual trim sheet plotting: fuel index arrows, cargo hold distribution, passenger index",
        "Determining stabilizer trim setting (STAB TRIM units) for takeoff pitch trim",
        "Underload before last-minute changes (LMC) and maximum allowable traffic load"
      ]
    }],
    2: [{
      id: "av-weightbal-p2-3qN1vM",
      title: "Takeoff V-Speeds Architecture: V1 Decision, VR Rotate, V2 Climb & Balanced Field",
      youtube_video_id: "7p8Pqna4t7c",
      youtube_url: "https://www.youtube.com/watch?v=7p8Pqna4t7c",
      fallback_video_id: "xsD8VmNaXA8",
      search_query: "Takeoff performance V speeds V1 VR V2 balanced field length accelerate stop",
      channel_name: "Captain Joe Aerodynamics & Performance",
      duration: "1:24:20",
      difficulty: "Advanced",
      topic_focus: "Takeoff V-Speeds Architecture",
      key_takeaways: [
        "V1 Takeoff Decision Speed: accelerate-stop distance equal to accelerate-go distance",
        "VR Rotation Speed and tail strike prevention pitch attitudes",
        "V2 Takeoff Safety Speed and obstacle clearance second segment climb gradients",
        "Derated thrust and flexible temperature (FLEX/ASSUME TEMP) takeoff operations"
      ]
    }],
    3: [{
      id: "av-weightbal-p3-8vB3mK",
      title: "Capstone: Complete Electronic Flight Bag (EFB) Takeoff Performance Calculation & Loadsheet",
      youtube_video_id: "dc2VOHTDplA",
      youtube_url: "https://www.youtube.com/watch?v=dc2VOHTDplA",
      fallback_video_id: "me3KVZiQcn0",
      search_query: "Electronic Flight Bag EFB performance calculation loadsheet runway analysis capstone",
      channel_name: "Airline Operations Center (AOC) Training",
      duration: "1:38:40",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Computing runway performance on EFB: contaminated runway (rain/snow) corrections",
        "Generating digital operational loadsheet and verifying CG envelope margins",
        "Accounting for intersection takeoffs, clearway, stopway, and obstacle envelopes",
        "Validating aircraft cross-check between Pilot Flying and Pilot Monitoring before pushback"
      ]
    }],
    4: [{
      id: "av-weightbal-p4-2mP8vN",
      title: "Airline Technical Viva & DGCA CPL Aircraft Performance Exam Prep",
      youtube_video_id: "0fT3fzvdgQU",
      youtube_url: "https://www.youtube.com/watch?v=0fT3fzvdgQU",
      fallback_video_id: "0ZlPsrhWQ8I",
      search_query: "Pilot technical interview questions weight and balance V speeds viva DGCA exam",
      channel_name: "DGCA CPL Exam & Airline Technical Prep",
      duration: "1:01:45",
      difficulty: "Placement",
      topic_focus: "Airline Technical Viva & DGCA CPL Aircraft Performance Exam Prep",
      key_takeaways: [
        "High-probability interview questions on CG shift with fuel burn in swept-wing jets",
        "Handling emergency scenarios: rejected takeoff after V1 vs before V1",
        "Explaining Vmcg, Vmca, and critical engine failure in multi-engine aircraft",
        "Cracking airline induction technical tests on performance charts and trim units"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // av-airlaw
  // --------------------------------------------------------------------------
  'av-airlaw': {
    0: [{
      id: "av-airlaw-p0-6vM2mQ",
      title: "Air Law Fundamentals: Chicago Convention, ICAO Annexes & Airspace Classes",
      youtube_video_id: "BxSJ_ieFcgE",
      youtube_url: "https://www.youtube.com/watch?v=BxSJ_ieFcgE",
      fallback_video_id: "2yRBRGjcHAw",
      search_query: "Chicago Convention 1944 ICAO Annexes airspace classification Class A to G",
      channel_name: "ICAO & Aviation Legal Academy",
      duration: "55:30",
      difficulty: "Beginner",
      topic_focus: "Air Law Fundamentals",
      key_takeaways: [
        "Chicago Convention of 1944: sovereignty over airspace and the 5 Freedoms of the Air",
        "Key ICAO Annexes: Annex 2 (Rules of the Air), Annex 6 (Operation of Aircraft), Annex 14 (Aerodromes)",
        "Airspace classification: controlled airspace (Classes A, B, C, D, E) vs uncontrolled (Classes F, G)",
        "Visual Flight Rules (VFR) vs Instrument Flight Rules (IFR) legal flight criteria"
      ]
    }],
    1: [{
      id: "av-airlaw-p1-9mK5vP",
      title: "DGCA Civil Aviation Requirements (CAR) & Pilot Licensing Regulations",
      youtube_video_id: "WQHr1EvCRvw",
      youtube_url: "https://www.youtube.com/watch?v=WQHr1EvCRvw",
      fallback_video_id: "S_qgIDGBOBU",
      search_query: "DGCA CAR regulations Section 7 flight duty time FDTL pilot licensing",
      channel_name: "DGCA Air Law Ground School",
      duration: "1:20:15",
      difficulty: "Intermediate",
      topic_focus: "DGCA Civil Aviation Requirements (CAR) & Pilot Licensing Regulations",
      key_takeaways: [
        "DGCA Civil Aviation Requirements (CAR) structure: Section 2 (Airworthiness), Section 7 (Flight Crew)",
        "Flight and Duty Time Limitations (FDTL) and rest period legal mandates",
        "Pilot licensing requirements: medical assessment Class 1, validity, instrument rating renewals",
        "Alcohol breathalyzer testing protocols (Pre-flight and Post-flight CAR requirements)"
      ]
    }],
    2: [{
      id: "av-airlaw-p2-4qN3vM",
      title: "Rules of the Air, Separation Minima, Squawk Codes & Right of Way",
      youtube_video_id: "3jdjlhwBgJk",
      youtube_url: "https://www.youtube.com/watch?v=3jdjlhwBgJk",
      fallback_video_id: "5i6td2PLJDk",
      search_query: "Rules of the air right of way emergency squawk codes 7500 7600 7700 separation",
      channel_name: "Air Traffic Management Masterclass",
      duration: "1:16:50",
      difficulty: "Advanced",
      topic_focus: "Rules of the Air, Separation Minima, Squawk Codes & Right of Way",
      key_takeaways: [
        "Right of way rules: converging, head-on, overtaking, and aircraft landing priorities",
        "Radar and procedural separation minima: vertical separation (RVSM) and lateral separation",
        "Emergency transponder squawk codes: 7500 (Hijack), 7600 (Radio Failure), 7700 (General Emergency)",
        "Intercept protocols: military interception of civil aircraft and signaling procedures"
      ]
    }],
    3: [{
      id: "av-airlaw-p3-1vB7mK",
      title: "Capstone: Aviation Incident Legal Investigation Briefing & DGCA CAR Compliance Audit",
      youtube_video_id: "-t7YYbkw_rU",
      youtube_url: "https://www.youtube.com/watch?v=-t7YYbkw_rU",
      fallback_video_id: "JTvZaSjGhB0",
      search_query: "Aviation accident investigation Annex 13 DGCA CAR compliance audit capstone",
      channel_name: "Aviation Safety & Regulatory Clinic",
      duration: "1:35:10",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "ICAO Annex 13 accident and incident investigation protocols: AAIB mandate",
        "CVR and FDR black box preservation and legal chain of custody",
        "Conducting airline internal compliance audit against updated DGCA CAR circulars",
        "Drafting formal mandatory occurrence report (MOR) to regulatory authorities"
      ]
    }],
    4: [{
      id: "av-airlaw-p4-7mP1vN",
      title: "DGCA Air Law CPL Exam & Airline Technical Interview Preparation",
      youtube_video_id: "rg97o188bMQ",
      youtube_url: "https://www.youtube.com/watch?v=rg97o188bMQ",
      fallback_video_id: "NSx6CV6BxI0",
      search_query: "DGCA Air Law CPL exam questions pilot interview air regulations viva",
      channel_name: "DGCA Air Law Masterclass",
      duration: "1:03:20",
      difficulty: "Placement",
      topic_focus: "DGCA Air Law CPL Exam & Airline Technical Interview Preparation",
      key_takeaways: [
        "Comprehensive review of 100 high-frequency DGCA Air Law exam questions",
        "Resolving ambiguous questions on RVSM airspace equipment mandates and contingency routes",
        "Airline interview questions on handling unruly passengers under CAR Section 3",
        "Defending pilot actions in hypothetical ATC violation and altitude bust hearings"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // cc-safety
  // --------------------------------------------------------------------------
  'cc-safety': {
    0: [{
      id: "cc-safety-p0-5vM1mQ",
      title: "In-Flight Safety & Cabin Architecture Fundamentals",
      youtube_video_id: "rGEGD_GYguM",
      youtube_url: "https://www.youtube.com/watch?v=rGEGD_GYguM",
      fallback_video_id: "ax4B6cEMoGQ",
      search_query: "Cabin crew safety equipment pre flight check emergency doors architecture",
      channel_name: "Aviation Training Academy & British Airways Crew",
      duration: "52:10",
      difficulty: "Beginner",
      topic_focus: "In-Flight Safety & Cabin Architecture Fundamentals",
      key_takeaways: [
        "Pre-flight emergency equipment check: life vests, oxygen bottles, fire extinguishers, megaphones",
        "Aircraft door operations: arming, disarming, girt bar engagement, and mechanical door indicators",
        "Passenger safety briefing: life jacket demonstration, emergency exit locations, oxygen masks",
        "Cabin secure for takeoff and landing: tray tables, window blinds, seat belts, baggage stowage"
      ]
    }],
    1: [{
      id: "cc-safety-p1-8mK7vP",
      title: "Emergency Evacuation Procedures: 90-Second Certification Standard",
      youtube_video_id: "cjRLAOfjEJg",
      youtube_url: "https://www.youtube.com/watch?v=cjRLAOfjEJg",
      fallback_video_id: "VRmMU6isIYQ",
      search_query: "Aircraft emergency evacuation drill 90 seconds slide raft deployment cabin crew",
      channel_name: "Airline Cabin Safety Training",
      duration: "1:19:40",
      difficulty: "Intermediate",
      topic_focus: "Emergency Evacuation Procedures",
      key_takeaways: [
        "The 90-second evacuation mandate with 50% exits blocked under FAA/EASA certification",
        "Slide raft automatic and manual inflation procedures: handle pull and aspirator inspection",
        "Overwing exit operation: window removal, lanyard attachment, and evacuation commands",
        "Standard evacuation commands: OPEN SEAT BELTS, LEAVE EVERYTHING, COME THIS WAY"
      ]
    }],
    2: [{
      id: "cc-safety-p2-3qN5vM",
      title: "Rapid Decompression & Ditching (Water Landing) Drills",
      youtube_video_id: "OT4GhbnUwUk",
      youtube_url: "https://www.youtube.com/watch?v=OT4GhbnUwUk",
      fallback_video_id: "kxPjj20pQ4Y",
      search_query: "Rapid decompression drill ditching water landing cabin crew safety training",
      channel_name: "Flight Attendant Safety School",
      duration: "1:15:30",
      difficulty: "Advanced",
      topic_focus: "Rapid Decompression & Ditching (Water Landing) Drills",
      key_takeaways: [
        "Recognizing rapid decompression: loud bang, fog, rushing air, sudden drop in temperature",
        "Crew immediate action: donning nearest oxygen mask, sitting down, bracing",
        "Post-decompression cabin sweep: administering portable oxygen to hypoxemic passengers",
        "Ditching procedures: life jacket donning discipline, survival kit deployment, raft boarding"
      ]
    }],
    3: [{
      id: "cc-safety-p3-9vB4mK",
      title: "Capstone: High-Fidelity Cabin Emergency Evacuation Drill in Smoke Simulator",
      youtube_video_id: "sFS9uX4YpLI",
      youtube_url: "https://www.youtube.com/watch?v=sFS9uX4YpLI",
      fallback_video_id: "5C_d65kkE_s",
      search_query: "Cabin crew emergency simulator smoke drill evacuation capstone Emirates",
      channel_name: "Emirates Cabin Safety Center",
      duration: "1:33:20",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Managing panic and zero-visibility evacuation in full-cabin mock-up filled with synthetic smoke",
        "Assessing exit usability: checking for fire, water, or debris outside viewing window",
        "Redirecting passenger flows away from jammed exits using commanding assertiveness",
        "Final sweep of cabin and flight deck to ensure zero passenger abandonment"
      ]
    }],
    4: [{
      id: "cc-safety-p4-2mP9vN",
      title: "Cabin Crew Safety Recurrent & Airline Assessment Day Interview Prep",
      youtube_video_id: "ZrHSME20igs",
      youtube_url: "https://www.youtube.com/watch?v=ZrHSME20igs",
      fallback_video_id: "FPVNfDBA4CY",
      search_query: "Cabin crew interview questions safety procedures assessment day mock interview",
      channel_name: "Cabin Crew Excellence & Recruitment",
      duration: "57:40",
      difficulty: "Placement",
      topic_focus: "Cabin Crew Safety Recurrent & Airline Assessment Day Interview Prep",
      key_takeaways: [
        "Answering challenging safety scenario questions in Qatar Airways and Emirates interviews",
        "Explaining the exact difference between armed and disarmed door states",
        "Roleplaying high-pressure safety compliance scenarios with non-compliant passengers",
        "Demonstrating executive calm and authoritative command voice under pressure"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // cc-firstaid
  // --------------------------------------------------------------------------
  'cc-firstaid': {
    0: [{
      id: "cc-firstaid-p0-6vM8mQ",
      title: "Aviation First Aid Fundamentals: Primary Survey & Emergency Medical Kit (EMK)",
      youtube_video_id: "h5iKxHO5oVY",
      youtube_url: "https://www.youtube.com/watch?v=h5iKxHO5oVY",
      fallback_video_id: "VwY6QHCAxDM",
      search_query: "Aviation first aid primary survey DRABC emergency medical kit EMK cabin crew",
      channel_name: "Red Cross Aviation First Aid Training",
      duration: "54:30",
      difficulty: "Beginner",
      topic_focus: "Aviation First Aid Fundamentals",
      key_takeaways: [
        "DRABC primary survey: Danger, Response, Airway, Breathing, Circulation assessment",
        "Emergency Medical Kit (EMK) vs First Aid Kit (FAK) contents and authorized usage",
        "Universal Precautions: personal protective equipment, gloves, sharps container, biohazard bag",
        "Communicating passenger medical distress to flight deck via interphone"
      ]
    }],
    1: [{
      id: "cc-firstaid-p1-1mK3vP",
      title: "In-Flight CPR & Automated External Defibrillator (AED) Operations",
      youtube_video_id: "M6ovzv3Fe6w",
      youtube_url: "https://www.youtube.com/watch?v=M6ovzv3Fe6w",
      fallback_video_id: "hTS6gtaTHcI",
      search_query: "In flight CPR automated external defibrillator AED cabin crew training",
      channel_name: "American Heart Association Crew Training",
      duration: "1:17:15",
      difficulty: "Intermediate",
      topic_focus: "In-Flight CPR & Automated External Defibrillator (AED) Operations",
      key_takeaways: [
        "High-quality CPR in cramped cabin aisle: 30 compressions to 2 rescue breaths at 100-120 bpm",
        "AED operation: pad placement, clearing passengers during shock analysis and delivery",
        "CPR cycle management during turbulence and emergency descent",
        "Paging for medical doctor volunteers on board and MedLink satellite consultation"
      ]
    }],
    2: [{
      id: "cc-firstaid-p2-4qN9vM",
      title: "Managing Hypoxia, Hyperventilation, Stroke, Burns & Bleeding",
      youtube_video_id: "K0TT6nJU3jc",
      youtube_url: "https://www.youtube.com/watch?v=K0TT6nJU3jc",
      fallback_video_id: "pjQm4m5uD-w",
      search_query: "In flight medical emergency hypoxia stroke severe bleeding cabin crew protocol",
      channel_name: "Flight Medic & Aviation Health Guild",
      duration: "1:14:40",
      difficulty: "Advanced",
      topic_focus: "Managing Hypoxia, Hyperventilation, Stroke, Burns & Bleeding",
      key_takeaways: [
        "Recognizing hypoxia: cyanosis, confusion, euphoria; administering portable oxygen at 4L/min",
        "Stroke FAST assessment (Face, Arms, Speech, Time) and recovery position management",
        "Arterial bleeding control: direct pressure, pressure bandages, and tourniquet protocols",
        "Treating galley scalding burns and managing in-flight anaphylactic allergic shocks with EpiPen"
      ]
    }],
    3: [{
      id: "cc-firstaid-p3-7vB2mK",
      title: "Capstone: Managing Critical In-Flight Cardiac Arrest & Unscheduled Medical Diversion",
      youtube_video_id: "uhAVzOwnIU8",
      youtube_url: "https://www.youtube.com/watch?v=uhAVzOwnIU8",
      fallback_video_id: "vDwao0HOUk8",
      search_query: "In flight cardiac arrest diversion simulation cabin crew doctor coordination capstone",
      channel_name: "Aviation Medicine Clinical Simulation",
      duration: "1:36:00",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Simulating full resuscitation protocol: CPR, AED shock, and physician coordination",
        "Providing MedLink telemedicine updates: vitals, pulse rate, oxygen saturation, pupil dilation",
        "Advising Captain on passenger criticality to support diversion decision to nearest airport",
        "Handover documentation and briefing paramedical emergency teams upon landing"
      ]
    }],
    4: [{
      id: "cc-firstaid-p4-3mP4vN",
      title: "Cabin Crew First Aid Practical Exam & Airline Medical Viva Prep",
      youtube_video_id: "2iGL-ErTTIc",
      youtube_url: "https://www.youtube.com/watch?v=2iGL-ErTTIc",
      fallback_video_id: "ueJrsVEdtZA",
      search_query: "Cabin crew first aid exam practical test CPR AED viva questions airline interview",
      channel_name: "Aviation Medical Examiners Academy",
      duration: "56:20",
      difficulty: "Placement",
      topic_focus: "Cabin Crew First Aid Practical Exam & Airline Medical Viva Prep",
      key_takeaways: [
        "Step-by-step practical demonstration tips for AED pad placement on pediatric and adult manikins",
        "Resolving complex triage questions: deciding priority between multiple injured passengers",
        "Handling in-flight emergency childbirth scenarios with specialized delivery kits",
        "Acing first-aid assessment station in top international airline recruitment drives"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // cc-dgca
  // --------------------------------------------------------------------------
  'cc-dgca': {
    0: [{
      id: "cc-dgca-p0-8vM4mQ",
      title: "DGCA & IATA Cabin Safety Regulations: Legal Mandates & CAR Section 3",
      youtube_video_id: "WX2p3e3-XMQ",
      youtube_url: "https://www.youtube.com/watch?v=WX2p3e3-XMQ",
      fallback_video_id: "iQen0Xj1odk",
      search_query: "DGCA CAR Section 3 cabin crew safety regulations IATA standards",
      channel_name: "DGCA Aviation Safety Academy",
      duration: "50:45",
      difficulty: "Beginner",
      topic_focus: "DGCA & IATA Cabin Safety Regulations",
      key_takeaways: [
        "DGCA Civil Aviation Requirements (CAR) Section 3 Series M: Passenger care and facilitation",
        "Minimum cabin crew complement rules based on passenger seating capacity",
        "Pre-flight safety briefings and mandatory passenger announcement scripts",
        "Alcohol serving guidelines and identifying intoxicated passengers before boarding"
      ]
    }],
    1: [{
      id: "cc-dgca-p1-2mK8vP",
      title: "Dangerous Goods Regulations (DGR): IATA Categories & Lithium Battery Protocols",
      youtube_video_id: "ogcjTkB8xCU",
      youtube_url: "https://www.youtube.com/watch?v=ogcjTkB8xCU",
      fallback_video_id: "MzcRfVUq60I",
      search_query: "IATA dangerous goods regulations cabin crew lithium battery thermal runaway",
      channel_name: "IATA Dangerous Goods School",
      duration: "1:21:00",
      difficulty: "Intermediate",
      topic_focus: "Dangerous Goods Regulations (DGR)",
      key_takeaways: [
        "Classification of 9 Dangerous Goods classes: explosives, gases, flammables, toxics, corrosives",
        "Acceptable baggage items vs prohibited dangerous goods in cabin and cargo holds",
        "Lithium-ion battery thermal runaway containment: using water/non-alcoholic liquid and thermal burn bag",
        "Dangerous goods emergency drill: isolation, pilot notification, and post-flight reporting"
      ]
    }],
    2: [{
      id: "cc-dgca-p2-5qN2vM",
      title: "Aviation Security Protocols: Hijacking, Bomb Threat & Disruptive Passengers",
      youtube_video_id: "LhnUfU_nX6Q",
      youtube_url: "https://www.youtube.com/watch?v=LhnUfU_nX6Q",
      fallback_video_id: "sRLcql1YWnI",
      search_query: "Aviation security cabin crew bomb threat search hijack protocol BCAS DGCA",
      channel_name: "Aviation Security Training Academy",
      duration: "1:16:15",
      difficulty: "Advanced",
      topic_focus: "Aviation Security Protocols",
      key_takeaways: [
        "BCAS (Bureau of Civil Aviation Security) mandates: flight deck door locked protocols",
        "Levels of disruptive behavior: Level 1 (verbal), Level 2 (physical), Level 3 (life-threatening), Level 4 (cockpit breach)",
        "Least Risk Bomb Location (LRBL) procedure: positioning improvised explosive device with wetted blankets",
        "Hijacking response: compliance strategy, subtle transponder communication with flight crew"
      ]
    }],
    3: [{
      id: "cc-dgca-p3-9vB7mK",
      title: "Capstone: Comprehensive Cabin Security Inspection & Pre-Flight DGR Audit",
      youtube_video_id: "eVOXVaj_5m0",
      youtube_url: "https://www.youtube.com/watch?v=eVOXVaj_5m0",
      fallback_video_id: "8UKJquReZEM",
      search_query: "Pre flight security check cabin sweep dangerous goods audit capstone",
      channel_name: "Airline Quality & Compliance Center",
      duration: "1:34:50",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Executing systematic pre-boarding security search: overhead bins, seat pockets, under cushions, galleys",
        "Detecting disguised prohibited dangerous goods: e-cigarettes, aerosols, uncertified power banks",
        "Authoring pre-flight security sign-off manifest for flight purser and captain",
        "Handling DGCA / FAA surprise ramp inspection on board with complete regulatory compliance"
      ]
    }],
    4: [{
      id: "cc-dgca-p4-4mP6vN",
      title: "DGCA Cabin Crew Competency Exam & Airline Security Viva Prep",
      youtube_video_id: "z2Md3R4jOJU",
      youtube_url: "https://www.youtube.com/watch?v=z2Md3R4jOJU",
      fallback_video_id: "LJpEtUAW9hw",
      search_query: "DGCA cabin crew exam questions DGR security interview questions airline recruitment",
      channel_name: "Cabin Crew Training Institute",
      duration: "58:30",
      difficulty: "Placement",
      topic_focus: "DGCA Cabin Crew Competency Exam & Airline Security Viva Prep",
      key_takeaways: [
        "Mastering high-yield questions on DGCA CAR guidelines, security check steps, and DGR limits",
        "Explaining the exact protocol for passenger refusal to wear seatbelts or turn off phones",
        "Airline assessment day technical questions on fire-resistant stowage and cabin baggage dimensions",
        "Securing DGCA Cabin Crew Attestation (CCA) certification"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // cc-hospitality
  // --------------------------------------------------------------------------
  'cc-hospitality': {
    0: [{
      id: "cc-hospitality-p0-7vM9mQ",
      title: "World-Class In-Flight Hospitality: First & Business Class Etiquette",
      youtube_video_id: "oY_XLZlpuzA",
      youtube_url: "https://www.youtube.com/watch?v=oY_XLZlpuzA",
      fallback_video_id: "ufw4m-wIDA4",
      search_query: "First class cabin crew hospitality service etiquette fine dining Emirates",
      channel_name: "Etihad & Emirates In-Flight Service Academy",
      duration: "53:40",
      difficulty: "Beginner",
      topic_focus: "World-Class In-Flight Hospitality",
      key_takeaways: [
        "The philosophy of luxury aviation hospitality: anticipatory service and brand elegance",
        "First and business class table setting: linen placement, porcelain layout, silverware alignment",
        "Fine wine and champagne service: presentation, cork uncorking, temperature, and pouring angles",
        "Menu presentation, dietary requirements (vegan, gluten-free, halal, kosher), and gourmet plating"
      ]
    }],
    1: [{
      id: "cc-hospitality-p1-3mK2vP",
      title: "Galley Management, Food Safety (HACCP) & Convection Oven Operations",
      youtube_video_id: "sMzOMXs8iTc",
      youtube_url: "https://www.youtube.com/watch?v=sMzOMXs8iTc",
      fallback_video_id: "qi6kqJ1umeU",
      search_query: "Galley management airline convection oven food safety HACCP trolley workflow",
      channel_name: "In-Flight Catering & Galley Operations",
      duration: "1:18:20",
      difficulty: "Intermediate",
      topic_focus: "Galley Management, Food Safety (HACCP) & Convection Oven Operations",
      key_takeaways: [
        "Galley ergonomics and meal stowage: organizing beverage carts and dry goods containers",
        "Aircraft steam/convection oven operations: heating profiles, timer management, and temperature checks",
        "HACCP food safety standards: preventing bacterial growth, cross-contamination, and food poisoning",
        "Bar cart workflow: efficient aisle beverage service in economy class within schedule windows"
      ]
    }],
    2: [{
      id: "cc-hospitality-p2-6qN4vM",
      title: "VIP Passenger Psychology, Cross-Cultural Communication & Special Care",
      youtube_video_id: "Kw3OLQtG2rU",
      youtube_url: "https://www.youtube.com/watch?v=Kw3OLQtG2rU",
      fallback_video_id: "HTCjmqfqedY",
      search_query: "VIP passenger service cross cultural communication cabin crew empathy",
      channel_name: "Luxury Hospitality Guild",
      duration: "1:12:50",
      difficulty: "Advanced",
      topic_focus: "VIP Passenger Psychology, Cross-Cultural Communication & Special Care",
      key_takeaways: [
        "Reading high-net-worth passenger body language: privacy needs vs conversational engagement",
        "Cross-cultural service nuances across Asian, Middle Eastern, European, and American travelers",
        "Caring for Unaccompanied Minors (UM), passengers with reduced mobility (PRM), and anxious flyers",
        "Managing high-altitude sensory desensitization and elevating culinary taste perceptions"
      ]
    }],
    3: [{
      id: "cc-hospitality-p3-1vB5mK",
      title: "Capstone: Long-Haul Multi-Course Fine Dining & Premium Turn-Down Service Simulation",
      youtube_video_id: "aKNEuNrM0Yw",
      youtube_url: "https://www.youtube.com/watch?v=aKNEuNrM0Yw",
      fallback_video_id: "1ENbMhycLwY",
      search_query: "Singapore Airlines business class service turn down bed fine dining capstone",
      channel_name: "Singapore Airlines Service Center",
      duration: "1:31:40",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Executing seamless 5-course gourmet dining service in full flight cabin simulator",
        "Synchronizing galley oven timing with aisle delivery to prevent course delays",
        "Delivering luxury turn-down bed service: mattress pad fitting, duvet arranging, amenity kit delivery",
        "Managing mid-flight passenger requests and quiet cabin ambient lighting management"
      ]
    }],
    4: [{
      id: "cc-hospitality-p4-8mP3vN",
      title: "Airlines Premium Service Assessment & Grooming Interview Masterclass",
      youtube_video_id: "Ex1PGEincrk",
      youtube_url: "https://www.youtube.com/watch?v=Ex1PGEincrk",
      fallback_video_id: "Tk56uHuwrAI",
      search_query: "Emirates cabin crew grooming standards interview service assessment hospitality test",
      channel_name: "Cabin Crew Grooming & Interview Prep",
      duration: "1:00:15",
      difficulty: "Placement",
      topic_focus: "Airlines Premium Service Assessment & Grooming Interview Masterclass",
      key_takeaways: [
        "International airline grooming standards: uniform posture, hair styling, skin care, makeup guidelines",
        "Acing customer service roleplays in Singapore Airlines, Emirates, and Qatar assessment days",
        "Resolving service complaints: missing special meals, delayed beverages, broken in-flight entertainment",
        "Demonstrating genuine warmth, poise, and hospitality passion during personal interviews"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // cc-conflict
  // --------------------------------------------------------------------------
  'cc-conflict': {
    0: [{
      id: "cc-conflict-p0-4vM7mQ",
      title: "Passenger Conflict Management & De-Escalation Psychology",
      youtube_video_id: "H01B1r2IA3w",
      youtube_url: "https://www.youtube.com/watch?v=H01B1r2IA3w",
      fallback_video_id: "9jpsPZGqYwY",
      search_query: "Passenger conflict de-escalation psychology verbal judo cabin crew",
      channel_name: "Aviation Conflict Resolution Institute",
      duration: "52:30",
      difficulty: "Beginner",
      topic_focus: "Passenger Conflict Management & De-Escalation Psychology",
      key_takeaways: [
        "Root causes of passenger conflict: flight delays, claustrophobia, alcohol, seating disputes",
        "Psychology of aggression: fight-or-flight triggers and signs of impending escalation",
        "Active listening and empathetic validation: CALM technique and non-defensive postures",
        "Setting firm boundaries without aggravating passenger dignity or provoking defiance"
      ]
    }],
    1: [{
      id: "cc-conflict-p1-9mK3vP",
      title: "Verbal De-Escalation Frameworks: The LAST Method & Assertive Communication",
      youtube_video_id: "tnEwpAdj1ig",
      youtube_url: "https://www.youtube.com/watch?v=tnEwpAdj1ig",
      fallback_video_id: "SwhxwuLlrOk",
      search_query: "LAST method Listen Apologize Solve Thank cabin crew conflict handling",
      channel_name: "Customer Service Crisis Training",
      duration: "1:16:45",
      difficulty: "Intermediate",
      topic_focus: "Verbal De-Escalation Frameworks",
      key_takeaways: [
        "The LAST method: Listen actively, Apologize for frustration, Solve practically, Thank for patience",
        "Using assertive I-statements instead of accusatory you-statements during disagreements",
        "Handling difficult seat change demands, overhead luggage disputes, and crying infant tensions",
        "Issuing formal verbal warnings regarding compliance with aircraft commander orders"
      ]
    }],
    2: [{
      id: "cc-conflict-p2-2qN8vM",
      title: "Unruly Passenger Levels 1-4 & Restraint Device Application Protocols",
      youtube_video_id: "7oXR2aOsJCc",
      youtube_url: "https://www.youtube.com/watch?v=7oXR2aOsJCc",
      fallback_video_id: "C-DA02JmCxQ",
      search_query: "Unruly passenger levels flexicuffs physical restraint cabin crew protocol",
      channel_name: "Aviation Security & Law Enforcement",
      duration: "1:22:10",
      difficulty: "Advanced",
      topic_focus: "Unruly Passenger Levels 1-4 & Restraint Device Application Protocols",
      key_takeaways: [
        "Classification of unruly behavior: Level 1 (Disruptive), Level 2 (Physically Abusive), Level 3 (Life Threatening)",
        "Issuing written Final Warning Notice signed by the Pilot-in-Command",
        "Authorizing passenger restraint: obtaining Captains consent and recruiting able-bodied passengers (ABP)",
        "Safe application of nylon flexi-cuffs and restraint kit without restricting airway or circulation"
      ]
    }],
    3: [{
      id: "cc-conflict-p3-7vB6mK",
      title: "Capstone: Full Cabin Air Rage De-Escalation & Physical Restraint Simulation",
      youtube_video_id: "GleOID3qb9o",
      youtube_url: "https://www.youtube.com/watch?v=GleOID3qb9o",
      fallback_video_id: "WhtLy_yG-J0",
      search_query: "Air rage passenger simulation restraint flexicuffs de escalation capstone",
      channel_name: "Commercial Flight Crew Security Sim",
      duration: "1:37:00",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Live simulation de-escalating an intoxicated aggressive passenger threatening fellow travelers",
        "De-escalating escalation points and transitioning to ABP recruitment when physical safety is breached",
        "Executing safe takedown and wrist restraint following standardized defensive tactics",
        "Post-restraint passenger monitoring: continuous breathing check and legal handover to airport police"
      ]
    }],
    4: [{
      id: "cc-conflict-p4-5mP1vN",
      title: "Cabin Crew Behavioral Interview & Conflict Handling Roleplay Preparation",
      youtube_video_id: "CgZRtOLwcS8",
      youtube_url: "https://www.youtube.com/watch?v=CgZRtOLwcS8",
      fallback_video_id: "JvbVyBIMhL0",
      search_query: "Cabin crew behavioral interview questions conflict roleplay airline assessment",
      channel_name: "Cabin Crew Assessment Day Masterclass",
      duration: "58:50",
      difficulty: "Placement",
      topic_focus: "Cabin Crew Behavioral Interview & Conflict Handling Roleplay Preparation",
      key_takeaways: [
        "Tackling high-frequency behavioral questions: Tell me about a time you handled an angry customer",
        "Acing the surprise roleplay station: keeping calm when the interviewer shouts or acts difficult",
        "Demonstrating composure, empathy, emotional intelligence, and unwavering safety focus",
        "Drafting incident reports (Cabin Safety Reports) with objective, admissible facts"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // cc-fire
  // --------------------------------------------------------------------------
  'cc-fire': {
    0: [{
      id: "cc-fire-p0-3vM9mQ",
      title: "Aviation Fire Chemistry, Classes of Fire & Aircraft Fire Hazards",
      youtube_video_id: "CcxsITiS5HQ",
      youtube_url: "https://www.youtube.com/watch?v=CcxsITiS5HQ",
      fallback_video_id: "k6MXUDOcZNk",
      search_query: "Aircraft fire chemistry classes of fire A B C D lithium battery hazards",
      channel_name: "FAA Fire Safety & Flight Safety Academy",
      duration: "51:15",
      difficulty: "Beginner",
      topic_focus: "Aviation Fire Chemistry, Classes of Fire & Aircraft Fire Hazards",
      key_takeaways: [
        "The Fire Triangle and Tetrahedron: Fuel, Oxygen, Heat, and Chemical Chain Reaction",
        "Classes of fire: Class A (solids/fabric), Class B (flammable liquids), Class C (electrical), Class D (metals)",
        "Unique aircraft cabin fire dangers: toxic gases (cyanide, CO), flashover in confined fuselage",
        "Common ignition sources: overheated galley equipment, passenger electronics, lavatory smoking"
      ]
    }],
    1: [{
      id: "cc-fire-p1-8mK5vP",
      title: "Cabin Firefighting Equipment: Halon, BCF, Water Extinguishers & PBE",
      youtube_video_id: "jXL5Q4OwLYc",
      youtube_url: "https://www.youtube.com/watch?v=jXL5Q4OwLYc",
      fallback_video_id: "ozeupFihLqs",
      search_query: "Halon 1211 extinguisher Protective Breathing Equipment PBE crash axe cabin crew",
      channel_name: "Aviation Emergency Equipment Training",
      duration: "1:17:30",
      difficulty: "Intermediate",
      topic_focus: "Cabin Firefighting Equipment",
      key_takeaways: [
        "Halon 1211 / BCF fire extinguisher: pre-flight check, pin removal, sweep technique at base of fire",
        "Water fire extinguisher: when to use (Class A) and strict prohibition on electrical/grease fires",
        "Protective Breathing Equipment (PBE) smoke hood: donning procedure within 15 seconds, 15-minute oxygen supply",
        "Crash axe and thermal gloves: locating hidden hot spots behind cabin sidewall panels"
      ]
    }],
    2: [{
      id: "cc-fire-p2-1qN7vM",
      title: "Firefighting Roles: Firefighter, Communicator & Backup Support Teamwork",
      youtube_video_id: "s8UqnF_k-wY",
      youtube_url: "https://www.youtube.com/watch?v=s8UqnF_k-wY",
      fallback_video_id: "yHUYmmIQ98g",
      search_query: "Cabin crew firefighting roles firefighter communicator backup assistant",
      channel_name: "Airline Firefighting Protocols",
      duration: "1:20:45",
      difficulty: "Advanced",
      topic_focus: "Firefighting Roles",
      key_takeaways: [
        "The 3-crew firefighting team: Firefighter (attacks fire), Communicator (informs flight deck), Backup (brings equipment)",
        "Continuous interphone communication with pilots: location, source, color/smell of smoke, severity, action taken",
        "Lavatory fire drill: feeling door with back of hand, cracking door open, discharging Halon nozzle",
        "Overhead bin fire attack: releasing latch slightly, discharging Halon, shutting bin to smother fumes"
      ]
    }],
    3: [{
      id: "cc-fire-p3-6vB3mK",
      title: "Capstone: Live Fire Simulator Attack & Thick Smoke Cabin Evacuation Drill",
      youtube_video_id: "CkP2Ns9rpAI",
      youtube_url: "https://www.youtube.com/watch?v=CkP2Ns9rpAI",
      fallback_video_id: "3iYXcO-16KI",
      search_query: "Live fire fighting simulator cabin crew smoke drill PBE deployment capstone",
      channel_name: "Lufthansa Aviation Training Center",
      duration: "1:35:15",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Live firefighting exercise: extinguishing real galley flame using Halon extinguisher in mock-up",
        "Donning PBE in pitch-black simulated cabin smoke and navigating by touch along aisle seats",
        "Calming panicked passengers, distributing wet tissues, and instructing them to breathe low near the floor",
        "Executing immediate ground evacuation drill if fire cannot be contained in flight"
      ]
    }],
    4: [{
      id: "cc-fire-p4-9mP2vN",
      title: "Cabin Crew Fire Drill Recurrent Exam & Technical Viva Preparation",
      youtube_video_id: "5utfcLZQHCI",
      youtube_url: "https://www.youtube.com/watch?v=5utfcLZQHCI",
      fallback_video_id: "axXMSeb_8BI",
      search_query: "Cabin crew fire drill exam questions viva firefighting recurrent test airline",
      channel_name: "Aviation Fire Academy & Crew Recurrent",
      duration: "57:10",
      difficulty: "Placement",
      topic_focus: "Cabin Crew Fire Drill Recurrent Exam & Technical Viva Preparation",
      key_takeaways: [
        "Answering high-pressure viva questions on PBE activation oxygen candles and disposal after use",
        "Explaining the exact protocol for passenger smart-phone caught and smoking in seat mechanism",
        "Resolving tactical scenarios: dealing with lithium-ion thermal runaway using water quenching",
        "Passing annual airline cabin safety recurrent firefighting practical checks with distinction"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // hum-policy
  // --------------------------------------------------------------------------
  'hum-policy': {
    0: [{
      id: "hum-policy-p0-4vM2mQ",
      title: "Public Policy Formulation Foundations: Agenda Setting & Policy Cycle",
      youtube_video_id: "4_rmVbVKaI8",
      youtube_url: "https://www.youtube.com/watch?v=4_rmVbVKaI8",
      fallback_video_id: "iNJgVzQ0WqY",
      search_query: "Public policy formulation policy cycle agenda setting Kingdon model LSE",
      channel_name: "LSE & Harvard Kennedy School",
      duration: "56:20",
      difficulty: "Beginner",
      topic_focus: "Public Policy Formulation Foundations",
      key_takeaways: [
        "The Stages of the Policy Cycle: problem identification, agenda setting, formulation, implementation, evaluation",
        "Kingdons Multiple Streams Framework: problem stream, policy stream, politics stream, and policy windows",
        "Stakeholder mapping: interest vs influence matrix in participatory democratic policymaking",
        "Market failures vs government failures: externalities, public goods, information asymmetry"
      ]
    }],
    1: [{
      id: "hum-policy-p1-9mK6vP",
      title: "Regulatory Impact Assessment (RIA) & Cost-Benefit Analysis (CBA)",
      youtube_video_id: "yG8vCmU--Qs",
      youtube_url: "https://www.youtube.com/watch?v=yG8vCmU--Qs",
      fallback_video_id: "NgNzd5CdMpc",
      search_query: "Regulatory impact assessment RIA cost benefit analysis public policy Oxford",
      channel_name: "Oxford Department of International Development",
      duration: "1:19:40",
      difficulty: "Intermediate",
      topic_focus: "Regulatory Impact Assessment (RIA) & Cost-Benefit Analysis (CBA)",
      key_takeaways: [
        "Regulatory Impact Assessment (RIA) methodologies: identifying unintended consequences",
        "Cost-Benefit Analysis (CBA): discounting, net present value (NPV), and social discount rates",
        "Cost-Effectiveness Analysis (CEA) for non-monetizable social welfare outcomes",
        "Consultation papers and stakeholder comment synthesis under pre-legislative consultative policy"
      ]
    }],
    2: [{
      id: "hum-policy-p2-2qN9vM",
      title: "Drafting Policy Briefs, Whitepapers & Legislative Proposals",
      youtube_video_id: "qx76cTKYNOg",
      youtube_url: "https://www.youtube.com/watch?v=qx76cTKYNOg",
      fallback_video_id: "aCWeObZwJEE",
      search_query: "Policy brief drafting whitepaper authoring think tank policy memo",
      channel_name: "Think Tank Masterclass & Brookings",
      duration: "1:23:15",
      difficulty: "Advanced",
      topic_focus: "Drafting Policy Briefs, Whitepapers & Legislative Proposals",
      key_takeaways: [
        "Policy brief architecture: executive summary, context, policy options, actionable recommendations",
        "Authoring government Whitepapers: framing systemic reforms and visionary targets",
        "Drafting model legislative clauses and administrative rules for ministry implementation",
        "Translating complex econometric and qualitative evidence into C-suite and ministerial summaries"
      ]
    }],
    3: [{
      id: "hum-policy-p3-7vB1mK",
      title: "Capstone: Comprehensive National Renewable Energy Transition Policy Whitepaper",
      youtube_video_id: "jlRNNJFrcVY",
      youtube_url: "https://www.youtube.com/watch?v=jlRNNJFrcVY",
      fallback_video_id: "Ftu2DEcnKWU",
      search_query: "Public policy capstone whitepaper renewable energy transition regulatory brief",
      channel_name: "Global Policy Institute Capstone",
      duration: "1:38:30",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Authoring 25-page comprehensive national transition whitepaper for clean energy subsidy reforms",
        "Modeling fiscal implications, tariff impacts on vulnerable socio-economic groups, and grid stability",
        "Designing monitoring and evaluation (M&E) key performance indicators and sunset clauses",
        "Presenting policy pitch to simulated parliamentary standing committee panel"
      ]
    }],
    4: [{
      id: "hum-policy-p4-3mP7vN",
      title: "Public Policy Analyst Placement & Think Tank Research Fellow Viva Prep",
      youtube_video_id: "RAU7kmO5Tss",
      youtube_url: "https://www.youtube.com/watch?v=RAU7kmO5Tss",
      fallback_video_id: "zOBjOkb9ju0",
      search_query: "Public policy interview questions think tank analyst policy memo test viva",
      channel_name: "Think Tank Careers & Policy Fellowships",
      duration: "1:02:10",
      difficulty: "Placement",
      topic_focus: "Public Policy Analyst Placement & Think Tank Research Fellow Viva Prep",
      key_takeaways: [
        "Solving real-time 90-minute policy memo drafting assessment tests for top consultancies",
        "Articulating answers on nudges, behavioral economics in policy (Sunstein & Thaler frameworks)",
        "Answering tough questions on federalism, inter-state funding disputes, and public health equity",
        "Cracking recruitment interviews for NITI Aayog, Brookings, CPR, and multilateral agencies"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // hum-research
  // --------------------------------------------------------------------------
  'hum-research': {
    0: [{
      id: "hum-research-p0-5vM8mQ",
      title: "Social Science Research Methodologies: Qualitative vs Quantitative Paradigms",
      youtube_video_id: "iINbYSyp0Hw",
      youtube_url: "https://www.youtube.com/watch?v=iINbYSyp0Hw",
      fallback_video_id: "a-XtVF7Bofg",
      search_query: "Social science research methodology qualitative quantitative epistemology ontology",
      channel_name: "Stanford University & Sage Research Methods",
      duration: "54:10",
      difficulty: "Beginner",
      topic_focus: "Social Science Research Methodologies",
      key_takeaways: [
        "Epistemological foundations: positivism, interpretivism, and critical realism in social inquiries",
        "Qualitative vs quantitative paradigms: choosing appropriate methodology for research questions",
        "Research ethics: informed consent, institutional review boards (IRB), and vulnerable populations",
        "Formulating testable hypotheses and operationalizing theoretical constructs"
      ]
    }],
    1: [{
      id: "hum-research-p1-1mK4vP",
      title: "Survey Methodology, Sampling Design & Questionnaire Architecture",
      youtube_video_id: "VbdIA8WO2a4",
      youtube_url: "https://www.youtube.com/watch?v=VbdIA8WO2a4",
      fallback_video_id: "sKtoW5cXt14",
      search_query: "Survey design sampling methodology probability stratified questionnaire Pew",
      channel_name: "Pew Research Center Methods",
      duration: "1:18:50",
      difficulty: "Intermediate",
      topic_focus: "Survey Methodology, Sampling Design & Questionnaire Architecture",
      key_takeaways: [
        "Probability sampling: simple random, stratified, cluster, and multi-stage sampling techniques",
        "Non-probability sampling: purposive, quota, snowball sampling, and managing selection bias",
        "Questionnaire design: Likert scales, semantic differentials, avoiding leading/double-barreled questions",
        "Pilot testing, cognitive interviewing, and response rate optimization strategies"
      ]
    }],
    2: [{
      id: "hum-research-p2-8qN2vM",
      title: "Qualitative Fieldwork: In-Depth Interviews, Focus Groups & Thematic Coding",
      youtube_video_id: "eCW-lg_XnJs",
      youtube_url: "https://www.youtube.com/watch?v=eCW-lg_XnJs",
      fallback_video_id: "LMaz9GsTL_Q",
      search_query: "Qualitative research in depth interviews focus groups thematic analysis NVivo",
      channel_name: "Qualitative Research Institute",
      duration: "1:21:40",
      difficulty: "Advanced",
      topic_focus: "Qualitative Fieldwork",
      key_takeaways: [
        "Semi-structured in-depth interview techniques: probing, active neutrality, and rapport building",
        "Focus Group Discussions (FGD): moderation dynamics, group consensus, and conflict tracking",
        "Thematic analysis frameworks (Braun & Clarke): generating initial codes, reviewing themes",
        "Using qualitative data analysis software (NVivo / ATLAS.ti) for transcription tagging"
      ]
    }],
    3: [{
      id: "hum-research-p3-4vB9mK",
      title: "Capstone: End-to-End Mixed-Methods Socio-Economic Impact Evaluation Study",
      youtube_video_id: "WviglPQAdtw",
      youtube_url: "https://www.youtube.com/watch?v=WviglPQAdtw",
      fallback_video_id: "Q6q1RL22o74",
      search_query: "Mixed methods research design socio economic impact evaluation capstone",
      channel_name: "Social Research Methods Capstone Guild",
      duration: "1:36:20",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Designing convergent parallel mixed-methods study integrating survey data with qualitative interviews",
        "Running descriptive and inferential regression analysis in R / SPSS to establish correlations",
        "Triangulating quantitative survey findings with qualitative participant narratives",
        "Publishing academic research paper adhering to peer-reviewed publication standards"
      ]
    }],
    4: [{
      id: "hum-research-p4-7mP3vN",
      title: "Social Research Fellow Placement & PhD / Think Tank Viva Preparation",
      youtube_video_id: "2JHBpj1H9LA",
      youtube_url: "https://www.youtube.com/watch?v=2JHBpj1H9LA",
      fallback_video_id: "YUsqlVqTx8Y",
      search_query: "Research assistant interview questions social science viva defense PhD interview",
      channel_name: "Academic Research & PhD Viva Prep",
      duration: "59:45",
      difficulty: "Placement",
      topic_focus: "Social Research Fellow Placement & PhD / Think Tank Viva Preparation",
      key_takeaways: [
        "Defending research proposal methodology and sample size justification before faculty panels",
        "Addressing internal validity, external validity, and confounders in observational studies",
        "Demonstrating proficiency in data cleaning, coding books, and reproducible research workflows",
        "Recruitment interviews for research analyst positions at top universities and global NGOs"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // hum-macro
  // --------------------------------------------------------------------------
  'hum-macro': {
    0: [{
      id: "hum-macro-p0-2vM6mQ",
      title: "Macroeconomic Foundations: National Income, GDP & Aggregate Demand",
      youtube_video_id: "NqEbXhiatCQ",
      youtube_url: "https://www.youtube.com/watch?v=NqEbXhiatCQ",
      fallback_video_id: "45ijJXd2YYE",
      search_query: "Macroeconomics basics GDP calculation aggregate demand aggregate supply IS-LM",
      channel_name: "Khan Academy & MIT OpenCourseWare",
      duration: "55:50",
      difficulty: "Beginner",
      topic_focus: "Macroeconomic Foundations",
      key_takeaways: [
        "National income accounting: Gross Domestic Product (GDP) via expenditure, income, value-added methods",
        "Nominal GDP vs Real GDP, GDP deflator, and Purchasing Power Parity (PPP)",
        "Aggregate Demand (AD) and Aggregate Supply (AS) macroeconomic equilibrium",
        "The Keynesian multiplier, marginal propensity to consume (MPC), and paradoxical savings"
      ]
    }],
    1: [{
      id: "hum-macro-p1-6mK1vP",
      title: "Monetary Policy, Central Banking & Interest Rate Transmission",
      youtube_video_id: "AXFbcwnFATk",
      youtube_url: "https://www.youtube.com/watch?v=AXFbcwnFATk",
      fallback_video_id: "iD9WlvTrxOg",
      search_query: "Monetary policy central banking repo rate open market operations inflation targeting",
      channel_name: "Federal Reserve & Reserve Bank Economics",
      duration: "1:20:10",
      difficulty: "Intermediate",
      topic_focus: "Monetary Policy, Central Banking & Interest Rate Transmission",
      key_takeaways: [
        "Central bank monetary toolkits: Repo rate, Reverse Repo, Cash Reserve Ratio (CRR), Open Market Ops (OMO)",
        "Money supply definitions (M1, M2, M3) and the money multiplier mechanism",
        "Inflation targeting frameworks: headline CPI vs Core CPI and Taylor Rule dynamics",
        "Monetary transmission mechanism: how interest rate adjustments impact investment and consumer loans"
      ]
    }],
    2: [{
      id: "hum-macro-p2-9qN7vM",
      title: "Fiscal Policy, Government Debt & Balance of Payments (BoP) Dynamics",
      youtube_video_id: "9jHiJwwVpuk",
      youtube_url: "https://www.youtube.com/watch?v=9jHiJwwVpuk",
      fallback_video_id: "W0YwGLz50TA",
      search_query: "Fiscal policy government deficit debt sustainability balance of payments current account",
      channel_name: "LSE Economics Department",
      duration: "1:25:30",
      difficulty: "Advanced",
      topic_focus: "Fiscal Policy, Government Debt & Balance of Payments (BoP) Dynamics",
      key_takeaways: [
        "Fiscal deficit, revenue deficit, and primary deficit under FRBM Act disciplines",
        "Sovereign debt sustainability: Domar debt dynamics and debt-to-GDP ratios",
        "Balance of Payments (BoP) structure: Current Account (trade in goods/services) vs Capital Account (FDI/FPI)",
        "Foreign exchange reserve management, currency depreciation/appreciation, and import cover"
      ]
    }],
    3: [{
      id: "hum-macro-p3-3vB4mK",
      title: "Capstone: Macroeconomic Forecasting & Union Budget Impact Analysis Model",
      youtube_video_id: "GjxhDo9luh8",
      youtube_url: "https://www.youtube.com/watch?v=GjxhDo9luh8",
      fallback_video_id: "dwVx6mVDrZU",
      search_query: "Macroeconomic forecasting model union budget analysis capstone econometrics",
      channel_name: "Economic Advisory Council Masterclass",
      duration: "1:39:15",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Building dynamic spreadsheet econometric model forecasting GDP growth, inflation, and tax revenues",
        "Analyzing Union Budget fiscal allocations: capital expenditure (Capex) multiplier effects on growth",
        "Simulating external shocks: crude oil price spikes, global interest rate hikes, and currency shocks",
        "Authoring macroeconomic outlook report for chief economist and institutional investors"
      ]
    }],
    4: [{
      id: "hum-macro-p4-8mP5vN",
      title: "Economic Analyst Placement & Investment Bank Economics Research Viva Prep",
      youtube_video_id: "N_jCozse73g",
      youtube_url: "https://www.youtube.com/watch?v=N_jCozse73g",
      fallback_video_id: "An_rEcWdhAg",
      search_query: "Macroeconomist interview questions economic research analyst viva investment bank",
      channel_name: "Wall Street Economics & Macro Research",
      duration: "1:03:50",
      difficulty: "Placement",
      topic_focus: "Economic Analyst Placement & Investment Bank Economics Research Viva Prep",
      key_takeaways: [
        "Technical questions on Phillips curve trade-offs, stagflation, and yield curve inversions",
        "Solving real-time 45-minute macroeconomic data release interpretation tests (CPI / Non-farm payrolls)",
        "Synthesizing emerging market central bank policies and monetary policy committee (MPC) stances",
        "Cracking global bank and rating agency (Moody’s, S&P, Fitch) economic research interviews"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // hum-communications
  // --------------------------------------------------------------------------
  'hum-communications': {
    0: [{
      id: "hum-communications-p0-7vM3mQ",
      title: "Strategic Communications & Media Advocacy Foundations",
      youtube_video_id: "pEesyqlOv8M",
      youtube_url: "https://www.youtube.com/watch?v=pEesyqlOv8M",
      fallback_video_id: "oWnVmow9frg",
      search_query: "Strategic communications foundations narrative framing media advocacy public relations",
      channel_name: "Georgetown University & PRCA",
      duration: "51:40",
      difficulty: "Beginner",
      topic_focus: "Strategic Communications & Media Advocacy Foundations",
      key_takeaways: [
        "The Strategic Communication Model: objectives, target audiences, messages, channels, metrics",
        "Narrative framing: agenda setting, priming, and cognitive framing theory in public discourse",
        "Audience segmentation: demographics, psychographics, and identifying influential amplifiers",
        "Ethics of public advocacy: transparency, avoiding disinformation, and regulatory advertising standards"
      ]
    }],
    1: [{
      id: "hum-communications-p1-2mK9vP",
      title: "Corporate Press Releases, Media Pitching & Press Conference Management",
      youtube_video_id: "FWVnXQCF_f4",
      youtube_url: "https://www.youtube.com/watch?v=FWVnXQCF_f4",
      fallback_video_id: "OYcWVdiwhZU",
      search_query: "Press release writing media pitching press conference journalism relations",
      channel_name: "Media Relations Institute",
      duration: "1:17:25",
      difficulty: "Intermediate",
      topic_focus: "Corporate Press Releases, Media Pitching & Press Conference Management",
      key_takeaways: [
        "Inverted pyramid news writing: strong headline, dateline, lead paragraph, quotes, boilerplate",
        "Crafting customized media pitches to financial, tech, and mainstream journalists",
        "Organizing press conferences: media invitations, press kits, speaker briefings, Q&A protocols",
        "Building media relationship lists and tracking earned media coverage metrics (AVE, reach)"
      ]
    }],
    2: [{
      id: "hum-communications-p2-5qN1vM",
      title: "Crisis Communications & Real-Time Reputation Damage Control",
      youtube_video_id: "x47EcD3d0pA",
      youtube_url: "https://www.youtube.com/watch?v=x47EcD3d0pA",
      fallback_video_id: "30SXTxGs-WM",
      search_query: "Crisis communications plan reputation management holding statement social media crisis",
      channel_name: "Crisis PR Academy & Harvard Business Review",
      duration: "1:22:40",
      difficulty: "Advanced",
      topic_focus: "Crisis Communications & Real-Time Reputation Damage Control",
      key_takeaways: [
        "The Golden Hour of crisis response: speed, accountability, transparency, and empathy",
        "Drafting immediate holding statements and multi-channel crisis communication plans",
        "Managing social media firestorms: mitigating virality, addressing misinformation without amplifying",
        "Spokesperson media training: bridging, hooking, and flagging techniques during hostile live interviews"
      ]
    }],
    3: [{
      id: "hum-communications-p3-1vB8mK",
      title: "Capstone: End-to-End Corporate PR Campaign Launch & Crisis Response Simulation",
      youtube_video_id: "cMLQUCihXQk",
      youtube_url: "https://www.youtube.com/watch?v=cMLQUCihXQk",
      fallback_video_id: "4qFcLXjloY0",
      search_query: "PR campaign launch plan crisis communications simulation capstone project",
      channel_name: "Global Communications Agency Capstone",
      duration: "1:34:30",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Authoring 360-degree brand launch campaign integrating press releases, thought leadership, digital PR",
        "Simulating sudden product recall crisis: drafting crisis responses, internal employee emails, CEO remarks",
        "Measuring multi-channel campaign impact: sentiment analysis, media impressions, brand equity lift",
        "Presenting crisis debrief to corporate board of directors and risk management committee"
      ]
    }],
    4: [{
      id: "hum-communications-p4-6mP4vN",
      title: "Corporate Communications Placement & Agency PR Account Lead Interview Prep",
      youtube_video_id: "lOHx2FmUgFg",
      youtube_url: "https://www.youtube.com/watch?v=lOHx2FmUgFg",
      fallback_video_id: "bf8Q_hP4Xzc",
      search_query: "Corporate communications interview questions PR agency account lead interview viva",
      channel_name: "PR Week Careers & Communications Guild",
      duration: "58:20",
      difficulty: "Placement",
      topic_focus: "Corporate Communications Placement & Agency PR Account Lead Interview Prep",
      key_takeaways: [
        "Acing real-time 60-minute crisis statement drafting assessment tests for top global PR agencies",
        "Explaining ESG communication strategies and avoiding greenwashing allegations",
        "Demonstrating executive presence, persuasive speech delivery, and media interview coaching abilities",
        "Interviews for Corporate Communications Officer and PR agency Account Director positions"
      ]
    }],
  },

  // --------------------------------------------------------------------------
  // hum-csr
  // --------------------------------------------------------------------------
  'hum-csr': {
    0: [{
      id: "hum-csr-p0-3vM1mQ",
      title: "Corporate Social Responsibility (CSR) & ESG Governance Foundations",
      youtube_video_id: "AzHaDKZ-iiI",
      youtube_url: "https://www.youtube.com/watch?v=AzHaDKZ-iiI",
      fallback_video_id: "phkb1LTM5jY",
      search_query: "Corporate social responsibility CSR ESG environmental social governance Section 135",
      channel_name: "Harvard Business School & UN Global Compact",
      duration: "53:10",
      difficulty: "Beginner",
      topic_focus: "Corporate Social Responsibility (CSR) & ESG Governance Foundations",
      key_takeaways: [
        "Evolution from philanthropy to strategic CSR: Carolls CSR pyramid and stakeholder theory",
        "Section 135 of Indian Companies Act 2013: 2% CSR spending mandate and Schedule VII activities",
        "The ESG triad: Environmental stewardship, Social responsibility, and Corporate Governance",
        "UN Sustainable Development Goals (SDGs) alignment with corporate core competencies"
      ]
    }],
    1: [{
      id: "hum-csr-p1-8mK6vP",
      title: "BRSR Reporting (SEBI Mandate) & GRI Sustainability Standards",
      youtube_video_id: "-ii98IlGS_Q",
      youtube_url: "https://www.youtube.com/watch?v=-ii98IlGS_Q",
      fallback_video_id: "A1gWztOMJrg",
      search_query: "BRSR Business Responsibility and Sustainability Report SEBI GRI standards",
      channel_name: "Sustainability Reporting Institute",
      duration: "1:21:50",
      difficulty: "Intermediate",
      topic_focus: "BRSR Reporting (SEBI Mandate) & GRI Sustainability Standards",
      key_takeaways: [
        "SEBI Business Responsibility and Sustainability Report (BRSR) 9 principles and core KPIs",
        "Global Reporting Initiative (GRI) Standards: materiality assessments and stakeholder inclusivity",
        "Scope 1, Scope 2, and Scope 3 greenhouse gas (GHG) emissions accounting under GHG Protocol",
        "Human rights, labor practices, fair wages, and supply chain ethical auditing metrics"
      ]
    }],
    2: [{
      id: "hum-csr-p2-4qN8vM",
      title: "Social Impact Assessment (SIA) & SROI (Social Return on Investment) Modeling",
      youtube_video_id: "9-OX0-bHE28",
      youtube_url: "https://www.youtube.com/watch?v=9-OX0-bHE28",
      fallback_video_id: "BbSspl6zx0k",
      search_query: "Social impact assessment SIA Social Return on Investment SROI calculation",
      channel_name: "Social Impact Measurement Guild",
      duration: "1:24:10",
      difficulty: "Advanced",
      topic_focus: "Social Impact Assessment (SIA) & SROI (Social Return on Investment) Modeling",
      key_takeaways: [
        "Designing Social Impact Assessments (SIA): baseline surveys, theory of change, logic models",
        "Calculating Social Return on Investment (SROI): monetizing qualitative social outcomes",
        "Deadweight, attribution, drop-off, and displacement deductions in impact valuation",
        "Third-party independent monitoring and evaluation (M&E) audit verification protocols"
      ]
    }],
    3: [{
      id: "hum-csr-p3-9vB3mK",
      title: "Capstone: End-to-End Enterprise BRSR Sustainability Report & CSR Project Portfolio",
      youtube_video_id: "U8e-f-Yqm7k",
      youtube_url: "https://www.youtube.com/watch?v=U8e-f-Yqm7k",
      fallback_video_id: "iQXNAG5p5gA",
      search_query: "Drafting BRSR report CSR project portfolio ESG strategy capstone",
      channel_name: "Corporate Sustainability Officer Clinic",
      duration: "1:37:45",
      difficulty: "Advanced",
      topic_focus: "Capstone",
      key_takeaways: [
        "Authoring 40-page corporate BRSR report for top 1000 listed entity adhering to SEBI norms",
        "Formulating INR 50 Crore CSR allocation portfolio across rural healthcare, water, and skilling",
        "Drafting NGO partner due diligence checklist and monitoring fund utilization certificates",
        "Presenting ESG risk audit and carbon offset transition plan to board CSR committee"
      ]
    }],
    4: [{
      id: "hum-csr-p4-2mP5vN",
      title: "ESG & CSR Analyst Placement & Corporate Sustainability Viva Preparation",
      youtube_video_id: "dkzkfoOC9cE",
      youtube_url: "https://www.youtube.com/watch?v=dkzkfoOC9cE",
      fallback_video_id: "9S1mTMMMiB8",
      search_query: "ESG analyst interview questions CSR manager viva sustainable finance interview",
      channel_name: "Sustainability Careers & ESG Guild",
      duration: "1:01:30",
      difficulty: "Placement",
      topic_focus: "ESG & CSR Analyst Placement & Corporate Sustainability Viva Preparation",
      key_takeaways: [
        "Cracking technical questions on EU CBAM (Carbon Border Adjustment Mechanism) and ISSB standards",
        "Analyzing greenwashing risks in corporate marketing and ESG debt issuance (green bonds)",
        "Answering questions on board diversity, whistle-blower policies, and supply chain ethics",
        "Placement interviews for Big 4 ESG advisory, corporate sustainability desks, and impact funds"
      ]
    }],
  },

};
