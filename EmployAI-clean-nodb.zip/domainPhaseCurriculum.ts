export interface CoDomainPhaseTemplate {
  phaseTitle: string;
  focusSkill: string;
  goal: string;
  howToAchieve: string;
  topics: string[];
  practicalProject: string;
  deliverable: string;
  recommendedTools: string[];
  interviewQuestions: { question: string; answer_guide: string }[];
  tasks: { title: string; description: string; estimated_hours: number }[];
}

export interface CoDomainProgressItem {
  id: string;
  name: string;
  category: string;
  completedPhasesCount: number;
  totalPhasesCount: number;
  completionPct: number;
  isCompleted: boolean;
}

export interface StreamProgressStats {
  streamName: string;
  totalCoDomainsCount: number;
  completedCoDomainsCount: number;
  totalPhasesCount: number;
  completedPhasesCount: number;
  streamCompletionPct: number;
  coDomainMap: Record<string, CoDomainProgressItem>;
}

// ============================================================================
// Curated Authentic 5-Phase Tracks for Key Disciplines & Co-Domains
// ============================================================================
export const CO_DOMAIN_PHASE_TEMPLATES: Record<string, CoDomainPhaseTemplate[]> = {
  // --------------------------------------------------------------------------
  // 1. DATA STRUCTURES & ALGORITHMS (DSA)
  // --------------------------------------------------------------------------
  'cs-dsa': [
    {
      phaseTitle: 'Phase 1: Complexity Analysis (Big-O), Arrays, Strings & Two Pointers',
      focusSkill: 'Algorithmic Big-O Analysis & Linear Sequence Traversals',
      goal: 'Master asymptotic time/space bounds, in-place memory mutations, prefix sums, and two-pointer / sliding window techniques.',
      howToAchieve: 'Step 1: Analyze Big-O time and auxiliary space on worst/average/amortized bounds.\nStep 2: Solve 20+ problems on two-pointer convergence, sliding windows, and kadane algorithm.\nStep 3: Implement dynamic array doubling and string frequency counters from scratch.\nStep 4: Verify test suites against extreme edge cases (empty inputs, integer overflow).',
      topics: [
        'Time & Space Complexity: Big-O, Big-Omega, Big-Theta and amortized analysis',
        'In-place array manipulations, prefix sums, difference arrays and two-pointer patterns',
        'Sliding window optimization for contiguous substring/subarray problems',
        'Bit manipulation primitives, XOR operations, and fast power exponentiation'
      ],
      practicalProject: 'High-Performance String & Array Search Engine: Build a zero-dependency algorithmic utility benchmarking two-pointer search versus naive linear scans.',
      deliverable: 'Tested algorithmic library with benchmark graphs proving O(n) runtime over O(n^2).',
      recommendedTools: ['VS Code / CLion', 'LeetCode / NeetCode 150', 'VisuAlgo State Tracing', 'GTest / Pytest'],
      interviewQuestions: [
        {
          question: 'How does amortized time complexity differ from average time complexity in dynamic arrays (e.g. C++ vector / Python list)?',
          answer_guide: 'Explain array doubling: occasional O(n) reallocation spread over n insertions yields O(1) amortized cost, whereas average includes all typical runs.'
        },
        {
          question: 'When is a sliding window technique strictly preferable to a two-pointer inward convergence approach?',
          answer_guide: 'Sliding window maintains a contiguous subsegment window, ideal for subarray sums/longest substrings; two-pointer inward handles sorted pairs or palindrome checks.'
        }
      ],
      tasks: [
        { title: 'Solve 25 fundamental two-pointer and sliding window challenges', description: 'Complete curated NeetCode two-pointer and sliding window problem sets with optimal O(n) complexity.', estimated_hours: 10 },
        { title: 'Benchmark prefix sum vs brute-force range queries', description: 'Implement static 2D range sum queries with verified O(1) retrieval and zero memory leaks.', estimated_hours: 6 }
      ]
    },
    {
      phaseTitle: 'Phase 2: Linear Data Structures: Linked Lists, Stacks, Queues & Trees',
      focusSkill: 'Pointer Manipulation, Monotonic Stacks & Binary Tree Traversals',
      goal: 'Implement pointer-based structures, monotonic stack patterns, recursion trees, and binary search tree (BST) operations.',
      howToAchieve: 'Step 1: Implement singly and doubly linked lists with fast/slow cycle detection (Floyd algorithm).\nStep 2: Master monotonic stacks for Next Greater Element and histogram area calculations.\nStep 3: Write recursive and iterative DFS (pre/in/post-order) and BFS level-order traversals.\nStep 4: Validate BST invariant properties, node deletions, and lowest common ancestor (LCA).',
      topics: [
        'Floyd cycle-finding algorithm, linked list reversal, and recursive merging',
        'Monotonic stacks and double-ended queues (Deque) for sliding window maximums',
        'Binary tree traversals: Recursive vs iterative stack-based DFS and queue-based BFS',
        'Binary Search Trees (BST): Insertion, deletion, validation, and successor searching'
      ],
      practicalProject: 'Custom Expression Evaluation Engine: Build an AST (Abstract Syntax Tree) parser using shunting-yard algorithm and tree traversal.',
      deliverable: 'Working arithmetic expression parser handling parentheses, precedence, and variables.',
      recommendedTools: ['LeetCode Tree Explorer', 'Graphviz AST Visualizer', 'GDB / LLDB Debugger'],
      interviewQuestions: [
        {
          question: 'How do you detect and find the exact entry point of a loop in a linked list in O(1) space?',
          answer_guide: 'Use Floyd Tortoise and Hare: when fast and slow meet, reset slow to head; advance both one step at a time until they collide at the loop entrance.'
        },
        {
          question: 'Explain how monotonic stack achieves O(n) overall time for Next Greater Element despite nested loops.',
          answer_guide: 'Each element is pushed and popped at most once across the entire sequence, guaranteeing amortized 2n operations total.'
        }
      ],
      tasks: [
        { title: 'Implement and verify iterative DFS and BFS binary tree traversals', description: 'Write zero-recursion iterative DFS using explicit stacks and level-order BFS using queues.', estimated_hours: 8 },
        { title: 'Solve Monotonic Stack pattern drills on LeetCode', description: 'Complete Largest Rectangle in Histogram and Daily Temperatures with full test coverage.', estimated_hours: 7 }
      ]
    },
    {
      phaseTitle: 'Phase 3: Non-Linear & Dynamic Algorithms: Graphs, Dynamic Programming & Heaps',
      focusSkill: 'Graph Traversals (BFS/DFS), Dijkstra, Memoization & Tabulation DP',
      goal: 'Solve complex shortest path and network flow graphs, and formulate multi-dimensional dynamic programming state transitions.',
      howToAchieve: 'Step 1: Represent graphs with adjacency lists, implement topological sort (Kahn algorithm) and cycle detection.\nStep 2: Solve single-source shortest path using Dijkstra with priority queue (Min-Heap).\nStep 3: Master 1D and 2D dynamic programming: 0/1 Knapsack, Longest Common Subsequence (LCS), and Edit Distance.\nStep 4: Optimize DP space complexity from O(n*m) to O(m) via rolling arrays.',
      topics: [
        'Graph representations, topological sort, Disjoint Set Union (DSU / Kruskal)',
        'Dijkstra shortest path algorithm, Bellman-Ford, and A* search heuristics',
        '1D & 2D Dynamic Programming: State definitions, base cases, and optimal substructure',
        'Binary Heaps (Min/Max Heap), Priority Queues, and Trie prefix trees'
      ],
      practicalProject: 'Automated Route Optimization & Pathfinding Engine: Build a Dijkstra-driven shortest routing module on real-world city coordinate graphs.',
      deliverable: 'Visual route pathfinder with priority queue benchmarking against Floyd-Warshall.',
      recommendedTools: ['CSES Problem Set', 'Striver A2Z DSA Sheet', 'Graph Editor Sandbox'],
      interviewQuestions: [
        {
          question: 'Why does Dijkstra algorithm fail on graphs with negative edge weights, and which algorithm fixes this?',
          answer_guide: 'Dijkstra assumes once a node is visited its distance is final; negative edges invalidate this greedy assumption. Bellman-Ford or SPFA handles negative weights.'
        },
        {
          question: 'Walk through the state transition equation for the 0/1 Knapsack problem and explain how to optimize space to 1D array.',
          answer_guide: 'dp[i][w] = max(dp[i-1][w], val[i] + dp[i-1][w-weight[i]]). Iterate capacity backwards from W to weight[i] to safely compress into 1D.'
        }
      ],
      tasks: [
        { title: 'Implement Dijkstra and Disjoint Set Union from scratch', description: 'Code priority-queue Dijkstra and Union-Find with path compression and rank optimization.', estimated_hours: 10 },
        { title: 'Solve 15 essential Dynamic Programming placement problems', description: 'Cover Coin Change, Longest Increasing Subsequence, Word Break, and Edit Distance.', estimated_hours: 12 }
      ]
    },
    {
      phaseTitle: 'Phase 4: Algorithmic Systems & Computational Library Capstone',
      focusSkill: 'Production Algorithmic Architecture, Benchmark Rigor & Clean Code',
      goal: 'Architect a standalone, production-tested algorithmic library with automated benchmarks and comprehensive documentation.',
      howToAchieve: 'Step 1: Design clean API interfaces for complex data structures (Trie, Segment Tree, LRU Cache).\nStep 2: Write comprehensive unit tests and fuzzing suites validating edge cases.\nStep 3: Benchmark latency and memory consumption against standard library implementations.\nStep 4: Package with comprehensive markdown documentation, ASCII state diagrams, and CI pipeline.',
      topics: [
        'Advanced data structures: LRU Cache (HashMap + Doubly Linked List), Segment Trees, Fenwick Trees',
        'Memory alignment, cache locality, and branch prediction performance impacts',
        'Fuzz testing and property-based verification of algorithmic correctness',
        'Packaging reusable software libraries with automated CI testing workflows'
      ],
      practicalProject: 'Flagship LRU/LFU In-Memory Cache & Segment Tree Engine: Build an ultra-fast O(1) eviction cache library with 100% test coverage.',
      deliverable: 'Public GitHub repository with benchmark graphs, API docs, and automated CI test pass.',
      recommendedTools: ['Google Benchmark / Criterion', 'GitHub Actions', 'Valgrind / Memory Sanitizers'],
      interviewQuestions: [
        {
          question: 'How do you design an LRU Cache with strictly O(1) get and put operations?',
          answer_guide: 'Combine a Hash Map (key -> node pointer) with a Doubly Linked List (most recently used at head, least at tail); map lookup and list relinking are O(1).'
        }
      ],
      tasks: [
        { title: 'Implement and stress-test an O(1) LRU Cache with Doubly Linked List', description: 'Deliver thread-safe or high-speed LRU cache passing 100k random access test cases.', estimated_hours: 14 },
        { title: 'Publish algorithmic benchmark report on GitHub', description: 'Document latency percentiles (p50, p99) and memory profiles for custom data structures.', estimated_hours: 6 }
      ]
    },
    {
      phaseTitle: 'Phase 5: Technical Whiteboarding & Live Screening Interview Prep',
      focusSkill: 'FAANG / Tier-1 Technical Screening, Live Problem Solving & Articulation',
      goal: 'Pass high-pressure technical coding rounds, articulate algorithmic trade-offs, and master the Blind 75 / NeetCode 150 problem bank.',
      howToAchieve: 'Step 1: Practice live problem solving with think-aloud verbal articulation.\nStep 2: Master fast problem classification: sliding window vs two pointers vs binary search vs BFS.\nStep 3: Conduct mock peer technical interviews under strict 45-minute timed constraints.\nStep 4: Align resume with verified algorithmic project bullet points and ATS keywords.',
      topics: [
        '45-Minute Coding Interview Framework: Clarify, Propose, Analyze, Code, Dry-run, Optimize',
        'Pattern recognition across 14 essential algorithmic archetypes',
        'Handling interviewer hints and graceful error recovery during live screening',
        'Verbalizing Big-O trade-offs between memory overhead and runtime throughput'
      ],
      practicalProject: 'Placement Mock Screening Sprint: Complete 5 timed mock interviews scoring 85%+ on algorithmic correctness and communication.',
      deliverable: 'Verified Employ.AI Coding Portfolio with 150+ solved challenges and interview scorecard.',
      recommendedTools: ['Pramp / Interviewing.io', 'Employ.AI Resume ATS Optimizer', 'Blind 75 Checklist'],
      interviewQuestions: [
        {
          question: 'Given an array of integers, how do you find the median in a live continuous stream of data in O(log n)?',
          answer_guide: 'Maintain two heaps: a Max-Heap for the lower half and a Min-Heap for the upper half; balance sizes so difference <= 1; median is the top element or average of tops.'
        }
      ],
      tasks: [
        { title: 'Complete comprehensive Blind 75 timed revision drill', description: 'Re-solve 30 most frequent tier-1 tech company coding problems under 30 minutes each.', estimated_hours: 10 },
        { title: 'Conduct two live peer mock technical coding interviews', description: 'Simulate full whiteboard screening including requirements gathering and trade-off debate.', estimated_hours: 6 }
      ]
    }
  ],

  // --------------------------------------------------------------------------
  // 2. REACT & NEXT.JS UI ARCHITECTURE
  // --------------------------------------------------------------------------
  'cs-react': [
    {
      phaseTitle: 'Phase 1: React 18 Core: JSX, Components, Props & Essential Hooks',
      focusSkill: 'Declarative UI, Virtual DOM Reconciliation & Hook Lifecycles',
      goal: 'Master component composition, unidirectional data flow, virtual DOM diffing, and core hooks (useState, useEffect, useRef).',
      howToAchieve: 'Step 1: Master JSX compilation into React.createElement calls and Fiber node structures.\nStep 2: Understand unidirectional data flow, prop drilling, and controlled vs uncontrolled inputs.\nStep 3: Master useEffect dependencies, cleanup functions, and avoiding infinite re-render loops.\nStep 4: Use useRef for mutable values without re-renders and direct DOM references.',
      topics: [
        'Virtual DOM reconciliation, React Fiber architecture, and synthetic events',
        'useState state batching, functional state updates, and immutability rules',
        'useEffect lifecycle: Mounting, dependency arrays, unmount cleanups, and abort controllers',
        'Component composition patterns, children prop, and reusable layout wrappers'
      ],
      practicalProject: 'Interactive Multi-Filter Product Catalog: Build a lightning-fast responsive product showcase with instant client-side search, debounced input, and category filters.',
      deliverable: 'Component architecture with zero memory leaks and strict TypeScript interfaces.',
      recommendedTools: ['React DevTools', 'Vite + React 18', 'TypeScript', 'Tailwind CSS'],
      interviewQuestions: [
        {
          question: 'How does React 18 automatic batching work, and how does it differ from React 17?',
          answer_guide: 'In React 18, state updates inside promises, setTimeout, and native event handlers are automatically batched together into a single re-render, improving performance.'
        },
        {
          question: 'Why should you never mutate state directly in React (e.g. state.push(item))?',
          answer_guide: 'React relies on shallow reference equality (Object.is) to detect changes; mutating in-place retains the same reference, preventing Fiber diffing and skipping UI re-renders.'
        }
      ],
      tasks: [
        { title: 'Build and verify debounced search and filtering interface', description: 'Implement custom useDebounce hook with clean AbortController cleanup in useEffect.', estimated_hours: 8 },
        { title: 'Refactor complex form into controlled component architecture', description: 'Create multi-step form with real-time field validation, error states, and zero lag.', estimated_hours: 6 }
      ]
    },
    {
      phaseTitle: 'Phase 2: State Management: Custom Hooks, Context API & Redux Toolkit',
      focusSkill: 'Global State Architectures, Custom Hook Extraction & Performance',
      goal: 'Architect scalable global state, prevent unnecessary re-render cascades with useMemo/useCallback, and master Redux Toolkit / Zustand.',
      howToAchieve: 'Step 1: Extract reusable business logic into custom hooks (useFetch, useLocalStorage, useMediaQuery).\nStep 2: Implement Context API with state and dispatch separation to avoid provider re-render waterfalls.\nStep 3: Setup Redux Toolkit (RTK) with createSlice and createAsyncThunk or Zustand store.\nStep 4: Profile render counts using React DevTools Profiler and optimize using React.memo.',
      topics: [
        'Custom hook design: Clean API boundaries, hook composition, and testing with Vitest',
        'Context API optimization: Splitting state and actions to isolate consumer re-renders',
        'Redux Toolkit (RTK) vs Zustand: Slices, selectors, immutability with Immer, and middleware',
        'Performance optimization: React.memo, useMemo, useCallback, and virtualized list rendering'
      ],
      practicalProject: 'Enterprise State Dashboard: Build a real-time analytics dashboard with global filtering, undo/redo state history, and persistent local storage.',
      deliverable: 'Modular global state architecture with zero redundant render cascades measured in Profiler.',
      recommendedTools: ['Redux DevTools', 'Zustand', 'React DevTools Profiler', 'Vitest'],
      interviewQuestions: [
        {
          question: 'When should you choose Zustand or Redux Toolkit over React Context for global state?',
          answer_guide: 'Context is best for low-velocity data (auth, theme) because any state update re-renders all consumers. RTK/Zustand support selector-based subscriptions to prevent unnecessary renders in high-velocity apps.'
        },
        {
          question: 'What is the real performance cost of overusing useCallback and useMemo everywhere?',
          answer_guide: 'Each hook allocates memory for dependency arrays and performs equality comparisons on every render; for trivial calculations, the overhead exceeds any performance savings.'
        }
      ],
      tasks: [
        { title: 'Create a suite of 4 production-grade custom hooks', description: 'Author useLocalStorage, useDebounce, useClickOutside, and useAsync with full TypeScript generics.', estimated_hours: 8 },
        { title: 'Implement optimized global shopping cart with Zustand / RTK', description: 'Wire slice selectors, optimistic updates, and persist middleware with zero re-render leaks.', estimated_hours: 8 }
      ]
    },
    {
      phaseTitle: 'Phase 3: Next.js App Router: Server Components, SSR & Server Actions',
      focusSkill: 'Hybrid Rendering (RSC vs Client), Streaming SSR & Turbopack',
      goal: 'Master React Server Components (RSC), dynamic server routing, streaming UI with Suspense, and fullstack Server Actions.',
      howToAchieve: 'Step 1: Understand the mental model: Server Components (zero bundle footprint) vs Client Components ("use client").\nStep 2: Leverage Next.js App Router file conventions: page, layout, loading, error, and not-found.\nStep 3: Fetch data directly on the server with automated fetch caching and revalidation (ISR).\nStep 4: Implement mutations using Server Actions with revalidatePath and optimistic UI updates.',
      topics: [
        'React Server Components (RSC) vs Client Components: Boundary serialization and security',
        'Next.js 14/15 App Router routing tree: Layout nesting, templates, and parallel/intercepting routes',
        'Data fetching paradigms: Server fetch caching, tags, revalidatePath, and Incremental Static Regeneration (ISR)',
        'Server Actions: Form mutations, progressive enhancement, pending states (useFormStatus), and security'
      ],
      practicalProject: 'Full-Stack Modern Blog & Content Platform: Build a Next.js App Router application with Markdown rendering, server actions for comments, and streaming suspense skeletons.',
      deliverable: 'Production Next.js application achieving 98+ Google Lighthouse Performance Score.',
      recommendedTools: ['Next.js 14/15', 'Tailwind CSS', 'Vercel CLI', 'TypeScript'],
      interviewQuestions: [
        {
          question: 'What can React Server Components do that Client Components cannot, and vice versa?',
          answer_guide: 'RSC can access backend resources (databases, secrets) directly without API layers and add zero KB to client bundle; Client Components can use browser APIs, hooks (useState/useEffect), and event listeners.'
        },
        {
          question: 'Explain how Streaming with Suspense improves TTFB and First Contentful Paint (FCP) in Next.js.',
          answer_guide: 'Instead of blocking the entire HTML response until all server queries finish, Next.js streams the initial layout and skeleton immediately, streaming data chunks as promises resolve.'
        }
      ],
      tasks: [
        { title: 'Migrate a multi-page app to Next.js App Router architecture', description: 'Implement nested layouts, loading skeletons with Suspense, and error boundaries.', estimated_hours: 10 },
        { title: 'Build end-to-end form mutation using Next.js Server Actions', description: 'Integrate Zod schema validation, useFormState, useOptimistic, and revalidatePath.', estimated_hours: 8 }
      ]
    },
    {
      phaseTitle: 'Phase 4: Fullstack Web Application Capstone with Tailwind & Prisma',
      focusSkill: 'Production Application Architecture, Authentication & Cloud Deployment',
      goal: 'Synthesize acquired skills into a production-grade fullstack SaaS capstone with database ORM, user auth, and public deployment.',
      howToAchieve: 'Step 1: Set up PostgreSQL database with Prisma ORM / Drizzle schema migrations.\nStep 2: Implement secure authentication using NextAuth.js / Clerk with OAuth and session tokens.\nStep 3: Design responsive, accessible UI with Tailwind CSS and Radix UI / Shadcn UI components.\nStep 4: Deploy to Vercel with environment variables, custom domain, and automated preview branch builds.',
      topics: [
        'Prisma / Drizzle ORM schema design, relational migrations, and relation queries',
        'Authentication flows: OAuth2 (Google/GitHub), JWT session tokens, and route middleware protection',
        'Modern component systems: Tailwind CSS, Radix UI primitives, and Shadcn UI architecture',
        'Production deployment, environment variable hygiene, and web analytics integration'
      ],
      practicalProject: 'Production SaaS Management Platform: End-to-end multi-tenant dashboard with authentication, database persistence, dark mode, and public URL.',
      deliverable: 'Live deployed fullstack URL + GitHub repository + 90-second Loom architecture walkthrough.',
      recommendedTools: ['Next.js', 'Prisma ORM', 'Supabase / Neon Postgres', 'NextAuth / Clerk', 'Vercel'],
      interviewQuestions: [
        {
          question: 'How do you protect private routes and API endpoints in Next.js App Router against unauthorized access?',
          answer_guide: 'Use Next.js Middleware to verify JWT/session cookies before rendering, and re-verify session authenticity inside Server Actions and Data Access Layers (DAL).'
        }
      ],
      tasks: [
        { title: 'Architect and deploy fullstack SaaS capstone with Prisma and NextAuth', description: 'Deliver complete CRUD application with database migrations, OAuth, and live Vercel URL.', estimated_hours: 16 },
        { title: 'Record a 90-second technical architecture video demo', description: 'Articulate architectural trade-offs, state flow, and performance metrics clearly.', estimated_hours: 6 }
      ]
    },
    {
      phaseTitle: 'Phase 5: Frontend System Design, Web Vitals & Technical Screening',
      focusSkill: 'Frontend System Design, Core Web Vitals (LCP/INP/CLS) & Interview Mastery',
      goal: 'Pass senior frontend technical interviews, ace frontend system design rounds, and optimize Core Web Vitals to perfection.',
      howToAchieve: 'Step 1: Study Frontend System Design frameworks: Requirements, Component Hierarchy, State Model, Data APIs, Optimizations.\nStep 2: Optimize Core Web Vitals: Largest Contentful Paint (LCP), Interaction to Next Paint (INP), and Cumulative Layout Shift (CLS).\nStep 3: Master live coding challenges: Infinite scroll, autocomplete combobox, drag-and-drop kanban.\nStep 4: Conduct mock technical rounds focusing on trade-off communication and engineering depth.',
      topics: [
        'Frontend System Design: Building News Feed, Infinite Scroll, E-Commerce Checkout, Autocomplete',
        'Core Web Vitals profiling: LCP, INP, CLS optimization, bundle splitting, and image formats (AVIF/WebP)',
        'Web security essentials: XSS mitigation, CSRF tokens, Content Security Policy (CSP), and sanitized dangerouslySetInnerHTML',
        'Frontend interview behavioral drills and STAR storytelling for key architectural accomplishments'
      ],
      practicalProject: 'Production Autocomplete & Infinite Scroll System Design Lab: Build an accessible, debounced, virtualized combobox handling 50k items at 60 FPS.',
      deliverable: 'Verified portfolio component benchmarked with 60 FPS scrolling and zero layout shift.',
      recommendedTools: ['Lighthouse / Chrome DevTools Performance', 'WebPageTest', 'Employ.AI Resume ATS'],
      interviewQuestions: [
        {
          question: 'How would you architect an infinite scrolling news feed that remains smooth over 10,000 posts?',
          answer_guide: 'Implement list virtualization (DOM recycling with TanStack Virtual / react-window), debounce scroll events, paginate backend cursor-based queries, and memoize rendered post items.'
        }
      ],
      tasks: [
        { title: 'Optimize an application to achieve 95+ score on all Core Web Vitals', description: 'Eliminate layout shifts, implement image priority loading, and compress JS bundles.', estimated_hours: 8 },
        { title: 'Complete mock Frontend System Design interview simulation', description: 'Design an end-to-end collaborative kanban board or video streaming UI under 45 minutes.', estimated_hours: 6 }
      ]
    }
  ],

  // --------------------------------------------------------------------------
  // 3. FASTAPI & ASYNC MICROSERVICES
  // --------------------------------------------------------------------------
  'cs-fastapi': [
    {
      phaseTitle: 'Phase 1: Python Async Foundations, Routing & Pydantic v2 Models',
      focusSkill: 'Asyncio Event Loops, Type Hinting & Automatic OpenAPI Generation',
      goal: 'Master async/await concurrency, Pydantic v2 data validation schemas, path/query parameters, and RESTful routing.',
      howToAchieve: 'Step 1: Understand Python asyncio event loops, coroutines, and non-blocking I/O.\nStep 2: Build FastAPI routers using APIRouter, response models, and status codes.\nStep 3: Define strict Pydantic v2 schemas with Field constraints and custom validators.\nStep 4: Leverage automatic Swagger UI / ReDoc generation for interactive API inspection.',
      topics: [
        'Asyncio event loop execution model: Coroutines, tasks, and non-blocking network I/O',
        'FastAPI route decorators, path parameters, query parameters, and header extraction',
        'Pydantic v2: BaseModel, Field validation, computed fields, and serialization performance',
        'OpenAPI 3.1 specification, Swagger UI customization, and HTTP error handling'
      ],
      practicalProject: 'High-Throughput Student Admissions API: Build an asynchronous RESTful microservice with comprehensive Pydantic validation and auto-generated docs.',
      deliverable: 'FastAPI application with 100% schema validation and automated OpenAPI spec export.',
      recommendedTools: ['FastAPI', 'Uvicorn', 'Pydantic v2', 'Pytest-asyncio'],
      interviewQuestions: [
        {
          question: 'Why does FastAPI perform significantly faster than traditional frameworks like Flask or Django for I/O-bound tasks?',
          answer_guide: 'FastAPI is built on Starlette and ASGI, leveraging Python async/await to handle thousands of concurrent I/O operations without thread blocking overhead.'
        }
      ],
      tasks: [
        { title: 'Create REST microservice with nested Pydantic v2 validation models', description: 'Implement field sanitizers, custom validators, and comprehensive HTTP exception handlers.', estimated_hours: 8 },
        { title: 'Write async unit test suite using httpx and pytest-asyncio', description: 'Achieve 95%+ coverage validating status codes, validation errors, and payloads.', estimated_hours: 6 }
      ]
    },
    {
      phaseTitle: 'Phase 2: Relational Persistence: Async SQLAlchemy, Migrations & JWT Auth',
      focusSkill: 'Async ORM Sessions, Database Connection Pooling & OAuth2 Security',
      goal: 'Integrate PostgreSQL with async SQLAlchemy 2.0, execute Alembic migrations, and implement OAuth2 password bearer authentication with JWT.',
      howToAchieve: 'Step 1: Configure async PostgreSQL engine with connection pooling and async_sessionmaker.\nStep 2: Define SQLAlchemy ORM mapped models and configure Alembic migration scripts.\nStep 3: Implement user registration, bcrypt password hashing, and JWT token generation.\nStep 4: Build reusable FastAPI Depends() dependency injection for current authenticated user.',
      topics: [
        'SQLAlchemy 2.0 async engine, AsyncSession, select/insert queries, and relationship loading',
        'Alembic database migrations: auto-generation, upgrade, and downgrade workflows',
        'OAuth2 Password Bearer flow, PyJWT token creation, expiration, and refresh mechanics',
        'FastAPI Dependency Injection (Depends): Database session lifecycle and auth guard isolation'
      ],
      practicalProject: 'Secure Multi-Tenant Auth & User Profile Microservice: Build an async PostgreSQL service with password hashing, JWT rotation, and RBAC roles.',
      deliverable: 'Fully migrated database service with isolated test database fixtures and passing auth tests.',
      recommendedTools: ['SQLAlchemy 2.0', 'Alembic', 'PostgreSQL / asyncpg', 'Passlib / Bcrypt'],
      interviewQuestions: [
        {
          question: 'How does FastAPI Dependency Injection (Depends) manage the lifecycle of database sessions?',
          answer_guide: 'Using a generator with yield (e.g. async with async_session() as session: yield session) ensures the session is created per-request and automatically closed even if errors occur.'
        }
      ],
      tasks: [
        { title: 'Set up async PostgreSQL engine with Alembic migration pipeline', description: 'Configure mapped declarative base with relationship cascades and connection pool sizing.', estimated_hours: 8 },
        { title: 'Implement JWT OAuth2 authentication with role-based access control', description: 'Create secure token verification dependency with automated 401/403 authorization guards.', estimated_hours: 8 }
      ]
    },
    {
      phaseTitle: 'Phase 3: Microservices, Celery/Redis Queues & Background Workers',
      focusSkill: 'Asynchronous Background Jobs, Caching Layers & Inter-Service Messaging',
      goal: 'Offload long-running tasks using Celery/Redis or FastAPI BackgroundTasks, implement Redis caching, and build WebSockets.',
      howToAchieve: 'Step 1: Implement FastAPI BackgroundTasks for lightweight post-response execution.\nStep 2: Connect Celery with Redis broker for heavy computational or email jobs.\nStep 3: Add Redis cache-aside decorators to high-frequency GET endpoints.\nStep 4: Implement bidirectional WebSockets for real-time notifications and telemetry.',
      topics: [
        'FastAPI BackgroundTasks vs Celery worker architecture for long-running processes',
        'Redis cache-aside pattern: TTL management, cache invalidation, and serialization',
        'FastAPI WebSocket endpoints: Connection management, broadcast channels, and heartbeat pings',
        'Microservice communication: HTTPX async client, retry policies, and circuit breakers'
      ],
      practicalProject: 'Real-Time Notification & Background Report Engine: Build an async service that processes heavy PDF generation in background queues and pushes WebSocket progress updates.',
      deliverable: 'Async service with Redis queue monitoring and real-time WebSocket client.',
      recommendedTools: ['Redis', 'Celery / ARQ', 'HTTPX', 'Docker Compose'],
      interviewQuestions: [
        {
          question: 'When should you use Celery instead of FastAPI built-in BackgroundTasks?',
          answer_guide: 'BackgroundTasks run inside the same process memory; if the server restarts, tasks are lost. Celery uses a persistent message queue, supports retries, distributed workers, and rate limiting.'
        }
      ],
      tasks: [
        { title: 'Integrate Redis cache-aside layer on high-traffic endpoints', description: 'Implement cache hit/miss logic with automated cache invalidation on mutations.', estimated_hours: 8 },
        { title: 'Build background task pipeline with Celery worker cluster', description: 'Offload batch data processing jobs with progress tracking and failure retries.', estimated_hours: 8 }
      ]
    },
    {
      phaseTitle: 'Phase 4: High-Throughput API Capstone with Docker & Rate Limiting',
      focusSkill: 'Production Containerization, Rate Limiting & Performance Profiling',
      goal: 'Package an enterprise-grade async microservice in multi-stage Docker containers with rate limiting, logging, and stress testing.',
      howToAchieve: 'Step 1: Write multi-stage Dockerfile optimized for minimal size and non-root execution.\nStep 2: Implement Redis-backed token bucket rate limiting using SlowAPI.\nStep 3: Configure structured JSON logging with request ID correlation for distributed tracing.\nStep 4: Execute stress testing with Locust benchmarking 2000+ RPS under sub-50ms latency.',
      topics: [
        'Docker multi-stage builds, Gunicorn + Uvicorn worker process management',
        'SlowAPI / Redis rate limiting: Token bucket and sliding window rate limiting',
        'Structured logging (structlog), correlation IDs, and Prometheus metrics exposition',
        'Load testing with Locust: Concurrent user ramp-up, latency percentiles, and bottleneck triage'
      ],
      practicalProject: 'High-Throughput Financial Transaction Microservice: Deploy a containerized, rate-limited, metrics-instrumented async API handling 2k+ requests per second.',
      deliverable: 'Public GitHub repo + Docker Compose configuration + Locust benchmark audit report.',
      recommendedTools: ['Docker', 'Gunicorn', 'Locust', 'SlowAPI', 'Prometheus'],
      interviewQuestions: [
        {
          question: 'How do you calculate the optimal number of Gunicorn Uvicorn workers for a production FastAPI instance?',
          answer_guide: 'Formula: (2 x CPU cores) + 1. For predominantly async I/O-bound tasks, fewer workers with high concurrent event loop concurrency are preferred to avoid CPU context switching.'
        }
      ],
      tasks: [
        { title: 'Containerize FastAPI microservice with multi-stage Docker build', description: 'Configure non-root user, health checks, and Gunicorn UvicornWorker cluster.', estimated_hours: 10 },
        { title: 'Execute Locust load test benchmarking 2000+ requests per second', description: 'Document latency percentiles and eliminate database connection pool starvation.', estimated_hours: 8 }
      ]
    },
    {
      phaseTitle: 'Phase 5: Backend Engineering Placement & System Design Screening',
      focusSkill: 'Distributed Backend System Design, API Security & Technical Interviews',
      goal: 'Pass senior backend engineering screening rounds, articulate microservice architectural decisions, and optimize ATS resume match.',
      howToAchieve: 'Step 1: Practice backend system design: URL shortener, rate limiter, notification system.\nStep 2: Deep dive into API security: OWASP API Security Top 10, CORS, and SQL injection prevention.\nStep 3: Simulate live backend coding challenges covering concurrency, caching, and ORM profiling.\nStep 4: Target top backend openings with verified project metrics on Employ.AI.',
      topics: [
        'Backend System Design: Designing idempotent payment APIs, event-driven architectures, and sharding',
        'OWASP API Security Top 10: Broken object level authorization (BOLA), mass assignment, rate limiting',
        'Database query profiling: Eliminating N+1 query antipatterns in SQLAlchemy with joinedload/selectinload',
        'Technical interview communication: Explaining distributed transactions (Saga pattern) and CAP theorem'
      ],
      practicalProject: 'Placement Portfolio Verification: Pass technical mock backend evaluation and submit verified profile to hiring partners.',
      deliverable: 'Verified Employ.AI Backend Engineer Profile with 95%+ ATS score and active applications.',
      recommendedTools: ['Employ.AI Resume ATS Optimizer', 'Draw.io / Excalidraw', 'Postman / Bruno'],
      interviewQuestions: [
        {
          question: 'How do you prevent the N+1 query problem when loading related models in SQLAlchemy async?',
          answer_guide: 'Use eager loading strategies like selectinload() (separate IN query) or joinedload() (SQL JOIN) rather than lazy loading, which executes a query per parent record.'
        }
      ],
      tasks: [
        { title: 'Complete mock Backend System Design whiteboard interview', description: 'Architect a scalable distributed notification microservice under 45 minutes.', estimated_hours: 6 },
        { title: 'Audit and eliminate N+1 queries using SQLAlchemy logging', description: 'Verify all relational endpoints execute in constant O(1) database queries.', estimated_hours: 6 }
      ]
    }
  ]
};

// ============================================================================
// Intelligent Discipline / Category Phase Generator for All Other Co-Domains
// ============================================================================
export function generateCategoryPhases(
  effectiveDomain: string,
  effectiveCoDomain: string,
  category: string = 'General',
  _difficulty: string = 'Intermediate'
): CoDomainPhaseTemplate[] {
  const cd = effectiveCoDomain;
  const dom = effectiveDomain;
  const cat = category.toLowerCase();

  if (cat.includes('clinical') || cat.includes('medicine') || cat.includes('diagnostics') || dom === 'MBBS') {
    return [
      {
        phaseTitle: `Phase 1: Clinical Fundamentals, Bedside History & Physical Examination: ${cd}`,
        focusSkill: `Patient History Taking, Systemic Physical Examination & Baseline Rules`,
        goal: `Master foundational clinical terminology, anatomical landmarks, patient rapport, and systematic bedside diagnostic examination for ${cd}.`,
        howToAchieve: `Step 1: Study clinical anatomy, physiology, and cardinal symptoms for ${cd}.\nStep 2: Practice IPPA (Inspection, Palpation, Percussion, Auscultation) bedside techniques.\nStep 3: Formulate broad differential diagnoses based on patient history.\nStep 4: Verify physical signs against verified clinical reference textbooks.`,
        topics: [
          `Foundational clinical principles, terminology, and patient examination protocols for ${cd}`,
          'Systemic history taking: Onset, duration, exacerbating factors, and past medical history',
          'Inspection, palpation, percussion, and auscultation checklists',
          'Formulating initial differential diagnoses and red-flag symptom triage'
        ],
        practicalProject: `Clinical Diagnostic Workup: Document 3 comprehensive simulated patient case examinations for ${cd}.`,
        deliverable: `Standardized Clinical History & Examination Case Portfolio with differential trees.`,
        recommendedTools: ['Stethoscope / Diagnostic Kit', 'Geeky Medics Clinical Checklists', 'Clinical OSCE Arena'],
        interviewQuestions: [
          { question: `What are the critical red-flag findings in ${cd} that demand immediate emergency stabilization?`, answer_guide: 'Detail hemodynamic instability, acute neurological deficits, and organ failure criteria.' }
        ],
        tasks: [
          { title: `Complete bedside examination protocols for ${cd}`, description: 'Master structured IPPA checklists and clinical history elicitation.', estimated_hours: 8 },
          { title: `Author 3 differential diagnosis workups for ${cd}`, description: 'Document systemic findings and correlate with standard medical guidelines.', estimated_hours: 6 }
        ]
      },
      {
        phaseTitle: `Phase 2: Applied Diagnostic Investigations & Clinical Pathology: ${cd}`,
        focusSkill: `Laboratory Biomarkers, Imaging Correlation & Diagnostic Algorithms`,
        goal: `Interpret core diagnostic laboratory panels, radiological imaging, and procedural diagnostics relevant to ${cd}.`,
        howToAchieve: `Step 1: Master normal physiological ranges and pathological deviations for ${cd}.\nStep 2: Interpret relevant imaging (X-Ray, CT, Ultrasound) and laboratory biomarker panels.\nStep 3: Connect investigative findings with clinical history to confirm primary diagnosis.\nStep 4: Adhere strictly to diagnostic stewardship and cost-effective patient care.`,
        topics: [
          `Diagnostic investigations: Complete blood counts, biochemical panels, and biomarkers in ${cd}`,
          'Radiological imaging interpretation: Systematic reading of plain radiographs and cross-sectional scans',
          'Diagnostic algorithms: Ruling out life-threatening conditions systematically',
          'Interpreting borderline or ambiguous investigative results'
        ],
        practicalProject: `Diagnostic Investigation Case Series: Correlate laboratory biomarkers and imaging findings across 5 clinical cases in ${cd}.`,
        deliverable: `Diagnostic Report Analysis Portfolio with validated clinical deductions.`,
        recommendedTools: ['Hospital EHR / PACS Simulator', 'UpToDate / ClinicalKey', 'Diagnostic Guidelines'],
        interviewQuestions: [
          { question: `How do you reconcile a clinical presentation that contradicts laboratory test findings in ${cd}?`, answer_guide: 'Re-examine the patient, repeat the test to rule out pre-analytical error, and evaluate clinical sensitivity/specificity.' }
        ],
        tasks: [
          { title: `Interpret 10 investigative laboratory panels in ${cd}`, description: 'Analyze arterial blood gases, organ function tests, and specific disease markers.', estimated_hours: 8 },
          { title: `Formulate diagnostic algorithm flowchart for ${cd}`, description: 'Map step-by-step diagnostic pathways from presenting complaint to confirmation.', estimated_hours: 6 }
        ]
      },
      {
        phaseTitle: `Phase 3: Evidence-Based Therapeutics & Critical Decision Making: ${cd}`,
        focusSkill: `Pharmacotherapy, Clinical Protocols & Emergency Interventions`,
        goal: `Master evidence-based medical treatment guidelines, drug dosages, counter-indications, and acute intervention protocols for ${cd}.`,
        howToAchieve: `Step 1: Study first-line pharmacotherapy, mechanism of action, and drug interactions in ${cd}.\nStep 2: Master dose calculations, renal/hepatic adjustments, and antibiotic stewardship.\nStep 3: Practice acute patient stabilization protocols (BLS / ACLS / ATLS).\nStep 4: Evaluate surgical versus conservative management criteria.`,
        topics: [
          `Evidence-based clinical guidelines and therapeutic protocols in ${cd}`,
          'Pharmacotherapy: Dosing calculations, adverse drug reactions, and drug-drug interactions',
          'Emergency management: Rapid stabilization, fluid resuscitation, and monitoring',
          'Multidisciplinary care coordination and specialist referral criteria'
        ],
        practicalProject: `Comprehensive Patient Treatment Plan: Formulate complete therapeutic regimen and monitoring schedule for acute and chronic stages of ${cd}.`,
        deliverable: `Evidence-based Treatment Protocol with monitoring criteria and contingency plans.`,
        recommendedTools: ['National Clinical Guidelines', 'BNF / Medscape Pharmacotherapy', 'Hospital SOP Manuals'],
        interviewQuestions: [
          { question: `What are the dosage calculation considerations and contraindications for first-line therapies in ${cd}?`, answer_guide: 'Discuss patient weight, renal/hepatic clearance, therapeutic drug monitoring, and black-box warnings.' }
        ],
        tasks: [
          { title: `Develop therapeutic care plan for complex ${cd} patient`, description: 'Detail pharmacological dosing, supportive measures, and adverse reaction protocols.', estimated_hours: 10 },
          { title: `Audit antibiotic and pharmacotherapy stewardship in ${cd}`, description: 'Verify treatment compliance against latest evidence-based clinical guidelines.', estimated_hours: 6 }
        ]
      },
      {
        phaseTitle: `Phase 4: Hospital Case Workups & Clinical Audit Portfolio: ${cd}`,
        focusSkill: `Clinical Auditing, Multidisciplinary Case Presentation & Inpatient Care`,
        goal: `Synthesize comprehensive patient care in hospital wards/clinics into documented clinical audits and case presentations in ${cd}.`,
        howToAchieve: `Step 1: Document end-to-end patient hospital stays from admission to discharge for ${cd}.\nStep 2: Conduct clinical audit measuring institutional care against national quality standards.\nStep 3: Present case studies with structured clinical reasoning and literature reviews.\nStep 4: Author standardized discharge summaries and patient counselling instructions.`,
        topics: [
          `Inpatient management: Daily ward rounds, progress notes, and clinical trajectory tracking in ${cd}`,
          'Clinical governance: Morbidity & mortality reviews, adverse event reporting, and clinical audits',
          'Patient communication: Delivering difficult diagnoses, informed consent, and shared decision making',
          'Discharge planning, rehabilitation protocols, and outpatient follow-up schedules'
        ],
        practicalProject: `Flagship Hospital Clinical Audit: Conduct an audit of 20 clinical cases in ${cd} evaluating adherence to institutional standard operating procedures.`,
        deliverable: `Formal Clinical Audit Presentation with quantified compliance benchmarks and improvement recommendations.`,
        recommendedTools: ['Hospital Quality Frameworks', 'Clinical Audit Tools', 'Medical Case Repositories'],
        interviewQuestions: [
          { question: `Describe how you conducted a clinical audit in ${cd} and what institutional changes resulted from your findings.`, answer_guide: 'Use the audit cycle: standard criteria, data collection, gap identification, intervention, and re-audit.' }
        ],
        tasks: [
          { title: `Complete formal clinical case audit in ${cd}`, description: 'Evaluate care outcomes against national guidelines and identify quality improvement targets.', estimated_hours: 14 },
          { title: `Present multidisciplinary case report on complex ${cd} presentation`, description: 'Deliver clinical viva slide deck with comprehensive literature appraisal.', estimated_hours: 6 }
        ]
      },
      {
        phaseTitle: `Phase 5: Medical Officer & Residency Placement Screening: ${cd}`,
        focusSkill: `OSCE Clinical Stations, Viva Voce Mastery & Medical Council Standards`,
        goal: `Excel in medical residency interviews, Clinical OSCE examinations, and hospital placement evaluations in ${cd}.`,
        howToAchieve: `Step 1: Practice timed OSCE clinical examination stations with peer standardized patients.\nStep 2: Drill viva voce scenarios covering clinical dilemmas, ethics, and medico-legal laws.\nStep 3: Align medical curriculum vitae highlighting clinical audits, case presentations, and BLS/ACLS certifications.\nStep 4: Prepare for hospital panel interviews with top healthcare networks.`,
        topics: [
          `OSCE stations: Structured clinical exams covering history, examination, communication, and procedural skills in ${cd}`,
          'Viva voce examination: Rapid clinical decision making, rare presentations, and guideline updates',
          'Medical ethics: Patient autonomy, confidentiality, consent in emergencies, and clinical negligence laws',
          'Hospital panel interviews: Clinical leadership, teamwork, stress management, and continuous learning'
        ],
        practicalProject: `Residency Placement Clinical Evaluation: Complete 6 timed OSCE mock stations and pass medical panel screening with 85%+ score.`,
        deliverable: `Verified Employ.AI Medical Placement Portfolio with OSCE assessment reports.`,
        recommendedTools: ['OSCE Station Stopwatch', 'Employ.AI Medical CV Optimizer', 'Medical Council Guidelines'],
        interviewQuestions: [
          { question: `How do you handle a clinical conflict with a senior colleague regarding patient management in ${cd}?`, answer_guide: 'Focus on patient safety first, verify clinical evidence politely, communicate objectively, and escalate via proper clinical governance.' }
        ],
        tasks: [
          { title: `Complete 6 mock OSCE clinical examination stations in ${cd}`, description: 'Simulate high-pressure medical residency evaluation with standardized patient feedback.', estimated_hours: 8 },
          { title: `Optimize medical curriculum vitae and clinical portfolio`, description: 'Verify clinical procedure logs, case reports, and certifications on Employ.AI.', estimated_hours: 6 }
        ]
      }
    ];
  }

  if (cat.includes('accounting') || cat.includes('finance') || cat.includes('taxation') || dom === 'BCOM') {
    return [
      {
        phaseTitle: `Phase 1: Statutory Accounting Framework & Ledger Foundations: ${cd}`,
        focusSkill: `Double-Entry Bookkeeping, Financial Standard Principles & Journal Mechanics`,
        goal: `Master core statutory guidelines, accounting standards, voucher entries, and trial balance verification for ${cd}.`,
        howToAchieve: `Step 1: Study statutory accounting principles and regulatory mandates for ${cd}.\nStep 2: Execute complex journal entries, adjustments, and ledger reconciliations.\nStep 3: Build trial balance and identify debit/credit discrepancies.\nStep 4: Verify compliance against national accounting standards.`,
        topics: [
          `Foundational accounting principles, double-entry conventions, and statutory rules in ${cd}`,
          'Voucher processing, ledger accounting, and bank reconciliation statements (BRS)',
          'Prepayments, accruals, depreciation schedules, and closing entries',
          'Statutory chart of accounts and ERP financial configuration'
        ],
        practicalProject: `Full-Year Corporate Ledger Reconciliation: Balance annual books and generate verified Trial Balance for ${cd}.`,
        deliverable: `Audited Trial Balance and Ledger Reconciliation Report with zero variance.`,
        recommendedTools: ['TallyPrime / SAP ERP', 'Microsoft Excel', 'ICAI Accounting Guidelines'],
        interviewQuestions: [
          { question: `What are the golden rules of accounting and how do they apply to complex transactions in ${cd}?`, answer_guide: 'Detail Personal, Real, and Nominal accounts with concrete transaction examples.' }
        ],
        tasks: [
          { title: `Reconcile monthly corporate ledger and bank statements for ${cd}`, description: 'Identify and resolve timing differences, unpresented cheques, and bank charges.', estimated_hours: 8 },
          { title: `Construct verified adjusted Trial Balance`, description: 'Apply period-end accruals, depreciation, and closing inventory valuations.', estimated_hours: 6 }
        ]
      },
      {
        phaseTitle: `Phase 2: Financial Statement Preparation & Statutory Compliance: ${cd}`,
        focusSkill: `Balance Sheet Preparation, Profit & Loss Schedules & Regulatory Filings`,
        goal: `Prepare comprehensive financial statements adhering strictly to statutory presentation schedules and accounting standards for ${cd}.`,
        howToAchieve: `Step 1: Draft Balance Sheet and Statement of Profit & Loss to official schedules.\nStep 2: Compute statutory tax liabilities, advance taxes, and deferred tax assets/liabilities.\nStep 3: Prepare notes to accounts and mandatory statutory disclosures.\nStep 4: Verify internal financial controls and voucher substantive evidence.`,
        topics: [
          `Preparation of Balance Sheet and Statement of Profit & Loss under statutory schedules for ${cd}`,
          'Cash Flow Statement (Direct vs Indirect method under AS 3 / Ind AS 7)',
          'Statutory disclosures: Contingent liabilities, related party transactions, and segment reporting',
          'Tax provisions: Current tax, deferred tax, and minimum alternate tax (MAT) computations'
        ],
        practicalProject: `Corporate Financial Statements Compilation: Draft full financial statements package including Balance Sheet, P&L, Cash Flow, and Notes for ${cd}.`,
        deliverable: `Published Financial Statements Portfolio compliant with Schedule III standards.`,
        recommendedTools: ['Excel Financial Modeling', 'ERP Financial Reporting', 'MCA Filing Portal'],
        interviewQuestions: [
          { question: `Explain the difference between deferred tax assets and liabilities in ${cd} and when they are recognized.`, answer_guide: 'Arise from temporary timing differences between accounting profit and taxable income; recognized only when future taxable profit is probable.' }
        ],
        tasks: [
          { title: `Draft complete corporate financial statements for ${cd}`, description: 'Generate Balance Sheet, P&L, and Cash Flow Statement from raw trial balance data.', estimated_hours: 10 },
          { title: `Prepare comprehensive statutory notes and disclosure schedules`, description: 'Document accounting policies, fixed asset registers, and contingent liabilities.', estimated_hours: 6 }
        ]
      },
      {
        phaseTitle: `Phase 3: Corporate Financial Modeling, Ratios & Audit Assurance: ${cd}`,
        focusSkill: `Financial Ratio Analysis, Internal Assurance & Statutory Audit Standards`,
        goal: `Execute in-depth financial ratio analysis, working capital optimization, and substantive internal audit procedures in ${cd}.`,
        howToAchieve: `Step 1: Compute liquidity, solvency, profitability, and operational efficiency ratios.\nStep 2: Perform vouching, verification, and internal control reviews.\nStep 3: Analyze CARO compliance checkpoints and statutory auditor responsibilities.\nStep 4: Identify fraud risk factors and internal control weaknesses.`,
        topics: [
          `Financial statement analysis: DuPont analysis, working capital cycles, and cash flow adequacy in ${cd}`,
          'Statutory auditing standards: Substantive testing, analytical procedures, and audit sampling',
          'Companies (Auditor Report) Order (CARO) reporting requirements and checklists',
          'Internal financial controls (IFC) and testing operational effectiveness'
        ],
        practicalProject: `Statutory Audit & Financial Analysis Dossier: Perform comprehensive audit verification and financial ratio diagnostic on corporate accounts in ${cd}.`,
        deliverable: `Formal Audit Verification Memo with identified variances and ratio diagnostic report.`,
        recommendedTools: ['Excel Financial Tools', 'Audit Working Papers', 'MCA Statutory Portal'],
        interviewQuestions: [
          { question: `What substantive audit procedures do you perform to verify revenue recognition in ${cd}?`, answer_guide: 'Inspect contracts, verify performance obligations, vouch sales invoices to shipping bills, and perform cut-off testing.' }
        ],
        tasks: [
          { title: `Perform comprehensive financial ratio diagnostic on corporate entity in ${cd}`, description: 'Compute and interpret 15 key financial ratios benchmarking against industry peers.', estimated_hours: 8 },
          { title: `Execute statutory audit verification checklist`, description: 'Perform substantive audit sampling and document CARO compliance checkpoints.', estimated_hours: 8 }
        ]
      },
      {
        phaseTitle: `Phase 4: Advanced Valuation, Capital Budgeting & Executive Reporting: ${cd}`,
        focusSkill: `DCF Valuation, Capital Budgeting (NPV/IRR) & Strategic Presentations`,
        goal: `Build dynamic 3-statement financial models, evaluate capital investments, and present strategic recommendations in ${cd}.`,
        howToAchieve: `Step 1: Build dynamically linked 3-statement model (P&L, Balance Sheet, Cash Flow) in Excel.\nStep 2: Model capital budgeting scenarios using NPV, IRR, and payback period.\nStep 3: Perform Discounted Cash Flow (DCF) valuation and sensitivity analysis.\nStep 4: Prepare executive board deck synthesizing financial projections and recommendations.`,
        topics: [
          `Dynamic 3-statement financial modeling in Excel with linked schedules in ${cd}`,
          'Capital budgeting: Net Present Value (NPV), Internal Rate of Return (IRR), and hurdle rates',
          'Discounted Cash Flow (DCF) valuation: Free Cash Flow to Firm (FCFF), WACC, and terminal value',
          'Executive financial storytelling and presenting to Chief Financial Officers (CFOs)'
        ],
        practicalProject: `Dynamic 3-Statement Financial Model & Valuation Capstone: Build fully interactive model projecting 5-year financials and DCF valuation for ${cd}.`,
        deliverable: `Dynamic Excel Financial Model with sensitivity tables and executive presentation deck.`,
        recommendedTools: ['Advanced Excel', 'Power BI / Tableau', 'Financial Modeling Templates'],
        interviewQuestions: [
          { question: `Walk through how an increase in depreciation flows through the 3 financial statements in ${cd}.`, answer_guide: 'P&L: Operating income drops, tax decreases; Cash Flow: Net income lower but depreciation added back, net cash increases by tax savings; Balance Sheet: Cash increases, PPE decreases.' }
        ],
        tasks: [
          { title: `Construct dynamic 5-year 3-statement projection model in Excel for ${cd}`, description: 'Link revenue drivers, working capital schedules, and debt amortization tables.', estimated_hours: 14 },
          { title: `Perform DCF valuation with multi-variable sensitivity tables`, description: 'Calculate WACC, project free cash flows, and stress-test terminal growth rates.', estimated_hours: 6 }
        ]
      },
      {
        phaseTitle: `Phase 5: Corporate Finance & Big-4 Placement Screening: ${cd}`,
        focusSkill: `Big-4 Technical Interviews, Corporate Accounting Drills & ATS Optimization`,
        goal: `Pass technical screening rounds at Big-4 audit firms, global investment banks, and multinational corporate finance teams in ${cd}.`,
        howToAchieve: `Step 1: Practice technical interview accounting scenarios and practical journaling.\nStep 2: Master financial modeling speed tests under timed corporate screening conditions.\nStep 3: Align resume ATS score with verified finance keywords and STAR impact bullets.\nStep 4: Participate in corporate finance mock interviews and behavioral rounds.`,
        topics: [
          `Technical accounting interviews: Complex journal entries, Ind AS/IFRS adjustments, and consolidation in ${cd}`,
          'Financial modeling test drills: Rapid 3-statement build under 60-minute time limit',
          'ATS resume optimization for Big-4 audit, tax consulting, and FP&A analyst roles',
          'Behavioral screening: Ethical dilemmas, pressure handling, and client-facing communication'
        ],
        practicalProject: `Corporate Finance Placement Verification: Complete timed financial modeling test and pass technical screening panel with 90%+ score.`,
        deliverable: `Verified Employ.AI Corporate Finance Portfolio with benchmarked evaluation report.`,
        recommendedTools: ['Employ.AI Resume ATS Optimizer', 'Financial Interview Question Bank'],
        interviewQuestions: [
          { question: `Why should our corporate finance / Big-4 audit team hire you over other candidates for this ${cd} role?`, answer_guide: 'Emphasize strong first-principles accounting, hands-on 3-statement modeling fluency, statutory compliance knowledge, and verified audit projects.' }
        ],
        tasks: [
          { title: `Complete 60-minute timed financial modeling test for ${cd}`, description: 'Build dynamic 3-statement model under strict corporate interview constraints.', estimated_hours: 8 },
          { title: `Optimize resume ATS score for target Big-4 and corporate finance roles`, description: 'Incorporate verified valuation capstones and statutory compliance keywords on Employ.AI.', estimated_hours: 6 }
        ]
      }
    ];
  }

  // Universal Default for Engineering, Science, Tech, Law, Humanities
  return [
    {
      phaseTitle: `Phase 1: Foundational First Principles, Terminology & Toolchain: ${cd}`,
      focusSkill: `Core Theoretical Intuition, Syntax Rules & Professional Environment Setup`,
      goal: `Build rock-solid theoretical intuition, terminology, core equations/rules, and set up the professional working environment for ${cd}.`,
      howToAchieve: `Step 1: Study core theoretical frameworks, syntax rules, and domain specifications for ${cd}.\nStep 2: Install and configure industry-standard toolchains, linters, simulators, and workspace extensions.\nStep 3: Solve introductory problem sets, analyze standard baseline test cases, and establish diagnostic checklists.\nStep 4: Verify your foundational setup against established academic and industry standards.`,
      topics: [
        `Core theoretical foundations and structural rules of ${cd}`,
        'Workspace configuration, dependency management, and linters',
        'Standard terminology, units, parameter boundaries, and safety factors',
        'Introductory problem solving, baseline calculations, and error isolation'
      ],
      practicalProject: `Foundational Diagnostic Benchmark: Build a clean, verified introductory artifact validating ${cd} from scratch.`,
      deliverable: `Working Foundation Repository / Technical Report with zero errors and documented parameters.`,
      recommendedTools: [`Official ${cd} Documentation`, 'VS Code / Professional Domain IDE', 'Standard Verification Checklists'],
      interviewQuestions: [
        { question: `What are the core foundational principles that distinguish ${cd} from legacy alternatives?`, answer_guide: 'Focus on performance, standard compliance, modularity, and error tolerance.' }
      ],
      tasks: [
        { title: `Complete comprehensive documentation study of ${cd}`, description: 'Master foundational syntax, terminology, and baseline equations.', estimated_hours: 8 },
        { title: `Implement baseline hands-on drill in ${cd}`, description: 'Build and verify introductory problem set adhering strictly to best practices.', estimated_hours: 6 }
      ]
    },
    {
      phaseTitle: `Phase 2: Applied Core Tooling, Real-World Data & Architecture: ${cd}`,
      focusSkill: `Intermediate Modeling, Industry Tool Suites & Real-World Constraints`,
      goal: `Advance from introductory exercises to intermediate domain modeling, realistic data workflows, and professional industry tool suites in ${cd}.`,
      howToAchieve: `Step 1: Dive into intermediate formulas, edge cases, and standard operational failure modes in ${cd}.\nStep 2: Model realistic scenarios with multi-variable constraints and evaluate system trade-offs.\nStep 3: Connect modular components, databases, APIs, or physical simulation engines.\nStep 4: Refine accuracy, error tolerances, and documentation quality.`,
      topics: [
        `Intermediate methodologies, equations, and simulation techniques in ${cd}`,
        'Handling noisy inputs, missing data, and multi-variable constraints',
        'Standard tolerance limits, quality assurance, and compliance checks',
        'Performance profiling and parameter sensitivity tuning'
      ],
      practicalProject: `Applied Industry Case Study: Execute an end-to-end multi-variable modeling exercise in ${cd}.`,
      deliverable: `Verified Computational Model & Analysis Report with Parameter Sensitivity Charts.`,
      recommendedTools: [`Specialized ${cd} Industry Suite`, 'Benchmark Datasets & Real-World Case Studies', 'Automated Testing Frameworks'],
      interviewQuestions: [
        { question: `Explain how you handle data validation and error recovery when applying ${cd} to real-world datasets.`, answer_guide: 'Detail input sanitization, boundary checking, graceful degradation, and structured exception handling.' }
      ],
      tasks: [
        { title: `Develop multi-variable workflow in ${cd}`, description: 'Simulate realistic operational constraints and verify outputs against benchmarks.', estimated_hours: 10 },
        { title: `Perform error diagnostic and tolerance check`, description: 'Document sensitivity analysis across minimum/maximum variance.', estimated_hours: 6 }
      ]
    },
    {
      phaseTitle: `Phase 3: Advanced Systems, Optimization & Statutory Hardening: ${cd}`,
      focusSkill: `High-Performance Optimization, Security, Reliability & System Integration`,
      goal: `Master high-performance optimization, regulatory standards, security hardening, and complex multi-component system integrations in ${cd}.`,
      howToAchieve: `Step 1: Implement high-throughput, low-latency, or high-precision optimizations.\nStep 2: Harden solutions against security vulnerabilities, statutory non-compliance, and edge-case failures.\nStep 3: Integrate with upstream and downstream systems across corporate/engineering pipelines.\nStep 4: Prepare comprehensive technical documentation and audit logs.`,
      topics: [
        `Advanced architecture patterns and high-performance algorithms in ${cd}`,
        'Security hardening, zero-trust principles, and statutory compliance',
        'Scalability, load balancing, caching, and failover redundancy',
        'Executive documentation, audit trails, and automated reporting'
      ],
      practicalProject: `High-Performance Subsystem Integration: Build an integrated, stress-tested system module combining ${cd} with upstream pipelines.`,
      deliverable: `Production-Grade Module with Automated Verification Tests and Performance Benchmark Audit.`,
      recommendedTools: ['System Profilers & Load Testing Utilities', 'Compliance & Audit Verification Engines'],
      interviewQuestions: [
        { question: `What are the trade-offs between performance optimization and maintainability in ${cd}?`, answer_guide: 'Discuss readability, modularity, abstraction overhead, and profiling evidence.' }
      ],
      tasks: [
        { title: `Implement advanced architectural optimizations for ${cd}`, description: 'Achieve measurable performance gain without sacrificing code maintainability.', estimated_hours: 12 },
        { title: `Conduct security and compliance audit`, description: 'Verify zero vulnerabilities and full compliance with industry standards.', estimated_hours: 8 }
      ]
    },
    {
      phaseTitle: `Phase 4: Flagship Production Capstone & Case Study Deliverable: ${cd}`,
      focusSkill: `End-to-End Production Execution, Capstone Deployment & Case Study`,
      goal: `Synthesize acquired competencies into a standalone, production-ready capstone project that proves domain authority to recruiters.`,
      howToAchieve: `Step 1: Define project scope, requirements, user constraints, and quantified impact metrics.\nStep 2: Build the end-to-end solution utilizing professional industry best practices.\nStep 3: Deploy or publish the project publicly with live access, documentation, and demo walkthrough.\nStep 4: Package the capstone with a high-impact case study and quantified STAR bullet summaries.`,
      topics: [
        `Full-lifecycle project execution: Discovery, architecture, build, test, deploy`,
        'Public cloud deployment, HTTPS SSL, and automated CI/CD releases',
        'Technical documentation authoring: README, architecture diagrams, API specs',
        'Quantifying project metrics: Latency, throughput, accuracy, user capacity'
      ],
      practicalProject: `Flagship Production Capstone: End-to-end design, execution, and public deployment showcasing ${cd}.`,
      deliverable: `Live Deployed Application / Published Portfolio Case Study + Architecture Readme + Demo Video.`,
      recommendedTools: ['Public Hosting / Cloud Infrastructure / GitHub', 'Excalidraw / Mermaid Diagrams', 'Loom Video Recording'],
      interviewQuestions: [
        { question: `Walk me through the most challenging hurdle you faced in your ${cd} capstone project.`, answer_guide: 'Use the STAR framework: Situation, Task, Action, Result with quantified metrics.' }
      ],
      tasks: [
        { title: `Build and deploy flagship capstone project for ${cd}`, description: 'Deliver full production-ready implementation with automated tests and documentation.', estimated_hours: 16 },
        { title: `Record a professional 90-second technical walkthrough video`, description: 'Showcase key architectural decisions, trade-offs, and live functionality.', estimated_hours: 6 }
      ]
    },
    {
      phaseTitle: `Phase 5: Internship & Placement Screening: Technical Interviews & ATS Alignment: ${cd}`,
      focusSkill: `Placement Campaign, Technical Screening Mastery & ATS Resume Matching`,
      goal: `Pass technical mock screenings, optimize your resume ATS score on Employ.AI, and convert top-tier internship and job offers in ${cd}.`,
      howToAchieve: `Step 1: Practice 50+ domain-specific interview screening questions covering algorithms, system design, and practical edge cases.\nStep 2: Align your resume on Employ.AI ATS Scanner, formulating STAR impact bullets with verified project metrics.\nStep 3: Conduct mock peer and technical panel interviews focusing on structured technical communication.\nStep 4: Apply to top matched openings on the Employ.AI Opportunities Portal.`,
      topics: [
        `Comprehensive ${cd} technical interview question bank and mock drills`,
        'ATS resume optimization: Keyword density, STAR bullet formatting, project synchronization',
        'Technical behavioral interviews, salary negotiation frameworks, and offer evaluation',
        'Direct application campaign targeting verified hiring partners on Employ.AI'
      ],
      practicalProject: `Placement Campaign Launch: Complete technical mock evaluation and submit 10 applications via Employ.AI Portal.`,
      deliverable: `Verified Employ.AI Candidate Profile with 95%+ Match Score and Active Placement Applications.`,
      recommendedTools: ['Employ.AI Resume ATS Optimizer', 'Employ.AI Opportunities Portal', 'Technical Mock Simulator'],
      interviewQuestions: [
        { question: `Why should our engineering / corporate team hire you for this ${cd} role over other candidates?`, answer_guide: 'Highlight your verified project portfolio, hands-on debugging skills, first-principles understanding, and fast learning velocity.' }
      ],
      tasks: [
        { title: `Complete comprehensive technical mock screening for ${cd}`, description: 'Score 85%+ on comprehensive domain knowledge and problem-solving assessment.', estimated_hours: 8 },
        { title: `Optimize resume ATS score to 90%+ and submit verified applications`, description: 'Incorporate verified capstone evidence and apply to target matching companies.', estimated_hours: 6 }
      ]
    }
  ];
}

// ============================================================================
// Master Phase Builder: Returns 5-Phase Array for ANY Co-Domain
// ============================================================================
export function resolveCoDomainPhaseTemplates(
  effectiveDomain: string,
  effectiveCoDomain: string,
  category?: string
): CoDomainPhaseTemplate[] {
  const cdLower = (effectiveCoDomain || '').toLowerCase();

  // Direct ID or alias matching in curated registry
  if (cdLower.includes('dsa') || cdLower.includes('data structure') || cdLower.includes('algorithm')) {
    return CO_DOMAIN_PHASE_TEMPLATES['cs-dsa'];
  }
  if (cdLower.includes('react') || cdLower.includes('next.js') || cdLower.includes('nextjs')) {
    return CO_DOMAIN_PHASE_TEMPLATES['cs-react'];
  }
  if (cdLower.includes('fastapi')) {
    return CO_DOMAIN_PHASE_TEMPLATES['cs-fastapi'];
  }

  // Check matching key in registry
  for (const [key, templates] of Object.entries(CO_DOMAIN_PHASE_TEMPLATES)) {
    const cleanKey = key.replace(/^cs-|^med-|^ba-|^bcom-|^law-/, '').replace(/-/g, ' ');
    if (cdLower.includes(cleanKey) || cleanKey.includes(cdLower)) {
      return templates;
    }
  }

  // Fallback to intelligent category/discipline generator
  return generateCategoryPhases(effectiveDomain, effectiveCoDomain, category);
}

// ============================================================================
// Stream Progress Engine: Computes Co-Domains Completed and Total Phases
// ============================================================================
export function computeStreamProgressStats(
  streamName: string,
  availableCoDomains: Array<{ id: string; name: string; domain?: string; category: string }>,
  generatorFn: (name: string, stream: string) => any
): StreamProgressStats {
  let savedTasks: Set<string> = new Set();
  try {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('employai_completed_tasks');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) savedTasks = new Set(parsed);
      }
    }
  } catch {}

  const coDomainMap: Record<string, CoDomainProgressItem> = {};
  let totalPhases = 0;
  let completedPhases = 0;
  let completedCoDomains = 0;

  (availableCoDomains || []).forEach(item => {
    const r = generatorFn(item.name, streamName);
    let itemCompletedPhases = 0;
    let itemTotalTasks = 0;
    let itemCompletedTasks = 0;
    let itemTotalVideos = 0;
    let itemWatchedVideos = 0;

    (r.milestones || []).forEach((milestone: any) => {
      let pTasksTotal = (milestone.tasks || []).length;
      let pTasksCompleted = 0;
      (milestone.tasks || []).forEach((t: any) => {
        itemTotalTasks++;
        if (savedTasks.has(t.id) || t.is_completed) {
          itemCompletedTasks++;
          pTasksCompleted++;
        }
      });

      let pVideosTotal = (milestone.youtube_resources || []).length;
      let pVideosWatched = 0;
      (milestone.youtube_resources || []).forEach((v: any) => {
        itemTotalVideos++;
        try {
          if (typeof window !== 'undefined' && localStorage.getItem(`yt_watched_${v.id}`) === 'true') {
            itemWatchedVideos++;
            pVideosWatched++;
          }
        } catch {}
      });

      const tasksDone = pTasksTotal > 0 ? pTasksCompleted === pTasksTotal : true;
      const videosDone = pVideosTotal > 0 ? pVideosWatched === pVideosTotal : true;
      if (tasksDone && videosDone && (pTasksTotal > 0 || pVideosTotal > 0)) {
        itemCompletedPhases++;
      }
    });

    const totalTrackable = itemTotalTasks + itemTotalVideos;
    const completedTrackable = itemCompletedTasks + itemWatchedVideos;
    const pct = totalTrackable > 0 ? Math.min(100, Math.round((completedTrackable / totalTrackable) * 100)) : 0;
    const isComp = itemCompletedPhases === (r.milestones || []).length && (r.milestones || []).length > 0;

    if (isComp) completedCoDomains++;
    completedPhases += itemCompletedPhases;
    totalPhases += (r.milestones || []).length;

    coDomainMap[item.name] = {
      id: item.id,
      name: item.name,
      category: item.category,
      completedPhasesCount: itemCompletedPhases,
      totalPhasesCount: (r.milestones || []).length,
      completionPct: pct,
      isCompleted: isComp
    };
  });

  const streamPct = totalPhases > 0 ? Math.min(100, Math.round((completedPhases / totalPhases) * 100)) : 0;

  return {
    streamName,
    totalCoDomainsCount: (availableCoDomains || []).length,
    completedCoDomainsCount: completedCoDomains,
    totalPhasesCount: totalPhases,
    completedPhasesCount: completedPhases,
    streamCompletionPct: streamPct,
    coDomainMap
  };
}
