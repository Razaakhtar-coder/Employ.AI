import React, { useState, useEffect, useMemo, useRef } from 'react';
import { documentApi, profileApi, getUserScopedStorageKey } from '../services/api';
import { useAuth } from '../context/AuthContext';
import type { StudentProfile, ResumeAnalysisResult, LearningPlatformResource, SavedResumeItem } from '../types';
import { DOMAIN_CO_DOMAINS, type CoDomainDefinition, resolvePhaseLearningPlatforms } from '../utils/domainRoadmapData';
import { 
  CheckCircle2, AlertCircle, 
  Compass, Award,
  Sparkles, Target, FileText, Search, Filter,
  Check, Zap, ExternalLink,
  BookOpen, Copy, Code2,
  TrendingUp, DollarSign, Building2, ShieldAlert
} from 'lucide-react';

interface RoleMatchingViewProps {
  onNavigateToRoadmap?: (roleTitleOrId?: string, domain?: string) => void;
  onNavigateToResume?: () => void;
}

// Comprehensive Canonical Synonym Mapping for Deterministic Matching
const CANONICAL_SYNONYMS: Record<string, Set<string>> = {
  'python': new Set(['python', 'python3', 'py']),
  'react': new Set(['react', 'react.js', 'reactjs', 'react-native']),
  'next.js': new Set(['next.js', 'nextjs', 'next']),
  'node.js': new Set(['node', 'node.js', 'nodejs']),
  'typescript': new Set(['typescript', 'ts']),
  'javascript': new Set(['javascript', 'js', 'ecmascript']),
  'fastapi': new Set(['fastapi', 'fast-api']),
  'django': new Set(['django', 'django rest framework', 'drf']),
  'flask': new Set(['flask']),
  'java': new Set(['java', 'core java']),
  'c++': new Set(['c++', 'cpp']),
  'c#': new Set(['c#', 'csharp', '.net', 'dotnet']),
  'postgresql': new Set(['postgresql', 'postgres', 'psql']),
  'mysql': new Set(['mysql']),
  'mongodb': new Set(['mongodb', 'mongo']),
  'redis': new Set(['redis']),
  'sql': new Set(['sql', 'rdbms', 'relational database']),
  'docker': new Set(['docker', 'dockerfile', 'containerization']),
  'kubernetes': new Set(['kubernetes', 'k8s']),
  'aws': new Set(['aws', 'amazon web services']),
  'azure': new Set(['azure', 'microsoft azure']),
  'gcp': new Set(['gcp', 'google cloud', 'google cloud platform']),
  'git': new Set(['git', 'github', 'gitlab']),
  'ci/cd': new Set(['ci/cd', 'cicd', 'continuous integration', 'github actions', 'jenkins']),
  'rest apis': new Set(['rest api', 'rest apis', 'restful api', 'rest', 'api development']),
  'graphql': new Set(['graphql', 'apollo']),
  'data structures': new Set(['data structures', 'algorithms', 'dsa', 'data structures & algorithms', 'data structures and algorithms']),
  'algorithms': new Set(['data structures', 'algorithms', 'dsa', 'data structures & algorithms', 'data structures and algorithms']),
  'machine learning': new Set(['machine learning', 'ml', 'scikit-learn']),
  'deep learning': new Set(['deep learning', 'dl', 'neural networks', 'pytorch', 'tensorflow']),
  'power bi': new Set(['power bi', 'powerbi', 'power-bi', 'dax']),
  'tableau': new Set(['tableau']),
  'excel': new Set(['excel', 'advanced excel', 'ms excel', 'spreadsheets', 'pivot tables', 'xlookup']),
  'financial modeling': new Set(['financial modeling', 'financial modelling', 'dcf', '3-statement modeling']),
  'financial accounting': new Set(['financial accounting', 'accounting', 'ind as', 'ifrs', 'general ledger', 'bookkeeping']),
  'auditing': new Set(['auditing', 'statutory audit', 'caro', 'internal audit']),
  'taxation': new Set(['taxation', 'gst', 'gst return', 'gstr', 'income tax', 'tds']),
  'tallyprime': new Set(['tally', 'tallyprime', 'tally erp', 'tally erp 9']),
  'sap fico': new Set(['sap fico', 'sap']),
  'solidworks': new Set(['solidworks', 'solid works', 'parametric cad']),
  'autocad': new Set(['autocad', 'cad']),
  'ansys': new Set(['ansys', 'fea', 'finite element analysis', 'ansys fluent', 'cfd']),
  'staad.pro': new Set(['staad.pro', 'staad', 'structural analysis']),
  'revit': new Set(['revit', 'autodesk revit', 'bim']),
  'rcc design': new Set(['rcc design', 'reinforced concrete', 'is 456', 'concrete design']),
  'geotechnical engineering': new Set(['geotechnical', 'soil mechanics', 'foundation design']),
  'quantity surveying': new Set(['quantity surveying', 'boq', 'bill of quantities', 'cost estimation']),
  'embedded c': new Set(['embedded c', 'bare-metal c', 'arm cortex', 'firmware']),
  'vlsi': new Set(['vlsi', 'verilog', 'rtl design', 'digital circuit design', 'fpga']),
  'pcb design': new Set(['altium', 'pcb design', 'schematic capture', 'gerber']),
  'matlab': new Set(['matlab', 'simulink']),
  'contract drafting': new Set(['contract drafting', 'commercial contracts', 'ndas', 'msas', 'legal drafting']),
  'corporate law': new Set(['corporate law', 'companies act', 'corporate governance']),
  'clinical diagnostics': new Set(['clinical diagnostics', 'physical examination', 'differential diagnosis', 'patient examination']),
  'patient care': new Set(['patient care', 'bedside nursing', 'patient care plans', 'vital signs']),
  'emergency medicine': new Set(['emergency medicine', 'trauma care', 'atls', 'triage']),
  'bls / acls': new Set(['bls', 'acls', 'cpr', 'life support', 'defibrillation']),
  'ros 2': new Set(['ros 2', 'ros', 'robot operating system']),
  'crispr': new Set(['crispr', 'crispr-cas9', 'genetic engineering', 'recombinant dna'])
};

// Strict Disciplinary Domain Affinity Clusters
const DOMAIN_CLUSTERS: Record<string, Set<string>> = {
  'Computer Science': new Set(['computer science', 'software', 'information technology', 'cs', 'it', 'web', 'backend', 'frontend', 'cloud', 'devops', 'ai/ml', 'data science']),
  'MBBS': new Set(['mbbs', 'medicine', 'clinical', 'medical', 'physician', 'doctor', 'surgery', 'pathology', 'radiology']),
  'Nursing': new Set(['nursing', 'clinical nursing', 'patient care', 'staff nurse']),
  'Business Analytics': new Set(['business analytics', 'data analytics', 'bi', 'business intelligence', 'data science']),
  'BCOM': new Set(['bcom', 'b.com', 'commerce', 'finance', 'accounting', 'taxation', 'audit', 'chartered accountancy']),
  'BBA': new Set(['bba', 'management', 'mba', 'business administration', 'marketing', 'human resources', 'operations']),
  'BA LLB': new Set(['ba llb', 'law', 'legal', 'corporate law', 'litigation', 'llb']),
  'Aviation': new Set(['aviation', 'pilot', 'commercial pilot', 'flight operations']),
  'Aeronautical': new Set(['aeronautical', 'aerospace', 'propulsion', 'aerodynamics']),
  'Cabin Crew': new Set(['cabin crew', 'in-flight services', 'aviation hospitality', 'flight attendant']),
  'Robotics': new Set(['robotics', 'mechatronics', 'autonomous systems']),
  'Biotechnology': new Set(['biotechnology', 'biotech', 'genomics', 'bioinformatics', 'biopharma']),
  'Marine': new Set(['marine', 'marine engineering', 'naval architecture', 'merchant navy']),
  'Mechanical': new Set(['mechanical', 'mechanical engineering', 'manufacturing', 'cad/cam', 'automotive']),
  'Civil': new Set(['civil', 'civil engineering', 'structural engineering', 'construction']),
  'Electrical': new Set(['electrical', 'electrical engineering', 'electronics', 'vlsi', 'embedded systems', 'power electronics']),
  'Chemical': new Set(['chemical', 'chemical engineering', 'process engineering', 'petrochemical']),
  'BA Hons': new Set(['ba hons', 'humanities', 'public policy', 'social sciences', 'economics'])
};

// Explicit Co-Domain Benchmark Specifications
const CO_DOMAIN_BENCHMARK_SKILLS: Record<string, { required: string[]; preferred: string[] }> = {
  // Computer Science
  'React & Next.js UI Architecture': {
    required: ['React', 'Next.js', 'JavaScript', 'TypeScript', 'HTML & CSS'],
    preferred: ['Redux', 'TailwindCSS', 'Web Performance', 'Server Components']
  },
  'FastAPI & Async Microservices': {
    required: ['Python', 'FastAPI', 'REST APIs', 'Asyncio', 'Pydantic'],
    preferred: ['Docker', 'PostgreSQL', 'Dependency Injection', 'OpenAPI']
  },
  'Node.js & Express API Engines': {
    required: ['Node.js', 'Express', 'JavaScript', 'TypeScript', 'REST APIs'],
    preferred: ['JWT Auth', 'MongoDB', 'Event Loop', 'Middleware']
  },
  'Docker & Container Orchestration': {
    required: ['Docker', 'Containerization', 'Docker Compose', 'Linux'],
    preferred: ['Kubernetes', 'CI/CD Pipelines', 'Multi-Stage Builds']
  },
  'SQL & Relational DB Modeling': {
    required: ['SQL', 'PostgreSQL', 'Database Design', 'Schema Normalization'],
    preferred: ['Query Optimization', 'Index Tuning', 'ACID Transactions']
  },
  'Data Structures & Algorithms (DSA)': {
    required: ['Data Structures', 'Algorithms', 'Dynamic Programming', 'Graph Algorithms'],
    preferred: ['Big-O Analysis', 'Trees & Heaps', 'System Design']
  },
  'Cloud Computing (AWS / GCP)': {
    required: ['Cloud Computing', 'AWS', 'IAM Security', 'EC2 / S3'],
    preferred: ['Serverless Lambda', 'CloudFront CDN', 'GCP']
  },
  'Applied Machine Learning & LLM Integration': {
    required: ['Machine Learning', 'Python', 'LLM Integration', 'PyTorch / TensorFlow'],
    preferred: ['RAG Pipelines', 'Vector Databases', 'LangChain']
  },
  'System Design & Distributed Systems': {
    required: ['System Design', 'Distributed Systems', 'Load Balancing', 'Caching'],
    preferred: ['Redis', 'Database Sharding', 'Microservices Architecture']
  },
  'Redis Caching & Message Queues': {
    required: ['Redis', 'Caching', 'In-Memory Data Structures'],
    preferred: ['Pub/Sub Messaging', 'Rate Limiting', 'Cache-Aside']
  },
  'DevOps & CI/CD Pipelines': {
    required: ['CI/CD', 'GitHub Actions', 'DevOps', 'Git'],
    preferred: ['Automated Testing', 'Docker', 'Release Management']
  },
  'Cybersecurity & OAuth2 / JWT': {
    required: ['Cybersecurity', 'OAuth2', 'JWT', 'Security & Cryptography'],
    preferred: ['OWASP Mitigation', 'Zero-Trust', 'Token Rotation']
  },
  'TypeScript & Type Safety': {
    required: ['TypeScript', 'JavaScript', 'Type Safety'],
    preferred: ['Generics', 'Utility Types', 'Runtime Validation']
  },
  'Python Backend & Async Programming': {
    required: ['Python', 'Backend Development', 'OOP & Data Structures'],
    preferred: ['Asyncio', 'Pytest', 'Type Hints']
  },
  'GraphQL & Apollo Federation': {
    required: ['GraphQL', 'API Development', 'Schema Design'],
    preferred: ['Apollo Federation', 'DataLoader', 'Mutations']
  },
  'NoSQL Databases (MongoDB / DynamoDB)': {
    required: ['NoSQL', 'MongoDB', 'Document Databases'],
    preferred: ['DynamoDB', 'Single-Table Design', 'Sharding']
  },
  'Event-Driven Architecture (Kafka / RabbitMQ)': {
    required: ['Kafka', 'Event-Driven Architecture', 'Message Queues'],
    preferred: ['RabbitMQ', 'Stream Processing', 'Idempotency']
  },
  'Test-Driven Development (TDD / Pytest / Vitest)': {
    required: ['TDD', 'Unit Testing', 'Pytest', 'Vitest'],
    preferred: ['Integration Testing', 'Mocking', 'Code Coverage']
  },

  // MBBS / Medicine
  'Clinical Diagnostics & Examination': {
    required: ['Clinical Diagnostics', 'Physical Examination', 'Differential Diagnosis', 'Patient History Taking'],
    preferred: ['Pathology', 'Internal Medicine', 'Clinical Examination']
  },
  'Radiology & Imaging Interpretation': {
    required: ['Radiology', 'X-Ray Interpretation', 'CT Scans', 'MRI Interpretation'],
    preferred: ['Ultrasonography', 'Nuclear Medicine']
  },
  'Laboratory Reports & Clinical Pathology': {
    required: ['Clinical Pathology', 'Blood Reports (CBC/ABG)', 'Biomarker Analysis'],
    preferred: ['Liver Panels', 'Renal Panels', 'Microbiology']
  },
  'Emergency Medicine & Trauma Care': {
    required: ['Emergency Medicine', 'Trauma Stabilization (ATLS)', 'Hypovolemic Shock Management'],
    preferred: ['Triage Protocols', 'Airway Management']
  },
  'Internal Medicine & Therapeutics': {
    required: ['Internal Medicine', 'Therapeutics & Pharmacology', 'Chronic Disease Management'],
    preferred: ['Cardiology', 'Pulmonology', 'Diabetes Care']
  },
  'Cardiology & 12-Lead ECG Analysis': {
    required: ['Cardiology', '12-Lead ECG Analysis', 'Arrhythmia Diagnostics'],
    preferred: ['STEMI/NSTEMI', 'Echocardiography']
  },
  'General Surgery & Minor OT Skills': {
    required: ['General Surgery', 'Aseptic Technique', 'Surgical Suturing', 'Minor OT Procedures'],
    preferred: ['Local Anesthesia', 'Abscess Drainage']
  },
  'Pharmacology & Prescription Writing': {
    required: ['Pharmacology', 'Prescription Writing', 'Antibiotic Stewardship'],
    preferred: ['Drug Interactions', 'Pharmacokinetics']
  },
  'Pediatrics & Neonatal Resuscitation': {
    required: ['Pediatrics', 'Neonatal Resuscitation (NRP)', 'APGAR Scoring'],
    preferred: ['Developmental Milestones', 'Pediatric Dosage']
  },
  'Obstetrics & Gynecology (OB-GYN)': {
    required: ['Obstetrics', 'Gynecology', 'Antenatal Care', 'Labor Partograph'],
    preferred: ['Obstetric Emergencies', 'Postpartum Care']
  },
  'Critical Care & Hemodynamic Monitoring': {
    required: ['Critical Care', 'Hemodynamic Monitoring', 'Mechanical Ventilation'],
    preferred: ['Vasopressor Titration', 'Sepsis Bundles']
  },
  'Basic & Advanced Life Support (BLS / ACLS)': {
    required: ['BLS', 'ACLS', 'CPR & Defibrillation', 'Cardiac Arrest Algorithms'],
    preferred: ['Airway Management', 'Crash Cart Protocols']
  },
  'Medical Ethics & Medico-Legal Laws': {
    required: ['Medical Ethics', 'Medico-Legal Regulations', 'Informed Consent'],
    preferred: ['Patient Confidentiality', 'Clinical Negligence Law']
  },
  'Infectious Diseases & Infection Control': {
    required: ['Infectious Diseases', 'Infection Control', 'Antimicrobial Stewardship'],
    preferred: ['Nosocomial Prevention', 'Epidemiology']
  },

  // Nursing
  'Clinical Patient Care & Bedside Nursing': {
    required: ['Bedside Nursing', 'Patient Care Plans', 'Vital Signs Assessment', 'Catheterization'],
    preferred: ['IV Infusion Management', 'Fluid Balance Charts']
  },
  'ICU Hemodynamic & Ventilator Monitoring': {
    required: ['ICU Nursing', 'Hemodynamic Monitoring', 'Ventilator Patient Care'],
    preferred: ['Arterial Line Care', 'Vasoactive Infusions']
  },
  'Emergency Triage & Rapid Code Blue Response': {
    required: ['Emergency Triage', 'Code Blue Response', 'CPR / BLS Protocols'],
    preferred: ['Crash Cart Preparation', 'Rapid Response Team']
  },
  'Medication Administration & 5 Rights Protocol': {
    required: ['Medication Administration', '5 Rights of Medication', 'Dosage Calculations'],
    preferred: ['High-Alert Medications', 'IV Push Protocol']
  },
  'Aseptic Wound Care & Post-Operative Dressing': {
    required: ['Aseptic Wound Care', 'Post-Op Surgical Dressing', 'Sterile Techniques'],
    preferred: ['Drain Maintenance', 'Pressure Ulcer Staging']
  },

  // Civil Engineering
  'STAAD.Pro 3D Space Frame & Seismic Design': {
    required: ['STAAD.Pro', 'Structural Analysis', 'Seismic Design (IS 1893)', 'Space Frame Modeling'],
    preferred: ['Load Combinations', 'Steel Structure Design']
  },
  'Building Information Modeling (Autodesk Revit BIM)': {
    required: ['Autodesk Revit', 'BIM Modeling', '3D Architectural Drafting'],
    preferred: ['Clash Detection', '4D Construction Scheduling']
  },
  'Reinforced Concrete Design (IS 456 / ACI 318)': {
    required: ['RCC Design', 'IS 456 Standards', 'Limit State Design', 'Concrete Structures'],
    preferred: ['Column Sizing', 'Footing Foundations']
  },
  'Geotechnical Soil Mechanics & Foundations': {
    required: ['Geotechnical Engineering', 'Soil Mechanics', 'Foundation Design', 'Bearing Capacity'],
    preferred: ['Slope Stability', 'Soil Consolidation']
  },
  'Quantity Surveying, Estimation & BOQ': {
    required: ['Quantity Surveying', 'Bill of Quantities (BOQ)', 'Rate Analysis', 'Cost Estimation'],
    preferred: ['Tender Documentation', 'Material Reconciliation']
  },
  'Construction Project Scheduling (Primavera / MS Project)': {
    required: ['Construction Management', 'Primavera P6', 'MS Project', 'CPM Scheduling'],
    preferred: ['Resource Leveling', 'Earned Value Management']
  },

  // Mechanical Engineering
  '3D Parametric CAD Modeling (SolidWorks)': {
    required: ['SolidWorks', '3D CAD Modeling', 'Parametric Part Modeling', 'Assembly Design'],
    preferred: ['BOM Generation', 'Surface Modeling']
  },
  'GD&T (ASME Y14.5 Geometric Tolerancing)': {
    required: ['GD&T', 'ASME Y14.5', 'Feature Control Frames', 'Datum Reference Frames'],
    preferred: ['Tolerance Stack-Up', 'Runout & Position']
  },
  'Finite Element Analysis (ANSYS Structural FEA)': {
    required: ['ANSYS', 'Finite Element Analysis (FEA)', 'Structural Stress Analysis', 'Von Mises Criteria'],
    preferred: ['Modal Analysis', 'Thermal FEA']
  },
  'CNC Machining, G-Code & CAM Toolpaths': {
    required: ['CNC Machining', 'G-Code Programming', 'CAM Toolpaths (Mastercam)'],
    preferred: ['Spindle Feeds & Speeds', 'Tool Offsets']
  },
  'Thermodynamics & Heat Exchanger Design': {
    required: ['Thermodynamics', 'Heat Transfer', 'Heat Exchanger Design', 'LMTD Sizing'],
    preferred: ['Rankine Cycles', 'Fluid Mechanics']
  },
  'Design for Manufacturing & Assembly (DFMA)': {
    required: ['DFMA', 'Sheet Metal Design', 'Injection Molding Design', 'Fastener Optimization'],
    preferred: ['Manufacturing Processes', 'Prototyping']
  },

  // Electrical Engineering
  'Embedded C & ARM Cortex-M Firmware': {
    required: ['Embedded C', 'ARM Cortex-M', 'Microcontrollers', 'Bare-Metal Firmware'],
    preferred: ['UART / SPI / I2C', 'Timer Interrupts']
  },
  'VLSI Digital Design & Verilog RTL': {
    required: ['VLSI', 'Verilog', 'RTL Design', 'Digital Circuit Design'],
    preferred: ['FPGA Synthesis', 'Static Timing Analysis']
  },
  'High-Speed Multi-Layer PCB Design (Altium)': {
    required: ['Altium Designer', 'PCB Design', 'Schematic Capture', 'Multi-Layer Routing'],
    preferred: ['Impedance Control', 'Gerber Generation']
  },
  'Power Electronics & Motor Inverters': {
    required: ['Power Electronics', 'Motor Inverters', 'PWM Control', 'DC-DC Converters'],
    preferred: ['MOSFET / IGBT Drivers', 'Space Vector PWM']
  },
  'MATLAB Simulink Control Systems & Modeling': {
    required: ['MATLAB', 'Simulink', 'Control Systems', 'State-Space Modeling'],
    preferred: ['PID Controller Tuning', 'Bode Plots']
  },
  'EV Battery Management Systems (BMS)': {
    required: ['Battery Management Systems (BMS)', 'State of Charge (SoC)', 'EV Powertrain', 'Cell Balancing'],
    preferred: ['Thermal Management', 'CAN Bus']
  },

  // Business Analytics
  'Data Wrangling & ETL Pipelines': {
    required: ['Data Wrangling', 'Python', 'Pandas', 'ETL Pipelines'],
    preferred: ['NumPy', 'Data Cleaning', 'Regex Parsing']
  },
  'Advanced Excel & Financial Modeling': {
    required: ['Excel', 'Advanced Excel', 'Pivot Tables', 'XLOOKUP / Formulas'],
    preferred: ['Power Query', 'Financial Modeling', 'Dashboards']
  },
  'SQL & Relational Analytics': {
    required: ['SQL', 'Window Functions', 'Relational Databases', 'CTEs & Aggregations'],
    preferred: ['Database Views', 'Performance Tuning']
  },
  'Power BI & DAX Dashboards': {
    required: ['Power BI', 'DAX Measures', 'Dashboard Design', 'Data Modeling (Star Schema)'],
    preferred: ['Power Query', 'Row-Level Security']
  },
  'Tableau Visual Analytics & Storytelling': {
    required: ['Tableau', 'Visual Analytics', 'Calculated Fields', 'Interactive Dashboards'],
    preferred: ['LOD Expressions', 'Data Storytelling']
  },
  'Python for Data Analysis (Pandas/NumPy)': {
    required: ['Python', 'Pandas', 'NumPy', 'Exploratory Data Analysis'],
    preferred: ['Seaborn', 'Matplotlib', 'Statistics']
  },
  'Statistical Testing & A/B Experimentation': {
    required: ['Statistics', 'Hypothesis Testing', 'A/B Testing', 'p-values & Confidence Intervals'],
    preferred: ['Regression Analysis', 'ANOVA']
  },
  'Predictive Machine Learning Modeling': {
    required: ['Machine Learning', 'Scikit-Learn', 'Predictive Modeling', 'Regression & Classification'],
    preferred: ['Feature Engineering', 'Model Evaluation']
  },
  'Financial KPI Analysis & Unit Economics': {
    required: ['KPI Dashboards', 'Unit Economics', 'CAC & LTV Analysis', 'Business Metrics'],
    preferred: ['Cohort Analysis', 'Forecasting']
  },
  'Business Requirements Gathering (BRD/FRD)': {
    required: ['BRD / FRD', 'Requirements Gathering', 'User Stories', 'Stakeholder Analysis'],
    preferred: ['Acceptance Criteria', 'Agile / Scrum']
  },

  // Commerce / BCOM
  'Financial Accounting & Ind AS / IFRS': {
    required: ['Financial Accounting', 'Ind AS / IFRS', 'Balance Sheet Preparation', 'General Ledger'],
    preferred: ['Double-Entry Bookkeeping', 'Trial Balance']
  },
  'Taxation & GST Return Filing (GSTR 1/3B/9)': {
    required: ['Taxation', 'GST Compliance', 'GSTR 1 & 3B Filing', 'Input Tax Credit (ITC)'],
    preferred: ['TDS / TCS', 'Direct Taxation']
  },
  'Statutory Auditing & Internal Assurance': {
    required: ['Auditing', 'Statutory Audit', 'CARO Compliance', 'Internal Financial Controls'],
    preferred: ['Substantive Testing', 'Vouching']
  },
  'TallyPrime & SAP ERP Financials': {
    required: ['TallyPrime', 'Accounting Software', 'Voucher Entry', 'Ledger Reconciliation'],
    preferred: ['SAP FICO', 'Inventory Ledger']
  },
  '3-Statement Financial Modeling in Excel': {
    required: ['Financial Modeling', '3-Statement Modeling', 'Excel', 'Cash Flow Forecasting'],
    preferred: ['Debt Schedules', 'Scenario Analysis']
  },
  'Corporate Finance & Valuation (DCF / WACC)': {
    required: ['Corporate Finance', 'Valuation', 'DCF Modeling', 'WACC & Capital Budgeting'],
    preferred: ['NPV / IRR', 'M&A Valuation']
  },
  'Cost & Management Accounting': {
    required: ['Cost Accounting', 'Marginal Costing', 'Variance Analysis', 'Standard Costing'],
    preferred: ['Break-Even Analysis', 'Budgeting']
  },

  // Law / BA LLB
  'Commercial Contract Drafting & Redlining': {
    required: ['Contract Drafting', 'Commercial Law', 'NDAs & MSAs', 'Contract Review & Redlining'],
    preferred: ['Indemnity Clauses', 'Dispute Resolution']
  },
  'Corporate Governance & Companies Act': {
    required: ['Corporate Law', 'Companies Act 2013', 'Corporate Governance', 'Board Compliance'],
    preferred: ['Shareholder Agreements (SHA)', 'SEBI Compliance']
  },
  'Civil Litigation & Court Pleadings': {
    required: ['Civil Litigation', 'Court Pleadings', 'CPC Procedure', 'Plaints & Written Statements'],
    preferred: ['Interim Applications', 'Execution Petitions']
  },
  'Criminal Law & Bharatiya Nyaya Sanhita (BNS)': {
    required: ['Criminal Law', 'Bharatiya Nyaya Sanhita (BNS)', 'Bail Applications', 'Criminal Procedure'],
    preferred: ['Evidentiary Burden', 'Trial Advocacy']
  },
  'Intellectual Property (IPR & Patents)': {
    required: ['IPR', 'Trademark Filing', 'Copyright Law', 'Patent Prosecution'],
    preferred: ['Trade Secrets', 'IP Infringement']
  },
  'Data Privacy Law (DPDP Act & GDPR)': {
    required: ['Data Privacy Law', 'DPDP Act', 'GDPR Compliance', 'Data Protection'],
    preferred: ['Consent Frameworks', 'Privacy Impact Assessments']
  },

  // Aviation
  'Instrument Flight Rules (IFR) & Chart Navigation': {
    required: ['IFR Navigation', 'Jeppesen Charts', 'ILS / VOR Intercept', 'Flight Navigation'],
    preferred: ['SID / STAR Procedures', 'Approach Plates']
  },
  'Flight Management Systems (FMS / MCDU)': {
    required: ['Flight Management Systems (FMS)', 'MCDU Operation', 'Route Waypoint Entry'],
    preferred: ['PERF INIT Calculations', 'Cost Index']
  },
  'Aviation Meteorology & Severe Weather Hazards': {
    required: ['Aviation Meteorology', 'METAR / TAF Decoding', 'Severe Weather Avoidance'],
    preferred: ['Turbulence Avoidance', 'Microburst Recognition']
  },

  // Aeronautical
  'Aerodynamics & Airfoil Lift-Drag Polars': {
    required: ['Aerodynamics', 'Airfoil Lift & Drag', 'Subsonic Flow', 'Boundary Layer Theory'],
    preferred: ['NACA Polars', 'Compressible Flow']
  },
  'CFD Airflow Simulation (ANSYS Fluent)': {
    required: ['CFD Simulation', 'ANSYS Fluent', 'Fluid Dynamics', 'Mesh Generation'],
    preferred: ['Turbulence Modeling', 'Navier-Stokes']
  },
  'Gas Turbine Propulsion & Jet Engines': {
    required: ['Gas Turbine Engines', 'Jet Propulsion', 'Thermodynamic Brayton Cycle'],
    preferred: ['Turbofan Bypass', 'Combustor Design']
  },

  // Robotics
  'ROS 2 (Robot Operating System) Core Architecture': {
    required: ['ROS 2', 'Robotics Software', 'Nodes & Topics', 'C++ / Python for Robotics'],
    preferred: ['DDS Middleware', 'Launch Files']
  },
  'Robot Kinematics & Inverse Kinematics': {
    required: ['Robot Kinematics', 'Inverse Kinematics', 'DH Parameters', 'Trajectory Planning'],
    preferred: ['Jacobian Matrices', 'Robotic Manipulators']
  },
  'Autonomous Navigation & LiDAR SLAM': {
    required: ['LiDAR SLAM', 'Autonomous Navigation', 'Nav2 Stack', 'Point Cloud Processing'],
    preferred: ['Costmaps', 'AMCL Localization']
  },
  'Industrial PLC Programming & Ladder Logic': {
    required: ['PLC Programming', 'Ladder Logic', 'Siemens TIA Portal', 'Industrial Automation'],
    preferred: ['Sensors & Actuators', 'SCADA']
  },

  // Biotechnology
  'Genetic Engineering & CRISPR-Cas9 Protocols': {
    required: ['Genetic Engineering', 'CRISPR-Cas9', 'Recombinant DNA', 'Molecular Biology'],
    preferred: ['Plasmid Vectors', 'Guide RNA Design']
  },
  'Bioreactor Fermentation & Process Parameters': {
    required: ['Bioreactor Fermentation', 'Bioprocessing', 'Dissolved Oxygen & pH Control'],
    preferred: ['Batch & Fed-Batch Kinetics', 'Sterility Protocols']
  },
  'Protein Purification & Chromatography (HPLC/FPLC)': {
    required: ['Protein Purification', 'HPLC / FPLC', 'Chromatography', 'SDS-PAGE Analysis'],
    preferred: ['Size Exclusion', 'Affinity Chromatography']
  },
  'Bio-Informatics Python & Sequence Alignment': {
    required: ['Bioinformatics', 'BioPython', 'BLAST Search', 'Sequence Alignment'],
    preferred: ['NGS Analysis', 'NCBI Databases']
  }
};

/**
 * Checks if a required skill is genuinely matched by candidate resume skills.
 * Strictly prevents false substring positives like single letters ('c', 'r') or generic words.
 */
function checkSkillMatch(targetSkill: string, candidateSkills: Set<string>): boolean {
  const tClean = targetSkill.trim().toLowerCase();
  if (!tClean) return false;

  // 1. Exact match
  if (candidateSkills.has(tClean)) return true;

  // 2. Canonical synonyms match
  const tSyns = CANONICAL_SYNONYMS[tClean] || new Set([tClean]);
  for (const cs of candidateSkills) {
    const csClean = cs.trim().toLowerCase();
    if (tSyns.has(csClean)) return true;
    const csSyns = CANONICAL_SYNONYMS[csClean];
    if (csSyns) {
      for (const item of csSyns) {
        if (tSyns.has(item) || item === tClean) return true;
      }
    }
  }

  // 3. Multi-word phrase token boundary match (Only for multi-word phrases with length >= 4)
  if (tClean.length >= 4 && tClean.includes(' ')) {
    for (const cs of candidateSkills) {
      const csClean = cs.trim().toLowerCase();
      if (csClean.includes(tClean) || tClean.includes(csClean)) {
        if (csClean.length >= 4) return true;
      }
    }
  }

  return false;
}

/**
 * Computes honest domain affinity between candidate's specialization and target domain.
 * Completely incompatible domains (e.g. CS vs MBBS/Nursing/Civil/Law) evaluate to 0%.
 */
function calculateDomainAffinity(candidateDomain: string, targetDomain: string): number {
  const cLow = candidateDomain.trim().toLowerCase();
  const tLow = targetDomain.trim().toLowerCase();

  if (!cLow || !tLow) return 0;

  // 1. Direct or identical domain match
  if (cLow === tLow || cLow.includes(tLow) || tLow.includes(cLow)) {
    return 100;
  }

  // 2. Check cluster alignment
  for (const [_clusterKey, aliases] of Object.entries(DOMAIN_CLUSTERS)) {
    const cMatches = Array.from(aliases).some(a => cLow.includes(a) || a.includes(cLow));
    const tMatches = Array.from(aliases).some(a => tLow.includes(a) || a.includes(tLow));
    if (cMatches && tMatches) {
      return 100;
    }
  }

  // 3. Valid adjacent/cross-disciplinary domains
  const techDataDomains = ['computer science', 'business analytics', 'robotics'];
  const isCandidateTech = techDataDomains.some(d => cLow.includes(d));
  const isTargetTech = techDataDomains.some(d => tLow.includes(d));
  if (isCandidateTech && isTargetTech) {
    return 70;
  }

  const businessDomains = ['bcom', 'bba', 'business analytics', 'finance', 'commerce', 'management'];
  const isCandidateBiz = businessDomains.some(d => cLow.includes(d));
  const isTargetBiz = businessDomains.some(d => tLow.includes(d));
  if (isCandidateBiz && isTargetBiz) {
    return 75;
  }

  const engDomains = ['mechanical', 'aeronautical', 'robotics', 'electrical'];
  const isCandidateEng = engDomains.some(d => cLow.includes(d));
  const isTargetEng = engDomains.some(d => tLow.includes(d));
  if (isCandidateEng && isTargetEng) {
    return 65;
  }

  const healthDomains = ['mbbs', 'nursing', 'medicine', 'healthcare'];
  const isCandidateHealth = healthDomains.some(d => cLow.includes(d));
  const isTargetHealth = healthDomains.some(d => tLow.includes(d));
  if (isCandidateHealth && isTargetHealth) {
    return 50;
  }

  // 4. Completely disparate domains (e.g. CS vs MBBS, CS vs Civil, CS vs Law, Civil vs MBBS, Mechanical vs Nursing)
  return 0;
}

const RoleMatchingViewComponent: React.FC<RoleMatchingViewProps> = ({ onNavigateToRoadmap, onNavigateToResume }) => {
  const { isAuthenticated, user } = useAuth();
  
  // Data State - Lazy initialized with user-scoped cache to prevent empty flash and layout shift
  const [latestResume, setLatestResume] = useState<ResumeAnalysisResult | null>(() => {
    try {
      const key = getUserScopedStorageKey('employai_active_resume_analysis');
      const saved = localStorage.getItem(key) || localStorage.getItem('employai_active_resume_analysis');
      if (saved) return JSON.parse(saved);
    } catch {}
    return null;
  });
  const [studentProfile, setStudentProfile] = useState<StudentProfile | null>(null);
  const [savedResumesList, setSavedResumesList] = useState<SavedResumeItem[]>([]);
  const [selectedResumeId, setSelectedResumeId] = useState<string>('latest');
  const [isLoadingResume, setIsLoadingResume] = useState<boolean>(false);
  
  // Selection State - Preserved from localStorage with rock-solid defaults just like RoadmapView
  const [activeDomainFilter, setActiveDomainFilter] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('employai_matching_domain');
      if (saved && DOMAIN_CO_DOMAINS[saved]) return saved;
      const roadmapSaved = localStorage.getItem('employai_roadmap_stream');
      if (roadmapSaved && DOMAIN_CO_DOMAINS[roadmapSaved]) return roadmapSaved;
    } catch {}
    return 'Computer Science';
  });
  const [selectedCoDomainName, setSelectedCoDomainName] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('employai_matching_codomain');
      if (saved) return saved;
      const roadmapSaved = localStorage.getItem('employai_roadmap_codomain');
      if (roadmapSaved) return roadmapSaved;
    } catch {}
    return 'React & Next.js UI Architecture';
  });
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Evaluation & UI State
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const hasInitializedRef = useRef<boolean>(false);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  const handleCopyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    showToast(`Copied ${label} to clipboard!`);
    setTimeout(() => setCopiedText(null), 2500);
  };

  // Switch Selected Co-Domain with zero scroll jump or layout shift (Identical to RoadmapView)
  const handleSelectCoDomain = (coDomainName: string, domainName: string, e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }

    const contentArea = document.querySelector('.content-area') as HTMLElement | null;
    const currentScrollTop = contentArea ? contentArea.scrollTop : window.scrollY;

    setSelectedCoDomainName(coDomainName);
    setActiveDomainFilter(domainName);
    try {
      localStorage.setItem('employai_matching_codomain', coDomainName);
      localStorage.setItem('employai_matching_domain', domainName);
    } catch {}

    requestAnimationFrame(() => {
      if (contentArea) {
        contentArea.scrollTop = currentScrollTop;
      } else {
        window.scrollTo(0, currentScrollTop);
      }
    });
  };

  // Real-time synchronization when resume is updated or uploaded in Studio
  useEffect(() => {
    const handleResumeUpdate = (e: any) => {
      if (e?.detail) {
        setLatestResume(e.detail);
      } else if (e?.detail === null) {
        setLatestResume(null);
      }
    };
    window.addEventListener('employai:resume-updated', handleResumeUpdate);
    return () => {
      window.removeEventListener('employai:resume-updated', handleResumeUpdate);
    };
  }, []);

  // 1. Load Initial Data once on mount without overwriting user selections
  useEffect(() => {
    async function loadInitialData() {
      if (hasInitializedRef.current) return;
      hasInitializedRef.current = true;

      try {
        const [resumeData, profileData, savedResumes] = await Promise.all([
          documentApi.getLatestAnalysis().catch(() => null),
          isAuthenticated ? profileApi.getStudentMe().catch(() => null) : Promise.resolve(null),
          documentApi.listMyResumes().catch(() => [])
        ]);

        if (resumeData) setLatestResume(resumeData);
        if (profileData) setStudentProfile(profileData);
        setSavedResumesList(savedResumes || []);

        // Only auto-detect if the user hasn't already saved or selected a custom domain
        const savedDomain = localStorage.getItem('employai_matching_domain');
        if (!savedDomain) {
          const resumeDomain = resumeData?.detected_domain || profileData?.department || '';
          if (resumeDomain) {
            const matchedDomainKey = Object.keys(DOMAIN_CO_DOMAINS).find(k => 
              k.toLowerCase() === resumeDomain.toLowerCase() || 
              resumeDomain.toLowerCase().includes(k.toLowerCase()) || 
              k.toLowerCase().includes(resumeDomain.toLowerCase())
            );
            if (matchedDomainKey) {
              setActiveDomainFilter(matchedDomainKey);
              const firstCo = DOMAIN_CO_DOMAINS[matchedDomainKey]?.[0]?.name;
              if (firstCo) setSelectedCoDomainName(firstCo);
            }
          }
        }
      } catch (err: any) {
        setError(err?.message || 'Failed to load matching data');
      }
    }

    loadInitialData();
  }, [isAuthenticated]);

  // Handle Switching Between Different Saved Resumes
  const handleSelectResume = async (resumeId: string) => {
    setSelectedResumeId(resumeId);
    if (resumeId === 'latest') {
      try {
        setIsLoadingResume(true);
        const data = await documentApi.getLatestAnalysis();
        setLatestResume(data);
        showToast('Switched to active resume analysis');
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoadingResume(false);
      }
    } else {
      try {
        setIsLoadingResume(true);
        const data = await documentApi.openResume(resumeId);
        setLatestResume(data);
        showToast('Loaded selected resume analysis');
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoadingResume(false);
      }
    }
  };

  // Extract Candidate Resume Profile Info & Genuine Skills
  const candidateInfo = useMemo(() => {
    const p = latestResume?.structured_resume?.personal_info || {};
    const name = p.full_name || user?.full_name || 'Candidate';
    const headline = p.headline || p.title || latestResume?.structured_resume?.headline || 'Verified Candidate Profile';
    const domain = latestResume?.detected_domain || studentProfile?.department || 'Computer Science';
    
    // Consolidate all extracted skills across structured resume, extracted_skills array, projects, and profile
    const skillsSet = new Set<string>();

    if (latestResume?.extracted_skills && Array.isArray(latestResume.extracted_skills)) {
      latestResume.extracted_skills.forEach(s => {
        if (typeof s === 'string' && s.trim()) skillsSet.add(s.trim());
      });
    }

    const structSkills = latestResume?.structured_resume?.skills;
    if (Array.isArray(structSkills)) {
      structSkills.forEach(s => {
        if (typeof s === 'string' && s.trim()) skillsSet.add(s.trim());
        else if (typeof s === 'object' && s && (s as any).name) skillsSet.add(String((s as any).name).trim());
      });
    } else if (structSkills && typeof structSkills === 'object') {
      Object.values(structSkills).forEach(categoryList => {
        if (Array.isArray(categoryList)) {
          categoryList.forEach(s => {
            if (typeof s === 'string' && s.trim()) skillsSet.add(s.trim());
          });
        }
      });
    }

    // Include project keywords/technologies if available
    const projects = latestResume?.structured_resume?.projects;
    if (Array.isArray(projects)) {
      projects.forEach(proj => {
        if (proj.technologies && Array.isArray(proj.technologies)) {
          proj.technologies.forEach(t => {
            if (typeof t === 'string' && t.trim()) skillsSet.add(t.trim());
          });
        }
      });
    }

    if (studentProfile?.skills && Array.isArray(studentProfile.skills)) {
      studentProfile.skills.forEach(s => {
        if (s.skill_name && s.skill_name.trim()) skillsSet.add(s.skill_name.trim());
      });
    }

    const skillsList = Array.from(skillsSet);
    const hasResume = !!latestResume;

    return { name, headline, domain, skillsList, hasResume };
  }, [latestResume, studentProfile, user]);

  // Candidate Skill Names Set for Normalized Evaluation
  const candidateSkillNamesSet = useMemo(() => {
    const set = new Set<string>();
    candidateInfo.skillsList.forEach(s => set.add(s.toLowerCase().trim()));
    return set;
  }, [candidateInfo]);

  // Available Co-Domains for Active Stream
  const availableCoDomains = useMemo(() => {
    const list = DOMAIN_CO_DOMAINS[activeDomainFilter] || [];
    if (!searchQuery.trim()) return list;
    return list.filter(item => 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.short_description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [activeDomainFilter, searchQuery]);

  // Active Target Co-Domain Object
  const currentCoDomainDef: CoDomainDefinition = useMemo(() => {
    const domainList = DOMAIN_CO_DOMAINS[activeDomainFilter] || [];
    const found = domainList.find(c => c.name === selectedCoDomainName);
    if (found) return found;

    for (const d of Object.keys(DOMAIN_CO_DOMAINS)) {
      const f = DOMAIN_CO_DOMAINS[d].find(c => c.name === selectedCoDomainName);
      if (f) return f;
    }

    return domainList[0] || {
      id: 'default-co',
      name: selectedCoDomainName || 'Advanced Industry Specialization',
      domain: activeDomainFilter,
      category: 'Core Competency',
      short_description: 'High-impact industry specialization with verified placement benchmark standards.',
      difficulty: 'Intermediate'
    };
  }, [activeDomainFilter, selectedCoDomainName]);

  // Current Target Title & Domain
  const activeTargetTitle = currentCoDomainDef.name;
  const activeTargetDomain = currentCoDomainDef.domain;

  // Deep Explainable Mathematical Evaluation
  const evaluation = useMemo(() => {
    const hasResume = candidateInfo.hasResume && candidateSkillNamesSet.size > 0;

    if (!hasResume) {
      return {
        overallMatchPct: 0,
        reqCoveragePct: 0,
        prefCoveragePct: 0,
        domainAffinity: 0,
        projectRelevance: 0,
        matchedRequiredCount: 0,
        totalRequiredCount: 0,
        matchedPreferredCount: 0,
        totalPreferredCount: 0,
        matched: [],
        missing: [],
        summary: 'No active resume credentials detected. Upload or create a resume to generate your authentic explainable match metrics.',
        strengths: 'No verified capabilities identified yet.',
        gapSummary: 'Connect your resume to analyze technical benchmarks and compute match compatibility.'
      };
    }

    // 1. Resolve benchmark specifications for this co-domain
    const benchmarkSpec = CO_DOMAIN_BENCHMARK_SKILLS[currentCoDomainDef.name] || {
      required: [currentCoDomainDef.name, currentCoDomainDef.category],
      preferred: [`${currentCoDomainDef.domain} Standards`]
    };

    const matched: { skill_name: string; is_required: boolean; proficiency: string }[] = [];
    const missing: { skill_name: string; is_required: boolean; importance: string; recommendation: string }[] = [];

    let reqMatchedCount = 0;
    let prefMatchedCount = 0;

    benchmarkSpec.required.forEach(sName => {
      if (checkSkillMatch(sName, candidateSkillNamesSet)) {
        reqMatchedCount++;
        matched.push({ skill_name: sName, is_required: true, proficiency: 'Verified in Resume' });
      } else {
        missing.push({
          skill_name: sName,
          is_required: true,
          importance: 'Critical Core',
          recommendation: `Acquire practical verified proficiency in ${sName} according to ${currentCoDomainDef.domain} benchmark standards.`
        });
      }
    });

    benchmarkSpec.preferred.forEach(sName => {
      if (checkSkillMatch(sName, candidateSkillNamesSet)) {
        prefMatchedCount++;
        matched.push({ skill_name: sName, is_required: false, proficiency: 'Verified in Resume' });
      } else {
        missing.push({
          skill_name: sName,
          is_required: false,
          importance: 'Preferred Bonus',
          recommendation: `Learn ${sName} as a competitive differentiator.`
        });
      }
    });

    const totalReq = benchmarkSpec.required.length || 1;
    const totalPref = benchmarkSpec.preferred.length || 1;
    const reqCoveragePct = Math.round((reqMatchedCount / totalReq) * 100);
    const prefCoveragePct = benchmarkSpec.preferred.length > 0 ? Math.round((prefMatchedCount / totalPref) * 100) : 100;
    const domainAffinity = calculateDomainAffinity(candidateInfo.domain, currentCoDomainDef.domain);

    // Project Evidence
    let projectRelevance = 0;
    if (matched.length >= 3) projectRelevance = 90;
    else if (matched.length >= 1) projectRelevance = 65;
    else projectRelevance = 0;

    // Strict Non-Compensatory Gate: If 0 required core skills match, score is strictly 0%
    let overallMatchPct = 0;
    if (reqCoveragePct === 0) {
      overallMatchPct = 0;
    } else {
      let rawScore = (reqCoveragePct * 0.60) + (prefCoveragePct * 0.15) + (domainAffinity * 0.15) + (projectRelevance * 0.10);
      if (domainAffinity <= 15) {
        rawScore *= 0.50;
      }
      overallMatchPct = Math.min(100, Math.max(0, Math.round(rawScore)));
    }

    // Generate explainability narratives
    let summaryText = '';
    let strengthsText = '';
    let gapText = '';

    if (!candidateInfo.hasResume) {
      summaryText = `No resume connected. Upload or create a resume to analyze compatibility with ${currentCoDomainDef.name} (${currentCoDomainDef.domain}).`;
      strengthsText = 'Awaiting verified resume upload.';
      gapText = `Upload your resume to calculate your exact multi-domain match score and discover targeted prerequisites for ${currentCoDomainDef.name}.`;
    } else if (overallMatchPct === 0) {
      summaryText = `0% Match: ${candidateInfo.name}'s resume is specialized in '${candidateInfo.domain}' and exhibits 0 qualifying competencies for ${currentCoDomainDef.name} (${currentCoDomainDef.domain}).`;
      strengthsText = `No skill overlap detected with ${currentCoDomainDef.domain} specifications.`;
      gapText = `Complete disciplinary divergence. Transitioning to ${currentCoDomainDef.domain} requires acquiring formal domain qualifications and all ${totalReq} core competencies.`;
    } else {
      summaryText = `${candidateInfo.name} demonstrates a verified ${overallMatchPct}% match for ${currentCoDomainDef.name} (${currentCoDomainDef.domain}) based on authentic parsed resume credentials.`;
      strengthsText = `Verified resume credentials in: ${matched.slice(0, 3).map(m => m.skill_name).join(', ')}.`;
      gapText = missing.length > 0 
        ? `Target skill gaps identified in ${missing.slice(0, 2).map(m => m.skill_name).join(', ')}. Bridge these to reach 100% placement readiness.`
        : 'All primary co-domain benchmarks fulfilled!';
    }

    return {
      overallMatchPct,
      reqCoveragePct: overallMatchPct > 0 ? reqCoveragePct : 0,
      prefCoveragePct: overallMatchPct > 0 ? prefCoveragePct : 0,
      domainAffinity: overallMatchPct > 0 ? domainAffinity : (domainAffinity <= 15 ? 0 : domainAffinity),
      projectRelevance,
      matchedRequiredCount: reqMatchedCount,
      totalRequiredCount: benchmarkSpec.required.length,
      matchedPreferredCount: prefMatchedCount,
      totalPreferredCount: benchmarkSpec.preferred.length,
      matched,
      missing,
      summary: summaryText,
      strengths: strengthsText,
      gapSummary: gapText
    };
  }, [currentCoDomainDef, candidateSkillNamesSet, candidateInfo]);

  // Verified Learning Platforms for the active target
  const activeLearningPlatforms: LearningPlatformResource[] = useMemo(() => {
    const p1 = resolvePhaseLearningPlatforms(activeTargetDomain, activeTargetTitle, 0);
    const p2 = resolvePhaseLearningPlatforms(activeTargetDomain, activeTargetTitle, 1);
    return [...p1, ...p2].slice(0, 4);
  }, [activeTargetDomain, activeTargetTitle]);

  // Placement Intelligence Metadata
  const placementIntelligence = useMemo(() => {
    const domainUpper = activeTargetDomain.toUpperCase();
    const titleLower = activeTargetTitle.toLowerCase();

    let salary = '₹8.5L – ₹32.0L / yr';
    let demand = '96% Surge across Industry Hiring';
    let companies = ['Google', 'Microsoft', 'Amazon', 'Meta', 'Uber', 'Top Unicorns'];
    let atsKeywords = [activeTargetTitle, activeTargetDomain, 'Clean Architecture', 'Unit Testing', 'CI/CD Pipelines', 'Quality Assurance'];

    if (domainUpper.includes('MBBS') || domainUpper.includes('MEDICINE') || domainUpper.includes('HEALTHCARE')) {
      salary = '₹10.0L – ₹36.0L / yr';
      demand = '98% Massive Clinical & Healthcare Hiring Demand';
      companies = ['Apollo Hospitals', 'Fortis Healthcare', 'Max Healthcare', 'Manipal Hospitals', 'Medanta', 'AIIMS'];
      atsKeywords = [activeTargetTitle, 'Clinical Diagnostics', 'Physical Examination', 'Differential Diagnosis', 'Patient Triage (ATLS)', 'SOP Compliance', 'BLS / ACLS'];
    } else if (domainUpper.includes('NURSING')) {
      salary = '₹5.5L – ₹20.0L / yr';
      demand = '97% Critical Global Nursing Demand';
      companies = ['Apollo Hospitals', 'Fortis', 'Max Healthcare', 'NHS UK', 'Cleveland Clinic', 'Medanta'];
      atsKeywords = [activeTargetTitle, 'Patient Care Plan', '5 Rights of Medication', 'ICU Hemodynamic Monitoring', 'Aseptic Wound Care', 'CPR / ACLS'];
    } else if (domainUpper.includes('LAW') || domainUpper.includes('LLB')) {
      salary = '₹9.0L – ₹32.0L / yr';
      demand = '95% Strong Demand in Corporate Tech & Privacy Law';
      companies = ['AZB & Partners', 'Khaitan & Co', 'Shardul Amarchand Mangaldas', 'Trilegal', 'Cyril Amarchand', 'JSA Law'];
      atsKeywords = [activeTargetTitle, 'Commercial Contract Drafting', 'DPDP Act Compliance', 'Due Diligence', 'Corporate Governance', 'Legal Precedents'];
    } else if (domainUpper.includes('ANALYTICS') || domainUpper.includes('BUSINESS ANALYTICS')) {
      salary = '₹8.0L – ₹28.0L / yr';
      demand = '94% High Demand in Enterprise Decision Intelligence';
      companies = ['McKinsey', 'Fractal Analytics', 'Bain & Company', 'Deloitte', 'Mu Sigma', 'Tiger Analytics'];
      atsKeywords = [activeTargetTitle, 'Data Wrangling (Pandas)', 'SQL Window Functions', 'Power BI & DAX', 'Advanced Excel Modeling', 'A/B Testing'];
    } else if (domainUpper.includes('COMMERCE') || domainUpper.includes('BCOM')) {
      salary = '₹6.5L – ₹24.0L / yr';
      demand = '92% High Demand across Corporate Treasury & Audit';
      companies = ['EY', 'PwC', 'KPMG', 'Deloitte', 'BDO India', 'Grant Thornton', 'Morgan Stanley'];
      atsKeywords = [activeTargetTitle, 'Ind AS / IFRS Standards', 'GST Return Filing', 'Statutory Auditing (CARO)', '3-Statement Modeling', 'TallyPrime'];
    } else if (domainUpper.includes('BBA') || domainUpper.includes('MANAGEMENT') || domainUpper.includes('MBA')) {
      salary = '₹6.5L – ₹26.0L / yr';
      demand = '91% High Demand across Startups & Enterprises';
      companies = ['Amazon', 'HUL', 'P&G', 'Zomato', 'Swiggy', 'Accenture Strategy', 'Gartner'];
      atsKeywords = [activeTargetTitle, 'Business Strategy & OKRs', 'Product-Led Growth (PLG)', 'Brand Marketing Funnels', 'Customer Acquisition Cost (CAC)', 'Unit Economics'];
    } else if (domainUpper.includes('PILOT') || domainUpper.includes('AVIATION')) {
      salary = '₹14.0L – ₹45.0L / yr';
      demand = '96% Explosive Global Fleet Expansion Demand';
      companies = ['IndiGo Airlines', 'Air India', 'Emirates', 'Qatar Airways', 'Singapore Airlines'];
      atsKeywords = [activeTargetTitle, 'IFR Navigation', 'Flight Management Systems (FMS)', 'Aviation Meteorology (METAR/TAF)', 'Crew Resource Management', 'DGCA Air Law'];
    } else if (domainUpper.includes('AERONAUTICAL') || domainUpper.includes('AEROSPACE')) {
      salary = '₹7.5L – ₹28.0L / yr';
      demand = '94% High Growth in Defense & Civil Aerospace';
      companies = ['ISRO', 'DRDO', 'Hindustan Aeronautics (HAL)', 'Boeing India', 'Airbus Engineering'];
      atsKeywords = [activeTargetTitle, 'Aerodynamics & Lift-Drag Polars', 'ANSYS Fluent CFD Mesh', 'Fuselage FEA Stress', 'Gas Turbine Propulsion', 'Flight Dynamics'];
    } else if (domainUpper.includes('CABIN CREW')) {
      salary = '₹6.0L – ₹22.0L / yr';
      demand = '95% Airline Fleet Hiring Surge';
      companies = ['Emirates', 'Etihad Airways', 'Qatar Airways', 'Singapore Airlines', 'Air India', 'IndiGo'];
      atsKeywords = [activeTargetTitle, '90-Second Cabin Evacuation', 'Aviation First Aid & AED', 'CRM SOP Callouts', 'Luxury Galley Hospitality', 'De-escalation Protocols'];
    } else if (domainUpper.includes('ROBOTICS')) {
      salary = '₹8.0L – ₹32.0L / yr';
      demand = '93% Surge in Industrial & Autonomous Robotics';
      companies = ['Boston Dynamics', 'GreyOrange', 'ABB Robotics', 'Fanuc', 'Tesla Robotics', 'Addverb Technologies'];
      atsKeywords = [activeTargetTitle, 'ROS 2 Nodes & Topics', 'Inverse Kinematics (DH)', '2D/3D LiDAR SLAM (Nav2)', 'Siemens PLC Ladder Logic', 'Closed-Loop PID Tuning'];
    } else if (domainUpper.includes('MECHANICAL')) {
      salary = '₹6.5L – ₹25.0L / yr';
      demand = '88% Core Manufacturing & EV Hiring Growth';
      companies = ['Tata Motors', 'Mahindra & Mahindra', 'Larsen & Toubro', 'Bosch', 'Cummins', 'Tesla'];
      atsKeywords = [activeTargetTitle, '3D Parametric CAD (SolidWorks)', 'GD&T (ASME Y14.5)', 'ANSYS Structural FEA', 'CNC Toolpaths & G-Code', 'Design for Manufacturing (DFMA)'];
    } else if (domainUpper.includes('CIVIL')) {
      salary = '₹6.0L – ₹24.0L / yr';
      demand = '87% Infrastructure & Smart Cities Expansion';
      companies = ['Larsen & Toubro (L&T Construction)', 'Shapoorji Pallonji', 'Tata Projects', 'AFCONS', 'AECOM', 'Bechtel'];
      atsKeywords = [activeTargetTitle, 'STAAD.Pro Frame Modeling', 'Autodesk Revit BIM 3D', 'RCC Design (IS 456)', 'Geotechnical Foundation', 'Quantity Surveying & BOQ'];
    } else if (domainUpper.includes('ELECTRICAL')) {
      salary = '₹7.5L – ₹30.0L / yr';
      demand = '93% Semiconductor & EV Powertrain Surge';
      companies = ['Texas Instruments', 'Qualcomm', 'Intel', 'NVIDIA', 'Schneider Electric', 'Siemens', 'ABB'];
      atsKeywords = [activeTargetTitle, 'ARM Cortex-M Embedded C', 'VLSI Verilog RTL Design', 'Altium PCB Multi-Layer Routing', 'Power Inverters (PWM)', 'MATLAB Simulink'];
    } else if (domainUpper.includes('CHEMICAL')) {
      salary = '₹6.5L – ₹26.0L / yr';
      demand = '86% Steady Petrochemical & Green Energy Growth';
      companies = ['Reliance Industries', 'Tata Chemicals', 'Indian Oil (IOCL)', 'Bharat Petroleum', 'Dow Chemical', 'BASF'];
      atsKeywords = [activeTargetTitle, 'Aspen Plus Flowsheets', 'Mass & Energy Balances', 'McCabe-Thiele Distillation', 'HAZOP Risk Matrix', 'Piping & Instrumentation (P&ID)'];
    } else if (domainUpper.includes('BIOTECH')) {
      salary = '₹6.0L – ₹24.0L / yr';
      demand = '90% Biopharma & Genomics Expansion';
      companies = ['Biocon', 'Serum Institute of India', "Dr. Reddy's", 'Bharat Biotech', 'Novozymes', 'Thermo Fisher'];
      atsKeywords = [activeTargetTitle, 'CRISPR Guide RNA Design', 'Bioreactor Fermentation Kinetics', 'HPLC Protein Purification', 'BioPython Sequence Alignment', 'cGMP Standards'];
    } else if (domainUpper.includes('MARINE')) {
      salary = '₹9.0L – ₹38.0L / yr';
      demand = '91% High Demand in Merchant Marine';
      companies = ['Maersk Line', 'Anglo-Eastern Ship Management', 'Fleet Management Limited', 'MSC', 'V.Group', 'Cochin Shipyard'];
      atsKeywords = [activeTargetTitle, '2-Stroke Marine Diesel Engines', 'Ship Metacentric Height (GM)', 'IMO MARPOL Regulations', 'Maxsurf 3D Hull Resistance', 'STCW Watchkeeping'];
    } else if (domainUpper.includes('HUMANITIES') || domainUpper.includes('HONS')) {
      salary = '₹5.5L – ₹22.0L / yr';
      demand = '85% Think Tank & Strategic Policy Demand';
      companies = ['NITI Aayog', 'Observer Research Foundation (ORF)', 'Centre for Policy Research (CPR)', 'UNDP', 'World Bank', 'Edelman PR'];
      atsKeywords = [activeTargetTitle, 'Public Policy Life Cycle', 'Qualitative Social Research', 'Macroeconomic Indicator Analysis', 'Strategic Communications', 'GRI / ESG Reporting'];
    } else if (titleLower.includes('dsa') || titleLower.includes('data structure') || titleLower.includes('algorithm')) {
      salary = '₹10.0L – ₹42.0L / yr';
      demand = '99% Universal FAANG / Tier-1 Core Requirement';
      companies = ['Google', 'Microsoft', 'Amazon', 'Meta', 'Uber', 'Directi', 'Goldman Sachs'];
      atsKeywords = ['Data Structures & Algorithms', 'Time Complexity O(1)/O(log N)', 'Dynamic Programming', 'Graph BFS/DFS', 'System Design', 'Clean Code'];
    }

    const starBullet = `Architected and executed verified end-to-end ${activeTargetTitle} implementations, improving workflow accuracy by 34% and adhering strictly to ${activeTargetDomain} industry benchmark standards.`;

    return { salary, demand, companies, atsKeywords, starBullet };
  }, [activeTargetDomain, activeTargetTitle]);

  // Navigate to Master Placement Level Roadmap
  const handleOpenRoadmap = () => {
    if (onNavigateToRoadmap) {
      onNavigateToRoadmap(activeTargetTitle, activeTargetDomain);
    }
  };

  const hasResume = candidateInfo.hasResume;
  const isZeroMatch = hasResume && evaluation.overallMatchPct === 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      {/* Toast Notification */}
      {toastMsg && (
        <div style={{
          position: 'fixed',
          top: '1.5rem',
          right: '1.5rem',
          zIndex: 99999,
          background: 'var(--bg-modal)',
          color: 'var(--text-primary)',
          border: '1.5px solid var(--accent-cyan)',
          padding: '0.75rem 1.25rem',
          borderRadius: '10px',
          boxShadow: 'var(--shadow-modal)',
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          fontSize: '0.85rem',
          fontWeight: 700
        }}>
          <Check size={16} color="var(--accent-emerald)" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Target size={24} color="var(--accent-cyan)" />
              Explainable Match & Placement Skill Gap Analytics
            </h2>
            <span className="badge badge-cyan">
              <Award size={12} /> 100% Deterministic AI
            </span>
          </div>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
            Real-time alignment engine evaluating your verified resume credentials against multi-domain benchmarks with transparent mathematical proof.
          </p>
        </div>

        {/* Action Button: Jump to Placement Roadmap */}
        <button
          onClick={handleOpenRoadmap}
          className="btn btn-primary btn-sm"
          style={{ padding: '0.5rem 1rem', display: 'flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700, fontSize: '0.82rem' }}
        >
          <Compass size={14} />
          <span>Open Placement Level Roadmap →</span>
        </button>
      </div>

      {/* Uploaded Resume Metadata Banner with Multi-Resume Selector */}
      <div 
        className="glass-card" 
        style={{ 
          padding: '0.9rem 1.25rem', 
          background: 'linear-gradient(90deg, rgba(2, 132, 199, 0.12) 0%, rgba(16, 185, 129, 0.08) 100%)',
          border: '1.5px solid rgba(56, 189, 248, 0.3)',
          borderRadius: '12px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '1rem'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
          <div style={{ 
            width: '42px', 
            height: '42px', 
            borderRadius: '10px', 
            background: 'rgba(56, 189, 248, 0.2)', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center', 
            border: '1px solid rgba(56, 189, 248, 0.4)',
            color: '#38bdf8'
          }}>
            <FileText size={22} />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
              <span style={{ fontWeight: 800, fontSize: '1rem', color: 'var(--text-primary)' }}>
                {candidateInfo.name}
              </span>
              {candidateInfo.hasResume ? (
                <span className="badge badge-emerald" style={{ fontSize: '0.68rem', fontWeight: 700 }}>
                  <CheckCircle2 size={11} /> Real Resume Connected
                </span>
              ) : (
                <span className="badge badge-rose" style={{ fontSize: '0.68rem', fontWeight: 700 }}>
                  <AlertCircle size={11} /> No Resume Uploaded
                </span>
              )}
              <span className="badge badge-purple" style={{ fontSize: '0.68rem' }}>
                {candidateInfo.domain}
              </span>
            </div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '0.15rem' }}>
              <strong>Headline:</strong> {candidateInfo.headline} • <strong>Extracted Skills:</strong> {candidateInfo.skillsList.length} Competencies
            </div>
          </div>
        </div>

        {/* Resume Selector Dropdown (if multiple saved resumes exist) */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
          {savedResumesList.length > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Resume:</span>
              <select
                value={selectedResumeId}
                onChange={(e) => handleSelectResume(e.target.value)}
                disabled={isLoadingResume}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.75rem', padding: '0.3rem 0.6rem' }}
              >
                <option value="latest">⚡ Active Resume</option>
                {savedResumesList.map((res) => (
                  <option key={res.id} value={res.id}>
                    📄 {res.title || res.original_filename}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap' }}>
            {candidateInfo.skillsList.slice(0, 4).map((sk, i) => (
              <span key={i} style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', padding: '0.2rem 0.5rem', borderRadius: '4px', fontSize: '0.72rem', color: 'var(--text-primary)', fontWeight: 600 }}>
                {sk}
              </span>
            ))}
            {candidateInfo.skillsList.length > 4 && (
              <span style={{ fontSize: '0.72rem', color: 'var(--accent-cyan)', fontWeight: 600 }}>+{candidateInfo.skillsList.length - 4} more</span>
            )}
          </div>
        </div>
      </div>

      {/* Target Mode Switcher & Stream Filter */}
      <div className="glass-card" style={{ padding: '0.85rem 1rem', display: 'flex', flexDirection: 'column', gap: '0.75rem', border: '1px solid var(--border-subtle)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-primary)', fontWeight: 700, fontSize: '0.85rem' }}>
            <Code2 size={16} color="var(--accent-cyan)" />
            <span>3D Galaxy Co-Domains & Specializations ({availableCoDomains.length})</span>
          </div>

          {/* Search bar */}
          <div style={{ position: 'relative', minWidth: '220px' }}>
            <Search size={13} style={{ position: 'absolute', left: '0.6rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              type="text"
              placeholder="Search co-domain (e.g. React, Docker, Diagnostics)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                width: '100%',
                padding: '0.35rem 0.5rem 0.35rem 1.8rem',
                fontSize: '0.75rem',
                borderRadius: '6px',
                background: 'var(--bg-glass)',
                border: '1px solid var(--border-subtle)',
                color: 'var(--text-primary)',
                outline: 'none'
              }}
            />
          </div>
        </div>

        {/* 15+ Multi-Domain Stream Filter Tabs */}
        {/* Stream Filter Tabs */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap', paddingTop: '0.2rem' }}>
          <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.3rem', fontWeight: 600, textTransform: 'uppercase' }}>
            <Filter size={12} /> Stream:
          </span>
          {[
            { id: 'Computer Science', label: '💻 Computer Science' },
            { id: 'MBBS', label: '🩺 MBBS & Medicine' },
            { id: 'Nursing', label: '🏥 Nursing & Care' },
            { id: 'Business Analytics', label: '📈 Business Analytics' },
            { id: 'BCOM', label: '📊 Commerce & Ind AS' },
            { id: 'BBA', label: '💼 Management & BBA' },
            { id: 'BA LLB', label: '⚖️ Law & Corporate' },
            { id: 'Aviation', label: '✈️ Pilot Studies' },
            { id: 'Aeronautical', label: '🚀 Aeronautical' },
            { id: 'Cabin Crew', label: '👩‍✈️ Cabin Crew' },
            { id: 'Robotics', label: '🤖 Robotics' },
            { id: 'Biotechnology', label: '🧬 Biotechnology' },
            { id: 'Marine', label: '⚓ Marine Eng' },
            { id: 'Mechanical', label: '⚙️ Mechanical' },
            { id: 'Civil', label: '🏗️ Civil & BIM' },
            { id: 'Electrical', label: '⚡ Electrical' },
            { id: 'Chemical', label: '🧪 Chemical' },
            { id: 'BA Hons', label: '🏛️ Humanities' }
          ].map(tab => (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setActiveDomainFilter(tab.id);
                try {
                  localStorage.setItem('employai_matching_domain', tab.id);
                } catch {}
                const streamList = DOMAIN_CO_DOMAINS[tab.id] || [];
                if (streamList.length > 0) {
                  handleSelectCoDomain(streamList[0].name, tab.id);
                }
              }}
              className={activeDomainFilter === tab.id ? 'btn btn-primary btn-sm' : 'btn btn-secondary btn-sm'}
              style={{ fontSize: '0.725rem', padding: '0.25rem 0.6rem', borderRadius: '6px' }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Co-Domain Pill Grid Selector - Rock-solid in place with zero layout shifting */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap', paddingTop: '0.3rem' }}>
          {availableCoDomains.map((coItem) => {
            const isSelected = selectedCoDomainName === coItem.name;
            return (
              <button
                key={coItem.id}
                type="button"
                onClick={(e) => handleSelectCoDomain(coItem.name, activeDomainFilter, e)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  fontSize: '0.78rem',
                  padding: '0.35rem 0.8rem',
                  borderRadius: '20px',
                  border: isSelected ? '1.5px solid var(--accent-cyan)' : '1.5px solid var(--border-subtle)',
                  background: isSelected ? 'rgba(56, 189, 248, 0.22)' : 'rgba(255, 255, 255, 0.03)',
                  color: isSelected ? 'var(--accent-cyan)' : 'var(--text-secondary)',
                  fontWeight: isSelected ? 800 : 500,
                  cursor: 'pointer',
                  transition: 'background-color 0.15s ease, color 0.15s ease, box-shadow 0.15s ease',
                  boxShadow: isSelected ? '0 0 14px rgba(56, 189, 248, 0.35)' : 'none',
                  contain: 'layout style',
                  whiteSpace: 'nowrap'
                }}
              >
                <Sparkles size={12} color={isSelected ? 'var(--accent-cyan)' : 'var(--text-muted)'} />
                <span>{coItem.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {error && (
        <div style={{ padding: '0.75rem 1rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.1)', border: '1px solid rgba(244, 63, 94, 0.3)', color: '#fb7185', fontSize: '0.825rem' }}>
          {error}
        </div>
      )}

      {/* Main Alignment Hero Banner */}
      <div className="role-hero-banner" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', flexWrap: 'wrap' }}>
          <div style={{
            width: '100px',
            height: '100px',
            borderRadius: '50%',
            background: !hasResume
              ? 'rgba(255, 255, 255, 0.04)'
              : isZeroMatch 
                ? 'rgba(244, 63, 94, 0.2)' 
                : `conic-gradient(var(--accent-cyan) 0% ${evaluation.overallMatchPct}%, rgba(255, 255, 255, 0.12) ${evaluation.overallMatchPct}% 100%)`,
            border: !hasResume
              ? '1.5px dashed rgba(255, 255, 255, 0.25)'
              : isZeroMatch 
                ? '2px solid rgba(244, 63, 94, 0.5)' 
                : 'none',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: !hasResume ? 'none' : isZeroMatch ? '0 0 20px rgba(244, 63, 94, 0.2)' : '0 0 25px rgba(2, 132, 199, 0.25)'
          }}>
            <div style={{
              width: '80px',
              height: '80px',
              borderRadius: '50%',
              backgroundColor: 'var(--bg-secondary)',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <span style={{ fontSize: !hasResume ? '1.5rem' : '1.7rem', fontWeight: 900, color: !hasResume ? 'var(--text-muted)' : isZeroMatch ? '#fb7185' : 'var(--accent-cyan)', lineHeight: 1 }}>
                {!hasResume ? '--' : `${evaluation.overallMatchPct}%`}
              </span>
              <span style={{ fontSize: '0.625rem', color: !hasResume ? 'var(--text-muted)' : isZeroMatch ? '#fb7185' : 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>
                {!hasResume ? 'No Resume' : isZeroMatch ? 'No Match' : 'Match'}
              </span>
            </div>
          </div>

          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.3rem', flexWrap: 'wrap' }}>
              <span className="badge badge-cyan">
                {activeTargetDomain}
              </span>
              <span className="badge badge-emerald" style={{ fontSize: '0.68rem' }}>
                ⭐ {currentCoDomainDef.difficulty} Level
              </span>
              {!hasResume ? (
                <span className="badge" style={{ fontSize: '0.68rem', background: 'rgba(255, 255, 255, 0.06)', color: 'var(--text-muted)', border: '1px solid var(--border-subtle)' }}>
                  📄 Awaiting Resume
                </span>
              ) : isZeroMatch ? (
                <span className="badge badge-rose" style={{ fontSize: '0.68rem', fontWeight: 700 }}>
                  ⛔ Incompatible Specialization
                </span>
              ) : (
                <span className="badge badge-purple" style={{ fontSize: '0.68rem' }}>
                  <TrendingUp size={11} /> {placementIntelligence.demand}
                </span>
              )}
            </div>
            <h3 style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
              {activeTargetTitle}
            </h3>
            <p style={{ fontSize: '0.84rem', color: 'var(--text-secondary)', maxWidth: '640px', marginTop: '0.25rem', lineHeight: 1.45 }}>
              {currentCoDomainDef.short_description}
            </p>
            {!hasResume ? (
              <div style={{ marginTop: '0.6rem', display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-muted)', fontSize: '0.78rem', background: 'rgba(255, 255, 255, 0.03)', padding: '0.45rem 0.75rem', borderRadius: '8px', border: '1px solid var(--border-subtle)', flexWrap: 'wrap' }}>
                <AlertCircle size={15} style={{ flexShrink: 0, color: 'var(--accent-cyan)' }} />
                <span>
                  No active resume connected. Upload or generate a resume in <strong>AI Resume Studio</strong> to calculate verified placement alignment.
                </span>
                {onNavigateToResume && (
                  <button 
                    onClick={onNavigateToResume}
                    className="btn btn-outline-cyan btn-sm"
                    style={{ marginLeft: 'auto', padding: '0.25rem 0.6rem', fontSize: '0.72rem' }}
                  >
                    Upload Resume →
                  </button>
                )}
              </div>
            ) : isZeroMatch ? (
              <div style={{ marginTop: '0.6rem', display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#fb7185', fontSize: '0.78rem', background: 'rgba(244, 63, 94, 0.1)', padding: '0.45rem 0.75rem', borderRadius: '8px', border: '1px solid rgba(244, 63, 94, 0.3)' }}>
                <ShieldAlert size={15} style={{ flexShrink: 0 }} />
                <span>
                  Resume domain (<strong>{candidateInfo.domain}</strong>) has 0 of {evaluation.totalRequiredCount} prerequisites for {activeTargetTitle}. Deterministic engine reflects strict benchmark standards.
                </span>
              </div>
            ) : null}
          </div>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem', flexDirection: 'column' }}>
          <button
            onClick={handleOpenRoadmap}
            className="btn btn-primary"
            style={{ padding: '0.75rem 1.4rem', fontSize: '0.88rem', display: 'flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
          >
            <Compass size={18} />
            <span>Open Placement Level Roadmap →</span>
          </button>
          <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textAlign: 'center' }}>
            5-Phase structured progression directly for {activeTargetTitle}
          </span>
        </div>
      </div>

      {/* Matched vs Missing Skills Grid */}
      <div className="grid-2" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1.25rem' }}>
        {/* Matched Skills */}
        <div className="glass-card" style={{ padding: '1.5rem', border: '1px solid var(--border-subtle)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <CheckCircle2 size={18} color="var(--accent-emerald)" />
              <h4 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                Matched Capabilities ({evaluation.matched.length})
              </h4>
            </div>
            <span className={evaluation.matched.length > 0 ? "badge badge-emerald" : "badge badge-secondary"}>
              {evaluation.matched.length > 0 ? "Verified in Resume" : "0 Overlap"}
            </span>
          </div>

          {evaluation.matched.length === 0 ? (
            <div style={{ padding: '1.5rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.825rem', background: 'rgba(255, 255, 255, 0.02)', borderRadius: '8px', border: '1px dashed var(--border-subtle)' }}>
              {!hasResume 
                ? 'No resume connected. Upload your resume to automatically match your skills against this role.' 
                : 'No verified competencies in your resume currently match this specific focus. Acquire the foundational skills listed under Skill Gaps to build capability.'}
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
              {evaluation.matched.map((skill, idx) => (
                <div
                  key={idx}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '0.65rem 0.9rem',
                    borderRadius: '8px',
                    background: 'rgba(16, 185, 129, 0.06)',
                    border: '1px solid rgba(16, 185, 129, 0.2)'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <CheckCircle2 size={14} color="#10b981" />
                    <span style={{ fontWeight: 600, fontSize: '0.825rem', color: 'var(--text-primary)' }}>
                      {skill.skill_name}
                    </span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    <span style={{ fontSize: '0.68rem', color: '#10b981', fontWeight: 700, textTransform: 'uppercase' }}>
                      {skill.is_required ? 'Required Core' : 'Preferred Bonus'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Missing Skills */}
        <div className="glass-card" style={{ padding: '1.5rem', border: '1px solid var(--border-subtle)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <AlertCircle size={18} color="#f43f5e" />
              <h4 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                Skill Gaps to Bridge ({evaluation.missing.length})
              </h4>
            </div>
            <span className="badge badge-rose">Roadmap Action Items</span>
          </div>

          {evaluation.missing.length === 0 ? (
            <div style={{ padding: '1.5rem', textAlign: 'center', color: '#10b981', fontSize: '0.825rem', fontWeight: 700 }}>
              🎉 Perfect 100% Match! All core specifications verified for this target.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem', maxHeight: '340px', overflowY: 'auto' }}>
              {evaluation.missing.map((skill, idx) => (
                <div
                  key={idx}
                  style={{
                    padding: '0.75rem 0.9rem',
                    borderRadius: '8px',
                    background: 'rgba(244, 63, 94, 0.05)',
                    border: '1px solid rgba(244, 63, 94, 0.2)'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                      <AlertCircle size={13} color="#f43f5e" />
                      <span style={{ fontWeight: 700, fontSize: '0.84rem', color: 'var(--text-primary)' }}>
                        {skill.skill_name}
                      </span>
                    </div>
                    <span style={{ fontSize: '0.68rem', color: '#f43f5e', fontWeight: 700, textTransform: 'uppercase' }}>
                      {skill.importance}
                    </span>
                  </div>
                  <p style={{ fontSize: '0.74rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.3 }}>
                    {skill.recommendation}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 🎓 Verified Learning Platforms for this Target */}
      {activeLearningPlatforms.length > 0 && (
        <div className="glass-card" style={{ padding: '1.25rem 1.5rem', border: '1px solid rgba(56, 189, 248, 0.25)', background: 'rgba(56, 189, 248, 0.04)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem', flexWrap: 'wrap', gap: '0.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <BookOpen size={18} color="var(--accent-cyan)" />
              <h4 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                Verified Learning Platforms & Courseware for {activeTargetTitle}
              </h4>
            </div>
            <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
              Direct authentic links to study material & documentation
            </span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '0.75rem' }}>
            {activeLearningPlatforms.map((res, rIdx) => (
              <a
                key={rIdx}
                href={res.platform_url}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                  padding: '0.85rem 1rem',
                  background: 'var(--bg-tertiary)',
                  borderRadius: '10px',
                  border: '1px solid var(--border-subtle)',
                  textDecoration: 'none',
                  color: 'inherit',
                  transition: 'all 0.2s ease',
                  cursor: 'pointer'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = 'var(--accent-cyan)';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 6px 16px rgba(56, 189, 248, 0.15)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = 'var(--border-subtle)';
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem', marginBottom: '0.35rem' }}>
                    <span style={{ fontWeight: 700, fontSize: '0.84rem', color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                      🎓 {res.platform_name}
                    </span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '0.2rem', color: 'var(--accent-cyan)', fontSize: '0.72rem', fontWeight: 600 }}>
                      <ExternalLink size={12} /> Open ↗
                    </span>
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.3rem', marginBottom: '0.45rem' }}>
                    <span style={{ background: 'rgba(56, 189, 248, 0.12)', color: 'var(--accent-cyan)', border: '1px solid rgba(56, 189, 248, 0.25)', fontSize: '0.66rem', fontWeight: 600, padding: '0.1rem 0.45rem', borderRadius: '4px' }}>
                      📌 {res.topic_focus}
                    </span>
                    <span style={{ background: 'rgba(168, 85, 247, 0.12)', color: 'var(--accent-purple)', border: '1px solid rgba(168, 85, 247, 0.25)', fontSize: '0.66rem', fontWeight: 600, padding: '0.1rem 0.45rem', borderRadius: '4px' }}>
                      ⭐ {res.access_badge}
                    </span>
                  </div>
                  <p style={{ fontSize: '0.74rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.4 }}>
                    {res.description}
                  </p>
                </div>
              </a>
            ))}
          </div>
        </div>
      )}

      {/* 4-Pillar Transparent Match Weight Breakdown */}
      <div className="glass-card" style={{ padding: '1.5rem', border: '1px solid var(--border-subtle)' }}>
        <h4 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Zap size={18} color="var(--accent-cyan)" />
          4-Factor Weighted Evaluation Proof
        </h4>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
          <div style={{ padding: '1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Required Core Skills (60%)</div>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: !hasResume ? 'var(--text-muted)' : isZeroMatch ? '#fb7185' : '#38bdf8', marginTop: '0.25rem' }}>
              {!hasResume ? '--' : `${evaluation.reqCoveragePct}%`}
            </div>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
              {!hasResume ? 'Pending resume upload' : `${evaluation.matchedRequiredCount} of ${evaluation.totalRequiredCount} verified`}
            </div>
          </div>

          <div style={{ padding: '1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Preferred Bonus (15%)</div>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: !hasResume ? 'var(--text-muted)' : isZeroMatch ? '#fb7185' : '#10b981', marginTop: '0.25rem' }}>
              {!hasResume ? '--' : `${evaluation.prefCoveragePct}%`}
            </div>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
              {!hasResume ? 'Pending resume upload' : `${evaluation.matchedPreferredCount} of ${evaluation.totalPreferredCount} bonus capabilities`}
            </div>
          </div>

          <div style={{ padding: '1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Academic / Domain Affinity (15%)</div>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: !hasResume ? 'var(--text-muted)' : isZeroMatch ? '#fb7185' : '#a855f7', marginTop: '0.25rem' }}>
              {!hasResume ? '--' : `${evaluation.domainAffinity}%`}
            </div>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
              {!hasResume ? 'No resume domain' : `${candidateInfo.domain} vs ${activeTargetDomain}`}
            </div>
          </div>

          <div style={{ padding: '1rem', background: 'rgba(255,255,255,0.03)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Resume Project Evidence (10%)</div>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: !hasResume ? 'var(--text-muted)' : isZeroMatch ? '#fb7185' : '#f59e0b', marginTop: '0.25rem' }}>
              {!hasResume ? '--' : `${evaluation.projectRelevance}%`}
            </div>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
              {!hasResume ? 'No project deliverables' : 'Verified Portfolio Deliverables'}
            </div>
          </div>
        </div>
      </div>

      {/* Placement Destination & ATS Intelligence Pack */}
      <div className="glass-card" style={{ padding: '1.5rem', border: '1.5px solid var(--accent-purple)44', background: 'var(--bg-tertiary)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Award size={20} color="var(--accent-purple)" />
            <h4 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
              Placement & ATS Hiring Intelligence for {activeTargetTitle}
            </h4>
          </div>
          <span className="badge badge-purple" style={{ fontSize: '0.74rem' }}>
            <DollarSign size={12} /> Expected Benchmark: {placementIntelligence.salary}
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem', marginBottom: '1rem' }}>
          {/* Top Hiring Companies */}
          <div>
            <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: '0.35rem', marginBottom: '0.5rem' }}>
              <Building2 size={13} color="var(--accent-purple)" /> Top Hiring Employers & Ecosystem:
            </span>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
              {placementIntelligence.companies.map((comp, cIdx) => (
                <span key={cIdx} style={{ background: 'rgba(168, 85, 247, 0.12)', border: '1px solid rgba(168, 85, 247, 0.3)', color: 'var(--accent-purple)', padding: '0.25rem 0.65rem', borderRadius: '6px', fontSize: '0.74rem', fontWeight: 600 }}>
                  🏢 {comp}
                </span>
              ))}
            </div>
          </div>

          {/* Top ATS Keywords */}
          <div>
            <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', display: 'block', marginBottom: '0.5rem' }}>
              Top Resume ATS Keywords (Click to Copy):
            </span>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
              {placementIntelligence.atsKeywords.map((kw, kIdx) => (
                <button
                  key={kIdx}
                  type="button"
                  onClick={() => handleCopyText(kw, 'keyword')}
                  style={{
                    background: copiedText === kw ? '#10b98122' : 'rgba(56, 189, 248, 0.08)',
                    border: copiedText === kw ? '1px solid #10b981' : '1px solid rgba(56, 189, 248, 0.25)',
                    color: copiedText === kw ? '#10b981' : 'var(--accent-cyan)',
                    padding: '0.2rem 0.55rem',
                    borderRadius: '6px',
                    fontSize: '0.72rem',
                    fontWeight: 600,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.25rem'
                  }}
                >
                  {copiedText === kw ? <Check size={11} /> : <Copy size={11} />}
                  <span>{kw}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Recommended Resume STAR Bullet */}
        <div style={{ padding: '0.85rem 1rem', background: 'rgba(255,255,255,0.02)', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
            <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase' }}>
              Verified Resume STAR Bullet Formulation:
            </span>
            <button
              type="button"
              onClick={() => handleCopyText(placementIntelligence.starBullet, 'STAR bullet')}
              className="btn btn-ghost btn-sm"
              style={{ fontSize: '0.7rem', padding: '0.15rem 0.45rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
            >
              <Copy size={12} /> Copy Bullet
            </button>
          </div>
          <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.45 }}>
            "{placementIntelligence.starBullet}"
          </p>
        </div>
      </div>

      {/* Explainable AI Decision Narrative */}
      <div className="glass-card" style={{ padding: '1.5rem', border: '1px solid var(--border-subtle)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.8rem' }}>
          <Sparkles size={18} color="var(--accent-cyan)" />
          <h4 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
            Explainable AI Decision Narrative
          </h4>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem', fontSize: '0.825rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>
          <div style={{ padding: '0.75rem', background: 'rgba(255, 255, 255, 0.02)', borderRadius: '8px', borderLeft: `3px solid ${!hasResume ? 'var(--border-subtle)' : isZeroMatch ? '#f43f5e' : '#38bdf8'}` }}>
            <strong style={{ color: 'var(--text-primary)' }}>Match Summary: </strong>
            {evaluation.summary}
          </div>

          <div style={{ padding: '0.75rem', background: 'rgba(255, 255, 255, 0.02)', borderRadius: '8px', borderLeft: '3px solid #10b981' }}>
            <strong style={{ color: '#10b981' }}>Key Strengths: </strong>
            {evaluation.strengths}
          </div>

          <div style={{ padding: '0.75rem', background: 'rgba(255, 255, 255, 0.02)', borderRadius: '8px', borderLeft: '3px solid #f43f5e' }}>
            <strong style={{ color: '#f43f5e' }}>Primary Gap to Close: </strong>
            {evaluation.gapSummary}
          </div>
        </div>
      </div>
    </div>
  );
};

export const RoleMatchingView = React.memo(RoleMatchingViewComponent);
