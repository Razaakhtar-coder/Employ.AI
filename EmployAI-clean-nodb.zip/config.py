import os
from pathlib import Path
from typing import List, Union
from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(BACKEND_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore"
    )

    PROJECT_NAME: str = "EmployAI"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    # ⚠ Set DEBUG=False in production via environment variable
    DEBUG: bool = False

    # Security & JWT
    # ⚠ REQUIRED in production: set a strong random SECRET_KEY environment variable.
    # Default is only for local dev — NEVER use the default in production.
    SECRET_KEY: str = "e9b8f2d4c6a1e3b57890123456789abcdeffedcba9876543210fedcba9876543"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440  # 24 hours

    # Database
    DATABASE_URL: str = (
        "sqlite:////tmp/employai.db"
        if os.getenv("VERCEL")
        else f"sqlite:///{(BACKEND_DIR / 'employai.db').resolve().as_posix()}"
    )

    # AI Integration
    GEMINI_API_KEY: str = ""
    GEMINI_MODEL: str = "gemini-1.5-flash"

    # Google OAuth
    GOOGLE_CLIENT_ID: str = ""
    GOOGLE_CLIENT_SECRET: str = ""

    # Job & Internship Provider API Keys (Optional - Free public APIs work out-of-the-box)
    THEMUSE_API_KEY: str = ""
    JOOBLE_API_KEY: str = ""
    FINDWORK_API_KEY: str = ""
    RAPIDAPI_KEY: str = ""
    ADZUNA_APP_ID: str = ""
    ADZUNA_APP_KEY: str = ""
    ADZUNA_COUNTRY: str = "in"
    USAJOBS_API_KEY: str = ""
    USAJOBS_EMAIL: str = ""

    # Curated & Low-Crowd Job Platforms (Remote.com, Instahyre, Careerhound, Wellfound, YC, Cutshort, Otta)
    REMOTE_COM_API_KEY: str = ""
    INSTAHYRE_API_KEY: str = ""
    CAREERHOUND_API_KEY: str = ""
    WELLFOUND_API_KEY: str = ""
    YC_STARTUP_API_KEY: str = ""
    CUTSHORT_API_KEY: str = ""
    OTTA_API_KEY: str = ""

    # Razorpay Payment Gateway (configured strictly via environment variables or .env)
    RAZORPAY_KEY_ID: str = ""
    RAZORPAY_KEY_SECRET: str = ""
    RAZORPAY_WEBHOOK_SECRET: str = ""
    RAZORPAY_AMOUNT_MONTHLY_INR: float = 49.0
    RAZORPAY_AMOUNT_ANNUAL_INR: float = 499.0
    RAZORPAY_AMOUNT_INR: float = 49.0
    RAZORPAY_CURRENCY: str = "INR"
    RAZORPAY_COMPANY_NAME: str = "Employ.AI PRO"

    # Storage
    STORAGE_DIR: str = "/tmp/storage" if os.getenv("VERCEL") else "./storage"
    MAX_UPLOAD_SIZE_MB: int = 10

    # CORS
    ALLOWED_ORIGINS: Union[str, List[str]] = [
        "http://localhost:5173",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
        "https://employai-hub.vercel.app"
    ]

    @field_validator("DATABASE_URL", mode="after")
    @classmethod
    def resolve_database_url(cls, v: str) -> str:
        if os.getenv("VERCEL"):
            return "sqlite:////tmp/employai.db"
        if v.startswith("sqlite:///./"):
            db_filename = v.replace("sqlite:///./", "")
            resolved = (BACKEND_DIR / db_filename).resolve().as_posix()
            return f"sqlite:///{resolved}"
        return v

    @field_validator("STORAGE_DIR", mode="after")
    @classmethod
    def resolve_storage_dir(cls, v: str) -> str:
        if os.getenv("VERCEL"):
            return "/tmp/storage"
        path = Path(v)
        if not path.is_absolute():
            return str((BACKEND_DIR / path).resolve())
        return v

    @field_validator("ALLOWED_ORIGINS", mode="before")
    @classmethod
    def parse_allowed_origins(cls, v: Union[str, List[str]]) -> List[str]:
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",") if origin.strip()]
        return v

    @property
    def max_upload_size_bytes(self) -> int:
        return self.MAX_UPLOAD_SIZE_MB * 1024 * 1024


settings = Settings()

# Ensure storage directory exists safely
try:
    os.makedirs(settings.STORAGE_DIR, exist_ok=True)
except Exception:
    pass

