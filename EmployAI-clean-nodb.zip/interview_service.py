import json
import re
import uuid
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
import google.generativeai as genai
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from app.core.config import settings
from app.models.interview import InterviewSession
from app.models.document import Document, DocumentVersion, AnalysisResult
from app.models.profile import StudentProfile
from app.models.user import User
from app.schemas.interview import (
    InterviewStartRequest, InterviewQuestionItem, InterviewSessionResponse,
    QuestionEvaluationResponse, InterviewScoreHistoryItem, InterviewHistoryResponse
)


class InterviewService:

    @staticmethod
    def _is_similar_to_past(candidate_text: str, past_questions: Optional[List[str]]) -> bool:
        """Fuzzy similarity and keyword check to guarantee zero repeated questions across multiple mock interviews."""
        if not past_questions or not candidate_text:
            return False
        cand_norm = candidate_text.lower().strip()
        stopwords = {
            "what", "would", "when", "your", "with", "have", "from", "that", "this",
            "discuss", "provide", "explain", "describe", "which", "about", "using",
            "into", "tell", "time", "where", "project", "skill", "their", "will",
            "could", "were", "been", "also", "some", "most", "make", "made", "like"
        }
        cand_words = set(w for w in re.findall(r'\b[a-z]{3,}\b', cand_norm) if w not in stopwords)
        if not cand_words:
            return False

        for past in past_questions:
            if not past or not isinstance(past, str):
                continue
            past_norm = past.lower().strip()
            # Exact match
            if cand_norm == past_norm:
                return True
            past_words = set(w for w in re.findall(r'\b[a-z]{3,}\b', past_norm) if w not in stopwords)
            if not past_words:
                continue
            # Jaccard word overlap on non-stopword tokens
            inter = len(cand_words & past_words)
            union = len(cand_words | past_words)
            if union > 0 and (inter / union) >= 0.52:
                return True
        return False

    @classmethod
    def _get_gemini_model(cls):
        """Initialize Google Generative AI client if valid API key is configured."""
        if settings.GEMINI_API_KEY and settings.GEMINI_API_KEY != "your-gemini-api-key-here" and len(settings.GEMINI_API_KEY) > 10:
            try:
                genai.configure(api_key=settings.GEMINI_API_KEY)
                return genai.GenerativeModel(settings.GEMINI_MODEL)
            except Exception as e:
                print(f"[WARN] InterviewService: Failed to configure Gemini API: {e}")
        return None

    @classmethod
    def _detect_domain_category(cls, domain: str = "", target_role: str = "", skills: List[str] = None) -> str:
        """
        Classify candidate's field into a standard domain category for specialized interview generation.
        Returns one of: 'business_management', 'finance_commerce', 'civil_engineering', 
        'mechanical_engineering', 'electrical_electronics', 'law_legal', 'healthcare_medicine',
        'design_creative', 'data_analytics', 'computer_science', 'general'.
        """
        text = f"{domain or ''} {target_role or ''} {' '.join(skills or [])}".lower()
        
        # 1. Management, Business, Strategy, Operations, Marketing, HR
        if any(k in text for k in [
            "management", "business", "mba", "bba", "operations", "strategic", "strategy",
            "product management", "project management", "scrum master", "agile coach",
            "marketing", "digital marketing", "seo", "sem", "human resources", "talent acquisition",
            "supply chain", "logistics", "crm", "salesforce", "hubspot", "sales", "business development",
            "consulting", "retail", "general management", "business specialist", "brand management"
        ]):
            return "business_management"
            
        # 2. Finance, Commerce, Banking, Accounting, Audit, Taxation
        if any(k in text for k in [
            "finance", "commerce", "accounting", "banking", "audit", "taxation", "gst",
            "chartered accountant", "tally", "balance sheet", "corporate finance", "valuation",
            "equity research", "investment banking", "cost accounting", "sap fico", "quickbooks",
            "financial modeling", "portfolio management", "b.com", "m.com", "fintech", "accounts"
        ]):
            return "finance_commerce"

        # 3. Civil & Structural Engineering
        if any(k in text for k in [
            "civil", "structural", "construction", "bim", "revit", "staad", "etabs",
            "surveying", "geotechnical", "quantity surveying", "estimation & costing",
            "concrete", "site supervision", "primavera", "transportation engineering"
        ]):
            return "civil_engineering"

        # 4. Mechanical & Aerospace Engineering
        if any(k in text for k in [
            "mechanical", "aerospace", "solidworks", "catia", "autocad", "ansys", "fea",
            "cfd", "thermodynamics", "hvac", "fluid mechanics", "manufacturing", "gd&t",
            "cnc", "cam", "finite element", "mechatronics", "automobile"
        ]):
            return "mechanical_engineering"

        # 5. Electrical & Electronics
        if any(k in text for k in [
            "electrical", "electronics", "vlsi", "verilog", "vhdl", "embedded c", "microcontroller",
            "pcb design", "altium", "plc", "scada", "power systems", "circuit design", "fpga",
            "arduino", "raspberry pi", "iot", "control systems", "semiconductor"
        ]):
            return "electrical_electronics"

        # 6. Law & Legal
        if any(k in text for k in [
            "law", "legal", "litigation", "corporate law", "contract drafting", "intellectual property",
            "arbitration", "compliance", "llb", "llm", "advocate", "due diligence", "dispute resolution"
        ]):
            return "law_legal"

        # 7. Healthcare, Pharmacy & Medicine
        if any(k in text for k in [
            "health", "medicine", "pharmacy", "mbbs", "b.pharm", "m.pharm", "pharmacology",
            "clinical research", "pharmacovigilance", "medical diagnostics", "patient care", "regulatory affairs"
        ]):
            return "healthcare_medicine"

        # 8. Design, UI/UX & Creative
        if any(k in text for k in [
            "ui/ux", "ux design", "ui design", "product design", "figma", "wireframing",
            "user research", "usability", "graphic design", "visual design", "design system", "interaction design"
        ]):
            return "design_creative"

        # 9. Data Analytics & Business Intelligence
        if any(k in text for k in [
            "data analyst", "business intelligence", "power bi", "tableau", "data analytics",
            "kpi dashboard", "data visualization", "sql analyst", "data science"
        ]):
            return "data_analytics"

        # 10. Computer Science & Software Engineering (Default technical)
        if any(k in text for k in [
            "computer science", "software", "developer", "full stack", "frontend", "backend",
            "python", "react", "node", "java", "golang", "devops", "cloud", "aws", "docker",
            "api", "database", "machine learning", "ai/ml", "deep learning", "cybersecurity",
            "c++", "c#", "rust", "kubernetes"
        ]):
            return "computer_science"

        return "general"

    @classmethod
    def _extract_resume_facts(cls, db: Session, user_id: Optional[str], student_profile_id: Optional[str], document_id: Optional[str]) -> Dict[str, Any]:
        """Extract candidate's actual projects, skills, experience, and domain strictly for the authenticated user."""
        facts = {
            "has_resume": False,
            "skills": [],
            "projects": [],
            "experience": [],
            "domain": "General Professional",
            "candidate_name": "Candidate",
            "education": [],
            "certifications": [],
            "structured_resume": None,
            "raw_text_snippet": ""
        }

        # If user is completely unauthenticated and no document_id provided, return clean empty facts
        if not user_id and not student_profile_id and not document_id:
            return facts

        analysis = None
        doc = None
        doc_ver = None

        if document_id:
            analysis = db.query(AnalysisResult).filter(AnalysisResult.document_id == document_id).order_by(AnalysisResult.created_at.desc()).first()
            doc = db.query(Document).filter(Document.id == document_id).first()
        
        if not analysis and student_profile_id:
            analysis = db.query(AnalysisResult).filter(AnalysisResult.student_profile_id == student_profile_id).order_by(AnalysisResult.created_at.desc()).first()

        if not analysis and user_id:
            doc = db.query(Document).filter(Document.user_id == user_id).order_by(Document.created_at.desc()).first()
            if doc:
                analysis = db.query(AnalysisResult).filter(AnalysisResult.document_id == doc.id).order_by(AnalysisResult.created_at.desc()).first()

        if analysis:
            doc_id = analysis.document_id
            doc_ver = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc_id).order_by(DocumentVersion.version_num.desc()).first()

        if analysis:
            facts["has_resume"] = True
            facts["skills"] = analysis.extracted_skills_json or []
            facts["projects"] = analysis.extracted_projects_json or []
            facts["experience"] = analysis.extracted_experience_json or []
            facts["domain"] = analysis.detected_domain or "General Professional"
            
            if doc_ver and doc_ver.parsed_metadata_json:
                struct = doc_ver.parsed_metadata_json.get("structured_resume") or {}
                if isinstance(struct, dict):
                    facts["structured_resume"] = struct
                    if struct.get("skills") and not facts["skills"]:
                        facts["skills"] = struct.get("skills", [])
                    if struct.get("projects") and not facts["projects"]:
                        facts["projects"] = struct.get("projects", [])
                    if struct.get("experience") and not facts["experience"]:
                        facts["experience"] = struct.get("experience", [])
                    if struct.get("personal_info", {}).get("full_name"):
                        facts["candidate_name"] = struct["personal_info"]["full_name"]
                    if struct.get("education"):
                        facts["education"] = struct.get("education", [])
                    if struct.get("certifications"):
                        facts["certifications"] = struct.get("certifications", [])

            if doc_ver and doc_ver.raw_text:
                facts["raw_text_snippet"] = doc_ver.raw_text[:3000]
        elif student_profile_id:
            sp = db.query(StudentProfile).filter(StudentProfile.id == student_profile_id).first()
            if sp:
                facts["domain"] = sp.department or sp.target_domain or "General Professional"
                facts["skills"] = [s.skill.name for s in sp.skills if s.skill] if hasattr(sp, "skills") else []
                if sp.user:
                    facts["candidate_name"] = sp.user.full_name
                if facts["skills"]:
                    facts["has_resume"] = True

        return facts

    @classmethod
    def generate_interview_questions(
        cls,
        facts: Dict[str, Any],
        target_role: str,
        interview_type: str,
        difficulty: str,
        num_questions: int,
        past_questions: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """Generate tailored questions strictly grounded in candidate's resume facts using Gemini or smart fallback."""
        dom_category = cls._detect_domain_category(
            domain=facts.get("domain", ""),
            target_role=target_role,
            skills=facts.get("skills", [])
        )

        model = cls._get_gemini_model()
        if model:
            try:
                # Persona mapping per domain
                persona_map = {
                    "business_management": f"You are an executive interviewer and Senior Business Director interviewing a candidate for '{target_role}'.",
                    "finance_commerce": f"You are a Senior Financial Controller and Chief Financial Officer interviewing a candidate for '{target_role}'.",
                    "civil_engineering": f"You are a Principal Civil & Structural Engineering Director interviewing a candidate for '{target_role}'.",
                    "mechanical_engineering": f"You are a Senior Principal Mechanical Engineer and R&D Director interviewing a candidate for '{target_role}'.",
                    "electrical_electronics": f"You are a Principal Hardware & Embedded Systems Lead interviewing a candidate for '{target_role}'.",
                    "law_legal": f"You are a Senior Partner and General Counsel conducting a rigorous interview for '{target_role}'.",
                    "healthcare_medicine": f"You are a Senior Medical Director and Head of Clinical Research interviewing a candidate for '{target_role}'.",
                    "design_creative": f"You are a Principal Product Design Lead and Head of UX interviewing a candidate for '{target_role}'.",
                    "data_analytics": f"You are a Head of Data Analytics & Business Intelligence interviewing a candidate for '{target_role}'.",
                    "computer_science": f"You are an expert senior engineering hiring manager conducting a technical interview for '{target_role}'.",
                    "general": f"You are a Senior Director and Lead Interviewer conducting a professional interview for '{target_role}'."
                }
                interviewer_persona = persona_map.get(dom_category, persona_map["general"])

                # Anti-repetition past questions block
                past_questions_directive = ""
                if past_questions and len(past_questions) > 0:
                    past_samples = past_questions[-20:]
                    formatted_past = "\n".join(f"- {pq}" for pq in past_samples)
                    past_questions_directive = f"""
STRICT ANTI-REPETITION MANDATE:
The candidate has completed multiple mock interviews and has ALREADY been asked the following questions:
{formatted_past}

YOU ARE STRICTLY FORBIDDEN FROM REPEATING, PARAPHRASING, OR ASKING ANY QUESTION SIMILAR TO THE ABOVE LIST!
Every single question you generate in this session MUST explore a completely new angle, different edge case, alternate skill, or different project!
"""

                # Mode-specific guidelines tailored for the candidate's exact domain
                if interview_type in ["project_deepdive", "resume_project"]:
                    if dom_category == "business_management":
                        mode_guidance = """
MODE: RESUME PROJECTS DEFENSE (MANAGEMENT & BUSINESS)
- Generate 100% of questions focused entirely on the candidate's actual listed business/management projects, case studies, or operational deliverables.
- Drill into strategic frameworks, ROI/cost-benefit trade-offs, stakeholder negotiations, operational bottlenecks, KPI metrics (CAC, LTV, revenue growth, cost reduction, cycle time), and organizational change management.
- STRICT PURITY MANDATE: NEVER ask about software code, APIs, Redis, app development, or servers.
"""
                    elif dom_category == "finance_commerce":
                        mode_guidance = """
MODE: RESUME PROJECTS DEFENSE (FINANCE & COMMERCE)
- Generate 100% of questions focused on their financial models, accounting audits, tax planning, cash flow forecasting, or cost analysis.
- Drill into GAAP/IFRS compliance, risk management, internal controls, and balance sheet reconciliation.
- STRICT PURITY MANDATE: NEVER ask about software code, APIs, Redis, or app development.
"""
                    elif dom_category in ["civil_engineering", "mechanical_engineering", "electrical_electronics"]:
                        mode_guidance = """
MODE: RESUME PROJECTS DEFENSE (PHYSICAL ENGINEERING)
- Generate 100% of questions focused on their engineering projects, CAD/BIM models, simulations, circuit designs, or manufacturing processes.
- Drill into technical calculations, tolerances, safety codes, failure analysis, and production trade-offs.
- NEVER ask about web APIs or software servers unless their listed project is explicitly software.
"""
                    else:
                        mode_guidance = """
MODE: RESUME PROJECTS DEFENSE
- Generate 100% of questions focused entirely on the candidate's actual listed projects.
- Drill into architecture, methodology, trade-offs, bottlenecks, metrics, and execution challenges.
"""
                elif interview_type == "technical":
                    if dom_category == "business_management":
                        mode_guidance = """
MODE: DOMAIN MASTERY (BUSINESS & MANAGEMENT COMPETENCIES)
- Generate 100% of questions focused on their listed business skills (e.g. Strategic Planning, Budgeting, Agile/Lean, CRM, KPI Dashboards, Market Research, Operations).
- Focus on strategic frameworks (SWOT, Porter's Five Forces, PESTLE, OKRs), budgetary variance, process optimization, stakeholder alignment, and data-driven governance.
- STRICT PURITY MANDATE: NEVER ask about software code, APIs, Redis, or app development!
"""
                    elif dom_category == "finance_commerce":
                        mode_guidance = """
MODE: DOMAIN MASTERY (FINANCE & COMMERCE COMPETENCIES)
- Generate 100% of questions focused on financial accounting, auditing standards, GST/taxation, DCF valuation, working capital, and financial risk controls.
- STRICT PURITY MANDATE: NEVER ask about software code, APIs, Redis, or app development!
"""
                    elif dom_category == "law_legal":
                        mode_guidance = """
MODE: DOMAIN MASTERY (LAW & LEGAL COMPETENCIES)
- Generate 100% of questions focused on contract drafting (indemnity, liability, force majeure), statutory compliance, litigation strategy, IP rights, and dispute resolution.
- STRICT PURITY MANDATE: NEVER ask about software code, APIs, Redis, or app development!
"""
                    elif dom_category == "healthcare_medicine":
                        mode_guidance = """
MODE: DOMAIN MASTERY (HEALTHCARE & PHARMACY)
- Generate 100% of questions focused on clinical trials (GCP), pharmacology (ADME), adverse drug reaction reporting, regulatory compliance (FDA/EMA), and diagnostic protocols.
"""
                    elif dom_category == "design_creative":
                        mode_guidance = """
MODE: DOMAIN MASTERY (DESIGN & UI/UX)
- Generate 100% of questions focused on UX research, design systems, wireframing/prototyping in Figma, accessibility (WCAG), usability testing, and developer handoff.
"""
                    elif dom_category == "data_analytics":
                        mode_guidance = """
MODE: DOMAIN MASTERY (DATA ANALYTICS & BI)
- Generate 100% of questions focused on SQL querying, data modeling (Star/Snowflake), KPI dashboard design (Power BI/Tableau), statistical hypothesis testing, and data storytelling.
"""
                    else:
                        mode_guidance = """
MODE: TECHNICAL DEEP-DIVE (SOFTWARE & COMPUTING)
- Generate 100% of questions focused on deep technical concepts, algorithms, frameworks, and architecture of their listed skills.
- Focus on internal mechanisms, database optimization/indexing, async architecture, caching, API security, and code quality.
"""
                elif interview_type == "behavioral_star":
                    mode_guidance = f"""
MODE: BEHAVIORAL (STAR METHOD) FOR {dom_category.upper()}
- Generate 100% of questions focused on behavioral and situational scenarios using the STAR framework.
- Tie questions to high-stakes stakeholder disagreements, tight deadline crunches, handling ambiguous requirements, proactive leadership, and constructive feedback within '{target_role}'.
"""
                else:
                    mode_guidance = f"""
MODE: COMPREHENSIVE MOCK INTERVIEW FOR {dom_category.upper()}
- Mix 1 core domain methodology question from their top skill, 1 project execution/strategy question from their primary project, 1 bottleneck/risk management question from their secondary project, 1 STAR behavioral stakeholder scenario, and 1 scaling / governance question.
- STRICT DOMAIN PURITY: Ensure 100% of questions are purely relevant to '{facts.get('domain', target_role)}'.
"""

                prompt = f"""
{interviewer_persona}
The interview type is '{interview_type}' and difficulty level is '{difficulty}'.
Session Random Seed: {uuid.uuid4().hex[:8]}

{mode_guidance}

{past_questions_directive}

CRITICAL TWISTED & ZIG-ZAG QUESTION DIRECTIVE:
As the candidate will take several mock interviews, you MUST ask TWISTED, NON-LINEAR, and ZIG-ZAG questions with real-world curveballs:
- NEVER ask flat, predictable textbook questions (e.g. "What is your experience with X?" or "Explain the syntax of Y").
- Ask twisted questions with conflicting constraints:
  * Sudden Cascading Failure: A dependent service hangs silently, causing worker pool starvation under peak load.
  * Invalidation Curveball: A core design assumption or tool is prohibited by security policy; redesign from scratch under latency constraints.
  * Adversarial Input & Attack: Malformed payloads, race conditions, memory leaks, and edge-case exploits.
  * Disaster Recovery & Regrets: Brutally dissect the fragile architectural shortcuts and technical debt in their projects.
  * High-Stakes Dilemmas: Pushing back against executive pressure to cut corners, owning a self-inflicted production outage, or resolving a week-long technical deadlock.

CRITICAL DOMAIN PURITY MANDATE:
- Candidate Domain: {facts.get('domain', 'General')} (Detected Category: {dom_category})
- Target Role: {target_role}
- You MUST ONLY ask questions strictly relevant to '{target_role}' and '{facts.get('domain')}'.
- NEVER ask software engineering, coding, API, database server, or programming questions to candidates in non-software fields (such as Management, Business, Finance, Law, Civil/Mechanical Engineering, Healthcare, Design, etc.)!

You must generate EXACTLY {num_questions} interview questions STRICTLY GROUNDED in the candidate's actual uploaded resume facts below.
Make sure questions are unique, non-repetitive, and directly cite specific items from the resume.

CANDIDATE'S ACTUAL RESUME DATA:
- Target Role / Domain: {target_role} ({facts.get('domain', 'General')})
- Verified Skills: {json.dumps(facts.get('skills', [])[:15])}
- Uploaded Projects: {json.dumps(facts.get('projects', [])[:6])}
- Work Experience / Internships: {json.dumps(facts.get('experience', [])[:4])}
- Education: {json.dumps(facts.get('education', [])[:2])}
- Resume Snippet: {facts.get('raw_text_snippet', '')[:1000]}

MANDATORY RULES:
1. In 'resume_reference', cite the EXACT name of the project, skill, or employer (e.g. "Project: Market Expansion Study", "Skill: Strategic Planning", "Experience: Business Analyst at Apex").
2. Ensure every question is twisted, non-linear, and strictly distinct from previous sessions.
3. For every question, write 3 concrete evaluation points in `ideal_answer_points` so the answer can be graded factually based on semantic accuracy.

Output ONLY valid raw JSON array matching this exact schema:
[
  {{
    "id": "q1",
    "index": 1,
    "question": "Twisted, direct question referencing their specific project or skill within their exact professional field",
    "category": "technical | project_deepdive | behavioral_star | system_design | core_fundamentals",
    "resume_reference": "Specific reference to their exact project title or skill",
    "context_hint": "Tip for how the candidate should structure their answer (e.g. STAR method or methodology breakdown)",
    "ideal_answer_points": [
      "Key domain concept 1 expected in an accurate response",
      "Key domain concept 2 expected in an accurate response",
      "Key domain concept 3 expected in an accurate response"
    ]
  }}
]
"""
                response = model.generate_content(prompt)
                content = response.text.strip()
                if content.startswith("```json"):
                    content = content[7:]
                if content.endswith("```"):
                    content = content[:-3]
                parsed = json.loads(content.strip())
                if isinstance(parsed, list) and len(parsed) >= 1:
                    for i, q in enumerate(parsed):
                        q["id"] = f"q_{i+1}_{uuid.uuid4().hex[:6]}"
                        q["index"] = i + 1
                        q["user_answer"] = None
                        q["score"] = None
                        q["feedback"] = None
                        q["strengths"] = []
                        q["improvements"] = []
                        q["star_breakdown"] = None
                    return parsed[:num_questions]
            except Exception as e:
                print(f"[WARN] Gemini question generation failed, using dynamic domain generator: {e}")

        # Dynamic Smart Fallback Generator with anti-repetition and twisted questions
        return cls._generate_fallback_questions(facts, target_role, interview_type, difficulty, num_questions, past_questions=past_questions)

    @classmethod
    def _generate_fallback_questions(
        cls,
        facts: Dict[str, Any],
        target_role: str,
        interview_type: str,
        difficulty: str,
        num_questions: int,
        past_questions: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """Generate diverse deterministic interview questions strictly tailored to interview_type and grounded in resume domain."""
        import random
        dom_category = cls._detect_domain_category(
            domain=facts.get("domain", ""),
            target_role=target_role,
            skills=facts.get("skills", [])
        )

        # Domain-appropriate default skills if candidate's resume has empty skill list
        default_skills_map = {
            "business_management": ["Strategic Planning", "Market Research", "CRM & Salesforce", "Budgeting & Cost Control", "Agile Project Management", "KPI Dashboards", "Operations Management"],
            "finance_commerce": ["Financial Accounting", "GST & Taxation", "Auditing", "Financial Modeling", "Balance Sheet Analysis", "Budgeting & Variance", "Tally Prime & Excel"],
            "civil_engineering": ["Structural Analysis", "Revit & BIM", "STAAD.Pro", "Quantity Surveying", "Concrete Design", "Geotechnical Engineering", "Site Supervision"],
            "mechanical_engineering": ["SolidWorks", "ANSYS FEA", "AutoCAD", "Thermodynamics", "GD&T Tolerancing", "DFM / DFA", "Manufacturing Processes"],
            "electrical_electronics": ["Embedded C", "Microcontrollers", "VLSI & Verilog", "PCB Design", "Altium Designer", "IoT & Sensors", "Circuit Design"],
            "law_legal": ["Corporate Law", "Contract Drafting", "Legal Research", "Litigation Strategy", "Intellectual Property", "Due Diligence", "Arbitration & Compliance"],
            "healthcare_medicine": ["Clinical Research", "Pharmacology", "Regulatory Affairs", "Patient Care", "Medical Diagnostics", "Pharmacovigilance", "Good Clinical Practice"],
            "design_creative": ["UI/UX Design", "Figma", "User Research", "Wireframing & Prototyping", "Design Systems", "Usability Testing", "Information Architecture"],
            "data_analytics": ["SQL", "Power BI", "Tableau", "Data Modeling", "Python / Pandas", "KPI Dashboards", "Statistical Analysis"],
            "computer_science": ["FastAPI", "React", "Python", "PostgreSQL", "Redis", "Docker", "System Design", "Git"],
            "general": ["Strategic Planning", "Project Management", "Data Analysis", "Communication", "Problem Solving", "Quality Assurance"]
        }

        skills = facts.get("skills") or default_skills_map.get(dom_category, default_skills_map["general"])
        projects = facts.get("projects") or []
        experience = facts.get("experience") or []

        # Helper to format project titles & domain focus
        def get_proj_info(p):
            if isinstance(p, dict):
                title = p.get("title") or p.get("name") or "Featured Initiative"
                tech = p.get("key_technologies") or p.get("role_or_tech") or ("Strategic Framework" if dom_category == "business_management" else "Core Stack")
                if isinstance(tech, list):
                    tech = ", ".join(tech[:3])
                return title, tech
            return str(p), ("Management Framework" if dom_category == "business_management" else "Methodology")

        q_pool: List[Dict[str, Any]] = []

        # =========================================================================
        # 1. MODE: RESUME PROJECTS DEFENSE ('project_deepdive' / 'resume_project')
        # =========================================================================
        if interview_type in ["project_deepdive", "resume_project"]:
            if projects:
                for idx, p in enumerate(projects):
                    p_title, p_tech = get_proj_info(p)

                    if dom_category == "business_management":
                        # Business Strategy & Operational Architecture
                        q_pool.append({
                            "question": f"In your project '{p_title}' involving {p_tech}, walk me through the strategic framework and operational model you designed. Why did you choose this execution approach over alternatives, and what was your primary ROI or cost-benefit trade-off?",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Explain the business objective, market dynamics, operational model, and financial/resource trade-offs.",
                            "ideal_answer_points": [
                                f"Clear strategic breakdown of the {p_title} framework",
                                f"Justification for selecting {p_tech} / operational model",
                                "Analysis of trade-offs made between budget, timeline, and ROI"
                            ]
                        })

                        # Operational Bottlenecks & Problem Resolution
                        q_pool.append({
                            "question": f"While executing '{p_title}', what was the most critical operational bottleneck, stakeholder pushback, or resource constraint you faced, and how did you resolve it?",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Describe the root cause of the blocker, how you negotiated with stakeholders, and the concrete resolution.",
                            "ideal_answer_points": [
                                "Precise identification of the operational bottleneck or resistance",
                                "Stakeholder management and negotiation methodology",
                                "Concrete resolution and verification through business outcomes"
                            ]
                        })

                        # KPI Governance & Performance Metrics
                        q_pool.append({
                            "question": f"What key performance metrics (e.g. CAC, LTV, conversion rate, cost reduction, delivery cycle time) and tracking mechanisms did you implement in '{p_title}' to quantify business impact?",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Detail specific KPIs, dashboard reporting, and measurable business improvements achieved.",
                            "ideal_answer_points": [
                                "Identification of critical operational/financial KPIs",
                                "Mechanisms for tracking metrics and governance reporting",
                                "Quantifiable business impact or efficiency gains"
                            ]
                        })

                        # Scale & Organizational Change Management
                        q_pool.append({
                            "question": f"If you had to scale the rollout of '{p_title}' across multiple business units or an entire enterprise, how would you navigate cross-functional alignment and organizational change management?",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Discuss change management frameworks (e.g. Kotter / ADKAR), cross-departmental alignment, and risk mitigation.",
                            "ideal_answer_points": [
                                "Framework for driving cross-functional alignment and communication",
                                "Mitigation of adoption resistance across business units",
                                "Governance model for multi-departmental scalability"
                            ]
                        })

                    elif dom_category == "finance_commerce":
                        # Financial Modeling & Audit Framework
                        q_pool.append({
                            "question": f"In your project '{p_title}' ({p_tech}), walk me through the financial methodology and regulatory accounting standards applied. How did you ensure GAAP/IFRS and statutory compliance?",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Explain the financial model structure, accounting policies, and regulatory adherence.",
                            "ideal_answer_points": [
                                f"Clear financial and accounting structure of {p_title}",
                                "Compliance with statutory accounting and tax standards",
                                "Identification of financial risk factors and internal controls"
                            ]
                        })

                        # Reconciliation & Financial Variance
                        q_pool.append({
                            "question": f"While executing '{p_title}', what was the most complex financial variance, reconciliation mismatch, or compliance hurdle you resolved?",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Explain variance analysis, root cause auditing, and corrective adjustments.",
                            "ideal_answer_points": [
                                "Root cause analysis of the financial variance or discrepancy",
                                "Auditing procedures and ledger reconciliation applied",
                                "Corrective ledger entries and internal controls implemented"
                            ]
                        })

                    elif dom_category in ["civil_engineering", "mechanical_engineering", "electrical_electronics"]:
                        # Engineering Design & Physics/Code Standards
                        q_pool.append({
                            "question": f"In your project '{p_title}' ({p_tech}), walk me through the core design calculations, simulation parameters, and safety standards you adopted. What was your primary engineering constraint?",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Detail technical design codes, simulation assumptions, tolerances, and safety factor calculations.",
                            "ideal_answer_points": [
                                f"Engineering design methodology and calculations for {p_title}",
                                "Adherence to industry design codes and safety factors",
                                "Resolution of physical stress, thermal, or signal constraints"
                            ]
                        })

                        # Hardware / Structural Bottlenecks
                        q_pool.append({
                            "question": f"While working on '{p_title}', what unexpected physical failure mode, simulation divergence, or fabrication challenge did you encounter, and how did you resolve it?",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Explain failure analysis, test bench / FEA verification, and structural/circuit redesign.",
                            "ideal_answer_points": [
                                "Diagnosis of failure mode or design flaw",
                                "Testing/simulation methodology used to isolate root cause",
                                "Iterative redesign and physical verification"
                            ]
                        })

                    elif dom_category == "law_legal":
                        q_pool.append({
                            "question": f"In your work/case study on '{p_title}' ({p_tech}), walk me through the legal framework, statutory provisions, and risk allocation clauses you drafted or analyzed.",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Detail statutory interpretation, indemnification/liability clauses, and legal risk management.",
                            "ideal_answer_points": [
                                f"Legal analysis and statutory provisions in {p_title}",
                                "Drafting of protective clauses and liability caps",
                                "Risk mitigation and compliance verification"
                            ]
                        })

                    elif dom_category == "design_creative":
                        q_pool.append({
                            "question": f"In your design project '{p_title}' ({p_tech}), walk me through your end-to-end UX process from discovery and wireframing to final high-fidelity Figma prototypes. How did user testing shape the outcome?",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Explain user research findings, iterative wireframing, usability testing, and design system integration.",
                            "ideal_answer_points": [
                                f"End-to-end design thinking methodology for {p_title}",
                                "Evidence-based usability testing insights and iterations",
                                "Design system component consistency and accessibility"
                            ]
                        })

                    else:
                        # Software & Computing Deep Dive
                        q_pool.append({
                            "question": f"In your project '{p_title}' built with {p_tech}, walk me through the high-level system architecture. Why did you choose {p_tech} over other architectural alternatives, and what was your primary design trade-off?",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Explain the frontend/backend/database topology, architectural trade-offs, and your specific implementation decisions.",
                            "ideal_answer_points": [
                                f"Clear structural breakdown of the {p_title} architecture",
                                f"Technical justification for selecting {p_tech}",
                                "Analysis of trade-offs made between latency, complexity, and maintainability"
                            ]
                        })

                        q_pool.append({
                            "question": f"While building '{p_title}', what was the most difficult technical bottleneck, unexpected edge-case, or performance regression you encountered, and how did you debug and resolve it?",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Describe the root cause analysis, profiling or debugging tools utilized, and how you validated the fix.",
                            "ideal_answer_points": [
                                "Precise identification of the technical bottleneck or bug",
                                "Methodology used to isolate and debug the root cause",
                                "Concrete resolution and verification through testing or performance metrics"
                            ]
                        })

                        q_pool.append({
                            "question": f"How did you handle data persistence, state synchronization, and edge-case errors in '{p_title}'? How did you protect against data corruption or race conditions?",
                            "category": "project_deepdive",
                            "resume_reference": f"Project: {p_title}",
                            "context_hint": "Discuss database schemas, transactions, caching layers, or state management frameworks.",
                            "ideal_answer_points": [
                                "Data modeling and storage schema design",
                                "Mechanisms for ensuring concurrency safety and idempotent operations",
                                "Graceful degradation and error recovery patterns"
                            ]
                        })
            else:
                top_skill = skills[0] if skills else ("Strategic Planning" if dom_category == "business_management" else "Core Competency")
                if dom_category == "business_management":
                    q_pool.append({
                        "question": f"Walk me through the strategic design and execution of a major initiative you spearheaded involving '{top_skill}'. How did you establish KPIs, align stakeholders, and measure business impact?",
                        "category": "project_deepdive",
                        "resume_reference": f"Initiative: {top_skill}",
                        "context_hint": "Explain the business problem, stakeholder alignment, milestone roadmap, and measurable ROI.",
                        "ideal_answer_points": [
                            "Clear definition of business objectives and scope",
                            "Stakeholder communication and resource allocation",
                            "Quantifiable business metrics and ROI achieved"
                        ]
                    })
                else:
                    q_pool.append({
                        "question": f"Walk me through the end-to-end execution of a key deliverable you designed using {top_skill}. What trade-offs did you make and how did you validate the final outcome?",
                        "category": "project_deepdive",
                        "resume_reference": f"Deliverable: {top_skill}",
                        "context_hint": "Explain methodologies applied, constraints managed, and measurable outcomes.",
                        "ideal_answer_points": [
                            "Clear breakdown of domain methodology",
                            "Management of constraints and trade-offs",
                            "Verification and outcome metrics"
                        ]
                    })

        # =========================================================================
        # 2. MODE: TECHNICAL / DOMAIN MASTERY ('technical')
        # =========================================================================
        elif interview_type == "technical":
            for idx, skill in enumerate(skills[:6]):
                if dom_category == "business_management":
                    if idx == 0:
                        q_pool.append({
                            "question": f"You list '{skill}' as a primary core competency. What analytical frameworks (such as SWOT, Porter's Five Forces, PESTLE, or OKRs) do you apply to formulate strategy, and how do you stress-test your business assumptions?",
                            "category": "technical",
                            "resume_reference": f"Core Competency: {skill}",
                            "context_hint": "Focus on strategic analysis tools, market validation, competitive positioning, and risk evaluation.",
                            "ideal_answer_points": [
                                f"Demonstrates mastery of strategic frameworks within {skill}",
                                "Explains methods to validate market assumptions and competitive moats",
                                "Discusses risk assessment and long-term value creation"
                            ]
                        })
                    elif idx == 1:
                        q_pool.append({
                            "question": f"When establishing financial budgets, resource allocations, and variance analysis for initiatives involving '{skill}', how do you balance short-term operational expenses against long-term ROI?",
                            "category": "technical",
                            "resume_reference": f"Financial & Resource Planning: {skill}",
                            "context_hint": "Discuss budget forecasting, Capex vs Opex, variance tracking, and ROI calculations.",
                            "ideal_answer_points": [
                                "Methodology for cost-benefit analysis and budget allocation",
                                "Tracking variance against financial forecasts",
                                "Quantifying expected return on investment (ROI)"
                            ]
                        })
                    elif idx == 2:
                        q_pool.append({
                            "question": f"How do you apply process improvement methodologies (like Agile, Lean, BPMN, or Six Sigma) to eliminate operational waste and optimize workflow efficiency when executing '{skill}'?",
                            "category": "technical",
                            "resume_reference": f"Process Optimization: {skill}",
                            "context_hint": "Discuss workflow mapping, bottleneck removal, sprint/cycle time reduction, and continuous improvement.",
                            "ideal_answer_points": [
                                "Application of process mapping and waste elimination",
                                "Implementation of iterative delivery cycles and feedback loops",
                                "Measurable improvements in operational throughput"
                            ]
                        })
                    elif idx == 3:
                        q_pool.append({
                            "question": f"How do you leverage '{skill}' to manage customer acquisition funnels, client retention strategies, or CRM workflow automation to drive sustainable business growth?",
                            "category": "technical",
                            "resume_reference": f"Growth & CRM Strategy: {skill}",
                            "context_hint": "Detail customer lifecycle stages, CAC/LTV optimization, churn reduction, and CRM pipeline governance.",
                            "ideal_answer_points": [
                                "Understanding customer journey and pipeline conversion metrics",
                                "Optimization of CAC, LTV, and retention rates",
                                "Data-driven pipeline management and automation"
                            ]
                        })
                    elif idx == 4:
                        q_pool.append({
                            "question": f"What executive KPI dashboards and governance scorecards do you build in '{skill}' to track business health, identify revenue leakage, and report to senior leadership?",
                            "category": "technical",
                            "resume_reference": f"KPI Dashboards & Governance: {skill}",
                            "context_hint": "Discuss leading vs lagging indicators, data visualization, and executive reporting cadence.",
                            "ideal_answer_points": [
                                "Selection of high-impact leading and lagging indicators",
                                "Dashboard design and data integrity assurance",
                                "Executive communication and actionable decision support"
                            ]
                        })
                    else:
                        q_pool.append({
                            "question": f"What risk mitigation and contingency planning frameworks do you execute to protect business operations against supply disruptions or regulatory shifts when managing '{skill}'?",
                            "category": "technical",
                            "resume_reference": f"Risk Management: {skill}",
                            "context_hint": "Cover risk assessment matrices, scenario planning, contingency budgets, and compliance checks.",
                            "ideal_answer_points": [
                                "Identification of critical operational and external risk vectors",
                                "Development of scenario plans and business continuity procedures",
                                "Monitoring protocols and proactive escalation pathways"
                            ]
                        })

                elif dom_category == "finance_commerce":
                    if idx == 0:
                        q_pool.append({
                            "question": f"How do you ensure audit readiness and internal financial controls when applying '{skill}'? Discuss standard reconciliation procedures and GAAP/IFRS adherence.",
                            "category": "technical",
                            "resume_reference": f"Auditing & Controls: {skill}",
                            "context_hint": "Discuss balance sheet substantiation, trial balance reviews, and compliance checkpoints.",
                            "ideal_answer_points": [
                                "Demonstrates mastery of financial standards and internal controls",
                                "Substantiation of ledger accounts and audit documentation",
                                "Risk mitigation against accounting errors or non-compliance"
                            ]
                        })
                    elif idx == 1:
                        q_pool.append({
                            "question": f"How do you navigate GST/Taxation compliance and calculate input tax credits or statutory deductions when working with '{skill}'?",
                            "category": "technical",
                            "resume_reference": f"Taxation & Compliance: {skill}",
                            "context_hint": "Detail tax filing protocols, reconciliation with government portals, and penalty avoidance.",
                            "ideal_answer_points": [
                                "Accurate calculation of tax liabilities and eligible credits",
                                "Reconciliation between financial books and tax filings",
                                "Adherence to statutory deadlines and disclosure requirements"
                            ]
                        })
                    else:
                        q_pool.append({
                            "question": f"When building financial models or cost variance reports using '{skill}', what valuation methods (DCF, Multiples) and sensitivity analyses do you incorporate?",
                            "category": "technical",
                            "resume_reference": f"Financial Modeling: {skill}",
                            "context_hint": "Discuss discounted cash flows, WACC, working capital assumptions, and scenario modeling.",
                            "ideal_answer_points": [
                                "Structure of discounted cash flow or ratio models",
                                "Sensitivity analysis on revenue and cost drivers",
                                "Translating financial findings into executive recommendations"
                            ]
                        })

                elif dom_category in ["civil_engineering", "mechanical_engineering", "electrical_electronics"]:
                    if idx == 0:
                        q_pool.append({
                            "question": f"You list '{skill}' as a primary core skill. How do you approach mathematical modeling, design codes, and factor of safety calculations when engineering with {skill}?",
                            "category": "technical",
                            "resume_reference": f"Core Engineering: {skill}",
                            "context_hint": "Focus on engineering formulas, standard design codes (IS/ACI/ASME/IEEE), and stress/load limits.",
                            "ideal_answer_points": [
                                f"Deep theoretical and practical understanding of {skill}",
                                "Application of industry safety factors and design standards",
                                "Validation through simulation or empirical testing"
                            ]
                        })
                    else:
                        q_pool.append({
                            "question": f"When evaluating technical trade-offs in '{skill}', how do you balance material/component costs against structural integrity, thermal limits, or power efficiency?",
                            "category": "technical",
                            "resume_reference": f"Engineering Optimization: {skill}",
                            "context_hint": "Discuss material selection, failure modes, tolerance analysis, and manufacturing constraints.",
                            "ideal_answer_points": [
                                "Rigorous analysis of engineering constraints and trade-offs",
                                "Application of failure prevention methodologies",
                                "Optimization for production feasibility and reliability"
                            ]
                        })

                elif dom_category == "law_legal":
                    q_pool.append({
                        "question": f"How do you draft, interpret, and negotiate risk allocation clauses (indemnity, limitation of liability, dispute resolution) in matters involving '{skill}'?",
                        "category": "technical",
                        "resume_reference": f"Legal Competency: {skill}",
                        "context_hint": "Discuss statutory provisions, contract enforceability, case law precedents, and client protection.",
                        "ideal_answer_points": [
                            "Precise drafting of protective contractual covenants",
                            "Knowledge of relevant statutory frameworks and case precedents",
                            "Strategic negotiation and liability capping"
                        ]
                    })

                elif dom_category == "design_creative":
                    q_pool.append({
                        "question": f"When building design systems or user interfaces with '{skill}', how do you ensure WCAG accessibility compliance, component reusability, and cognitive ease for users?",
                        "category": "technical",
                        "resume_reference": f"Design Competency: {skill}",
                        "context_hint": "Discuss contrast ratios, component variants, auto-layout tokens, and user testing feedback.",
                        "ideal_answer_points": [
                            "Understanding of WCAG accessibility standards and inclusive design",
                            "Scalable design token architecture in Figma",
                            "Usability validation through qualitative testing"
                        ]
                    })

                else:
                    # Software Engineering Technical Questions - Varied Angles per Skill
                    slot = idx % 5
                    if slot == 0:
                        q_pool.append({
                            "question": f"You list '{skill}' as a primary core skill. How does {skill} handle memory management, concurrency, and runtime execution under heavy load? Provide a concrete example.",
                            "category": "technical",
                            "resume_reference": f"Core Skill: {skill}",
                            "context_hint": "Focus on runtime internals, thread/event loop models, memory leaks, and profiling techniques.",
                            "ideal_answer_points": [
                                f"Demonstrates deep conceptual understanding of {skill} execution model",
                                "Explains concurrency handling, asynchronous patterns, or thread safety",
                                "Discusses memory profiling and resource cleanup"
                            ]
                        })
                    elif slot == 1:
                        q_pool.append({
                            "question": f"When designing database schemas and query execution for systems built with {skill}, what indexing strategies, transaction isolation levels, and query optimization techniques do you apply?",
                            "category": "technical",
                            "resume_reference": f"Database & Optimization: {skill}",
                            "context_hint": "Discuss B-Trees, composite indexes, query execution plans (EXPLAIN), and N+1 query prevention.",
                            "ideal_answer_points": [
                                "Indexing strategies (B-Tree, GIN, composite keys) and scan mechanics",
                                "Understanding ACID transaction isolation levels and deadlock avoidance",
                                "Query optimization and ORM batching techniques"
                            ]
                        })
                    elif slot == 2:
                        q_pool.append({
                            "question": f"How do you design, secure, and version production systems when building with '{skill}'? Discuss authentication, input validation, and defensive error handling.",
                            "category": "technical",
                            "resume_reference": f"Architecture: {skill}",
                            "context_hint": "Detail authentication flows, payload validation schemas, rate limiting, and exception handlers.",
                            "ideal_answer_points": [
                                "Secure authentication and permission management",
                                "Strict schema validation to prevent injection and malformed requests",
                                "Defensive exception handling and structured status codes"
                            ]
                        })
                    elif slot == 3:
                        q_pool.append({
                            "question": f"When establishing automated testing and continuous delivery for codebases utilizing '{skill}', how do you balance unit tests, contract tests, and integration test coverage without sacrificing build velocity?",
                            "category": "technical",
                            "resume_reference": f"Testing & CI/CD: {skill}",
                            "context_hint": "Discuss the test pyramid, mock vs live test doubles, hermetic test containers, and CI pipeline stages.",
                            "ideal_answer_points": [
                                "Proper distribution across the testing pyramid (unit, integration, e2e)",
                                "Effective isolation using test containers or mocks",
                                "Continuous integration gatekeeping and regression prevention"
                            ]
                        })
                    else:
                        q_pool.append({
                            "question": f"How do you instrument observability, APM distributed tracing, and real-time alerting for services built with '{skill}' to detect latency anomalies before users report them?",
                            "category": "technical",
                            "resume_reference": f"Observability: {skill}",
                            "context_hint": "Discuss OpenTelemetry, p95/p99 latency percentiles, structured JSON logging, and error budgets.",
                            "ideal_answer_points": [
                                "Instrumentation using OpenTelemetry or distributed trace spans",
                                "Tracking tail latency percentiles (p95/p99) and saturation",
                                "Actionable alerting strategies avoiding alert fatigue"
                            ]
                        })

        # =========================================================================
        # 3. MODE: BEHAVIORAL (STAR METHOD) ('behavioral_star')
        # =========================================================================
        elif interview_type == "behavioral_star":
            if experience:
                exp = experience[0]
                comp = exp.get("company_or_org", "your past team") if isinstance(exp, dict) else "your team"
                role = exp.get("role", "your role") if isinstance(exp, dict) else "your role"
                ref_prefix = f"Experience: {role} at {comp}"
            else:
                ref_prefix = "Leadership & Professional Ownership"

            if dom_category == "business_management":
                q_pool.append({
                    "question": "Tell me about a time when you strongly disagreed with a senior executive or cross-functional stakeholder regarding a strategic initiative or resource allocation. How did you navigate the discussion, present data-backed alternatives, and reach consensus?",
                    "category": "behavioral_star",
                    "resume_reference": f"{ref_prefix} - Stakeholder Negotiation",
                    "context_hint": "Use STAR: Situation (the strategic disagreement), Task (the business objective), Action (data analysis, stakeholder interviews, trade-off presentation), and Result (the consensus reached).",
                    "ideal_answer_points": [
                        "Situation: Clear strategic dispute with leadership or cross-functional team",
                        "Task: Goal of aligning priorities without alienating stakeholders",
                        "Action: Data-driven presentations, objective ROI comparisons, and active listening",
                        "Result: Successful project greenlight and strengthened executive alignment"
                    ]
                })

                q_pool.append({
                    "question": "Describe a major business initiative or operational deliverable where you faced severe deadline crunches, sudden budget cuts, or supply chain bottlenecks. How did you reprioritize deliverables, manage stakeholder expectations, and deliver?",
                    "category": "behavioral_star",
                    "resume_reference": f"{ref_prefix} - High Pressure Delivery",
                    "context_hint": "Use STAR: Detail the triage methodology, resource reallocations, executive status communications, and the business outcome.",
                    "ideal_answer_points": [
                        "Situation: Urgent operational crisis or sudden resource reduction",
                        "Task: Preserve core deliverables and customer SLAs within constraints",
                        "Action: Decisive prioritization, transparent stakeholder updates, and agile reallocations",
                        "Result: On-time delivery meeting critical KPIs with zero client churn"
                    ]
                })

                q_pool.append({
                    "question": "Tell me about a project where market conditions, client requirements, or business objectives were highly ambiguous or constantly shifting. How did you define milestone roadmaps, validate assumptions, and keep team momentum?",
                    "category": "behavioral_star",
                    "resume_reference": f"{ref_prefix} - Managing Ambiguity",
                    "context_hint": "Use STAR: Explain how you gathered customer discovery data, established iterative OKRs, and drove clarity.",
                    "ideal_answer_points": [
                        "Situation: High market uncertainty or shifting business scope",
                        "Task: Establish clarity and an actionable roadmap for the team",
                        "Action: Customer feedback loops, phased milestone delivery, and risk gates",
                        "Result: Delivered high-impact business solution meeting market demand"
                    ]
                })

                q_pool.append({
                    "question": "Tell me about a time when you proactively identified a significant operational inefficiency, revenue leakage, or process bottleneck in your organization and spearheaded a solution without being asked.",
                    "category": "behavioral_star",
                    "resume_reference": f"{ref_prefix} - Proactive Business Leadership",
                    "context_hint": "Use STAR: Detail the inefficiency discovered, how you built the business case, your implementation steps, and quantifiable benefits.",
                    "ideal_answer_points": [
                        "Situation: Latent operational waste, manual bottleneck, or missed revenue",
                        "Task: Proactively design a streamlined workflow or revenue strategy",
                        "Action: Cross-functional coordination, process automation, and rollout",
                        "Result: Quantifiable cost savings, revenue uplift, or hours saved"
                    ]
                })

                q_pool.append({
                    "question": "Give an example of a time when you received tough critical feedback on a proposal, business case, or strategy presentation from senior management. How did you process that critique, refine your strategy, and adapt?",
                    "category": "behavioral_star",
                    "resume_reference": f"{ref_prefix} - Executive Feedback & Growth",
                    "context_hint": "Use STAR: Focus on constructive listening, objective data refinement, and presenting an enhanced proposal.",
                    "ideal_answer_points": [
                        "Situation: Critical pushback on business case assumptions or financial forecasts",
                        "Task: Absorb feedback objectively and stress-test the model",
                        "Action: Gather supplementary market data, revise projections, and re-engage",
                        "Result: Approval of refined strategy and enhanced leadership credibility"
                    ]
                })

            else:
                # Standard Professional / Technical STAR
                q_pool.append({
                    "question": "Tell me about a time when you strongly disagreed with a teammate or senior lead on a key implementation or methodology choice. How did you navigate the discussion, evaluate alternatives, and resolve the conflict?",
                    "category": "behavioral_star",
                    "resume_reference": f"{ref_prefix} - Conflict Resolution",
                    "context_hint": "Use the STAR method: Situation (the debate), Task (the objective), Action (data-driven trade-off analysis), and Result (the collaborative outcome).",
                    "ideal_answer_points": [
                        "Situation: Concrete technical or strategic disagreement with stakeholders",
                        "Task: Clear objective without interpersonal friction",
                        "Action: Objective comparison, benchmark testing, and respectful communication",
                        "Result: Successful delivery and strengthened team consensus"
                    ]
                })

                q_pool.append({
                    "question": "Describe a critical high-stakes deadline crunch, sudden project blocker, or emergency you faced. How did you prioritize tasks, communicate status under pressure, and achieve resolution?",
                    "category": "behavioral_star",
                    "resume_reference": f"{ref_prefix} - High Pressure Delivery",
                    "context_hint": "Use STAR: Detail the triage process, root cause isolation, stakeholder updates, and safeguards established.",
                    "ideal_answer_points": [
                        "Situation: High urgency crunch or tight delivery constraint",
                        "Task: Mitigate impact immediately while diagnosing root cause",
                        "Action: Systematic troubleshooting, clear communication, and permanent safeguards",
                        "Result: Quantifiable outcome and post-incident prevention"
                    ]
                })

                q_pool.append({
                    "question": "Tell me about a project where the requirements or scope were highly ambiguous or constantly changing. How did you define milestones, validate assumptions, and maintain momentum?",
                    "category": "behavioral_star",
                    "resume_reference": f"{ref_prefix} - Managing Ambiguity",
                    "context_hint": "Use STAR: Explain how you broke down the problem, gathered requirements, and delivered iteratively.",
                    "ideal_answer_points": [
                        "Situation: Ambiguous specifications or changing requirements",
                        "Task: Clarify requirements and establish an actionable execution plan",
                        "Action: Iterative prototyping, user feedback loops, and milestone tracking",
                        "Result: Delivered functional system on schedule"
                    ]
                })

                q_pool.append({
                    "question": "Tell me about a time when you proactively identified a latent bottleneck, inefficiency, or missing quality check in your project and took initiative to fix it without being prompted.",
                    "category": "behavioral_star",
                    "resume_reference": f"{ref_prefix} - Proactive Ownership",
                    "context_hint": "Use STAR: Explain the problem identified, how you justified the effort, the implementation, and measurable benefits.",
                    "ideal_answer_points": [
                        "Situation: Latent inefficiency or manual toil",
                        "Task: Proactively design and implement an improved solution",
                        "Action: End-to-end development, testing, and rollout",
                        "Result: Measurable speedup, hours saved, or quality increase"
                    ]
                })

                q_pool.append({
                    "question": "Give an example of a time when you received tough constructive feedback on your work or proposal. How did you process that feedback, adapt your deliverable, and grow professionally?",
                    "category": "behavioral_star",
                    "resume_reference": f"{ref_prefix} - Growth Mindset & Feedback",
                    "context_hint": "Use STAR: Focus on openness to critique, objective adaptation, and continuous improvement.",
                    "ideal_answer_points": [
                        "Situation: Constructive critique on architecture, deliverable quality, or execution",
                        "Task: Absorb feedback objectively without defensiveness",
                        "Action: Refactor solution according to best practices and document learnings",
                        "Result: Higher quality deliverable and enhanced long-term skill"
                    ]
                })

        # =========================================================================
        # 4. MODE: COMPREHENSIVE MOCK INTERVIEW ('comprehensive')
        # =========================================================================
        else:
            top_skill = skills[0] if len(skills) > 0 else ("Strategic Planning" if dom_category == "business_management" else "Core Competency")
            second_skill = skills[1] if len(skills) > 1 else ("KPI Dashboards" if dom_category == "business_management" else "Operations")

            if dom_category == "business_management":
                # 1. Primary Project Strategy & Execution
                if projects:
                    p1_title, p1_tech = get_proj_info(projects[0])
                    q_pool.append({
                        "question": f"In your project '{p1_title}' ({p1_tech}), walk me through the strategic framework you designed. What were your most critical ROI/cost-benefit trade-offs, and why did you choose this operational model?",
                        "category": "project_deepdive",
                        "resume_reference": f"Project: {p1_title}",
                        "context_hint": "Detail strategic methodology, stakeholder alignment, operational model, and measurable ROI.",
                        "ideal_answer_points": [
                            "Clear strategic breakdown of the project roadmap",
                            "Sound justification for business model and resource allocation",
                            "Quantifiable business outcomes (revenue, margin, or efficiency)"
                        ]
                    })
                else:
                    q_pool.append({
                        "question": f"Walk me through how you design and execute a comprehensive strategic initiative using '{top_skill}'. How do you establish business cases, validate market assumptions, and align executive leadership?",
                        "category": "project_deepdive",
                        "resume_reference": f"Strategy: {top_skill}",
                        "context_hint": "Detail business problem formulation, financial justification, and stakeholder governance.",
                        "ideal_answer_points": [
                            "Comprehensive business case formulation",
                            "Stakeholder alignment and resource planning",
                            "Risk management and ROI tracking"
                        ]
                    })

                # 2. Domain Mastery Competency (Methodology & Analytics)
                q_pool.append({
                    "question": f"You list '{top_skill}' as one of your core competencies. What analytical frameworks (such as SWOT, Porter's Five Forces, PESTLE, or OKRs) do you apply to optimize decisions in {top_skill}?",
                    "category": "technical",
                    "resume_reference": f"Competency: {top_skill}",
                    "context_hint": "Focus on strategic frameworks, data-driven validation, and measurable performance metrics.",
                    "ideal_answer_points": [
                        f"Demonstrates deep conceptual understanding of {top_skill}",
                        "Mentions concrete analytical tools (market sizing, SWOT, OKRs, KPI dashboards)",
                        "Covers executive decision-making and risk mitigation"
                    ]
                })

                # 3. Operational Bottleneck / Secondary Initiative Governance
                if len(projects) > 1:
                    p2_title, p2_tech = get_proj_info(projects[1])
                    q_pool.append({
                        "question": f"Looking at your work on '{p2_title}', what was the most difficult operational bottleneck or stakeholder pushback you encountered, and how did you resolve it?",
                        "category": "project_deepdive",
                        "resume_reference": f"Project: {p2_title}",
                        "context_hint": "Explain root-cause diagnosis, stakeholder negotiation, and outcome verification.",
                        "ideal_answer_points": [
                            "Accurate diagnosis of the operational constraint",
                            "Stakeholder management and negotiation tactics",
                            "Measurable resolution and business impact"
                        ]
                    })
                else:
                    q_pool.append({
                        "question": f"How do you establish budgetary variance controls, KPI dashboards, and governance mechanisms when integrating '{top_skill}' with '{second_skill}' initiatives?",
                        "category": "technical",
                        "resume_reference": f"Governance: {second_skill}",
                        "context_hint": "Discuss variance tracking, leading vs lagging metrics, and executive reporting.",
                        "ideal_answer_points": [
                            "Budgetary control and variance analysis",
                            "KPI dashboard tracking and reporting cadence",
                            "Continuous process optimization"
                        ]
                    })

                # 4. STAR Behavioral Scenario (Stakeholder Leadership)
                q_pool.append({
                    "question": "Tell me about a time when you were leading a key business deliverable and faced severe deadline crunches, sudden budget cuts, or conflicting stakeholder demands. How did you prioritize, communicate, and deliver?",
                    "category": "behavioral_star",
                    "resume_reference": "Business Leadership & Stakeholder Management",
                    "context_hint": "Use the STAR method: Situation (the crisis/conflict), Task (your goal), Action (data-backed negotiations and agile reallocations), and Result (the business outcome).",
                    "ideal_answer_points": [
                        "Situation: Clear context with stakes and resource constraints",
                        "Task: Defined business objective and deliverables",
                        "Action: Decisive prioritization, transparent communications, and execution",
                        "Result: Successful delivery meeting KPIs and preserving stakeholder trust"
                    ]
                })

                # 5. Business Scaling / Organizational Change Management
                q_pool.append({
                    "question": f"Imagine you need to scale the initiatives you built using '{top_skill}' across an enterprise with 5x more regional divisions. What change management frameworks, governance policies, and performance dashboards would you implement?",
                    "category": "system_design",
                    "resume_reference": f"Scalability & Change Management: {top_skill}",
                    "context_hint": "Consider change management (Kotter/ADKAR), centralized KPI dashboards, training programs, and regional risk controls.",
                    "ideal_answer_points": [
                        "Structured change management and communication rollout",
                        "Standardized governance scorecards and regional dashboards",
                        "Risk mitigation against operational friction during scaling"
                    ]
                })

            else:
                # Standard / Software Comprehensive Pool
                if projects:
                    p1_title, p1_tech = get_proj_info(projects[0])
                    q_pool.append({
                        "question": f"In your resume project '{p1_title}' ({p1_tech}), walk me through the high-level architecture. What were the most critical engineering trade-offs you made, and why did you select this tech stack?",
                        "category": "project_deepdive",
                        "resume_reference": f"Project: {p1_title}",
                        "context_hint": "Detail system topology, database choices, component interactions, and measurable impact.",
                        "ideal_answer_points": [
                            "Clear architectural breakdown across layers",
                            "Sound justification for technology and design choices",
                            "Quantifiable outcomes or performance characteristics"
                        ]
                    })
                else:
                    q_pool.append({
                        "question": f"Walk me through the architecture and design of a key application you built with {top_skill}. How did you structure your components and data flow?",
                        "category": "project_deepdive",
                        "resume_reference": f"Architecture: {top_skill}",
                        "context_hint": "Detail system boundaries, data persistence, and API integration.",
                        "ideal_answer_points": [
                            "Component separation of concerns",
                            "Data flow and state management",
                            "Error resilience"
                        ]
                    })

                # 2. Technical Skill Deep Concept
                q_pool.append({
                    "question": f"You listed '{top_skill}' as one of your core skills. How do you approach concurrency, asynchronous execution, and memory optimization when developing with {top_skill}?",
                    "category": "technical",
                    "resume_reference": f"Skill: {top_skill}",
                    "context_hint": "Focus on profiling bottlenecks, async/await patterns, caching, and exception handling.",
                    "ideal_answer_points": [
                        f"Demonstrates deep idiomatic understanding of {top_skill}",
                        "Mentions concrete optimization techniques (caching, connection pools, async pipelines)",
                        "Covers structured error handling and resilience"
                    ]
                })

                # 3. Secondary Project Bottleneck
                if len(projects) > 1:
                    p2_title, p2_tech = get_proj_info(projects[1])
                    q_pool.append({
                        "question": f"Looking at your work on '{p2_title}', what was the most difficult technical bottleneck or race condition you encountered, and how did you debug and verify the fix?",
                        "category": "project_deepdive",
                        "resume_reference": f"Project: {p2_title}",
                        "context_hint": "Explain root-cause analysis, debugging tools used, and automated verification.",
                        "ideal_answer_points": [
                            "Accurate diagnosis of the root cause",
                            "Isolation using profiling/logging/debuggers",
                            "Verification through regression testing"
                        ]
                    })
                else:
                    q_pool.append({
                        "question": f"How do you design, secure, and optimize database queries and APIs when connecting {top_skill} services with {second_skill} databases?",
                        "category": "technical",
                        "resume_reference": f"Integration: {second_skill}",
                        "context_hint": "Discuss query optimization, indexing, authentication, and validation.",
                        "ideal_answer_points": [
                            "Database indexing and connection pooling",
                            "Input validation and API security",
                            "Query execution plan optimization"
                        ]
                    })

                # 4. STAR Behavioral Scenario
                q_pool.append({
                    "question": "Tell me about a time when you were working on a critical feature deliverable and encountered unexpected blocking bugs or conflicting technical requirements. How did you prioritize, communicate, and deliver?",
                    "category": "behavioral_star",
                    "resume_reference": "Engineering Ownership & Team Collaboration",
                    "context_hint": "Use the STAR method: Situation (the blocker), Task (your goal), Action (technical & communication steps), and Result (the outcome).",
                    "ideal_answer_points": [
                        "Situation: Clear context with stakes and constraints",
                        "Task: Defined objective and deliverables",
                        "Action: Concrete technical troubleshooting and stakeholder updates",
                        "Result: Successful delivery and team takeaways"
                    ]
                })

                # 5. System Design / Scalability
                q_pool.append({
                    "question": f"Imagine you need to scale the services you built using {top_skill} to support 100x traffic volume with zero downtime. What caching layers, message queues, and database scaling strategies would you introduce and why?",
                    "category": "system_design",
                    "resume_reference": f"Scalability: {top_skill}",
                    "context_hint": "Consider Redis/Kafka, horizontal scaling, database read replicas, and stateless workers.",
                    "ideal_answer_points": [
                        "Decoupling asynchronous tasks with pub/sub or message brokers",
                        "Multi-tier caching and database read/write splitting",
                        "Idempotency, circuit breakers, and rate limiting"
                    ]
                })

        # Shuffle pool to ensure random variety
        random.shuffle(q_pool)

        # Filter out questions that are similar to any questions asked in prior sessions
        selected: List[Dict[str, Any]] = []
        for item in q_pool:
            q_text = item.get("question", "")
            if not cls._is_similar_to_past(q_text, past_questions):
                selected.append(item)
            if len(selected) >= num_questions:
                break

        # If we need more questions because past sessions consumed standard pool, dynamically synthesize twisted zig-zag questions
        if len(selected) < num_questions:
            needed = num_questions - len(selected)
            synthetic_questions = cls._synthesize_procedural_twisted_questions(
                facts=facts,
                target_role=target_role,
                interview_type=interview_type,
                difficulty=difficulty,
                count_needed=needed,
                past_questions=(past_questions or []) + [s["question"] for s in selected],
                dom_category=dom_category
            )
            selected.extend(synthetic_questions)

        # Fallback safeguard if candidate has taken extreme number of sessions
        if len(selected) < num_questions and q_pool:
            for item in q_pool:
                if item not in selected:
                    selected.append(item)
                if len(selected) >= num_questions:
                    break

        result = []
        for i, item in enumerate(selected[:num_questions]):
            result.append({
                "id": f"q_{i+1}_{uuid.uuid4().hex[:6]}",
                "index": i + 1,
                "question": item["question"],
                "category": item.get("category", interview_type),
                "resume_reference": item.get("resume_reference"),
                "context_hint": item.get("context_hint"),
                "ideal_answer_points": item.get("ideal_answer_points", []),
                "user_answer": None,
                "score": None,
                "feedback": None,
                "strengths": [],
                "improvements": [],
                "star_breakdown": None,
                "model_answer_snippet": None
            })
        return result

    @classmethod
    def _synthesize_procedural_twisted_questions(
        cls,
        facts: Dict[str, Any],
        target_role: str,
        interview_type: str,
        difficulty: str,
        count_needed: int,
        past_questions: Optional[List[str]],
        dom_category: str
    ) -> List[Dict[str, Any]]:
        """Procedurally generate non-repetitive, twisted, zig-zag interview questions testing adversarial edge-cases, trade-offs, and unexpected failure modes."""
        import random
        skills = facts.get("skills") or ["Core Architecture", "System Design", "Strategic Operations", "Performance Optimization"]
        projects = facts.get("projects") or []
        experience = facts.get("experience") or []

        def get_p_name(idx):
            if projects and idx < len(projects):
                p = projects[idx]
                if isinstance(p, dict):
                    return p.get("title") or p.get("name") or f"Project #{idx+1}"
                return str(p)
            return "your flagship project"

        p0 = get_p_name(0)
        p1 = get_p_name(1) if len(projects) > 1 else p0
        s0 = skills[0] if len(skills) > 0 else "System Architecture"
        s1 = skills[1] if len(skills) > 1 else s0
        s2 = skills[2] if len(skills) > 2 else s0

        candidates: List[Dict[str, Any]] = []

        if interview_type in ["project_deepdive", "resume_project"]:
            # Zig-zag project curveballs
            candidates.extend([
                {
                    "question": f"In '{p0}', imagine a sudden security audit exposes an unpatched critical vulnerability in your core dependency. You have 48 hours to replace it without degrading latency or introducing data loss. What is your exact step-by-step containment and cutover plan?",
                    "category": "project_deepdive",
                    "resume_reference": f"Emergency Architecture: {p0}",
                    "context_hint": "Break down containment, zero-downtime migration, dual-write validation, and rollback checkpoints.",
                    "ideal_answer_points": ["Incident containment and risk isolation", "Shadow validation or blue-green cutover", "Data integrity verification post-migration"]
                },
                {
                    "question": f"Looking back at '{p0}', if your infrastructure team unexpectedly suffered a 70% budget reduction overnight while daily active traffic doubled, what deliberate technical sacrifices or architectural trade-offs would you have enforced?",
                    "category": "project_deepdive",
                    "resume_reference": f"High-Pressure Trade-offs: {p0}",
                    "context_hint": "Discuss aggressive caching, lossy data sampling, asynchronous shedding, and disabling non-critical services.",
                    "ideal_answer_points": ["Prioritization of critical path vs non-essential services", "Cost optimization via caching and compute downsizing", "Graceful degradation under resource starvation"]
                },
                {
                    "question": f"Walk me through the single most insidious, silent failure mode that could occur in '{p1}'—a bug or data corruption scenario that would NOT trigger any 500 error alerts or crash logs.",
                    "category": "project_deepdive",
                    "resume_reference": f"Silent Failure Analysis: {p1}",
                    "context_hint": "Focus on race conditions, eventual consistency drift, precision loss, or partial batch rollbacks.",
                    "ideal_answer_points": ["Identification of subtle data inconsistency or edge condition", "Defensive validation and reconciliation jobs", "Telemetry and anomaly detection strategies"]
                },
                {
                    "question": f"If an external architect audited '{p0}' and claimed your chosen architecture was over-engineered and fragile compared to a monolithic approach, how would you empirically counter or validate their critique?",
                    "category": "project_deepdive",
                    "resume_reference": f"Architectural Defense: {p0}",
                    "context_hint": "Use latency benchmarks, deployment velocity metrics, fault domain isolation, and operational maintenance costs.",
                    "ideal_answer_points": ["Objective architectural justification with empirical metrics", "Honest acknowledgment of unnecessary complexity where valid", "Evaluation of operational cognitive load on the engineering team"]
                },
                {
                    "question": f"In '{p0}', what happens if two concurrent workflows execute identical state transitions simultaneously? Did you implement optimistic locking, pessimistic distributed locks, or idempotency keys, and where could that design break down?",
                    "category": "project_deepdive",
                    "resume_reference": f"Concurrency & Idempotency: {p0}",
                    "context_hint": "Explain race conditions, lock timeouts, deadlock mitigation, and distributed transaction semantics.",
                    "ideal_answer_points": ["Explanation of concurrency control mechanisms used", "Edge-case analysis of distributed lock expiration or network partition", "Idempotency enforcement across retries"]
                }
            ])

        elif interview_type == "technical":
            # Zig-zag technical curveballs
            candidates.extend([
                {
                    "question": f"When executing high-throughput workloads with '{s0}', a downstream service enters an unresponsive 45-second silent hang instead of throwing a fast error. How do you prevent thread pool exhaustion and cascading failure across the entire system?",
                    "category": "technical",
                    "resume_reference": f"Resilience Engineering: {s0}",
                    "context_hint": "Discuss circuit breakers, timeout budgets, bulkhead isolation, and reactive backpressure.",
                    "ideal_answer_points": ["Bulkhead thread pool isolation", "Dynamic circuit breakers with exponential backoff", "Proactive request deadline propagation"]
                },
                {
                    "question": f"Suppose a malicious client exploits an algorithmic complexity weakness (such as quadratic parsing or regex backtracking) against your '{s0}' endpoint, spiking CPU to 100%. How would you trace, mitigate, and architecturally defend against this ReDoS/complexity attack?",
                    "category": "technical",
                    "resume_reference": f"Adversarial Defense: {s0}",
                    "context_hint": "Focus on input length caps, streaming parsers, worker execution timeouts, and rate-limiting tiers.",
                    "ideal_answer_points": ["Root cause isolation using CPU profiling", "Defensive parser design with strict payload limits", "WAF and API gateway rate limiting with token buckets"]
                },
                {
                    "question": f"You need to maintain zero-downtime database schema migrations for a large relational table managed with '{s1}'. How do you add a non-nullable indexed column with millions of existing rows without taking table locks or causing replication lag?",
                    "category": "technical",
                    "resume_reference": f"Zero-Downtime Data Architecture: {s1}",
                    "context_hint": "Explain expand-and-contract pattern: nullable column addition, background backfill, dual-writing, and eventual constraint application.",
                    "ideal_answer_points": ["Expand and contract migration pattern", "Background batched data backfill without row lock contention", "Zero-downtime column constraint validation"]
                },
                {
                    "question": f"Explain a concrete scenario in '{s2}' where an abstraction or 'best-practice' design pattern actually harmed runtime performance or created subtle memory leaks. How did you diagnose it?",
                    "category": "technical",
                    "resume_reference": f"Deep Diagnostics: {s2}",
                    "context_hint": "Discuss premature abstraction, object allocation churn, event listener leakage, or unclosed file descriptors.",
                    "ideal_answer_points": ["Identification of leaky abstraction or excessive object allocation", "Diagnostic tooling (heap dumps, profilers, flamegraphs)", "Pragmatic simplification of architecture"]
                },
                {
                    "question": f"If you had to scale a service built on '{s0}' to handle a 50x sudden traffic spike during a flash event, what specific caching invalidation strategy and cache stampede protection (e.g. mutex locks, probabilistic early expiration) would you implement?",
                    "category": "technical",
                    "resume_reference": f"Scale & Cache Invalidation: {s0}",
                    "context_hint": "Discuss the thundering herd problem, single-flight request coalescing, and cache warm-up pipelines.",
                    "ideal_answer_points": ["Cache stampede mitigation (mutex locking / singleflight)", "Probabilistic early expiration (XFetch algorithm)", "Graceful fallback to stale data while refreshing"]
                }
            ])

        elif interview_type == "behavioral_star":
            # Zig-zag behavioral curveballs
            candidates.extend([
                {
                    "question": "Tell me about a high-visibility mistake you personally made in a project—such as a flawed assumption, a breaking configuration, or a missed edge-case. How did you handle reporting it to your team in real time, and what safeguard did you implement?",
                    "category": "behavioral_star",
                    "resume_reference": "Personal Accountability & Blameless Post-Mortem",
                    "context_hint": "Use STAR: Situation (the incident), Task (immediate containment), Action (transparent communication & root-cause fix), Result (strengthened team resilience).",
                    "ideal_answer_points": ["Radical transparency without blame-shifting", "Swift incident containment under pressure", "Implementation of permanent preventative guardrails"]
                },
                {
                    "question": "Describe a scenario where a product manager or executive demanded an aggressive feature launch, but you knew the implementation had severe architectural debt that would destabilize production. How did you articulate the risk and negotiate the compromise?",
                    "category": "behavioral_star",
                    "resume_reference": "Executive Stakeholder Negotiation",
                    "context_hint": "Use STAR: Explain the conflict between business velocity and technical stability, how you framed the risk in business terms, and the agreed phased roadmap.",
                    "ideal_answer_points": ["Translating technical risk into business impact (downtime risk, churn, cost)", "Constructive negotiation instead of rigid pushback", "Phased delivery plan balancing speed with reliability"]
                },
                {
                    "question": "Tell me about a situation where you and another experienced peer had irreconcilable technical philosophies on an architecture choice. When neither side gave way, how did you break the deadlock objectively?",
                    "category": "behavioral_star",
                    "resume_reference": "Technical Deadlock Resolution",
                    "context_hint": "Use STAR: Detail the competing paradigms, the empirical benchmark or spike created to test hypotheses, and how consensus was preserved.",
                    "ideal_answer_points": ["Objective proof-of-concept / spike to replace opinion with data", "Preserving professional respect and team psychological safety", "Committing fully once a consensus decision was chosen"]
                },
                {
                    "question": "Describe an instance where a third-party dependency, vendor service, or external contractor completely failed to deliver on their SLA just weeks before your go-live. How did you pivot your strategy to keep the launch on track?",
                    "category": "behavioral_star",
                    "resume_reference": "Crisis Management & Rapid Pivoting",
                    "context_hint": "Use STAR: Focus on rapid triage, building internal stopgaps or fallback adaptors, and communicating transparently with leadership.",
                    "ideal_answer_points": ["Rapid assessment of failure impact", "Creative fallback or lightweight in-house replacement", "Delivering core value despite external vendor collapse"]
                }
            ])

        else:
            # Comprehensive twisted curveballs
            candidates.extend([
                {
                    "question": f"In your work with '{s0}', what is the most dangerous failure mode under peak stress, and how did you guarantee graceful degradation rather than an all-or-nothing service crash?",
                    "category": "technical",
                    "resume_reference": f"Deep Resilience: {s0}",
                    "context_hint": "Explain backpressure, load shedding, and decoupled queues.",
                    "ideal_answer_points": ["Understanding failure modes under high load", "Load shedding and queue limits", "Observability and alerting"]
                },
                {
                    "question": f"Looking at '{p0}', if you were tasked with migrating this entire system to a zero-trust architecture with end-to-end encryption in transit and at rest, what bottlenecks would emerge and how would you resolve them?",
                    "category": "project_deepdive",
                    "resume_reference": f"Security Architecture: {p0}",
                    "context_hint": "Discuss TLS handshake overhead, key rotation pipelines, and secure secret vaults.",
                    "ideal_answer_points": ["Zero-trust principles applied to {p0}", "Performance trade-offs of continuous cryptographic verification", "Automated credential and certificate rotation"]
                },
                {
                    "question": "Tell me about a time when you received contradictory requirements from two different senior stakeholders. How did you resolve the ambiguity and align both parties without delaying the milestone?",
                    "category": "behavioral_star",
                    "resume_reference": "Cross-Functional Alignment",
                    "context_hint": "Use STAR: Focus on active listening, identifying core underlying incentives, and facilitating an alignment workshop.",
                    "ideal_answer_points": ["Uncovering underlying business priorities", "Synthesizing a balanced proposal", "Achieving explicit stakeholder sign-off"]
                },
                {
                    "question": f"How would you re-architect the data flow between '{s0}' and '{s1}' if data latency between regions surged to 350ms? What consistency model (strong vs eventual) would you adopt and why?",
                    "category": "system_design",
                    "resume_reference": f"Distributed Latency: {s0} & {s1}",
                    "context_hint": "Consider CAP theorem implications, CRDTs, optimistic UI updates, and conflict resolution rules.",
                    "ideal_answer_points": ["CAP theorem trade-off analysis in high-latency network", "Eventual consistency and conflict resolution strategy", "User experience preservation despite network delay"]
                }
            ])

        random.shuffle(candidates)
        selected_synthetic: List[Dict[str, Any]] = []

        for c in candidates:
            if not cls._is_similar_to_past(c["question"], past_questions):
                selected_synthetic.append(c)
            if len(selected_synthetic) >= count_needed:
                break

        # If still short, append with unique seed qualifiers
        while len(selected_synthetic) < count_needed:
            iter_id = uuid.uuid4().hex[:4]
            selected_synthetic.append({
                "question": f"Twisted Challenge [{iter_id.upper()}]: Suppose your implementation of '{s0}' in '{p0}' encounters an intermittent 1% packet loss combined with memory pressure. How would you isolate whether the root cause is garbage collection pauses or thread pool contention?",
                "category": interview_type,
                "resume_reference": f"Advanced Diagnostics: {s0}",
                "context_hint": "Discuss profiling tools, GC logging, thread dump analysis, and synthetic stress testing.",
                "ideal_answer_points": ["Differentiating GC pause spikes from I/O starvation", "Heap and thread profiling under load", "Root cause remediation"]
            })

        return selected_synthetic[:count_needed]

    @classmethod
    def evaluate_answer(
        cls,
        question_data: Dict[str, Any],
        user_answer: str,
        target_role: str = "Professional Specialist"
    ) -> Dict[str, Any]:
        """Evaluate candidate's answer with semantic accuracy verification matching question criteria rather than word count."""
        text = user_answer.strip()
        words = text.split()
        word_count = len(words)
        lower = text.lower()

        # Strict check for minimal / empty / evasive non-answers (< 6 words or trivial phrases)
        trivial_phrases = [
            "i don't know", "dont know", "no idea", "yes", "no", "ok", "okay", "pass", "skip",
            "python react", "good", "fine", "hello", "hi", "test", "i know it", "i did it",
            "i built it", "using code", "using python", "using react", "not sure", "i did it with python",
            "done with python", "i worked on it", "management strategy", "business done"
        ]
        
        # Domain indicator check across all fields
        domain_indicators = [
            "implemented", "architecture", "designed", "optimized", "redis", "database", "latency", "async", "cache",
            "because", "algorithm", "roi", "kpi", "swot", "budget", "variance", "strategy", "market", "revenue",
            "stakeholder", "lean", "agile", "okr", "crm", "cac", "ltv", "audit", "taxation", "gst", "balance sheet",
            "cad", "fea", "cfd", "gd&t", "bim", "revit", "staad", "embedded", "pcb", "vlsi", "clause", "indemnity",
            "contract", "clinical", "trial", "pharmacology", "figma", "usability", "wireframe", "sql", "tableau", "power bi"
        ]

        if word_count < 6 or any(lower == tp for tp in trivial_phrases) or (word_count < 8 and not any(k in lower for k in domain_indicators)):
            return {
                "score": 0.0,
                "is_correct": False,
                "verdict": "Incorrect / Non-Answer (0/100)",
                "feedback": "Answer is too minimal or non-substantive (less than 6 words or lacking methodology). In a professional interview, you must directly explain your actual methodology, reasoning, and concrete execution steps. 0 marks awarded.",
                "strengths": [],
                "improvements": [
                    "Answer the question directly by explaining your methodology and professional reasoning.",
                    "Provide concrete details addressing the specific concepts in the question."
                ],
                "star_breakdown": {
                    "situation": "Not provided",
                    "task": "Not provided",
                    "action": "Not provided",
                    "result": "Not provided"
                },
                "model_answer_snippet": question_data.get("ideal_answer_points", ["Provide a structured response detailing methodology and quantifiable outcomes."])[0] if question_data.get("ideal_answer_points") else "Provide a structured explanation detailing methodology choices."
            }

        model = cls._get_gemini_model()
        if model:
            try:
                prompt = f"""
You are a senior hiring manager and domain expert evaluating a candidate for '{target_role}'.
Evaluate the candidate's answer strictly based on FACTUAL ACCURACY, DOMAIN REASONING, METHODOLOGY, and DIRECT ALIGNMENT with the question criteria.

QUESTION:
{question_data.get('question')}

CATEGORY:
{question_data.get('category')}

RESUME CONTEXT:
{question_data.get('resume_reference')}

IDEAL ANSWER EXPECTATIONS / CRITERIA:
{json.dumps(question_data.get('ideal_answer_points', []))}

CANDIDATE'S ACTUAL ANSWER:
\"\"\"{user_answer}\"\"\"

STRICT ACCURACY-BASED SCORING RULES:
1. DO NOT SCORE BASED ON WORD COUNT OR ANSWER LENGTH. Score purely on whether the answer factually and accurately addresses the question and satisfies the expected criteria!
2. A concise, direct, and factually accurate answer (even 2-3 sentences) that accurately explains the domain concept, strategy, or methodology MUST receive a high score (80-95/100) with is_correct: true!
3. A verbose or wordy answer filled with fluff, buzzwords, or evasion that fails to address the question must receive a low score (10-35/100) with is_correct: false.
4. An incorrect, contradictory, or completely off-topic answer must receive 0/100 with is_correct: false.
5. If the answer is partially accurate (hits some points but misses essential mechanisms), award 40-60/100.

Return ONLY valid JSON matching this schema:
{{
  "is_correct": true | false,
  "score": 0.0 to 100.0,
  "verdict": "Incorrect (0/100)" | "Incomplete / Needs Work" | "Partially Correct" | "Correct & Solid" | "Exceptional",
  "feedback": "2-3 sentences stating whether the answer is domain-accurate, what was correct, and what was missing.",
  "strengths": [
    "Specific accurate methodology or conceptual point made"
  ],
  "improvements": [
    "Specific missing domain concept, trade-off, or metric needed"
  ],
  "star_breakdown": {{
    "situation": "Summary of situation or 'Not explicitly stated'",
    "task": "Summary of task or 'Not explicitly stated'",
    "action": "Concrete actions mentioned or 'Missing specific action'",
    "result": "Metrics stated or 'Missing quantitative result'"
  }},
  "model_answer_snippet": "A concise 2-sentence benchmark response demonstrating an ideal accurate candidate answer."
}}
"""
                response = model.generate_content(prompt)
                content = response.text.strip()
                if content.startswith("```json"):
                    content = content[7:]
                if content.endswith("```"):
                    content = content[:-3]
                parsed = json.loads(content.strip())
                if isinstance(parsed, dict) and "score" in parsed:
                    parsed["score"] = max(0.0, min(100.0, float(parsed["score"])))
                    if parsed["score"] < 50:
                        parsed["is_correct"] = False
                    return parsed
            except Exception as e:
                print(f"[WARN] Gemini answer evaluation failed, using domain accuracy grading: {e}")

        # Semantic Accuracy Deterministic Evaluator
        return cls._evaluate_answer_deterministic(question_data, user_answer)

    @classmethod
    def _evaluate_answer_deterministic(cls, question_data: Dict[str, Any], user_answer: str) -> Dict[str, Any]:
        """Deterministic semantic accuracy evaluation across all domains with zero word-count bias."""
        text = user_answer.strip()
        words = text.split()
        word_count = len(words)
        lower = text.lower()

        trivial_phrases = [
            "i don't know", "dont know", "no idea", "yes", "no", "ok", "okay", "pass", "skip",
            "python react", "good", "fine", "hello", "hi", "test", "i know it", "i did it",
            "i built it", "using code", "using python", "using react", "not sure", "i did it with python",
            "done with python", "i worked on it", "management strategy", "business done"
        ]

        # Extract core domain terms and expected technical points
        question_text = (question_data.get("question") or "").lower()
        ideal_points = question_data.get("ideal_answer_points") or []
        
        # Build set of key subject terms from question and criteria
        stop_words = {"which", "their", "about", "using", "should", "could", "would", "where", "there", "these", "those", "when", "what", "with", "your", "from", "that", "this", "have", "been", "were", "tell", "explain", "walk", "provide", "looking", "would"}
        
        key_target_terms = set()
        for ip in ideal_points:
            for w in ip.lower().replace(",", " ").replace(".", " ").replace("(", " ").replace(")", " ").replace("/", " ").replace("-", " ").split():
                if len(w) >= 3 and w not in stop_words and not w.isdigit():
                    key_target_terms.add(w)

        for w in question_text.replace(",", " ").replace(".", " ").replace("'", " ").replace("?", " ").replace("/", " ").replace("-", " ").split():
            if len(w) >= 4 and w not in stop_words:
                key_target_terms.add(w)

        # Count how many key target terms are accurately addressed in the candidate's answer
        matched_terms = [t for t in key_target_terms if t in lower]
        term_match_ratio = len(matched_terms) / max(1, min(len(key_target_terms), 10))

        # Action verbs across all domains
        action_keywords = [
            "implemented", "built", "designed", "created", "refactored", "optimized", "developed",
            "configured", "debugged", "resolved", "architected", "analyzed", "deployed", "scaled",
            "indexed", "cached", "tested", "isolated", "migrated", "managed", "negotiated",
            "formulated", "budgeted", "audited", "conducted", "modeled", "streamlined", "drafted",
            "executed", "led", "calculated", "simulated", "spearheaded", "evaluated", "standardized",
            "reconciled", "aligned", "prioritized", "facilitated", "forecasted", "mitigated"
        ]
        matched_actions = [w for w in action_keywords if w in lower]

        # Domain terms dictionary across all professional fields
        domain_vocabulary = [
            # Management & Business
            "roi", "kpi", "stakeholder", "swot", "budget", "variance", "strategy", "market", "revenue", "cost",
            "lean", "agile", "okr", "crm", "cac", "ltv", "margin", "risk", "mitigation", "operations",
            "supply chain", "conversion", "ebitda", "cash flow", "governance", "change management", "framework",
            "alignment", "deliverable", "milestone", "efficiency", "optimization", "process", "salesforce",
            "hubspot", "power bi", "tableau", "pestle", "scrum", "kanban", "waterfall", "churn",
            # Finance & Commerce
            "audit", "taxation", "gst", "balance sheet", "dcf", "valuation", "journal", "ledger", "depreciation",
            "working capital", "p&l", "gaap", "ifrs", "tally", "sap", "reconciliation", "equity", "asset", "liability",
            "ebit", "npv", "irr", "portfolio", "ratio",
            # Physical Engineering
            "cad", "solidworks", "ansys", "fea", "cfd", "gd&t", "tolerance", "stress", "strain", "thermal", "hvac",
            "revit", "bim", "staad", "etabs", "concrete", "structural", "surveying", "geotechnical", "pcb", "embedded",
            "microcontroller", "vlsi", "verilog", "vhdl", "circuit", "sensor", "plc", "scada", "cnc", "cam", "dfm", "dfa",
            # Law & Healthcare
            "clause", "indemnity", "liability", "arbitration", "jurisdiction", "statute", "compliance", "precedent",
            "due diligence", "litigation", "intellectual property", "trademark", "patent", "copyright", "contract",
            "clinical", "trial", "pharmacology", "protocol", "adverse", "gcp", "patient", "diagnostic", "pharmacovigilance",
            # Design & UI/UX
            "figma", "wireframe", "prototype", "usability", "design system", "wcag", "accessibility", "user research",
            "heuristic", "typography", "interaction", "information architecture", "persona", "journey map",
            # Software & Computing
            "api", "database", "cache", "redis", "async", "await", "schema", "architecture", "component",
            "state", "test", "docker", "pipeline", "query", "index", "latency", "security", "jwt",
            "model", "server", "algorithm", "microservice", "react", "fastapi", "sql", "git",
            "b-tree", "acid", "transaction", "isolation", "concurrency", "thread", "memory", "event loop",
            "pub/sub", "queue", "rabbitmq", "kafka", "trade-off", "bottleneck", "profiling", "star"
        ]
        matched_domain = [t for t in domain_vocabulary if t in lower]

        # Quantitative metrics detection
        has_metrics = any(char.isdigit() for char in text) or any(k in lower for k in ["percent", "%", "ms", "seconds", "users", "reduced", "increased", "improved", "saved", "scale", "qps", "throughput", "dollar", "inr", "crore", "lakh", "growth", "margin", "variance"])

        # Check minimal non-answer
        if word_count < 6 or any(lower == tp for tp in trivial_phrases) or (len(matched_terms) == 0 and len(matched_domain) == 0):
            return {
                "score": 0.0,
                "is_correct": False,
                "verdict": "Incorrect / Irrelevant (0/100)",
                "feedback": "The response does not address the core subject asked in the question. Zero marks (0/100) awarded.",
                "strengths": [],
                "improvements": [
                    "Directly address the core prompt with relevant domain methodologies and mechanisms.",
                    "Explain your decisions and concrete implementation details specifically matching the question."
                ],
                "star_breakdown": {
                    "situation": "Unclear / Irrelevant",
                    "task": "Unclear",
                    "action": "Missing relevant domain actions",
                    "result": "No relevant outcome"
                },
                "model_answer_snippet": "In my implementation, I established structured methodologies, aligned stakeholders, and delivered measurable business outcomes."
            }

        # Pure accuracy scoring (no word-length bonuses)
        # 1. Relevance & Subject Alignment (0 to 45 pts)
        relevance_score = min(45.0, len(matched_terms) * 11.0 + (term_match_ratio * 20.0))
        
        # 2. Domain Mechanism & Conceptual Precision (0 to 35 pts)
        domain_score = min(35.0, len(matched_domain) * 9.0)

        # 3. Practical Implementation / Actions / STAR Depth (0 to 20 pts)
        methodology_score = 0.0
        if matched_actions:
            methodology_score += min(12.0, len(matched_actions) * 6.0)
        if has_metrics:
            methodology_score += 8.0

        total_score = relevance_score + domain_score + methodology_score
        final_score = max(0.0, min(96.0, round(total_score, 1)))
        is_correct = final_score >= 50.0

        strengths = []
        improvements = []

        if matched_terms:
            strengths.append(f"Accurately addressed key concepts: {', '.join(matched_terms[:3])}.")
        if matched_domain:
            strengths.append(f"Demonstrated domain understanding of {', '.join(matched_domain[:3])}.")
        if has_metrics:
            strengths.append("Included quantitative impact and measurable outcomes.")
        if not strengths:
            strengths.append("Attempted the question with relevant terminology.")

        if not matched_actions:
            improvements.append("Detail the specific actions, methodologies, and decisions you executed.")
        if not has_metrics:
            improvements.append("Include quantitative metrics (e.g. ROI %, cost savings, cycle time, scale) to demonstrate impact.")
        if len(matched_terms) < 2:
            improvements.append("Deepen the explanation to address all aspects of the question prompt.")

        verdict = "Exceptional" if final_score >= 82 else ("Correct & Solid" if final_score >= 65 else ("Partially Correct" if final_score >= 45 else "Incomplete / Needs Work"))

        feedback = (
            f"Evaluated: {verdict} ({final_score}/100). " +
            ("Accurate response directly addressing the question criteria with solid domain grounding." if is_correct else "Answer partially touches on the topic but lacks essential precision, core methodologies, or measurable outcomes.")
        )

        return {
            "score": final_score,
            "is_correct": is_correct,
            "verdict": verdict,
            "feedback": feedback,
            "strengths": strengths,
            "improvements": improvements,
            "star_breakdown": {
                "situation": "Context established from candidate background",
                "task": "Objective stated",
                "action": f"Executed via {', '.join(matched_actions[:2]) if matched_actions else 'domain methodology'}",
                "result": "Measurable outcome referenced" if has_metrics else "Completed successfully; add metrics for higher impact"
            },
            "model_answer_snippet": f"In our initiative, I applied structured methodologies ({matched_domain[0] if matched_domain else 'best practices'}), achieving high quality execution and measurable ROI."
        }

    @classmethod
    def start_session(
        cls,
        db: Session,
        user: Optional[User],
        start_req: InterviewStartRequest
    ) -> InterviewSessionResponse:
        """Create new interview session with resume-grounded questions."""
        user_id = user.id if user else None
        student_profile_id = user.student_profile.id if (user and user.student_profile) else None

        # Extract facts from candidate's resume
        facts = cls._extract_resume_facts(db, user_id, student_profile_id, start_req.document_id)
        if start_req.resume_text:
            facts["raw_text_snippet"] = start_req.resume_text[:3000]

        target_role = start_req.target_role or facts.get("domain") or "Professional Specialist"
        interview_type = start_req.interview_type or "comprehensive"
        difficulty = start_req.difficulty or "intermediate"
        num_questions = start_req.num_questions or 5

        # Collect past questions to guarantee zero repetition across multiple mock interviews
        past_questions_set = set()
        if hasattr(start_req, "previous_questions") and start_req.previous_questions:
            for pq in start_req.previous_questions:
                if pq and isinstance(pq, str) and len(pq.strip()) > 8:
                    past_questions_set.add(pq.strip())

        if user_id:
            try:
                past_sessions = (
                    db.query(InterviewSession)
                    .filter(InterviewSession.user_id == user_id)
                    .order_by(InterviewSession.created_at.desc())
                    .limit(30)
                    .all()
                )
                for s in past_sessions:
                    if s.questions_json and isinstance(s.questions_json, list):
                        for q in s.questions_json:
                            if isinstance(q, dict) and q.get("question"):
                                past_questions_set.add(q.get("question").strip())
            except Exception as e:
                print(f"[WARN] Failed to fetch past interview questions: {e}")

        past_questions_list = list(past_questions_set)

        # Generate questions with strict anti-repetition and twisted zig-zag logic
        questions = cls.generate_interview_questions(
            facts=facts,
            target_role=target_role,
            interview_type=interview_type,
            difficulty=difficulty,
            num_questions=num_questions,
            past_questions=past_questions_list
        )

        # Create session in DB
        session = InterviewSession(
            user_id=user_id,
            student_profile_id=student_profile_id,
            document_id=start_req.document_id,
            target_role=target_role,
            interview_type=interview_type,
            difficulty=difficulty,
            total_questions=len(questions),
            status="in_progress",
            overall_score=0.0,
            questions_json=questions,
            created_at=datetime.now(timezone.utc)
        )
        db.add(session)
        db.commit()
        db.refresh(session)

        resp = cls._build_session_response(session)
        resp.resume_snapshot = facts
        return resp

    @classmethod
    def get_session(cls, db: Session, session_id: str) -> Optional[InterviewSessionResponse]:
        """Fetch session by ID."""
        session = db.query(InterviewSession).filter(InterviewSession.id == session_id).first()
        if not session:
            return None
        resp = cls._build_session_response(session)
        facts = cls._extract_resume_facts(db, session.user_id, session.student_profile_id, session.document_id)
        resp.resume_snapshot = facts
        return resp

    @classmethod
    def submit_answer(
        cls,
        db: Session,
        session_id: str,
        question_id: str,
        user_answer: str,
        audio_duration_seconds: int = 0
    ) -> QuestionEvaluationResponse:
        """Evaluate an answer to a single question and update the session state."""
        session = db.query(InterviewSession).filter(InterviewSession.id == session_id).first()
        if not session:
            raise ValueError("Interview session not found.")

        questions = list(session.questions_json or [])
        target_q = None
        target_idx = -1

        for idx, q in enumerate(questions):
            if q.get("id") == question_id or str(q.get("index")) == str(question_id):
                target_q = q
                target_idx = idx
                break

        if not target_q:
            raise ValueError(f"Question with ID '{question_id}' not found in this interview session.")

        # Run strict evaluation
        eval_result = cls.evaluate_answer(target_q, user_answer, session.target_role)

        # Update question in questions list
        target_q["user_answer"] = user_answer
        target_q["score"] = eval_result["score"]
        target_q["feedback"] = eval_result["feedback"]
        target_q["strengths"] = eval_result.get("strengths", [])
        target_q["improvements"] = eval_result.get("improvements", [])
        target_q["star_breakdown"] = eval_result.get("star_breakdown")
        target_q["model_answer_snippet"] = eval_result.get("model_answer_snippet")

        questions[target_idx] = target_q
        session.questions_json = questions
        flag_modified(session, "questions_json")

        db.commit()
        db.refresh(session)

        return QuestionEvaluationResponse(
            question_id=target_q.get("id", question_id),
            score=eval_result["score"],
            is_correct=eval_result.get("is_correct", True),
            verdict=eval_result.get("verdict", "Evaluated"),
            feedback=eval_result["feedback"],
            strengths=eval_result.get("strengths", []),
            improvements=eval_result.get("improvements", []),
            star_breakdown=eval_result.get("star_breakdown"),
            model_answer_snippet=eval_result.get("model_answer_snippet")
        )

    @classmethod
    def complete_session(
        cls,
        db: Session,
        session_id: str,
        duration_seconds: int = 0
    ) -> InterviewSessionResponse:
        """Finalize interview session, calculate overall marks and breakdown, and persist permanently."""
        session = db.query(InterviewSession).filter(InterviewSession.id == session_id).first()
        if not session:
            raise ValueError("Interview session not found.")

        questions = list(session.questions_json or [])
        answered = [q for q in questions if q.get("score") is not None]

        if not answered:
            overall = 0.0
            tech_score = 0.0
            comm_score = 0.0
            star_score = 0.0
            problem_score = 0.0
            auth_score = 0.0
        else:
            overall = sum(q.get("score", 0.0) for q in answered) / len(answered)
            
            tech_qs = [q for q in answered if q.get("category") in ["technical", "core_fundamentals"]]
            star_qs = [q for q in answered if q.get("category") in ["behavioral_star"]]
            proj_qs = [q for q in answered if q.get("category") in ["project_deepdive"]]
            sys_qs = [q for q in answered if q.get("category") in ["system_design"]]

            tech_score = sum(q.get("score", overall) for q in tech_qs) / len(tech_qs) if tech_qs else overall
            star_score = sum(q.get("score", overall) for q in star_qs) / len(star_qs) if star_qs else overall
            auth_score = sum(q.get("score", overall) for q in proj_qs) / len(proj_qs) if proj_qs else overall
            problem_score = sum(q.get("score", overall) for q in sys_qs) / len(sys_qs) if sys_qs else overall
            comm_score = min(100.0, (overall * 0.5) + (star_score * 0.5))

        overall_rounded = round(overall, 1)

        # Determine readiness level
        if overall_rounded >= 85:
            readiness = "Placement Ready"
        elif overall_rounded >= 72:
            readiness = "Strong Candidate"
        elif overall_rounded >= 55:
            readiness = "Developing"
        else:
            readiness = "Needs Preparation"

        # Aggregate unique strengths and improvements
        all_strengths = []
        all_improvements = []
        for q in answered:
            for s in q.get("strengths", []):
                if s not in all_strengths:
                    all_strengths.append(s)
            for imp in q.get("improvements", []):
                if imp not in all_improvements:
                    all_improvements.append(imp)

        summary_verdict = (
            f"Candidate achieved an overall interview performance score of {overall_rounded}/100 for {session.target_role}. "
            f"Status: {readiness}. Answered {len(answered)} of {len(questions)} questions."
        )

        session.overall_score = overall_rounded
        session.technical_score = round(tech_score, 1)
        session.communication_score = round(comm_score, 1)
        session.star_method_score = round(star_score, 1)
        session.problem_solving_score = round(problem_score, 1)
        session.resume_authenticity_score = round(auth_score, 1)
        session.readiness_level = readiness
        session.summary_verdict = summary_verdict
        session.strengths_json = all_strengths[:5]
        session.improvements_json = all_improvements[:5]
        session.key_takeaways_json = [
            f"Target Role: {session.target_role}",
            f"Readiness Status: {readiness}",
            f"Answered {len(answered)} of {len(questions)} questions"
        ]
        flag_modified(session, "strengths_json")
        flag_modified(session, "improvements_json")
        flag_modified(session, "key_takeaways_json")
        session.status = "completed"
        session.duration_seconds = duration_seconds or session.duration_seconds or 180
        session.completed_at = datetime.now(timezone.utc)

        db.commit()
        db.refresh(session)

        resp = cls._build_session_response(session)
        facts = cls._extract_resume_facts(db, session.user_id, session.student_profile_id, session.document_id)
        resp.resume_snapshot = facts
        return resp

    @classmethod
    def get_user_history(
        cls,
        db: Session,
        user: Optional[User]
    ) -> InterviewHistoryResponse:
        """Fetch all completed interviews for the user, computing score progression & averages."""
        if not user:
            return InterviewHistoryResponse(
                history=[],
                total_interviews=0,
                average_score=0.0,
                highest_score=0.0,
                score_trend=[],
                category_averages={"technical": 0.0, "communication": 0.0, "star_method": 0.0, "problem_solving": 0.0}
            )

        student_prof_id = user.student_profile.id if user.student_profile else None
        query = db.query(InterviewSession).filter(
            InterviewSession.status == "completed",
            (InterviewSession.user_id == user.id) | 
            (InterviewSession.student_profile_id == student_prof_id)
        )

        sessions = query.order_by(InterviewSession.created_at.desc()).all()

        if not sessions:
            return InterviewHistoryResponse(
                history=[],
                total_interviews=0,
                average_score=0.0,
                highest_score=0.0,
                score_trend=[],
                category_averages={"technical": 0.0, "communication": 0.0, "star_method": 0.0, "problem_solving": 0.0}
            )

        history_items = []
        total_score = 0.0
        highest_score = 0.0
        tech_sum = 0.0
        comm_sum = 0.0
        star_sum = 0.0
        prob_sum = 0.0

        trend_items = []

        for s in sessions:
            sc = s.overall_score or 0.0
            total_score += sc
            if sc > highest_score:
                highest_score = sc

            tech_sum += s.technical_score or sc
            comm_sum += s.communication_score or sc
            star_sum += s.star_method_score or sc
            prob_sum += s.problem_solving_score or sc

            history_items.append(InterviewScoreHistoryItem(
                id=s.id,
                target_role=s.target_role,
                interview_type=s.interview_type,
                difficulty=s.difficulty,
                overall_score=sc,
                technical_score=s.technical_score,
                communication_score=s.communication_score,
                star_method_score=s.star_method_score,
                readiness_level=s.readiness_level or "Developing",
                total_questions=s.total_questions,
                duration_seconds=s.duration_seconds or 0,
                created_at=s.created_at,
                completed_at=s.completed_at,
                strengths_count=len(s.strengths_json or []),
                improvements_count=len(s.improvements_json or [])
            ))

        # Build chronological score trend (oldest to newest)
        for s in reversed(sessions):
            trend_items.append({
                "date": s.created_at.strftime("%b %d, %H:%M") if s.created_at else "Recent",
                "score": s.overall_score or 0.0,
                "role": s.target_role,
                "type": s.interview_type
            })

        count = len(sessions)
        avg_score = round(total_score / count, 1)

        return InterviewHistoryResponse(
            history=history_items,
            total_interviews=count,
            average_score=avg_score,
            highest_score=round(highest_score, 1),
            score_trend=trend_items,
            category_averages={
                "technical": round(tech_sum / count, 1),
                "communication": round(comm_sum / count, 1),
                "star_method": round(star_sum / count, 1),
                "problem_solving": round(prob_sum / count, 1)
            }
        )

    @classmethod
    def delete_session(cls, db: Session, session_id: str, user: Optional[User]) -> bool:
        """Delete an interview session from history with strict user ownership validation."""
        if not user:
            return False
        query = db.query(InterviewSession).filter(
            InterviewSession.id == session_id,
            (
                (InterviewSession.user_id == user.id) | 
                (InterviewSession.student_profile_id == (user.student_profile.id if user.student_profile else None))
            )
        )
        session = query.first()
        if not session:
            return False

        db.delete(session)
        db.commit()
        return True

    @classmethod
    def _build_session_response(cls, session: InterviewSession) -> InterviewSessionResponse:
        """Helper to construct InterviewSessionResponse from DB model."""
        raw_qs = session.questions_json or []
        qs_list = []
        for q in raw_qs:
            qs_list.append(InterviewQuestionItem(
                id=q.get("id", str(uuid.uuid4())),
                index=q.get("index", 1),
                question=q.get("question", ""),
                category=q.get("category", "technical"),
                resume_reference=q.get("resume_reference"),
                context_hint=q.get("context_hint"),
                ideal_answer_points=q.get("ideal_answer_points", []),
                user_answer=q.get("user_answer"),
                score=q.get("score"),
                feedback=q.get("feedback"),
                strengths=q.get("strengths", []),
                improvements=q.get("improvements", []),
                star_breakdown=q.get("star_breakdown"),
                model_answer_snippet=q.get("model_answer_snippet")
            ))

        return InterviewSessionResponse(
            id=session.id,
            user_id=session.user_id,
            student_profile_id=session.student_profile_id,
            target_role=session.target_role,
            interview_type=session.interview_type,
            difficulty=session.difficulty,
            total_questions=session.total_questions,
            status=session.status,
            overall_score=session.overall_score or 0.0,
            technical_score=session.technical_score,
            communication_score=session.communication_score,
            star_method_score=session.star_method_score,
            problem_solving_score=session.problem_solving_score,
            resume_authenticity_score=session.resume_authenticity_score,
            readiness_level=session.readiness_level or "Developing",
            summary_verdict=session.summary_verdict,
            strengths=session.strengths_json or [],
            improvements=session.improvements_json or [],
            key_takeaways=session.key_takeaways_json or [],
            questions=qs_list,
            duration_seconds=session.duration_seconds or 0,
            created_at=session.created_at,
            completed_at=session.completed_at
        )
