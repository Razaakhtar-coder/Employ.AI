import type { LearningRoadmap, RoadmapMilestone, PlacementIntelligence, LearningPlatformResource } from '../types';
import { resolvePhaseYouTubeVideos } from './domainYouTubeData';
import { resolveCoDomainPhaseTemplates, computeStreamProgressStats, type StreamProgressStats, type CoDomainProgressItem } from './domainPhaseCurriculum';

export interface CoDomainDefinition {
  id: string;
  name: string;
  domain: string;
  category: string;
  is_emerging?: boolean;
  short_description: string;
  difficulty: 'Foundational' | 'Intermediate' | 'Advanced' | 'Expert';
}

// -------------------------------------------------------------
// Comprehensive Co-Domain Taxonomies across All Disciplines
// -------------------------------------------------------------
export const DOMAIN_CO_DOMAINS: Record<string, CoDomainDefinition[]> = {
  'Computer Science': [
    { id: 'cs-dsa', name: 'Data Structures & Algorithms (DSA)', domain: 'Computer Science', category: 'Core Theory', short_description: 'Big-O complexity, graphs (BFS/DFS), dynamic programming, trees, heaps, search.', difficulty: 'Foundational' },
    { id: 'cs-react', name: 'React & Next.js UI Architecture', domain: 'Computer Science', category: 'Frontend', short_description: 'Modern SPA development, Server Components, Hooks, Context, Virtual DOM reconciliation.', difficulty: 'Intermediate' },
    { id: 'cs-fastapi', name: 'FastAPI & Async Microservices', domain: 'Computer Science', category: 'Backend', short_description: 'High-throughput async REST endpoints, Pydantic validation, dependency injection, OpenAPI.', difficulty: 'Intermediate' },
    { id: 'cs-nodejs', name: 'Node.js & Express API Engines', domain: 'Computer Science', category: 'Backend', short_description: 'Event-loop concurrency, streaming I/O, middleware pipelines, JWT auth.', difficulty: 'Intermediate' },
    { id: 'cs-docker', name: 'Docker & Container Orchestration', domain: 'Computer Science', category: 'DevOps', short_description: 'Multi-stage builds, container isolation, docker-compose, image optimization, Kubernetes pods.', difficulty: 'Intermediate' },
    { id: 'cs-sql', name: 'SQL & Relational DB Modeling', domain: 'Computer Science', category: 'Databases', short_description: 'PostgreSQL, 3NF schema normalization, ACID transactions, complex CTEs, index tuning.', difficulty: 'Foundational' },
    { id: 'cs-cloud', name: 'Cloud Computing (AWS / GCP)', domain: 'Computer Science', category: 'Cloud', short_description: 'IAM security, EC2/ECS, S3, Serverless Lambda, API Gateway, CloudFront CDN.', difficulty: 'Advanced', is_emerging: true },
    { id: 'cs-sysdesign', name: 'System Design & Distributed Systems', domain: 'Computer Science', category: 'Architecture', short_description: 'Load balancers, caching layers, CAP theorem, database sharding, microservices.', difficulty: 'Advanced' },
    { id: 'cs-redis', name: 'Redis Caching & Message Queues', domain: 'Computer Science', category: 'Databases', short_description: 'In-memory data structures, pub/sub messaging, rate limiting, cache-aside patterns.', difficulty: 'Intermediate' },
    { id: 'cs-devops', name: 'DevOps & CI/CD Pipelines', domain: 'Computer Science', category: 'DevOps', short_description: 'GitHub Actions, automated test workflows, semantic release, container registry push.', difficulty: 'Intermediate', is_emerging: true },
    { id: 'cs-security', name: 'Cybersecurity & OAuth2 / JWT', domain: 'Computer Science', category: 'Security', short_description: 'Zero-trust architecture, OWASP Top 10 mitigation, token rotation, bcrypt, CORS.', difficulty: 'Advanced' },
    { id: 'cs-ts', name: 'TypeScript & Type Safety', domain: 'Computer Science', category: 'Frontend', short_description: 'Generics, discriminated unions, utility types, tsconfig optimization, runtime validation.', difficulty: 'Foundational' },
    { id: 'cs-fullstack', name: 'Fullstack Web Development (React & Node / Python)', domain: 'Computer Science', category: 'Fullstack', short_description: 'End-to-end fullstack architecture, REST/GraphQL APIs, database integration, auth, and cloud deployment.', difficulty: 'Intermediate' },
    { id: 'cs-python', name: 'Python Backend & Async Programming', domain: 'Computer Science', category: 'Backend', short_description: 'Asyncio event loops, generators, decorators, pytest suites, type hinting.', difficulty: 'Foundational' },
    { id: 'cs-ml', name: 'Applied Machine Learning & LLM Integration', domain: 'Computer Science', category: 'AI/ML', short_description: 'RAG pipelines, vector embeddings, LangChain, OpenAI/Gemini APIs, model fine-tuning.', difficulty: 'Advanced', is_emerging: true },
    { id: 'cs-graphql', name: 'GraphQL & Apollo Federation', domain: 'Computer Science', category: 'Backend', short_description: 'Schema definition, queries, mutations, resolvers, N+1 DataLoader batching.', difficulty: 'Intermediate' },
    { id: 'cs-nosql', name: 'NoSQL Databases (MongoDB / DynamoDB)', domain: 'Computer Science', category: 'Databases', short_description: 'Document data modeling, single-table design, sharding, replication, indexing.', difficulty: 'Intermediate' },
    { id: 'cs-kafka', name: 'Event-Driven Architecture (Kafka / RabbitMQ)', domain: 'Computer Science', category: 'Architecture', short_description: 'Event streaming, topic partitions, consumer groups, idempotency, dead-letter queues.', difficulty: 'Advanced', is_emerging: true },
    { id: 'cs-testing', name: 'Test-Driven Development (TDD / Pytest / Vitest)', domain: 'Computer Science', category: 'Quality', short_description: 'Unit tests, mocking, integration testing, end-to-end Playwright tests, coverage.', difficulty: 'Intermediate' }
  ],

  'MBBS': [
    { id: 'med-diagnostics', name: 'Clinical Diagnostics & Examination', domain: 'MBBS', category: 'Clinical Medicine', short_description: 'Comprehensive patient history taking, systemic physical examination, differential diagnosis.', difficulty: 'Foundational' },
    { id: 'med-radiology', name: 'Radiology & Imaging Interpretation', domain: 'MBBS', category: 'Diagnostics', short_description: 'Systematic reading of Chest X-Rays, Non-Contrast CT scans, Brain MRIs, Ultrasonography.', difficulty: 'Intermediate' },
    { id: 'med-lab', name: 'Laboratory Reports & Clinical Pathology', domain: 'MBBS', category: 'Diagnostics', short_description: 'CBC, arterial blood gases (ABG), renal/liver function panels, biomarker analysis.', difficulty: 'Foundational' },
    { id: 'med-emergency', name: 'Emergency Medicine & Trauma Care', domain: 'MBBS', category: 'Emergency', short_description: 'Acute trauma stabilization, triage protocols (ATLS), hypovolemic shock resuscitation.', difficulty: 'Advanced', is_emerging: true },
    { id: 'med-internal', name: 'Internal Medicine & Therapeutics', domain: 'MBBS', category: 'Clinical Medicine', short_description: 'Evidence-based management of hypertension, diabetes mellitus, COPD, sepsis, renal failure.', difficulty: 'Intermediate' },
    { id: 'med-ecg', name: 'Cardiology & 12-Lead ECG Analysis', domain: 'MBBS', category: 'Cardiology', short_description: 'Arrhythmia identification, STEMI/NSTEMI axis deviation, bundle branch blocks, ischemia.', difficulty: 'Intermediate' },
    { id: 'med-surgery', name: 'General Surgery & Minor OT Skills', domain: 'MBBS', category: 'Surgery', short_description: 'Aseptic scrubbing, local anesthesia, surgical suturing techniques, abscess drainage.', difficulty: 'Intermediate' },
    { id: 'med-pharma', name: 'Pharmacology & Prescription Writing', domain: 'MBBS', category: 'Therapeutics', short_description: 'Drug interactions, antibiotic stewardship, pharmacokinetics, dosage computation.', difficulty: 'Foundational' },
    { id: 'med-pediatrics', name: 'Pediatrics & Neonatal Resuscitation', domain: 'MBBS', category: 'Specialty', short_description: 'APGAR scoring, developmental milestones, pediatric dosing, immunization schedules.', difficulty: 'Intermediate' },
    { id: 'med-obgyn', name: 'Obstetrics & Gynecology (OB-GYN)', domain: 'MBBS', category: 'Specialty', short_description: 'Antenatal care, labor partograph monitoring, emergency obstetric hemorrhage management.', difficulty: 'Intermediate' },
    { id: 'med-icu', name: 'Critical Care & Hemodynamic Monitoring', domain: 'MBBS', category: 'Critical Care', short_description: 'Mechanical ventilator modes, vasopressor titration, central line care, sepsis bundles.', difficulty: 'Advanced', is_emerging: true },
    { id: 'med-bls', name: 'Basic & Advanced Life Support (BLS / ACLS)', domain: 'MBBS', category: 'Emergency', short_description: 'High-quality CPR, defibrillator operation, cardiac arrest shockable/non-shockable algorithms.', difficulty: 'Foundational' },
    { id: 'med-ethics', name: 'Medical Ethics & Medico-Legal Laws', domain: 'MBBS', category: 'Jurisprudence', short_description: 'Informed consent, medical negligence laws, patient confidentiality, death certification.', difficulty: 'Foundational' },
    { id: 'med-infectious', name: 'Infectious Diseases & Infection Control', domain: 'MBBS', category: 'Public Health', short_description: 'Nosocomial infection prevention, viral fever management, antimicrobial resistance.', difficulty: 'Intermediate' }
  ],

  'Nursing': [
    { id: 'nurs-care', name: 'Clinical Patient Care & Bedside Nursing', domain: 'Nursing', category: 'Patient Care', short_description: 'Vital signs assessment, hygiene, catheter care, IV infusion rates, fluid balance charts.', difficulty: 'Foundational' },
    { id: 'nurs-icu', name: 'ICU Hemodynamic & Ventilator Monitoring', domain: 'Nursing', category: 'Critical Care', short_description: 'Arterial line pressure monitoring, mechanical ventilator suctioning, vasoactive titrations.', difficulty: 'Advanced', is_emerging: true },
    { id: 'nurs-triage', name: 'Emergency Triage & Rapid Code Blue Response', domain: 'Nursing', category: 'Emergency', short_description: 'Emergency severity index (ESI), CPR/ACLS algorithms, defibrillator crash cart management.', difficulty: 'Intermediate' },
    { id: 'nurs-pharma', name: 'Medication Administration & 5 Rights Protocol', domain: 'Nursing', category: 'Pharmacology', short_description: '5 Rights of medication safety, pediatric dose calculations, high-alert drug protocols.', difficulty: 'Foundational' },
    { id: 'nurs-wound', name: 'Aseptic Wound Care & Post-Operative Dressing', domain: 'Nursing', category: 'Surgical', short_description: 'Sterile dressing technique, surgical drain maintenance, pressure ulcer staging.', difficulty: 'Intermediate' }
  ],

  'Business Analytics': [
    { id: 'ba-wrangling', name: 'Data Wrangling & ETL Pipelines', domain: 'Business Analytics', category: 'Data Engineering', short_description: 'Cleaning messy real-world datasets, handling missing values, regex parsing, Pandas transformations.', difficulty: 'Foundational' },
    { id: 'ba-excel', name: 'Advanced Excel & Financial Modeling', domain: 'Business Analytics', category: 'Spreadsheets', short_description: 'XLOOKUP, INDEX/MATCH, Dynamic Arrays, Pivot Tables, Power Query, scenario managers.', difficulty: 'Foundational' },
    { id: 'ba-sql', name: 'SQL & Relational Analytics', domain: 'Business Analytics', category: 'Databases', short_description: 'Window functions (RANK, LAG/LEAD), CTEs, self-joins, aggregations, database views.', difficulty: 'Intermediate' },
    { id: 'ba-powerbi', name: 'Power BI & DAX Dashboards', domain: 'Business Analytics', category: 'BI Visualization', short_description: 'Star schema modeling, complex DAX measures, row-level security, interactive executive reports.', difficulty: 'Intermediate' },
    { id: 'ba-tableau', name: 'Tableau Visual Analytics & Storytelling', domain: 'Business Analytics', category: 'BI Visualization', short_description: 'Calculated fields, Level of Detail (LOD) expressions, parameters, narrative dashboard design.', difficulty: 'Intermediate' },
    { id: 'ba-python', name: 'Python for Data Analysis (Pandas/NumPy)', domain: 'Business Analytics', category: 'Programming', short_description: 'Exploratory data analysis, statistical aggregations, vectorization, Seaborn charting.', difficulty: 'Intermediate' },
    { id: 'ba-brd', name: 'Business Requirements Gathering (BRD/FRD)', domain: 'Business Analytics', category: 'Consulting', short_description: 'Stakeholder discovery interviews, functional specs, user stories, acceptance criteria.', difficulty: 'Foundational' },
    { id: 'ba-bpmn', name: 'Business Process Modeling (BPMN 2.0)', domain: 'Business Analytics', category: 'Consulting', short_description: 'As-Is vs To-Be process mapping, bottleneck identification, workflow automation design.', difficulty: 'Intermediate' },
    { id: 'ba-stats', name: 'Statistical Testing & A/B Experimentation', domain: 'Business Analytics', category: 'Analytics', short_description: 'Hypothesis testing, p-values, t-tests, ANOVA, confidence intervals, sample sizing.', difficulty: 'Intermediate' },
    { id: 'ba-predictive', name: 'Predictive Machine Learning Modeling', domain: 'Business Analytics', category: 'Data Science', short_description: 'Linear/logistic regression, decision trees, customer churn prediction, model evaluation.', difficulty: 'Advanced', is_emerging: true },
    { id: 'ba-kpi', name: 'Financial KPI Analysis & Unit Economics', domain: 'Business Analytics', category: 'Strategy', short_description: 'CAC, LTV, churn rate, gross margins, Cohort retention analysis, EBITDA forecasting.', difficulty: 'Intermediate' },
    { id: 'ba-storytelling', name: 'Data Storytelling & Executive Presentations', domain: 'Business Analytics', category: 'Communication', short_description: 'Translating quantitative insights into C-suite strategic recommendations.', difficulty: 'Intermediate' }
  ],

  'BCOM': [
    { id: 'bcom-indas', name: 'Financial Accounting & Ind AS / IFRS', domain: 'BCOM', category: 'Accounting', short_description: 'Double-entry bookkeeping, trial balance, Balance Sheet preparation to Ind AS standards.', difficulty: 'Foundational' },
    { id: 'bcom-gst', name: 'Taxation & GST Return Filing (GSTR 1/3B/9)', domain: 'BCOM', category: 'Taxation', short_description: 'Input tax credit reconciliation, reverse charge mechanism, TDS/TCS, GST portal filings.', difficulty: 'Intermediate' },
    { id: 'bcom-audit', name: 'Statutory Auditing & Internal Assurance', domain: 'BCOM', category: 'Audit', short_description: 'Vouching, substantive verification, internal financial controls (IFC), CARO compliance.', difficulty: 'Intermediate' },
    { id: 'bcom-tally', name: 'TallyPrime & SAP ERP Financials', domain: 'BCOM', category: 'Accounting Software', short_description: 'Voucher creation, multi-currency invoicing, cost centers, inventory ledger reconciliation.', difficulty: 'Foundational' },
    { id: 'bcom-modeling', name: '3-Statement Financial Modeling in Excel', domain: 'BCOM', category: 'Corporate Finance', short_description: 'Dynamic linking of Income Statement, Balance Sheet, and Cash Flow with debt schedules.', difficulty: 'Advanced', is_emerging: true },
    { id: 'bcom-corpfin', name: 'Corporate Finance & Valuation (DCF / WACC)', domain: 'BCOM', category: 'Corporate Finance', short_description: 'Discounted Cash Flow, weighted average cost of capital, capital budgeting (NPV/IRR).', difficulty: 'Advanced' },
    { id: 'bcom-costing', name: 'Cost & Management Accounting', domain: 'BCOM', category: 'Costing', short_description: 'Marginal costing, break-even analysis, standard variance computations, budget variance.', difficulty: 'Intermediate' },
    { id: 'bcom-workingcap', name: 'Working Capital Management & Cash Forecasting', domain: 'BCOM', category: 'Treasury', short_description: 'Cash conversion cycle optimization, debtor aging, inventory turnover, treasury bills.', difficulty: 'Intermediate' },
    { id: 'bcom-directtax', name: 'Corporate Direct Taxation & ITR Computations', domain: 'BCOM', category: 'Taxation', short_description: 'PGBP income calculations, capital gains tax, MAT provisions, advance tax scheduling.', difficulty: 'Intermediate' },
    { id: 'bcom-compliancelaw', name: 'Company Law & MCA Statutory Filings', domain: 'BCOM', category: 'Legal/Corporate', short_description: 'Companies Act 2013 filings, ROC annual returns (MGT-7, AOC-4), board resolutions.', difficulty: 'Intermediate' }
  ],

  'BBA': [
    { id: 'bba-strategy', name: 'Business Strategy & Corporate OKRs', domain: 'BBA', category: 'Strategy', short_description: 'Competitive advantage analysis, SWOT/PESTLE frameworks, unit economics, market entry models.', difficulty: 'Foundational' },
    { id: 'bba-marketing', name: 'Brand Marketing & Digital Growth Funnels', domain: 'BBA', category: 'Marketing', short_description: 'Customer acquisition cost (CAC), LTV, search engine marketing, omni-channel campaigns.', difficulty: 'Intermediate' },
    { id: 'bba-productops', name: 'Product Operations & Lifecycle Management', domain: 'BBA', category: 'Product', short_description: 'Product-led growth (PLG), roadmap prioritization, feature backlog management, user journeys.', difficulty: 'Intermediate', is_emerging: true },
    { id: 'bba-hrm', name: 'Human Resource Management & Talent Acquisition', domain: 'BBA', category: 'HRM', short_description: 'Talent sourcing pipelines, performance appraisal systems, employee retention, labor laws.', difficulty: 'Foundational' },
    { id: 'bba-supplychain', name: 'Supply Chain Logistics & Operations', domain: 'BBA', category: 'Operations', short_description: 'Inventory management (EOQ, JIT), vendor SLA management, distribution network logistics.', difficulty: 'Intermediate' }
  ],

  'BA LLB': [
    { id: 'law-contracts', name: 'Commercial Contract Drafting & Redlining', domain: 'BA LLB', category: 'Commercial Law', short_description: 'Drafting MSAs, NDAs, SLAs, indemnity clauses, limitation of liability, dispute mechanics.', difficulty: 'Intermediate' },
    { id: 'law-corporate', name: 'Corporate Governance & Companies Act', domain: 'BA LLB', category: 'Corporate Law', short_description: 'Board compliance, director duties, shareholder agreements (SHA/SSA), SEBI disclosures.', difficulty: 'Intermediate' },
    { id: 'law-civil', name: 'Civil Litigation & Court Pleadings', domain: 'BA LLB', category: 'Litigation', short_description: 'Plaints, written statements, interim applications, CPC procedure, execution petitions.', difficulty: 'Foundational' },
    { id: 'law-criminal', name: 'Criminal Law & Bharatiya Nyaya Sanhita (BNS)', domain: 'BA LLB', category: 'Litigation', short_description: 'Bail applications, FIR filing, criminal trial procedures, evidentiary burden under BSA.', difficulty: 'Foundational' },
    { id: 'law-ipr', name: 'Intellectual Property (IPR & Patents)', domain: 'BA LLB', category: 'IP Law', short_description: 'Trademark filings, copyright infringement, patent prosecution, trade secret protection.', difficulty: 'Intermediate', is_emerging: true },
    { id: 'law-research', name: 'Legal Research & Precedent Synthesis', domain: 'BA LLB', category: 'Legal Tech', short_description: 'SCC Online, Manupatra citation analysis, legislative intent interpretation, legal memos.', difficulty: 'Foundational' },
    { id: 'law-adr', name: 'Dispute Resolution & Commercial Arbitration', domain: 'BA LLB', category: 'Arbitration', short_description: 'Arbitration agreements, Section 9/11/34 petitions, mediation settlements, UNCITRAL.', difficulty: 'Advanced' },
    { id: 'law-duediligence', name: 'M&A Legal Due Diligence Audits', domain: 'BA LLB', category: 'Corporate Law', short_description: 'Title verification, regulatory licenses, labor compliance audits, red-flag memo authoring.', difficulty: 'Advanced', is_emerging: true },
    { id: 'law-dpdp', name: 'Data Privacy Law (DPDP Act & GDPR)', domain: 'BA LLB', category: 'Tech Law', short_description: 'Consent frameworks, data fiduciary obligations, cross-border transfers, penalty analysis.', difficulty: 'Advanced', is_emerging: true },
    { id: 'law-fintech', name: 'FinTech & Banking Regulatory Compliance', domain: 'BA LLB', category: 'Regulatory', short_description: 'RBI digital lending guidelines, payment aggregator licenses, KYC/PMLA compliance.', difficulty: 'Advanced' }
  ],

  'Aeronautical': [
    { id: 'aero-aerodynamics', name: 'Aerodynamics & Airfoil Lift-Drag Polars', domain: 'Aeronautical', category: 'Aerodynamics', short_description: 'Subsonic/supersonic flows, boundary layer separation, NACA airfoil lift/drag curves.', difficulty: 'Foundational' },
    { id: 'aero-cfd', name: 'CFD Airflow Simulation (ANSYS Fluent)', domain: 'Aeronautical', category: 'Simulation', short_description: 'Mesh generation, boundary conditions, Navier-Stokes solvers, turbulence modeling (k-omega).', difficulty: 'Advanced' },
    { id: 'aero-structures', name: 'Aircraft Structural Mechanics & FEA', domain: 'Aeronautical', category: 'Structures', short_description: 'Wing spar bending, fuselage semi-monocoque stress analysis, composite laminates.', difficulty: 'Intermediate' },
    { id: 'aero-propulsion', name: 'Gas Turbine Propulsion & Jet Engines', domain: 'Aeronautical', category: 'Propulsion', short_description: 'Brayton thermodynamic cycle, turbofan bypass ratios, compressor blade aerodynamics.', difficulty: 'Intermediate' },
    { id: 'aero-stability', name: 'Flight Dynamics & Aircraft Stability Derivatives', domain: 'Aeronautical', category: 'Flight Mechanics', short_description: 'Longitudinal/lateral-directional dynamic stability, phugoid oscillation, trim states.', difficulty: 'Advanced' },
    { id: 'aero-avionics', name: 'Avionics & Digital Flight Control Systems', domain: 'Aeronautical', category: 'Avionics', short_description: 'Fly-by-wire architectures, ARINC 429 databus, autopilot control laws, Pitot-static systems.', difficulty: 'Intermediate' }
  ],

  'Aviation': [
    { id: 'av-ifr', name: 'Instrument Flight Rules (IFR) & Chart Navigation', domain: 'Aviation', category: 'Navigation', short_description: 'Jeppesen approach plates, SID/STAR procedures, VOR/ILS intercept, missed approach holds.', difficulty: 'Intermediate' },
    { id: 'av-fms', name: 'Flight Management Systems (FMS / MCDU)', domain: 'Aviation', category: 'Cockpit Systems', short_description: 'Route waypoint entry, performance initialization (PERF INIT), cost index calculations.', difficulty: 'Intermediate' },
    { id: 'av-meteo', name: 'Aviation Meteorology & Severe Weather Hazards', domain: 'Aviation', category: 'Meteorology', short_description: 'Live METAR/TAF decoding, microburst detection, thunderstorm avoidance, clear air turbulence.', difficulty: 'Foundational' },
    { id: 'av-crm', name: 'Crew Resource Management (CRM) & Human Factors', domain: 'Aviation', category: 'Safety', short_description: 'Sterile cockpit rules, standard SOP callouts, Threat & Error Management (TEM), DODAR.', difficulty: 'Intermediate' },
    { id: 'av-weightbal', name: 'Aircraft Weight & Balance and V-Speeds', domain: 'Aviation', category: 'Performance', short_description: 'Center of gravity (CG) calculations, Zero Fuel Weight, V1 decision, VR rotate, V2 safety speed.', difficulty: 'Intermediate' },
    { id: 'av-airlaw', name: 'DGCA / FAA Air Regulations & Air Law', domain: 'Aviation', category: 'Air Law', short_description: 'Airspace classes (A through G), VFR/IFR minima, right of way rules, emergency squawk codes.', difficulty: 'Foundational' }
  ],

  'Cabin Crew': [
    { id: 'cc-safety', name: 'In-Flight Safety & Evacuation Procedures', domain: 'Cabin Crew', category: 'Safety', short_description: 'Emergency slide deployment, overwing exit drills, 90-second cabin evacuation standards.', difficulty: 'Foundational' },
    { id: 'cc-firstaid', name: 'Aviation First Aid, CPR & Medical Triage', domain: 'Cabin Crew', category: 'Medical', short_description: 'Automated External Defibrillator (AED), hypoxia care, emergency childbirth, first aid kit.', difficulty: 'Foundational' },
    { id: 'cc-dgca', name: 'DGCA & IATA Air Safety Regulations', domain: 'Cabin Crew', category: 'Regulations', short_description: 'Pre-flight safety briefings, security search protocols, dangerous goods carriage rules.', difficulty: 'Foundational' },
    { id: 'cc-hospitality', name: 'Luxury Galley & In-Flight Hospitality', domain: 'Cabin Crew', category: 'Service', short_description: 'First/Business class dining etiquette, special meal service, multi-cultural passenger care.', difficulty: 'Intermediate' },
    { id: 'cc-conflict', name: 'Passenger Conflict & Unruly Passenger Handling', domain: 'Cabin Crew', category: 'Human Factors', short_description: 'Verbal de-escalation, assertive communication, level 1-4 air rage restraint protocols.', difficulty: 'Intermediate' },
    { id: 'cc-fire', name: 'Aviation Fire Fighting & Smoke Drills', domain: 'Cabin Crew', category: 'Safety', short_description: 'Halon extinguisher operation, PBE smoke hood donning, hidden lavatory fire detection.', difficulty: 'Intermediate' }
  ],

  'Robotics': [
    { id: 'rob-ros2', name: 'ROS 2 (Robot Operating System) Core Architecture', domain: 'Robotics', category: 'Software', short_description: 'Nodes, topics, services, actions, ROS 2 parameters, DDS middleware, launch files.', difficulty: 'Intermediate' },
    { id: 'rob-kinematics', name: 'Robot Kinematics & Inverse Kinematics', domain: 'Robotics', category: 'Control Theory', short_description: 'Denavit-Hartenberg (DH) parameters, transformation matrices, Jacobian trajectory planning.', difficulty: 'Advanced' },
    { id: 'rob-slam', name: 'Autonomous Navigation & LiDAR SLAM', domain: 'Robotics', category: 'Navigation', short_description: 'Nav2 stack, 2D/3D LiDAR point cloud processing, costmaps, AMCL localization.', difficulty: 'Advanced', is_emerging: true },
    { id: 'rob-plc', name: 'Industrial PLC Programming & Ladder Logic', domain: 'Robotics', category: 'Industrial', short_description: 'Siemens TIA Portal, ladder diagrams, timer/counter circuits, industrial sensors/actuators.', difficulty: 'Intermediate' },
    { id: 'rob-vision', name: 'Computer Vision & YOLO Object Detection', domain: 'Robotics', category: 'Vision', short_description: 'OpenCV image filters, edge detection, YOLO real-time robotic object grasping models.', difficulty: 'Intermediate' },
    { id: 'rob-motors', name: 'BLDC Motors, Servos & PID Control Tuning', domain: 'Robotics', category: 'Hardware', short_description: 'Closed-loop PID feedback, PWM motor drivers, encoder position sensing, torque control.', difficulty: 'Foundational' }
  ],

  'Biotechnology': [
    { id: 'bio-crispr', name: 'Genetic Engineering & CRISPR-Cas9 Protocols', domain: 'Biotechnology', category: 'Genetics', short_description: 'Guide RNA design, recombinant DNA plasmid vectors, restriction digestion, transfection.', difficulty: 'Advanced', is_emerging: true },
    { id: 'bio-fermentation', name: 'Bioreactor Fermentation & Process Parameters', domain: 'Biotechnology', category: 'Bioprocessing', short_description: 'Dissolved oxygen (DO), pH control, impeller agitation, batch vs fed-batch kinetics.', difficulty: 'Intermediate' },
    { id: 'bio-chromatography', name: 'Protein Purification & Chromatography (HPLC/FPLC)', domain: 'Biotechnology', category: 'Downstream', short_description: 'Affinity chromatography, size exclusion, ion exchange, SDS-PAGE protein yield analysis.', difficulty: 'Intermediate' },
    { id: 'bio-bioinfo', name: 'Bio-Informatics Python & Sequence Alignment', domain: 'Biotechnology', category: 'Computational', short_description: 'BLAST search, NCBI database querying, BioPython, Next-Gen Sequencing (NGS) analysis.', difficulty: 'Intermediate' },
    { id: 'bio-meddevice', name: 'Biomedical Device Design & Biosensors', domain: 'Biotechnology', category: 'Devices', short_description: 'Electrochemical biosensors, microfluidic lab-on-a-chip, ISO 13485 medical standards.', difficulty: 'Advanced' },
    { id: 'bio-cgmp', name: 'cGMP Cleanroom & Biopharma Regulatory Standards', domain: 'Biotechnology', category: 'Regulatory', short_description: 'Cleanroom ISO classification, sterility validation, FDA 21 CFR Part 11, CDSCO filings.', difficulty: 'Foundational' }
  ],

  'Marine': [
    { id: 'mar-diesel', name: 'Marine Diesel Engines & Propulsion Systems', domain: 'Marine', category: 'Propulsion', short_description: '2-stroke slow-speed crosshead engines, turbochargers, indicator diagram power analysis.', difficulty: 'Intermediate' },
    { id: 'mar-stability', name: 'Ship Hydrostatics, Metacentric Height & Stability', domain: 'Marine', category: 'Naval Arch', short_description: 'Archimedes principle, GM height calculations, cross curves of stability, damage stability.', difficulty: 'Foundational' },
    { id: 'mar-auxiliary', name: 'Marine Auxiliary Boilers, Purifiers & FWG', domain: 'Marine', category: 'Machinery', short_description: 'Centrifugal fuel purifiers, exhaust gas boilers, fresh water generators, oily water separators.', difficulty: 'Intermediate' },
    { id: 'mar-marpol', name: 'IMO MARPOL Regulations & Environmental Safety', domain: 'Marine', category: 'Compliance', short_description: 'Annex I-VI compliance, sulfur cap limits, ballast water treatment, safety at sea (SOLAS).', difficulty: 'Foundational' },
    { id: 'mar-maxsurf', name: 'Naval Architecture & Maxsurf 3D Hull Modeling', domain: 'Marine', category: 'CAD', short_description: 'Hull surface generation, resistance estimation, propeller cavitation analysis in Maxsurf.', difficulty: 'Advanced' },
    { id: 'mar-watchkeeping', name: 'Engine Room Watchkeeping & Alarm Protocols', domain: 'Marine', category: 'Operations', short_description: 'STCW watchkeeping duties, logbook entries, emergency steering changeover drills.', difficulty: 'Foundational' }
  ],

  'Mechanical': [
    { id: 'mech-solidworks', name: '3D Parametric CAD Modeling (SolidWorks)', domain: 'Mechanical', category: 'CAD', short_description: 'Part sketching, complex lofted surfaces, assembly constraints, bill of materials (BOM).', difficulty: 'Foundational' },
    { id: 'mech-gdt', name: 'GD&T (ASME Y14.5 Geometric Tolerancing)', domain: 'Mechanical', category: 'Design Standards', short_description: 'Datums, feature control frames, position tolerance, concentricity, runout tolerances.', difficulty: 'Intermediate' },
    { id: 'mech-fea', name: 'Finite Element Analysis (ANSYS Structural FEA)', domain: 'Mechanical', category: 'Simulation', short_description: 'Stress/strain distribution, von Mises criteria, modal vibration analysis, thermal FEA.', difficulty: 'Intermediate' },
    { id: 'mech-cnc', name: 'CNC Machining, G-Code & CAM Toolpaths', domain: 'Mechanical', category: 'Manufacturing', short_description: 'Mastercam milling toolpaths, G01/G02/G03 interpolations, spindle speeds, feeds, offsets.', difficulty: 'Intermediate' },
    { id: 'mech-thermo', name: 'Thermodynamics & Heat Exchanger Design', domain: 'Mechanical', category: 'Thermal', short_description: 'First & Second Laws, Rankine/Carnot cycles, LMTD shell-and-tube heat exchanger sizing.', difficulty: 'Foundational' },
    { id: 'mech-dfma', name: 'Design for Manufacturing & Assembly (DFMA)', domain: 'Mechanical', category: 'Design', short_description: 'Sheet metal design rules, injection molding draft angles, reducing fastener counts.', difficulty: 'Intermediate' }
  ],

  'Civil': [
    { id: 'civ-staad', name: 'STAAD.Pro 3D Space Frame & Seismic Design', domain: 'Civil', category: 'Structural', short_description: 'Node/beam modeling, dead/live/wind loads, IS 1893 seismic response spectrum analysis.', difficulty: 'Intermediate' },
    { id: 'civ-revit', name: 'Building Information Modeling (Autodesk Revit BIM)', domain: 'Civil', category: 'BIM', short_description: '3D architectural & structural modeling, 4D construction scheduling, clash detection.', difficulty: 'Intermediate', is_emerging: true },
    { id: 'civ-rcc', name: 'Reinforced Concrete Design (IS 456 / ACI 318)', domain: 'Civil', category: 'Structural', short_description: 'Limit state design of singly/doubly reinforced beams, columns, footing foundations.', difficulty: 'Foundational' },
    { id: 'civ-geotech', name: 'Geotechnical Soil Mechanics & Foundations', domain: 'Civil', category: 'Geotechnical', short_description: 'Terzaghi bearing capacity, soil consolidation, standard penetration test (SPT), slope stability.', difficulty: 'Foundational' },
    { id: 'civ-boq', name: 'Quantity Surveying, Estimation & BOQ', domain: 'Civil', category: 'Project Management', short_description: 'Centerline method rate analysis, Bill of Quantities (BOQ), tender bidding documents.', difficulty: 'Foundational' },
    { id: 'civ-projectmgmt', name: 'Construction Project Scheduling (Primavera / MS Project)', domain: 'Civil', category: 'Management', short_description: 'Critical Path Method (CPM), PERT chart tracking, resource leveling, cost variance S-curves.', difficulty: 'Intermediate' }
  ],

  'Electrical': [
    { id: 'ee-embedded', name: 'Embedded C & ARM Cortex-M Firmware', domain: 'Electrical', category: 'Embedded', short_description: 'Bare-metal C, register configuration, interrupts, timers, ADC, UART, SPI, I2C bus.', difficulty: 'Intermediate' },
    { id: 'ee-vlsi', name: 'VLSI Digital Design & Verilog RTL', domain: 'Electrical', category: 'VLSI', short_description: 'Finite State Machines (FSM), testbenches, static timing analysis (STA), FPGA synthesis.', difficulty: 'Advanced' },
    { id: 'ee-pcb', name: 'High-Speed Multi-Layer PCB Design (Altium)', domain: 'Electrical', category: 'Hardware', short_description: 'Schematic capture, impedance matching, differential pair routing, Gerber manufacturing files.', difficulty: 'Intermediate' },
    { id: 'ee-powerelec', name: 'Power Electronics & Motor Inverters', domain: 'Electrical', category: 'Power', short_description: 'Buck-boost DC-DC converters, 3-phase MOSFET inverters, space vector PWM, gate drivers.', difficulty: 'Intermediate' },
    { id: 'ee-matlab', name: 'MATLAB Simulink Control Systems & Modeling', domain: 'Electrical', category: 'Simulation', short_description: 'Transfer functions, root locus, Bode plots, state-space modeling, closed-loop PID.', difficulty: 'Foundational' },
    { id: 'ee-evbms', name: 'EV Battery Management Systems (BMS)', domain: 'Electrical', category: 'EV Tech', short_description: 'Cell balancing algorithms, State of Charge (SoC) estimation, thermal runaway prevention.', difficulty: 'Advanced', is_emerging: true }
  ],

  'Chemical': [
    { id: 'chem-aspen', name: 'Chemical Process Simulation (Aspen Plus / HYSYS)', domain: 'Chemical', category: 'Simulation', short_description: 'Thermodynamic property packages (NRTL/Peng-Robinson), flash calculations, flowsheet convergence.', difficulty: 'Intermediate' },
    { id: 'chem-massenergy', name: 'Mass & Energy Balances across Unit Operations', domain: 'Chemical', category: 'Core Chemical', short_description: 'Recycle stream calculations, purge ratios, combustion stoichiometric energy balances.', difficulty: 'Foundational' },
    { id: 'chem-distillation', name: 'Distillation Column & Mass Transfer Design', domain: 'Chemical', category: 'Separation', short_description: 'McCabe-Thiele method, reflux ratio optimization, sieve tray hydraulics, packed columns.', difficulty: 'Intermediate' },
    { id: 'chem-hazop', name: 'Process Safety Management & HAZOP Analysis', domain: 'Chemical', category: 'Safety', short_description: 'Hazard and Operability guide words, Layer of Protection Analysis (LOPA), relief valves.', difficulty: 'Intermediate' },
    { id: 'chem-pid', name: 'Piping & Instrumentation Diagrams (P&ID)', domain: 'Chemical', category: 'Engineering Drawing', short_description: 'ISA-5.1 symbology, control loop instrumentation, line sizing, fail-safe valve states.', difficulty: 'Foundational' }
  ],

  'BA Hons': [
    { id: 'hum-policy', name: 'Public Policy Formulation & Whitepaper Drafting', domain: 'BA Hons', category: 'Public Policy', short_description: 'Policy cycle analysis, stakeholder mapping, regulatory impact assessments, policy briefs.', difficulty: 'Intermediate' },
    { id: 'hum-research', name: 'Qualitative & Quantitative Social Research', domain: 'BA Hons', category: 'Research', short_description: 'Survey methodology, semi-structured interviews, SPSS/R regression, statistical inference.', difficulty: 'Foundational' },
    { id: 'hum-macro', name: 'Macroeconomic Analysis & Fiscal Policy Modeling', domain: 'BA Hons', category: 'Economics', short_description: 'Inflation-unemployment trade-offs, monetary easing, balance of payments, econometrics.', difficulty: 'Intermediate' },
    { id: 'hum-communications', name: 'Strategic Communications & Media Advocacy', domain: 'BA Hons', category: 'Communications', short_description: 'Corporate press releases, crisis communications, narrative framing, digital public relations.', difficulty: 'Foundational' },
    { id: 'hum-csr', name: 'Corporate Social Responsibility (CSR) & ESG Auditing', domain: 'BA Hons', category: 'ESG Governance', short_description: 'GRI sustainability reporting, ESG compliance frameworks, social impact evaluation.', difficulty: 'Intermediate', is_emerging: true }
  ]
};

// Aliases lookup to safely resolve domain variants
export const DOMAIN_ALIASES: Record<string, string> = {
  'cs': 'Computer Science',
  'software': 'Computer Science',
  'computer': 'Computer Science',
  'computer science': 'Computer Science',
  'b.com': 'BCOM',
  'commerce': 'BCOM',
  'accounting': 'BCOM',
  'finance': 'BCOM',
  'finance & commerce': 'BCOM',
  'finance and commerce': 'BCOM',
  'llb': 'BA LLB',
  'law': 'BA LLB',
  'legal': 'BA LLB',
  'corporate law': 'BA LLB',
  'pilot': 'Aviation',
  'commercial pilot': 'Aviation',
  'medicine': 'MBBS',
  'clinical': 'MBBS',
  'mbbs': 'MBBS',
  'nursing': 'Nursing',
  'analytics': 'Business Analytics',
  'data analytics': 'Business Analytics',
  'business analytics': 'Business Analytics',
  'mech': 'Mechanical',
  'mechanical': 'Mechanical',
  'mechanical engineering': 'Mechanical',
  'aerospace': 'Aeronautical',
  'aeronautical': 'Aeronautical',
  'aeronautical engineering': 'Aeronautical',
  'cabin crew': 'Cabin Crew',
  'management': 'BBA',
  'management & business': 'BBA',
  'management and business': 'BBA',
  'business & management': 'BBA',
  'business administration': 'BBA',
  'business': 'BBA',
  'operations': 'BBA',
  'bba': 'BBA',
  'mba': 'BBA',
  'humanities': 'BA Hons',
  'marineeng': 'Marine',
  'marine engineering': 'Marine',
  'marine': 'Marine',
  'civil': 'Civil',
  'civil engineering': 'Civil',
  'electrical': 'Electrical',
  'electrical engineering': 'Electrical',
  'chemical': 'Chemical',
  'chemical engineering': 'Chemical',
  'biotech': 'Biotechnology',
  'biotechnology': 'Biotechnology',
  'robotics': 'Robotics'
};

export function getCanonicalDomain(domainName: string): string {
  if (!domainName) return 'Computer Science';
  const trimmed = domainName.trim();
  if (DOMAIN_CO_DOMAINS[trimmed]) return trimmed;
  const lower = trimmed.toLowerCase();
  for (const [alias, canonical] of Object.entries(DOMAIN_ALIASES)) {
    if (lower === alias || lower.includes(alias)) {
      return canonical;
    }
  }
  for (const key of Object.keys(DOMAIN_CO_DOMAINS)) {
    if (key.toLowerCase() === lower || lower.includes(key.toLowerCase()) || key.toLowerCase().includes(lower)) {
      return key;
    }
  }
  return trimmed;
}

// -------------------------------------------------------------
// Universal Learning Platform & Verified Courseware Resolver
// -------------------------------------------------------------
export function resolvePhaseLearningPlatforms(
  domain: string,
  coDomain: string,
  phaseIndex: number
): LearningPlatformResource[] {
  const cd = (coDomain || '').toLowerCase();
  const dom = (domain || '').toLowerCase();

  // 1. DATA STRUCTURES & ALGORITHMS (DSA) - Absolute priority check
  if (
    cd.includes('dsa') ||
    cd.includes('data structure') ||
    cd.includes('algorithm') ||
    cd.includes('leetcode') ||
    cd.includes('binary search tree') ||
    cd.includes('dynamic programming') ||
    cd.includes('graph traversal') ||
    cd.includes('algorithmic')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'NeetCode.io (NeetCode 150 & Big-O Core)',
          platform_url: 'https://neetcode.io/roadmap',
          topic_focus: 'Time & Space Complexity Big-O, Arrays, Hashing & Two Pointers',
          resource_type: 'curated_course',
          access_badge: 'Industry Gold Standard',
          description: 'Interactive visual roadmap for mastering fundamental data structures, memory layouts, and algorithmic complexity.'
        },
        {
          platform_name: 'GeeksforGeeks DSA Foundation Hub',
          platform_url: 'https://www.geeksforgeeks.org/data-structures/',
          topic_focus: 'Linear & Non-Linear Data Structures, Stacks, Queues & Linked Lists',
          resource_type: 'official_docs',
          access_badge: 'Comprehensive Free Guide',
          description: 'Deep-dive theoretical blueprints, zero-dependency implementations, and standard operational edge cases.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'LeetCode Explore & Study Plans',
          platform_url: 'https://leetcode.com/explore/',
          topic_focus: 'Binary Trees, BSTs, BFS/DFS Graph Traversals & Recursion',
          resource_type: 'interactive_lab',
          access_badge: 'Interactive Coding Arena',
          description: 'Hands-on problem sets covering tree traversals, back-tracking recursion, binary search boundaries, and heaps.'
        },
        {
          platform_name: 'VisuAlgo (Visualizing Data Structures & Algorithms)',
          platform_url: 'https://visualgo.net/en',
          topic_focus: 'Interactive Animated Algorithm Tracing & Graph Step-by-Step',
          resource_type: 'interactive_lab',
          access_badge: 'Visual Sandbox',
          description: 'Real-time interactive state visualization of graph exploration, sorting algorithms, and tree re-balancing.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: "Striver's A2Z DSA Sheet (takeUforward)",
          platform_url: 'https://takeuforward.org/strivers-a2z-dsa-course/strivers-a2z-dsa-course-sheet-2/',
          topic_focus: 'Dynamic Programming, Disjoint Set Union, Trie & Segment Trees',
          resource_type: 'curated_course',
          access_badge: 'Top Placement Standard',
          description: 'Curated 450+ progressive interview problems covering memoization, tabulations, shortest paths, and tries.'
        },
        {
          platform_name: 'CSES Algorithmic Problem Set (Univ of Helsinki)',
          platform_url: 'https://cses.fi/problemset/',
          topic_focus: 'Advanced Algorithmic Problem Solving & Competitive Optimization',
          resource_type: 'practice_arena',
          access_badge: 'University Benchmark',
          description: 'Rigorous algorithmic challenges benchmarking optimal sub-millisecond runtime and tight memory limits.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'GitHub Open-Source Algorithms Library (JavaScript / Python)',
          platform_url: 'https://github.com/trekhleb/javascript-algorithms',
          topic_focus: 'Flagship Algorithmic Engine & Custom Data Structures Capstone',
          resource_type: 'curated_course',
          access_badge: 'Portfolio Showcase',
          description: 'Architecture repository demonstrating clean, documented, zero-dependency implementations with 100% test coverage.'
        },
        {
          platform_name: 'LeetCode Top Interview 150 Benchmark',
          platform_url: 'https://leetcode.com/studyplan/top-interview-150/',
          topic_focus: '150 Production-Tested Solutions with Verified Complexity Profiles',
          resource_type: 'interactive_lab',
          access_badge: 'Verified Benchmark',
          description: 'Complete verified solutions portfolio targeting tier-1 software engineering problem sets.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'LeetCode FAANG & Big Tech Question Bank',
          platform_url: 'https://leetcode.com/problemset/',
          topic_focus: 'FAANG / Tier 1 Live Technical Whiteboarding & Problem Solving',
          resource_type: 'practice_arena',
          access_badge: 'FAANG Placement Prep',
          description: 'Company-tagged technical screening questions from Google, Microsoft, Amazon, Meta, and top startups.'
        },
        {
          platform_name: 'HackerRank Problem Solving Skill Certification',
          platform_url: 'https://www.hackerrank.com/skills-verification',
          topic_focus: 'Timed Coding Rounds, Verified Certifications & ATS Matching',
          resource_type: 'practice_arena',
          access_badge: 'Employ.AI Recruiter Verified',
          description: 'Standardized skill assessment tests verified directly by hiring partners on the Employ.AI portal.'
        }
      ];
    }
  }

  // 2. SYSTEM DESIGN & DISTRIBUTED SYSTEMS
  if (
    cd.includes('sysdesign') ||
    cd.includes('system design') ||
    cd.includes('distributed system') ||
    cd.includes('software architecture') ||
    cd.includes('high availability')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'System Design Primer (GitHub / Donne Martin)',
          platform_url: 'https://github.com/donnemartin/system-design-primer',
          topic_focus: 'Load Balancers, Reverse Proxies, CDN Caching & CAP Theorem',
          resource_type: 'official_docs',
          access_badge: 'Architecture Standard',
          description: 'The definitive open-source guide to distributed systems design, scaling bottlenecks, and tradeoffs.'
        },
        {
          platform_name: 'ByteByteGo System Design Foundations (Alex Xu)',
          platform_url: 'https://bytebytego.com',
          topic_focus: 'High-Level Architecture Diagrams & Latency Numbers Every Programmer Should Know',
          resource_type: 'curated_course',
          access_badge: 'Visual Architecture Hub',
          description: 'Step-by-step visual guides breaking down distributed databases, caching tiers, and rate limiters.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'High Scalability Real-World Architecture Archive',
          platform_url: 'http://highscalability.com',
          topic_focus: 'Netflix, Uber, Discord & WhatsApp Production Architecture Breakdowns',
          resource_type: 'curated_course',
          access_badge: 'Real-World Production Case Studies',
          description: 'In-depth case studies on how global scale tech giants handle millions of concurrent socket connections.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Redis University & Distributed Caching Hub',
          platform_url: 'https://redis.io/learn/',
          topic_focus: 'Pub/Sub Messaging, Cache Stampede Mitigation & Sharding',
          resource_type: 'interactive_lab',
          access_badge: 'Distributed Systems Standard',
          description: 'Enterprise caching strategies, distributed locking with Redlock, and asynchronous job queuing.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Excalidraw RFC Architecture Design & Portfolio Capstone',
          platform_url: 'https://excalidraw.com',
          topic_focus: 'Flagship Distributed Microservice System Design Whitepaper',
          resource_type: 'clinical_case',
          access_badge: 'Portfolio Architecture RFC',
          description: 'Author a complete engineering Request for Comments (RFC) with full database schemas and failover diagrams.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'ByteByteGo / LeetCode System Design Mock Interview Bank',
          platform_url: 'https://bytebytego.com',
          topic_focus: 'Designing URL Shortener, Twitter Feed, Payment Gateway & Ride-Sharing',
          resource_type: 'practice_arena',
          access_badge: 'System Design Placement Prep',
          description: 'Real technical screening questions for senior & staff software engineering interviews.'
        }
      ];
    }
  }

  // 2.5 FULLSTACK WEB DEVELOPMENT
  if (
    cd.includes('fullstack') ||
    cd.includes('full stack') ||
    cd.includes('mern') ||
    cd.includes('pern')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'MDN Web Docs (Fullstack Architecture & Web Standards)',
          platform_url: 'https://developer.mozilla.org/en-US/docs/Learn',
          topic_focus: 'Client-Server Architecture, HTTP Protocol, REST APIs & JSON',
          resource_type: 'official_docs',
          access_badge: 'Web Standard',
          description: 'The foundational architectural blueprint for web applications, client-server lifecycles, and modern protocols.'
        },
        {
          platform_name: 'roadmap.sh Full Stack Developer Roadmap',
          platform_url: 'https://roadmap.sh/full-stack',
          topic_focus: 'End-to-End System Components, Tooling & Frontend-Backend Contracts',
          resource_type: 'curated_course',
          access_badge: 'Industry Roadmap Standard',
          description: 'Comprehensive visual roadmap outlining production technologies across the entire web stack.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Full Stack Open (University of Helsinki)',
          platform_url: 'https://fullstackopen.com/en/',
          topic_focus: 'Fullstack MERN / TypeScript: React UI connected to Node/Express REST APIs',
          resource_type: 'curated_course',
          access_badge: 'University Benchmark',
          description: 'Deep dive into modern single-page applications, state management, REST APIs, and automated testing.'
        },
        {
          platform_name: 'freeCodeCamp Full Stack Curriculum',
          platform_url: 'https://www.freecodecamp.org/learn/',
          topic_focus: 'Connecting Frontend Clients to Backend Endpoints with CORS & JWT',
          resource_type: 'interactive_lab',
          access_badge: 'Free Interactive Sandbox',
          description: 'Hands-on projects building end-to-end applications with secure authentication and token refresh.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Prisma ORM & PostgreSQL Fullstack Architecture Guides',
          platform_url: 'https://www.prisma.io/docs',
          topic_focus: 'Type-Safe ORM Queries, Relational Migrations & Auth (NextAuth / JWT)',
          resource_type: 'official_docs',
          access_badge: 'Production ORM Standard',
          description: 'Complete guides on database migrations, multi-tenant schemas, and secure token authentication.'
        },
        {
          platform_name: 'Auth0 Developer Center (OAuth2 & JWT Architecture)',
          platform_url: 'https://auth0.com/docs',
          topic_focus: 'Identity Management, Secure Session Cookies, CSRF & RBAC',
          resource_type: 'official_docs',
          access_badge: 'Security Standard',
          description: 'Industry-standard authentication patterns, token rotation, and identity provider integration.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Docker & Multi-Container Cloud Deployment Hub',
          platform_url: 'https://docs.docker.com/compose/',
          topic_focus: 'Production Docker Compose: React UI, API Microservice & PostgreSQL',
          resource_type: 'official_docs',
          access_badge: 'Cloud Native Standard',
          description: 'Multi-container orchestration, Nginx reverse proxy configuration, and production SSL deployment.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'ByteByteGo Full Stack System Design & Mock Interview Bank',
          platform_url: 'https://bytebytego.com',
          topic_focus: 'Full Stack Architecture Rounds, Caching, Scaling & Machine Coding',
          resource_type: 'practice_arena',
          access_badge: 'Placement Prep',
          description: 'Real technical screening scenarios for fullstack and software engineering roles at top tech companies.'
        }
      ];
    }
  }

  // 3. REACT & FRONTEND UI ARCHITECTURE
  if (
    cd.includes('react') ||
    cd.includes('next.js') ||
    cd.includes('nextjs') ||
    cd.includes('frontend') ||
    cd.includes('ui architecture') ||
    cd.includes('vue') ||
    cd.includes('angular')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'React.dev Official Interactive Tutorial',
          platform_url: 'https://react.dev/learn',
          topic_focus: 'React 19 Components, State Hooks, Props & Virtual DOM',
          resource_type: 'official_docs',
          access_badge: 'Official & Free',
          description: 'Authoritative interactive sandbox documentation created directly by the React Core Team.'
        },
        {
          platform_name: 'MDN Web Docs (JavaScript & Modern DOM APIs)',
          platform_url: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript',
          topic_focus: 'ES6+ Syntax, Event Loop, Closures, Promises & Async/Await',
          resource_type: 'official_docs',
          access_badge: 'Web Standard',
          description: 'The foundation of modern web standards, browser rendering lifecycles, and event delegation.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'TanStack Query (React Query) Documentation',
          platform_url: 'https://tanstack.com/query/latest',
          topic_focus: 'Server-State Caching, Auto-Refetching & Optimistic UI',
          resource_type: 'official_docs',
          access_badge: 'Production Library Standard',
          description: 'Master asynchronous state management, deduplication, and background cache invalidation.'
        },
        {
          platform_name: 'Vite & Vitest Fast Modern Toolchain Guides',
          platform_url: 'https://vitejs.dev/guide/',
          topic_focus: 'Lightning HMR, ESM Bundling & Component Unit Testing',
          resource_type: 'interactive_lab',
          access_badge: 'Tooling Standard',
          description: 'Production frontend tooling setup with fast hot module replacement and automated component tests.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Patterns.dev Web Performance & Architecture',
          platform_url: 'https://www.patterns.dev',
          topic_focus: 'Design Patterns, Code Splitting, Lazy Loading & Memoization',
          resource_type: 'curated_course',
          access_badge: 'Engineering Standard',
          description: 'Architecture patterns for building accessible, 60fps micro-frontend user interfaces.'
        },
        {
          platform_name: 'Chrome DevTools Lighthouse & Core Web Vitals',
          platform_url: 'https://developer.chrome.com/docs/devtools/performance/',
          topic_focus: 'LCP, FID/INP, CLS Optimization & Bundle Profiling',
          resource_type: 'official_docs',
          access_badge: 'Google Standard',
          description: 'Diagnosing unnecessary re-renders, layout thrashing, and memory leaks in web apps.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Full Stack Open (University of Helsinki)',
          platform_url: 'https://fullstackopen.com/en/',
          topic_focus: 'Flagship Fullstack React & Cloud Deployed Capstone',
          resource_type: 'curated_course',
          access_badge: 'University Capstone',
          description: 'Deep dive into production-grade React, TypeScript, state caching, and continuous deployment.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'GreatFrontEnd Technical Interview Screening',
          platform_url: 'https://www.greatfrontend.com',
          topic_focus: 'Frontend Coding Screenings, DOM Manipulation & Framework Drills',
          resource_type: 'practice_arena',
          access_badge: 'Frontend Placement Prep',
          description: 'Real coding challenges asked in Big Tech and high-growth unicorn UI engineering rounds.'
        }
      ];
    }
  }

  // 4. FASTAPI, PYTHON & BACKEND MICROSERVICES
  if (
    cd.includes('fastapi') ||
    cd.includes('backend') ||
    cd.includes('python backend') ||
    cd.includes('node.js') ||
    cd.includes('express') ||
    cd.includes('microservice') ||
    cd.includes('graphql') ||
    cd.includes('rest api')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'FastAPI Official Interactive Tutorial & OpenAPI Docs',
          platform_url: 'https://fastapi.tiangolo.com/tutorial/',
          topic_focus: 'Async Async/Await, Pydantic Schema Validation & Dependency Injection',
          resource_type: 'official_docs',
          access_badge: 'FastAPI Official',
          description: 'High-speed Python web framework with automated Swagger UI documentation and strict type checking.'
        },
        {
          platform_name: 'Python.org Official Language Reference',
          platform_url: 'https://docs.python.org/3/tutorial/',
          topic_focus: 'Type Hints, Generators, Decorators, Context Managers & Asyncio',
          resource_type: 'official_docs',
          access_badge: 'Python Standard',
          description: 'Official Python 3.12 documentation covering concurrency, typing, and standard library modules.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'SQLAlchemy 2.0 & Real Python Async Guides',
          platform_url: 'https://realpython.com/',
          topic_focus: 'Async ORM Queries, Connection Pooling, Foreign Keys & Alembic Migrations',
          resource_type: 'curated_course',
          access_badge: 'Industry Practice',
          description: 'Asynchronous relational database operations, JWT authentication tokens, and bcrypt hashing.'
        },
        {
          platform_name: 'Postman API Testing Academy',
          platform_url: 'https://learning.postman.com',
          topic_focus: 'Automated REST Integration Tests, Environment Headers & Auth Verification',
          resource_type: 'interactive_lab',
          access_badge: 'Testing Tooling',
          description: 'Test suites for REST endpoints, bearer tokens, error status handling, and schema validation.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Redis University & Distributed Caching Patterns',
          platform_url: 'https://redis.io/learn/',
          topic_focus: 'High-Throughput Rate Limiting, Cache-Aside & Celery Background Queues',
          resource_type: 'interactive_lab',
          access_badge: 'Distributed Systems',
          description: 'Accelerate backend throughput 10x with in-memory caching, pub/sub notifications, and task workers.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'TestDriven.io Fullstack FastAPI Courseware',
          platform_url: 'https://testdriven.io/courses/',
          topic_focus: 'Containerized Microservices SaaS Flagship Capstone',
          resource_type: 'curated_course',
          access_badge: 'Production Capstone',
          description: 'Build and deploy an enterprise SaaS service with Docker, PostgreSQL, Redis, and Pytest.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'NeetCode & LeetCode Backend System Design Drills',
          platform_url: 'https://neetcode.io',
          topic_focus: 'Backend Concurrency, Database Query Optimization & API Security Drills',
          resource_type: 'practice_arena',
          access_badge: 'Backend Placement Prep',
          description: 'Real-world backend engineering screening scenarios, database indexes, and concurrency locks.'
        }
      ];
    }
  }

  // 5. TYPESCRIPT & MODERN PYTHON PROGRAMMING
  if (cd.includes('typescript') || cd.includes('type safety') || (cd.includes('python') && !dom.includes('analytics') && !dom.includes('bio'))) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'TypeScript Official Handbook & Sandbox',
          platform_url: 'https://www.typescriptlang.org/docs/',
          topic_focus: 'Strict Types, Generics, Discriminated Unions & Utility Types',
          resource_type: 'official_docs',
          access_badge: 'Official TypeScript',
          description: 'Authoritative guide to TypeScript type inference, compiler options, and interface design.'
        },
        {
          platform_name: 'Python.org Official Tutorial & Typing Module',
          platform_url: 'https://docs.python.org/3/library/typing.html',
          topic_focus: 'Modern Type Hints, Dataclasses, Protocol Classes & Pydantic V2',
          resource_type: 'official_docs',
          access_badge: 'Python Standard',
          description: 'Leveraging strict typing in Python to eliminate runtime bugs and enable clean code design.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Total TypeScript (Matt Pocock)',
          platform_url: 'https://www.totaltypescript.com/tutorials',
          topic_focus: 'Advanced Generics, Conditional Types & Template Literal Types',
          resource_type: 'interactive_lab',
          access_badge: 'Advanced TypeScript',
          description: 'Master enterprise-level type transformations and zero-runtime-cost safety guarantees.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Pytest Official Documentation & Testing Best Practices',
          platform_url: 'https://docs.pytest.org/',
          topic_focus: 'Fixtures, Parametrization, Mocking & Automated Code Coverage',
          resource_type: 'official_docs',
          access_badge: 'Testing Standard',
          description: 'Writing robust, maintainable test suites for Python applications with mock databases.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'GitHub Open-Source TypeScript Library Capstone',
          platform_url: 'https://github.com',
          topic_focus: 'Published Type-Safe NPM/PyPI Package with CI Workflows',
          resource_type: 'clinical_case',
          access_badge: 'Open Source Capstone',
          description: 'Package, test, and publish a production-ready utility package with automated semantic releases.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'TypeHero Interactive TypeScript Challenges',
          platform_url: 'https://typehero.dev',
          topic_focus: 'Advanced TypeScript Coding Screening & Problem Sets',
          resource_type: 'practice_arena',
          access_badge: 'Type System Prep',
          description: 'Interactive browser puzzles to master type manipulation for technical screenings.'
        }
      ];
    }
  }

  // 6. SQL, RELATIONAL DB & NOSQL (UNDER CS / IT)
  if (
    cd.includes('relational db') ||
    cd.includes('postgresql') ||
    cd.includes('nosql') ||
    cd.includes('mongodb') ||
    cd.includes('dynamodb') ||
    (cd.includes('sql') && (dom.includes('computer') || dom.includes('software') || dom.includes('tech') || dom.includes('it')))
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'PostgreSQL Official Documentation & Interactive Tutorials',
          platform_url: 'https://www.postgresql.org/docs/',
          topic_focus: '3NF Normalization, Primary/Foreign Keys, Constraints & ACID Transactions',
          resource_type: 'official_docs',
          access_badge: 'Database Standard',
          description: 'World standard open-source relational database architecture, schemas, and relational theory.'
        },
        {
          platform_name: 'SQLZoo Interactive SQL Platform',
          platform_url: 'https://sqlzoo.net',
          topic_focus: 'Interactive SQL Queries, Subqueries, Aggregations & Complex Joins',
          resource_type: 'interactive_lab',
          access_badge: 'Free Interactive Lab',
          description: 'Interactive query editor for practicing real-world relational database queries.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Use The Index, Luke! (SQL Indexing Guide)',
          platform_url: 'https://use-the-index-luke.com',
          topic_focus: 'B-Tree Indexes, Composite Indexes, EXPLAIN ANALYZE & Query Plans',
          resource_type: 'curated_course',
          access_badge: 'Performance Tuning',
          description: 'Master database index anatomy, range queries, and query execution plan optimization.'
        },
        {
          platform_name: 'MongoDB University Official Learning Hub',
          platform_url: 'https://learn.mongodb.com',
          topic_focus: 'Document Schema Modeling, Aggregation Pipelines & Sharding',
          resource_type: 'official_docs',
          access_badge: 'NoSQL Standard',
          description: 'Official NoSQL curriculum covering horizontal scaling, document schemas, and indexing.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Prisma ORM & DBeaver Database Engineering Guides',
          platform_url: 'https://www.prisma.io/docs',
          topic_focus: 'Database Migrations, Connection Pooling & Read/Write Replication',
          resource_type: 'official_docs',
          access_badge: 'Modern DB Tooling',
          description: 'Type-safe database client access, zero-downtime schema migrations, and replication pools.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'High-Volume Database Architecture Capstone (GitHub)',
          platform_url: 'https://github.com',
          topic_focus: 'Sharded Multi-Tenant PostgreSQL Schema with Connection Pooling',
          resource_type: 'clinical_case',
          access_badge: 'Database Capstone',
          description: 'Deploy a multi-tenant PostgreSQL database with automated backups and read replicas.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'LeetCode Database Problem Set (SQL & Optimization)',
          platform_url: 'https://leetcode.com/problemset/database/',
          topic_focus: 'Complex Window Functions, Self-Joins & Transaction Locks Screening',
          resource_type: 'practice_arena',
          access_badge: 'DB Placement Prep',
          description: 'Top SQL screening questions asked in Big Tech database engineering interviews.'
        }
      ];
    }
  }

  // 7. DOCKER, KUBERNETES, DEVOPS & CLOUD (AWS / GCP)
  if (
    cd.includes('docker') ||
    cd.includes('kubernetes') ||
    cd.includes('k8s') ||
    cd.includes('cloud') ||
    cd.includes('devops') ||
    cd.includes('aws') ||
    cd.includes('gcp') ||
    cd.includes('ci/cd')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'Docker Official Getting Started Guide',
          platform_url: 'https://docs.docker.com/get-started/',
          topic_focus: 'Docker Engine, Images, Containers, Layers & CLI Commands',
          resource_type: 'official_docs',
          access_badge: 'Official Docker Standard',
          description: 'Step-by-step foundation covering container isolation, Dockerfile instructions, and layers.'
        },
        {
          platform_name: 'Play with Docker Classroom',
          platform_url: 'https://labs.play-with-docker.com/',
          topic_focus: 'Interactive Browser Terminal & Multi-Node Container Labs',
          resource_type: 'interactive_lab',
          access_badge: 'Free Interactive Sandbox',
          description: 'Live interactive command line sandbox for practicing container lifecycle and networking.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Docker Compose & GitHub Actions CI/CD Workflows',
          platform_url: 'https://docs.docker.com/compose/',
          topic_focus: 'Multi-Service Orchestration, Isolated Networks & Automated Tests',
          resource_type: 'official_docs',
          access_badge: 'Industry Standard',
          description: 'Authoring docker-compose.yml for microservices with isolated internal networks and CI pipelines.'
        },
        {
          platform_name: 'AWS Skill Builder & Cloud Practitioner Labs',
          platform_url: 'https://explore.skillbuilder.aws',
          topic_focus: 'Amazon ECS, S3, IAM Security Policies & Elastic Load Balancing',
          resource_type: 'curated_course',
          access_badge: 'Official AWS Training',
          description: 'Deploying containerized microservices to enterprise cloud infrastructure with zero-downtime.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Kubernetes Official Interactive Tutorials',
          platform_url: 'https://kubernetes.io/docs/tutorials/',
          topic_focus: 'Cluster Architecture, Pods, Deployments, Services & Ingress',
          resource_type: 'interactive_lab',
          access_badge: 'Cloud Native Standard',
          description: 'Hands-on browser tutorials on rolling updates, services, ConfigMaps, and cluster auto-scaling.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'DevOps Directive & Production Cloud Capstone',
          platform_url: 'https://github.com/sidpalas/devops-directive-docker-course',
          topic_focus: 'Production Multi-Container Cloud Deployment with CI/CD & SSL',
          resource_type: 'curated_course',
          access_badge: 'Open-Source Capstone',
          description: 'End-to-end guide to deploying scalable cloud systems with Grafana metrics and reverse proxies.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'DevOps & SRE Interview Guide (Roadmap.sh)',
          platform_url: 'https://roadmap.sh/devops',
          topic_focus: 'Cloud Architecture, Linux Troubleshooting & Kubernetes Screening',
          resource_type: 'practice_arena',
          access_badge: 'Cloud Placement Prep',
          description: 'Curated technical interview screening questions on container lifecycle, DNS, and high availability.'
        }
      ];
    }
  }

  // 8. REDIS CACHING, KAFKA & EVENT STREAMING
  if (
    cd.includes('redis') ||
    cd.includes('kafka') ||
    cd.includes('rabbitmq') ||
    cd.includes('message queue') ||
    cd.includes('event-driven')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'Redis University (RU101: Introduction to Redis Data Structures)',
          platform_url: 'https://redis.io/learn/',
          topic_focus: 'Strings, Hashes, Lists, Sets, Sorted Sets & In-Memory Storage',
          resource_type: 'official_docs',
          access_badge: 'Redis Official',
          description: 'Free university-grade courses on in-memory data structures, persistence (RDB/AOF), and TTL expiration.'
        },
        {
          platform_name: 'Apache Kafka Official Quickstart Guide',
          platform_url: 'https://kafka.apache.org/quickstart',
          topic_focus: 'Event Streaming, Topics, Partitions, Producers & Consumers',
          resource_type: 'official_docs',
          access_badge: 'Kafka Standard',
          description: 'The foundation of event-driven architectures, partition replication, and consumer offsets.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Confluent Developer (Kafka Event Streaming Academy)',
          platform_url: 'https://developer.confluent.io',
          topic_focus: 'Schema Registry, Kafka Connect, Consumer Groups & Exactly-Once Semantics',
          resource_type: 'interactive_lab',
          access_badge: 'Confluent Official',
          description: 'Interactive tutorials on streaming data pipelines, dead-letter queues, and consumer re-balancing.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'RabbitMQ Tutorials & Message Broker Patterns',
          platform_url: 'https://www.rabbitmq.com/tutorials',
          topic_focus: 'Exchange Routing (Direct, Topic, Fanout), AMQP & Acknowledgments',
          resource_type: 'interactive_lab',
          access_badge: 'Messaging Standard',
          description: 'Implementing asynchronous task workers, priority queues, and backpressure management.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Event-Driven Real-Time Notification Pipeline Capstone (GitHub)',
          platform_url: 'https://github.com',
          topic_focus: 'High-Throughput Streaming Engine with Redis Cache and Kafka Brokers',
          resource_type: 'clinical_case',
          access_badge: 'Streaming Capstone',
          description: 'Build and deploy a scalable distributed messaging engine processing 50,000 events/sec.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Distributed Systems & Messaging Technical Interview Drills',
          platform_url: 'https://bytebytego.com',
          topic_focus: 'Message Ordering, Idempotency, Dead Letter Queues & Failover Screening',
          resource_type: 'practice_arena',
          access_badge: 'Placement Prep',
          description: 'Real technical screening scenarios for event-driven and messaging architecture roles.'
        }
      ];
    }
  }

  // 9. CYBERSECURITY, ETHICAL HACKING & OAUTH2 / JWT
  if (
    cd.includes('cyber') ||
    cd.includes('security') ||
    cd.includes('soc') ||
    cd.includes('penetration') ||
    cd.includes('cryptography') ||
    cd.includes('oauth') ||
    cd.includes('jwt')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'OWASP Top 10 Security Guides',
          platform_url: 'https://owasp.org/www-project-top-ten/',
          topic_focus: 'Web Vulnerability Assessment, Injection, Broken Auth & SSRF',
          resource_type: 'official_docs',
          access_badge: 'Global Security Standard',
          description: 'The global standard awareness document for developers and application security engineers.'
        },
        {
          platform_name: 'PortSwigger Web Security Academy',
          platform_url: 'https://portswigger.net/web-security',
          topic_focus: 'Interactive Hands-on Web Security Labs (SQLi, XSS, CSRF, JWT)',
          resource_type: 'interactive_lab',
          access_badge: 'Free Interactive Labs',
          description: 'Free, interactive online training from the creators of Burp Suite.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'TryHackMe Pre-Security & SOC Pathways',
          platform_url: 'https://tryhackme.com',
          topic_focus: 'Network Security, Wireshark, SIEM Logs & Linux Forensics',
          resource_type: 'interactive_lab',
          access_badge: 'Interactive Sandbox',
          description: 'Hands-on browser labs for defensive security, threat hunting, and packet capture analysis.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Hack The Box Penetration Testing Arena',
          platform_url: 'https://www.hackthebox.com',
          topic_focus: 'Infrastructure Exploitation, Active Directory & Privilege Escalation',
          resource_type: 'interactive_lab',
          access_badge: 'Industry Pentest Lab',
          description: 'Realistic corporate network labs for mastering advanced red team and blue team defense.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'NIST Cybersecurity Framework (CSF 2.0) Repository',
          platform_url: 'https://www.nist.gov/cyberframework',
          topic_focus: 'Enterprise Threat Modeling & Security Audit Capstone',
          resource_type: 'official_docs',
          access_badge: 'Statutory Standard',
          description: 'Official US government framework for managing and reducing cybersecurity risk.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Cybrary Cybersecurity Interview Question Bank',
          platform_url: 'https://www.cybrary.it',
          topic_focus: 'SOC Analyst & Security Engineer Technical Screenings',
          resource_type: 'practice_arena',
          access_badge: 'Security Placement Prep',
          description: 'Real-world incident response scenarios, cryptosystem screening questions, and mock viva.'
        }
      ];
    }
  }

  // 10. APPLIED MACHINE LEARNING, AI & LLM INTEGRATION
  if (
    cd.includes('applied machine learning') ||
    cd.includes('llm') ||
    cd.includes('langchain') ||
    cd.includes('rag pipeline') ||
    cd.includes('artificial intelligence') ||
    cd.includes('ai/ml') ||
    (cd.includes('machine learning') && !dom.includes('analytics'))
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'DeepLearning.AI Machine Learning Specialization (Andrew Ng)',
          platform_url: 'https://www.deeplearning.ai',
          topic_focus: 'Supervised Learning, Linear/Logistic Regression, Neural Networks',
          resource_type: 'curated_course',
          access_badge: 'AI Gold Standard',
          description: 'First-principles intuition, cost functions, gradient descent, and PyTorch / scikit-learn foundations.'
        },
        {
          platform_name: 'Hugging Face NLP & Transformers Course',
          platform_url: 'https://huggingface.co/learn',
          topic_focus: 'Tokenization, Embeddings, Transformer Architectures & Pipelines',
          resource_type: 'official_docs',
          access_badge: 'Hugging Face Official',
          description: 'Hands-on guide to modern transformer models, pretrained checkpoints, and text embeddings.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'LangChain & LlamaIndex Official Documentation',
          platform_url: 'https://python.langchain.com/docs/get_started/introduction',
          topic_focus: 'RAG Pipelines, Vector Databases (Chroma / Pinecone), Chunking & Prompting',
          resource_type: 'official_docs',
          access_badge: 'GenAI Tooling Standard',
          description: 'Building Production Retrieval-Augmented Generation (RAG) agents and tool-calling chains.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Kaggle Competitions & ML Notebooks Hub',
          platform_url: 'https://www.kaggle.com',
          topic_focus: 'Hyperparameter Tuning, Cross-Validation, Feature Engineering & Ensembles',
          resource_type: 'interactive_lab',
          access_badge: 'Competitive ML Arena',
          description: 'Hands-on real-world datasets benchmarking model metrics (F1 score, ROC-AUC, RMSE).'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Full-Stack GenAI SaaS Application Capstone (GitHub)',
          platform_url: 'https://github.com',
          topic_focus: 'Deployed RAG Assistant with Vector Indexing, FastAPI & React UI',
          resource_type: 'clinical_case',
          access_badge: 'AI Capstone',
          description: 'Deploy an end-to-end intelligent document query engine with streaming token responses.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Applied AI & ML Technical Interview Guide',
          platform_url: 'https://www.interviewquery.com',
          topic_focus: 'Model Evaluation, Bias-Variance Tradeoff, Embeddings & GenAI Screening',
          resource_type: 'practice_arena',
          access_badge: 'AI Placement Prep',
          description: 'Screening questions from top AI labs and enterprise data science engineering rounds.'
        }
      ];
    }
  }

  // 11. SOFTWARE TESTING & QUALITY ASSURANCE (TDD / PYTEST / VITEST)
  if (
    cd.includes('test-driven') ||
    cd.includes('testing') ||
    cd.includes('tdd') ||
    cd.includes('pytest') ||
    cd.includes('vitest') ||
    cd.includes('playwright')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'Vitest & Jest Unit Testing Official Guides',
          platform_url: 'https://vitest.dev',
          topic_focus: 'Assertions, Test Runners, Mocking Functions & Code Coverage',
          resource_type: 'official_docs',
          access_badge: 'Testing Standard',
          description: 'High-speed unit testing architecture, test suites, and snapshot verification.'
        },
        {
          platform_name: 'Pytest Official Documentation',
          platform_url: 'https://docs.pytest.org/',
          topic_focus: 'Fixtures, Monkeypatching, Parametrization & Test Isolation',
          resource_type: 'official_docs',
          access_badge: 'Python Testing Standard',
          description: 'Authoritative guide to writing Python test suites with zero boilerplate.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Playwright End-to-End Automation Documentation',
          platform_url: 'https://playwright.dev/docs/intro',
          topic_focus: 'Browser Automation, E2E Workflows, Headless Testing & Tracing',
          resource_type: 'official_docs',
          access_badge: 'E2E Testing Standard',
          description: 'Multi-browser automated UI regression testing with video recording and network mocking.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Martin Fowler Testing Pyramid & Architecture Guides',
          platform_url: 'https://martinfowler.com/articles/practical-test-pyramid.html',
          topic_focus: 'Unit vs Integration vs Contract vs E2E Testing Ratios',
          resource_type: 'curated_course',
          access_badge: 'Architecture Standard',
          description: 'Engineering scalable test suites that prevent production regressions without slowing velocity.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Automated CI/CD Testing Pipeline Capstone (GitHub Actions)',
          platform_url: 'https://github.com',
          topic_focus: '95%+ Tested Production Service with Automated PR Gates',
          resource_type: 'clinical_case',
          access_badge: 'QA Capstone',
          description: 'Continuous testing pipeline running automated unit, integration, and performance benchmarks.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Test Automation University Interview & Screening Bank',
          platform_url: 'https://testautomationu.applitools.com',
          topic_focus: 'QA Automation Engineer Technical Screenings & Test Strategy Viva',
          resource_type: 'practice_arena',
          access_badge: 'QA Placement Prep',
          description: 'Technical screening drills on test design patterns, page object models, and test stability.'
        }
      ];
    }
  }

  // 12. ROBOTICS & AUTONOMOUS SYSTEMS
  if (
    dom.includes('robot') ||
    cd.includes('ros 2') ||
    cd.includes('kinematics') ||
    cd.includes('slam') ||
    cd.includes('plc') ||
    cd.includes('autonomous') ||
    cd.includes('bldc')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'ROS 2 Official Documentation & Humble/Iron Tutorials',
          platform_url: 'https://docs.ros.org/en/humble/',
          topic_focus: 'ROS 2 Nodes, Topics, Services, Action Servers & DDS Architecture',
          resource_type: 'official_docs',
          access_badge: 'Robotics Standard',
          description: 'Authoritative documentation on robot operating system architecture, node communication, and parameters.'
        },
        {
          platform_name: 'MIT Underactuated Robotics & Kinematics',
          platform_url: 'https://underactuated.csail.mit.edu',
          topic_focus: 'Denavit-Hartenberg (DH) Parameters, Forward/Inverse Kinematics & Jacobians',
          resource_type: 'curated_course',
          access_badge: 'MIT Open Courseware',
          description: 'Mathematical foundations of robotic manipulator trajectories, dynamics, and torque controls.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Nav2 (Navigation 2 Stack) & Gazebo Simulators',
          platform_url: 'https://navigation.ros.org',
          topic_focus: '2D/3D LiDAR SLAM, AMCL Localization, Costmaps & Path Planners',
          resource_type: 'interactive_lab',
          access_badge: 'Autonomous Navigation Standard',
          description: 'Simulating autonomous mobile robots in Gazebo physics engines with obstacle avoidance.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Siemens TIA Portal & Industrial PLC Training',
          platform_url: 'https://www.siemens.com',
          topic_focus: 'Ladder Logic (LAD), Structured Text (ST), SCADA & Industrial Sensors',
          resource_type: 'curated_course',
          access_badge: 'Industrial Automation',
          description: 'Industrial automation standards, factory safety interlocks, and servo actuator controls.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Autonomous Mobile Robot (AMR) Navigation Capstone (GitHub)',
          platform_url: 'https://github.com',
          topic_focus: 'ROS 2 SLAM Mapping & Autonomous Waypoint Dispatcher Prototype',
          resource_type: 'clinical_case',
          access_badge: 'Robotics Capstone',
          description: 'Complete simulation code, URDF robot definition files, and video demo of autonomous navigation.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Robotics & Automation Technical Interview Screening Bank',
          platform_url: 'https://www.indiabix.com',
          topic_focus: 'Robot Kinematics, Control Theory & ROS 2 Technical Viva',
          resource_type: 'practice_arena',
          access_badge: 'Robotics Placement Prep',
          description: 'Screening questions covering motor control, feedback loops, sensor fusion, and trajectory optimization.'
        }
      ];
    }
  }

  // 13. MBBS, MEDICINE & CLINICAL SCIENCES
  if (
    dom.includes('mbbs') ||
    dom.includes('medicine') ||
    cd.includes('clinical') ||
    cd.includes('radiology') ||
    cd.includes('pathology') ||
    cd.includes('surgery') ||
    cd.includes('pharmacology') ||
    cd.includes('pediatrics') ||
    cd.includes('ob-gyn') ||
    cd.includes('cardiology') ||
    cd.includes('emergency medicine') ||
    cd.includes('icu')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'Osmosis by Elsevier (Pathophysiology & Diagnostics)',
          platform_url: 'https://www.osmosis.org',
          topic_focus: 'Etiology, Disease Mechanisms & Foundational Clinical Signs',
          resource_type: 'curated_course',
          access_badge: 'Medical Gold Standard',
          description: 'Visual medical learning platform explaining cellular pathophysiology and diagnostic algorithms.'
        },
        {
          platform_name: 'Geeky Medics Clinical OSCE Examination Guides',
          platform_url: 'https://geekymedics.com',
          topic_focus: 'Systematic Physical Examination & History Taking',
          resource_type: 'clinical_case',
          access_badge: 'OSCE Practice Guide',
          description: 'Step-by-step physical examination checklists, diagnostic equipment usage, and clinical video guides.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Radiopaedia (Peer-Reviewed Radiology Case Library)',
          platform_url: 'https://radiopaedia.org',
          topic_focus: 'X-Ray, CT, Ultrasound & MRI Diagnostic Interpretation',
          resource_type: 'clinical_case',
          access_badge: 'Global Radiology Standard',
          description: 'Thousands of verified radiographic cases with annotated anatomical pathologies and clinical correlations.'
        },
        {
          platform_name: 'Medscape Clinical Reference & Drug Interaction Portal',
          platform_url: 'https://reference.medscape.com',
          topic_focus: 'Lab Parameter Calibration, Biomarkers & Therapeutics',
          resource_type: 'statutory_portal',
          access_badge: 'Point-of-Care Portal',
          description: 'Comprehensive medical references, reference ranges, and therapeutic dosing calculators.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'UpToDate Evidence-Based Clinical Portal',
          platform_url: 'https://www.uptodate.com',
          topic_focus: 'Differential Diagnosis, Treatment Protocols & Clinical Guidelines',
          resource_type: 'statutory_portal',
          access_badge: 'Global Clinical Evidence',
          description: 'Gold standard clinical decision support tool synthesizing latest peer-reviewed medical consensus.'
        },
        {
          platform_name: 'NCBI PubMed Central Clinical Research Archive',
          platform_url: 'https://pubmed.ncbi.nlm.nih.gov',
          topic_focus: 'Clinical Trials, Systematic Reviews & Disease Management',
          resource_type: 'official_docs',
          access_badge: 'National Library of Medicine',
          description: 'Millions of biomedical publications, clinical case series, and randomized controlled trial data.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'BMJ Best Practice & Clinical Case Reports',
          platform_url: 'https://bestpractice.bmj.com',
          topic_focus: 'Complex Multi-Morbidity Clinical Case Audit & Management',
          resource_type: 'clinical_case',
          access_badge: 'Flagship Clinical Capstone',
          description: 'Step-by-step diagnostic workflows, patient management summaries, and clinical audit frameworks.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Amboss Medical Knowledge & Residency Exam Bank',
          platform_url: 'https://www.amboss.com',
          topic_focus: 'High-Yield Clinical Vignette Screening & Residency Viva',
          resource_type: 'practice_arena',
          access_badge: 'Residency Placement Prep',
          description: 'Comprehensive USMLE, NEET-PG, and PLAB question bank with clinical case reasoning explanations.'
        }
      ];
    }
  }

  // 14. NURSING & PATIENT CARE
  if (
    dom.includes('nursing') ||
    cd.includes('nursing') ||
    cd.includes('patient care') ||
    cd.includes('triage') ||
    cd.includes('wound care')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'RegisteredNurseRN Clinical Skills & Lecture Hub',
          platform_url: 'https://www.registerednursern.com',
          topic_focus: 'Bedside Nursing Fundamentals, Vital Signs & Sterile Aseptic Techniques',
          resource_type: 'curated_course',
          access_badge: 'Nursing Standard',
          description: 'Comprehensive video tutorials and step-by-step checklists for clinical nursing procedures.'
        },
        {
          platform_name: 'Lippincott NursingCenter Clinical Procedures',
          platform_url: 'https://www.nursingcenter.com',
          topic_focus: 'Evidence-Based Nursing Protocols, IV Cannulation & Fluid Balance',
          resource_type: 'official_docs',
          access_badge: 'Clinical Evidence',
          description: 'Peer-reviewed nursing procedures, medication administration guidelines, and patient safety standards.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'American Heart Association (AHA CPR & ACLS Guidelines)',
          platform_url: 'https://cpr.heart.org',
          topic_focus: 'High-Quality CPR, Defibrillation, Code Blue Protocols & Shock Algorithms',
          resource_type: 'statutory_portal',
          access_badge: 'Emergency Resuscitation',
          description: 'Official AHA life support guidelines for critical care and emergency triage nursing.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Emergency Nurses Association (ENA) Clinical Hub',
          platform_url: 'https://www.ena.org',
          topic_focus: 'Trauma Nursing Core Course (TNCC) & ICU Ventilator Monitoring',
          resource_type: 'curated_course',
          access_badge: 'Critical Care Standard',
          description: 'Advanced protocols for hemodynamic stabilization, arterial line management, and pediatric triage.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Clinical Nursing Audit & Patient Care Plan Capstone',
          platform_url: 'https://www.nursingcenter.com',
          topic_focus: 'Comprehensive 4-Stage Nursing Care Plan (NANDA-I Formatted)',
          resource_type: 'clinical_case',
          access_badge: 'Clinical Portfolio',
          description: 'Documented multi-system patient care plan with nursing diagnoses, interventions, and evaluation metrics.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'NCLEX-RN & Staff Nurse Placement Screening Bank',
          platform_url: 'https://www.nursingcenter.com',
          topic_focus: 'Hospital Technical Viva, Medication Calculations & Triage Scenarios',
          resource_type: 'practice_arena',
          access_badge: 'Staff Nurse Placement Prep',
          description: 'Screening questions from premier hospital networks (Apollo, Fortis, NHS UK, Medanta).'
        }
      ];
    }
  }

  // 15. CORPORATE LAW & BA LLB
  if (
    dom.includes('llb') ||
    dom.includes('law') ||
    dom.includes('legal') ||
    cd.includes('commercial contract') ||
    cd.includes('corporate governance') ||
    cd.includes('civil litigation') ||
    cd.includes('criminal law') ||
    cd.includes('intellectual property') ||
    cd.includes('legal research') ||
    cd.includes('arbitration') ||
    cd.includes('due diligence') ||
    cd.includes('data privacy law') ||
    cd.includes('fintech regulatory')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'IAPP (International Association of Privacy Professionals)',
          platform_url: 'https://iapp.org/resources/',
          topic_focus: 'Data Protection Principles, DPDP Act & GDPR Frameworks',
          resource_type: 'official_docs',
          access_badge: 'Global Privacy Standard',
          description: 'Global privacy knowledge repository covering privacy governance, consent principles, and data principal rights.'
        },
        {
          platform_name: 'Ministry of Electronics & IT (DPDP Statutory Portal)',
          platform_url: 'https://www.meity.gov.in',
          topic_focus: 'Statutory Provisions, Data Fiduciary Rules & Penalties',
          resource_type: 'statutory_portal',
          access_badge: 'Government Statutory Portal',
          description: 'Official Digital Personal Data Protection Act text, notified rules, and compliance notifications.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'SCC Online Law Research & Case Tracker',
          platform_url: 'https://www.scconline.com',
          topic_focus: 'Supreme Court Case Precedents, Drafting & Clause Analysis',
          resource_type: 'statutory_portal',
          access_badge: 'Legal Research Gold Standard',
          description: 'Authoritative legal database for case law citations, judicial precedents, and legislative amendments.'
        },
        {
          platform_name: 'European Data Protection Board (EDPB) Guidelines',
          platform_url: 'https://edpb.europa.eu',
          topic_focus: 'Data Protection Impact Assessment (DPIA) & Cross-Border Rules',
          resource_type: 'official_docs',
          access_badge: 'Regulatory Enforcement',
          description: 'Statutory guidelines on breach notification, vendor processing agreements, and international transfers.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Harvard Law School Forum on Corporate Governance',
          platform_url: 'https://corpgov.law.harvard.edu',
          topic_focus: 'M&A Deal Structures, Risk Allocation & Corporate Compliance',
          resource_type: 'curated_course',
          access_badge: 'Harvard Legal Research',
          description: 'Leading discourse on corporate governance, M&A contract dispute risk, and antitrust regulations.'
        },
        {
          platform_name: 'Manupatra Knowledge & Practical Law Drafting',
          platform_url: 'https://www.manupatrafast.com',
          topic_focus: 'Advanced Commercial Contracts, Indemnity & Due Diligence',
          resource_type: 'statutory_portal',
          access_badge: 'Corporate Law Database',
          description: 'Standardized templates, judicial interpretation of commercial clauses, and corporate due diligence tools.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'WIPO Academy & Legal Portfolio Publishing',
          platform_url: 'https://www.wipo.int/academy/',
          topic_focus: 'Flagship Corporate Deal Brief & Statutory Audit Portfolio',
          resource_type: 'official_docs',
          access_badge: 'Global IP & Legal Academy',
          description: 'Authoritative commercial legal frameworks for building publishable legal briefs and deal case studies.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'LiveLaw & Lawctopus Tier 1 Firm Interview Bank',
          platform_url: 'https://www.livelaw.in',
          topic_focus: 'Corporate Law Firm Technical Screening & Moot Drills',
          resource_type: 'practice_arena',
          access_badge: 'Law Firm Placement Prep',
          description: 'Screening questions from top corporate law firms (AZB, Khaitan, SAM) and legal problem-solving rounds.'
        }
      ];
    }
  }

  // 16. BUSINESS ANALYTICS & BUSINESS INTELLIGENCE
  if (
    dom.includes('analytics') ||
    cd.includes('wrangling') ||
    cd.includes('power bi') ||
    cd.includes('tableau') ||
    cd.includes('etl') ||
    cd.includes('bpmn') ||
    cd.includes('brd') ||
    cd.includes('data storytelling') ||
    (cd.includes('sql') && dom.includes('analytics')) ||
    (cd.includes('excel') && !dom.includes('commerce') && !dom.includes('bcom') && !dom.includes('b.com'))
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'Kaggle Learn (Data Cleaning & Pandas Micro-Courses)',
          platform_url: 'https://www.kaggle.com/learn',
          topic_focus: 'Data Wrangling, Imputation, GroupBys & Exploratory Analysis',
          resource_type: 'interactive_lab',
          access_badge: 'Free Interactive Labs',
          description: 'Hands-on browser coding notebooks analyzing real-world messy datasets with Pandas and NumPy.'
        },
        {
          platform_name: 'Mode Analytics SQL & Python School',
          platform_url: 'https://mode.com/sql-tutorial/',
          topic_focus: 'Interactive SQL Queries, Joins, Aggregations & Logic',
          resource_type: 'interactive_lab',
          access_badge: 'Industry Standard Tutorial',
          description: 'Interactive query editor connected to live relational databases for foundational data analytics.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Microsoft Learn (Power BI & Advanced DAX)',
          platform_url: 'https://learn.microsoft.com/en-us/power-bi/',
          topic_focus: 'Data Modeling, DAX Measures & Star-Schema Data Warehousing',
          resource_type: 'official_docs',
          access_badge: 'Official Microsoft Standard',
          description: 'Official enterprise curriculum covering dashboard design, row-level security, and automated refreshes.'
        },
        {
          platform_name: 'Chandoo.org Advanced Excel & Financial Modeling',
          platform_url: 'https://chandoo.org',
          topic_focus: 'Dynamic Arrays, XLOOKUP, INDEX/MATCH & Pivot Dashboards',
          resource_type: 'curated_course',
          access_badge: 'Free Excel Masterclass',
          description: 'Practical business templates, formula optimization, and executive reporting methods.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Databricks Learning Hub & Apache Spark Guides',
          platform_url: 'https://www.databricks.com/learn',
          topic_focus: 'Distributed ETL Pipelines, Delta Lake & High-Volume Analytics',
          resource_type: 'curated_course',
          access_badge: 'Enterprise Big Data Standard',
          description: 'Scaling analytics from single machine scripts to distributed clusters and automated data lakes.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Tableau Public Global Visual Gallery',
          platform_url: 'https://public.tableau.com',
          topic_focus: 'Executive Storytelling Dashboard Portfolio Capstone',
          resource_type: 'clinical_case',
          access_badge: 'Portfolio Showcase Hub',
          description: 'Publish interactive analytics dashboards with live cloud connections and recruiter-facing case studies.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'StrataScratch & Interview Query',
          platform_url: 'https://www.stratascratch.com',
          topic_focus: 'FAANG / McKinsey Business Analyst Technical Interview Drills',
          resource_type: 'practice_arena',
          access_badge: 'Analyst Placement Prep',
          description: 'Over 500+ real SQL, case study, and metric estimation interview questions from top employers.'
        }
      ];
    }
  }

  // 17. BCOM, COMMERCE, IND AS, TAXATION & CORPORATE FINANCE
  if (
    dom.includes('commerce') ||
    dom.includes('bcom') ||
    dom.includes('b.com') ||
    dom.includes('accounting') ||
    dom.includes('chartered') ||
    cd.includes('ind as') ||
    cd.includes('gst') ||
    cd.includes('statutory auditing') ||
    cd.includes('tally') ||
    cd.includes('corporate finance') ||
    cd.includes('3-statement financial') ||
    cd.includes('cost & management') ||
    cd.includes('working capital') ||
    cd.includes('direct taxation') ||
    cd.includes('company law')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'ICAI Cloud Campus & Board of Studies Portal',
          platform_url: 'https://www.icai.org/post/bos-knowledge-portal',
          topic_focus: 'Ind AS Standards, Double-Entry Mechanics & Financial Statements',
          resource_type: 'official_docs',
          access_badge: 'Official Statutory Body',
          description: 'Authoritative statutory learning materials from the Institute of Chartered Accountants of India.'
        },
        {
          platform_name: 'Corporate Finance Institute (CFI) Free Resources',
          platform_url: 'https://corporatefinanceinstitute.com/resources/',
          topic_focus: 'Accounting Fundamentals, Balance Sheets & Ratio Diagnostics',
          resource_type: 'curated_course',
          access_badge: 'Global Finance Standard',
          description: 'Comprehensive financial definitions, accounting guides, and downloadable Excel templates.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'IFRS Foundation Standards Portal',
          platform_url: 'https://www.ifrs.org',
          topic_focus: 'Global IFRS Standards, Revenue Recognition & Lease Accounting',
          resource_type: 'official_docs',
          access_badge: 'Global Financial Standard',
          description: 'Official standard text, educational briefings, and illustrative disclosures for corporate reporting.'
        },
        {
          platform_name: 'GST Council & Income Tax E-Filing Knowledge Base',
          platform_url: 'https://www.gst.gov.in',
          topic_focus: 'Direct/Indirect Taxation, Input Tax Credit & Statutory Returns',
          resource_type: 'statutory_portal',
          access_badge: 'Government Tax Portal',
          description: 'Statutory GST laws, circulars, advance rulings, and compliance verification procedures.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Wall Street Prep Financial Modeling Guides',
          platform_url: 'https://www.wallstreetprep.com',
          topic_focus: '3-Statement Financial Modeling, DCF Valuation & Sensitivity',
          resource_type: 'curated_course',
          access_badge: 'Wall Street Standard',
          description: 'Industry-standard modeling practices used by Tier 1 investment banks and equity research desks.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Corporate Finance Institute (CFI) Free Resources',
          platform_url: 'https://corporatefinanceinstitute.com/resources/',
          topic_focus: 'Corporate Annual Report Audit & Equity Valuation Portfolio',
          resource_type: 'clinical_case',
          access_badge: 'Financial Case Studies',
          description: 'Real-world public company analysis templates, financial health scoring, and investment memos.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'CFI Finance & Valuation Technical Interview Guide',
          platform_url: 'https://corporatefinanceinstitute.com/resources/career/finance-interview-questions/',
          topic_focus: 'Accounting & Valuation Technical Screening Drills',
          resource_type: 'practice_arena',
          access_badge: 'Finance Placement Prep',
          description: 'Technical questions on accounting adjustments, Ind AS nuances, and working capital modeling.'
        }
      ];
    }
  }

  // 18. BBA & MANAGEMENT (BUSINESS ADMINISTRATION / MBA)
  if (
    dom.includes('bba') ||
    dom.includes('mba') ||
    dom.includes('management') ||
    cd.includes('brand marketing') ||
    cd.includes('product operations') ||
    cd.includes('business strategy') ||
    cd.includes('human capital') ||
    cd.includes('supply chain')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'Harvard Business Review (HBR) Case Studies & Insights',
          platform_url: 'https://hbr.org',
          topic_focus: 'Business Strategy, Competitive Advantage & Core Operations',
          resource_type: 'curated_course',
          access_badge: 'Harvard Business Publishing',
          description: 'Authoritative case studies analyzing market positioning, unit economics, and operational scaling.'
        },
        {
          platform_name: 'Coursera Wharton Business Foundations',
          platform_url: 'https://www.coursera.org',
          topic_focus: 'Marketing Funnels, Microeconomics & Corporate Finance',
          resource_type: 'curated_course',
          access_badge: 'Wharton School Standard',
          description: 'University-accredited foundational modules covering brand management and managerial accounting.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Product School & Mind the Product Knowledge Hub',
          platform_url: 'https://productschool.com',
          topic_focus: 'Product-Led Growth (PLG), Backlog Prioritization & User OKRs',
          resource_type: 'official_docs',
          access_badge: 'Product Management Standard',
          description: 'Industry-standard frameworks for agile roadmap planning, metrics tracking, and product launches.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'McKinsey Quarterly & Strategy Insights Hub',
          platform_url: 'https://www.mckinsey.com/capabilities/strategy-and-corporate-finance/our-insights',
          topic_focus: 'Digital Transformation, Operational Efficiency & Unit Economics',
          resource_type: 'official_docs',
          access_badge: 'Tier 1 Strategy Standard',
          description: 'Strategic frameworks for supply chain resilience, organizational design, and market disruption.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Corporate Strategy Pitch Deck & Business Plan Capstone',
          platform_url: 'https://hbr.org',
          topic_focus: 'Market Entry Strategy & 5-Year Financial Pro-Forma Model',
          resource_type: 'clinical_case',
          access_badge: 'Executive Portfolio',
          description: 'Complete executive pitch deck with TAM/SAM/SOM market sizing, unit economics, and go-to-market plan.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Case In Point & Management Consulting Case Interview Prep',
          platform_url: 'https://www.caseinterview.com',
          topic_focus: 'Management Consulting & Product Strategy Case Screenings',
          resource_type: 'practice_arena',
          access_badge: 'Consulting Placement Prep',
          description: 'Comprehensive business problem-solving frameworks for McKinsey, BCG, Bain, and Big Tech PM interviews.'
        }
      ];
    }
  }

  // 19. AVIATION & COMMERCIAL PILOT
  if (
    dom.includes('pilot') ||
    dom.includes('aviation') ||
    cd.includes('instrument flight') ||
    cd.includes('ifr') ||
    cd.includes('flight management') ||
    cd.includes('fms') ||
    cd.includes('aviation meteorology') ||
    cd.includes('crew resource') ||
    cd.includes('crm') ||
    cd.includes('dgca / faa') ||
    cd.includes('weight & balance')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: "FAA Pilot's Handbook of Aeronautical Knowledge (PHAK)",
          platform_url: 'https://www.faa.gov/regulations_policies/handbooks_manuals/aviation/',
          topic_focus: 'Principles of Flight, Aerodynamics, Aircraft Systems & Air Law',
          resource_type: 'official_docs',
          access_badge: 'Official Aviation Manual',
          description: 'The fundamental bible of aviation ground school covering aerodynamics, weight & balance, and regulations.'
        },
        {
          platform_name: 'Boldmethod Interactive Flight Training & Quizzes',
          platform_url: 'https://www.boldmethod.com',
          topic_focus: 'Visual Flight Rules, Airspace Classifications & Aviation Weather',
          resource_type: 'interactive_lab',
          access_badge: 'Interactive Flight School',
          description: 'Bite-sized aviation lessons, airspace decision trees, and meteorological report decoders.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Skybrary Aviation Safety Knowledge Portal',
          platform_url: 'https://skybrary.aero',
          topic_focus: 'Instrument Procedures, Weather Hazards & Threat Management',
          resource_type: 'statutory_portal',
          access_badge: 'ICAO / Eurocontrol Standard',
          description: 'Comprehensive aviation safety database covering wind shear, icing, CFIT, and emergency checklists.'
        },
        {
          platform_name: 'FAA Pilot Radio & Communication Flight Handbooks',
          platform_url: 'https://www.faa.gov/regulations_policies/handbooks_manuals/aviation/',
          topic_focus: 'Real-Time Air Traffic Control (ATC) Readbacks & Phraseology',
          resource_type: 'official_docs',
          access_badge: 'FAA Official Aviation Standard',
          description: 'Comprehensive guides for standard aviation phraseology, readbacks, and air-ground communications.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Jeppesen Chart Training & IFR Route Navigation',
          platform_url: 'https://ww1.jeppesen.com/aviation/training/',
          topic_focus: 'SID, STAR, RNAV (GNSS) & ILS Approach Plate Navigation',
          resource_type: 'official_docs',
          access_badge: 'Airline Navigation Standard',
          description: 'Mastering instrument departure, enroute, and precision landing approach charts used by commercial airlines.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'SimBrief & Flight Operations Flight Planning Hub',
          platform_url: 'https://www.simbrief.com',
          topic_focus: 'Operational Flight Plan (OFP), Fuel Reserves & Loadsheets',
          resource_type: 'interactive_lab',
          access_badge: 'Flight Operations Dispatch',
          description: 'Generate certified airline flight plans, load manifests, cost index profiles, and route alternates.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Pilot Aptitude & Technical Screening Guide',
          platform_url: 'https://www.pilotaptitudetest.com',
          topic_focus: 'Airline First Officer Technical Screening & Psychomotor Drills',
          resource_type: 'practice_arena',
          access_badge: 'Airline Cadet Screening',
          description: 'Aviation technical screening question banks, spatial orientation drills, and airline panel interview prep.'
        }
      ];
    }
  }

  // 20. AERONAUTICAL & AEROSPACE ENGINEERING
  if (
    dom.includes('aeronautical') ||
    dom.includes('aerospace') ||
    cd.includes('aerodynamics') ||
    cd.includes('airfoil') ||
    cd.includes('ansys fluent') ||
    cd.includes('propulsion') ||
    cd.includes('flight dynamics') ||
    cd.includes('avionics')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'NASA Glenn Research Center (Aerodynamics & Propulsion)',
          platform_url: 'https://www.grc.nasa.gov/www/k-12/airplane/',
          topic_focus: 'Lift-Drag Polars, Mach Numbers, Shock Waves & Gas Turbines',
          resource_type: 'official_docs',
          access_badge: 'NASA Official Research',
          description: 'First-principles aerodynamic equations, boundary layer theory, and propulsion thermodynamic cycles.'
        },
        {
          platform_name: 'MIT OpenCourseWare (Aerodynamics & Aircraft Structures)',
          platform_url: 'https://ocw.mit.edu/courses/aeronautics-and-astronautics/',
          topic_focus: 'Subsonic/Supersonic Aerodynamics & Fuselage Stress Analysis',
          resource_type: 'curated_course',
          access_badge: 'MIT Open Learning',
          description: 'University lecture notes, problem sets, and wing spar bending calculations from MIT faculty.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Ansys Innovation Space (Aerospace CFD Simulation)',
          platform_url: 'https://innovationspace.ansys.com/courses/',
          topic_focus: 'ANSYS Fluent Mesh Generation, k-Omega Turbulence & Flow Separation',
          resource_type: 'curated_course',
          access_badge: 'Ansys Official CFD Lab',
          description: 'Hands-on simulation physics courses covering airfoil lift-drag verification and supersonic nozzles.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'AIAA Aerospace Research Central Library',
          platform_url: 'https://arc.aiaa.org',
          topic_focus: 'Flight Control Stability Derivatives & Fly-By-Wire Systems',
          resource_type: 'official_docs',
          access_badge: 'AIAA Global Standard',
          description: 'Peer-reviewed technical standards on aircraft dynamic stability, phugoid oscillation, and avionics.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Complete Aircraft Wing Aerodynamic Design Capstone (GitHub)',
          platform_url: 'https://github.com',
          topic_focus: 'Validated 3D CFD Airfoil Mesh & Structural FEA Stress Report',
          resource_type: 'clinical_case',
          access_badge: 'Aerospace Capstone',
          description: 'End-to-end design report with ANSYS Fluent CFD pressure contours and composite laminate safety factors.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Aeronautical Technical Screening & Aerospace Viva',
          platform_url: 'https://www.indiabix.com',
          topic_focus: 'DRDO, ISRO, Boeing & Airbus Technical Screening Question Bank',
          resource_type: 'practice_arena',
          access_badge: 'Aerospace Placement Prep',
          description: 'Technical screening drills covering compressible flow, turbojets, and structural buckling.'
        }
      ];
    }
  }

  // 21. CABIN CREW & IN-FLIGHT HOSPITALITY
  if (
    dom.includes('cabin crew') ||
    cd.includes('in-flight safety') ||
    cd.includes('aviation first aid') ||
    cd.includes('galley') ||
    cd.includes('passenger conflict') ||
    cd.includes('smoke drills')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'IATA Cabin Safety Guidelines & Standards',
          platform_url: 'https://www.iata.org',
          topic_focus: 'Pre-Flight Briefings, Emergency Evacuation (90s) & Safety Equipment',
          resource_type: 'official_docs',
          access_badge: 'IATA Aviation Standard',
          description: 'Global airline safety standards for aircraft exit operations, slide deployment, and safety checks.'
        },
        {
          platform_name: 'Red Cross Aviation First Aid & Medical Triage',
          platform_url: 'https://www.redcross.org',
          topic_focus: 'Automated External Defibrillator (AED), Hypoxia Care & In-Flight Triage',
          resource_type: 'official_docs',
          access_badge: 'Medical First Aid Standard',
          description: 'Emergency protocols for managing in-flight medical emergencies, CPR, and first aid kit deployment.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Skybrary Cabin Operations & CRM Procedures',
          platform_url: 'https://skybrary.aero',
          topic_focus: 'Sterile Cockpit Rules, Fire Fighting Drills & Smoke Hood Donning',
          resource_type: 'statutory_portal',
          access_badge: 'ICAO Standard',
          description: 'Comprehensive procedures for Halon extinguisher operation, PBE smoke hood usage, and lavatory fire drills.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Emirates / Qatar Airline Service & Conflict De-escalation',
          platform_url: 'https://www.iata.org',
          topic_focus: 'First/Business Class Galley Hospitality & Air Rage Level 1-4 Restraint',
          resource_type: 'curated_course',
          access_badge: 'Luxury Aviation Service',
          description: 'Premium cabin etiquette, multi-cultural passenger communication, and assertive verbal de-escalation.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Cabin Crew Safety Emergency Briefing Simulation Portfolio',
          platform_url: 'https://www.iata.org',
          topic_focus: 'Emergency Slide Drill & Passenger Briefing Video Walkthrough',
          resource_type: 'clinical_case',
          access_badge: 'Cabin Crew Capstone',
          description: 'Recorded 90-second safety briefing demonstration, CRM callout flow, and emergency checklist audit.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Airline Assessment Day & Cabin Crew Panel Interview Guide',
          platform_url: 'https://www.flightdeckfriend.com',
          topic_focus: 'IndiGo, Emirates, Qatar Airways & Air India Assessment Day Prep',
          resource_type: 'practice_arena',
          access_badge: 'Cabin Crew Placement Prep',
          description: 'Group discussion scenarios, grooming standards, reach test criteria, and behavioral STAR interviews.'
        }
      ];
    }
  }

  // 22. MECHANICAL & INDUSTRIAL ENGINEERING
  if (
    dom.includes('mech') ||
    cd.includes('solidworks') ||
    cd.includes('gd&t') ||
    cd.includes('ansys structural') ||
    cd.includes('fea') ||
    cd.includes('cnc machining') ||
    cd.includes('thermodynamics') ||
    cd.includes('dfma')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'Autodesk Design & CAD Official Support Hub',
          platform_url: 'https://www.autodesk.com/support',
          topic_focus: 'Parametric 3D Modeling, 2D Drafting & Geometric Constraints',
          resource_type: 'official_docs',
          access_badge: 'Official Autodesk Standard',
          description: 'Fundamental guides on sketch constraints, feature creation, extrusions, and drawing sheets.'
        },
        {
          platform_name: 'GrabCAD Community Tutorials & 3D Model Library',
          platform_url: 'https://grabcad.com/tutorials',
          topic_focus: 'Applied Mechanical Design, Assemblies & CAD Best Practices',
          resource_type: 'interactive_lab',
          access_badge: 'Global CAD Community',
          description: 'Community-contributed CAD tutorials, open-source 3D CAD files, and design challenges.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'ASME Y14.5 GD&T Standards & Tolerancing Guide',
          platform_url: 'https://www.asme.org',
          topic_focus: 'Geometric Dimensioning & Tolerancing (GD&T) and Datums',
          resource_type: 'official_docs',
          access_badge: 'ASME Industry Standard',
          description: 'Engineering standards for datum reference frames, position tolerancing, and tolerance stackups.'
        },
        {
          platform_name: 'Ansys Innovation Space (Free Simulation Courses)',
          platform_url: 'https://innovationspace.ansys.com/courses/',
          topic_focus: 'Finite Element Analysis (FEA), Meshing & Stress Simulation',
          resource_type: 'curated_course',
          access_badge: 'Free Ansys Engineering Lab',
          description: 'Hands-on simulation physics courses covering structural mechanics, thermal dissipation, and fluids.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'MIT OpenCourseWare (Mechanical Engineering)',
          platform_url: 'https://ocw.mit.edu/courses/mechanical-engineering/',
          topic_focus: 'Advanced Dynamics, Machine Design & Material Mechanics',
          resource_type: 'curated_course',
          access_badge: 'MIT Open Learning',
          description: 'University-level lecture notes, design problem sets, and mechanical system modeling.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'SAE International Mobility & Vehicle Engineering',
          platform_url: 'https://www.sae.org',
          topic_focus: 'Verified Mechanical Subsystem Prototype & DFM Portfolio',
          resource_type: 'official_docs',
          access_badge: 'Automotive & Aerospace Standard',
          description: 'Design for Manufacturing (DFM) guidelines, testing standards, and capstone technical documentation.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Mechanical Engineering Technical Interview Drills',
          platform_url: 'https://www.indiabix.com/mechanical-engineering/questions-and-answers/',
          topic_focus: 'Core Engineering Technical Viva, DFM & CAD Screening',
          resource_type: 'practice_arena',
          access_badge: 'Core Placement Prep',
          description: 'Technical screening questions covering manufacturing processes, thermodynamics, and machine design.'
        }
      ];
    }
  }

  // 23. CIVIL ENGINEERING & BIM
  if (
    dom.includes('civil') ||
    cd.includes('staad') ||
    cd.includes('revit') ||
    cd.includes('bim') ||
    cd.includes('reinforced concrete') ||
    cd.includes('rcc') ||
    cd.includes('geotechnical') ||
    cd.includes('quantity surveying') ||
    cd.includes('boq')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'Autodesk Student & Education BIM Community',
          platform_url: 'https://www.autodesk.com/education/home',
          topic_focus: 'Building Information Modeling (BIM), 3D Structural Modeling',
          resource_type: 'official_docs',
          access_badge: 'Autodesk BIM Standard',
          description: 'Foundational BIM modeling, family creation, parameter scheduling, and construction drawings.'
        },
        {
          platform_name: 'NPTEL Civil Engineering (IIT Faculty Lectures)',
          platform_url: 'https://nptel.ac.in',
          topic_focus: 'Structural Analysis, Strength of Materials & Concrete Design',
          resource_type: 'curated_course',
          access_badge: 'Free IIT Courseware',
          description: 'University-level lectures and problem-solving modules from premier IIT engineering faculty.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'ASCE American Society of Civil Engineers Portal',
          platform_url: 'https://www.asce.org',
          topic_focus: 'Geotechnical Engineering, Foundation Design & IS/ACI Codes',
          resource_type: 'official_docs',
          access_badge: 'Global Civil Standard',
          description: 'Design codes, structural peer-reviewed papers, and seismic vulnerability assessments.'
        },
        {
          platform_name: 'Bentley Learn Server (STAAD.Pro & OpenRoads)',
          platform_url: 'https://learn.bentley.com',
          topic_focus: '3D Frame Analysis, Load Combinations & Shear Force Modeling',
          resource_type: 'curated_course',
          access_badge: 'Infrastructure Standard',
          description: 'Professional training in multi-story frame analysis, finite element plate modeling, and foundation design.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Autodesk Construction Cloud (BIM 360 Clash Detection)',
          platform_url: 'https://construction.autodesk.com',
          topic_focus: 'Inter-Disciplinary Clash Detection & Construction Scheduling',
          resource_type: 'official_docs',
          access_badge: 'Enterprise BIM Platform',
          description: 'Navisworks clash reports, 4D time-schedule simulation, and quantity takeoff (BOQ).'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Civil Engineering Multi-Story Structural Capstone',
          platform_url: 'https://www.asce.org',
          topic_focus: 'Flagship Multi-Story Building Structural Audit & Portfolio',
          resource_type: 'clinical_case',
          access_badge: 'Flagship Infrastructure Project',
          description: 'Complete structural design drawings, BOQ estimation sheets, and BIM coordination models.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Civil Engineering Technical Screening & EPC Exam Prep',
          platform_url: 'https://www.indiabix.com/civil-engineering/questions-and-answers/',
          topic_focus: 'L&T / EPC Site Engineer Viva & IS Code Screening',
          resource_type: 'practice_arena',
          access_badge: 'Site Engineer Placement Prep',
          description: 'Practical site engineering interview questions, slump tests, concrete curing standards, and estimation.'
        }
      ];
    }
  }

  // 24. ELECTRICAL & ELECTRONICS ENGINEERING
  if (
    dom.includes('electrical') ||
    dom.includes('electronic') ||
    cd.includes('embedded c') ||
    cd.includes('vlsi') ||
    cd.includes('pcb design') ||
    cd.includes('altium') ||
    cd.includes('power electronics') ||
    cd.includes('matlab simulink') ||
    cd.includes('battery management')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'All About Circuits (Electrical Engineering Hub)',
          platform_url: 'https://www.allaboutcircuits.com',
          topic_focus: 'Kirchhoff Laws, Semiconductor Physics, Op-Amps & Digital Logic',
          resource_type: 'official_docs',
          access_badge: 'EE Gold Standard',
          description: 'Comprehensive tutorials, interactive circuit simulators, and component datasheets.'
        },
        {
          platform_name: 'ARM Developer Architecture & Cortex-M Portal',
          platform_url: 'https://developer.arm.com',
          topic_focus: 'ARM Cortex-M Embedded C, Register Level Configuration & Interrupts',
          resource_type: 'official_docs',
          access_badge: 'ARM Official',
          description: 'Official ARM documentation covering registers, nested vectored interrupt controllers (NVIC), and timers.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Altium Academy (PCB Layout & High-Speed Routing)',
          platform_url: 'https://www.altium.com/resources',
          topic_focus: 'Multi-Layer PCB Routing, Differential Pairs & Impedance Matching',
          resource_type: 'interactive_lab',
          access_badge: 'PCB Design Standard',
          description: 'Master schematic capture, component footprint creation, and Gerber manufacturing exports.'
        },
        {
          platform_name: 'MATLAB & Simulink Onramp Courses',
          platform_url: 'https://matlabacademy.mathworks.com',
          topic_focus: 'Transfer Functions, Bode Plots, Closed-Loop PID & Motor Simulation',
          resource_type: 'curated_course',
          access_badge: 'MathWorks Official',
          description: 'Interactive browser modeling of power electronics, DC-DC buck converters, and feedback controllers.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Cadence & Synopsys VLSI Digital Design Portal',
          platform_url: 'https://www.cadence.com',
          topic_focus: 'Verilog RTL Coding, Testbenches, Static Timing Analysis (STA) & FPGA Synthesis',
          resource_type: 'curated_course',
          access_badge: 'Semiconductor Standard',
          description: 'Modern VLSI design flows, finite state machines, clock domain crossing, and FPGA programming.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Custom Embedded IoT / EV BMS Hardware Capstone (GitHub)',
          platform_url: 'https://github.com',
          topic_focus: 'Verified 4-Layer PCB Gerber Files & ARM Cortex-M C Firmware',
          resource_type: 'clinical_case',
          access_badge: 'Hardware Capstone',
          description: 'Complete hardware project with Altium schematics, bill of materials, and working firmware repository.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Texas Instruments / Qualcomm Technical Screening Bank',
          platform_url: 'https://www.indiabix.com/electronics-and-communication-engineering/questions-and-answers/',
          topic_focus: 'VLSI Timing Closure, Embedded C Memory Layout & Power Electronics Viva',
          resource_type: 'practice_arena',
          access_badge: 'Core EE Placement Prep',
          description: 'Technical screening questions asked by Texas Instruments, Qualcomm, Intel, NVIDIA, and Schneider.'
        }
      ];
    }
  }

  // 25. CHEMICAL & PROCESS ENGINEERING
  if (
    dom.includes('chem') ||
    cd.includes('aspen') ||
    cd.includes('mass & energy') ||
    cd.includes('distillation') ||
    cd.includes('hazop') ||
    cd.includes('p&id')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'LearnChemE (University of Colorado Boulder)',
          platform_url: 'https://learncheme.com',
          topic_focus: 'Mass & Energy Balances, Unit Operations & Chemical Thermodynamics',
          resource_type: 'curated_course',
          access_badge: 'University Standard',
          description: 'Over 1,000 interactive screencasts and simulations covering distillation, reaction kinetics, and fluids.'
        },
        {
          platform_name: 'NIST Chemistry WebBook',
          platform_url: 'https://webbook.nist.gov/chemistry/',
          topic_focus: 'Thermochemical Properties, Phase Enthalpy & Vapor Pressures',
          resource_type: 'official_docs',
          access_badge: 'Statutory Thermodata',
          description: 'Authoritative chemical thermodynamic data for process simulation and equilibrium flash calculations.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'Aspen Plus & HYSYS Process Simulation Academy',
          platform_url: 'https://www.aspentech.com',
          topic_focus: 'NRTL/Peng-Robinson Property Models, Flash Distillation & Flowsheets',
          resource_type: 'curated_course',
          access_badge: 'Aspen Standard',
          description: 'Chemical process flowsheet convergence, McCabe-Thiele column sizing, and heat exchanger networks.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'AIChE / CCPS Center for Chemical Process Safety',
          platform_url: 'https://www.aiche.org/ccps',
          topic_focus: 'HAZOP Guide Words, Layer of Protection Analysis (LOPA) & Relief Sizing',
          resource_type: 'statutory_portal',
          access_badge: 'Process Safety Standard',
          description: 'Statutory plant safety guidelines, risk mitigation, and industrial P&ID instrumentation.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Chemical Refining Plant Flowsheet Simulation Capstone',
          platform_url: 'https://www.aiche.org',
          topic_focus: 'Complete Aspen Plus Simulation File, P&ID and HAZOP Safety Report',
          resource_type: 'clinical_case',
          access_badge: 'Chemical Capstone',
          description: 'End-to-end chemical plant design package with mass balances, equipment sizing, and safety audit.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Chemical Engineering Technical Screening & Plant Viva',
          platform_url: 'https://www.indiabix.com/chemical-engineering/questions-and-answers/',
          topic_focus: 'Reliance, IOCL, Dow & BASF Technical Screening Question Bank',
          resource_type: 'practice_arena',
          access_badge: 'Chemical Placement Prep',
          description: 'Screening questions covering distillation hydraulics, pump NPSH calculations, and reactor kinetics.'
        }
      ];
    }
  }

  // 26. BIOTECHNOLOGY & BIOPROCESSING
  if (
    dom.includes('bio') ||
    cd.includes('crispr') ||
    cd.includes('fermentation') ||
    cd.includes('chromatography') ||
    cd.includes('bio-informatics') ||
    cd.includes('biosensors') ||
    cd.includes('cgmp')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'NCBI BLAST & GenBank Bio-Informatics Portal',
          platform_url: 'https://blast.ncbi.nlm.nih.gov/Blast.cgi',
          topic_focus: 'Nucleotide/Protein Sequence Alignment, BioPython & FASTA Parsing',
          resource_type: 'official_docs',
          access_badge: 'NIH / NCBI Standard',
          description: 'Authoritative biological database for searching genomic sequences, protein domains, and mutations.'
        },
        {
          platform_name: 'Addgene CRISPR & Recombinant DNA Plasmids Guide',
          platform_url: 'https://www.addgene.org/guides/crispr/',
          topic_focus: 'Guide RNA Design, Plasmid Cloning, Restriction Enzymes & Transfection',
          resource_type: 'official_docs',
          access_badge: 'Genetic Engineering Standard',
          description: 'Step-by-step molecular biology protocols for targeted gene editing and expression vectors.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'RCSB Protein Data Bank (PDB) & PyMOL 3D Visualization',
          platform_url: 'https://www.rcsb.org',
          topic_focus: '3D Protein Crystallography, Active Binding Sites & Molecular Docking',
          resource_type: 'interactive_lab',
          access_badge: 'Structural Biology Standard',
          description: 'Exploring molecular structures, enzyme-substrate interactions, and ligand binding affinities.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Bio-Rad HPLC Chromatography & Bioprocessing Learning Center',
          platform_url: 'https://www.bio-rad.com',
          topic_focus: 'Affinity Chromatography, FPLC, Bioreactor Kinetics & cGMP Compliance',
          resource_type: 'curated_course',
          access_badge: 'Biopharma Standard',
          description: 'Industrial downstream protein purification, cleanroom ISO validation, and FDA 21 CFR Part 11.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Biotech Recombinant Protein Expression Capstone (GitHub)',
          platform_url: 'https://github.com',
          topic_focus: 'Verified In-Silico Molecular Docking & Bioreactor Process Audit',
          resource_type: 'clinical_case',
          access_badge: 'Biotech Capstone',
          description: 'Full computational research paper with binding affinity scores, SDS-PAGE yield analysis, and SOPs.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Biocon / Serum Institute / Biopharma Technical Screening Bank',
          platform_url: 'https://www.indiabix.com/biotechnology/questions-and-answers/',
          topic_focus: 'Fermentation Kinetics, Chromatography & Molecular Biology Viva',
          resource_type: 'practice_arena',
          access_badge: 'Biotech Placement Prep',
          description: 'Technical screening questions from leading biopharma, vaccine manufacturing, and genomics employers.'
        }
      ];
    }
  }

  // 27. MARINE ENGINEERING & NAVAL ARCHITECTURE
  if (
    dom.includes('marine') ||
    dom.includes('naval') ||
    cd.includes('marine diesel') ||
    cd.includes('ship hydrostatics') ||
    cd.includes('auxiliary boilers') ||
    cd.includes('marpol') ||
    cd.includes('maxsurf') ||
    cd.includes('watchkeeping')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'IMO MARPOL Knowledge Base & SOLAS Safety Conventions',
          platform_url: 'https://www.imo.org',
          topic_focus: 'Annex I-VI Pollution Prevention, Sulfur Caps & Safety at Sea',
          resource_type: 'official_docs',
          access_badge: 'UN Maritime Standard',
          description: 'Authoritative international maritime regulations for commercial ships, tankers, and cargo vessels.'
        },
        {
          platform_name: 'Wärtsilä Marine Diesel Engines Academy',
          platform_url: 'https://www.wartsila.com',
          topic_focus: '2-Stroke Slow-Speed Crosshead Engines & Turbocharging Cycles',
          resource_type: 'official_docs',
          access_badge: 'Marine Propulsion Standard',
          description: 'Indicator diagrams, fuel injection pumps, scavenging air systems, and power calculation methods.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'SNAME (Society of Naval Architects & Marine Engineers)',
          platform_url: 'https://www.sname.org',
          topic_focus: 'Ship Hydrostatics, Metacentric Height (GM) & Damage Stability',
          resource_type: 'curated_course',
          access_badge: 'Naval Architecture Standard',
          description: 'Cross curves of stability, crosshead stress distribution, and ballast water management.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'Maxsurf 3D Hull Modeling & Resistance Prediction Guides',
          platform_url: 'https://www.bentley.com/software/maxsurf/',
          topic_focus: 'Parametric Hull Surface Generation, Resistance & Cavitation',
          resource_type: 'curated_course',
          access_badge: 'Naval CAD Standard',
          description: 'Computer-aided hull lines plan drafting, wave-making resistance, and propeller blade pitch optimization.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Complete Cargo Ship Machinery & Stability Dossier Capstone',
          platform_url: 'https://www.imo.org',
          topic_focus: 'Certified Ship Metacentric Stability & Auxiliary Purifier Logbook',
          resource_type: 'clinical_case',
          access_badge: 'Marine Capstone',
          description: 'Complete naval architecture calculations, trim sheet, and machinery watchkeeping logs.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'STCW & Marine Chief Engineer Technical Screening Bank',
          platform_url: 'https://www.dieselship.com',
          topic_focus: 'Maersk, Fleet Management & Anglo-Eastern Technical Oral Viva',
          resource_type: 'practice_arena',
          access_badge: 'Merchant Navy Placement Prep',
          description: 'Technical screening questions on marine diesel troubleshooting, emergency steering, and bunker analysis.'
        }
      ];
    }
  }

  // 28. BA HONS / HUMANITIES & PUBLIC POLICY
  if (
    dom.includes('humanities') ||
    dom.includes('hons') ||
    dom.includes('social') ||
    cd.includes('public policy') ||
    cd.includes('social research') ||
    cd.includes('macroeconomic') ||
    cd.includes('strategic communications') ||
    cd.includes('csr & esg')
  ) {
    if (phaseIndex === 0) {
      return [
        {
          platform_name: 'NITI Aayog & Public Policy Formulation Knowledge Portal',
          platform_url: 'https://www.niti.gov.in',
          topic_focus: 'Policy Life Cycle, Regulatory Impact Assessments & Stakeholder Mapping',
          resource_type: 'official_docs',
          access_badge: 'Government Policy Portal',
          description: 'Authoritative policy whitepapers, development metrics, and governance program evaluations.'
        },
        {
          platform_name: 'JSTOR Digital Research Archive',
          platform_url: 'https://www.jstor.org',
          topic_focus: 'Peer-Reviewed Social Theory, Qualitative Methodologies & Ethnography',
          resource_type: 'official_docs',
          access_badge: 'Academic Research Gold Standard',
          description: 'Leading digital library of academic journals, books, and primary research sources across the humanities.'
        }
      ];
    } else if (phaseIndex === 1) {
      return [
        {
          platform_name: 'World Bank Open Knowledge Repository',
          platform_url: 'https://openknowledge.worldbank.org',
          topic_focus: 'Macroeconomic Modeling, Development Indicators & Fiscal Policies',
          resource_type: 'statutory_portal',
          access_badge: 'Global Development Standard',
          description: 'Global economic reports, poverty metrics, inflation tracking, and trade balance datasets.'
        }
      ];
    } else if (phaseIndex === 2) {
      return [
        {
          platform_name: 'GRI (Global Reporting Initiative) & ESG Standards Hub',
          platform_url: 'https://www.globalreporting.org',
          topic_focus: 'Corporate Social Responsibility (CSR), ESG Auditing & Impact Reporting',
          resource_type: 'official_docs',
          access_badge: 'ESG Sustainability Standard',
          description: 'International standards for sustainability reporting, stakeholder impact analysis, and ESG frameworks.'
        }
      ];
    } else if (phaseIndex === 3) {
      return [
        {
          platform_name: 'Public Policy Whitepaper & Strategic Brief Portfolio',
          platform_url: 'https://www.orfonline.org',
          topic_focus: 'Published Think Tank Policy Brief with Quantified Data Models',
          resource_type: 'clinical_case',
          access_badge: 'Policy Capstone',
          description: 'Comprehensive policy brief analyzing regulatory bottlenecks with multi-variable economic projections.'
        }
      ];
    } else {
      return [
        {
          platform_name: 'Think Tank, NGO & Policy Analyst Technical Screening Guide',
          platform_url: 'https://www.cprindia.org',
          topic_focus: 'Policy Case Interview, Data Interpretation & Oral Advocacy Screening',
          resource_type: 'practice_arena',
          access_badge: 'Policy Placement Prep',
          description: 'Technical screening drills for research fellowships, international consultancies, and think tanks.'
        }
      ];
    }
  }

  // 29. UNIVERSAL SAFE FALLBACK
  const cleanDomain = getCanonicalDomain(domain);
  if (phaseIndex === 0) {
    return [
      {
        platform_name: `Official ${coDomain} Documentation & Knowledge Base`,
        platform_url: 'https://www.coursera.org',
        topic_focus: `Foundational Principles, Terminology & Specifications of ${coDomain}`,
        resource_type: 'official_docs',
        access_badge: 'Foundational Knowledge',
        description: `Verified core standards, introductory modules, and foundational specifications for ${coDomain}.`
      },
      {
        platform_name: 'edX & MIT Open Learning Library',
        platform_url: 'https://www.edx.org',
        topic_focus: 'First-Principles Theory & University Problem Sets',
        resource_type: 'curated_course',
        access_badge: 'Free University Audit',
        description: 'Structured university-level lectures and baseline problem sets from leading global institutions.'
      }
    ];
  } else if (phaseIndex === 1) {
    return [
      {
        platform_name: 'MIT OpenCourseWare & Open Learning Library',
        platform_url: 'https://ocw.mit.edu',
        topic_focus: `Applied Systems, Engineering & Practical Computing for ${coDomain}`,
        resource_type: 'curated_course',
        access_badge: 'Free MIT Courseware',
        description: 'Open course lecture series, assignments, and problem sets covering applied engineering and systems.'
      }
    ];
  } else if (phaseIndex === 2) {
    return [
      {
        platform_name: 'JSTOR & National Standards Knowledge Hub',
        platform_url: 'https://www.jstor.org',
        topic_focus: 'Advanced System Standards, Quality Assurance & Optimization',
        resource_type: 'statutory_portal',
        access_badge: 'Statutory Standards',
        description: 'Peer-reviewed journals, regulatory benchmarks, and high-performance system optimization guidelines.'
      }
    ];
  } else if (phaseIndex === 3) {
    return [
      {
        platform_name: 'GitHub / Public Portfolio Publishing Platform',
        platform_url: 'https://github.com',
        topic_focus: `Flagship Production Capstone Project in ${coDomain}`,
        resource_type: 'clinical_case',
        access_badge: 'Portfolio Showcase',
        description: 'Publish your end-to-end verified case study, architecture documentation, and live demo.'
      }
    ];
  } else {
    return [
      {
        platform_name: `${cleanDomain} Technical Screening & Placement Prep`,
        platform_url: 'https://www.indiabix.com',
        topic_focus: `${coDomain} Technical Viva, Screening Drills & Resume ATS`,
        resource_type: 'practice_arena',
        access_badge: 'Placement Preparation',
        description: `Industry screening questions and problem-solving scenarios for top ${cleanDomain} recruiters.`
      }
    ];
  }
}

// -------------------------------------------------------------
// Universal Beginner-to-Internship & Placement Level Generator
// -------------------------------------------------------------
export function generateCoDomainRoadmap(coDomainName: string, domainName: string): LearningRoadmap {
  const nameLower = (coDomainName || '').toLowerCase();
  const canonicalDomain = getCanonicalDomain(domainName);
  const domainLower = canonicalDomain.toLowerCase();

  // Find matching definition
  let matchedDef: CoDomainDefinition | undefined;
  for (const domKey of Object.keys(DOMAIN_CO_DOMAINS)) {
    if (domKey.toLowerCase() === domainLower || domainLower.includes(domKey.toLowerCase())) {
      const list = DOMAIN_CO_DOMAINS[domKey];
      const found = list.find(item => item.name.toLowerCase() === nameLower || nameLower.includes(item.name.toLowerCase()) || item.name.toLowerCase().includes(nameLower));
      if (found) {
        matchedDef = found;
        break;
      }
    }
  }

  if (!matchedDef) {
    for (const domKey of Object.keys(DOMAIN_CO_DOMAINS)) {
      const list = DOMAIN_CO_DOMAINS[domKey];
      const found = list.find(item => item.name.toLowerCase() === nameLower || nameLower.includes(item.name.toLowerCase()) || item.name.toLowerCase().includes(nameLower));
      if (found) {
        matchedDef = found;
        break;
      }
    }
  }

  // Intelligent CSE alias fallback
  if (!matchedDef && (canonicalDomain === 'Computer Science' || domainLower.includes('computer') || domainLower.includes('software'))) {
    const csList = DOMAIN_CO_DOMAINS['Computer Science'] || [];
    if (nameLower.includes('react')) matchedDef = csList.find(c => c.id === 'cs-react');
    else if (nameLower.includes('llm') || nameLower.includes('artificial intelligence') || nameLower.includes('machine learning') || nameLower.includes('genai') || /\bai\b/.test(nameLower)) matchedDef = csList.find(c => c.id === 'cs-ml');
    else if (nameLower.includes('fullstack') || nameLower.includes('full stack') || nameLower.includes('mern') || nameLower.includes('pern')) matchedDef = csList.find(c => c.id === 'cs-fullstack');
    else if (nameLower.includes('graphql') || (nameLower.includes('graph') && !nameLower.includes('dsa') && !nameLower.includes('algorithm'))) matchedDef = csList.find(c => c.id === 'cs-graphql');
    else if (nameLower.includes('nosql') || nameLower.includes('mongo') || nameLower.includes('dynamo')) matchedDef = csList.find(c => c.id === 'cs-nosql');
    else if (nameLower.includes('sql') || nameLower.includes('relational') || nameLower.includes('postgres')) matchedDef = csList.find(c => c.id === 'cs-sql');
    else if (nameLower.includes('dsa') || nameLower.includes('algorithm') || nameLower.includes('data structure') || nameLower.includes('leetcode')) matchedDef = csList.find(c => c.id === 'cs-dsa');
    else if (nameLower.includes('docker') || nameLower.includes('container') || nameLower.includes('kubernetes') || nameLower.includes('k8s')) matchedDef = csList.find(c => c.id === 'cs-docker');
    else if (nameLower.includes('fastapi')) matchedDef = csList.find(c => c.id === 'cs-fastapi');
    else if (nameLower.includes('node') || nameLower.includes('express')) matchedDef = csList.find(c => c.id === 'cs-nodejs');
    else if (nameLower.includes('cloud') || nameLower.includes('aws') || nameLower.includes('gcp')) matchedDef = csList.find(c => c.id === 'cs-cloud');
    else if (nameLower.includes('sysdesign') || nameLower.includes('system design') || nameLower.includes('distributed')) matchedDef = csList.find(c => c.id === 'cs-sysdesign');
    else if (nameLower.includes('redis') || nameLower.includes('cache')) matchedDef = csList.find(c => c.id === 'cs-redis');
    else if (nameLower.includes('devops') || nameLower.includes('ci/cd') || nameLower.includes('pipeline')) matchedDef = csList.find(c => c.id === 'cs-devops');
    else if (nameLower.includes('security') || nameLower.includes('oauth') || nameLower.includes('jwt') || nameLower.includes('cyber')) matchedDef = csList.find(c => c.id === 'cs-security');
    else if (nameLower.includes('typescript') || nameLower.includes('type safety')) matchedDef = csList.find(c => c.id === 'cs-ts');
    else if (nameLower.includes('python')) matchedDef = csList.find(c => c.id === 'cs-python');
    else if (nameLower.includes('kafka') || nameLower.includes('rabbitmq') || nameLower.includes('event-driven')) matchedDef = csList.find(c => c.id === 'cs-kafka');
    else if (nameLower.includes('test') || nameLower.includes('tdd') || nameLower.includes('pytest') || nameLower.includes('vitest')) matchedDef = csList.find(c => c.id === 'cs-testing');
  }

  const effectiveDomain = matchedDef?.domain || canonicalDomain;
  const effectiveCoDomain = matchedDef?.name || coDomainName;

  // Domain-accurate placement benchmarks
  const domUpper = effectiveDomain.toUpperCase();
  let hiringCompanies = ['Top Tier Global Enterprises', 'Leading Industry Consultancies', 'High-Growth Tech Unicorns', 'Specialized Research Centers'];
  let salaryRange = '₹8.0L – ₹28.0L / yr (Based on verified placement benchmarks)';
  let specificKeywords = [effectiveCoDomain, `${effectiveDomain} Core`, 'Root Cause Analysis', 'Standard Operating Procedures', 'Verification & Testing', 'Quality Assurance'];

  if (domUpper.includes('COMPUTER') || domUpper.includes('SOFTWARE') || effectiveDomain === 'Computer Science') {
    hiringCompanies = ['Google', 'Microsoft', 'Amazon', 'Meta', 'Uber', 'Adobe', 'Razorpay', 'Flipkart'];
    salaryRange = '₹8.5L – ₹35.0L / yr (Verified Tech Placement Benchmark)';
    specificKeywords = [effectiveCoDomain, 'Data Structures & Algorithms', 'Time Complexity O(1)/O(n)', 'System Design', 'Clean Code', 'REST APIs', 'Unit Testing', 'CI/CD'];
  } else if (domUpper.includes('MBBS') || domUpper.includes('MEDICINE')) {
    hiringCompanies = ['Apollo Hospitals', 'Fortis Healthcare', 'Max Healthcare', 'Manipal Hospitals', 'Medanta', 'AIIMS'];
    salaryRange = '₹10.0L – ₹36.0L / yr (Clinical Specialist Benchmark)';
    specificKeywords = [effectiveCoDomain, 'Differential Diagnosis', 'Physical Examination', 'Patient Triage (ATLS)', 'SOP Compliance', 'Radiology Interpretation', 'BLS / ACLS'];
  } else if (domUpper.includes('NURSING')) {
    hiringCompanies = ['Apollo Hospitals', 'Fortis', 'Max Healthcare', 'NHS UK', 'Cleveland Clinic', 'Medanta'];
    salaryRange = '₹5.5L – ₹20.0L / yr (Healthcare Benchmark)';
    specificKeywords = [effectiveCoDomain, 'Patient Care Plan', '5 Rights of Medication', 'ICU Hemodynamic Monitoring', 'Aseptic Wound Care', 'CPR / ACLS'];
  } else if (domUpper.includes('LAW') || domUpper.includes('LLB')) {
    hiringCompanies = ['AZB & Partners', 'Khaitan & Co', 'Shardul Amarchand Mangaldas', 'Trilegal', 'Cyril Amarchand Mangaldas', 'JSA Law'];
    salaryRange = '₹9.0L – ₹32.0L / yr (Tier-1 Law Firm Benchmark)';
    specificKeywords = [effectiveCoDomain, 'Commercial Contract Drafting', 'Indemnity & Liability', 'DPDP Act / GDPR', 'Legal Precedent Synthesis', 'Due Diligence Audit'];
  } else if (domUpper.includes('ANALYTICS') || effectiveDomain === 'Business Analytics') {
    hiringCompanies = ['McKinsey', 'Bain & Company', 'BCG', 'Fractal Analytics', 'Mu Sigma', 'Deloitte', 'Tiger Analytics'];
    salaryRange = '₹8.0L – ₹28.0L / yr (Decision Intelligence Benchmark)';
    specificKeywords = [effectiveCoDomain, 'SQL Window Functions', 'Data Wrangling (Pandas)', 'Power BI & DAX', 'Advanced Excel Modeling', 'Executive Storytelling', 'A/B Testing'];
  } else if (domUpper.includes('COMMERCE') || domUpper.includes('BCOM')) {
    hiringCompanies = ['EY', 'PwC', 'KPMG', 'Deloitte', 'BDO India', 'Grant Thornton', 'Morgan Stanley'];
    salaryRange = '₹6.5L – ₹24.0L / yr (Corporate Finance Benchmark)';
    specificKeywords = [effectiveCoDomain, 'Ind AS / IFRS Compliance', 'GST Return Filing (GSTR 1/3B)', 'Statutory Auditing (CARO)', '3-Statement Financial Modeling', 'DCF Valuation', 'TallyPrime'];
  } else if (domUpper.includes('BBA') || domUpper.includes('MANAGEMENT')) {
    hiringCompanies = ['Amazon', 'Hindustan Unilever', 'P&G', 'Zomato', 'Swiggy', 'Accenture Strategy', 'Gartner'];
    salaryRange = '₹6.5L – ₹26.0L / yr (Strategy & Growth Benchmark)';
    specificKeywords = [effectiveCoDomain, 'Business Strategy & OKRs', 'Product-Led Growth (PLG)', 'Brand Marketing Funnels', 'Customer Acquisition Cost (CAC)', 'Unit Economics'];
  } else if (domUpper.includes('PILOT') || domUpper.includes('AVIATION')) {
    hiringCompanies = ['IndiGo Airlines', 'Air India', 'Emirates', 'Qatar Airways', 'Singapore Airlines', 'SpiceJet'];
    salaryRange = '₹14.0L – ₹45.0L / yr (Airline Cadet / First Officer Benchmark)';
    specificKeywords = [effectiveCoDomain, 'Instrument Flight Rules (IFR)', 'FMS MCDU Navigation', 'Aviation Meteorology (METAR/TAF)', 'Crew Resource Management (CRM)', 'DGCA Air Law'];
  } else if (domUpper.includes('AERONAUTICAL') || domUpper.includes('AEROSPACE')) {
    hiringCompanies = ['ISRO', 'DRDO', 'Hindustan Aeronautics (HAL)', 'Boeing India', 'Airbus Engineering', 'Collins Aerospace'];
    salaryRange = '₹7.5L – ₹28.0L / yr (Aerospace Benchmark)';
    specificKeywords = [effectiveCoDomain, 'Aerodynamics & Lift-Drag Polars', 'ANSYS Fluent CFD Mesh', 'Fuselage FEA Stress', 'Gas Turbine Propulsion', 'Flight Dynamics'];
  } else if (domUpper.includes('CABIN CREW')) {
    hiringCompanies = ['Emirates', 'Etihad Airways', 'Qatar Airways', 'Singapore Airlines', 'Air India', 'IndiGo'];
    salaryRange = '₹6.0L – ₹22.0L / yr (Global Cabin Crew Benchmark)';
    specificKeywords = [effectiveCoDomain, '90-Second Cabin Evacuation', 'Aviation First Aid & AED', 'CRM SOP Callouts', 'Luxury Galley Hospitality', 'De-escalation Protocols'];
  } else if (domUpper.includes('MECHANICAL')) {
    hiringCompanies = ['Tata Motors', 'Mahindra & Mahindra', 'Larsen & Toubro', 'Bosch', 'Cummins', 'Tesla', 'General Electric'];
    salaryRange = '₹6.5L – ₹25.0L / yr (Core Engineering Benchmark)';
    specificKeywords = [effectiveCoDomain, '3D Parametric CAD (SolidWorks)', 'GD&T (ASME Y14.5)', 'ANSYS Structural FEA', 'CNC Toolpaths & G-Code', 'Design for Manufacturing (DFMA)'];
  } else if (domUpper.includes('CIVIL')) {
    hiringCompanies = ['Larsen & Toubro (L&T)', 'Shapoorji Pallonji', 'Tata Projects', 'AFCONS', 'AECOM', 'Bechtel'];
    salaryRange = '₹6.0L – ₹24.0L / yr (Infrastructure & BIM Benchmark)';
    specificKeywords = [effectiveCoDomain, 'STAAD.Pro Frame Modeling', 'Autodesk Revit BIM 3D', 'RCC Design (IS 456)', 'Geotechnical Foundation', 'Quantity Surveying & BOQ'];
  } else if (domUpper.includes('ELECTRICAL')) {
    hiringCompanies = ['Texas Instruments', 'Qualcomm', 'Intel', 'NVIDIA', 'Schneider Electric', 'Siemens', 'ABB', 'Ola Electric'];
    salaryRange = '₹7.5L – ₹30.0L / yr (Semiconductor & Power Benchmark)';
    specificKeywords = [effectiveCoDomain, 'ARM Cortex-M Embedded C', 'VLSI Verilog RTL Design', 'Altium PCB Multi-Layer Routing', 'Power Inverters (PWM)', 'MATLAB Simulink'];
  } else if (domUpper.includes('CHEMICAL')) {
    hiringCompanies = ['Reliance Industries', 'Tata Chemicals', 'Indian Oil (IOCL)', 'Bharat Petroleum', 'Dow Chemical', 'BASF'];
    salaryRange = '₹6.5L – ₹26.0L / yr (Process Engineering Benchmark)';
    specificKeywords = [effectiveCoDomain, 'Aspen Plus Flowsheets', 'Mass & Energy Balances', 'McCabe-Thiele Distillation', 'HAZOP Risk Matrix', 'Piping & Instrumentation (P&ID)'];
  } else if (domUpper.includes('BIOTECH')) {
    hiringCompanies = ['Biocon', 'Serum Institute of India', "Dr. Reddy's", 'Bharat Biotech', 'Novozymes', 'Thermo Fisher'];
    salaryRange = '₹6.0L – ₹24.0L / yr (Biopharma & Genomics Benchmark)';
    specificKeywords = [effectiveCoDomain, 'CRISPR Guide RNA Design', 'Bioreactor Fermentation Kinetics', 'HPLC Protein Purification', 'BioPython Sequence Alignment', 'cGMP Standards'];
  } else if (domUpper.includes('MARINE')) {
    hiringCompanies = ['Maersk Line', 'Anglo-Eastern Ship Management', 'Fleet Management Limited', 'MSC', 'V.Group', 'Cochin Shipyard'];
    salaryRange = '₹9.0L – ₹38.0L / yr (Merchant Marine Benchmark)';
    specificKeywords = [effectiveCoDomain, '2-Stroke Marine Diesel Engines', 'Ship Metacentric Height (GM)', 'IMO MARPOL Regulations', 'Maxsurf 3D Hull Resistance', 'STCW Watchkeeping'];
  } else if (domUpper.includes('ROBOTICS')) {
    hiringCompanies = ['Boston Dynamics', 'GreyOrange', 'ABB Robotics', 'Fanuc', 'Tesla Robotics', 'Addverb Technologies'];
    salaryRange = '₹8.0L – ₹32.0L / yr (Robotics & Autonomous Benchmark)';
    specificKeywords = [effectiveCoDomain, 'ROS 2 Nodes & Topics', 'Inverse Kinematics (DH)', '2D/3D LiDAR SLAM (Nav2)', 'Siemens PLC Ladder Logic', 'Closed-Loop PID Tuning'];
  } else if (domUpper.includes('HUMANITIES') || domUpper.includes('HONS')) {
    hiringCompanies = ['NITI Aayog', 'Observer Research Foundation (ORF)', 'Centre for Policy Research (CPR)', 'UNDP', 'World Bank', 'Edelman PR'];
    salaryRange = '₹5.5L – ₹22.0L / yr (Public Policy & Research Benchmark)';
    specificKeywords = [effectiveCoDomain, 'Public Policy Life Cycle', 'Qualitative Social Research', 'Macroeconomic Indicator Analysis', 'Strategic Communications', 'GRI / ESG Reporting'];
  }

  // Curated Placement Intelligence
  const placementData: PlacementIntelligence = {
    target_entry_roles: [
      `Junior ${effectiveCoDomain} Specialist`,
      `${effectiveCoDomain} Trainee Engineer / Analyst`,
      `Associate Consultant (${effectiveDomain})`,
      `Graduate Placement Trainee`
    ],
    ats_keywords: specificKeywords,
    star_bullet_examples: [
      `Architected and executed an end-to-end ${effectiveCoDomain} implementation, accelerating workflow throughput by 32% while maintaining 100% compliance with industry standards.`,
      `Diagnosed critical edge-case bottlenecks across ${effectiveCoDomain} systems, reducing operational error rates by 28% through standardized verification checklists.`,
      `Collaborated across cross-functional teams to integrate ${effectiveCoDomain} deliverables, presenting verified technical audits to senior leaders.`
    ],
    top_hiring_companies: hiringCompanies,
    expected_salary_range: salaryRange,
    interview_screening_checklist: [
      `Mastered first principles and architectural tradeoffs of ${effectiveCoDomain}`,
      `Built and deployed at least one verified production-grade flagship capstone project`,
      `Capable of articulating technical decisions under live whiteboarding / case screening`,
      `Resume ATS keyword density verified on Employ.AI Resume Studio with 90%+ match`
    ]
  };

  // Construct the 5-Phase Beginner-to-Placement Milestones with Authentic Learning Platforms
  const phaseTemplates = resolveCoDomainPhaseTemplates(effectiveDomain, effectiveCoDomain, matchedDef?.category);
  const cleanKey = effectiveCoDomain.toLowerCase().replace(/[^a-z0-9]/g, '');

  const milestones: RoadmapMilestone[] = phaseTemplates.map((pt, pIdx) => {
    const stageLevels: Array<'beginner' | 'intermediate' | 'advanced' | 'projects' | 'placement'> = [
      'beginner', 'intermediate', 'advanced', 'projects', 'placement'
    ];
    const defaultWeekRanges = ['Phase 1', 'Phase 2', 'Phase 3', 'Phase 4', 'Phase 5'];

    return {
      week_range: defaultWeekRanges[pIdx] || `Phase ${pIdx + 1}`,
      stage_level: stageLevels[pIdx] || 'intermediate',
      phase_title: pt.phaseTitle,
      focus_skill: pt.focusSkill,
      goal: pt.goal,
      how_to_achieve: pt.howToAchieve,
      recommended_tools: pt.recommendedTools,
      pro_tips: [
        `Master first principles in ${pt.focusSkill} before relying on auto-generation or high-level abstractions.`,
        'Keep a structured engineering notebook documenting every technical concept and gotcha encountered.'
      ],
      checkpoint_criteria: [
        `Can you articulate the core mechanics and trade-offs of this phase to a technical interviewer?`,
        `Have you verified your implementation against standard diagnostic checklists?`
      ],
      interview_questions: pt.interviewQuestions,
      learning_platforms: resolvePhaseLearningPlatforms(effectiveDomain, effectiveCoDomain, pIdx),
      youtube_resources: resolvePhaseYouTubeVideos(effectiveDomain, effectiveCoDomain, pIdx),
      topics: pt.topics,
      practical_project: pt.practicalProject,
      deliverable: pt.deliverable,
      tasks: (pt.tasks || []).map((t, tIdx) => ({
        id: `task-${cleanKey}-${pIdx + 1}-${tIdx + 1}`,
        title: t.title,
        description: t.description,
        estimated_hours: t.estimated_hours,
        is_completed: false
      }))
    };
  });


  return {
    id: `roadmap-${effectiveCoDomain.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
    title: `Beginner to Internship & Placement Level Destination: ${effectiveCoDomain}`,
    target_role_title: `Industry Benchmark in ${effectiveCoDomain}`,
    target_domain: effectiveDomain,
    domain: effectiveDomain,
    roadmap_type: 'co_domain',
    co_domain_name: effectiveCoDomain,
    estimated_weeks: 16,
    completion_pct: 0,
    placement_destination: placementData,
    milestones,
    created_at: new Date().toISOString()
  };
}

// -------------------------------------------------------------
// Dynamic Progress Computation: Video Mastery & Phase Task Completion
// -------------------------------------------------------------
export function computeRoadmapProgress(roadmap: LearningRoadmap): {
  completionPct: number;
  watchedVideosCount: number;
  totalVideosCount: number;
  completedTasksCount: number;
  totalTasksCount: number;
  completedPhasesCount: number;
  totalPhasesCount: number;
} {
  let totalTasks = 0;
  let completedTasks = 0;
  let totalVideos = 0;
  let watchedVideos = 0;
  let completedPhases = 0;

  (roadmap.milestones || []).forEach(milestone => {
    let phaseTasksTotal = 0;
    let phaseTasksCompleted = 0;

    (milestone.tasks || []).forEach(task => {
      totalTasks++;
      phaseTasksTotal++;
      if (task.is_completed) {
        completedTasks++;
        phaseTasksCompleted++;
      }
    });

    let phaseVideosTotal = 0;
    let phaseVideosWatched = 0;
    (milestone.youtube_resources || []).forEach(video => {
      totalVideos++;
      phaseVideosTotal++;
      try {
        if (typeof window !== 'undefined') {
          const isWatched = localStorage.getItem(`yt_watched_${video.id}`) === 'true';
          if (isWatched) {
            watchedVideos++;
            phaseVideosWatched++;
          }
        }
      } catch {}
    });

    const tasksDone = phaseTasksTotal > 0 ? phaseTasksCompleted === phaseTasksTotal : true;
    const videosDone = phaseVideosTotal > 0 ? phaseVideosWatched === phaseVideosTotal : true;
    if (tasksDone && videosDone && (phaseTasksTotal > 0 || phaseVideosTotal > 0)) {
      completedPhases++;
    }
  });

  const totalTrackable = totalTasks + totalVideos;
  const completedTrackable = completedTasks + watchedVideos;
  const pct = totalTrackable > 0 
    ? Math.min(100, Math.round((completedTrackable / totalTrackable) * 100)) 
    : 0;

  return {
    completionPct: pct,
    watchedVideosCount: watchedVideos,
    totalVideosCount: totalVideos,
    completedTasksCount: completedTasks,
    totalTasksCount: totalTasks,
    completedPhasesCount: completedPhases,
    totalPhasesCount: (roadmap.milestones || []).length
  };
}

export function hydrateRoadmapWithSavedProgress(roadmap: LearningRoadmap): LearningRoadmap {
  let savedTasks: Set<string> = new Set();
  try {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('employai_completed_tasks');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          savedTasks = new Set(parsed);
        }
      }
    }
  } catch {}

  const hydratedMilestones = (roadmap.milestones || []).map(milestone => {
    const tasks = (milestone.tasks || []).map(task => {
      const isCompleted = savedTasks.has(task.id) || !!task.is_completed;
      return { ...task, is_completed: isCompleted };
    });

    return {
      ...milestone,
      tasks
    };
  });

  const candidateRoadmap: LearningRoadmap = {
    ...roadmap,
    milestones: hydratedMilestones
  };

  const progress = computeRoadmapProgress(candidateRoadmap);
  candidateRoadmap.completion_pct = progress.completionPct;

  return candidateRoadmap;
}

export function getStreamProgressStats(
  streamName: string,
  availableCoDomains: CoDomainDefinition[]
): StreamProgressStats {
  return computeStreamProgressStats(streamName, availableCoDomains, generateCoDomainRoadmap);
}

export { computeStreamProgressStats };
export type { StreamProgressStats, CoDomainProgressItem };

