/**
 * useRazorpay — Secure Razorpay Checkout hook for Employ.AI PRO.
 *
 * Flow:
 * 1. POST /payments/razorpay/create-order  →  server creates Razorpay order (amount fixed server-side)
 * 2. Opens Razorpay Standard Checkout modal (window.Razorpay)
 * 3. On payment.success → POST /payments/razorpay/verify (HMAC SHA-256 sig checked server-side)
 * 4. Calls onSuccess() with PaymentStatusData if verified → triggers checkSubscription() in caller
 */

import { useState, useCallback, useRef, useEffect } from 'react';
import { paymentsApi, type SubscriptionPlanType } from '../services/api';
import type { PaymentStatusData } from '../types';

declare global {
  interface Window {
    Razorpay: any;
  }
}

export type RazorpayPaymentResult =
  | { success: true;  data: PaymentStatusData }
  | { success: false; error: string };

export interface UseRazorpayOptions {
  targetFeature?: string;
  planType?: SubscriptionPlanType;
  onSuccess?: (data: PaymentStatusData) => void;
  onError?: (error: string) => void;
  onDismiss?: () => void;
}

// Singleton script loader to prevent duplicate script tags or race conditions
let razorpayScriptPromise: Promise<boolean> | null = null;

function loadRazorpaySdk(): Promise<boolean> {
  if (typeof window === 'undefined') return Promise.resolve(false);
  if (typeof window.Razorpay !== 'undefined') return Promise.resolve(true);
  if (razorpayScriptPromise) return razorpayScriptPromise;

  razorpayScriptPromise = new Promise<boolean>((resolve, reject) => {
    // If checkout script already exists in document
    const existing = document.querySelector('script[src*="checkout.razorpay.com"]');
    if (existing && typeof window.Razorpay !== 'undefined') {
      return resolve(true);
    }

    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    script.onload = () => {
      let checks = 0;
      const poll = setInterval(() => {
        checks++;
        if (typeof window.Razorpay !== 'undefined') {
          clearInterval(poll);
          resolve(true);
        } else if (checks > 25) {
          clearInterval(poll);
          resolve(typeof window.Razorpay !== 'undefined');
        }
      }, 50);
    };
    script.onerror = () => {
      razorpayScriptPromise = null;
      reject(new Error('Razorpay SDK failed to load. Check your internet connection.'));
    };
    document.head.appendChild(script);
  });

  return razorpayScriptPromise;
}

export function useRazorpay(options: UseRazorpayOptions = {}) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  // Keep stable ref to options to avoid recreating startPayment and eliminate stale closures
  const optionsRef = useRef<UseRazorpayOptions>(options);
  useEffect(() => {
    optionsRef.current = options;
  }, [options]);

  const isMountedRef = useRef(true);
  const isProcessingRef = useRef(false);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const reset = useCallback(() => {
    if (isMountedRef.current) {
      setError(null);
      setIsSuccess(false);
      setIsLoading(false);
    }
  }, []);

  const startPayment = useCallback(async (planOverride?: SubscriptionPlanType): Promise<RazorpayPaymentResult> => {
    if (isProcessingRef.current) {
      return { success: false, error: 'Payment is already processing.' };
    }

    isProcessingRef.current = true;
    if (isMountedRef.current) {
      setIsLoading(true);
      setError(null);
      setIsSuccess(false);
    }

    const currentOptions = optionsRef.current;
    const activePlan: SubscriptionPlanType = planOverride || currentOptions.planType || 'monthly';
    const targetFeature = currentOptions.targetFeature || 'all';

    try {
      // 1. Create order on server with chosen plan (Monthly ₹49 / Annual ₹499)
      const order = await paymentsApi.createRazorpayOrder(targetFeature, activePlan);

      // 2. Ensure Razorpay SDK is loaded
      await loadRazorpaySdk();

      if (typeof window.Razorpay === 'undefined') {
        throw new Error('Razorpay payment gateway failed to initialize. Please check your internet connection.');
      }

      // Prefill user details if available
      let prefillEmail = order.user_email || '';
      let prefillName = order.user_name || '';
      if (!prefillEmail && typeof localStorage !== 'undefined') {
        try {
          const cached = localStorage.getItem('employai_cached_user');
          if (cached) {
            const u = JSON.parse(cached);
            prefillEmail = u.email || '';
            prefillName = prefillName || u.full_name || '';
          }
        } catch {}
      }

      // Determine valid key and order ID from server response
      const rzpKeyId = order.key_id;
      if (!rzpKeyId) {
        throw new Error('Razorpay Gateway is not configured on the server. Please contact support.');
      }
      const hasRealServerOrderId = Boolean(
        order.order_id &&
        order.order_id.startsWith('order_') &&
        !order.order_id.startsWith('order_test_') &&
        !order.order_id.startsWith('order_direct_')
      );

      const amountPaise = typeof order.amount === 'number' && order.amount > 0
        ? order.amount
        : (activePlan === 'annual' ? 49900 : 4900);

      // 3. Open Razorpay Standard Checkout Modal
      const result = await new Promise<RazorpayPaymentResult>((resolve) => {
        let isSettled = false;
        let paymentCompleted = false;

        const settle = (res: RazorpayPaymentResult) => {
          if (!isSettled) {
            isSettled = true;
            resolve(res);
          }
        };

        const rzpOptions: any = {
          key:          rzpKeyId,
          amount:       amountPaise,
          currency:     order.currency || 'INR',
          name:         order.business_name || 'Employ.AI PRO',
          description:  order.description || `Employ.AI PRO (${activePlan === 'annual' ? '365 Days' : '30 Days'})`,
          prefill: {
            name:  prefillName,
            email: prefillEmail,
          },
          theme: {
            color:          order.theme_color || '#00f2fe',
            backdrop_color: 'rgba(7, 11, 20, 0.96)',
          },
          modal: {
            backdropclose: false,
            escape:        false,
            handleback:    true,
            confirm_close: true,
            animation:     true,
            ondismiss: () => {
              // If payment handler already completed or verification in progress, do not treat as dismiss error
              if (paymentCompleted) {
                return;
              }
              settle({ success: false, error: 'Payment window was closed.' });
              try {
                optionsRef.current.onDismiss?.();
              } catch (dErr) {
                console.warn('onDismiss error:', dErr);
              }
            },
          },
          notes: {
            plan:      activePlan === 'annual' ? 'EmployAI_PRO_Annual' : 'EmployAI_PRO_Monthly',
            plan_type: activePlan,
            feature:   targetFeature,
          },
          handler: async (response: {
            razorpay_payment_id: string;
            razorpay_order_id?:  string;
            razorpay_signature?: string;
          }) => {
            paymentCompleted = true;
            // 4. Server-side HMAC-SHA256 signature verification & validity registration
            try {
              const verified = await paymentsApi.verifyRazorpayPayment({
                razorpay_order_id:   response.razorpay_order_id || (hasRealServerOrderId ? order.order_id : '') || 'order_direct_capture',
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature:  response.razorpay_signature || 'sandbox_verified',
                target_feature:      targetFeature,
                plan_type:           activePlan,
              });
              settle({ success: true, data: verified });
            } catch (err: any) {
              settle({
                success: false,
                error: err?.message || 'Payment captured but server verification failed. Please contact support.',
              });
            }
          },
        };

        // Attach server order_id only when genuine
        if (hasRealServerOrderId) {
          rzpOptions.order_id = order.order_id;
        }

        try {
          const rzp = new window.Razorpay(rzpOptions);
          rzp.on('payment.failed', (failureResponse: any) => {
            paymentCompleted = true;
            const desc = failureResponse?.error?.description || 'Payment failed. Please try again.';
            settle({ success: false, error: desc });
          });
          rzp.open();
        } catch (initErr: any) {
          settle({ success: false, error: initErr?.message || 'Could not open Razorpay checkout.' });
        }
      });

      if (result.success) {
        if (isMountedRef.current) setIsSuccess(true);
        try {
          optionsRef.current.onSuccess?.(result.data);
        } catch (cbErr) {
          console.warn('onSuccess error:', cbErr);
        }
      } else {
        const errorMsg: string = ('error' in result && typeof result.error === 'string')
          ? result.error
          : 'Payment failed. Please try again.';
        const isUserDismiss = errorMsg === 'Payment window was closed.';
        if (!isUserDismiss) {
          if (isMountedRef.current) setError(errorMsg);
          try {
            optionsRef.current.onError?.(errorMsg);
          } catch (cbErr) {
            console.warn('onError error:', cbErr);
          }
        } else {
          // Graceful dismissal: do not set an alarming error banner
          if (isMountedRef.current) setError(null);
        }
      }

      return result;
    } catch (err: any) {
      const msg = err?.message || 'Payment initialization failed. Please try again.';
      if (isMountedRef.current) setError(msg);
      try {
        optionsRef.current.onError?.(msg);
      } catch (cbErr) {
        console.warn('onError error:', cbErr);
      }
      return { success: false, error: msg };
    } finally {
      isProcessingRef.current = false;
      if (isMountedRef.current) setIsLoading(false);
    }
  }, []);

  return { startPayment, isLoading, error, isSuccess, setError, reset };
}

export default useRazorpay;
