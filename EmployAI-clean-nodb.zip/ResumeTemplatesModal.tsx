import React from 'react';
import { createPortal } from 'react-dom';
import type { ResumeTemplateId } from '../types';
import { 
  Layout, Check, Sparkles, X, 
  ShieldCheck, ArrowRight
} from 'lucide-react';

export interface TemplateOption {
  id: ResumeTemplateId;
  name: string;
  tag: string;
  category: string;
  description: string;
  atsScore: string;
  accentColor: string;
  previewHeaderBg: string;
  previewBorderColor: string;
  bestFor: string;
}

const RESUME_TEMPLATES_CATALOG: TemplateOption[] = [
  {
    id: 'emerald_sidebar',
    name: 'Emerald Forest Sidebar',
    tag: 'Sales & Operations • Green',
    category: 'Dual-Column Sidebar',
    description: 'Vibrant deep-emerald left sidebar with candidate photo/monogram, rounded pill skill capsules, and date-aligned work history.',
    atsScore: '98% ATS Friendly',
    accentColor: '#15803d',
    previewHeaderBg: 'rgba(21, 128, 61, 0.15)',
    previewBorderColor: '#15803d',
    bestFor: 'Sales, Customer Success, Management, Retail & Field Operations'
  },
  {
    id: 'lavender_lilac',
    name: 'Lavender Pastel Minimal',
    tag: 'Security & Legal • Lilac',
    category: 'Pastel Two-Tone',
    description: 'Soft lilac header banner with geometric monogram avatar, monospace typography, and skill proficiency indicators.',
    atsScore: '99% ATS Friendly',
    accentColor: '#a855f7',
    previewHeaderBg: 'rgba(168, 85, 247, 0.15)',
    previewBorderColor: '#c084fc',
    bestFor: 'Security Officers, Law & Compliance, Public Safety, Administration'
  },
  {
    id: 'midnight_gold',
    name: 'Midnight Navy & Gold',
    tag: 'Game Design & Creative Tech',
    category: 'Navy Header Banner',
    description: 'Full-width midnight navy header banner with gold accents, rounded dark skill badges, and two-column achievements.',
    atsScore: '98% ATS Friendly',
    accentColor: '#d97706',
    previewHeaderBg: 'rgba(217, 119, 6, 0.15)',
    previewBorderColor: '#f59e0b',
    bestFor: 'Game Designers, 3D Artists, Creative Technologists, UX Engineers'
  },
  {
    id: 'executive_yellow',
    name: 'Golden Modern Executive',
    tag: 'Financial & Consulting',
    category: 'Executive Card Grid',
    description: 'Hero yellow avatar backdrop, executive yellow headline pill, and clean 2x2 grid cards with circular icon badges.',
    atsScore: '97% ATS Friendly',
    accentColor: '#eab308',
    previewHeaderBg: 'rgba(234, 179, 8, 0.15)',
    previewBorderColor: '#eab308',
    bestFor: 'Financial Consultants, Senior Advisors, Corporate Executives, Wealth Managers'
  },
  {
    id: 'ats_classic',
    name: 'ATS Classic (Harvard Style)',
    tag: 'Ivy League Standard',
    category: 'Standard ATS',
    description: 'Ultra-clean single-column typography optimized for 99.8% ATS parser compatibility and corporate recruiting.',
    atsScore: '99% ATS Friendly',
    accentColor: '#0284c7',
    previewHeaderBg: 'rgba(2, 132, 199, 0.08)',
    previewBorderColor: '#0284c7',
    bestFor: 'Software Engineering, Finance, Consulting, Enterprise Roles'
  },
  {
    id: 'modern',
    name: 'Modern Tech & Silicon Valley',
    tag: 'High Impact',
    category: 'Tech / AI',
    description: 'Sleek cyan accents, modern font weights, and highlighted skill chips built specifically for developers & AI specialists.',
    atsScore: '98% ATS Friendly',
    accentColor: '#00f2fe',
    previewHeaderBg: 'rgba(0, 242, 254, 0.12)',
    previewBorderColor: '#00f2fe',
    bestFor: 'AI/ML Engineers, Full-Stack Developers, DevOps, Cloud Architects'
  },
  {
    id: 'professional',
    name: 'Corporate Professional',
    tag: 'Executive Navy',
    category: 'Corporate',
    description: 'Commanding navy divider bars, structured dual-level hierarchy, and polished executive layout.',
    atsScore: '97% ATS Friendly',
    accentColor: '#3b82f6',
    previewHeaderBg: 'rgba(59, 130, 246, 0.12)',
    previewBorderColor: '#3b82f6',
    bestFor: 'Product Managers, Tech Leads, Engineering Managers, Consultants'
  },
  {
    id: 'minimal',
    name: 'Minimalist Swiss',
    tag: 'Clean Design',
    category: 'Minimalism',
    description: 'Distraction-free layout with elegant whitespace, high-contrast readability, and contemporary typography.',
    atsScore: '99% ATS Friendly',
    accentColor: '#10b981',
    previewHeaderBg: 'rgba(168, 85, 247, 0.1)',
    previewBorderColor: '#10b981',
    bestFor: 'Design Engineers, Frontend Specialists, Research, General Tech'
  },
  {
    id: 'executive',
    name: 'Executive Leadership',
    tag: 'Senior Tier',
    category: 'Leadership',
    description: 'Sophisticated header block emphasizing high-level career achievements, leadership metrics, and strategic initiatives.',
    atsScore: '96% ATS Friendly',
    accentColor: '#a855f7',
    previewHeaderBg: 'rgba(168, 85, 247, 0.12)',
    previewBorderColor: '#a855f7',
    bestFor: 'Directors, VP of Engineering, Senior Architects, Founders'
  },
  {
    id: 'student_fresher',
    name: 'Student & Fresher (Campus Placement)',
    tag: 'Academic Focus',
    category: 'Fresher / Entry',
    description: 'Highlights technical projects, competitive coding handles, coursework, and core competencies for college placements.',
    atsScore: '98% ATS Friendly',
    accentColor: '#f59e0b',
    previewHeaderBg: 'rgba(245, 158, 11, 0.12)',
    previewBorderColor: '#f59e0b',
    bestFor: 'B.Tech / MCA Students, Recent Graduates, Internships, Campus Drives'
  }
];

export interface ResumeTemplatesModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTemplateId: ResumeTemplateId;
  onSelectTemplate: (templateId: ResumeTemplateId) => void;
}

export const ResumeTemplatesModal: React.FC<ResumeTemplatesModalProps> = ({
  isOpen,
  onClose,
  activeTemplateId,
  onSelectTemplate
}) => {
  if (!isOpen) return null;

  const modalNode = (
    <div 
      className="modal-backdrop" 
      onClick={onClose} 
      style={{ 
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(3, 7, 18, 0.85)',
        backdropFilter: 'blur(4px)',
        WebkitBackdropFilter: 'blur(4px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 99999,
        padding: '1rem',
        boxSizing: 'border-box'
      }}
    >
      <div 
        className="modal-content" 
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '98%',
          maxWidth: '960px',
          maxHeight: '92vh',
          display: 'flex',
          flexDirection: 'column',
          padding: '1.5rem',
          borderRadius: '16px',
          background: 'var(--bg-modal, #0f172a)',
          border: '1.5px solid var(--border-glass, rgba(255, 255, 255, 0.12))',
          boxShadow: '0 25px 60px -15px rgba(0, 0, 0, 0.9)',
          boxSizing: 'border-box',
          overflow: 'hidden',
          contain: 'layout style',
          transform: 'translateZ(0)'
        }}
      >
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0.85rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div style={{
              width: '38px',
              height: '38px',
              borderRadius: '10px',
              background: 'var(--grad-primary)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 0 16px rgba(56, 189, 248, 0.3)'
            }}>
              <Layout size={20} color="#ffffff" />
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  Resume Design & Template Gallery
                </h3>
                <span className="badge badge-cyan" style={{ fontSize: '0.68rem', fontWeight: 700 }}>
                  6 Industry Templates
                </span>
              </div>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                Select from professionally curated, high-impact resume templates. Changes apply instantly to your live document.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="btn btn-ghost btn-sm"
            style={{ padding: '0.4rem', color: 'var(--text-muted)' }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Template Cards Grid - Hardware Accelerated & Zero Scroll Stutter */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: '1rem',
          overflowY: 'auto',
          touchAction: 'pan-y',
          WebkitOverflowScrolling: 'touch',
          flex: 1,
          paddingRight: '0.35rem',
          paddingBottom: '0.5rem'
        }}>
          {RESUME_TEMPLATES_CATALOG.map((tpl) => {
            const isActive = activeTemplateId === tpl.id;

            return (
              <div
                key={tpl.id}
                onClick={() => {
                  onSelectTemplate(tpl.id);
                }}
                style={{
                  cursor: 'pointer',
                  borderRadius: '12px',
                  background: isActive ? 'rgba(56, 189, 248, 0.12)' : 'var(--bg-tertiary, rgba(255, 255, 255, 0.03))',
                  border: isActive ? `2px solid ${tpl.accentColor}` : '1px solid var(--border-subtle, rgba(255, 255, 255, 0.08))',
                  boxShadow: isActive ? `0 0 16px rgba(56, 189, 248, 0.2)` : 'none',
                  padding: '1.1rem',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.75rem',
                  position: 'relative',
                  transition: 'border-color 0.15s ease, background-color 0.15s ease, box-shadow 0.15s ease',
                  contain: 'layout style',
                  backfaceVisibility: 'hidden',
                  WebkitBackfaceVisibility: 'hidden'
                }}
              >
                {/* Top Active Indicator & Badge */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span 
                    className="badge" 
                    style={{ 
                      fontSize: '0.65rem', 
                      fontWeight: 700,
                      background: tpl.previewHeaderBg,
                      color: tpl.accentColor,
                      border: `1px solid ${tpl.accentColor}`
                    }}
                  >
                    {tpl.tag}
                  </span>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                    <ShieldCheck size={12} color="var(--accent-emerald)" />
                    <span style={{ fontSize: '0.65rem', color: 'var(--accent-emerald)', fontWeight: 700 }}>
                      {tpl.atsScore}
                    </span>
                  </div>
                </div>

                {/* Simulated Mini Resume Preview Card */}
                <div style={{
                  background: '#ffffff',
                  borderRadius: '8px',
                  padding: '0.75rem',
                  border: `1.5px solid ${tpl.previewBorderColor}`,
                  boxShadow: '0 2px 6px rgba(0, 0, 0, 0.08)',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.35rem',
                  color: '#0f172a'
                }}>
                  {/* Name & Title Header */}
                  <div style={{
                    borderBottom: `2px solid ${tpl.accentColor}`,
                    paddingBottom: '0.3rem',
                    textAlign: tpl.id === 'professional' ? 'left' : 'center'
                  }}>
                    <div style={{ fontSize: '0.82rem', fontWeight: 800, color: '#0f172a' }}>
                      CANDIDATE NAME
                    </div>
                    <div style={{ fontSize: '0.62rem', color: tpl.accentColor, fontWeight: 700 }}>
                      Software & Systems Engineer
                    </div>
                  </div>

                  {/* Section Line Previews */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem', marginTop: '0.2rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <span style={{ fontSize: '0.58rem', fontWeight: 800, color: '#334155', textTransform: 'uppercase' }}>
                        Work Experience
                      </span>
                      <span style={{ fontSize: '0.52rem', color: '#64748b' }}>2024 - Present</span>
                    </div>
                    <div style={{ width: '85%', height: '3px', background: '#e2e8f0', borderRadius: '2px' }} />
                    <div style={{ width: '95%', height: '3px', background: '#e2e8f0', borderRadius: '2px' }} />

                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '0.15rem' }}>
                      <span style={{ fontSize: '0.58rem', fontWeight: 800, color: '#334155', textTransform: 'uppercase' }}>
                        Technical Skills
                      </span>
                    </div>
                    <div style={{ display: 'flex', gap: '0.2rem' }}>
                      <span style={{ fontSize: '0.5rem', background: '#f1f5f9', padding: '0.1rem 0.3rem', borderRadius: '3px', border: '1px solid #cbd5e1' }}>Python</span>
                      <span style={{ fontSize: '0.5rem', background: '#f1f5f9', padding: '0.1rem 0.3rem', borderRadius: '3px', border: '1px solid #cbd5e1' }}>FastAPI</span>
                      <span style={{ fontSize: '0.5rem', background: '#f1f5f9', padding: '0.1rem 0.3rem', borderRadius: '3px', border: '1px solid #cbd5e1' }}>React</span>
                    </div>
                  </div>
                </div>

                {/* Template Info */}
                <div>
                  <h4 style={{ fontSize: '0.92rem', fontWeight: 800, color: 'var(--text-primary)', margin: '0 0 0.2rem 0' }}>
                    {tpl.name}
                  </h4>
                  <p style={{ fontSize: '0.72rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.45 }}>
                    {tpl.description}
                  </p>
                </div>

                {/* Best For Tag */}
                <div style={{ marginTop: 'auto', paddingTop: '0.4rem', borderTop: '1px solid var(--border-subtle)' }}>
                  <span style={{ fontSize: '0.64rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.4rem' }}>
                    <strong>Best For:</strong> {tpl.bestFor}
                  </span>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectTemplate(tpl.id);
                      onClose();
                    }}
                    className={`btn btn-sm ${isActive ? 'btn-primary' : 'btn-secondary'}`}
                    style={{
                      width: '100%',
                      fontSize: '0.72rem',
                      fontWeight: 800,
                      padding: '0.35rem',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.35rem'
                    }}
                  >
                    {isActive ? (
                      <>
                        <Check size={13} />
                        <span>Active Template</span>
                      </>
                    ) : (
                      <>
                        <span>Apply {tpl.name.split(' ')[0]} Template</span>
                        <ArrowRight size={12} />
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer info banner */}
        <div style={{
          marginTop: '1rem',
          padding: '0.65rem 0.9rem',
          borderRadius: '8px',
          background: 'var(--bg-tertiary)',
          border: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '0.5rem'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
            <Sparkles size={14} color="var(--accent-cyan)" />
            <span style={{ fontSize: '0.76rem', color: 'var(--text-secondary)' }}>
              All 6 templates preserve 100% of your verified facts, contact info, and STAR enhancements automatically.
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="btn btn-primary btn-sm"
            style={{ fontSize: '0.74rem', padding: '0.3rem 0.75rem', fontWeight: 800 }}
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalNode, document.body) : modalNode;
};
