import os
import uuid
import hashlib
import io
import re
from typing import Tuple, Dict, Any, List
from fastapi import UploadFile
import pypdf
import docx
from app.core.config import settings
from app.core.exceptions import FileValidationException

try:
    import pdfplumber
    HAS_PDFPLUMBER = True
except ImportError:
    HAS_PDFPLUMBER = False


class DocumentService:
    @staticmethod
    def validate_file(file: UploadFile) -> str:
        """Validate file size, extension, and presence."""
        if not file.filename:
            raise FileValidationException("Uploaded file must have a valid filename.")

        ext = file.filename.split(".")[-1].lower() if "." in file.filename else ""
        if ext not in ["pdf", "docx", "txt", "doc"]:
            raise FileValidationException(
                f"Unsupported file format '.{ext}'. Supported formats: PDF, DOCX, TXT."
            )

        return ext

    @staticmethod
    def validate_content_bytes(content_bytes: bytes, file_type: str):
        """Cryptographically inspect magic bytes and file signature to prevent MIME-confusion & malicious uploads."""
        if not content_bytes:
            raise FileValidationException("Uploaded document is empty.")

        # Reject dangerous executable signatures regardless of extension
        if content_bytes.startswith(b"MZ") or content_bytes.startswith(b"\x7fELF") or content_bytes.startswith(b"#!/bin"):
            raise FileValidationException("Security Alert: Executable binaries are strictly forbidden.")

        # PDF validation: must begin with %PDF
        if file_type == "pdf":
            if not content_bytes.startswith(b"%PDF"):
                raise FileValidationException("Invalid PDF document: Missing genuine PDF file header signature.")

        # DOCX validation: OpenXML zip container starting with PK\x03\x04
        elif file_type == "docx":
            if not content_bytes.startswith(b"PK\x03\x04"):
                raise FileValidationException("Invalid DOCX document: Corrupted or non-standard Office OpenXML signature.")

        # DOC legacy validation: OLE Compound Document signature
        elif file_type == "doc":
            if not (content_bytes.startswith(b"\xd0\xcf\x11\xe0") or content_bytes.startswith(b"PK\x03\x04")):
                raise FileValidationException("Invalid DOC document: Unrecognized document container signature.")

        # TXT validation: text file cannot have script or executable tags
        elif file_type == "txt":
            sample = content_bytes[:1024].lower()
            if b"<script" in sample or b"<?php" in sample or b"<html" in sample:
                raise FileValidationException("Invalid TXT file: HTML/script markup detected in plain-text file.")

    @staticmethod
    def extract_text(file_bytes: bytes, file_type: str) -> str:
        """
        Extract clean, meaningful plain text from PDF, DOCX, or TXT file contents.
        Strict single-source-of-truth extraction: Never substitutes fallback/demo text.
        """
        extracted_text = ""

        if file_type == "pdf":
            # Priority 1: pdfplumber for layout & table preservation
            if HAS_PDFPLUMBER:
                try:
                    with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                        pages_text = []
                        for page in pdf.pages:
                            text = page.extract_text(layout=True) or page.extract_text()
                            if text and text.strip():
                                pages_text.append(text.strip())
                            
                            # Also extract text inside tables if any
                            tables = page.extract_tables()
                            for table in tables:
                                for row in table:
                                    row_filtered = [str(c).strip() for c in row if c is not None and str(c).strip()]
                                    if row_filtered:
                                        pages_text.append(" | ".join(row_filtered))
                        extracted_text = "\n\n".join(pages_text)
                except Exception as e:
                    print(f"[WARN] pdfplumber extraction notice: {e}. Attempting pypdf.")

            # Priority 2: pypdf fallback
            if not extracted_text.strip():
                try:
                    reader = pypdf.PdfReader(io.BytesIO(file_bytes))
                    pages_text = []
                    for page in reader.pages:
                        text = page.extract_text()
                        if text and text.strip():
                            pages_text.append(text.strip())
                    extracted_text = "\n\n".join(pages_text)
                except Exception as e:
                    raise FileValidationException(f"Failed to extract text from PDF document: {str(e)}")

        elif file_type in ["docx", "doc"]:
            try:
                doc = docx.Document(io.BytesIO(file_bytes))
                paragraphs = []
                for p in doc.paragraphs:
                    if p.text.strip():
                        paragraphs.append(p.text.strip())
                # Extract text within tables
                for table in doc.tables:
                    for row in table.rows:
                        row_text = " | ".join([cell.text.strip() for cell in row.cells if cell.text.strip()])
                        if row_text:
                            paragraphs.append(row_text)
                extracted_text = "\n\n".join(paragraphs)
            except Exception as e:
                raise FileValidationException(f"Failed to extract readable text from DOCX document: {str(e)}")

        elif file_type == "txt":
            try:
                extracted_text = file_bytes.decode("utf-8")
            except UnicodeDecodeError:
                try:
                    extracted_text = file_bytes.decode("latin-1")
                except Exception as e:
                    raise FileValidationException(f"Failed to decode TXT file: {str(e)}")

        # Clean null characters and whitespace
        extracted_text = extracted_text.replace('\x00', '').strip()

        # Strict validation: verify extracted text contains readable alphabetic resume content
        alpha_count = len(re.findall(r'[A-Za-z]', extracted_text))
        if not extracted_text or len(extracted_text) < 25 or alpha_count < 15:
            raise FileValidationException(
                "Unable to extract readable text from this resume. The file may be image-only, scanned, or corrupted. Please upload a text-based PDF/DOCX or try another file."
            )

        return extracted_text

    @staticmethod
    def categorize_link(url: str) -> Dict[str, str]:
        """Categorize a link and generate a friendly label and icon type."""
        u_lower = url.lower()
        
        # Normalize url
        norm_url = url
        if not norm_url.startswith(("http://", "https://", "mailto:", "tel:")):
            if "@" in norm_url and not norm_url.startswith("www."):
                norm_url = f"mailto:{norm_url}"
            else:
                norm_url = f"https://{norm_url}"

        if "linkedin.com" in u_lower:
            handle = url.split("linkedin.com/in/")[-1].strip("/").split("?")[0] if "linkedin.com/in/" in u_lower else "LinkedIn"
            return {"url": norm_url, "label": f"LinkedIn ({handle})" if handle and handle != "LinkedIn" else "LinkedIn Profile", "type": "linkedin"}
        elif "github.com" in u_lower:
            handle = url.split("github.com/")[-1].strip("/").split("?")[0] if "github.com/" in u_lower else "GitHub"
            return {"url": norm_url, "label": f"GitHub ({handle})" if handle and handle != "GitHub" else "GitHub Profile", "type": "github"}
        elif "leetcode.com" in u_lower:
            handle = url.split("leetcode.com/")[-1].replace("u/", "").strip("/").split("?")[0] if "leetcode.com/" in u_lower else "LeetCode"
            return {"url": norm_url, "label": f"LeetCode ({handle})" if handle and handle != "LeetCode" else "LeetCode Profile", "type": "leetcode"}
        elif "codeforces.com" in u_lower:
            handle = url.split("profile/")[-1].strip("/").split("?")[0] if "profile/" in u_lower else "Codeforces"
            return {"url": norm_url, "label": f"Codeforces ({handle})" if handle and handle != "Codeforces" else "Codeforces", "type": "codeforces"}
        elif "codechef.com" in u_lower:
            handle = url.split("users/")[-1].strip("/").split("?")[0] if "users/" in u_lower else "CodeChef"
            return {"url": norm_url, "label": f"CodeChef ({handle})" if handle and handle != "CodeChef" else "CodeChef", "type": "codechef"}
        elif "hackerrank.com" in u_lower:
            handle = url.split("hackerrank.com/")[-1].strip("/").split("?")[0] if "hackerrank.com/" in u_lower else "HackerRank"
            return {"url": norm_url, "label": f"HackerRank ({handle})" if handle and handle != "HackerRank" else "HackerRank", "type": "hackerrank"}
        elif "kaggle.com" in u_lower:
            handle = url.split("kaggle.com/")[-1].strip("/").split("?")[0] if "kaggle.com/" in u_lower else "Kaggle"
            return {"url": norm_url, "label": f"Kaggle ({handle})" if handle and handle != "Kaggle" else "Kaggle", "type": "kaggle"}
        elif any(ext in u_lower for ext in [".dev", ".me", ".io", "portfolio", "vercel.app", "netlify.app"]):
            return {"url": norm_url, "label": "Portfolio / Live Demo", "type": "portfolio"}
        elif norm_url.startswith("mailto:"):
            email_addr = norm_url.replace("mailto:", "")
            return {"url": norm_url, "label": f"Email: {email_addr}", "type": "email"}
        elif "gitlab.com" in u_lower or "bitbucket.org" in u_lower:
            return {"url": norm_url, "label": "Source Code Repo", "type": "code"}
        else:
            domain = url.replace("https://", "").replace("http://", "").split("/")[0]
            return {"url": norm_url, "label": domain or url, "type": "other"}

    @staticmethod
    def extract_hyperlinks(file_bytes: bytes, file_type: str, extracted_text: str = "") -> List[Dict[str, str]]:
        """
        Extracts all embedded hyperlinks, annotations, and URI actions from PDF, DOCX, or TXT documents.
        Returns a list of unique structured link items with labels and categories.
        """
        raw_urls: List[str] = []

        if file_type == "pdf":
            # 1. pypdf annotation extraction
            try:
                reader = pypdf.PdfReader(io.BytesIO(file_bytes))
                for page in reader.pages:
                    annots = page.get("/Annots")
                    if annots:
                        for a in annots:
                            annot_obj = a.get_object() if hasattr(a, "get_object") else a
                            if isinstance(annot_obj, dict):
                                action = annot_obj.get("/A")
                                if action and isinstance(action, dict) and "/URI" in action:
                                    uri = str(action["/URI"]).strip()
                                    if uri and uri not in raw_urls:
                                        raw_urls.append(uri)
            except Exception as e:
                print(f"[DEBUG] pypdf annotation extraction note: {e}")

            # 2. pdfplumber hyperlinks
            if HAS_PDFPLUMBER:
                try:
                    with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                        for page in pdf.pages:
                            if hasattr(page, "hyperlinks") and page.hyperlinks:
                                for h in page.hyperlinks:
                                    uri = h.get("uri") or h.get("url")
                                    if uri and str(uri).strip() not in raw_urls:
                                        raw_urls.append(str(uri).strip())
                except Exception as e:
                    print(f"[DEBUG] pdfplumber hyperlink note: {e}")

        elif file_type in ["docx", "doc"]:
            try:
                doc = docx.Document(io.BytesIO(file_bytes))
                for rel in doc.part.rels.values():
                    if "hyperlink" in str(rel.reltype).lower():
                        target = getattr(rel, "target_ref", None) or getattr(rel, "_target", None)
                        if target and str(target).strip() not in raw_urls:
                            raw_urls.append(str(target).strip())
            except Exception as e:
                print(f"[DEBUG] docx hyperlink note: {e}")

        # Extract explicit URLs directly from raw text
        if extracted_text:
            text_urls = re.findall(r'(?:https?://|www\.)[^\s)\]">]+', extracted_text, re.IGNORECASE)
            for u in text_urls:
                cleaned = u.rstrip(".,;:)")
                if cleaned and cleaned not in raw_urls:
                    raw_urls.append(cleaned)

            # Look for specific developer handles in text if missing protocol
            handle_patterns = [
                (r'\bleetcode\.com/(?:u/)?([A-Za-z0-9_-]+)', "https://leetcode.com/u/{}"),
                (r'\bgithub\.com/([A-Za-z0-9_-]+)', "https://github.com/{}"),
                (r'\blinkedin\.com/in/([A-Za-z0-9_-]+)', "https://linkedin.com/in/{}"),
                (r'\bcodeforces\.com/profile/([A-Za-z0-9_-]+)', "https://codeforces.com/profile/{}"),
                (r'\bcodechef\.com/users/([A-Za-z0-9_-]+)', "https://codechef.com/users/{}")
            ]
            for pat, tmpl in handle_patterns:
                for match in re.finditer(pat, extracted_text, re.IGNORECASE):
                    constructed = tmpl.format(match.group(1))
                    if not any(constructed.lower() in x.lower() for x in raw_urls):
                        raw_urls.append(constructed)

        structured_links: List[Dict[str, str]] = []
        seen_urls = set()
        for u in raw_urls:
            cleaned = u.strip()
            if cleaned and cleaned.lower() not in seen_urls:
                seen_urls.add(cleaned.lower())
                cat = DocumentService.categorize_link(cleaned)
                structured_links.append(cat)

        return structured_links

    @staticmethod
    def verify_extraction(file_bytes: bytes, filename: str, file_type: str, extracted_text: str) -> Dict[str, Any]:
        """Creates an audit verification metadata object for the extracted document."""
        alpha_count = len(re.findall(r'[A-Za-z]', extracted_text))
        word_count = len(extracted_text.split())
        return {
            "filename": filename,
            "file_type": file_type,
            "char_count": len(extracted_text),
            "word_count": word_count,
            "alpha_count": alpha_count,
            "extraction_method": "pdfplumber/pypdf" if file_type == "pdf" else file_type,
            "is_valid": len(extracted_text) >= 25 and alpha_count >= 15
        }

    @staticmethod
    def save_file_securely(file_bytes: bytes, original_filename: str, file_type: str) -> Tuple[str, str, int]:
        """Save file to private backend storage and return stored_filename, sha256, and size."""
        DocumentService.validate_content_bytes(file_bytes, file_type)
        file_size = len(file_bytes)
        if file_size > settings.max_upload_size_bytes:
            raise FileValidationException(
                f"File size ({file_size / (1024*1024):.2f} MB) exceeds maximum allowed limit of {settings.MAX_UPLOAD_SIZE_MB} MB."
            )

        sha256 = hashlib.sha256(file_bytes).hexdigest()
        stored_filename = f"{uuid.uuid4().hex}.{file_type}"
        target_dir = settings.STORAGE_DIR

        try:
            os.makedirs(target_dir, exist_ok=True)
            file_path = os.path.join(target_dir, stored_filename)
            with open(file_path, "wb") as f:
                f.write(file_bytes)
        except (OSError, IOError):
            # Fallback for serverless read-only environments (e.g. Vercel / Lambda)
            target_dir = "/tmp/storage"
            os.makedirs(target_dir, exist_ok=True)
            file_path = os.path.join(target_dir, stored_filename)
            with open(file_path, "wb") as f:
                f.write(file_bytes)

        return stored_filename, sha256, file_size

