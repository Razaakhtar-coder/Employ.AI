from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field


class OpportunitySkillItem(BaseModel):
    skill_id: str
    skill_name: str
    is_required: bool
    weight: float

    class Config:
        from_attributes = True


class OpportunityCreate(BaseModel):
    title: str = Field(..., min_length=3)
    type: str = Field(default="internship", pattern="^(job|internship|placement)$")
    domain: str
    location: str = "Bengaluru, India"
    work_mode: str = Field(default="hybrid", pattern="^(remote|onsite|hybrid)$")
    description: str
    stipend_salary: Optional[str] = "₹35,000 / month"
    eligibility_min_cgpa: float = Field(default=6.5, ge=0.0, le=10.0)
    eligible_departments: List[str] = ["Mechanical Engineering"]
    deadline: Optional[str] = "2025-06-30"
    required_skill_ids: List[str] = []
    preferred_skill_ids: List[str] = []


class OpportunityResponse(BaseModel):
    id: str
    company_id: str
    company_name: str
    company_location: Optional[str] = None
    title: str
    type: str
    domain: str
    location: str
    work_mode: str
    description: str
    stipend_salary: Optional[str] = None
    eligibility_min_cgpa: float
    eligible_departments: List[str] = []
    deadline: Optional[str] = None
    is_active: bool
    created_at: datetime
    skills: List[OpportunitySkillItem] = []
    
    # Matching metadata computed dynamically when viewed by a student
    user_match_percentage: Optional[float] = None
    matched_skills: Optional[List[str]] = None
    missing_skills: Optional[List[str]] = None
    eligibility_status: Optional[str] = None

    class Config:
        from_attributes = True


class ApplicationCreate(BaseModel):
    opportunity_id: str
    document_id: Optional[str] = None
    cover_note: Optional[str] = None


class ApplicationResponse(BaseModel):
    id: str
    opportunity_id: str
    opportunity_title: str
    company_name: str
    opportunity_type: str
    status: str
    match_score_snapshot: float
    cover_note: Optional[str] = None
    applied_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class CandidateMatchCard(BaseModel):
    application_id: Optional[str] = None
    student_id: str
    student_name: str
    email: str
    degree: str
    department: str
    cgpa: float
    match_percentage: float
    matched_skills: List[str]
    missing_skills: List[str]
    is_eligible: bool
    application_status: str
    applied_at: Optional[datetime] = None
    ats_score: Optional[float] = None
    is_ats_verified: Optional[bool] = True
