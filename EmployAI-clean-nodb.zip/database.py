from sqlalchemy import create_engine, event
from sqlalchemy.orm import declarative_base, sessionmaker
from app.core.config import settings

import os
import shutil

if os.getenv("VERCEL"):
    tmp_path = "/tmp/employai.db"
    if not os.path.exists(tmp_path) or os.path.getsize(tmp_path) < 1000:
        candidates = [
            os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "employai.db")),
            os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "employai.db")),
            os.path.join(os.getcwd(), "backend", "employai.db"),
            os.path.join(os.getcwd(), "employai.db"),
        ]
        for candidate in candidates:
            if os.path.exists(candidate) and os.path.getsize(candidate) > 1000:
                try:
                    os.makedirs(os.path.dirname(tmp_path), exist_ok=True)
                    shutil.copyfile(candidate, tmp_path)
                    print(f"[INFO] Restored database from {candidate} to {tmp_path} ({os.path.getsize(tmp_path)} bytes)")
                    break
                except Exception as ce:
                    print(f"[WARN] Could not copy seed database to {tmp_path}: {ce}")

db_url = "sqlite:////tmp/employai.db" if os.getenv("VERCEL") else settings.DATABASE_URL

# Engine configuration
connect_args = {}
if db_url.startswith("sqlite"):
    connect_args = {
        "check_same_thread": False,
        "timeout": 30.0  # 30-second timeout to prevent 'database is locked' errors
    }

engine = create_engine(
    db_url,
    connect_args=connect_args,
    echo=settings.DEBUG and False,  # set True if query debugging is required
    pool_pre_ping=True
)

if db_url.startswith("sqlite"):
    @event.listens_for(engine, "connect")
    def set_sqlite_pragma(dbapi_connection, connection_record):
        if not os.getenv("VERCEL"):
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.execute("PRAGMA busy_timeout=30000")
            cursor.close()

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

_tables_initialized = False

def init_db_tables():
    global _tables_initialized
    if not _tables_initialized:
        try:
            import app.models  # ensure models are registered
            Base.metadata.create_all(bind=engine)
            _tables_initialized = True

            # Ensure new columns exist on legacy/existing SQLite databases
            try:
                from sqlalchemy import text
                with engine.connect() as conn:
                    for col, col_type in [("subscription_plan", "VARCHAR(50)"), ("subscription_valid_until", "DATETIME")]:
                        try:
                            conn.execute(text(f"ALTER TABLE users ADD COLUMN {col} {col_type}"))
                            conn.commit()
                        except Exception:
                            pass
                    for col, col_type in [("plan_type", "VARCHAR(50)"), ("valid_until", "DATETIME")]:
                        try:
                            conn.execute(text(f"ALTER TABLE payments ADD COLUMN {col} {col_type}"))
                            conn.commit()
                        except Exception:
                            pass
            except Exception as me:
                print(f"[INFO] Schema check note: {me}")
            
            # Seed default users, taxonomy, and initial curated jobs
            from app.services.auth_service import AuthService
            from seeds.taxonomy_seed import seed_universal_taxonomy
            from app.services.job_aggregator_service import JobAggregatorService
            db = SessionLocal()
            try:
                AuthService.ensure_default_seed(db)
                seed_universal_taxonomy(db)
                JobAggregatorService.ensure_initial_seed(db)
            except Exception as se:
                print(f"[WARN] Error running initial seeds: {se}")
            finally:
                db.close()
        except Exception as e:
            print(f"[WARN] Error creating tables: {e}")



def get_db():
    """Dependency for obtaining database session per request."""
    init_db_tables()
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
