import re
import html
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting


class RemoteOKProvider(JobProviderAdapter):
    """
    RemoteOK Job Board Public API Adapter.
    Aggregates remote jobs across engineering, design, marketing, finance, and operations.
    """

    API_URL = "https://remoteok.com/api"

    @property
    def name(self) -> str:
        return "RemoteOK"

    def _strip_html(self, raw_html: str) -> str:
        if not raw_html:
            return ""
        clean = re.sub(r"<[^>]+>", " ", raw_html)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        postings: List[RawJobPosting] = []

        try:
            async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as client:
                headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) EmployAI-JobMatcher/1.0",
                    "Accept": "application/json"
                }
                response = await client.get(self.API_URL, headers=headers)
                if response.status_code != 200:
                    print(f"[WARN] RemoteOK API returned status {response.status_code}")
                    return []

                data = response.json()
                if not isinstance(data, list):
                    return []

                # Skip the first element if it's the disclaimer dict
                job_items = [d for d in data if isinstance(d, dict) and "position" in d]

                # Limit to latest 40 items to ensure fast response and rate limit safety
                for item in job_items[:40]:
                    raw_title = item.get("position", "")
                    raw_desc = self._strip_html(item.get("description", ""))
                    tags = item.get("tags") or []
                    company = item.get("company", "Remote Tech Partner")
                    item_id = str(item.get("id", item.get("slug", raw_title)))
                    apply_url = item.get("url") or f"https://remoteok.com/l/{item_id}"

                    # Salary parsing
                    salary_min = item.get("salary_min")
                    salary_max = item.get("salary_max")
                    salary_str = None
                    if salary_min or salary_max:
                        if salary_min and salary_max:
                            salary_str = f"${salary_min:,} - ${salary_max:,}/yr"
                        elif salary_min:
                            salary_str = f"From ${salary_min:,}/yr"
                        else:
                            salary_str = f"Up to ${salary_max:,}/yr"

                    # Determine job type
                    mapped_type = "full-time"
                    title_lower = raw_title.lower()
                    if "intern" in title_lower or "internship" in tags:
                        mapped_type = "internship"
                    elif "part-time" in title_lower or "part time" in tags:
                        mapped_type = "part-time"
                    elif "contract" in tags or "freelance" in tags:
                        mapped_type = "contract"

                    # Experience level
                    exp_level = "entry"
                    combined_text = (raw_title + " " + " ".join(tags)).lower()
                    if "intern" in combined_text or "junior" in combined_text or "trainee" in combined_text:
                        exp_level = "intern"
                    elif "senior" in combined_text or "lead" in combined_text or "principal" in combined_text or "staff" in combined_text:
                        exp_level = "senior"
                    elif "mid" in combined_text:
                        exp_level = "mid"

                    if query and query.lower() not in (raw_title + " " + raw_desc + " " + " ".join(tags) + " " + company).lower():
                        continue

                    postings.append(RawJobPosting(
                        source_id=f"remoteok-{item_id}",
                        source="RemoteOK",
                        title=raw_title,
                        company=company,
                        location=item.get("location") or "Worldwide (Remote)",
                        remote=True,
                        job_type=mapped_type,
                        experience_level=exp_level,
                        description=raw_desc[:2500],  # cap description length
                        required_skills=tags,
                        apply_url=apply_url,
                        salary_range=salary_str,
                        posted_date=item.get("date") or "Recently"
                    ))
        except Exception as e:
            print(f"[WARN] Error fetching from RemoteOK Provider: {e}")

        return postings
