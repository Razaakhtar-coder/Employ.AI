import React, { useState } from 'react';
import { 
  Sparkles, Compass, Mic, FileText, Orbit, 
  Building2, Zap, ArrowRight, 
  Layers, Shield, Cpu, 
  GraduationCap, ChevronDown, ChevronUp,
  Check, Activity,
  Mail, Phone, Headphones, ShieldCheck, Copy
} from 'lucide-react';
import { BrandLogo } from './BrandLogo';

export interface AboutViewProps {
  onNavigate?: (tab: string) => void;
  onNavigateToRoadmap?: (roleTitleOrId?: string, domain?: string) => void;
}

interface FaqItem {
  question: string;
  answer: string;
}

export const AboutView: React.FC<AboutViewProps> = ({ onNavigate, onNavigateToRoadmap }) => {
  const [activePillarTab, setActivePillarTab] = useState<'resume' | 'roadmap' | 'interview' | 'galaxy' | 'academia'>('resume');
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  const [copiedDetails, setCopiedDetails] = useState(false);

  const handleCopyMerchantDetails = () => {
    const details = `Employ.AI Platform\nLead Developer: Raza Akhtar\nOfficial Email: akhtarrakeeb52@gmail.com\nContact Number: +91 9415962079\nPayment Partner: Razorpay`;
    navigator.clipboard.writeText(details);
    setCopiedDetails(true);
    setTimeout(() => setCopiedDetails(false), 2500);
  };

  const toggleFaq = (index: number) => {
    setExpandedFaq(prev => prev === index ? null : index);
  };

  const handleLaunch = (tab: string) => {
    if (tab === 'roadmap' && onNavigateToRoadmap) {
      onNavigateToRoadmap();
    } else if (onNavigate) {
      onNavigate(tab);
    }
  };

  const faqs: FaqItem[] = [
    {
      question: "How is Employ.AI different from generic resume builders?",
      answer: "Traditional resume builders merely reformat templates without validating content quality. Employ.AI features a dual-engine architecture: a deterministic parser that strictly validates phone numbers, emails, GitHub, and LinkedIn links without hallucination, and an intelligent ATS multi-metric scoring engine that quantifies structural clarity, keyword density, quantifiable impact metrics, and STAR bullet quality against actual employer job descriptions."
    },
    {
      question: "How does the Placement Level Roadmap adapt to non-CS domains?",
      answer: "Employ.AI supports 18+ multi-disciplinary academic domains—including Computer Science, Mechanical, Civil, Electrical, MBBS/Clinical Medicine, Law, Finance, Architecture, and Aviation. Each domain provides tailored 5-phase tracks (from foundational principles to capstone deliverables and placement viva questions) calibrated specifically to industry expectations for that field."
    },
    {
      question: "How does the AI Mock Interview test my actual resume claims?",
      answer: "Unlike generic quiz bots, Employ.AI's mock interviewer reads your uploaded resume projects, verified tools, and target career domain to generate personalized, deep-dive behavioral and technical questions. You answer via live microphone voice input, and the engine assesses your response on the STAR framework (Situation, Task, Action, Result) with real-time feedback."
    },
    {
      question: "Can universities and Training & Placement Offices (TPOs) use Employ.AI?",
      answer: "Yes. Employ.AI includes a dedicated Institutional Command Center for TPOs, department heads, and deans. It features curriculum gap analytics, cohort placement readiness metrics, and syllabus ingestion AI to identify skill discrepancies between university syllabi and hiring trends before campus drives begin."
    },
    {
      question: "Is my personal and academic data kept private?",
      answer: "Employ.AI is designed with strict privacy standards. We enforce user-scoped storage isolation and deterministic local caching. Your resumes, voice recordings, and mock interview transcripts are strictly private to your session and are never sold or shared with unauthorized third parties."
    }
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', paddingBottom: '3rem', width: '100%', maxWidth: '1280px', margin: '0 auto' }}>
      
      {/* ========================================================================= */}
      {/* 1. HERO SECTION & BRAND IDENTITY */}
      {/* ========================================================================= */}
      <section
        className="glass-card"
        style={{
          position: 'relative',
          overflow: 'hidden',
          padding: 'clamp(2rem, 4vw, 3.5rem) clamp(1.5rem, 4vw, 3rem)',
          borderRadius: '28px',
          border: '1px solid var(--border-subtle)',
          background: 'var(--bg-secondary)',
          boxShadow: 'var(--shadow-lg)',
        }}
      >
        {/* Ambient glow blobs */}
        <div style={{
          position: 'absolute', top: '-80px', right: '-80px',
          width: '340px', height: '340px', borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(56, 189, 248, 0.18) 0%, transparent 70%)',
          pointerEvents: 'none', filter: 'blur(48px)', zIndex: 0
        }} />
        <div style={{
          position: 'absolute', bottom: '-60px', left: '-60px',
          width: '260px', height: '260px', borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(16, 185, 129, 0.12) 0%, transparent 70%)',
          pointerEvents: 'none', filter: 'blur(40px)', zIndex: 0
        }} />

        <div style={{ position: 'relative', zIndex: 2, display: 'flex', flexDirection: 'column', gap: '1.75rem' }}>

          {/* Top Badge & Logo Row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem', flexWrap: 'wrap' }}>
            <BrandLogo size={44} badgeText="Platform v2.5" />
            <span className="badge badge-cyan" style={{ fontSize: '0.78rem', padding: '0.4rem 1rem', display: 'flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}>
              <Sparkles size={13} /> Autonomous Placement Intelligence Engine
            </span>
            <span className="badge badge-emerald" style={{ fontSize: '0.78rem', padding: '0.4rem 1rem', fontWeight: 700 }}>
              18+ Academic Disciplines Supported
            </span>
          </div>

          {/* Main Title */}
          <div style={{ maxWidth: '880px' }}>
            <h1 style={{
              fontSize: 'clamp(2.1rem, 4.2vw, 3rem)',
              fontWeight: 900,
              lineHeight: 1.12,
              letterSpacing: '-0.03em',
              margin: '0 0 1rem 0',
              color: 'var(--text-primary)'
            }}>
              Bridging Higher Education to{' '}
              <span style={{
                background: 'linear-gradient(135deg, var(--accent-cyan) 0%, #38bdf8 45%, var(--accent-emerald) 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                display: 'inline-block'
              }}>
                High-Growth Placement Excellence.
              </span>
            </h1>
            <p style={{
              fontSize: '1.05rem',
              color: 'var(--text-secondary)',
              lineHeight: 1.7,
              margin: 0,
              fontWeight: 400,
              maxWidth: '760px'
            }}>
              <strong style={{ color: 'var(--text-primary)', fontWeight: 700 }}>Employ.AI</strong> is the holistic, AI-powered career acceleration and placement readiness operating system.
              We empower students to audit and perfect their resumes with zero hallucinations, master technical live voice interviews via the STAR framework, follow precision 5-phase co-domain roadmaps, and empower universities with curriculum gap analytics.
            </p>
          </div>

          {/* Stat Cards Grid */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))',
            gap: '1rem',
          }}>
            {[
              {
                icon: <Activity size={18} color="var(--accent-cyan)" />,
                label: 'Coverage',
                value: '18+ Domains',
                sub: 'CS, Med, Law, Mech, Aero & more',
                borderColor: 'var(--accent-cyan)',
                glow: 'rgba(2, 132, 199, 0.12)'
              },
              {
                icon: <Compass size={18} color="var(--accent-emerald)" />,
                label: 'Roadmap Engine',
                value: '5-Phase Track',
                sub: 'Tailored to selected co-domain',
                borderColor: 'var(--accent-emerald)',
                glow: 'rgba(5, 150, 105, 0.12)'
              },
              {
                icon: <Mic size={18} color="var(--accent-violet)" />,
                label: 'Interview Studio',
                value: 'Live Voice',
                sub: 'STAR defense & instant evaluation',
                borderColor: 'var(--accent-violet)',
                glow: 'rgba(99, 102, 241, 0.12)'
              },
              {
                icon: <Shield size={18} color="var(--accent-amber)" />,
                label: 'ATS Engine',
                value: 'Deterministic',
                sub: 'Zero hallucinations, 4-tier audit',
                borderColor: 'var(--accent-amber)',
                glow: 'rgba(217, 119, 6, 0.12)'
              }
            ].map((card, i) => (
              <div
                key={i}
                style={{
                  padding: '1.2rem 1.3rem',
                  borderRadius: '18px',
                  background: 'var(--bg-tertiary)',
                  border: `1px solid var(--border-subtle)`,
                  backdropFilter: 'blur(12px)',
                  transition: 'transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease',
                  cursor: 'default',
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLDivElement).style.transform = 'translateY(-3px)';
                  (e.currentTarget as HTMLDivElement).style.boxShadow = `0 12px 32px ${card.glow}, 0 4px 12px rgba(0,0,0,0.12)`;
                  (e.currentTarget as HTMLDivElement).style.borderColor = card.borderColor;
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLDivElement).style.transform = 'translateY(0)';
                  (e.currentTarget as HTMLDivElement).style.boxShadow = 'none';
                  (e.currentTarget as HTMLDivElement).style.borderColor = 'var(--border-subtle)';
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
                  <div style={{
                    width: '32px', height: '32px', borderRadius: '8px',
                    background: card.glow,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    border: `1px solid ${card.borderColor}33`
                  }}>
                    {card.icon}
                  </div>
                  <span style={{ fontSize: '0.7rem', fontWeight: 800, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                    {card.label}
                  </span>
                </div>
                <div style={{ fontSize: '1.55rem', fontWeight: 900, color: 'var(--text-primary)', lineHeight: 1.1, marginBottom: '0.3rem' }}>
                  {card.value}
                </div>
                <span style={{ fontSize: '0.77rem', color: 'var(--text-muted)', lineHeight: 1.4 }}>
                  {card.sub}
                </span>
              </div>
            ))}
          </div>

          {/* CTA Buttons */}
          <div style={{ display: 'flex', gap: '0.85rem', flexWrap: 'wrap', marginTop: '0.25rem' }}>
            <button
              onClick={() => handleLaunch('resume')}
              className="btn btn-primary"
              style={{
                padding: '0.8rem 1.75rem',
                fontSize: '0.95rem',
                fontWeight: 700,
                display: 'flex',
                alignItems: 'center',
                gap: '0.55rem',
                borderRadius: '12px',
                boxShadow: '0 4px 18px rgba(37, 99, 235, 0.35)',
              }}
            >
              <FileText size={18} /> Launch AI Resume Studio
            </button>
            <button
              onClick={() => handleLaunch('roadmap')}
              className="btn btn-outline-cyan"
              style={{
                padding: '0.8rem 1.75rem',
                fontSize: '0.95rem',
                fontWeight: 700,
                display: 'flex',
                alignItems: 'center',
                gap: '0.55rem',
                borderRadius: '12px',
              }}
            >
              <Compass size={18} /> Explore Placement Roadmap
            </button>
            <button
              onClick={() => handleLaunch('interview')}
              className="btn btn-secondary"
              style={{
                padding: '0.8rem 1.75rem',
                fontSize: '0.95rem',
                fontWeight: 700,
                display: 'flex',
                alignItems: 'center',
                gap: '0.55rem',
                borderRadius: '12px',
              }}
            >
              <Mic size={18} /> Practice Live AI Interview
            </button>
          </div>

        </div>
      </section>


      {/* ========================================================================= */}
      {/* 2. THE FIVE ARCHITECTURAL PILLARS (Interactive Tabs) */}
      {/* ========================================================================= */}
      <section style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Cpu size={18} color="var(--accent-cyan)" />
            <span style={{ fontSize: '0.75rem', fontWeight: 800, color: 'var(--accent-cyan)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
              System Architecture
            </span>
          </div>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
            Five Pillars Powering Your Employability
          </h2>
          <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', margin: 0 }}>
            Explore how each specialized module works harmoniously to optimize every dimension of student hiring readiness.
          </p>
        </div>

        {/* Pillar Switcher Navigation Bar */}
        <div style={{
          display: 'flex',
          gap: '0.5rem',
          overflowX: 'auto',
          paddingBottom: '0.35rem',
          scrollbarWidth: 'thin'
        }}>
          {[
            { id: 'resume', label: '1. AI Resume Studio', icon: FileText, color: 'var(--accent-cyan)' },
            { id: 'roadmap', label: '2. Placement Roadmap Engine', icon: Compass, color: 'var(--accent-emerald)' },
            { id: 'interview', label: '3. Voice Mock Interview', icon: Mic, color: 'var(--accent-purple)' },
            { id: 'galaxy', label: '4. Spatial 3D Analytics', icon: Orbit, color: 'var(--accent-blue)' },
            { id: 'academia', label: '5. Institutional TPO Portal', icon: Building2, color: 'var(--accent-amber)' },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activePillarTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActivePillarTab(tab.id as any)}
                style={{
                  padding: '0.65rem 1.15rem',
                  borderRadius: '12px',
                  background: isActive ? 'var(--bg-card)' : 'rgba(255, 255, 255, 0.03)',
                  border: isActive ? `1.5px solid ${tab.color}` : '1px solid var(--border-subtle)',
                  color: isActive ? 'var(--text-primary)' : 'var(--text-muted)',
                  fontWeight: isActive ? 700 : 500,
                  fontSize: '0.85rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                  boxShadow: isActive ? `0 4px 16px ${tab.color}25` : 'none',
                  transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)'
                }}
              >
                <Icon size={16} color={isActive ? tab.color : 'var(--text-muted)'} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Pillar Content Card */}
        <div className="glass-card" style={{ padding: '2rem', borderRadius: '20px', minHeight: '320px' }}>
          {activePillarTab === 'resume' && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '2rem', alignItems: 'center' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <span className="badge badge-cyan" style={{ width: 'fit-content', fontSize: '0.72rem' }}>
                  Engine 01 • Deterministic & ATS Verified
                </span>
                <h3 style={{ fontSize: '1.45rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  Ground-Truth AI Resume Engineering & STAR Studio
                </h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
                  Unlike simple LLM text rewrites that invent metrics or fabricate fake companies, Employ.AI uses a 
                  hybrid pipeline: deterministic parser technology guarantees all real personal information, contact links, 
                  and technologies are preserved verbatim, while our AI evaluator audits bullet points on the STAR 
                  (Situation, Task, Action, Result) model.
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {[
                    'Multi-Metric ATS Score Breakdown: Structure, Keywords, Impact & Formatting',
                    'Contextual Job Description Tailoring with real-time match delta',
                    'AI Headline Optimizer and interactive Section Editor',
                    'Zero-Latency local-first synchronization and one-click PDF generation'
                  ].map((feat, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.6rem', fontSize: '0.825rem', color: 'var(--text-primary)' }}>
                      <Check size={16} color="var(--accent-cyan)" style={{ flexShrink: 0, marginTop: '2px' }} />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => handleLaunch('resume')}
                  className="btn btn-outline-cyan btn-sm"
                  style={{ width: 'fit-content', marginTop: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}
                >
                  Open AI Resume Studio <ArrowRight size={14} />
                </button>
              </div>

              <div style={{
                background: 'var(--bg-secondary)',
                borderRadius: '16px',
                border: '1px solid var(--border-subtle)',
                padding: '1.5rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '1rem'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-primary)' }}>ATS Score Engine</span>
                  <span className="badge badge-cyan" style={{ fontSize: '0.7rem' }}>Live Verification</span>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                  <div style={{ padding: '0.85rem', background: 'rgba(255, 255, 255, 0.02)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                    <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Structure & Layout</div>
                    <div style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--accent-cyan)' }}>92%</div>
                  </div>
                  <div style={{ padding: '0.85rem', background: 'rgba(255, 255, 255, 0.02)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                    <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Content Impact</div>
                    <div style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--accent-emerald)' }}>88%</div>
                  </div>
                  <div style={{ padding: '0.85rem', background: 'rgba(255, 255, 255, 0.02)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                    <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Keyword Density</div>
                    <div style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--accent-violet)' }}>85%</div>
                  </div>
                  <div style={{ padding: '0.85rem', background: 'rgba(255, 255, 255, 0.02)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                    <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Formatting Clarity</div>
                    <div style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--accent-amber)' }}>94%</div>
                  </div>
                </div>
                <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: 0, fontStyle: 'italic' }}>
                  "Evaluates exact candidate claims without synthetic exaggeration."
                </p>
              </div>
            </div>
          )}

          {activePillarTab === 'roadmap' && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '2rem', alignItems: 'center' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <span className="badge badge-emerald" style={{ width: 'fit-content', fontSize: '0.72rem' }}>
                  Engine 02 • Co-Domain Specific Roadmap
                </span>
                <h3 style={{ fontSize: '1.45rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  5-Phase Placement Level Roadmap & Progress Engine
                </h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
                  Generic roadmaps that tell everyone to "learn programming" fail students in targeted hiring drives.
                  Employ.AI generates structured, discipline-tailored 5-phase tracks based directly on your chosen co-domain
                  (e.g., DSA, React & Next.js, FastAPI, Docker & Kubernetes, Clinical History, Financial Modeling, etc.).
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {[
                    'Real technical milestone titles representing the exact chosen co-domain',
                    'Verified practical project deliverables with GitHub repo & demo criteria',
                    'Curated learning resources: roadmap.sh, MDN, official documentation & video guides',
                    'Viva & technical screening question banks with authoritative answer guides',
                    'Interactive Progress Engine tracking phases done according to co-domains completed'
                  ].map((feat, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.6rem', fontSize: '0.825rem', color: 'var(--text-primary)' }}>
                      <Check size={16} color="var(--accent-emerald)" style={{ flexShrink: 0, marginTop: '2px' }} />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => handleLaunch('roadmap')}
                  className="btn btn-outline-cyan btn-sm"
                  style={{ width: 'fit-content', marginTop: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}
                >
                  Explore Placement Roadmaps <ArrowRight size={14} />
                </button>
              </div>

              <div style={{
                background: 'var(--bg-secondary)',
                borderRadius: '16px',
                border: '1px solid var(--border-subtle)',
                padding: '1.5rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.85rem'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-primary)' }}>5-Phase Curriculum Structure</span>
                  <span className="badge badge-emerald" style={{ fontSize: '0.7rem' }}>All Co-Domains</span>
                </div>
                {[
                  { phase: 'Phase 1', label: 'Core Fundamentals & Syntax Mastery', icon: '01' },
                  { phase: 'Phase 2', label: 'Architecture, State & Data Modeling', icon: '02' },
                  { phase: 'Phase 3', label: 'Production Engineering & API Ecosystems', icon: '03' },
                  { phase: 'Phase 4', label: 'End-to-End Scalable Capstone Project', icon: '04' },
                  { phase: 'Phase 5', label: 'Enterprise Viva & Interview Screening', icon: '05' },
                ].map((step, idx) => (
                  <div key={idx} style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                    padding: '0.65rem 0.85rem',
                    background: 'rgba(255, 255, 255, 0.02)',
                    borderRadius: '8px',
                    border: '1px solid var(--border-subtle)'
                  }}>
                    <span style={{
                      fontSize: '0.72rem',
                      fontWeight: 800,
                      color: 'var(--accent-emerald)',
                      background: 'rgba(16, 185, 129, 0.12)',
                      padding: '0.2rem 0.45rem',
                      borderRadius: '5px'
                    }}>
                      {step.icon}
                    </span>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <span style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-primary)' }}>{step.phase}</span>
                      <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{step.label}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activePillarTab === 'interview' && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '2rem', alignItems: 'center' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <span className="badge badge-purple" style={{ width: 'fit-content', fontSize: '0.72rem' }}>
                  Engine 03 • Real-Time Voice Simulation
                </span>
                <h3 style={{ fontSize: '1.45rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  AI Mock Interview Simulator with Live Voice Defense
                </h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
                  Acing high-stakes placement rounds requires defending every claim on your resume under pressure.
                  Our AI interviewer reads your exact uploaded projects, tools, and technical experience to generate realistic
                  behavioral, architectural, and situational questions. You speak your answers using natural voice microphone input.
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {[
                    'Speech Recognition & Natural Text-to-Speech Voice synthesis',
                    'Strict STAR framework scoring: Situation, Task, Action & Result verification',
                    'Project Defense Mode: interrogates architecture choices, tradeoffs & database models',
                    'Post-Interview Comprehensive Evaluation Card with verbatim feedback & improvement actions'
                  ].map((feat, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.6rem', fontSize: '0.825rem', color: 'var(--text-primary)' }}>
                      <Check size={16} color="var(--accent-purple)" style={{ flexShrink: 0, marginTop: '2px' }} />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => handleLaunch('interview')}
                  className="btn btn-outline-cyan btn-sm"
                  style={{ width: 'fit-content', marginTop: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}
                >
                  Enter Mock Interview Studio <ArrowRight size={14} />
                </button>
              </div>

              <div style={{
                background: 'var(--bg-secondary)',
                borderRadius: '16px',
                border: '1px solid var(--border-subtle)',
                padding: '1.5rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '1rem'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-primary)' }}>Live Audio Waveform</span>
                  <span className="badge badge-purple" style={{ fontSize: '0.7rem' }}>Voice & STAR AI</span>
                </div>
                <div style={{
                  height: '75px',
                  background: 'rgba(168, 85, 247, 0.06)',
                  borderRadius: '12px',
                  border: '1px dashed rgba(168, 85, 247, 0.3)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '5px'
                }}>
                  {[30, 48, 65, 85, 45, 90, 75, 40, 60, 95, 55, 70, 40, 80, 50, 30].map((h, i) => (
                    <div
                      key={i}
                      style={{
                        width: '4px',
                        height: `${h}%`,
                        backgroundColor: 'var(--accent-purple)',
                        borderRadius: '3px',
                        opacity: 0.8
                      }}
                    />
                  ))}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                  <span>Mic: Active</span>
                  <span>STAR Rubric: 89/100</span>
                  <span>Clarity: High</span>
                </div>
              </div>
            </div>
          )}

          {activePillarTab === 'galaxy' && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '2rem', alignItems: 'center' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <span className="badge badge-blue" style={{ width: 'fit-content', fontSize: '0.72rem' }}>
                  Engine 04 • Spatial Three.js Experience
                </span>
                <h3 style={{ fontSize: '1.45rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  3D Skill Galaxy & Real-Figure Spatial Workspace
                </h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
                  Career trajectories are not flat spreadsheets. Employ.AI brings careers to life through spatial 3D WebGL
                  technologies: a live interactive 3D character hero with reactive physics tracking your mouse gaze, a
                  3D Skill Galaxy visualizing skill clusters in 3D orbit, and a 3D Hologram Scanner that parses resumes in spatial layers.
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {[
                    'Three.js 60fps WebGL rendering with zero main-thread lag',
                    'Interactive mouse tracking and smooth orbital rotation controls',
                    'Curated thematic color palettes (Cyber Cyan, Emerald Matrix, Solar Gold, Deep Violet)',
                    'Spatial representation of required vs acquired skills across 18 domains'
                  ].map((feat, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.6rem', fontSize: '0.825rem', color: 'var(--text-primary)' }}>
                      <Check size={16} color="var(--accent-blue)" style={{ flexShrink: 0, marginTop: '2px' }} />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => handleLaunch('galaxy')}
                  className="btn btn-outline-cyan btn-sm"
                  style={{ width: 'fit-content', marginTop: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}
                >
                  Launch 3D Skill Galaxy <ArrowRight size={14} />
                </button>
              </div>

              <div style={{
                background: 'var(--bg-secondary)',
                borderRadius: '16px',
                border: '1px solid var(--border-subtle)',
                padding: '2rem',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                textAlign: 'center',
                gap: '0.75rem'
              }}>
                <Orbit size={48} color="var(--accent-blue)" style={{ animation: 'spin 12s linear infinite' }} />
                <span style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                  Interactive 3D Galaxy Canvas
                </span>
                <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: 0, maxWidth: '280px' }}>
                  Rotate, zoom, and inspect real skill nodes in 3D space to discover adjacent career competencies.
                </p>
              </div>
            </div>
          )}

          {activePillarTab === 'academia' && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '2rem', alignItems: 'center' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <span className="badge badge-amber" style={{ width: 'fit-content', fontSize: '0.72rem' }}>
                  Engine 05 • Institutional TPO Intelligence
                </span>
                <h3 style={{ fontSize: '1.45rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  Curriculum Gap Analytics for Universities & TPOs
                </h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
                  Universities often discover curriculum deficiencies only when campus recruitment statistics arrive.
                  Employ.AI provides Training and Placement Officers (TPOs) and academic deans with macro analytics:
                  ingesting university syllabi and comparing them against live employer hiring requirements across companies.
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {[
                    'Syllabus Ingestion AI: parses departmental course outlines and detects skill gaps',
                    'Department-wide readiness benchmarking across student cohorts',
                    'Live industry hiring requirement mapping vs academic prerequisites',
                    'Aggregated cohort metrics to guide guest lectures, workshops & syllabus revisions'
                  ].map((feat, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.6rem', fontSize: '0.825rem', color: 'var(--text-primary)' }}>
                      <Check size={16} color="var(--accent-amber)" style={{ flexShrink: 0, marginTop: '2px' }} />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => handleLaunch('academia_overview')}
                  className="btn btn-outline-cyan btn-sm"
                  style={{ width: 'fit-content', marginTop: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}
                >
                  View Institutional Portal <ArrowRight size={14} />
                </button>
              </div>

              <div style={{
                background: 'var(--bg-secondary)',
                borderRadius: '16px',
                border: '1px solid var(--border-subtle)',
                padding: '1.5rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.85rem'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-primary)' }}>Cohort Readiness Distribution</span>
                  <span className="badge badge-amber" style={{ fontSize: '0.7rem' }}>Campus Analytics</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '0.2rem' }}>
                      <span style={{ color: 'var(--text-secondary)' }}>Interview Ready (&gt;80% ATS)</span>
                      <span style={{ fontWeight: 700, color: 'var(--accent-emerald)' }}>64%</span>
                    </div>
                    <div style={{ height: '6px', width: '100%', background: 'var(--border-subtle)', borderRadius: '3px', overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: '64%', background: 'var(--accent-emerald)' }} />
                    </div>
                  </div>

                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '0.2rem' }}>
                      <span style={{ color: 'var(--text-secondary)' }}>Roadmap In Progress</span>
                      <span style={{ fontWeight: 700, color: 'var(--accent-cyan)' }}>28%</span>
                    </div>
                    <div style={{ height: '6px', width: '100%', background: 'var(--border-subtle)', borderRadius: '3px', overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: '28%', background: 'var(--accent-cyan)' }} />
                    </div>
                  </div>

                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '0.2rem' }}>
                      <span style={{ color: 'var(--text-secondary)' }}>Skill Gap Detected</span>
                      <span style={{ fontWeight: 700, color: 'var(--accent-amber)' }}>8%</span>
                    </div>
                    <div style={{ height: '6px', width: '100%', background: 'var(--border-subtle)', borderRadius: '3px', overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: '8%', background: 'var(--accent-amber)' }} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 3. END-TO-END WORKFLOW PIPELINE */}
      {/* ========================================================================= */}
      <section style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Layers size={18} color="var(--accent-emerald)" />
            <span style={{ fontSize: '0.75rem', fontWeight: 800, color: 'var(--accent-emerald)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
              Execution Flow
            </span>
          </div>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
            How Students Succeed with Employ.AI
          </h2>
          <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', margin: 0 }}>
            From initial resume audit to final offer letter, a verified 4-step pipeline accelerates your hiring readiness.
          </p>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: '1rem'
        }}>
          {[
            {
              step: 'Step 01',
              title: 'Ingest & ATS Audit',
              desc: 'Upload your existing PDF resume or build from scratch. Our deterministic engine audits contacts, projects, and STAR bullets against 4 ATS benchmarks.',
              color: 'var(--accent-cyan)',
              icon: FileText
            },
            {
              step: 'Step 02',
              title: 'Skill Gap Discovery',
              desc: 'Explore your field across 18+ domains in the 3D Skill Galaxy. Detect exactly which frameworks, databases, and core concepts top employers demand.',
              color: 'var(--accent-blue)',
              icon: Orbit
            },
            {
              step: 'Step 03',
              title: '5-Phase Co-Domain Roadmap',
              desc: 'Execute weekly milestones calibrated to your active co-domain. Build verifiable capstone projects and track completion on the Progress Engine.',
              color: 'var(--accent-emerald)',
              icon: Compass
            },
            {
              step: 'Step 04',
              title: 'Live Voice Technical Defense',
              desc: 'Enter the AI Mock Interview Studio. Speak naturally into your microphone to defend your actual projects and receive immediate rubric feedback.',
              color: 'var(--accent-purple)',
              icon: Mic
            }
          ].map((item, idx) => {
            const StepIcon = item.icon;
            return (
              <div
                key={idx}
                className="glass-card"
                style={{
                  padding: '1.5rem',
                  borderRadius: '16px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.75rem',
                  position: 'relative'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{
                    fontSize: '0.72rem',
                    fontWeight: 800,
                    color: item.color,
                    background: `${item.color}15`,
                    padding: '0.25rem 0.6rem',
                    borderRadius: '6px'
                  }}>
                    {item.step}
                  </span>
                  <StepIcon size={20} color={item.color} />
                </div>
                <h4 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                  {item.title}
                </h4>
                <p style={{ fontSize: '0.825rem', color: 'var(--text-secondary)', lineHeight: 1.55, margin: 0 }}>
                  {item.desc}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 4. TECHNICAL SPECIFICATIONS & PRIVACY COMMITMENT */}
      {/* ========================================================================= */}
      <section className="glass-card" style={{ padding: '2rem', borderRadius: '20px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '2rem' }}>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Zap size={18} color="var(--accent-amber)" />
              <span style={{ fontSize: '0.75rem', fontWeight: 800, color: 'var(--accent-amber)', textTransform: 'uppercase' }}>
                Engineering Excellence
              </span>
            </div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
              Built for Speed, Scalability & Local-First Reliability
            </h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
              Employ.AI is crafted with high-performance modern web technologies:
            </p>
            <ul style={{ paddingLeft: '1.2rem', margin: 0, fontSize: '0.825rem', color: 'var(--text-secondary)', lineHeight: 1.7 }}>
              <li><strong>Backend:</strong> High-throughput FastAPI (Python 3.11+) with Pydantic v2 schemas and SQLite/PostgreSQL with automatic migration seeding.</li>
              <li><strong>Frontend:</strong> React 18 + TypeScript with zero-rerender WebGL Three.js render loops and buttery 60fps animations.</li>
              <li><strong>AI Integration:</strong> Google Gemini multi-model fallback pipeline coupled with deterministic parsing rules.</li>
              <li><strong>Local-First:</strong> User-scoped storage isolation preventing cache collisions across different logins on shared campus terminals.</li>
            </ul>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Shield size={18} color="var(--accent-emerald)" />
              <span style={{ fontSize: '0.75rem', fontWeight: 800, color: 'var(--accent-emerald)', textTransform: 'uppercase' }}>
                Privacy & Data Integrity
              </span>
            </div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
              Strict Student Data Protection Commitment
            </h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6, margin: 0 }}>
              We understand the sensitive nature of student resumes, academic transcripts, and interview audio:
            </p>
            <ul style={{ paddingLeft: '1.2rem', margin: 0, fontSize: '0.825rem', color: 'var(--text-secondary)', lineHeight: 1.7 }}>
              <li><strong>Zero Unauthorized Monetization:</strong> Your data is never sold, leased, or distributed to advertising networks.</li>
              <li><strong>Encrypted Transport:</strong> All API communication utilizes HTTPS TLS encryption.</li>
              <li><strong>Audio Ephemerality:</strong> Live voice interview audio is processed securely in session and not stored as permanent voiceprints.</li>
              <li><strong>Deterministic Verification:</strong> Personal phone numbers, emails, and links are kept exact and immune to LLM hallucination.</li>
            </ul>
          </div>

        </div>
      </section>

      {/* ========================================================================= */}
      {/* 5. FREQUENTLY ASKED QUESTIONS */}
      {/* ========================================================================= */}
      <section style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <GraduationCap size={18} color="var(--accent-purple)" />
            <span style={{ fontSize: '0.75rem', fontWeight: 800, color: 'var(--accent-purple)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
              Knowledge Base
            </span>
          </div>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
            Frequently Asked Questions
          </h2>
          <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', margin: 0 }}>
            Everything you need to know about the Employ.AI platform, algorithms, and institutional integration.
          </p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {faqs.map((faq, idx) => {
            const isExpanded = expandedFaq === idx;
            return (
              <div
                key={idx}
                className="glass-card"
                style={{
                  borderRadius: '14px',
                  overflow: 'hidden',
                  border: isExpanded ? '1px solid var(--accent-cyan)' : '1px solid var(--border-subtle)',
                  transition: 'border 0.2s ease'
                }}
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(idx)}
                  style={{
                    width: '100%',
                    padding: '1.15rem 1.35rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: '1rem',
                    background: 'none',
                    border: 'none',
                    textAlign: 'left',
                    cursor: 'pointer'
                  }}
                >
                  <span style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                    {faq.question}
                  </span>
                  {isExpanded ? (
                    <ChevronUp size={18} color="var(--accent-cyan)" />
                  ) : (
                    <ChevronDown size={18} color="var(--text-muted)" />
                  )}
                </button>
                {isExpanded && (
                  <div style={{
                    padding: '0 1.35rem 1.25rem 1.35rem',
                    fontSize: '0.85rem',
                    color: 'var(--text-secondary)',
                    lineHeight: 1.65,
                    borderTop: '1px solid var(--border-subtle)',
                    paddingTop: '0.85rem'
                  }}>
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 6. CONTACT & OFFICIAL MERCHANT SUPPORT */}
      {/* ========================================================================= */}
      <section id="contact" className="contact-merchant-section">
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.45rem' }}>
          <div className="contact-section-eyebrow">
            <Headphones size={18} color="var(--accent-cyan)" />
            <span className="contact-section-eyebrow-text">
              Contact & Developer Information
            </span>
          </div>
          <h2 className="contact-section-title">
            Get in Touch with Employ.AI
          </h2>
          <p className="contact-section-subtitle">
            Have questions regarding placement intelligence, institutional partnerships, or Razorpay payment support? Reach out directly to our platform leadership.
          </p>
        </div>

        <div className="contact-grid">
          {/* Card 1: Official Email */}
          <div className="contact-card card-email">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
              <div className="contact-icon-wrap email-icon">
                <Mail size={22} />
              </div>
              <div>
                <span className="contact-card-subheading">Official Email</span>
                <div className="contact-card-primary-val">
                  akhtarrakeeb52@gmail.com
                </div>
              </div>
            </div>
            <p className="contact-card-desc">
              For support, account queries, enterprise onboarding, and Razorpay billing verification.
            </p>
            <a
              href="mailto:akhtarrakeeb52@gmail.com"
              className="contact-action-btn btn-email"
            >
              <Mail size={16} /> Send Email
            </a>
          </div>

          {/* Card 2: Phone Support */}
          <div className="contact-card card-phone">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
              <div className="contact-icon-wrap phone-icon">
                <Phone size={22} />
              </div>
              <div>
                <span className="contact-card-subheading">Direct Phone Support</span>
                <div className="contact-card-primary-val">
                  +91 9415962079
                </div>
              </div>
            </div>
            <p className="contact-card-desc">
              Available for priority developer support, payment issues, and institutional coordination.
            </p>
            <a
              href="tel:+919415962079"
              className="contact-action-btn btn-phone"
            >
              <Phone size={16} /> Call / Contact
            </a>
          </div>

          {/* Card 3: Platform & Merchant Verification */}
          <div className="contact-card card-merchant">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
              <div className="contact-icon-wrap merchant-icon">
                <ShieldCheck size={22} />
              </div>
              <div>
                <span className="contact-card-subheading">Merchant & Entity Details</span>
                <div className="contact-card-primary-val">
                  Employ.AI Platform
                </div>
              </div>
            </div>

            <div className="contact-detail-list">
              <div className="contact-detail-row">
                <span className="contact-detail-label">Lead Developer</span>
                <span className="contact-detail-val">Raza Akhtar</span>
              </div>
              <div className="contact-detail-row">
                <span className="contact-detail-label">Admin Email</span>
                <span className="contact-detail-val">akhtarrakeeb52@gmail.com</span>
              </div>
              <div className="contact-detail-row">
                <span className="contact-detail-label">Contact Number</span>
                <span className="contact-detail-val">+91 9415962079</span>
              </div>
              <div className="contact-detail-row">
                <span className="contact-detail-label">Payment Partner</span>
                <span className="contact-detail-val">Razorpay (UPI, NetBanking, Cards)</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleCopyMerchantDetails}
              className="contact-action-btn btn-merchant"
            >
              {copiedDetails ? (
                <>
                  <Check size={16} color="#10b981" /> Copied to Clipboard
                </>
              ) : (
                <>
                  <Copy size={16} /> Copy Verification Details
                </>
              )}
            </button>
          </div>
        </div>

        {/* Razorpay Merchant Policy Badges */}
        <div className="contact-compliance-strip">
          <div className="contact-compliance-left">
            <ShieldCheck size={20} color="var(--accent-emerald)" />
            <span>
              Razorpay Merchant Compliance: Verified Contact Details & Instant Digital Delivery
            </span>
          </div>
          <div className="contact-compliance-badges">
            <span>🔒 256-bit SSL Secure</span>
            <span>⚡ Instant Pro Activation</span>
            <span>📞 24/7 Support SLA</span>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 7. CALL TO ACTION FOOTER */}
      {/* ========================================================================= */}
      <section className="glass-card" style={{
        padding: '2.5rem',
        borderRadius: '20px',
        textAlign: 'center',
        background: 'linear-gradient(135deg, rgba(2, 132, 199, 0.12) 0%, rgba(16, 185, 129, 0.08) 100%)',
        border: '1px solid rgba(56, 189, 248, 0.25)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '1.25rem'
      }}>
        <div style={{
          width: '56px',
          height: '56px',
          borderRadius: '50%',
          background: 'rgba(56, 189, 248, 0.15)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: 'var(--glow-cyan)'
        }}>
          <Sparkles size={28} color="var(--accent-cyan)" />
        </div>
        <div style={{ maxWidth: '600px' }}>
          <h3 style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--text-primary)', margin: '0 0 0.5rem 0' }}>
            Ready to Accelerate Your Career Trajectory?
          </h3>
          <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.6 }}>
            Upload your resume now to receive immediate, deterministic ATS feedback, build a personalized 5-phase placement roadmap, or test your skills in the live voice mock interview simulator.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', justifyContent: 'center' }}>
          <button
            onClick={() => handleLaunch('resume')}
            className="btn btn-primary"
            style={{ padding: '0.75rem 1.85rem', fontWeight: 700, fontSize: '0.9rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}
          >
            <FileText size={16} /> Open AI Resume Studio
          </button>
          <button
            onClick={() => handleLaunch('interview')}
            className="btn btn-outline-cyan"
            style={{ padding: '0.75rem 1.85rem', fontWeight: 700, fontSize: '0.9rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}
          >
            <Mic size={16} /> Start AI Voice Defense
          </button>
        </div>
      </section>

      {/* Persistent Bottom Legal & Contact Bar */}
      <footer className="contact-footer-bar">
        <div>
          © {new Date().getFullYear()} Employ.AI. All rights reserved. Platform Developed by Raza Akhtar.
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem', flexWrap: 'wrap' }}>
          <a href="mailto:akhtarrakeeb52@gmail.com" style={{ color: 'var(--accent-cyan)' }}>
            akhtarrakeeb52@gmail.com
          </a>
          <span>•</span>
          <a href="tel:+919415962079" style={{ color: 'var(--accent-emerald)' }}>
            +91 9415962079
          </a>
        </div>
      </footer>

    </div>
  );
};

export default AboutView;
