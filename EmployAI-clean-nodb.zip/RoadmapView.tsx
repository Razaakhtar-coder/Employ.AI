import React, { useState, useEffect, useMemo, useRef } from 'react';
import type { LearningRoadmap } from '../types';
import { DOMAIN_CO_DOMAINS, generateCoDomainRoadmap, computeRoadmapProgress, hydrateRoadmapWithSavedProgress, getStreamProgressStats, type StreamProgressStats } from '../utils/domainRoadmapData';
import { YouTubePracticeStudio } from './YouTubePracticeStudio';
import { FuturisticLoader } from './FuturisticLoader';
import { GoodProjectsRoadmapSection } from './GoodProjectsRoadmapSection';
import { 
  CheckCircle2, Circle, Sparkles, 
  FolderGit2, Compass,
  Check, BookOpen,
  Filter, Search,
  Star, Zap, ChevronDown, ChevronUp,
  Wrench, Lightbulb, HelpCircle, ArrowRight,
  Copy, Award, Code2, ExternalLink, Layers
} from 'lucide-react';

interface RoadmapViewProps {
  targetRoleParam?: { roleId?: string; roleTitle?: string; domain?: string; isSkillCoDomain?: boolean } | null;
  onClearTargetRole?: () => void;
}

export const RoadmapView: React.FC<RoadmapViewProps> = ({ targetRoleParam, onClearTargetRole }) => {
  const [roadmap, setRoadmap] = useState<LearningRoadmap | null>(null);
  const [selectedCoDomain, setSelectedCoDomain] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('employai_roadmap_codomain');
      if (saved) return saved;
    } catch {}
    return '';
  });
  const [activeStreamFilter, setActiveStreamFilter] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('employai_roadmap_stream');
      if (saved && DOMAIN_CO_DOMAINS[saved]) return saved;
      const resumeRaw = localStorage.getItem('employai_resume_data');
      if (resumeRaw) {
        const res = JSON.parse(resumeRaw);
        const domain = res?.detected_domain;
        if (domain) {
          const match = Object.keys(DOMAIN_CO_DOMAINS).find(k => 
            k.toLowerCase() === domain.toLowerCase() ||
            domain.toLowerCase().includes(k.toLowerCase()) ||
            k.toLowerCase().includes(domain.toLowerCase())
          );
          if (match) return match;
        }
      }
    } catch {}
    return 'Computer Science';
  });
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedKeyword, setCopiedKeyword] = useState<string | null>(null);
  
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [expandedMilestones, setExpandedMilestones] = useState<Record<number, boolean>>({
    0: true, 1: true, 2: true, 3: true, 4: true
  });

  const hasInitializedRef = useRef<boolean>(false);
  const lastTargetRoleTitleRef = useRef<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  const handleCopyText = (text: string, label?: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKeyword(text);
    showToast(`Copied ${label || 'text'} to clipboard!`);
    setTimeout(() => setCopiedKeyword(null), 2500);
  };

  const toggleMilestoneExpand = (idx: number) => {
    setExpandedMilestones(prev => ({ ...prev, [idx]: !prev[idx] }));
  };

  // Co-Domains available for current stream
  const availableCoDomains = useMemo(() => {
    const list = DOMAIN_CO_DOMAINS[activeStreamFilter] || [];
    if (!searchQuery.trim()) return list;
    return list.filter(item => 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.short_description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [activeStreamFilter, searchQuery]);

  // Dynamic progress stats across videos and phase tasks
  const progressStats = useMemo(() => {
    if (!roadmap) {
      return {
        completionPct: 0,
        watchedVideosCount: 0,
        totalVideosCount: 0,
        completedTasksCount: 0,
        totalTasksCount: 0,
        completedPhasesCount: 0,
        totalPhasesCount: 5
      };
    }
    return computeRoadmapProgress(roadmap);
  }, [roadmap]);

  const [taskUpdateTrigger, setTaskUpdateTrigger] = useState<number>(0);

  // Dynamic progress stats across all co-domains in the active stream
  const streamStats: StreamProgressStats = useMemo(() => {
    return getStreamProgressStats(activeStreamFilter, availableCoDomains);
  }, [activeStreamFilter, availableCoDomains, roadmap, taskUpdateTrigger]);

  // Initial mount: load active co-domain or targeted role ONCE
  useEffect(() => {
    if (targetRoleParam && (targetRoleParam.roleTitle || targetRoleParam.roleId)) {
      const queryTitle = (targetRoleParam.roleTitle || '').trim();
      if (queryTitle && queryTitle !== lastTargetRoleTitleRef.current) {
        lastTargetRoleTitleRef.current = queryTitle;
        const rawDomain = targetRoleParam.domain || activeStreamFilter || 'Computer Science';
        
        const matchDomainKey = Object.keys(DOMAIN_CO_DOMAINS).find(k => 
          k.toLowerCase() === rawDomain.toLowerCase() || 
          rawDomain.toLowerCase().includes(k.toLowerCase()) || 
          k.toLowerCase().includes(rawDomain.toLowerCase())
        ) || rawDomain;
        
        const rawRoadmap = generateCoDomainRoadmap(queryTitle, matchDomainKey);
        const generatedRoadmap = hydrateRoadmapWithSavedProgress(rawRoadmap);
        setRoadmap(generatedRoadmap);
        setSelectedCoDomain(queryTitle);
        setActiveStreamFilter(matchDomainKey);
        setIsLoading(false);
        showToast(`Loaded Placement Level Roadmap for "${queryTitle}" (${matchDomainKey})!`);
        if (onClearTargetRole) onClearTargetRole();
        return;
      }
    }

    if (!hasInitializedRef.current) {
      hasInitializedRef.current = true;
      setIsLoading(true);
      setError(null);
      try {
        const stream = activeStreamFilter || 'Computer Science';
        const streamList = DOMAIN_CO_DOMAINS[stream] || DOMAIN_CO_DOMAINS['Computer Science'];
        const savedCoDomain = localStorage.getItem('employai_roadmap_codomain');
        const defaultCoDomain = (savedCoDomain && streamList.some(item => item.name === savedCoDomain))
          ? savedCoDomain
          : (streamList[0]?.name || 'Data Structures & Algorithms (DSA)');
        
        const rawRoadmap = generateCoDomainRoadmap(defaultCoDomain, stream);
        const initialRoadmap = hydrateRoadmapWithSavedProgress(rawRoadmap);
        setRoadmap(initialRoadmap);
        setSelectedCoDomain(defaultCoDomain);
      } catch (err: any) {
        setError(err?.message || 'Failed to load roadmap data');
      } finally {
        setIsLoading(false);
      }
    }
  }, [targetRoleParam]);

  // Real-time synchronization when YouTube videos are watched or toggled
  useEffect(() => {
    const handleVideoWatchedUpdate = () => {
      setTaskUpdateTrigger(prev => prev + 1);
      setRoadmap(prev => {
        if (!prev) return prev;
        const refreshed = hydrateRoadmapWithSavedProgress(prev);
        window.dispatchEvent(new CustomEvent('employai:roadmap-progress-updated', {
          detail: {
            roadmapId: refreshed.id,
            completionPct: refreshed.completion_pct
          }
        }));
        return refreshed;
      });
    };

    window.addEventListener('employai:video-watched-toggled', handleVideoWatchedUpdate);
    window.addEventListener('storage', handleVideoWatchedUpdate);
    return () => {
      window.removeEventListener('employai:video-watched-toggled', handleVideoWatchedUpdate);
      window.removeEventListener('storage', handleVideoWatchedUpdate);
    };
  }, []);

  // Toggle Task Completion and recalculate dynamic progress
  const handleToggleTask = (milestoneIdx: number, taskId: string) => {
    if (!roadmap) return;

    const updated = { ...roadmap };
    const task = updated.milestones[milestoneIdx]?.tasks.find(t => t.id === taskId);
    if (task) {
      task.is_completed = !task.is_completed;

      try {
        let storedTasks: string[] = [];
        const raw = localStorage.getItem('employai_completed_tasks');
        if (raw) storedTasks = JSON.parse(raw);
        if (task.is_completed) {
          if (!storedTasks.includes(taskId)) storedTasks.push(taskId);
        } else {
          storedTasks = storedTasks.filter(id => id !== taskId);
        }
        localStorage.setItem('employai_completed_tasks', JSON.stringify(storedTasks));
      } catch {}

      const refreshed = hydrateRoadmapWithSavedProgress(updated);
      setRoadmap(refreshed);
      setTaskUpdateTrigger(prev => prev + 1);

      window.dispatchEvent(new CustomEvent('employai:roadmap-progress-updated', {
        detail: {
          roadmapId: refreshed.id,
          completionPct: refreshed.completion_pct
        }
      }));

      showToast(task.is_completed ? `Completed task: "${task.title}"!` : `Marked task as pending.`);
    }
  };

  // Switch Selected Co-Domain with zero scroll jump or layout shift
  const handleSelectCoDomain = (coDomainName: string, domainName: string, e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }

    const contentArea = document.querySelector('.content-area') as HTMLElement | null;
    const currentScrollTop = contentArea ? contentArea.scrollTop : window.scrollY;

    setSelectedCoDomain(coDomainName);
    try {
      localStorage.setItem('employai_roadmap_codomain', coDomainName);
      localStorage.setItem('employai_roadmap_stream', domainName);
    } catch {}

    const rawRoadmap = generateCoDomainRoadmap(coDomainName, domainName);
    const refreshed = hydrateRoadmapWithSavedProgress(rawRoadmap);
    setRoadmap(refreshed);

    window.dispatchEvent(new CustomEvent('employai:roadmap-progress-updated', {
      detail: {
        roadmapId: refreshed.id,
        completionPct: refreshed.completion_pct
      }
    }));

    showToast(`Loaded Beginner to Placement Destination Roadmap for "${coDomainName}"!`);

    requestAnimationFrame(() => {
      if (contentArea) {
        contentArea.scrollTop = currentScrollTop;
      } else {
        window.scrollTo(0, currentScrollTop);
      }
    });
  };

  if (isLoading) {
    return (
      <div className="glass-card" style={{ padding: '3.5rem 1.5rem', textAlign: 'center' }}>
        <FuturisticLoader
          size="md"
          icon="zap"
          title="Loading Exact Beginner-to-Placement Roadmaps..."
          subtitle="Connecting to the EmployAI curriculum engine with verifiable milestones"
        />
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      {/* Toast Notification */}
      {toastMsg && (
        <div style={{
          position: 'fixed',
          top: '1.5rem',
          right: '1.5rem',
          zIndex: 99999,
          background: 'var(--bg-modal)',
          color: 'var(--text-primary)',
          border: '1.5px solid var(--accent-cyan)',
          padding: '0.75rem 1.25rem',
          borderRadius: '10px',
          boxShadow: 'var(--shadow-modal)',
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          fontSize: '0.85rem',
          fontWeight: 700
        }}>
          <Check size={16} color="var(--accent-emerald)" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Header Banner & Placement Progress Engine */}
      <div id="placement-roadmap-section" style={{ display: 'flex', flexDirection: 'column', gap: '1rem', scrollMarginTop: '80px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
              <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.5rem', margin: 0 }}>
                <Compass size={24} color="var(--accent-cyan)" />
                Beginner to Internship & Placement Level Roadmaps
              </h2>
              <span className="badge badge-cyan">
                <Sparkles size={12} /> 100% Exact & Career-Destination Aligned
              </span>
              <span className="badge badge-purple" style={{ fontSize: '0.72rem', fontWeight: 700 }}>
                {roadmap?.completion_pct || 0}% Completed ({selectedCoDomain})
              </span>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.25rem', marginBottom: 0 }}>
              Comprehensive 5-phase progressive curriculum engineered from foundational theory to practical capstones, technical screening mastery, and verified placement.
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              const el = document.getElementById('good-projects-section');
              if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }
            }}
            className="btn btn-outline-cyan btn-sm"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '0.45rem', fontWeight: 700, borderRadius: '8px' }}
          >
            <FolderGit2 size={15} color="var(--accent-cyan)" /> Explore Projects & Build Roadmaps ({selectedCoDomain}) ↓
          </button>
        </div>

        {/* Global Dynamic Progress Engine */}
        <div 
          className="glass-card" 
          style={{ 
            padding: '1rem 1.25rem', 
            borderRadius: '12px',
            border: '1.5px solid rgba(56, 189, 248, 0.35)', 
            background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.05) 0%, rgba(168, 85, 247, 0.05) 100%)',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.85rem'
          }}
        >
          {/* Top Engine Row: Active Co-Domain Progress & Stream Co-Domains Completed */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
            {/* Active Co-Domain Placement Progress */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem', flexWrap: 'wrap' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '0.75rem', fontSize: '0.74rem', marginBottom: '0.25rem' }}>
                  <span style={{ color: 'var(--text-primary)', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                    <Compass size={13} color="var(--accent-cyan)" /> {selectedCoDomain}
                  </span>
                  <span style={{ fontWeight: 800, color: '#38bdf8' }}>{roadmap?.completion_pct || 0}%</span>
                </div>
                <div style={{ width: '180px', height: '6px', background: 'rgba(255, 255, 255, 0.08)', borderRadius: '4px', overflow: 'hidden' }}>
                  <div style={{ width: `${roadmap?.completion_pct || 0}%`, height: '100%', background: 'linear-gradient(90deg, #00f2fe 0%, #3b82f6 100%)', transition: 'width 0.3s ease' }} />
                </div>
              </div>

              {/* Co-Domain Phases Done Badge */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.2rem' }}>
                <span className="badge badge-cyan" style={{ fontSize: '0.72rem', fontWeight: 800 }}>
                  <Zap size={11} /> {progressStats.completedPhasesCount}/{progressStats.totalPhasesCount} Phases Done ({selectedCoDomain})
                </span>
                <span style={{ fontSize: '0.66rem', color: 'var(--text-muted)' }}>
                  🎥 {progressStats.watchedVideosCount}/{progressStats.totalVideosCount} Videos • ✅ {progressStats.completedTasksCount}/{progressStats.totalTasksCount} Tasks
                </span>
              </div>
            </div>

            {/* Stream Co-Domains Completed Metric Cards */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
              <div style={{ padding: '0.45rem 0.85rem', borderRadius: '8px', background: 'rgba(168, 85, 247, 0.1)', border: '1px solid rgba(168, 85, 247, 0.3)', display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <Award size={18} color="var(--accent-purple)" />
                <div>
                  <div style={{ fontSize: '0.66rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase' }}>Co-Domains Completed</div>
                  <div style={{ fontSize: '0.88rem', fontWeight: 800, color: 'var(--accent-purple)' }}>
                    {streamStats.completedCoDomainsCount} / {streamStats.totalCoDomainsCount} Mastered
                  </div>
                </div>
              </div>

              <div style={{ padding: '0.45rem 0.85rem', borderRadius: '8px', background: 'rgba(16, 185, 129, 0.1)', border: '1px solid rgba(16, 185, 129, 0.3)', display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <Sparkles size={18} color="var(--accent-emerald)" />
                <div>
                  <div style={{ fontSize: '0.66rem', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase' }}>Stream Total Phases</div>
                  <div style={{ fontSize: '0.88rem', fontWeight: 800, color: 'var(--accent-emerald)' }}>
                    {streamStats.completedPhasesCount} / {streamStats.totalPhasesCount} Phases Done
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Phase Stepper: Shows All 5 Phases According to Active Co-Domain */}
          <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: '0.65rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.45rem', flexWrap: 'wrap', gap: '0.4rem' }}>
              <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <Layers size={13} color="var(--accent-cyan)" /> Phases for {selectedCoDomain} ({progressStats.completedPhasesCount}/5 Completed):
              </span>
              <span style={{ fontSize: '0.67rem', color: 'var(--accent-cyan)', fontWeight: 600 }}>
                Click any phase card to jump directly to its syllabus ↓
              </span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '0.5rem' }}>
              {(roadmap?.milestones || []).map((m, idx) => {
                const phaseTasksCount = (m.tasks || []).length;
                const phaseCompletedTasks = (m.tasks || []).filter(t => t.is_completed).length;
                const phaseVideos = (m.youtube_resources || []).length;
                const phaseWatched = (m.youtube_resources || []).filter(v => {
                  try {
                    return typeof window !== 'undefined' && localStorage.getItem(`yt_watched_${v.id}`) === 'true';
                  } catch {
                    return false;
                  }
                }).length;
                const isPhaseDone = (phaseTasksCount > 0 ? phaseCompletedTasks === phaseTasksCount : true) &&
                  (phaseVideos > 0 ? phaseWatched === phaseVideos : true) &&
                  (phaseTasksCount > 0 || phaseVideos > 0);

                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      const el = document.getElementById(`milestone-phase-${idx}`);
                      if (el) {
                        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                      }
                    }}
                    style={{
                      background: isPhaseDone ? 'rgba(16, 185, 129, 0.12)' : 'var(--bg-tertiary)',
                      border: isPhaseDone ? '1px solid rgba(16, 185, 129, 0.4)' : '1px solid var(--border-subtle)',
                      padding: '0.45rem 0.65rem',
                      borderRadius: '8px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.5rem',
                      cursor: 'pointer',
                      textAlign: 'left',
                      transition: 'all 0.15s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = isPhaseDone ? '#10b981' : 'var(--accent-cyan)';
                      e.currentTarget.style.transform = 'translateY(-1px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = isPhaseDone ? 'rgba(16, 185, 129, 0.4)' : 'var(--border-subtle)';
                      e.currentTarget.style.transform = 'translateY(0)';
                    }}
                  >
                    <span style={{
                      width: '22px',
                      height: '22px',
                      borderRadius: '50%',
                      background: isPhaseDone ? '#10b981' : 'rgba(56, 189, 248, 0.2)',
                      color: isPhaseDone ? '#fff' : 'var(--accent-cyan)',
                      fontSize: '0.68rem',
                      fontWeight: 800,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0
                    }}>
                      {isPhaseDone ? '✓' : `P${idx + 1}`}
                    </span>
                    <div style={{ overflow: 'hidden', minWidth: 0 }}>
                      <div style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--text-primary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {m.phase_title || `Phase ${idx + 1}`}
                      </div>
                      <div style={{ fontSize: '0.64rem', color: isPhaseDone ? 'var(--accent-emerald)' : 'var(--text-muted)' }}>
                        {isPhaseDone ? '✓ Phase Completed' : `${phaseCompletedTasks}/${phaseTasksCount} Tasks • ${phaseWatched}/${phaseVideos} Videos`}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Stream Filter & Co-Domains Selection */}
      <div className="glass-card" style={{ padding: '0.85rem 1rem', display: 'flex', flexDirection: 'column', gap: '0.75rem', border: '1px solid var(--border-subtle)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-primary)', fontWeight: 700, fontSize: '0.85rem' }}>
            <Code2 size={16} color="var(--accent-cyan)" />
            <span>Explore Specific Co-Domains & Skills</span>
          </div>

          <div style={{ position: 'relative', minWidth: '220px' }}>
            <Search size={13} style={{ position: 'absolute', left: '0.6rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              type="text"
              placeholder="Search co-domain (e.g. React, SQL, Radiology)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                width: '100%',
                padding: '0.35rem 0.5rem 0.35rem 1.8rem',
                fontSize: '0.75rem',
                borderRadius: '6px',
                background: 'var(--bg-glass)',
                border: '1px solid var(--border-subtle)',
                color: 'var(--text-primary)',
                outline: 'none'
              }}
            />
          </div>
        </div>

        {/* Stream Filter Tabs */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap', paddingTop: '0.2rem' }}>
          <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.3rem', fontWeight: 600, textTransform: 'uppercase' }}>
            <Filter size={12} /> Stream:
          </span>
          {[
            { id: 'Computer Science', label: '💻 Computer Science' },
            { id: 'MBBS', label: '🩺 MBBS & Medicine' },
            { id: 'Nursing', label: '🏥 Nursing & Care' },
            { id: 'Business Analytics', label: '📈 Business Analytics' },
            { id: 'BCOM', label: '📊 Commerce & Ind AS' },
            { id: 'BBA', label: '💼 Management & BBA' },
            { id: 'BA LLB', label: '⚖️ Law & Corporate' },
            { id: 'Aviation', label: '✈️ Pilot Studies' },
            { id: 'Aeronautical', label: '🚀 Aeronautical' },
            { id: 'Cabin Crew', label: '👩‍✈️ Cabin Crew' },
            { id: 'Robotics', label: '🤖 Robotics' },
            { id: 'Biotechnology', label: '🧬 Biotechnology' },
            { id: 'Marine', label: '⚓ Marine Eng' },
            { id: 'Mechanical', label: '⚙️ Mechanical' },
            { id: 'Civil', label: '🏗️ Civil & BIM' },
            { id: 'Electrical', label: '⚡ Electrical' },
            { id: 'Chemical', label: '🧪 Chemical' },
            { id: 'BA Hons', label: '🏛️ Humanities' }
          ].map(tab => (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setActiveStreamFilter(tab.id);
                try {
                  localStorage.setItem('employai_roadmap_stream', tab.id);
                } catch {}
                const streamList = DOMAIN_CO_DOMAINS[tab.id] || [];
                if (streamList.length > 0) {
                  handleSelectCoDomain(streamList[0].name, tab.id);
                }
              }}
              className={activeStreamFilter === tab.id ? 'btn btn-primary btn-sm' : 'btn btn-secondary btn-sm'}
              style={{ fontSize: '0.725rem', padding: '0.25rem 0.6rem', borderRadius: '6px' }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Co-Domain Pill Grid Selector - Rock-solid in place with zero layout shifting */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap', paddingTop: '0.3rem' }}>
          {availableCoDomains.map((coItem) => {
            const isSelected = selectedCoDomain === coItem.name || (roadmap?.co_domain_name === coItem.name);
            const coStats = streamStats.coDomainMap[coItem.name];
            const phasesDone = coStats?.completedPhasesCount || 0;
            const isAllPhasesDone = coStats?.isCompleted || false;

            return (
              <button
                key={coItem.id}
                type="button"
                onClick={(e) => handleSelectCoDomain(coItem.name, activeStreamFilter, e)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.45rem',
                  fontSize: '0.78rem',
                  padding: '0.35rem 0.8rem',
                  borderRadius: '20px',
                  border: isSelected ? '1.5px solid var(--accent-cyan)' : '1.5px solid var(--border-subtle)',
                  background: isSelected ? 'rgba(56, 189, 248, 0.22)' : 'rgba(255, 255, 255, 0.03)',
                  color: isSelected ? 'var(--accent-cyan)' : 'var(--text-secondary)',
                  fontWeight: isSelected ? 800 : 500,
                  cursor: 'pointer',
                  transition: 'background-color 0.15s ease, color 0.15s ease, box-shadow 0.15s ease',
                  boxShadow: isSelected ? '0 0 14px rgba(56, 189, 248, 0.35)' : 'none',
                  contain: 'layout style',
                  whiteSpace: 'nowrap'
                }}
              >
                <Sparkles size={12} color={isSelected ? 'var(--accent-cyan)' : 'var(--text-muted)'} />
                <span>{coItem.name}</span>
                {isAllPhasesDone ? (
                  <span style={{
                    background: 'rgba(16, 185, 129, 0.25)',
                    color: '#10b981',
                    fontSize: '0.62rem',
                    fontWeight: 800,
                    padding: '0.1rem 0.4rem',
                    borderRadius: '10px'
                  }}>
                    ✓ 5/5
                  </span>
                ) : phasesDone > 0 ? (
                  <span style={{
                    background: 'rgba(56, 189, 248, 0.25)',
                    color: '#38bdf8',
                    fontSize: '0.62rem',
                    fontWeight: 800,
                    padding: '0.1rem 0.4rem',
                    borderRadius: '10px'
                  }}>
                    {phasesDone}/5
                  </span>
                ) : (
                  <span style={{
                    background: 'rgba(255, 255, 255, 0.06)',
                    color: 'var(--text-muted)',
                    fontSize: '0.62rem',
                    fontWeight: 600,
                    padding: '0.1rem 0.35rem',
                    borderRadius: '10px'
                  }}>
                    0/5
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {error && (
        <div style={{ padding: '0.75rem 1rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.1)', border: '1px solid rgba(244, 63, 94, 0.3)', color: '#fb7185', fontSize: '0.825rem' }}>
          {error}
        </div>
      )}

      {/* Target Active Hero Card */}
      {roadmap && (
        <div 
          className="role-hero-banner"
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '1rem',
            background: 'var(--grad-banner)',
            border: '1px solid var(--border-glass)'
          }}
        >
          <div style={{ maxWidth: '680px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.3rem' }}>
              <span className="badge badge-cyan">{roadmap.domain || roadmap.target_domain}</span>
              <span className="badge badge-emerald" style={{ fontSize: '0.68rem' }}>
                <Star size={11} /> 100% Exact Roadmap
              </span>
              <span className="badge badge-purple" style={{ fontSize: '0.68rem' }}>
                Beginner → Placement Destination
              </span>
            </div>
            <h3 style={{ fontSize: '1.4rem', fontWeight: 900, color: 'var(--text-primary)', margin: 0 }}>
              {roadmap.title || roadmap.target_role_title}
            </h3>
            <p style={{ fontSize: '0.84rem', color: 'var(--text-secondary)', marginTop: '0.25rem', lineHeight: 1.45 }}>
              Progressive mastery structured into 5 concrete phases: Foundations, Applied Tooling, Advanced Systems, Capstone Projects, and Placement Readiness.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap' }}>
            <div className="banner-stat-box">
              <div style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--accent-cyan)' }}>5 Phases</div>
              <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>Beginner to Placement</div>
            </div>
            <div className="banner-stat-box">
              <div style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--accent-emerald)' }}>100% Practical</div>
              <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>Capstones & ATS Prep</div>
            </div>
          </div>
        </div>
      )}

      {/* 5-Phase Progressive Milestones Timeline */}
      {roadmap && roadmap.milestones && roadmap.milestones.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          {roadmap.milestones.map((milestone, mIdx) => {
            const isExpanded = expandedMilestones[mIdx] !== false;
            const phaseColors = ['#00f2fe', '#38bdf8', '#818cf8', '#a855f7', '#10b981'];
            const phaseIcons = ['🏁', '⚡', '🔬', '🏆', '🚀'];
            const levelBadges = [
              'Phase 1: Beginner Fundamentals & First Principles',
              'Phase 2: Intermediate Core & Applied Industry Tooling',
              'Phase 3: Advanced Industry Practice & Scalable Systems',
              'Phase 4: Flagship Production Projects & Portfolio Case Studies',
              'Phase 5: Internship & Placement Level Destination (Ready for Hiring)'
            ];

            const completedTasksCount = (milestone.tasks || []).filter(t => t.is_completed).length;
            const totalTasksCount = (milestone.tasks || []).length;
            const color = phaseColors[mIdx % phaseColors.length];

            const phaseWatchedVideos = (milestone.youtube_resources || []).filter(v => {
              try {
                return typeof window !== 'undefined' && localStorage.getItem(`yt_watched_${v.id}`) === 'true';
              } catch {
                return false;
              }
            }).length;
            const phaseTotalVideos = (milestone.youtube_resources || []).length;
            const isPhaseDone = (totalTasksCount > 0 ? completedTasksCount === totalTasksCount : true) &&
                                (phaseTotalVideos > 0 ? phaseWatchedVideos === phaseTotalVideos : true) &&
                                (totalTasksCount > 0 || phaseTotalVideos > 0);

            return (
              <div
                key={mIdx}
                id={`milestone-phase-${mIdx}`}
                className="sprint-milestone-card"
                style={{
                  borderLeft: `4px solid ${color}`,
                  boxShadow: isExpanded ? `0 8px 30px rgba(0,0,0,0.15), inset 0 0 15px ${color}11` : 'var(--shadow-sm)'
                }}
              >
                {/* Milestone Header */}
                <div 
                  style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem', cursor: 'pointer' }} 
                  onClick={() => toggleMilestoneExpand(mIdx)}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
                    <span className="badge" style={{ background: `${color}18`, color: color, fontSize: '0.75rem', fontWeight: 800, border: `1px solid ${color}44` }}>
                      {phaseIcons[mIdx % phaseIcons.length]} {milestone.week_range}
                    </span>
                    <span className="badge" style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)', border: '1px solid var(--border-subtle)', fontSize: '0.7rem' }}>
                      {milestone.phase_title || levelBadges[mIdx % levelBadges.length]}
                    </span>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                      {milestone.focus_skill}
                    </h3>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    {isPhaseDone ? (
                      <span className="badge badge-emerald" style={{ fontSize: '0.72rem', fontWeight: 800, display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                        <CheckCircle2 size={13} /> Phase Completed
                      </span>
                    ) : (
                      <span style={{ fontSize: '0.75rem', fontWeight: 700, color: color }}>
                        {completedTasksCount}/{totalTasksCount} Tasks • {phaseWatchedVideos}/{phaseTotalVideos} Videos
                      </span>
                    )}
                    <button
                      type="button"
                      style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', display: 'flex', alignItems: 'center' }}
                    >
                      {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                    </button>
                  </div>
                </div>

                {/* Milestone Goal Statement */}
                <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '1rem', lineHeight: 1.5 }}>
                  🎯 <strong>Phase Goal:</strong> {milestone.goal}
                </p>

                {isExpanded && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1.1rem' }}>
                    {/* Step-by-Step "How to Achieve" Section */}
                    {milestone.how_to_achieve && (
                      <div className="action-guide-box">
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', marginBottom: '0.6rem' }}>
                          <Compass size={16} color="var(--accent-cyan)" />
                          <span style={{ fontSize: '0.8rem', fontWeight: 800, color: 'var(--accent-cyan)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                            Step-by-Step Action Guide:
                          </span>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.45rem' }}>
                          {milestone.how_to_achieve.split('\n').map((step, sIdx) => (
                            <div key={sIdx} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.5rem', fontSize: '0.82rem', color: 'var(--text-primary)', lineHeight: 1.5 }}>
                              <ArrowRight size={13} style={{ color: color, flexShrink: 0, marginTop: '0.2rem' }} />
                              <span>{step}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Recommended Tools & Software */}
                    {milestone.recommended_tools && milestone.recommended_tools.length > 0 && (
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                        <span style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.3rem', textTransform: 'uppercase' }}>
                          <Wrench size={13} color={color} /> Recommended Software & Stack:
                        </span>
                        {milestone.recommended_tools.map((tool, tIdx) => (
                          <span 
                            key={tIdx} 
                            style={{ 
                              background: 'var(--bg-tertiary)', 
                              border: '1px solid var(--border-subtle)', 
                              padding: '0.25rem 0.6rem', 
                              borderRadius: '6px', 
                              fontSize: '0.74rem', 
                              color: 'var(--text-primary)', 
                              fontWeight: 600 
                            }}
                          >
                            🛠️ {tool}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Key Topics Checklist */}
                    {milestone.topics && milestone.topics.length > 0 && (
                      <div className="curriculum-topics-box">
                        <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'flex', alignItems: 'center', gap: '0.3rem', marginBottom: '0.5rem' }}>
                          <BookOpen size={12} color="var(--accent-cyan)" /> Core Curriculum Topics & Concepts:
                        </span>
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '0.45rem' }}>
                          {milestone.topics.map((top, tIdx) => (
                            <div key={tIdx} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.45rem', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                              <span style={{ color: color, fontWeight: 800 }}>•</span>
                              <span>{top}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Interactive YouTube Video Masterclass Platform */}
                    {milestone.youtube_resources && milestone.youtube_resources.length > 0 && (
                      <YouTubePracticeStudio
                        resources={milestone.youtube_resources}
                        milestoneIndex={mIdx}
                        domainName={roadmap.domain || roadmap.target_domain || activeStreamFilter || 'Computer Science'}
                        coDomainName={milestone.focus_skill || roadmap.title}
                      />
                    )}

                    {/* Verified Learning Platforms & Courseware Resources */}
                    {milestone.learning_platforms && milestone.learning_platforms.length > 0 && (
                      <div style={{ padding: '1rem', background: 'rgba(56, 189, 248, 0.05)', borderRadius: '10px', border: '1px solid rgba(56, 189, 248, 0.2)' }}>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.65rem', flexWrap: 'wrap', gap: '0.4rem' }}>
                          <span style={{ fontSize: '0.75rem', fontWeight: 800, color: 'var(--accent-cyan)', textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                            <BookOpen size={14} color="var(--accent-cyan)" /> Verified Learning Platforms & Courseware:
                          </span>
                          <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>
                            Direct access to authentic learning portals & documentation
                          </span>
                        </div>
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '0.75rem' }}>
                          {milestone.learning_platforms.map((res, rIdx) => (
                            <a
                              key={rIdx}
                              href={res.platform_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              style={{
                                display: 'flex',
                                flexDirection: 'column',
                                justifyContent: 'space-between',
                                padding: '0.75rem 0.9rem',
                                background: 'var(--bg-tertiary)',
                                borderRadius: '8px',
                                border: '1px solid var(--border-subtle)',
                                textDecoration: 'none',
                                color: 'inherit',
                                transition: 'all 0.2s ease',
                                cursor: 'pointer'
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.borderColor = 'var(--accent-cyan)';
                                e.currentTarget.style.transform = 'translateY(-2px)';
                                e.currentTarget.style.boxShadow = '0 4px 12px rgba(56, 189, 248, 0.15)';
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.borderColor = 'var(--border-subtle)';
                                e.currentTarget.style.transform = 'translateY(0)';
                                e.currentTarget.style.boxShadow = 'none';
                              }}
                            >
                              <div>
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem', marginBottom: '0.35rem' }}>
                                  <span style={{ fontWeight: 700, fontSize: '0.82rem', color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                                    🎓 {res.platform_name}
                                  </span>
                                  <span style={{ display: 'flex', alignItems: 'center', gap: '0.2rem', color: 'var(--accent-cyan)', fontSize: '0.7rem', fontWeight: 600 }}>
                                    <ExternalLink size={12} /> Open ↗
                                  </span>
                                </div>
                                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.3rem', marginBottom: '0.4rem' }}>
                                  <span style={{ background: 'rgba(56, 189, 248, 0.12)', color: 'var(--accent-cyan)', border: '1px solid rgba(56, 189, 248, 0.25)', fontSize: '0.66rem', fontWeight: 600, padding: '0.1rem 0.45rem', borderRadius: '4px' }}>
                                    📌 {res.topic_focus}
                                  </span>
                                  <span style={{ background: 'rgba(168, 85, 247, 0.12)', color: 'var(--accent-purple)', border: '1px solid rgba(168, 85, 247, 0.25)', fontSize: '0.66rem', fontWeight: 600, padding: '0.1rem 0.45rem', borderRadius: '4px' }}>
                                    ⭐ {res.access_badge}
                                  </span>
                                </div>
                                <p style={{ fontSize: '0.74rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.4 }}>
                                  {res.description}
                                </p>
                              </div>
                            </a>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Industry Pro-Tips */}
                    {milestone.pro_tips && milestone.pro_tips.length > 0 && (
                      <div className="protip-box">
                        <span style={{ fontSize: '0.7rem', fontWeight: 800, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: '0.3rem', marginBottom: '0.35rem' }}>
                          <Lightbulb size={13} color="var(--accent-amber)" /> Industry Pro-Tips & Pitfalls to Avoid:
                        </span>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
                          {milestone.pro_tips.map((tip, pIdx) => (
                            <div key={pIdx} style={{ fontSize: '0.78rem', color: 'inherit', display: 'flex', alignItems: 'flex-start', gap: '0.4rem', lineHeight: 1.45 }}>
                              <span>💡</span>
                              <span>{tip}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Checkpoint Screening & Interview Questions (with Answer Guides) */}
                    {milestone.interview_questions && milestone.interview_questions.length > 0 && (
                      <div style={{ padding: '1rem', background: 'rgba(168, 85, 247, 0.06)', borderRadius: '10px', border: '1px solid rgba(168, 85, 247, 0.25)' }}>
                        <span style={{ fontSize: '0.72rem', fontWeight: 800, color: 'var(--accent-purple)', textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: '0.35rem', marginBottom: '0.6rem' }}>
                          <HelpCircle size={14} color="var(--accent-purple)" /> Technical Screening Questions for this Phase:
                        </span>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                          {milestone.interview_questions.map((iq, iqIdx) => (
                            <div key={iqIdx} style={{ padding: '0.6rem 0.8rem', background: 'var(--bg-tertiary)', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
                              <div style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.2rem' }}>
                                Q{iqIdx + 1}: {iq.question}
                              </div>
                              {iq.answer_guide && (
                                <div style={{ fontSize: '0.74rem', color: 'var(--text-muted)' }}>
                                  <strong style={{ color: 'var(--accent-purple)' }}>Answer Strategy:</strong> {iq.answer_guide}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Actionable Tasks Checklist */}
                    {milestone.tasks && milestone.tasks.length > 0 && (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                          Actionable Tasks (Click to Complete & Boost Progress):
                        </span>
                        {milestone.tasks.map((task) => (
                          <div
                            key={task.id}
                            onClick={() => handleToggleTask(mIdx, task.id)}
                            className={`roadmap-task-item ${task.is_completed ? 'completed' : ''}`}
                          >
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                              {task.is_completed ? (
                                <CheckCircle2 size={18} color="var(--accent-emerald)" />
                              ) : (
                                <Circle size={18} color="var(--text-muted)" />
                              )}
                              <div>
                                <span style={{
                                  fontSize: '0.84rem',
                                  fontWeight: 600,
                                  color: task.is_completed ? 'var(--accent-emerald)' : 'var(--text-primary)',
                                  textDecoration: task.is_completed ? 'line-through' : 'none'
                                }}>
                                  {task.title}
                                </span>
                                <p style={{ fontSize: '0.74rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                                  {task.description}
                                </p>
                              </div>
                            </div>
                            <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontWeight: 600, flexShrink: 0 }}>
                              ~{task.estimated_hours} hrs
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Practical Project Deliverable Showcase */}
                    {(milestone.practical_project || milestone.suggested_project) && (
                      <div className="action-guide-box" style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '0.4rem',
                        background: 'rgba(16, 185, 129, 0.06)',
                        border: '1px solid rgba(16, 185, 129, 0.25)'
                      }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                          <FolderGit2 size={18} color="var(--accent-emerald)" />
                          <span style={{ fontSize: '0.72rem', fontWeight: 800, color: 'var(--accent-emerald)', textTransform: 'uppercase' }}>
                            Hands-on Portfolio Capstone / Tangible Deliverable:
                          </span>
                        </div>
                        <p style={{ fontSize: '0.84rem', fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>
                          {milestone.practical_project || milestone.suggested_project}
                        </p>
                        {milestone.deliverable && (
                          <div style={{ fontSize: '0.76rem', color: 'var(--accent-emerald)', fontWeight: 600, marginTop: '0.2rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                            <Check size={13} /> Deliverable: {milestone.deliverable}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}

          {/* Placement & Internship Intelligence Pack (Global) */}
          {roadmap.placement_destination && (
            <div className="glass-card" style={{ padding: '1.5rem', border: '1.5px solid var(--accent-purple)55' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                  <Award size={20} color="var(--accent-purple)" />
                  <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                    Placement & Internship Intelligence Pack
                  </h3>
                </div>
                <span className="badge badge-purple">
                  {roadmap.placement_destination.expected_salary_range}
                </span>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.25rem', marginBottom: '1.25rem' }}>
                {/* Target Entry Roles */}
                <div>
                  <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', display: 'block', marginBottom: '0.5rem' }}>
                    Target Entry Job Titles:
                  </span>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                    {roadmap.placement_destination.target_entry_roles.map((role, rIdx) => (
                      <span key={rIdx} style={{ background: 'rgba(168, 85, 247, 0.12)', border: '1px solid rgba(168, 85, 247, 0.3)', color: 'var(--accent-purple)', padding: '0.3rem 0.7rem', borderRadius: '6px', fontSize: '0.75rem', fontWeight: 600 }}>
                        🎯 {role}
                      </span>
                    ))}
                  </div>
                </div>

                {/* ATS Keywords */}
                <div>
                  <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', display: 'block', marginBottom: '0.5rem' }}>
                    Top Resume ATS Keywords (Click to Copy):
                  </span>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                    {roadmap.placement_destination.ats_keywords.map((kw, kIdx) => (
                      <button
                        key={kIdx}
                        type="button"
                        onClick={() => handleCopyText(kw, 'keyword')}
                        style={{
                          background: copiedKeyword === kw ? '#10b98122' : 'rgba(56, 189, 248, 0.08)',
                          border: copiedKeyword === kw ? '1px solid #10b981' : '1px solid rgba(56, 189, 248, 0.25)',
                          color: copiedKeyword === kw ? '#10b981' : 'var(--accent-cyan)',
                          padding: '0.25rem 0.65rem',
                          borderRadius: '6px',
                          fontSize: '0.72rem',
                          fontWeight: 600,
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.3rem'
                        }}
                      >
                        {copiedKeyword === kw ? <Check size={12} /> : <Copy size={12} />}
                        <span>{kw}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* STAR Bullet Example */}
              {roadmap.placement_destination.star_bullet_examples.length > 0 && (
                <div style={{ padding: '0.9rem 1.1rem', background: 'rgba(255,255,255,0.02)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
                    <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase' }}>
                      Recommended Resume STAR Bullet Formula:
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopyText(roadmap.placement_destination!.star_bullet_examples[0], 'STAR bullet')}
                      className="btn btn-ghost btn-sm"
                      style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                    >
                      <Copy size={12} /> Copy Bullet
                    </button>
                  </div>
                  <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                    "{roadmap.placement_destination.star_bullet_examples[0]}"
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ==================================================================== */}
      {/* Good Projects & Step-by-Step Build Roadmaps (Below Placement Roadmap) */}
      {/* ==================================================================== */}
      <GoodProjectsRoadmapSection
        activeStream={activeStreamFilter}
        selectedCoDomain={selectedCoDomain}
        onSelectCoDomain={(coDomainName, stream) => handleSelectCoDomain(coDomainName, stream)}
        availableCoDomains={availableCoDomains}
        onScrollToPlacementRoadmap={() => {
          const el = document.getElementById('placement-roadmap-section');
          if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        }}
      />
    </div>
  );
};
