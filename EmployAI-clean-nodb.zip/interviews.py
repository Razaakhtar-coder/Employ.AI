from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.dependencies import get_db, get_optional_current_user, get_current_user, require_premium_user
from app.models.user import User
from app.schemas.interview import (
    InterviewStartRequest, InterviewSessionResponse, SubmitAnswerRequest,
    QuestionEvaluationResponse, InterviewCompleteRequest, InterviewHistoryResponse
)
from app.services.interview_service import InterviewService

router = APIRouter(prefix="/interviews", tags=["AI Mock Interview Simulator"])


@router.post("/start", response_model=InterviewSessionResponse, status_code=status.HTTP_201_CREATED)
def start_interview_session(
    request: InterviewStartRequest,
    current_user: User = Depends(require_premium_user),
    db: Session = Depends(get_db)
):
    """
    Initialize a new AI Mock Interview session grounded in the candidate's actual resume facts.
    Generates tailored technical, project deep-dive, and STAR behavioral questions.
    """
    try:
        session_resp = InterviewService.start_session(db, current_user, request)
        return session_resp
    except Exception as e:
        print(f"[ERROR] Failed to start interview session: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate interview session: {str(e)}"
        )


@router.get("/history", response_model=InterviewHistoryResponse)
def get_interview_history(
    current_user: User = Depends(require_premium_user),
    db: Session = Depends(get_db)
):
    """
    Retrieve candidate's historical interview scores, performance progression trends, and category averages.
    """
    return InterviewService.get_user_history(db, current_user)


@router.get("/active-resume")
def get_active_resume_facts(
    current_user: Optional[User] = Depends(get_optional_current_user),
    db: Session = Depends(get_db)
):
    """
    Retrieve candidate's active parsed resume facts (skills, projects, experiences, education) for interview grounding.
    """
    user_id = current_user.id if current_user else None
    student_profile_id = current_user.student_profile.id if (current_user and current_user.student_profile) else None
    return InterviewService._extract_resume_facts(db, user_id, student_profile_id, None)


@router.get("/{session_id}", response_model=InterviewSessionResponse)
def get_interview_session(
    session_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Retrieve full details, questions, and scores of a specific interview session.
    Strictly enforces object-level authorization (candidate ownership).
    """
    from app.models.interview import InterviewSession
    from app.core.dependencies import ADMIN_EMAIL
    session_orm = db.query(InterviewSession).filter(InterviewSession.id == session_id).first()
    if not session_orm:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Interview session not found.")

    is_admin = current_user.email.strip().lower() == ADMIN_EMAIL.lower()
    if not is_admin and session_orm.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden: You cannot access another candidate's interview session.")

    session = InterviewService.get_session(db, session_id)
    return session


@router.post("/{session_id}/answer", response_model=QuestionEvaluationResponse)
def submit_question_answer(
    session_id: str,
    request: SubmitAnswerRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Submit and evaluate a single question answer in real-time.
    Provides immediate score (0-100), STAR breakdown, positive strengths, and improvement suggestions.
    Strictly enforces object-level authorization (candidate ownership).
    """
    from app.models.interview import InterviewSession
    from app.core.dependencies import ADMIN_EMAIL
    session_orm = db.query(InterviewSession).filter(InterviewSession.id == session_id).first()
    if not session_orm:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Interview session not found.")

    is_admin = current_user.email.strip().lower() == ADMIN_EMAIL.lower()
    if not is_admin and session_orm.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden: You cannot submit answers to another candidate's interview session.")

    try:
        return InterviewService.submit_answer(
            db=db,
            session_id=session_id,
            question_id=request.question_id,
            user_answer=request.user_answer,
            audio_duration_seconds=request.audio_duration_seconds or 0
        )
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(ve))
    except Exception as e:
        print(f"[ERROR] Failed to evaluate question answer: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to evaluate answer: {str(e)}"
        )


@router.post("/{session_id}/complete", response_model=InterviewSessionResponse)
def complete_interview_session(
    session_id: str,
    request: Optional[InterviewCompleteRequest] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Finalize an interview session, compute final scores, persist marks in database, and generate comprehensive scorecard.
    Strictly enforces object-level authorization (candidate ownership).
    """
    from app.models.interview import InterviewSession
    from app.core.dependencies import ADMIN_EMAIL
    session_orm = db.query(InterviewSession).filter(InterviewSession.id == session_id).first()
    if not session_orm:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Interview session not found.")

    is_admin = current_user.email.strip().lower() == ADMIN_EMAIL.lower()
    if not is_admin and session_orm.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden: You cannot complete another candidate's interview session.")

    try:
        duration = request.duration_seconds if request else 0
        return InterviewService.complete_session(db, session_id, duration)
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(ve))
    except Exception as e:
        print(f"[ERROR] Failed to complete interview session: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to finalize interview: {str(e)}"
        )


@router.delete("/{session_id}", status_code=status.HTTP_200_OK)
def delete_interview_session(
    session_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Delete a specific interview session from candidate history.
    """
    success = InterviewService.delete_session(db, session_id, current_user)
    if not success:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Interview session not found or unauthorized.")
    return {"message": "Interview session deleted successfully", "id": session_id}
