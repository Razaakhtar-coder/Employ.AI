import unittest
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient

from app.main import app
from app.core.database import SessionLocal
from app.models.user import User

client = TestClient(app)


class TestGoogleOAuthIntegration(unittest.TestCase):
    def setUp(self):
        self.db = SessionLocal()

    def tearDown(self):
        self.db.close()

    @patch("app.services.auth_service.requests.get")
    def test_google_1click_oauth_success(self, mock_get):
        """Official Google ID token should verify via Google tokeninfo and authenticate without password."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "iss": "https://accounts.google.com",
            "sub": "google_sub_123456789",
            "email": "verified_student@gmail.com",
            "email_verified": "true",
            "name": "Verified Google Student",
            "picture": "https://lh3.googleusercontent.com/test_avatar.jpg",
            "aud": "mock-client-id.apps.googleusercontent.com"
        }
        mock_get.return_value = mock_resp

        # Send ID token to /api/v1/auth/google
        res = client.post("/api/v1/auth/google", json={
            "id_token": "valid_google_signed_jwt_token_here",
            "role": "student"
        })

        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("access_token", data)
        self.assertEqual(data["email"], "verified_student@gmail.com")
        self.assertEqual(data["full_name"], "Verified Google Student")
        self.assertEqual(data["avatar_url"], "https://lh3.googleusercontent.com/test_avatar.jpg")

    def test_google_config_endpoint(self):
        """GET /api/v1/auth/google/config returns public configuration for GSI SDK."""
        res = client.get("/api/v1/auth/google/config")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("client_id", data)
        self.assertIn("configured", data)

    def test_fallback_unregistered_email_shows_404_not_silent_signup(self):
        """If user enters unregistered Gmail on Sign In (isRegister=False), do NOT silently create account."""
        res = client.post("/api/v1/auth/google", json={
            "email": "unregistered_random_user_9999@gmail.com",
            "password": "Password123!",
            "isRegister": False
        })
        self.assertEqual(res.status_code, 404)
        self.assertIn("No Employ.AI account found", res.json().get("detail", ""))

    def test_fallback_create_account_mode_registers_successfully(self):
        """When isRegister=True, explicit registration creates the account."""
        import uuid
        unique_email = f"new_signup_{uuid.uuid4().hex[:6]}@gmail.com"
        res = client.post("/api/v1/auth/google", json={
            "email": unique_email,
            "password": "SecurePassword123!",
            "full_name": "New Registered Student",
            "isRegister": True
        })
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["email"], unique_email)
        self.assertEqual(data["full_name"], "New Registered Student")


if __name__ == "__main__":
    unittest.main()
