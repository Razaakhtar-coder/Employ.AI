import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { HologramThemeProvider } from './context/HologramThemeContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { BrandLogo } from './components/BrandLogo';
import { AuthModal } from './components/AuthModal';
import { BackendStatusBanner } from './components/BackendStatusBanner';
import { SkillGalaxy3D } from './components/SkillGalaxy3D';
import { LivePlacementRadar } from './components/LivePlacementRadar';
import { ResumeAnalyzer } from './components/ResumeAnalyzer';
import { calculateATSScore, normalizeResumeForATS } from './services/atsScoring';
import { RoleMatchingView } from './components/RoleMatchingView';
import { RoadmapView } from './components/RoadmapView';
import { AcademiaPortal } from './components/AcademiaPortal';
import { OpportunitiesPortal } from './components/OpportunitiesPortal';
import { HologramScannerStage } from './components/HologramScannerStage';
import { ResumeLearningDashboard } from './components/ResumeLearningDashboard';
import { AIInterviewSimulator } from './components/AIInterviewSimulator';
import { Figma3DOverviewCanvas } from './components/Figma3DOverviewCanvas';
import { StudentOverviewHero3D } from './components/StudentOverviewHero3D';
import { AboutView } from './components/AboutView';
import { 
  matchingApi, roadmapApi, documentApi, profileApi, getUserScopedStorageKey, clearAllResumeStorage 
} from './services/api';
import type { 
  LearningRoadmap, ResumeAnalysisResult, CareerRole, StudentProfile 
} from './types';
import { 
  FileText, Compass, FolderGit2,
  ShieldCheck, BookMarked, BookOpen, Mic,
  Lock, Info, LogIn
} from 'lucide-react';

import { ErrorBoundary } from './components/ErrorBoundary';
import { PremiumSubscriptionModal } from './components/PremiumSubscriptionModal';
import { AdminPaymentsModal } from './components/AdminPaymentsModal';
import { LockedFeatureGate } from './components/LockedFeatureGate';


interface StudentOverviewProps {
  onNavigate: (tab: string) => void;
  onNavigateToRoadmap?: (roleTitleOrId?: string, domain?: string) => void;
}

interface OverviewDataCache {
  profile: StudentProfile | null;
  roadmap: LearningRoadmap | null;
  resume: ResumeAnalysisResult | null;
  topRole: CareerRole | null;
  timestamp: number;
}
let cachedOverview: OverviewDataCache | null = null;

if (typeof window !== 'undefined') {
  if (window.location.search && !window.location.search.includes('job=') && !window.location.search.includes('tab=')) {
    window.history.replaceState({}, document.title, window.location.pathname);
  }
  window.addEventListener('employai:resume-updated', (e: any) => {
    cachedOverview = null;
    if (e?.detail === null) {
      clearAllResumeStorage();
    }
  });
  window.addEventListener('employai:user-switched', () => {
    cachedOverview = null;
  });
}

const StudentOverviewComponent: React.FC<StudentOverviewProps> = ({ onNavigate, onNavigateToRoadmap }) => {
  const { user, isAuthenticated } = useAuth();
  const [profile, setProfile] = useState<StudentProfile | null>(() => cachedOverview?.profile || null);
  const [roadmap, setRoadmap] = useState<LearningRoadmap | null>(() => cachedOverview?.roadmap || null);
  const [resume, setResume] = useState<ResumeAnalysisResult | null>(() => {
    try {
      const key = getUserScopedStorageKey('employai_active_resume_analysis');
      const saved = localStorage.getItem(key) || localStorage.getItem('employai_active_resume_analysis');
      if (saved) return JSON.parse(saved);
      return null;
    } catch {}
    return null;
  });
  const [topRole, setTopRole] = useState<CareerRole | null>(() => cachedOverview?.topRole || null);

  useEffect(() => {
    const handleResumeSync = (e: any) => {
      cachedOverview = null;
      if (e?.detail === null) {
        setResume(null);
      } else if (e?.detail) {
        setResume(e.detail);
      }
    };
    const handleStorage = () => {
      const key = getUserScopedStorageKey('employai_active_resume_analysis');
      const saved = localStorage.getItem(key) || localStorage.getItem('employai_active_resume_analysis');
      if (!saved) {
        setResume(null);
        cachedOverview = null;
      } else {
        try {
          setResume(JSON.parse(saved));
        } catch {}
      }
    };
    window.addEventListener('employai:resume-updated', handleResumeSync);
    window.addEventListener('storage', handleStorage);
    return () => {
      window.removeEventListener('employai:resume-updated', handleResumeSync);
      window.removeEventListener('storage', handleStorage);
    };
  }, []);

  useEffect(() => {
    const handleRoadmapSync = (e: any) => {
      cachedOverview = null;
      if (e?.detail?.completionPct !== undefined) {
        setRoadmap(prev => prev ? { ...prev, completion_pct: e.detail.completionPct } : prev);
      }
    };
    window.addEventListener('employai:roadmap-progress-updated', handleRoadmapSync);
    return () => window.removeEventListener('employai:roadmap-progress-updated', handleRoadmapSync);
  }, []);

  useEffect(() => {
    let isMounted = true;
    async function loadStudentOverview() {
      // If cached recently (< 60s), avoid re-fetching on rapid tab navigation
      if (cachedOverview && Date.now() - cachedOverview.timestamp < 60000) {
        const key = getUserScopedStorageKey('employai_active_resume_analysis');
        const saved = localStorage.getItem(key) || localStorage.getItem('employai_active_resume_analysis');
        if (cachedOverview.resume && !saved) {
          cachedOverview = null;
        } else {
          return;
        }
      }
      try {
        const [roles, prof, activeRoadmap, latestResume] = await Promise.all([
          matchingApi.getRoles().catch(() => []),
          isAuthenticated ? profileApi.getStudentMe().catch(() => null) : Promise.resolve(null),
          isAuthenticated ? roadmapApi.getActiveRoadmap().catch(() => null) : Promise.resolve(null),
          documentApi.getLatestAnalysis().catch(() => null)
        ]);

        if (!isMounted) return;

        setProfile(prof);
        setRoadmap(activeRoadmap);
        setResume(latestResume || null);
        if (!latestResume) {
          if (cachedOverview) {
            cachedOverview.resume = null;
          }
        }

        // Dynamically select best matching role based on candidate's real resume skills & field
        let selectedTopRole = roles[0] || null;
        if (roles && roles.length > 0) {
          const candidateSkills = new Set<string>();
          (latestResume?.structured_resume?.skills || latestResume?.extracted_skills || []).forEach(s => candidateSkills.add(s.toLowerCase().trim()));
          (prof?.skills || []).forEach(s => candidateSkills.add(s.skill_name.toLowerCase().trim()));
          const headline = (
            latestResume?.structured_resume?.personal_info?.headline || 
            latestResume?.structured_resume?.headline || 
            latestResume?.structured_resume?.personal_info?.title || 
            latestResume?.structured_resume?.title || 
            ''
          ).toLowerCase();
          const resumeDomain = (latestResume?.detected_domain || prof?.department || '').toLowerCase();

          let bestScore = -1;
          roles.forEach(r => {
            let score = 0;
            const rTitle = (r.title || '').toLowerCase();
            const rDomain = (r.domain || '').toLowerCase();

            if (headline && (rTitle.includes(headline) || headline.includes(rTitle))) score += 12;
            if (resumeDomain && (rDomain.includes(resumeDomain) || resumeDomain.includes(rDomain))) score += 5;

            // Penalty if role is Fullstack but candidate headline or skills indicate AI/ML or Software Developer
            if ((rTitle.includes('fullstack') || rTitle.includes('full stack')) && 
                (headline.includes('software developer') || headline.includes('ai') || headline.includes('machine learning') || candidateSkills.has('machine learning') || candidateSkills.has('python'))) {
              score -= 10;
            }

            (r.skills || []).forEach(rs => {
              if (candidateSkills.has(rs.skill_name.toLowerCase().trim())) {
                score += rs.is_required ? 3 : 1.5;
              }
            });

            if (score > bestScore) {
              bestScore = score;
              selectedTopRole = r;
            }
          });
        }
        setTopRole(selectedTopRole);
        cachedOverview = {
          profile: prof,
          roadmap: activeRoadmap,
          resume: latestResume,
          topRole: selectedTopRole,
          timestamp: Date.now()
        };
      } catch (err) {
        console.warn('Failed to load overview data:', err);
      }
    }

    loadStudentOverview();
    return () => { isMounted = false; };
  }, [isAuthenticated]);

  // Exact candidate resume heading (e.g., Software Developer, AI/ML Engineer, etc.)
  const exactResumeHeading = useMemo(() => {
    // If no active resume is present, there is NO target heading from resume
    if (!resume) return null;

    // 1. Structured resume from state
    const struct = resume?.structured_resume;
    const headline = struct?.personal_info?.headline || 
                     struct?.headline || 
                     struct?.personal_info?.title || 
                     struct?.title ||
                     resume?.job_analysis?.target_job_title;
    if (headline && typeof headline === 'string' && headline.trim()) {
      return headline.trim();
    }

    // 2. Extracted experience roles (first/current role title)
    if (resume?.extracted_experience && resume.extracted_experience.length > 0) {
      const expRole = resume.extracted_experience[0]?.role;
      if (expRole && typeof expRole === 'string' && expRole.trim()) {
        return expRole.trim();
      }
    }

    // 3. If topRole is available AND does NOT say Fullstack / Full Stack, use it
    if (topRole?.title && !topRole.title.toLowerCase().includes('fullstack') && !topRole.title.toLowerCase().includes('full stack')) {
      return topRole.title;
    }

    // 4. Intelligent domain/skills deduction: if AI/ML skills present -> AI/ML Engineer, else Software Developer
    const candidateSkillsText = (
      (resume?.extracted_skills || []).concat(resume?.structured_resume?.skills || [])
    ).join(' ').toLowerCase();

    if (
      candidateSkillsText.includes('machine learning') || 
      candidateSkillsText.includes('deep learning') || 
      candidateSkillsText.includes('pytorch') || 
      candidateSkillsText.includes('tensorflow') || 
      candidateSkillsText.includes('artificial intelligence') ||
      candidateSkillsText.includes('ai/ml')
    ) {
      return 'AI/ML Engineer';
    }

    return 'Software Developer';
  }, [resume, topRole]);

  // Exact Live Resume ATS Score synchronized identically with AI Resume Studio
  const exactAtsScore = useMemo(() => {
    if (!resume) return null;
    const struct = normalizeResumeForATS(resume);
    const ats = calculateATSScore(struct, resume.resume_quality_score || 72);
    const score = ats.overall_score || Math.round(resume.resume_quality_score || 0);
    return score > 0 ? score : null;
  }, [resume]);

  // Dynamic Real Target Role Match percentage based on actual candidate skills
  const targetMatchPercentage = useMemo(() => {
    if (!resume || !topRole || !topRole.skills || topRole.skills.length === 0) return null;
    const candidateSkills = new Set<string>();
    const skillsList = resume?.structured_resume?.skills || resume?.extracted_skills || [];
    skillsList.forEach((s: any) => {
      const sName = typeof s === 'string' ? s : (s?.name || '');
      if (sName) candidateSkills.add(sName.toLowerCase().trim());
    });
    (profile?.skills || []).forEach((s: any) => {
      if (s?.skill_name) candidateSkills.add(s.skill_name.toLowerCase().trim());
    });

    const requiredSkills = topRole.skills.filter((s: any) => s.is_required);
    const pool = requiredSkills.length > 0 ? requiredSkills : topRole.skills;
    const matchedCount = pool.filter((s: any) => candidateSkills.has((s.skill_name || '').toLowerCase().trim())).length;
    return Math.round((matchedCount / pool.length) * 100);
  }, [resume, topRole, profile]);

  // Dynamically resolve candidate department / domain from user's uploaded resume
  const candidateDomain = useMemo(() => {
    if (!resume) {
      return profile?.department || profile?.target_domain || 'General Engineering';
    }

    // 1. Direct detected domain from latest resume analysis
    if (resume?.detected_domain && typeof resume.detected_domain === 'string' && resume.detected_domain.trim()) {
      const dd = resume.detected_domain.trim();
      if (dd.toLowerCase() !== 'general professional') {
        return dd;
      }
    }

    // 2. Structured resume education field of study or degree
    const eduList = resume?.structured_resume?.education || [];
    for (const edu of eduList) {
      if (edu?.field_of_study && typeof edu.field_of_study === 'string' && edu.field_of_study.trim()) {
        const fos = edu.field_of_study.trim();
        if (fos.length > 2) return fos;
      }
      if (edu?.degree && typeof edu.degree === 'string' && edu.degree.trim()) {
        const deg = edu.degree.trim();
        if (deg.length > 2) return deg;
      }
    }

    // 3. User-scoped localStorage check for active resume analysis / structured resume
    try {
      const userStr = localStorage.getItem('employai_auth_user');
      const userId = userStr ? JSON.parse(userStr)?.id : null;
      const key = userId ? `employai_active_resume_analysis_${userId}` : 'employai_active_resume_analysis';
      const raw = localStorage.getItem(key) || localStorage.getItem('employai_active_resume_analysis');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed?.detected_domain && typeof parsed.detected_domain === 'string' && parsed.detected_domain.trim()) {
          const pdd = parsed.detected_domain.trim();
          if (pdd.toLowerCase() !== 'general professional') return pdd;
        }
        const edu = parsed?.structured_resume?.education || [];
        for (const e of edu) {
          if (e?.field_of_study?.trim()) return e.field_of_study.trim();
          if (e?.degree?.trim()) return e.degree.trim();
        }
      }

      const structKey = userId ? `employai_active_structured_resume_${userId}` : 'employai_active_structured_resume';
      const rawStruct = localStorage.getItem(structKey) || localStorage.getItem('employai_active_structured_resume');
      if (rawStruct) {
        const parsedStruct = JSON.parse(rawStruct);
        const edu = parsedStruct?.education || [];
        for (const e of edu) {
          if (e?.field_of_study?.trim()) return e.field_of_study.trim();
          if (e?.degree?.trim()) return e.degree.trim();
        }
      }
    } catch {}

    // 4. Candidate headline or job target fallback from resume
    const candidateRole = resume?.structured_resume?.personal_info?.headline || 
                          resume?.structured_resume?.headline ||
                          resume?.structured_resume?.title ||
                          resume?.job_analysis?.target_job_title;
    if (candidateRole && typeof candidateRole === 'string' && candidateRole.trim()) {
      const cr = candidateRole.trim();
      if (!cr.toLowerCase().includes('candidate') && !cr.toLowerCase().includes('student')) {
        return cr;
      }
    }

    // 5. Fall back to profile department or target_domain if set and not generic default
    if (profile?.department && 
        profile.department.toLowerCase() !== 'computer science & engineering' && 
        profile.department.toLowerCase() !== 'computer science') {
      return profile.department;
    }
    if (profile?.target_domain && profile.target_domain.toLowerCase() !== 'computer science') {
      return profile.target_domain;
    }

    return profile?.department || profile?.target_domain || 'General Engineering';
  }, [resume, profile]);

  // Dynamically resolve institution from user's uploaded resume
  const candidateInstitution = useMemo(() => {
    const eduList = resume?.structured_resume?.education || [];
    for (const edu of eduList) {
      if (edu?.institution && typeof edu.institution === 'string' && edu.institution.trim()) {
        return edu.institution.trim();
      }
    }

    try {
      const userStr = localStorage.getItem('employai_auth_user');
      const userId = userStr ? JSON.parse(userStr)?.id : null;
      const key = userId ? `employai_active_resume_analysis_${userId}` : 'employai_active_resume_analysis';
      const raw = localStorage.getItem(key) || localStorage.getItem('employai_active_resume_analysis');
      if (raw) {
        const parsed = JSON.parse(raw);
        const edu = parsed?.structured_resume?.education || [];
        if (edu.length > 0 && edu[0]?.institution?.trim()) {
          return edu[0].institution.trim();
        }
      }
    } catch {}

    return profile?.institution_name || 'Academic Institution';
  }, [resume, profile]);

  const studentName = useMemo(() => {
    const resumeName = resume?.structured_resume?.personal_info?.full_name;
    if (resumeName && typeof resumeName === 'string' && resumeName.trim()) {
      return resumeName.trim();
    }
    return user?.full_name || 'Candidate';
  }, [resume, user]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Interactive 3D Real-Figure Animated Overview Workspace */}
      <StudentOverviewHero3D
        studentName={studentName}
        department={candidateDomain}
        institution={candidateInstitution}
        targetRoleTitle={resume ? exactResumeHeading : null}
        exactAtsScore={resume ? exactAtsScore : null}
        hasResume={Boolean(resume)}
        roadmapProgress={roadmap?.completion_pct}
        onNavigate={onNavigate}
        onNavigateToRoadmap={onNavigateToRoadmap}
      />

      {/* 3D Figma Canvas Overview Architecture Showcase */}
      <Figma3DOverviewCanvas 
        onNavigate={onNavigate}
        onNavigateToRoadmap={onNavigateToRoadmap}
      />

      {/* Main Row: Live Placement Radar Left + Skill Match Center + Upskilling Roadmap Right */}
      <div className="overview-main-grid">
        {/* Live Placement Radar Card */}
        <LivePlacementRadar 
          onNavigate={onNavigate}
          onNavigateToRoadmap={onNavigateToRoadmap}
          userDomain={candidateDomain}
        />

        {/* Skill Match Breakdown Card */}
        <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                Skill Alignment
              </h3>
              <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>
                AI Evaluated
              </span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', marginBottom: '1.25rem' }}>
              <div style={{
                width: '110px',
                height: '110px',
                borderRadius: '50%',
                background: resume 
                  ? `conic-gradient(var(--accent-cyan) 0% ${targetMatchPercentage ?? 75}%, var(--border-subtle) ${targetMatchPercentage ?? 75}% 100%)` 
                  : 'rgba(255, 255, 255, 0.02)',
                border: resume ? 'none' : '1.5px dashed var(--border-subtle)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: resume ? 'var(--glow-cyan)' : 'none',
                marginBottom: '0.6rem'
              }}>
                <div style={{
                  width: '90px',
                  height: '90px',
                  borderRadius: '50%',
                  backgroundColor: 'var(--bg-card)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  <span style={{ fontSize: '1.8rem', fontWeight: 800, color: resume ? 'var(--accent-cyan)' : 'var(--text-muted)', lineHeight: 1 }}>
                    {resume && topRole ? `${targetMatchPercentage ?? 75}%` : '--'}
                  </span>
                  <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)' }}>Target Match</span>
                </div>
              </div>

              <span style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                {resume ? (exactResumeHeading || topRole?.title || 'Software Developer') : 'No Resume Uploaded'}
              </span>
            </div>

            {/* Dynamic Skill Requirements List */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
              <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                Key Domain Requirements
              </span>
              {(topRole?.skills || []).slice(0, 3).map((rs, idx) => (
                <div key={idx}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '0.2rem' }}>
                    <span style={{ color: 'var(--text-secondary)' }}>{rs.skill_name}</span>
                    <span style={{ color: rs.is_required ? 'var(--accent-cyan)' : 'var(--accent-emerald)', fontWeight: 600 }}>
                      {rs.is_required ? 'Required Core' : 'Preferred'}
                    </span>
                  </div>
                  <div style={{ width: '100%', height: '5px', background: 'var(--border-subtle)', borderRadius: '3px', overflow: 'hidden' }}>
                    <div style={{ width: rs.is_required ? '85%' : '65%', height: '100%', background: rs.is_required ? 'var(--grad-primary)' : 'var(--grad-emerald)' }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button onClick={() => onNavigate('matching')} className="btn btn-outline-cyan btn-sm" style={{ width: '100%', marginTop: '1rem' }}>
            Explore Full Match Narrative →
          </button>
        </div>

        {/* AI-Generated Placement Level Roadmap Card */}
        <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Compass size={18} color="var(--accent-emerald)" />
                <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                  Placement Level Roadmap
                </h3>
              </div>
              <span className="badge badge-emerald" style={{ fontSize: '0.65rem' }}>
                {roadmap?.completion_pct || 0}% Done
              </span>
            </div>

            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '1rem' }}>
              {roadmap ? `Targeting ${roadmap.target_role_title} across 5 structured phases to placement.` : 'Personalized milestone plan to bridge identified industry skill gaps.'}
            </p>

            {roadmap && roadmap.milestones && roadmap.milestones.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {roadmap.milestones.slice(0, 2).map((m, idx) => (
                  <div key={idx} style={{ padding: '0.75rem', borderRadius: '8px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
                      <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>{m.week_range}</span>
                      <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                        {m.tasks.filter(t => t.is_completed).length}/{m.tasks.length} Tasks
                      </span>
                    </div>
                    <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-primary)', marginTop: '0.2rem' }}>
                      {m.focus_skill}
                    </h4>
                    <p style={{ fontSize: '0.725rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
                      {m.goal}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ padding: '1.25rem', textAlign: 'center', borderRadius: '8px', background: 'var(--bg-tertiary)', border: '1px dashed var(--border-subtle)' }}>
                <p style={{ fontSize: '0.775rem', color: 'var(--text-muted)' }}>No active roadmap generated yet.</p>
              </div>
            )}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.45rem', marginTop: '1rem' }}>
            <button onClick={() => onNavigate('roadmap')} className="btn btn-emerald btn-sm" style={{ width: '100%' }}>
              Open Placement Level Roadmap →
            </button>
            <button 
              onClick={() => {
                onNavigate('roadmap');
                setTimeout(() => {
                  const el = document.getElementById('good-projects-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 250);
              }} 
              className="btn btn-outline-cyan btn-sm" 
              style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.35rem', fontSize: '0.74rem', fontWeight: 700 }}
            >
              <FolderGit2 size={13} /> View Good Projects & Build Roadmaps →
            </button>
          </div>
        </div>
      </div>



      {/* AI Mock Interview Prep Room Banner */}
      <div 
        className="glass-card" 
        style={{ 
          padding: '1.5rem 1.75rem', 
          background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.08) 0%, rgba(168, 85, 247, 0.08) 100%)',
          border: '1px solid var(--border-glass)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '1.25rem'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{
            width: '46px',
            height: '46px',
            borderRadius: '12px',
            background: 'rgba(56, 189, 248, 0.15)',
            border: '1px solid var(--accent-cyan)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: 'var(--glow-cyan)'
          }}>
            <Mic size={22} color="var(--accent-cyan)" />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.2rem' }}>
              <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                AI MOCK INTERVIEW & VOICE PREP ROOM
              </h3>
              <span className="badge badge-cyan" style={{ fontSize: '0.65rem', fontWeight: 700 }}>
                <ShieldCheck size={12} /> Live Voice & STAR Scoring
              </span>
            </div>
            <p style={{ fontSize: '0.825rem', color: 'var(--text-muted)', margin: 0 }}>
              {resume 
                ? 'Practice real technical and STAR behavioral questions tailored to your resume, get evaluated out of 100, and track your score progression over time.' 
                : 'Upload your resume to defend your projects with personalized AI questions, or practice with standard role interviews.'}
            </p>
          </div>
        </div>

        <button 
          onClick={() => onNavigate('interview')} 
          className="btn btn-primary btn-sm"
          style={{ display: 'inline-flex', alignItems: 'center', gap: '0.45rem', fontWeight: 700, padding: '0.55rem 1.15rem' }}
        >
          <Mic size={15} /> Start AI Mock Interview →
        </button>
      </div>

      {/* Read & Learn My Resume Section (Directly Below Jobs & Internships) */}
      <div 
        className="glass-card role-hero-banner" 
        style={{ 
          padding: '1.75rem', 
          background: 'var(--grad-banner)',
          border: '1px solid var(--border-glass)',
          display: 'flex',
          flexDirection: 'column',
          gap: '1.25rem'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.35rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '32px', height: '32px', borderRadius: '8px', background: 'rgba(56, 189, 248, 0.15)', border: '1px solid var(--accent-cyan)' }}>
                <BookMarked size={18} color="var(--accent-cyan)" />
              </div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                READ & LEARN MY RESUME
              </h3>
              <span className="badge badge-cyan" style={{ fontSize: '0.65rem', fontWeight: 700 }}>
                <ShieldCheck size={12} /> Ground-Truth Study
              </span>
            </div>
            <p style={{ fontSize: '0.825rem', color: 'var(--text-muted)', margin: 0 }}>
              Understand every section, skill, project, and claim on your resume.
            </p>
          </div>

          <button 
            onClick={() => onNavigate('resume_learning')} 
            className="btn btn-primary btn-sm"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700, padding: '0.5rem 1rem' }}
          >
            <BookOpen size={14} /> Read & Learn Resume →
          </button>
        </div>

        {/* Quick Snapshot / Section Cards Grid Preview */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '0.85rem' }}>
          <div 
            onClick={() => onNavigate('resume_learning')}
            style={{ padding: '0.9rem 1rem', borderRadius: '8px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', cursor: 'pointer', transition: 'all 0.2s' }}
            onMouseEnter={(e) => { e.currentTarget.style.borderColor = 'var(--accent-cyan)'; e.currentTarget.style.background = 'var(--bg-card-hover)'; }}
            onMouseLeave={(e) => { e.currentTarget.style.borderColor = 'var(--border-subtle)'; e.currentTarget.style.background = 'var(--bg-tertiary)'; }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
              <span style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-primary)' }}>Skills & Tools</span>
              <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>{(resume?.extracted_skills || []).length} Verified</span>
            </div>
            <p style={{ fontSize: '0.725rem', color: 'var(--text-muted)', margin: 0, lineHeight: 1.4 }}>
              Study use cases, resume implications & interview talking points.
            </p>
          </div>

          <div 
            onClick={() => onNavigate('resume_learning')}
            style={{ padding: '0.9rem 1rem', borderRadius: '8px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', cursor: 'pointer', transition: 'all 0.2s' }}
            onMouseEnter={(e) => { e.currentTarget.style.borderColor = 'var(--accent-cyan)'; e.currentTarget.style.background = 'var(--bg-card-hover)'; }}
            onMouseLeave={(e) => { e.currentTarget.style.borderColor = 'var(--border-subtle)'; e.currentTarget.style.background = 'var(--bg-tertiary)'; }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
              <span style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-primary)' }}>Projects & Code</span>
              <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>{(resume?.extracted_projects || []).length} Projects</span>
            </div>
            <p style={{ fontSize: '0.725rem', color: 'var(--text-muted)', margin: 0, lineHeight: 1.4 }}>
              Understand architecture, technologies, and your exact contribution.
            </p>
          </div>

          <div 
            onClick={() => onNavigate('resume_learning')}
            style={{ padding: '0.9rem 1rem', borderRadius: '8px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', cursor: 'pointer', transition: 'all 0.2s' }}
            onMouseEnter={(e) => { e.currentTarget.style.borderColor = 'var(--accent-cyan)'; e.currentTarget.style.background = 'var(--bg-card-hover)'; }}
            onMouseLeave={(e) => { e.currentTarget.style.borderColor = 'var(--border-subtle)'; e.currentTarget.style.background = 'var(--bg-tertiary)'; }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
              <span style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-primary)' }}>Resume Claims</span>
              <span className="badge badge-emerald" style={{ fontSize: '0.65rem' }}>Truthful Prep</span>
            </div>
            <p style={{ fontSize: '0.725rem', color: 'var(--text-muted)', margin: 0, lineHeight: 1.4 }}>
              Deep dive into your claimed metrics, algorithms, and methodologies.
            </p>
          </div>
        </div>
      </div>

      {/* About Employ.AI Discovery Banner */}
      <div 
        onClick={() => onNavigate('about')}
        className="glass-card" 
        style={{ 
          padding: '1.25rem 1.75rem', 
          borderRadius: '16px',
          background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.08) 0%, rgba(16, 185, 129, 0.05) 100%)',
          border: '1px solid rgba(56, 189, 248, 0.22)',
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between',
          gap: '1rem',
          cursor: 'pointer',
          transition: 'all 0.2s ease',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{
            width: '42px',
            height: '42px',
            borderRadius: '12px',
            background: 'rgba(56, 189, 248, 0.15)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--accent-cyan)',
            flexShrink: 0
          }}>
            <Info size={22} />
          </div>
          <div>
            <div style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              About Employ.AI — Autonomous Placement Intelligence Engine
              <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>Platform Guide</span>
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
              Explore our 18+ academic domain roadmaps, deterministic ATS scoring, STAR AI voice mock interview studio, and institutional TPO tools.
            </div>
          </div>
        </div>
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onNavigate('about');
          }}
          className="btn btn-outline-cyan btn-sm" 
          style={{ whiteSpace: 'nowrap', display: 'flex', alignItems: 'center', gap: '0.4rem' }}
        >
          Explore Platform Architecture →
        </button>
      </div>
    </div>
  );
};

const StudentOverview = React.memo(StudentOverviewComponent);

const AuthGate: React.FC<{ onNavigate?: (tab: string) => void }> = ({ onNavigate }) => {
  const { openAuthModal } = useAuth();

  return (
    <div style={{
      minHeight: 'calc(100vh - 120px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2.5rem 1.25rem',
      position: 'relative',
      zIndex: 2,
      overflow: 'hidden'
    }}>
      {/* Ambient background light aura */}
      <div style={{
        position: 'absolute',
        top: '25%',
        left: '50%',
        transform: 'translate(-50%, -25%)',
        width: '650px',
        height: '400px',
        background: 'radial-gradient(circle, rgba(56, 189, 248, 0.15) 0%, rgba(168, 85, 247, 0.08) 50%, transparent 70%)',
        filter: 'blur(60px)',
        pointerEvents: 'none',
        zIndex: 1
      }} />

      <div 
        className="glass-card" 
        style={{
          maxWidth: '840px',
          width: '100%',
          padding: '3rem 2.5rem',
          borderRadius: '24px',
          border: '1px solid var(--border-subtle)',
          boxShadow: 'var(--shadow-modal)',
          background: 'var(--bg-card)',
          textAlign: 'center',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '2rem',
          position: 'relative',
          zIndex: 2,
          backdropFilter: 'blur(16px)'
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.85rem' }}>
          {/* Lock Emblem */}
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '20px',
            background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.15), rgba(168, 85, 247, 0.15))',
            border: '1px solid var(--border-glass)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: 'var(--glow-cyan)'
          }}>
            <Lock size={28} color="var(--accent-cyan)" />
          </div>

          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem', marginBottom: '0.65rem' }}>
              <span className="badge badge-cyan" style={{ fontSize: '0.75rem', fontWeight: 700, padding: '0.25rem 0.75rem', borderRadius: '9999px' }}>
                <ShieldCheck size={13} /> Sign in with Google
              </span>
            </div>

            {/* Title with App Logo */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.85rem', flexWrap: 'wrap' }}>
              <h1 style={{ 
                fontSize: 'clamp(1.75rem, 4vw, 2.35rem)', 
                fontWeight: 900, 
                color: 'var(--text-primary)', 
                margin: 0, 
                letterSpacing: '-0.025em',
                lineHeight: 1.2
              }}>
                WELCOME TO EMPLOY<span style={{ color: 'var(--accent-cyan)' }}>.AI</span>
              </h1>
              <div style={{ display: 'inline-flex', alignItems: 'center', flexShrink: 0 }}>
                <BrandLogo size={40} showText={false} showBadge={false} animated={true} />
              </div>
            </div>

            <p style={{ 
              fontSize: '0.95rem', 
              color: 'var(--text-secondary)', 
              maxWidth: '600px', 
              margin: '0.85rem auto 0 auto', 
              lineHeight: 1.6,
              fontWeight: 500
            }}>
              Sign in with your Google Account to access your personal AI Career Workspace, AI Mock Interview Studio with live voice defense, and 3D Placement Galaxy.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', justifyContent: 'center', width: '100%' }}>
          <button
            onClick={() => openAuthModal()}
            className="btn btn-primary"
            style={{
              padding: '0.85rem 2.25rem',
              fontSize: '1rem',
              fontWeight: 800,
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.75rem',
              boxShadow: 'var(--glow-cyan)',
              cursor: 'pointer',
              borderRadius: '10px'
            }}
          >
            <LogIn size={18} />
            <span>Sign In / Get Started</span>
          </button>
          {onNavigate && (
            <button
              onClick={() => onNavigate('about')}
              className="btn btn-secondary"
              style={{
                padding: '0.85rem 1.85rem',
                fontSize: '0.95rem',
                fontWeight: 700,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                cursor: 'pointer'
              }}
            >
              <Info size={17} color="var(--accent-cyan)" /> About Employ.AI
            </button>
          )}
        </div>

        {/* Feature Highlights Grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: '1rem',
          width: '100%',
          marginTop: '0.5rem',
          textAlign: 'left'
        }}>
          <div style={{ 
            padding: '1.15rem', 
            borderRadius: '14px', 
            background: 'var(--bg-secondary)', 
            border: '1px solid var(--border-subtle)',
            boxShadow: 'var(--shadow-sm)',
            transition: 'transform 0.2s, box-shadow 0.2s'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.55rem', marginBottom: '0.4rem' }}>
              <div style={{
                width: '30px',
                height: '30px',
                borderRadius: '8px',
                background: 'rgba(56, 189, 248, 0.12)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <Mic size={16} color="var(--accent-cyan)" />
              </div>
              <strong style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                AI Mock Interview
              </strong>
            </div>
            <p style={{ fontSize: '0.775rem', color: 'var(--text-muted)', margin: 0, lineHeight: 1.5 }}>
              Live voice defense grounded strictly in your real uploaded resume projects, skills, and target domain.
            </p>
          </div>

          <div style={{ 
            padding: '1.15rem', 
            borderRadius: '14px', 
            background: 'var(--bg-secondary)', 
            border: '1px solid var(--border-subtle)',
            boxShadow: 'var(--shadow-sm)',
            transition: 'transform 0.2s, box-shadow 0.2s'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.55rem', marginBottom: '0.4rem' }}>
              <div style={{
                width: '30px',
                height: '30px',
                borderRadius: '8px',
                background: 'rgba(16, 185, 129, 0.12)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <FileText size={16} color="var(--accent-emerald)" />
              </div>
              <strong style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                AI Resume Studio
              </strong>
            </div>
            <p style={{ fontSize: '0.775rem', color: 'var(--text-muted)', margin: 0, lineHeight: 1.5 }}>
              Real-time ATS scoring, multi-domain keyword optimization, and structured version management.
            </p>
          </div>

          <div style={{ 
            padding: '1.15rem', 
            borderRadius: '14px', 
            background: 'var(--bg-secondary)', 
            border: '1px solid var(--border-subtle)',
            boxShadow: 'var(--shadow-sm)',
            transition: 'transform 0.2s, box-shadow 0.2s'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.55rem', marginBottom: '0.4rem' }}>
              <div style={{
                width: '30px',
                height: '30px',
                borderRadius: '8px',
                background: 'rgba(168, 85, 247, 0.12)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <Compass size={16} color="var(--accent-purple)" />
              </div>
              <strong style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                Placement Roadmap
              </strong>
            </div>
            <p style={{ fontSize: '0.775rem', color: 'var(--text-muted)', margin: 0, lineHeight: 1.5 }}>
              AI-generated milestone roadmaps to bridge skill gaps and accelerate placement readiness.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const MainContent: React.FC = () => {
  const { 
    isAuthenticated, isLoading, activeRole,
    isPremium, isAdmin, openAuthModal,
    isSubscriptionModalOpen, closeSubscriptionModal,
    isAdminPaymentsModalOpen, closeAdminPaymentsModal
  } = useAuth();

  const hasAutoOpenedAuthRef = React.useRef(false);
  React.useEffect(() => {
    if (!isAuthenticated && !isLoading && !hasAutoOpenedAuthRef.current) {
      hasAutoOpenedAuthRef.current = true;
      openAuthModal();
    }
  }, [isAuthenticated, isLoading, openAuthModal]);
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth >= 1024;
    }
    return false;
  });

  // Responsive resize handler for sidebar: only update when crossing the mobile/desktop breakpoint
  React.useEffect(() => {
    let prevIsDesktop = typeof window !== 'undefined' ? window.innerWidth >= 1024 : true;
    const handleResize = () => {
      const isDesktop = window.innerWidth >= 1024;
      if (prevIsDesktop && !isDesktop) {
        setIsSidebarOpen(false);
      } else if (!prevIsDesktop && isDesktop) {
        setIsSidebarOpen(true);
      }
      prevIsDesktop = isDesktop;
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  const [currentTab, setCurrentTab] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      try {
        const params = new URLSearchParams(window.location.search);
        if (params.get('job') || params.get('tab') === 'opportunities' || window.location.hash.startsWith('#job-')) {
          return 'opportunities';
        }
        const tabParam = params.get('tab');
        if (tabParam) return tabParam;
      } catch {}
    }
    if (activeRole === 'academia') return 'academia_overview';
    return 'dashboard';
  });


  // Target role state passed to RoadmapView from Field Explorer, Skill Galaxy, or Role Matching
  const [targetRoadmapRole, setTargetRoadmapRole] = useState<{ roleId?: string; roleTitle?: string; domain?: string } | null>(null);

  const handleToggleSidebar = useCallback(() => {
    setIsSidebarOpen(prev => !prev);
  }, []);

  const handleCloseSidebar = useCallback(() => {
    setIsSidebarOpen(false);
  }, []);

  const handleNavigate = useCallback((tab: string) => {
    React.startTransition(() => {
      setCurrentTab(tab);
    });
  }, []);

  const handleNavigateToRoadmap = useCallback((roleTitleOrId?: string, domain?: string) => {
    React.startTransition(() => {
      if (roleTitleOrId || domain) {
        setTargetRoadmapRole({ roleTitle: roleTitleOrId, domain });
      }
      setCurrentTab('roadmap');
    });
  }, []);

  const handleClearTargetRoadmapRole = useCallback(() => {
    setTargetRoadmapRole(null);
  }, []);

  // Sync tab if user role changes - always land on student dashboard
  React.useEffect(() => {
    if (activeRole === 'academia') {
      setCurrentTab('academia_overview');
    } else {
      setCurrentTab('dashboard');
    }
  }, [activeRole]);

  if (isLoading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-primary)' }}>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem' }}>
          <div className="spinner-border" style={{ width: '36px', height: '36px', color: 'var(--accent-cyan)' }} />
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>Initializing secure workspace...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="app-container" style={{ position: 'relative', minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
        <BackendStatusBanner />
        <Header 
          onToggleSidebar={handleToggleSidebar} 
          isSidebarOpen={isSidebarOpen} 
          onNavigate={handleNavigate}
          currentTab={currentTab}
        />
        <AuthModal />
        {currentTab === 'about' ? (
          <main className="content-area" id="main-content-scroll-area" style={{ flex: 1, padding: '2rem 1.5rem', overflowY: 'auto' }}>
            <div style={{ maxWidth: '1280px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
                <button 
                  onClick={() => setCurrentTab('dashboard')} 
                  className="btn btn-outline-cyan btn-sm"
                  style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}
                >
                  ← Back to Sign In
                </button>
              </div>
              <AboutView 
                onNavigate={handleNavigate} 
                onNavigateToRoadmap={handleNavigateToRoadmap} 
              />
            </div>
          </main>
        ) : (
          <AuthGate onNavigate={handleNavigate} />
        )}
      </div>
    );
  }

  return (
    <div className="app-container" style={{ position: 'relative', minHeight: '100vh', height: '100dvh', maxHeight: '100dvh', display: 'flex', flexDirection: 'column' }}>
      <BackendStatusBanner />
      <Header 
        onToggleSidebar={handleToggleSidebar} 
        isSidebarOpen={isSidebarOpen} 
        onNavigate={handleNavigate}
        currentTab={currentTab}
      />
      <AuthModal />
      <PremiumSubscriptionModal 
        isOpen={isSubscriptionModalOpen} 
        onClose={closeSubscriptionModal} 
      />
      {isAdmin && (
        <AdminPaymentsModal 
          isOpen={isAdminPaymentsModalOpen} 
          onClose={closeAdminPaymentsModal} 
        />
      )}
      <div className="main-layout" style={{ position: 'relative', zIndex: 2, flex: 1, minHeight: 0, display: 'flex', overflow: 'hidden' }}>
        <Sidebar 
          currentTab={currentTab} 
          setCurrentTab={handleNavigate} 
          isOpen={isSidebarOpen}
          onClose={handleCloseSidebar}
        />
        <main className="content-area" id="main-content-scroll-area">
          <ErrorBoundary fallbackTitle="View Failed to Load">
            {/* Student Workflows */}
            {activeRole !== 'academia' && (
              <>
                {currentTab === 'dashboard' && (
                  <StudentOverview 
                    onNavigate={handleNavigate} 
                    onNavigateToRoadmap={handleNavigateToRoadmap} 
                  />
                )}

                {currentTab === 'interview' && (
                  !isPremium && !isAdmin ? (
                    <LockedFeatureGate 
                      sectionName="AI Mock Interview Simulator" 
                      sectionSubtitle="Real-time multi-agent mock interviews with voice interaction, STAR method scoring, and adaptive AI feedback."
                      features={[
                        'Interactive Voice & Audio-Based Mock Interviews with Speech Synthesis',
                        'Real-time STAR Technique (Situation, Task, Action, Result) Evaluation',
                        'Adaptive Technical & Behavioral Question Generation',
                        'Detailed Performance Metrics, Audio Transcripts & Actionable Improvements'
                      ]}
                    />
                  ) : (
                    <AIInterviewSimulator onNavigateToResume={() => handleNavigate('resume')} />
                  )
                )}

                {currentTab === 'scanner3d' && (
                  <HologramScannerStage 
                    onNavigateToResume={() => handleNavigate('resume')}
                    onNavigateToRoadmap={() => handleNavigateToRoadmap()}
                  />
                )}

                {currentTab === 'galaxy' && (
                  <SkillGalaxy3D onNavigateToRoadmap={handleNavigateToRoadmap} />
                )}

                <div style={{ 
                  display: currentTab === 'resume' ? 'block' : 'none', 
                  width: '100%', 
                  minWidth: 0,
                  contentVisibility: currentTab === 'resume' ? 'visible' : 'hidden'
                }}>
                  <ResumeAnalyzer onNavigate={handleNavigate} />
                </div>

                {currentTab === 'matching' && (
                  <RoleMatchingView 
                    onNavigateToRoadmap={handleNavigateToRoadmap} 
                    onNavigateToResume={() => setCurrentTab('resume')} 
                  />
                )}

                {currentTab === 'roadmap' && (
                  !isPremium && !isAdmin ? (
                    <LockedFeatureGate 
                      sectionName="Placement Level 6-Week Roadmap" 
                      sectionSubtitle="Personalized curriculum across 5 structured phases bridging skill gaps to secure your target role."
                      features={[
                        'Personalized 6-Week Milestone Plan with Progress Tracking',
                        'Curated Capstone Flagship Projects & GitHub Deliverables',
                        'Role-Specific Technical Skill Drills & Resource Guides',
                        'Interactive Task Checklists & Practice Labs'
                      ]}
                    />
                  ) : (
                    <RoadmapView 
                      targetRoleParam={targetRoadmapRole} 
                      onClearTargetRole={handleClearTargetRoadmapRole} 
                    />
                  )
                )}

                {currentTab === 'opportunities' && (
                  !isPremium && !isAdmin ? (
                    <LockedFeatureGate 
                      sectionName="Jobs & Internships Portal" 
                      sectionSubtitle="Real-time multi-provider job aggregator with automated candidate match scoring and direct apply."
                      features={[
                        'Real-Time Job Aggregation across 10+ Tech Provider Platforms',
                        'AI Candidate Fit Scoring & Explainable Match Breakdown',
                        'Direct ATS-Compliant Application Pipeline',
                        'Curated Low-Competition Startup Opportunities & Internships'
                      ]}
                    />
                  ) : (
                    <OpportunitiesPortal onNavigate={handleNavigate} />
                  )
                )}

                {currentTab === 'resume_learning' && (
                  <ResumeLearningDashboard onNavigateToResume={() => handleNavigate('resume')} />
                )}
              </>
            )}

            {/* Academia Tabs */}
            {activeRole === 'academia' && (
              <AcademiaPortal activeTab={currentTab} />
            )}

            {/* About Employ.AI Platform View */}
            {currentTab === 'about' && (
              <AboutView 
                onNavigate={handleNavigate} 
                onNavigateToRoadmap={handleNavigateToRoadmap} 
              />
            )}
          </ErrorBoundary>
        </main>
      </div>
    </div>
  );
};

export function App() {
  return (
    <AuthProvider>
      <HologramThemeProvider>
        <MainContent />
      </HologramThemeProvider>
    </AuthProvider>
  );
}

export default App;
