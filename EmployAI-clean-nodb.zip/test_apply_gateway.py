import os
import sys
import uuid
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fastapi.testclient import TestClient
from app.core.database import Base, engine, SessionLocal
from app.main import app
from app.models.job import JobPosting
from app.services.job_aggregator_service import JobAggregatorService
from app.services.job_normalization_service import JobNormalizationService

Base.metadata.create_all(bind=engine)
client = TestClient(app)


def test_apply_gateway_and_self_healing():
    db = SessionLocal()
    JobAggregatorService.ensure_initial_seed(db)

    # 1. Create a test job with a broken dummy link
    unique_slug = uuid.uuid4().hex[:8]
    test_job = JobPosting(
        source="Cutshort",
        source_id=f"test-gateway-{unique_slug}",
        title="Senior Distributed Systems Architect",
        company="Global Cloud Corp",
        location="Remote",
        remote=True,
        job_type="full-time",
        domain="Computer Science",
        description="Design high-throughput distributed systems.",
        required_skills_json=["Go", "Kubernetes", "Distributed Systems"],
        apply_url="https://non-existent-domain-12345-employai.com/404-role",
        is_active=True
    )
    db.add(test_job)
    db.commit()
    db.refresh(test_job)
    job_id = test_job.id

    # 2. Test apply-redirect with format=json
    resp_json = client.get(f"/api/v1/jobs/{job_id}/apply-redirect?format=json")
    assert resp_json.status_code == 200, f"Expected 200, got {resp_json.status_code}"
    data = resp_json.json()
    assert "target_url" in data
    assert data["target_url"].startswith("http")
    print(f"[TEST PASS] Smart Apply Gateway resolved target: {data['target_url']}")

    # 3. Test apply-redirect 302 redirect
    resp_redirect = client.get(f"/api/v1/jobs/{job_id}/apply-redirect", follow_redirects=False)
    assert resp_redirect.status_code == 302, f"Expected 302, got {resp_redirect.status_code}"
    assert "location" in resp_redirect.headers
    print(f"[TEST PASS] Smart Apply Gateway 302 Redirect verified to: {resp_redirect.headers['location']}")

    # 4. Test report-broken endpoint
    resp_report = client.post(f"/api/v1/jobs/{job_id}/report-broken")
    assert resp_report.status_code == 200, f"Expected 200, got {resp_report.status_code}"
    rep_data = resp_report.json()
    assert rep_data["status"] == "success"
    assert "healed_url" in rep_data
    print(f"[TEST PASS] report-broken endpoint successfully healed link to: {rep_data['healed_url']}")

    # 5. Verify database was updated with the healed fallback URL
    db.refresh(test_job)
    assert "404-role" not in test_job.apply_url
    print(f"[TEST PASS] Database persisted healed apply_url: {test_job.apply_url}")

    # 6. Verify guaranteed fallback generator
    fallback = JobNormalizationService.get_guaranteed_fallback_url("InVideo", "WebGL Engineer", "Cutshort")
    assert "cutshort.io" in fallback or "google.com" in fallback
    print(f"[TEST PASS] Guaranteed fallback URL verified: {fallback}")

    print("\n>>> All Production Reliability System tests PASSED successfully! <<<")


if __name__ == "__main__":
    test_apply_gateway_and_self_healing()
