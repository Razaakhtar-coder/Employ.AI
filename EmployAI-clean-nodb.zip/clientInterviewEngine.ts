import type { 
  InterviewSession, InterviewQuestion, 
  QuestionEvaluationResponse, InterviewHistoryData,
  InterviewScoreHistoryItem, InterviewStartRequest
} from '../types';

/**
 * Client-Side AI Mock Interview Engine for Employ.AI
 * Provides realistic, strictly grounded mock interview generation,
 * rigorous deterministic STAR answer evaluation with zero artificial score floors,
 * and persistent score analytics.
 */

const STORAGE_KEY_HISTORY = 'employai_client_interview_history';
const STORAGE_KEY_ACTIVE = 'employai_client_active_session';

export function getClientResumeFacts(): any {
  if (typeof localStorage === 'undefined') return { has_resume: false };

  try {
    const rawAnalysis = localStorage.getItem('employai_active_resume_analysis');
    const rawStructured = localStorage.getItem('employai_active_structured_resume');
    const rawCached = localStorage.getItem('employai_cached_resume');

    let analysis: any = rawAnalysis ? JSON.parse(rawAnalysis) : null;
    let structured: any = rawStructured ? JSON.parse(rawStructured) : null;

    if (!analysis && rawCached) {
      try { analysis = JSON.parse(rawCached); } catch {}
    }

    if (!analysis && !structured) {
      return { has_resume: false };
    }

    const candidateName = structured?.personal_info?.full_name 
      || analysis?.structured_resume?.personal_info?.full_name 
      || analysis?.raw_text?.split('\n')[0]?.trim()
      || 'Candidate';

    const domain = analysis?.detected_domain || structured?.headline || 'General';

    const skills: string[] = Array.from(new Set([
      ...(analysis?.extracted_skills || []),
      ...(structured?.skills || []),
      ...(analysis?.structured_resume?.skills || [])
    ])).filter(Boolean);

    const projects: any[] = [
      ...(analysis?.extracted_projects || []),
      ...(structured?.projects || [])
    ];

    const experience: any[] = [
      ...(analysis?.extracted_experience || []),
      ...(structured?.experience || [])
    ];

    const education: any[] = [
      ...(analysis?.structured_resume?.education || []),
      ...(structured?.education || [])
    ];

    const hasResume = skills.length > 0 || projects.length > 0 || experience.length > 0;

    return {
      has_resume: hasResume,
      candidate_name: candidateName,
      domain,
      skills,
      projects,
      experience,
      education
    };
  } catch (err) {
    console.warn('Error extracting client resume facts:', err);
    return { has_resume: false };
  }
}

/**
 * Generates genuine, domain-aware, resume-grounded questions across all four sections:
 * 1. comprehensive: Zig-Zag Full Spectrum (Project, Technical, STAR, Scalability, Critical Judgment)
 * 2. technical: Technical Deep-Dive (Runtime mechanics, downstream hangs, profiling, idempotency, adversarial defense)
 * 3. project_deepdive: Resume Projects Defense (Architecture defense, silent failure modes, 10x scale, metric verification)
 * 4. behavioral_star: Behavioral STAR Dilemmas (Crisis ownership, executive negotiation, peer deadlocks, mistakes, vendor collapse)
 */
export function generateClientInterviewSession(
  request: InterviewStartRequest,
  overrideFacts?: any
): InterviewSession {
  const facts = overrideFacts || getClientResumeFacts();
  const role = (request.target_role || facts.domain || 'Software Engineer').trim();
  const numQuestions = Math.min(Math.max(request.num_questions || 5, 3), 10);
  const rawType = (request.interview_type || 'comprehensive').toLowerCase().trim();
  const difficulty = request.difficulty || 'intermediate';

  const skills: string[] = facts.skills || [];
  const projects: any[] = facts.projects || [];
  const experience: any[] = facts.experience || [];
  const candidateName = facts.candidate_name || 'Candidate';

  // Normalize interview section type
  let interviewType: 'comprehensive' | 'technical' | 'project_deepdive' | 'behavioral_star' = 'comprehensive';
  if (rawType.includes('tech')) {
    interviewType = 'technical';
  } else if (rawType.includes('proj')) {
    interviewType = 'project_deepdive';
  } else if (rawType.includes('behav') || rawType.includes('star') || rawType.includes('deepdive')) {
    interviewType = 'behavioral_star';
  } else {
    interviewType = 'comprehensive';
  }

  // Helpers to get project details
  const getProject = (idx: number) => {
    if (projects.length > idx) {
      const p = projects[idx];
      const title = typeof p === 'string' ? p : (p.title || p.name || p.project_name || `Flagship Project ${idx + 1}`);
      const desc = typeof p === 'object' ? (p.description || (Array.isArray(p.bullets) ? p.bullets.join('. ') : '')) : '';
      const tech = typeof p === 'object' && Array.isArray(p.key_technologies) && p.key_technologies.length > 0 
        ? p.key_technologies.join(', ') 
        : (typeof p === 'object' && p.role_or_tech ? p.role_or_tech : (skills.slice(0, 3).join(', ') || 'Core Technologies'));
      return { title, desc, tech };
    }
    const defaultTitle = idx === 0 ? `${role} Flagship Project` : `${role} Initiative`;
    return { title: defaultTitle, desc: '', tech: skills.slice(0, 3).join(', ') || 'System Architecture' };
  };

  // Helpers to get skill details
  const getSkill = (idx: number) => {
    if (skills.length > idx) return skills[idx];
    const fallbacks = ['System Architecture', 'Performance Optimization', 'Data Consistency', 'API Integration', 'Reliability Engineering'];
    return fallbacks[idx % fallbacks.length];
  };

  // Helpers to get experience details
  const getExperience = (idx: number) => {
    if (experience.length > idx) {
      const e = experience[idx];
      const company = typeof e === 'string' ? e : (e.company || e.company_or_org || 'your prior organization');
      const r = typeof e === 'object' ? (e.role || role) : role;
      return { company, role: r };
    }
    return { company: 'your previous team', role };
  };

  const p0 = getProject(0);
  const p1 = getProject(1);
  const s0 = getSkill(0);
  const s1 = getSkill(1);
  const s2 = getSkill(2);
  const s3 = getSkill(3);
  const exp0 = getExperience(0);

  const candidatePool: InterviewQuestion[] = [];

  // ==========================================
  // SECTION 1: PROJECT DEEP-DIVE / DEFENSE
  // ==========================================
  if (interviewType === 'project_deepdive') {
    candidatePool.push(
      {
        id: `q-proj-${Date.now()}-0`,
        index: 0,
        category: 'project_deepdive',
        resume_reference: `Project Architecture: ${p0.title}`,
        question: `On your resume, you highlighted '${p0.title}'${p0.tech ? ` built using ${p0.tech}` : ''}. Walk me through the end-to-end technical pipeline and data flow. Why did you choose this technical stack over alternative solutions, and what was the decisive technical trade-off you accepted during implementation?`,
        context_hint: `Defend your architectural choices, component interactions, and the critical trade-off accepted for '${p0.title}'.`,
        ideal_answer_points: [
          `Clear architectural pipeline and problem statement for ${p0.title}`,
          `Specific technical justification for ${p0.tech || 'chosen tooling'} over alternatives`,
          `Concrete technical bottleneck or architectural trade-off accepted`,
          `Measurable outcome or performance metric achieved`
        ]
      },
      {
        id: `q-proj-${Date.now()}-1`,
        index: 1,
        category: 'project_deepdive',
        resume_reference: `Failure Mode Analysis: ${p0.title}`,
        question: `During the implementation of '${p0.title}', walk me through the single hardest silent failure mode, concurrency race condition, or data inconsistency issue you encountered. How did you isolate the root cause, and what preventative guardrails did you deploy to prevent regression?`,
        context_hint: `Focus on subtle race conditions, silent data corruption, isolation techniques, and permanent automated guardrails.`,
        ideal_answer_points: [
          `Identification of a subtle edge-case or silent failure mode in ${p0.title}`,
          `Root-cause diagnosis methodology using logs, profiling, or telemetry`,
          `Concrete technical fix and automated guardrails implemented`
        ]
      },
      {
        id: `q-proj-${Date.now()}-2`,
        index: 2,
        category: 'project_deepdive',
        resume_reference: `Scale & Budget Stress-Test: ${p0.title}`,
        question: `Looking back at '${p0.title}', if your daily traffic or volume surged 10x overnight while your compute infrastructure budget was reduced by 50%, where would the current architecture break first? What deliberate load shedding, caching, or compute optimizations would you enforce?`,
        context_hint: `Discuss aggressive caching, database read-replicas, asynchronous queue shedding, and compute downsizing.`,
        ideal_answer_points: [
          `Accurate identification of the critical-path bottleneck under 10x load`,
          `Compute cost reduction strategy via caching, queues, or downscaling`,
          `Graceful degradation preserving core data integrity without full outage`
        ]
      },
      {
        id: `q-proj-${Date.now()}-3`,
        index: 3,
        category: 'project_deepdive',
        resume_reference: `Metric Verification: ${p1.title}`,
        question: `On your resume for '${p1.title}', you highlight practical outcomes and results. How did you empirically measure and benchmark these metrics rather than relying on vanity indicators? Walk me through your telemetry, monitoring, and validation methodology.`,
        context_hint: `Explain specific baseline metrics, instrumentation, synthetic load tests, or analytics pipelines used to verify impact.`,
        ideal_answer_points: [
          `Telemetry and instrumentation setup for ${p1.title}`,
          `Specific quantitative baseline vs verified outcome metric achieved`,
          `Continuous monitoring and automated regression prevention`
        ]
      },
      {
        id: `q-proj-${Date.now()}-4`,
        index: 4,
        category: 'project_deepdive',
        resume_reference: `Architectural Critique: ${p0.title}`,
        question: `Suppose an external principal auditor reviewed '${p0.title}' and claimed your solution was either over-engineered or lacked sufficient fault-tolerance compared to standard patterns. How would you objectively counter or validate their critique using empirical engineering data?`,
        context_hint: `Defend using latency benchmarks, team maintenance cognitive load, fault domains, and operational costs.`,
        ideal_answer_points: [
          `Objective architectural defense supported by empirical data or benchmarks`,
          `Nuanced acknowledgment of complexity vs simplicity trade-offs`,
          `Evaluation of long-term maintainability and operational overhead`
        ]
      }
    );
  }

  // ==========================================
  // SECTION 2: TECHNICAL DEEP-DIVE
  // ==========================================
  else if (interviewType === 'technical') {
    candidatePool.push(
      {
        id: `q-tech-${Date.now()}-0`,
        index: 0,
        category: 'technical',
        resume_reference: `Core Runtime Competency: ${s0}`,
        question: `You list '${s0}' as one of your core competencies. Explain the low-level execution lifecycle, runtime memory management, and state handling mechanisms in '${s0}'. How does it behave under peak concurrency and resource contention?`,
        context_hint: `Demonstrate deep low-level mastery of ${s0}: lifecycle, memory allocation, and concurrency model.`,
        ideal_answer_points: [
          `Low-level runtime execution model and lifecycle in ${s0}`,
          `Memory allocation, garbage collection / cleanup, or state propagation`,
          `Behavior and tuning under peak concurrency or heavy throughput`
        ]
      },
      {
        id: `q-tech-${Date.now()}-1`,
        index: 1,
        category: 'technical',
        resume_reference: `Resilience Engineering: ${s1}`,
        question: `When executing high-throughput workflows with '${s1}', suppose a downstream dependency enters an unresponsive 45-second silent hang instead of throwing a fast error. How do you prevent thread starvation, connection pool exhaustion, and cascading failure across the entire system?`,
        context_hint: `Discuss bulkhead thread pool isolation, timeout budgets, reactive backpressure, and circuit breakers.`,
        ideal_answer_points: [
          `Bulkhead isolation and connection pool segregation in ${s1}`,
          `Timeout budgets and dynamic circuit breakers with exponential backoff`,
          `Proactive request deadline propagation and graceful degradation`
        ]
      },
      {
        id: `q-tech-${Date.now()}-2`,
        index: 2,
        category: 'technical',
        resume_reference: `Performance Diagnostics: ${s2}`,
        question: `Walk me through your methodology for diagnosing and resolving a severe performance regression or memory leak in '${s2}'. What profilers, flamegraphs, or metric indicators do you inspect, and what is one anti-pattern that severely degrades throughput?`,
        context_hint: `Detail specific profiling tools, heap analysis, flamegraphs, and concrete architectural fixes.`,
        ideal_answer_points: [
          `Diagnostic profiling tooling and flamegraph inspection in ${s2}`,
          `Root-cause identification of memory leak or CPU spike`,
          `Eradication of anti-patterns and empirical verification of latency reduction`
        ]
      },
      {
        id: `q-tech-${Date.now()}-3`,
        index: 3,
        category: 'technical',
        resume_reference: `Data Consistency & Idempotency: ${s0}`,
        question: `When executing state transitions or persisting critical data with '${s0}', how do you guarantee idempotency across network retries, prevent race conditions, and ensure transactional consistency?`,
        context_hint: `Explain distributed locks, optimistic vs pessimistic locking, idempotency keys, and transaction isolation levels.`,
        ideal_answer_points: [
          `Concurrency control mechanisms (optimistic concurrency, versioning, atomic locks)`,
          `Idempotency enforcement across network retries and duplicate requests`,
          `Data consistency guarantees and conflict resolution strategies`
        ]
      },
      {
        id: `q-tech-${Date.now()}-4`,
        index: 4,
        category: 'technical',
        resume_reference: `Adversarial Robustness: ${s3}`,
        question: `Suppose an attacker or malicious workload attempts an algorithmic complexity exploit (such as ReDoS, catastrophic quadratic backtracking, or payload flooding) against your '${s3}' implementation. How would you architecturally trace and mitigate this vulnerability?`,
        context_hint: `Discuss input length caps, streaming parsers, execution timeouts, rate-limiting tiers, and WAF protection.`,
        ideal_answer_points: [
          `Root cause isolation of complexity attack using CPU/memory profiling`,
          `Defensive parser architecture with strict payload and time limits`,
          `Rate-limiting token buckets and infrastructure containment for ${s3}`
        ]
      }
    );
  }

  // ==========================================
  // SECTION 3: BEHAVIORAL STAR DILEMMAS
  // ==========================================
  else if (interviewType === 'behavioral_star') {
    candidatePool.push(
      {
        id: `q-star-${Date.now()}-0`,
        index: 0,
        category: 'behavioral_star',
        resume_reference: `Crisis Ownership: ${exp0.role} at ${exp0.company}`,
        question: `During your role as ${exp0.role} at ${exp0.company}, describe a high-stakes situation where a critical deliverable or production launch was at imminent risk of catastrophic failure. How did you take ownership, communicate with stakeholders, and lead the resolution?`,
        context_hint: `Use the STAR method: Situation (the crisis), Task (immediate containment), Action (transparent communication & technical fix), Result (measurable outcome).`,
        ideal_answer_points: [
          `Clear context of the high-stakes situation at ${exp0.company}`,
          `Immediate crisis containment and transparent stakeholder communication`,
          `Concrete technical or operational actions personally executed`,
          `Quantifiable positive business or operational outcome achieved`
        ]
      },
      {
        id: `q-star-${Date.now()}-1`,
        index: 1,
        category: 'behavioral_star',
        resume_reference: `Stakeholder Negotiation: ${exp0.company}`,
        question: `Tell me about a situation at ${exp0.company} where an executive, client, or manager pushed for an aggressive, unrealistic deadline or an unsafe shortcut. How did you articulate the underlying technical and operational risks using data to negotiate a phased delivery plan?`,
        context_hint: `Use STAR: Show how you translated technical debt/risk into business impact (outage risk, churn, cost) and negotiated compromise.`,
        ideal_answer_points: [
          `Translating technical risk into tangible business impact (churn, downtime risk, cost)`,
          `Constructive negotiation and active listening without rigid obstruction`,
          `Agreed phased delivery plan balancing speed with reliability`
        ]
      },
      {
        id: `q-star-${Date.now()}-2`,
        index: 2,
        category: 'behavioral_star',
        resume_reference: `Peer Deadlock Resolution`,
        question: `Describe a scenario where you and another experienced colleague had irreconcilable technical philosophies or approaches to solving a problem. When discussions reached an impasse, how did you break the deadlock objectively without damaging team collaboration?`,
        context_hint: `Use STAR: Detail the competing paradigms, the empirical benchmark or spike created to test hypotheses, and how alignment was achieved.`,
        ideal_answer_points: [
          `Objective proof-of-concept or benchmark spike to replace opinion with data`,
          `Preserving professional respect and team psychological safety`,
          `Committing fully once a consensus decision was chosen`
        ]
      },
      {
        id: `q-star-${Date.now()}-3`,
        index: 3,
        category: 'behavioral_star',
        resume_reference: `Blameless Accountability`,
        question: `Tell me about a significant mistake or flawed assumption you personally made during a project. How did you handle reporting it to your team in real time, and what permanent guardrail did you engineer to ensure it could never happen again?`,
        context_hint: `Use STAR: Focus on radical transparency without blame-shifting, swift containment under pressure, and permanent preventative safeguards.`,
        ideal_answer_points: [
          `Radical transparency without blame-shifting or evasion`,
          `Swift incident containment under pressure`,
          `Implementation of permanent automated guardrails and team learning`
        ]
      },
      {
        id: `q-star-${Date.now()}-4`,
        index: 4,
        category: 'behavioral_star',
        resume_reference: `Vendor & Dependency Collapse`,
        question: `Describe an instance where a third-party vendor, external API, or partner completely failed to deliver on their SLA just weeks before your go-live. How did you pivot your strategy to keep the deliverable on track?`,
        context_hint: `Use STAR: Detail rapid impact triage, building lightweight in-house fallbacks, and maintaining milestone delivery.`,
        ideal_answer_points: [
          `Rapid assessment and impact triage of the external failure`,
          `Creative fallback or lightweight in-house solution executed`,
          `Delivering core milestone value despite third-party collapse`
        ]
      }
    );
  }

  // ==========================================
  // SECTION 4: COMPREHENSIVE (ZIG-ZAG SPECTRUM)
  // ==========================================
  else {
    candidatePool.push(
      {
        id: `q-comp-${Date.now()}-0`,
        index: 0,
        category: 'project_deepdive',
        resume_reference: `Project Defense: ${p0.title}`,
        question: `On your resume, you highlighted '${p0.title}'${p0.tech ? ` developed with ${p0.tech}` : ''}. Walk me through the core technical architecture and the most challenging bottleneck you overcame. Why did you choose this architecture over alternative designs?`,
        context_hint: `Defend your design choices, trade-offs, and metrics for '${p0.title}'.`,
        ideal_answer_points: [
          `Clear architectural overview and problem statement for ${p0.title}`,
          `Specific integration details using ${p0.tech || 'core technologies'}`,
          `Concrete technical bottleneck or trade-off encountered`,
          `Measurable outcome or metric achieved`
        ]
      },
      {
        id: `q-comp-${Date.now()}-1`,
        index: 1,
        category: 'technical',
        resume_reference: `Technical Mastery: ${s0}`,
        question: `You list '${s0}' as one of your core competencies. Explain how you leverage '${s0}' in production environments, particularly regarding performance optimization, error resilience, and edge-case handling under peak load.`,
        context_hint: `Demonstrate deep hands-on proficiency with ${s0} beyond textbook definitions.`,
        ideal_answer_points: [
          `Real-world production use cases of ${s0}`,
          `Specific performance tuning or caching strategies`,
          `Edge-case and error recovery handling`,
          `Best practices and anti-patterns to avoid`
        ]
      },
      {
        id: `q-comp-${Date.now()}-2`,
        index: 2,
        category: 'behavioral_star',
        resume_reference: `STAR Crisis Ownership: ${exp0.role} at ${exp0.company}`,
        question: `During your role as ${exp0.role} at ${exp0.company}, describe a high-stakes situation where a critical deliverable was at severe risk. How did you diagnose the issue, align stakeholders, and execute the resolution?`,
        context_hint: `Structure your response using the STAR method: Situation, Task, Action, and Result.`,
        ideal_answer_points: [
          `Clear context of the high-stakes situation at ${exp0.company}`,
          `Specific leadership and cross-functional actions you personally took`,
          `Quantifiable positive business or technical impact achieved`
        ]
      },
      {
        id: `q-comp-${Date.now()}-3`,
        index: 3,
        category: 'system_design',
        resume_reference: `Scalability Architecture: ${role}`,
        question: `In the context of ${role}, how would you architect a scalable, fault-tolerant workflow or system to handle a 10x throughput surge for a core service without degrading response latency or introducing data loss?`,
        context_hint: `Address scalability bottlenecks, rate limiting, asynchronous queues, and monitoring.`,
        ideal_answer_points: [
          `Identification of potential bottlenecks in ${role}`,
          `Decoupling mechanisms (asynchronous queues, caching tiers)`,
          `Graceful degradation strategies under resource starvation`,
          `Observability, telemetry, and alerting`
        ]
      },
      {
        id: `q-comp-${Date.now()}-4`,
        index: 4,
        category: 'core_fundamentals',
        resume_reference: `Nuanced Judgment: ${role}`,
        question: `In the context of ${role}, what is one industry 'best practice' or conventional wisdom that you believe is frequently misapplied or overrated, and what pragmatic approach do you recommend instead?`,
        context_hint: `Demonstrate critical independent thinking and nuanced engineering judgment.`,
        ideal_answer_points: [
          `Clear statement of the conventional practice`,
          `Explanation of when it fails or adds unnecessary operational overhead`,
          `Pragmatic alternative approach supported by experience`
        ]
      }
    );
  }

  // Select questions up to requested count
  const selectedQuestions = candidatePool.slice(0, numQuestions).map((q, idx) => ({
    ...q,
    index: idx
  }));

  const session: InterviewSession = {
    id: `sess-client-${Date.now()}`,
    target_role: role,
    interview_type: interviewType,
    difficulty: difficulty,
    total_questions: selectedQuestions.length,
    status: 'in_progress',
    strengths: [],
    improvements: [],
    questions: selectedQuestions,
    resume_snapshot: {
      candidate_name: candidateName,
      domain: facts.domain,
      skills_count: skills.length,
      projects_count: projects.length,
      has_resume: facts.has_resume
    },
    duration_seconds: 0,
    created_at: new Date().toISOString()
  };

  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(STORAGE_KEY_ACTIVE, JSON.stringify(session));
    }
  } catch {}

  return session;
}

/**
 * Deterministic Semantic Accuracy Evaluator
 * Strictly evaluates answer correctness against question prompt and ideal criteria.
 * Non-answers, evasions, and off-topic responses receive 0/100 (NO artificial 35% floors!).
 * Answers must be accurate and substantive to receive high scores.
 */
export function evaluateClientAnswer(
  question: InterviewQuestion,
  userAnswerText: string
): QuestionEvaluationResponse {
  const text = (userAnswerText || '').trim();
  const words = text.split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  const lower = text.toLowerCase();

  // 1. Trivial non-answer, evasion, or gibberish check
  const trivialPhrases = [
    "i don't know", "dont know", "no idea", "yes", "no", "ok", "okay", "pass", "skip",
    "good", "fine", "hello", "hi", "test", "i know it", "i did it", "not sure",
    "idk", "dunno", "na", "n/a", "none", "nothing", "asdf", "qwer", "wrong", "whatever",
    "cannot answer", "no answer", "skip this", "next question", "i have no experience",
    "i dont know", "don't know", "not known", "no comment", "i am not sure", "dont remember"
  ];

  const isTrivial = wordCount < 4 || trivialPhrases.some(tp => lower === tp || lower.startsWith(tp + ' ') || lower.endsWith(' ' + tp));
  
  if (isTrivial) {
    return {
      question_id: question.id,
      score: 0,
      is_correct: false,
      verdict: "Incorrect / Non-Answer (0/100)",
      feedback: "No substantive or accurate answer provided. Non-answers, evasions, and trivial phrases receive zero marks (0/100).",
      strengths: [],
      improvements: [
        "Directly address the specific question prompt with concrete domain concepts and methodologies.",
        "Explain your architectural decisions, trade-offs, and verifiable outcomes."
      ],
      star_breakdown: {
        situation: "No context provided (0/100)",
        task: "No task identified",
        action: "Missing execution actions",
        result: "No measurable outcome"
      },
      model_answer_snippet: question.ideal_answer_points && question.ideal_answer_points.length > 0
        ? `A 100% accurate answer must address: ${question.ideal_answer_points.join(' • ')}`
        : 'Focus on clear architecture, technical decision trade-offs, and measurable impact.'
    };
  }

  // 2. Extract key criteria terms from question and ideal points
  const stopWords = new Set([
    "the", "and", "for", "are", "but", "not", "you", "all", "any", "can", "had", "her", "was", "one", "our", "out", "day", "get", "has", "him", "his", "man", "new", "now", "old", "see", "two", "way", "who", "boy", "did", "its", "let", "put", "say", "she", "too", "use",
    "what", "which", "where", "when", "why", "how", "your", "their", "this", "that", "these",
    "those", "have", "been", "were", "with", "from", "about", "using", "should", "could", "would",
    "tell", "explain", "walk", "provide", "describe", "during", "looking", "into", "over", "under",
    "than", "more", "most", "some", "such", "project", "work", "time", "also", "just", "like", "will",
    "make", "made", "want", "went", "come", "came", "give", "take", "took", "think", "thought",
    "candidate", "question", "answer", "response", "point", "need", "needed", "end", "through",
    "well", "good", "much", "very", "every", "many", "back", "call", "called"
  ]);

  const cleanWords = (str: string) => str.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(w => w.length >= 3 && !stopWords.has(w));

  const questionTerms = new Set(cleanWords(question.question || ''));
  const idealPoints = question.ideal_answer_points || [];
  
  const idealPointWordSets: Set<string>[] = idealPoints.map(ip => new Set(cleanWords(ip)));
  const allTargetTerms = new Set<string>();
  questionTerms.forEach(w => allTargetTerms.add(w));
  idealPointWordSets.forEach(set => set.forEach(w => allTargetTerms.add(w)));

  // Domain terms dictionary across tech, management, engineering, finance
  const domainVocabulary = [
    // Tech & Software
    "api", "database", "cache", "caching", "redis", "async", "await", "schema", "architecture", "component",
    "state", "test", "testing", "docker", "pipeline", "query", "index", "indexing", "latency", "security",
    "model", "server", "algorithm", "microservice", "react", "fastapi", "sql", "git", "concurrency",
    "thread", "memory", "event", "queue", "rabbitmq", "kafka", "trade-off", "bottleneck", "profiling",
    "load", "shedding", "circuit", "breaker", "bulkhead", "telemetry", "metrics", "throughput", "idempotent",
    "idempotency", "lock", "locking", "transaction", "acid", "replication", "partition", "sharding",
    // Business & Marketing
    "roi", "kpi", "cac", "ltv", "funnel", "conversion", "attribution", "churn", "campaign", "crm", "hubspot",
    "salesforce", "analytics", "seo", "sem", "cpm", "ctr", "budget", "variance", "forecast", "stakeholder",
    // Finance & Operations
    "audit", "dcf", "valuation", "p&l", "ledger", "ebitda", "margin", "reconciliation", "cashflow", "asset",
    // Engineering & Physical
    "cad", "tolerance", "stress", "strain", "thermal", "hvac", "bim", "structural", "pcb", "sensor", "scada"
  ];

  // Tokenize candidate answer
  const answerTokens = new Set(cleanWords(userAnswerText));

  // Matched target terms and domain terms in user's response (strict token boundary matching)
  const matchedTargetTerms = Array.from(allTargetTerms).filter(term => answerTokens.has(term) || (term.length >= 5 && lower.includes(term)));
  const matchedDomainTerms = domainVocabulary.filter(term => answerTokens.has(term) || (term.length >= 5 && lower.includes(term)));

  // 3. Off-Topic Check: If 0 target terms match AND 0 domain terms match -> 0%
  if (matchedTargetTerms.length === 0 && matchedDomainTerms.length === 0) {
    return {
      question_id: question.id,
      score: 0,
      is_correct: false,
      verdict: "Incorrect / Irrelevant (0/100)",
      feedback: "The response is off-topic and did not address the question or its technical subject. Zero marks (0/100) awarded.",
      strengths: [],
      improvements: [
        `Directly address the question topic: mention required concepts (${Array.from(allTargetTerms).slice(0, 4).join(', ')}).`,
        "Ground your answer in real technical execution and verifiable metrics."
      ],
      star_breakdown: {
        situation: "Off-topic context",
        task: "Unaddressed",
        action: "No relevant actions",
        result: "No valid result"
      },
      model_answer_snippet: question.ideal_answer_points && question.ideal_answer_points.length > 0
        ? `A 100% accurate answer must address: ${question.ideal_answer_points.join(' • ')}`
        : 'Focus on clear architecture, technical decision trade-offs, and measurable impact.'
    };
  }

  // 4. Strict Dimensional Scoring Rubric (Zero Artificial Floors)
  // Dimension A: Ideal Answer Points Coverage (0 - 50 pts)
  let coveredIdealPointsCount = 0;
  idealPointWordSets.forEach(wordSet => {
    // Check if key words from this ideal point are present in the answer tokens
    const matches = Array.from(wordSet).filter(w => answerTokens.has(w) || (w.length >= 5 && lower.includes(w)));
    // Substantive coverage requires addressing at least 2 distinct key words (or all words if small)
    if (matches.length >= Math.min(2, wordSet.size)) {
      coveredIdealPointsCount++;
    }
  });

  const idealPointsRatio = idealPoints.length > 0 ? coveredIdealPointsCount / idealPoints.length : (matchedTargetTerms.length > 0 ? 0.4 : 0);
  const idealPointsScore = Math.round(idealPointsRatio * 50);

  // Dimension B: Technical Precision & Target Concept Breadth (0 - 25 pts)
  const targetTermDenominator = Math.min(6, Math.max(2, allTargetTerms.size));
  const targetTermRatio = Math.min(1.0, matchedTargetTerms.length / targetTermDenominator);
  const conceptScore = Math.round(targetTermRatio * 25);

  // Dimension C: Concrete Action Verbs & Methodology (0 - 15 pts)
  const actionKeywords = [
    "implemented", "built", "designed", "created", "refactored", "optimized", "developed",
    "configured", "debugged", "resolved", "architected", "analyzed", "deployed", "scaled",
    "indexed", "cached", "tested", "isolated", "migrated", "managed", "negotiated",
    "formulated", "budgeted", "audited", "conducted", "modeled", "streamlined", "executed",
    "led", "benchmarked", "spearheaded", "standardized", "reconciled", "aligned", "prioritized"
  ];
  const matchedActions = actionKeywords.filter(w => lower.includes(w));
  const actionScore = Math.min(15, matchedActions.length * 5);

  // Dimension D: Measurable Metrics & Quantitative Impact (0 - 10 pts)
  const hasDigits = /\d+/.test(text);
  const hasMetricKeywords = ["percent", "%", "ms", "seconds", "users", "reduced", "increased", "improved", "saved", "scale", "qps", "throughput", "dollar", "inr", "growth", "margin", "latency"].some(k => lower.includes(k));
  const hasMetrics = hasDigits || hasMetricKeywords;
  const metricScore = hasMetrics ? 10 : 0;

  // Calculate Total Score (0 - 100)
  const rawScore = idealPointsScore + conceptScore + actionScore + metricScore;
  const finalScore = Math.max(0, Math.min(100, rawScore));

  // Determine Verdict and Correctness
  let verdict = "Incorrect / Inadequate";
  if (finalScore >= 90) {
    verdict = "Exceptional / 100% Accurate";
  } else if (finalScore >= 75) {
    verdict = "Strong & Accurate";
  } else if (finalScore >= 55) {
    verdict = "Partially Correct / Incomplete";
  } else if (finalScore >= 25) {
    verdict = "Weak / Mostly Inaccurate";
  } else {
    verdict = "Incorrect / Inadequate";
  }

  const isCorrect = finalScore >= 60;

  // Construct Strengths & Improvements based on actual performance
  const strengths: string[] = [];
  const improvements: string[] = [];

  if (matchedTargetTerms.length > 0) {
    strengths.push(`Directly addressed key concepts: ${matchedTargetTerms.slice(0, 3).join(', ')}.`);
  }
  if (matchedActions.length > 0) {
    strengths.push(`Demonstrated hands-on execution verbs (${matchedActions.slice(0, 2).join(', ')}).`);
  }
  if (hasMetrics) {
    strengths.push('Substantiated claims with quantitative impact or measurable metrics.');
  }

  if (idealPointsRatio < 0.6) {
    improvements.push('Deepen the answer to address all core architectural and trade-off criteria.');
  }
  if (!matchedActions.length) {
    improvements.push('Detail the specific personal actions, tools, and methodologies you executed.');
  }
  if (!hasMetrics) {
    improvements.push('Include verifiable quantitative metrics (e.g., latency ms, throughput, scale, % reduction) to demonstrate impact.');
  }

  const feedback = finalScore >= 75
    ? `Strong response (${finalScore}/100). You demonstrated clear technical precision and addressed key evaluation criteria.`
    : finalScore >= 45
    ? `Partially correct (${finalScore}/100). Touches upon relevant concepts but lacks depth on trade-offs, root-cause mechanisms, or concrete metrics.`
    : `Inadequate response (${finalScore}/100). The answer missed the core subject criteria. Address the question prompt directly with specific methodologies.`;

  const starBreakdown = {
    situation: matchedTargetTerms.length > 0 ? 'Context established' : 'Needs clearer background framing',
    task: idealPointsScore >= 25 ? 'Objective defined' : 'Specify exact goals and deliverables',
    action: matchedActions.length > 0 ? `Executed via ${matchedActions.slice(0, 2).join(', ')}` : 'Detail your personal technical steps',
    result: hasMetrics ? 'Quantifiable metric provided' : 'Add measurable outcomes or numbers'
  };

  return {
    question_id: question.id,
    score: finalScore,
    is_correct: isCorrect,
    verdict,
    feedback,
    strengths,
    improvements,
    star_breakdown: starBreakdown,
    model_answer_snippet: question.ideal_answer_points && question.ideal_answer_points.length > 0
      ? `A 100% accurate answer must address: ${question.ideal_answer_points.join(' • ')}`
      : 'Focus on clear architecture, technical decision trade-offs, and measurable impact.'
  };
}

/**
 * Complete and record interview session
 * Computes exact mathematical average of question scores without baseline floors.
 * If questions scored 0%, overall score is 0% (NO fallback to 78%).
 */
export function completeClientInterview(
  sessionId: string,
  durationSeconds: number = 0,
  questionsOverride?: InterviewQuestion[]
): InterviewSession {
  let session: InterviewSession | null = null;
  try {
    if (typeof localStorage !== 'undefined') {
      const raw = localStorage.getItem(STORAGE_KEY_ACTIVE);
      if (raw) session = JSON.parse(raw);
    }
  } catch {}

  if (!session) {
    session = {
      id: sessionId || `sess-client-${Date.now()}`,
      target_role: 'Candidate',
      interview_type: 'comprehensive',
      difficulty: 'intermediate',
      total_questions: 5,
      status: 'completed',
      duration_seconds: durationSeconds,
      questions: [],
      strengths: ['Role alignment'],
      improvements: ['Deepen technical metric defense'],
      created_at: new Date().toISOString()
    };
  }

  // If questionsOverride was provided from the active UI state, update session questions
  if (questionsOverride && Array.isArray(questionsOverride) && questionsOverride.length > 0) {
    session.questions = questionsOverride;
  }

  session.status = 'completed';
  session.duration_seconds = durationSeconds;
  session.completed_at = new Date().toISOString();

  // Calculate scores honestly from answered questions
  const scores: number[] = [];
  session.questions?.forEach(q => {
    if (typeof q.score === 'number' && !isNaN(q.score)) {
      scores.push(q.score);
    }
  });

  // Pure arithmetic mean: if no answered questions or all 0, average is exactly 0!
  const avgScore = scores.length > 0 
    ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) 
    : 0;

  // Category breakdowns based on actual question categories
  const techQuestions = session.questions?.filter(q => q.category === 'technical' || q.category === 'core_fundamentals') || [];
  const techScores = techQuestions.map(q => q.score).filter((s): s is number => typeof s === 'number' && !isNaN(s));
  const techScore = techScores.length > 0 ? Math.round(techScores.reduce((a, b) => a + b, 0) / techScores.length) : avgScore;

  const starQuestions = session.questions?.filter(q => q.category === 'behavioral_star') || [];
  const starScores = starQuestions.map(q => q.score).filter((s): s is number => typeof s === 'number' && !isNaN(s));
  const starScore = starScores.length > 0 ? Math.round(starScores.reduce((a, b) => a + b, 0) / starScores.length) : avgScore;

  const projQuestions = session.questions?.filter(q => q.category === 'project_deepdive') || [];
  const projScores = projQuestions.map(q => q.score).filter((s): s is number => typeof s === 'number' && !isNaN(s));
  const projScore = projScores.length > 0 ? Math.round(projScores.reduce((a, b) => a + b, 0) / projScores.length) : avgScore;

  session.overall_score = avgScore;
  session.technical_score = techScore;
  session.communication_score = Math.round(avgScore * 0.5 + starScore * 0.5);
  session.star_method_score = starScore;
  session.problem_solving_score = projScore;
  session.resume_authenticity_score = projScore;

  session.readiness_level = avgScore >= 85 
    ? 'Placement Ready (Top 10%)' 
    : avgScore >= 70 
    ? 'Industry Qualified' 
    : avgScore >= 50 
    ? 'Developing Candidate' 
    : 'Needs Substantial Preparation';

  session.summary_verdict = `Completed ${session.questions?.length || 0} questions grounded in your resume with an overall score of ${avgScore}/100. Status: ${session.readiness_level}.`;

  // Collect unique strengths & improvements
  const allStrengths = new Set<string>();
  const allImprovements = new Set<string>();
  session.questions?.forEach(q => {
    (q.strengths || []).forEach(s => allStrengths.add(s));
    (q.improvements || []).forEach(i => allImprovements.add(i));
  });

  if (allStrengths.size === 0) {
    if (avgScore >= 60) allStrengths.add('Direct role alignment and structured articulation');
    else allStrengths.add('Completed mock interview round attempt');
  }
  if (allImprovements.size === 0) {
    allImprovements.add('Substantiate all technical and project claims with verified metrics');
  }

  session.strengths = Array.from(allStrengths).slice(0, 5);
  session.improvements = Array.from(allImprovements).slice(0, 5);

  // Save to persistent client history
  try {
    if (typeof localStorage !== 'undefined') {
      const historyRaw = localStorage.getItem(STORAGE_KEY_HISTORY);
      const historyList: InterviewScoreHistoryItem[] = historyRaw ? JSON.parse(historyRaw) : [];

      const historyItem: InterviewScoreHistoryItem = {
        id: session.id,
        target_role: session.target_role,
        interview_type: session.interview_type,
        difficulty: session.difficulty,
        overall_score: session.overall_score,
        technical_score: session.technical_score,
        communication_score: session.communication_score,
        star_method_score: session.star_method_score,
        readiness_level: session.readiness_level,
        total_questions: session.total_questions,
        duration_seconds: durationSeconds,
        created_at: session.created_at,
        completed_at: session.completed_at,
        strengths_count: session.strengths.length,
        improvements_count: session.improvements.length
      };

      const updatedHistory = [historyItem, ...historyList.filter(h => h.id !== session?.id)].slice(0, 50);
      localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(updatedHistory));
      localStorage.removeItem(STORAGE_KEY_ACTIVE);
    }
  } catch (e) {
    console.warn('Failed to save client interview session to history:', e);
  }

  return session;
}

// Get Client History Analytics
export function getClientInterviewHistory(): InterviewHistoryData {
  if (typeof localStorage === 'undefined') {
    return {
      history: [],
      total_interviews: 0,
      average_score: 0,
      highest_score: 0,
      score_trend: [],
      category_averages: { technical: 0, communication: 0, star_method: 0, problem_solving: 0 }
    };
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY_HISTORY);
    const history: InterviewScoreHistoryItem[] = raw ? JSON.parse(raw) : [];

    if (history.length === 0) {
      return {
        history: [],
        total_interviews: 0,
        average_score: 0,
        highest_score: 0,
        score_trend: [],
        category_averages: { technical: 0, communication: 0, star_method: 0, problem_solving: 0 }
      };
    }

    const total = history.length;
    const scores = history.map(h => h.overall_score || 0);
    const avg = Math.round(scores.reduce((a, b) => a + b, 0) / total);
    const highest = Math.max(...scores);

    const techScores = history.map(h => h.technical_score ?? avg).filter(s => typeof s === 'number');
    const commScores = history.map(h => h.communication_score ?? avg).filter(s => typeof s === 'number');
    const starScores = history.map(h => h.star_method_score ?? avg).filter(s => typeof s === 'number');

    const scoreTrend = history.slice(0, 10).reverse().map(h => ({
      date: (h.created_at || '').substring(0, 10),
      score: h.overall_score,
      role: h.target_role,
      type: h.interview_type
    }));

    return {
      history,
      total_interviews: total,
      average_score: avg,
      highest_score: highest,
      score_trend: scoreTrend,
      category_averages: {
        technical: techScores.length ? Math.round(techScores.reduce((a, b) => a + b, 0) / techScores.length) : avg,
        communication: commScores.length ? Math.round(commScores.reduce((a, b) => a + b, 0) / commScores.length) : avg,
        star_method: starScores.length ? Math.round(starScores.reduce((a, b) => a + b, 0) / starScores.length) : avg,
        problem_solving: avg
      }
    };
  } catch (err) {
    console.warn('Error reading client interview history:', err);
    return {
      history: [],
      total_interviews: 0,
      average_score: 0,
      highest_score: 0,
      score_trend: [],
      category_averages: {}
    };
  }
}
