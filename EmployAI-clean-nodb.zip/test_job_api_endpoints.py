import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fastapi.testclient import TestClient
from app.core.database import Base, engine, SessionLocal
from app.main import app
from app.services.job_aggregator_service import JobAggregatorService

Base.metadata.create_all(bind=engine)
db = SessionLocal()
JobAggregatorService.ensure_initial_seed(db)
db.close()

client = TestClient(app)


def test_list_jobs_endpoint():
    response = client.get("/api/v1/jobs")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    assert len(data) > 0
    first_job = data[0]
    assert "title" in first_job
    assert "company" in first_job
    assert "domain" in first_job
    assert "match_score" in first_job
    assert "match_badge" in first_job
    assert "apply_url" in first_job
    print(f"[TEST PASS] GET /api/v1/jobs returned {len(data)} postings with match scores.")


def test_domain_filtering():
    for domain in ["Civil", "Mechanical", "Healthcare & Medicine", "Finance & Commerce", "Computer Science"]:
        res = client.get(f"/api/v1/jobs?domain={domain}")
        assert res.status_code == 200
        jobs = res.json()
        assert len(jobs) > 0, f"Expected jobs for domain {domain}"
        print(f"[TEST PASS] Domain '{domain}' returned {len(jobs)} active job postings.")


def test_explain_job_endpoint():
    list_res = client.get("/api/v1/jobs")
    job_id = list_res.json()[0]["id"]

    response = client.get(f"/api/v1/jobs/{job_id}/explain")
    assert response.status_code == 200
    data = response.json()
    assert data["job_id"] == job_id
    assert "breakdown" in data
    assert "why_matches" in data
    assert "matched_skills" in data
    assert "missing_skills" in data
    print(f"[TEST PASS] GET /api/v1/jobs/{job_id}/explain returned breakdown & narrative.")


def test_manual_job_match_endpoint():
    payload = {
        "title": "React Frontend Developer Intern",
        "company": "Fast Unicorn",
        "pasted_description": "We need an intern proficient in React, TypeScript, and Tailwind CSS. Experience with REST APIs and Git is mandatory."
    }
    response = client.post("/api/v1/jobs/match-url", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "React Frontend Developer Intern"
    assert "match_score" in data
    assert "breakdown" in data
    assert "extracted_skills" in data
    assert "React" in data["extracted_skills"]
    assert "TypeScript" in data["extracted_skills"]
    print(f"[TEST PASS] POST /api/v1/jobs/match-url extracted skills & calculated match score: {data['match_score']}%.")


if __name__ == "__main__":
    test_list_jobs_endpoint()
    test_domain_filtering()
    test_explain_job_endpoint()
    test_manual_job_match_endpoint()
    print("All Job API Endpoint tests passed successfully!")
