import os
import sys
import uuid
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fastapi.testclient import TestClient
from app.core.database import Base, engine, SessionLocal
from app.main import app
from app.models.user import User
from app.models.profile import StudentProfile
from app.models.job import JobPosting
from app.models.taxonomy import StudentSkill, Skill
from app.core.security import create_access_token
from app.services.job_aggregator_service import JobAggregatorService

Base.metadata.create_all(bind=engine)
client = TestClient(app)

def test_resume_job_skill_sync():
    db = SessionLocal()
    JobAggregatorService.ensure_initial_seed(db)

    # 1. Create a test user and student profile
    test_email = f"sync_test_{uuid.uuid4().hex[:8]}@example.com"
    user = User(
        email=test_email,
        hashed_password="hashed_pw",
        full_name="Sync Test Candidate",
        role="student",
        is_active=True
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    profile = StudentProfile(
        user_id=user.id,
        target_domain="Design & Creative Media",
        department="Design & Creative Media"
    )
    db.add(profile)
    db.commit()
    db.refresh(profile)

    # 2. Ensure a job posting exists requiring "Content Creation"
    job = JobPosting(
        source="EmployAI Partner Network",
        source_id=f"test-cc-{uuid.uuid4().hex[:8]}",
        title="Social Media & Content Creator Intern",
        company="Digital Creator Studio",
        location="Remote",
        remote=True,
        job_type="internship",
        domain="Design & Creative Media",
        description="Looking for creative intern skilled in Content Creation and Video Editing.",
        required_skills_json=["Content Creation", "Video Editing"],
        apply_url="https://example.com/apply",
        is_active=True
    )
    db.add(job)
    db.commit()
    user_id = str(user.id)
    job_id = str(job.id)
    db.close()

    token = create_access_token(subject=user_id, role="student")
    auth_headers = {"Authorization": f"Bearer {token}"}



    # 3. Initially sync resume WITH "Content Creation"
    sync_payload_with_cc = {
        "structured_resume": {
            "personal_info": {
                "full_name": "Sync Test Candidate",
                "email": test_email,
                "headline": "Creative Specialist"
            },
            "skills": ["Content Creation", "Video Editing"],
            "experience": [],
            "projects": [],
            "education": []
        }
    }

    res = client.put("/api/v1/documents/active/sync-resume", json=sync_payload_with_cc, headers=auth_headers)
    assert res.status_code == 200, f"Sync resume failed: {res.text}"
    data = res.json()
    assert "Content Creation" in data["extracted_skills"]
    print("[TEST PASS] Successfully synced resume with 'Content Creation'.")

    # 4. Fetch jobs and verify "Content Creation" is matched with tick
    jobs_res = client.get("/api/v1/jobs", headers=auth_headers)
    assert jobs_res.status_code == 200
    jobs = jobs_res.json()
    target_job = next((j for j in jobs if j["id"] == job_id), None)
    assert target_job is not None, "Target test job not found in /jobs output"
    assert "Content Creation" in target_job["matched_skills"], f"Expected 'Content Creation' in matched_skills, got {target_job['matched_skills']}"
    initial_score = target_job["match_score"]
    assert initial_score is not None and initial_score >= 80, f"Expected high match score, got {initial_score}"
    print(f"[TEST PASS] Initial matching verified: Content Creation is MATCHED (score: {initial_score}%).")

    # 5. NOW REMOVE "Content Creation" from the resume
    sync_payload_without_cc = {
        "structured_resume": {
            "personal_info": {
                "full_name": "Sync Test Candidate",
                "email": test_email,
                "headline": "Video Specialist"
            },
            "skills": ["Video Editing"],  # "Content Creation" is removed!
            "experience": [],
            "projects": [],
            "education": []
        }
    }

    res2 = client.put("/api/v1/documents/active/sync-resume", json=sync_payload_without_cc, headers=auth_headers)
    assert res2.status_code == 200
    data2 = res2.json()
    assert "Content Creation" not in data2["extracted_skills"]
    print("[TEST PASS] Successfully synced resume without 'Content Creation'.")

    # 6. Fetch jobs again and verify "Content Creation" is NO LONGER matched
    jobs_res2 = client.get("/api/v1/jobs", headers=auth_headers)
    assert jobs_res2.status_code == 200
    jobs2 = jobs_res2.json()
    target_job2 = next((j for j in jobs2 if j["id"] == job_id), None)
    assert target_job2 is not None
    assert "Content Creation" not in target_job2["matched_skills"], f"Content Creation must NOT be in matched_skills, got {target_job2['matched_skills']}"
    assert "Content Creation" in target_job2["missing_skills"], f"Content Creation must be in missing_skills, got {target_job2['missing_skills']}"
    updated_score = target_job2["match_score"]
    assert updated_score < initial_score, f"Match score must decrease from {initial_score}%, got {updated_score}%"
    print(f"[TEST PASS] Verified: Content Creation is REMOVED from matched_skills (score dropped from {initial_score}% to {updated_score}%).")

    # 7. ADD "Content Creation" BACK and verify it re-matches
    res3 = client.put("/api/v1/documents/active/sync-resume", json=sync_payload_with_cc, headers=auth_headers)
    assert res3.status_code == 200
    jobs_res3 = client.get("/api/v1/jobs", headers=auth_headers)
    assert jobs_res3.status_code == 200
    jobs3 = jobs_res3.json()
    target_job3 = next((j for j in jobs3 if j["id"] == job_id), None)
    assert target_job3 is not None
    assert "Content Creation" in target_job3["matched_skills"]
    readded_score = target_job3["match_score"]
    assert readded_score >= updated_score
    print(f"[TEST PASS] Re-added Content Creation: score restored to {readded_score}%. All tests passed!")


if __name__ == "__main__":
    test_resume_job_skill_sync()
