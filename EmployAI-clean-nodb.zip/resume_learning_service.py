from typing import Dict, Any, List, Optional
import re
from app.schemas.document import (
    StructuredResumeData, ResumeLearningGuideResponse,
    ResumeLearningSkillItem, ResumeLearningProjectItem,
    ResumeLearningExperienceItem, ResumeLearningEducationItem,
    ResumeLearningCertificationItem, ResumeLearningClaimItem,
    ResumeLearningSectionSummary
)

# Canonical knowledge base for common skills across Tech, Design, Finance, Analytics, Mechanical, Electrical & Management
SKILL_KNOWLEDGE_BASE: Dict[str, Dict[str, Any]] = {
    "python": {
        "what_it_is": "A high-level, interpreted programming language known for readability and clean syntax.",
        "what_it_is_used_for": "Building backend web APIs, data analysis, automation scripts, machine learning, and scientific computing.",
        "what_it_means_on_resume": "You understand fundamental programming logic (variables, loops, data structures, OOP) and can write working scripts or application backends.",
        "what_you_should_know": [
            "Difference between mutable (lists, dicts) and immutable (tuples, strings) types",
            "How functions, scopes, and decorators work",
            "Error handling with try/except blocks",
            "Package management with pip and virtual environments"
        ],
        "how_to_explain_it": "I use Python to write backend services and scripts. It allows me to build clean, maintainable logic quickly and integrate with various libraries and APIs.",
        "beginner": "Python is like a versatile digital Swiss Army knife for writing computer instructions easily.",
        "deeper": "Python executes code line-by-line using CPython runtime, managing memory via reference counting and a generational garbage collector."
    },
    "javascript": {
        "what_it_is": "The core programming language of the web that runs inside browsers and on servers via Node.js.",
        "what_it_is_used_for": "Creating interactive web interfaces, handling user events, making API requests, and building full-stack web apps.",
        "what_it_means_on_resume": "You can build interactive web experiences and understand asynchronous operations like fetching data.",
        "what_you_should_know": [
            "Event loop, callbacks, Promises, and async/await syntax",
            "DOM manipulation and event listeners",
            "Scope differences between var, let, and const",
            "Array methods like .map(), .filter(), and .reduce()"
        ],
        "how_to_explain_it": "I use JavaScript to make web pages dynamic and interactive, communicating with backend servers asynchronously to update the UI without reloading.",
        "beginner": "JavaScript is the engine that brings static web pages to life with animations, clicks, and live data.",
        "deeper": "JavaScript is single-threaded and non-blocking, executing synchronous tasks on the call stack and offloading I/O to the event loop."
    },
    "typescript": {
        "what_it_is": "A strongly typed superset of JavaScript developed by Microsoft that compiles down to plain JavaScript.",
        "what_it_is_used_for": "Building scalable, enterprise web applications with compile-time type safety and fewer runtime bugs.",
        "what_it_means_on_resume": "You write structured, maintainable frontend/backend code and understand type contracts, interfaces, and generics.",
        "what_you_should_know": [
            "Interfaces vs Type Aliases",
            "Union types, Optional chaining, and Generics",
            "Compile-time vs runtime type checking",
            "Configuring tsconfig.json"
        ],
        "how_to_explain_it": "I use TypeScript to catch bugs early during development by defining explicit types for data models and component props.",
        "beginner": "TypeScript is JavaScript with an intelligent spellchecker that catches mistakes before code runs.",
        "deeper": "TypeScript provides static type analysis through structural subtyping ('duck typing') without adding runtime overhead."
    },
    "react": {
        "what_it_is": "A popular component-based JavaScript library developed by Meta for building user interfaces.",
        "what_it_is_used_for": "Building responsive Single Page Applications (SPAs) with reusable UI components and dynamic state.",
        "what_it_means_on_resume": "You know how to split a UI into modular components, manage data flow using props and state, and interact with APIs.",
        "what_you_should_know": [
            "React Hooks: useState, useEffect, useRef, useMemo, useCallback",
            "Virtual DOM and the reconciliation process",
            "Unidirectional data flow (props down, events up)",
            "Component lifecycle and cleanups in useEffect"
        ],
        "how_to_explain_it": "I build modular user interfaces with React by breaking screens into reusable components and managing state cleanly.",
        "beginner": "React lets you build web apps out of Lego-like blocks called components that update automatically when data changes.",
        "deeper": "React utilizes a virtual DOM diffing algorithm (Fiber) to compute minimal real DOM mutations during render cycles."
    },
    "fastapi": {
        "what_it_is": "A modern, high-performance web framework for building REST APIs with Python 3.8+ based on standard Python type hints.",
        "what_it_is_used_for": "Creating fast microservices, machine learning model inference backends, and full RESTful web APIs.",
        "what_it_means_on_resume": "You can design REST endpoints, validate request/response payloads with Pydantic, and handle asynchronous requests.",
        "what_you_should_know": [
            "Async def vs synchronous def endpoint routes",
            "Pydantic models for request validation and serialization",
            "Dependency Injection with Depends()",
            "Automatic OpenAPI / Swagger documentation at /docs"
        ],
        "how_to_explain_it": "I use FastAPI to build clean, asynchronous backend APIs that automatically validate incoming requests and generate interactive documentation.",
        "beginner": "FastAPI is a Python tool that acts like a receptionist, taking requests from websites and sending back the right data.",
        "deeper": "FastAPI runs on Starlette for ASGI routing and Pydantic for data validation, delivering performance on par with NodeJS and Go."
    },
    "sql": {
        "what_it_is": "Structured Query Language used to store, manipulate, query, and retrieve data from relational databases.",
        "what_it_is_used_for": "Querying relational tables, aggregating statistics, joining datasets, and managing database schemas.",
        "what_it_means_on_resume": "You can extract business data, write filtering queries, join related tables, and understand database relationships.",
        "what_you_should_know": [
            "SELECT, WHERE, GROUP BY, HAVING, ORDER BY clauses",
            "JOIN types: INNER, LEFT, RIGHT, FULL OUTER",
            "Aggregate functions: COUNT, SUM, AVG, MAX, MIN",
            "Primary Keys, Foreign Keys, and Indexing basics"
        ],
        "how_to_explain_it": "I use SQL to query relational databases, joining multiple tables to extract precise insights and power backend features.",
        "beginner": "SQL is the universal language for asking questions to structured tables of information.",
        "deeper": "SQL queries are parsed and transformed by a query planner into relational algebra trees optimized with index scans or hash joins."
    },
    "docker": {
        "what_it_is": "An open platform for developing, shipping, and running applications inside isolated containers.",
        "what_it_is_used_for": "Ensuring applications run identically across development, staging, and production environments.",
        "what_it_means_on_resume": "You understand containerization, can write a Dockerfile, and know how to package an app with its dependencies.",
        "what_you_should_know": [
            "Images vs Containers",
            "Dockerfile commands: FROM, WORKDIR, COPY, RUN, CMD, EXPOSE",
            "Port mapping (-p 8000:8000) and volumes (-v)",
            "Docker Compose for multi-container orchestration"
        ],
        "how_to_explain_it": "I use Docker to bundle code and its exact dependencies into a lightweight container that runs consistently anywhere.",
        "beginner": "Docker packages your app and everything it needs into a standardized shipping container so it works on any computer.",
        "deeper": "Docker leverages Linux kernel features (namespaces for isolation and cgroups for resource limits) to run lightweight processes."
    },
    "git": {
        "what_it_is": "A distributed version control system for tracking changes in source code during software development.",
        "what_it_is_used_for": "Managing code history, branching, collaborating with team members via GitHub/GitLab, and merging features.",
        "what_it_means_on_resume": "You can work in team codebases, commit changes logically, create pull requests, and resolve basic conflicts.",
        "what_you_should_know": [
            "git add, commit, push, pull, status, log",
            "Branching: git checkout -b, git merge, git rebase",
            "Handling merge conflicts and understanding HEAD",
            ".gitignore file setup"
        ],
        "how_to_explain_it": "I use Git for version control, saving checkpoints of my code and collaborating safely on branches through pull requests.",
        "beginner": "Git is like a timeline machine with infinite undo and branching possibilities for your project code.",
        "deeper": "Git is a content-addressable storage system that models repository state as a Directed Acyclic Graph (DAG) of commit objects."
    },
    "machine learning": {
        "what_it_is": "A branch of artificial intelligence where algorithms learn patterns from historical data to make predictions or decisions.",
        "what_it_is_used_for": "Classification, regression, recommendation systems, natural language processing, and computer vision.",
        "what_it_means_on_resume": "You understand the end-to-end ML lifecycle: preprocessing data, feature engineering, model training, and evaluation.",
        "what_you_should_know": [
            "Supervised vs Unsupervised learning",
            "Train/test splitting and cross-validation",
            "Evaluation metrics: Accuracy, Precision, Recall, F1-Score, RMSE",
            "Overfitting vs underfitting and regularization"
        ],
        "how_to_explain_it": "I build models that train on structured datasets to detect patterns and predict outcomes, evaluating them against holdout test sets.",
        "beginner": "Machine learning teaches computers to recognize patterns from examples instead of hand-coding every rule.",
        "deeper": "ML minimizes a mathematical loss function over parameter space via gradient descent algorithms with backpropagation."
    },
    "figma": {
        "what_it_is": "A collaborative cloud-based interface design and prototyping tool used by UI/UX designers and product teams.",
        "what_it_is_used_for": "Creating wireframes, interactive UI mockups, responsive design systems, and developer handoff specs.",
        "what_it_means_on_resume": "You understand user experience principles, design systems, typography hierarchy, and interactive prototyping.",
        "what_you_should_know": [
            "Auto Layout and responsive resizing constraints",
            "Components, Variants, and Design Tokens",
            "Interactive prototyping with triggers and transitions",
            "Design-to-code handoff"
        ],
        "how_to_explain_it": "I use Figma to design user flows, high-fidelity prototypes, and maintain reusable component libraries for engineers.",
        "beginner": "Figma is a shared digital canvas for designing app screens and clicking through interactive prototypes.",
        "deeper": "Figma runs a WebAssembly C++ rendering engine utilizing WebGL to deliver 60fps canvas performance in the browser."
    },
    "power bi": {
        "what_it_is": "A Microsoft business analytics service providing interactive visualizations and business intelligence capabilities.",
        "what_it_is_used_for": "Building executive KPI dashboards, aggregating multi-source datasets, and reporting business trends.",
        "what_it_means_on_resume": "You can transform raw business data into clear visual dashboards with filters, drill-downs, and DAX measures.",
        "what_you_should_know": [
            "Data modeling and table relationships (Star schema)",
            "DAX formulas (CALCULATE, SUMX, RELATED)",
            "Power Query for ETL data transformation",
            "Interactive slicers and drill-through reports"
        ],
        "how_to_explain_it": "I use Power BI to transform multi-source business data into interactive visual dashboards that track key KPIs.",
        "beginner": "Power BI turns messy spreadsheets into interactive charts and dashboards for decision-makers.",
        "deeper": "Power BI relies on the VertiPaq in-memory columnar database engine to perform rapid analytical queries across millions of rows."
    }
}


class ResumeLearningService:
    """
    Generates a personalized, truthful 'Read & Learn' guide based strictly
    on what the user actually wrote in their resume. Never invents facts.
    """

    @classmethod
    def generate_learning_guide(
        cls,
        structured_resume: StructuredResumeData,
        detected_domain: Any = "General Engineering & Technology",
        raw_text: str = ""
    ) -> ResumeLearningGuideResponse:
        domain_str = "General Professional"
        if isinstance(detected_domain, str) and detected_domain:
            domain_str = detected_domain
        elif isinstance(detected_domain, dict):
            domain_str = detected_domain.get("detected_domain") or "General Professional"

        # Check raw text and education for strong domain cues (e.g. Law, Finance, etc.)
        full_text_check = (raw_text + " " + (structured_resume.personal_info.summary or "") + " " + " ".join([getattr(e, "degree", "") + " " + getattr(e, "institution", "") for e in (structured_resume.education or [])])).lower()
        if re.search(r'\b(ba\s*llb|bba\s*llb|ll\.?b|ll\.?m|faculty of law|law faculty|advocate|litigation|arbitration|corporate law|legal research|scc online|manupatra)\b', full_text_check):
            domain_str = "Law & Legal"
        elif re.search(r'\b(b\.com|m\.com|chartered accountant|gst|tally|accounting|auditing|taxation|balance sheet)\b', full_text_check):
            domain_str = "Finance & Commerce"
        elif re.search(r'\b(mbbs|pharmacy|b\.pharm|clinical research|pharmacology)\b', full_text_check):
            domain_str = "Healthcare & Medicine"

        candidate_name = structured_resume.personal_info.full_name or "Candidate"
        headline = structured_resume.personal_info.title or structured_resume.headline or domain_str

        # 1. Summary Section Learning Breakdown
        summary_text = (
            structured_resume.personal_info.summary or
            structured_resume.summary or
            ""
        ).strip()

        summary_data = None
        if summary_text:
            summary_data = cls._generate_summary_guide(summary_text, headline, domain_str)

        # 2. Skills Learning Breakdown
        skills_guide: List[ResumeLearningSkillItem] = []
        raw_skills = structured_resume.skills or []
        for sk in raw_skills:
            skills_guide.append(cls._generate_skill_guide(sk, domain_str))

        # 3. Projects Learning Breakdown
        projects_guide: List[ResumeLearningProjectItem] = []
        raw_projects = structured_resume.projects or []
        for prj in raw_projects:
            projects_guide.append(cls._generate_project_guide(prj))

        # 4. Experience & Internships Breakdown
        experience_guide: List[ResumeLearningExperienceItem] = []
        internships_guide: List[ResumeLearningExperienceItem] = []
        raw_exp = structured_resume.experience or []
        for exp in raw_exp:
            exp_item = cls._generate_experience_guide(exp)
            if exp_item.is_internship:
                internships_guide.append(exp_item)
            else:
                experience_guide.append(exp_item)

        # 5. Education Breakdown
        education_guide: List[ResumeLearningEducationItem] = []
        raw_edu = structured_resume.education or []
        for edu in raw_edu:
            education_guide.append(cls._generate_education_guide(edu, domain_str))

        # 6. Certifications Breakdown
        certifications_guide: List[ResumeLearningCertificationItem] = []
        raw_certs = structured_resume.certifications or []
        for c in raw_certs:
            certifications_guide.append(cls._generate_certification_guide(c))

        # 7. Ground-Truth Claims Extraction
        claims_guide: List[ResumeLearningClaimItem] = cls._extract_resume_claims(
            structured_resume, summary_text, raw_projects, raw_exp
        )

        # 8. Summary of Sections Detected
        sections: List[ResumeLearningSectionSummary] = []
        if summary_data:
            sections.append(ResumeLearningSectionSummary(id="summary", title="Professional Summary", total_items=1))
        if skills_guide:
            sections.append(ResumeLearningSectionSummary(id="skills", title="Skills & Competencies", total_items=len(skills_guide)))
        if experience_guide:
            sections.append(ResumeLearningSectionSummary(id="experience", title="Work Experience", total_items=len(experience_guide)))
        if internships_guide:
            sections.append(ResumeLearningSectionSummary(id="internship", title="Internship Experience", total_items=len(internships_guide)))
        if projects_guide:
            sections.append(ResumeLearningSectionSummary(id="projects", title="Key Projects", total_items=len(projects_guide)))
        if education_guide:
            sections.append(ResumeLearningSectionSummary(id="education", title="Academic Education", total_items=len(education_guide)))
        if certifications_guide:
            sections.append(ResumeLearningSectionSummary(id="certifications", title="Certifications", total_items=len(certifications_guide)))
        if claims_guide:
            sections.append(ResumeLearningSectionSummary(id="claims", title="Resume Claims & Deep Dives", total_items=len(claims_guide)))

        return ResumeLearningGuideResponse(
            candidate_name=candidate_name,
            detected_domain=domain_str,
            headline=headline,
            summary_section=summary_data,
            skills=skills_guide,
            projects=projects_guide,
            experience=experience_guide,
            internships=internships_guide,
            education=education_guide,
            certifications=certifications_guide,
            claims=claims_guide,
            sections=sections,
            overall_progress_pct=0.0
        )

    @classmethod
    def _generate_summary_guide(cls, summary_text: str, headline: str, domain: str) -> Dict[str, Any]:
        return {
            "what_you_wrote": summary_text,
            "understand_it": f"Your summary introduces you as a candidate in {domain}. It summarizes your primary domain focus and professional direction.",
            "key_things_to_know": [
                f"Domain Positioning: Frames your profile around {domain}",
                "Core Value Proposition: Highlights your primary strengths and execution ability",
                "Tone: Sets a professional, proactive narrative for recruiters and managers"
            ],
            "why_it_matters": "The summary is often the first 6-second hook for a recruiter to confirm your discipline, seniority level, and core focus.",
            "what_you_should_explain": "You should be able to deliver a 30-second 'elevator pitch' that matches the themes in this summary smoothly without reading word-for-word.",
            "beginner_explanation": "Your summary is your personal 2-sentence teaser explaining who you are and what you build or analyze.",
            "deeper_explanation": "A high-impact executive summary establishes domain alignment, signals key competencies, and anchors technical expectations before deep-diving into project bullets."
        }

    @classmethod
    def _generate_skill_guide(cls, skill_name: str, domain: str) -> ResumeLearningSkillItem:
        sk_key = skill_name.lower().strip()
        kb = SKILL_KNOWLEDGE_BASE.get(sk_key)

        if kb:
            return ResumeLearningSkillItem(
                skill_name=skill_name,
                what_it_is=kb["what_it_is"],
                what_it_is_used_for=kb["what_it_is_used_for"],
                what_it_means_on_resume=kb["what_it_means_on_resume"],
                what_you_should_know=kb["what_you_should_know"],
                how_to_explain_it=kb["how_to_explain_it"],
                beginner_explanation=kb["beginner"],
                deeper_explanation=kb["deeper"]
            )

        # Dynamic high-precision default for any other detected skill
        return ResumeLearningSkillItem(
            skill_name=skill_name,
            what_it_is=f"A specialized skill or tool in {domain}.",
            what_it_is_used_for=f"Applied in industry workflows related to {domain} for building, analyzing, or automating core processes.",
            what_it_means_on_resume=f"Listing '{skill_name}' indicates you are familiar with its syntax, workflow, and practical applications in your domain.",
            what_you_should_know=[
                f"Core fundamentals and common use cases of {skill_name}",
                f"Where and why you chose to use {skill_name} in your projects",
                f"Standard tools or libraries that pair with {skill_name}",
                "Basic troubleshooting and best practices"
            ],
            how_to_explain_it=f"I have practical experience with {skill_name} from my coursework and projects, where I used it to implement key functionality.",
            beginner_explanation=f"{skill_name} is a key capability listed on your resume to demonstrate technical competence in {domain}.",
            deeper_explanation=f"{skill_name} involves understanding its underlying architecture, performance considerations, and how it integrates into production pipelines."
        )

    @classmethod
    def _generate_project_guide(cls, prj: Any) -> ResumeLearningProjectItem:
        title = getattr(prj, "title", "Project") or "Technical Project"
        raw_desc = getattr(prj, "description", "") or ""
        bullets = getattr(prj, "bullets", []) or []
        combined_text = raw_desc + " " + " ".join(bullets)
        techs = getattr(prj, "technologies", []) or getattr(prj, "key_technologies", []) or []

        # Extract technologies directly from text if empty
        if not techs:
            for kw in ["Python", "React", "TypeScript", "Node.js", "SQL", "FastAPI", "Docker", "Machine Learning", "Figma", "AWS"]:
                if re.search(r'\b' + re.escape(kw) + r'\b', combined_text, re.IGNORECASE):
                    techs.append(kw)

        what_you_wrote = "\n".join([f"• {b}" for b in bullets]) if bullets else (raw_desc or "Project listed on resume.")

        return ResumeLearningProjectItem(
            project_name=title,
            what_you_wrote=what_you_wrote,
            project_explanation=f"This project represents work where you applied {', '.join(techs) if techs else 'domain skills'} to build a functional solution.",
            technologies_mentioned=techs,
            concepts_to_understand=[
                "The core problem the project solves and why it matters",
                f"The overall architecture and data flow across {', '.join(techs[:3]) if techs else 'the solution'}",
                "How data is stored, processed, and validated",
                "Key technical hurdles you encountered and how you solved them"
            ],
            your_contribution=f"Based on your resume, your contribution was designing and implementing the features described in '{title}'.",
            what_you_should_know=[
                "Why you selected the specific tools and technologies used",
                "How you tested the project for accuracy or performance",
                "What trade-offs or limitations exist in the current version",
                "How you would scale or improve it with additional time"
            ],
            beginner_explanation=f"'{title}' is a project demonstrating your hands-on ability to build working solutions using {', '.join(techs) if techs else 'practical tools'}.",
            deeper_explanation=f"In technical interviews, '{title}' will be evaluated on architectural decisions, component modularity, error recovery, and measurable impact."
        )

    @classmethod
    def _generate_experience_guide(cls, exp: Any) -> ResumeLearningExperienceItem:
        role = getattr(exp, "role", "Role") or "Professional Role"
        company = getattr(exp, "company", "") or getattr(exp, "company_or_org", "") or "Organization"
        duration = getattr(exp, "duration", None)
        bullets = getattr(exp, "bullets", []) or getattr(exp, "highlights", []) or []
        desc = getattr(exp, "description", "") or " ".join(bullets) or "Experience entry on resume."
        what_you_wrote = "\n".join([f"• {b}" for b in bullets]) if bullets else desc

        is_internship = "intern" in role.lower() or "trainee" in role.lower() or "intern" in company.lower()

        # Extract demonstrated skills
        demo_skills: List[str] = []
        for sk in ["Python", "SQL", "React", "TypeScript", "FastAPI", "Docker", "Git", "Machine Learning", "Data Analytics", "Figma", "Power BI", "Excel", "Project Management"]:
            if re.search(r'\b' + re.escape(sk) + r'\b', what_you_wrote, re.IGNORECASE):
                demo_skills.append(sk)

        return ResumeLearningExperienceItem(
            role=role,
            company=company,
            dates=duration,
            description=what_you_wrote,
            is_internship=is_internship,
            what_you_claimed=f"You claimed responsibilities and milestones as {role} at {company}.",
            skills_demonstrated=demo_skills,
            important_terminology=[
                {"term": "Cross-functional Collaboration", "definition": "Working with different departments (engineering, product, business) to achieve goals."},
                {"term": "Deliverable", "definition": "A tangible result, feature, or report produced for a team or client."}
            ],
            what_you_should_understand=[
                f"Your specific day-to-day responsibilities at {company}",
                "The business context and purpose behind the projects you worked on",
                "How your work was evaluated or measured",
                "How you collaborated with teammates, mentors, or stakeholders"
            ],
            beginner_explanation=f"This entry shows what you accomplished and contributed during your time at {company}.",
            deeper_explanation=f"Interviewers look at this role to assess your operational reliability, code/work hygiene, teamwork, and ability to deliver under real-world constraints."
        )

    @classmethod
    def _generate_education_guide(cls, edu: Any, domain: str = "General Professional") -> ResumeLearningEducationItem:
        degree = getattr(edu, "degree", "Degree") or "Academic Degree"
        institution = getattr(edu, "institution", "Institution") or "University"
        field = getattr(edu, "field_of_study", "")
        if field and field not in degree:
            degree = f"{degree} in {field}"
        
        grade = getattr(edu, "grade_or_cgpa", "")
        if grade:
            clean_grade = re.sub(r'^(?:cgpa|grade|score|percentage)[:\s-]*', '', str(grade), flags=re.IGNORECASE).strip()
            grade_str = clean_grade if "cgpa" in clean_grade.lower() else f"CGPA: {clean_grade}"
        else:
            dates = getattr(edu, "end_year", "") or getattr(edu, "duration", "")
            grade_str = f"Graduation: {dates}" if dates else None
        
        coursework = getattr(edu, "coursework", []) or []

        is_law = "law" in domain.lower() or "legal" in domain.lower()
        is_finance = "finance" in domain.lower() or "commerce" in domain.lower() or "account" in domain.lower()

        if is_law:
            concepts = [
                "Constitutional Law & Judicial Review (Arts 32 & 226)",
                "Law of Contracts & Specific Relief (Formation, Breach, Damages)",
                "Civil & Criminal Procedural Frameworks (CPC, CrPC, Evidence Law)",
                "Statutory Interpretation & Precedent Ratio Decidendi",
                "Corporate Governance & Companies Act Statutory Compliance"
            ]
        elif is_finance:
            concepts = [
                "Financial Statement Analysis & Reconciliation",
                "Corporate Finance & Capital Budgeting",
                "Auditing Standards & Internal Financial Controls",
                "Taxation & Statutory Regulatory Compliance",
                "Financial Modeling & Valuation Metrics"
            ]
        else:
            concepts = [
                "Theoretical foundations and core curriculum concepts",
                "Problem solving methodology and critical analytical thinking",
                "Academic project collaboration and research discipline"
            ]

        return ResumeLearningEducationItem(
            degree=degree,
            institution=institution,
            dates_or_grade=grade_str,
            relevant_coursework=coursework,
            academic_achievements=[],
            what_it_demonstrates=f"Provides the foundational academic credentials and theoretical knowledge supporting your career in {field or domain}.",
            key_concepts=concepts
        )

    @classmethod
    def _generate_certification_guide(cls, cert: Any) -> ResumeLearningCertificationItem:
        name = getattr(cert, "name", "Certification") or "Professional Certification"
        issuer = getattr(cert, "issuer", None)

        return ResumeLearningCertificationItem(
            name=name,
            issuer=issuer,
            what_it_represents=f"A formal credential validating standardized knowledge in '{name}'.",
            knowledge_covered=[
                f"Foundational principles and syntax covered in the {name} syllabus",
                "Standard industry patterns and best practices tested by the certifying body"
            ],
            important_concepts=[
                "Core terminology and standards defined by the credential",
                "Practical tools or workflows emphasized in certification materials"
            ],
            what_you_should_understand=f"Be ready to explain why you pursued '{name}' and give examples of how you applied the concepts in your projects."
        )

    @classmethod
    def _extract_resume_claims(
        cls,
        structured_resume: StructuredResumeData,
        summary_text: str,
        projects: List[Any],
        experience: List[Any]
    ) -> List[ResumeLearningClaimItem]:
        """
        Extracts key action verbs and technical claims across the resume
        and creates an understanding checklist without inventing answers.
        """
        claims: List[ResumeLearningClaimItem] = []
        claim_id = 1

        # Check Experience bullets
        for exp in experience:
            role = getattr(exp, "role", "Role") or "Role"
            company = getattr(exp, "company", "Company") or getattr(exp, "company_or_org", "") or "Company"
            bullets = getattr(exp, "bullets", []) or getattr(exp, "highlights", []) or []
            for b in bullets:
                if len(b) > 25:
                    questions = cls._generate_claim_questions(b)
                    claims.append(ResumeLearningClaimItem(
                        id=f"claim-{claim_id}",
                        claim_text=b,
                        source_section=f"Experience ({role} at {company})",
                        what_you_should_understand=questions
                    ))
                    claim_id += 1
                    if len(claims) >= 6:
                        break
            if len(claims) >= 6:
                break

        # Check Project bullets if more claims needed
        if len(claims) < 6:
            for prj in projects:
                title = getattr(prj, "title", "Project") or "Project"
                desc = getattr(prj, "description", "")
                bullets = getattr(prj, "bullets", []) or ([desc] if desc else [])
                for b in bullets:
                    if len(b) > 25:
                        questions = cls._generate_claim_questions(b)
                        claims.append(ResumeLearningClaimItem(
                            id=f"claim-{claim_id}",
                            claim_text=b,
                            source_section=f"Projects ({title})",
                            what_you_should_understand=questions
                        ))
                        claim_id += 1
                        if len(claims) >= 8:
                            break
                if len(claims) >= 8:
                    break

        return claims

    @classmethod
    def _generate_claim_questions(cls, claim_text: str) -> List[str]:
        """Generates targeted reflection questions based strictly on claim phrasing."""
        questions = [
            "What specific tools, methods, or algorithms were used to accomplish this?",
            "What was your direct individual role vs the broader team's scope?",
            "How did you verify that this was working correctly?",
            "What challenges arose while doing this and how did you resolve them?"
        ]

        # Check for metrics
        if re.search(r'\d+%', claim_text) or re.search(r'\b\d+\b', claim_text):
            questions.insert(0, "How was the metric/result measured, and what was the baseline before your work?")

        # Check for ML / AI
        if re.search(r'\b(model|machine learning|deep learning|neural|dataset)\b', claim_text, re.IGNORECASE):
            questions.append("What dataset was used, and how was it preprocessed/evaluated?")

        # Check for APIs / Backends
        if re.search(r'\b(api|database|backend|endpoint|server)\b', claim_text, re.IGNORECASE):
            questions.append("How was the API/database structured and how did you handle errors/latency?")

        return questions[:5]
