import re
from typing import List, Dict, Any, Optional, Set
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.models.matching import Role, RoleSkill, SkillGap
from app.models.profile import StudentProfile
from app.models.taxonomy import StudentSkill, Skill
from app.models.document import AnalysisResult
from app.schemas.matching import (
    SkillGapResponse, MatchBreakdown, ExplainabilityNarrative,
    SkillMatchItem, MissingSkillItem
)
from app.services.job_matching_service import JobMatchingService


class MatchingService:
    @classmethod
    def extract_candidate_context(
        cls,
        db: Session,
        student_profile: StudentProfile
    ) -> Dict[str, Any]:
        """
        Extracts verified skills and detected domain from the student's latest uploaded resume and verified skills.
        """
        skill_names: Set[str] = set()
        detected_domain = None
        has_resume = False

        # 1. Latest Uploaded Resume Analysis (Ground Truth)
        latest_analysis = db.query(AnalysisResult).filter(
            AnalysisResult.student_profile_id == student_profile.id
        ).order_by(AnalysisResult.created_at.desc()).first()

        if latest_analysis:
            has_resume = True
            detected_domain = latest_analysis.detected_domain
            if latest_analysis.extracted_skills_json:
                for s in latest_analysis.extracted_skills_json:
                    if isinstance(s, str) and s.strip():
                        skill_names.add(s.strip().lower())
            
            # Also check structured resume skills if available
            if latest_analysis.structured_resume_json and isinstance(latest_analysis.structured_resume_json, dict):
                struct_skills = latest_analysis.structured_resume_json.get("skills", [])
                if isinstance(struct_skills, list):
                    for sk in struct_skills:
                        if isinstance(sk, str) and sk.strip():
                            skill_names.add(sk.strip().lower())
                        elif isinstance(sk, dict) and "name" in sk:
                            skill_names.add(str(sk["name"]).strip().lower())

        # 2. Verified StudentSkill records
        student_skills = db.query(StudentSkill).filter(StudentSkill.student_profile_id == student_profile.id).all()
        resume_skills_lower = {s.strip().lower() for s in (latest_analysis.extracted_skills_json or []) if isinstance(s, str)} if (has_resume and latest_analysis) else set()
        for ss in student_skills:
            sk = db.query(Skill).filter(Skill.id == ss.skill_id).first()
            if sk and sk.canonical_name:
                c_name = sk.canonical_name.strip().lower()
                if ss.source == "resume" and has_resume:
                    if c_name not in resume_skills_lower:
                        continue
                skill_names.add(c_name)
                has_resume = True


        # Candidate Domain Determination
        candidate_domain = (
            detected_domain or
            student_profile.target_domain or
            student_profile.department or
            "General"
        )

        return {
            "skills": skill_names,
            "domain": candidate_domain,
            "department": student_profile.department or candidate_domain,
            "has_resume": has_resume
        }

    @staticmethod
    def calculate_role_match(
        db: Session,
        student_profile: StudentProfile,
        role: Role
    ) -> SkillGapResponse:
        """
        Deterministically calculate explainable matching metrics and skill gaps for a student against an industry role.
        Guarantees honest 0% match when candidate has no qualifying skills or belongs to an incompatible discipline.
        """
        candidate_ctx = MatchingService.extract_candidate_context(db, student_profile)
        candidate_skills: Set[str] = candidate_ctx["skills"]
        candidate_domain: str = candidate_ctx["domain"]
        has_resume: bool = candidate_ctx["has_resume"] and len(candidate_skills) > 0

        role_skills = db.query(RoleSkill).filter(RoleSkill.role_id == role.id).all()
        required_skills = [rs for rs in role_skills if rs.is_required]
        preferred_skills = [rs for rs in role_skills if not rs.is_required]

        matched_items: List[SkillMatchItem] = []
        missing_items: List[MissingSkillItem] = []

        # 1. Required Skills Evaluation
        req_weight_total = sum(rs.weight for rs in required_skills) or 1.0
        req_weight_matched = 0.0

        for rs in required_skills:
            skill = db.query(Skill).filter(Skill.id == rs.skill_id).first()
            if not skill:
                continue

            skill_name = skill.canonical_name
            is_matched = has_resume and JobMatchingService.check_skill_match(skill_name, candidate_skills)

            if is_matched:
                req_weight_matched += rs.weight
                matched_items.append(SkillMatchItem(
                    skill_id=skill.id,
                    skill_name=skill_name,
                    is_required=True,
                    proficiency="verified",
                    source="resume"
                ))
            else:
                missing_items.append(MissingSkillItem(
                    skill_id=skill.id,
                    skill_name=skill_name,
                    domain=skill.domain,
                    is_required=True,
                    importance_level=rs.importance_level or "high",
                    recommendation=f"Acquire {skill_name} fundamentals and complete an application project."
                ))

        required_coverage_pct = min(100.0, (req_weight_matched / req_weight_total) * 100.0) if required_skills else 100.0

        # 2. Preferred Skills Evaluation
        pref_weight_total = sum(rs.weight for rs in preferred_skills) or 1.0
        pref_weight_matched = 0.0

        for rs in preferred_skills:
            skill = db.query(Skill).filter(Skill.id == rs.skill_id).first()
            if not skill:
                continue

            skill_name = skill.canonical_name
            is_matched = has_resume and JobMatchingService.check_skill_match(skill_name, candidate_skills)

            if is_matched:
                pref_weight_matched += rs.weight
                matched_items.append(SkillMatchItem(
                    skill_id=skill.id,
                    skill_name=skill_name,
                    is_required=False,
                    proficiency="verified",
                    source="resume"
                ))
            else:
                missing_items.append(MissingSkillItem(
                    skill_id=skill.id,
                    skill_name=skill_name,
                    domain=skill.domain,
                    is_required=False,
                    importance_level=rs.importance_level or "medium",
                    recommendation=f"Learn {skill_name} as a high-value differentiator."
                ))

        preferred_coverage_pct = min(100.0, (pref_weight_matched / pref_weight_total) * 100.0) if preferred_skills else 100.0

        # 3. Domain Compatibility & Project Relevance
        domain_score, domain_assessment = JobMatchingService.calculate_domain_fit(candidate_domain, role.domain)
        
        if not has_resume or len(matched_items) == 0:
            project_relevance = 0.0
            dept_match = 0.0 if domain_score <= 15.0 else domain_score
        else:
            project_relevance = 90.0 if len(matched_items) >= 3 else 70.0
            dept_match = domain_score

        # 4. Composite Match Score Formula (Non-Compensatory)
        if not has_resume or len(candidate_skills) == 0:
            composite_score = 0.0
        elif required_coverage_pct == 0.0:
            # Strict Non-Compensatory Gate: If 0 required core skills match, score is strictly 0.0%
            composite_score = 0.0
        else:
            raw_score = (
                (required_coverage_pct * 0.60) +
                (preferred_coverage_pct * 0.15) +
                (dept_match * 0.15) +
                (project_relevance * 0.10)
            )
            if dept_match <= 10.0:
                raw_score *= 0.50
            composite_score = round(min(100.0, max(0.0, raw_score)), 1)

        # 5. Explainability Generation
        why_matches: List[str] = []
        if composite_score == 0.0:
            why_matches.append(f"No qualifying skill overlap detected between your verified resume and this role's {len(role_skills)} specifications.")
            why_matches.append(f"Disciplinary Specialization: Your profile is centered in '{candidate_domain}', while this role requires '{role.domain}' credentials.")
        else:
            why_matches.append(f"Demonstrated verified alignment on {len(matched_items)} core competencies: {', '.join([m.skill_name for m in matched_items[:3]])}.")
            why_matches.append(domain_assessment)
            if project_relevance >= 80.0:
                why_matches.append("Resume project evidence correlates with industry specifications for this role.")

        missing_critical = [f"{m.skill_name} ({m.domain})" for m in missing_items if m.is_required]
        action_plan = [
            f"Focus learning on missing core skill: {m.skill_name}." for m in missing_items[:3]
        ]
        if not action_plan:
            action_plan.append("Candidate fulfills all core and preferred benchmarks. Ready for target placement applications.")

        if composite_score == 0.0:
            summary_narrative = (
                f"Candidate exhibits a 0.0% match for '{role.title}' ({role.domain}). "
                f"Possesses 0 of {len(role_skills)} required specifications. "
                f"Your verified resume is built for '{candidate_domain}'."
            )
        else:
            summary_narrative = (
                f"Candidate exhibits a {composite_score}% match for '{role.title}'. "
                f"Possesses {len(matched_items)} of {len(role_skills)} target competencies. "
                f"{'Bridging ' + ', '.join(missing_critical[:2]) + ' will elevate candidate to top-tier readiness.' if missing_critical else 'Candidate demonstrates comprehensive readiness for this role.'}"
            )

        breakdown = MatchBreakdown(
            required_skills_score=round(required_coverage_pct if composite_score > 0 else 0.0, 1),
            preferred_skills_score=round(preferred_coverage_pct if composite_score > 0 else 0.0, 1),
            projects_relevance_score=round(project_relevance, 1),
            education_eligibility_score=round(dept_match, 1),
            overall_match=composite_score
        )

        explainability = ExplainabilityNarrative(
            summary=summary_narrative,
            why_matches=why_matches,
            missing_critical_gaps=missing_critical,
            recommended_action_plan=action_plan
        )

        # Upsert SkillGap entity in DB
        gap_record = db.query(SkillGap).filter(
            SkillGap.student_profile_id == student_profile.id,
            SkillGap.role_id == role.id
        ).first()

        if not gap_record:
            gap_record = SkillGap(
                student_profile_id=student_profile.id,
                role_id=role.id,
                match_percentage=composite_score,
                score_breakdown_json=breakdown.model_dump(),
                matched_skills_json=[m.model_dump() for m in matched_items],
                missing_skills_json=[m.model_dump() for m in missing_items],
                explainability_summary=summary_narrative,
                calculated_at=datetime.now(timezone.utc)
            )
            db.add(gap_record)
        else:
            gap_record.match_percentage = composite_score
            gap_record.score_breakdown_json = breakdown.model_dump()
            gap_record.matched_skills_json = [m.model_dump() for m in matched_items]
            gap_record.missing_skills_json = [m.model_dump() for m in missing_items]
            gap_record.explainability_summary = summary_narrative
            gap_record.calculated_at = datetime.now(timezone.utc)

        db.commit()
        db.refresh(gap_record)

        return SkillGapResponse(
            id=gap_record.id,
            role_id=role.id,
            role_title=role.title,
            role_domain=role.domain,
            match_percentage=composite_score,
            breakdown=breakdown,
            matched_skills=matched_items,
            missing_skills=missing_items,
            explainability=explainability,
            calculated_at=gap_record.calculated_at
        )

    @staticmethod
    def evaluate_all_roles(db: Session, student_profile: StudentProfile) -> List[SkillGapResponse]:
        """Evaluate student against all industry roles in database and return sorted by match %."""
        roles = db.query(Role).all()
        results = []
        for role in roles:
            eval_res = MatchingService.calculate_role_match(db, student_profile, role)
            results.append(eval_res)

        results.sort(key=lambda x: x.match_percentage, reverse=True)
        return results
