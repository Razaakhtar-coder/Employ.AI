import React, { useState, useEffect, useRef } from 'react';
import type { RoadmapYouTubeResource } from '../types';
import { 
  Play, CheckCircle2, Circle, ExternalLink, 
  Clock, BookOpen, Check, AlertTriangle, RefreshCw, Search
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface YouTubePracticeStudioProps {
  resources: RoadmapYouTubeResource[];
  milestoneIndex?: number;
  domainName?: string;
  coDomainName?: string;
  onPracticalCompleted?: (exerciseId: string) => void;
}

export const YouTubePracticeStudio: React.FC<YouTubePracticeStudioProps> = ({
  resources,
  milestoneIndex: _milestoneIndex,
  domainName: _domainName = 'Computer Science',
  coDomainName: _coDomainName = 'Core Skill',
  onPracticalCompleted
}) => {
  const [activeVideoIndex, setActiveVideoIndex] = useState<number>(0);
  const [streamSource, setStreamSource] = useState<'primary' | 'backup'>('primary');
  const [hasPlaybackError, setHasPlaybackError] = useState<boolean>(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const activeVideo = resources[activeVideoIndex] || resources[0];

  // Reset stream source and error state when active video changes
  useEffect(() => {
    setStreamSource('primary');
    setHasPlaybackError(false);
  }, [activeVideo?.id, activeVideo?.youtube_video_id]);

  // Watched state persisted to localStorage per video
  const watchedStorageKey = `yt_watched_${activeVideo?.id || 'default'}`;
  const [isWatched, setIsWatched] = useState<boolean>(() => {
    return localStorage.getItem(watchedStorageKey) === 'true';
  });

  // Update watched status when active video changes
  useEffect(() => {
    if (activeVideo?.id) {
      const watched = localStorage.getItem(`yt_watched_${activeVideo.id}`) === 'true';
      setIsWatched(watched);
    }
  }, [activeVideo?.id]);

  // YouTube IFrame Player API postMessage error listener
  useEffect(() => {
    const handleWindowMessage = (event: MessageEvent) => {
      // Ensure message comes from YouTube
      if (typeof event.origin === 'string' && !event.origin.includes('youtube')) {
        return;
      }

      try {
        let payload: any = event.data;
        if (typeof payload === 'string') {
          try {
            payload = JSON.parse(payload);
          } catch {
            return;
          }
        }

        // Detect YouTube player error events
        // 2: Invalid parameter, 5: HTML5 error, 100: Not found/private, 101/150: Embed disabled by owner
        if (payload && (payload.event === 'onError' || (payload.info && typeof payload.info === 'number' && [2, 5, 100, 101, 150].includes(payload.info)))) {
          console.warn('[YouTubePracticeStudio] YouTube embed error reported:', payload);
          if (streamSource === 'primary' && activeVideo?.fallback_video_id && activeVideo.fallback_video_id !== activeVideo.youtube_video_id) {
            setStreamSource('backup');
          } else {
            setHasPlaybackError(true);
          }
        }
      } catch (err) {
        // Ignore JSON parsing errors for non-YT messages
      }
    };

    window.addEventListener('message', handleWindowMessage);
    return () => {
      window.removeEventListener('message', handleWindowMessage);
    };
  }, [activeVideo, streamSource]);

  const handleToggleWatched = () => {
    const newVal = !isWatched;
    setIsWatched(newVal);
    if (activeVideo?.id) {
      localStorage.setItem(`yt_watched_${activeVideo.id}`, String(newVal));
    }
    if (newVal) {
      confetti({ particleCount: 35, spread: 55, origin: { y: 0.8 } });
    }
    try {
      window.dispatchEvent(new CustomEvent('employai:video-watched-toggled', {
        detail: { videoId: activeVideo?.id, isWatched: newVal }
      }));
      window.dispatchEvent(new Event('storage'));
    } catch {}
    if (onPracticalCompleted && newVal && activeVideo?.id) {
      onPracticalCompleted(activeVideo.id);
    }
  };

  const handleSwitchStream = () => {
    if (streamSource === 'primary') {
      setStreamSource('backup');
      setHasPlaybackError(false);
    } else {
      setStreamSource('primary');
      setHasPlaybackError(false);
    }
  };

  if (!resources || resources.length === 0 || !activeVideo) {
    return null;
  }

  // Determine current active video ID
  const currentVideoId = (streamSource === 'backup' && activeVideo.fallback_video_id) 
    ? activeVideo.fallback_video_id 
    : activeVideo.youtube_video_id;

  const searchQuery = activeVideo.search_query || `${activeVideo.title} ${activeVideo.channel_name}`;
  const directSearchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(searchQuery)}`;

  return (
    <div 
      className="youtube-video-platform-card"
      style={{
        marginTop: '1rem',
        marginBottom: '0.75rem',
        borderRadius: '12px',
        border: '1.5px solid rgba(239, 68, 68, 0.28)',
        background: 'linear-gradient(180deg, rgba(239, 68, 68, 0.05) 0%, rgba(15, 23, 42, 0.65) 100%)',
        boxShadow: '0 6px 24px rgba(0, 0, 0, 0.25)',
        overflow: 'hidden',
        backdropFilter: 'blur(10px)'
      }}
    >
      {/* Top Banner with Video Title & Controls */}
      <div 
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '0.6rem',
          padding: '0.75rem 1.1rem',
          borderBottom: '1px solid rgba(239, 68, 68, 0.18)',
          background: 'rgba(239, 68, 68, 0.07)'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.55rem', flexWrap: 'wrap' }}>
          <span 
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.3rem',
              background: '#ef4444',
              color: '#ffffff',
              fontSize: '0.72rem',
              fontWeight: 800,
              padding: '0.22rem 0.6rem',
              borderRadius: '6px',
              letterSpacing: '0.04em',
              textTransform: 'uppercase',
              boxShadow: '0 0 10px rgba(239, 68, 68, 0.35)'
            }}
          >
            <Play size={11} fill="#ffffff" /> YouTube Masterclass
          </span>

          <h4 style={{ fontSize: '0.86rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
            {activeVideo.title}
          </h4>
        </div>

        {/* Right side controls: Stream switcher + Watched Toggle */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap' }}>
          {/* Stream 1 / Stream 2 selector if fallback exists */}
          {activeVideo.fallback_video_id && activeVideo.fallback_video_id !== activeVideo.youtube_video_id && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.2rem', background: 'rgba(0,0,0,0.35)', padding: '0.15rem 0.3rem', borderRadius: '7px', border: '1px solid var(--border-subtle)' }}>
              <button
                onClick={() => { setStreamSource('primary'); setHasPlaybackError(false); }}
                title="Primary verified stream"
                style={{
                  background: streamSource === 'primary' ? '#ef4444' : 'transparent',
                  color: streamSource === 'primary' ? '#ffffff' : 'var(--text-secondary)',
                  border: 'none',
                  borderRadius: '5px',
                  fontSize: '0.66rem',
                  fontWeight: 700,
                  padding: '0.2rem 0.45rem',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease'
                }}
              >
                Stream 1
              </button>
              <button
                onClick={() => { setStreamSource('backup'); setHasPlaybackError(false); }}
                title="Alternative backup stream"
                style={{
                  background: streamSource === 'backup' ? '#3b82f6' : 'transparent',
                  color: streamSource === 'backup' ? '#ffffff' : 'var(--text-secondary)',
                  border: 'none',
                  borderRadius: '5px',
                  fontSize: '0.66rem',
                  fontWeight: 700,
                  padding: '0.2rem 0.45rem',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease'
                }}
              >
                Stream 2
              </button>
            </div>
          )}

          {/* Multi-video selector if multiple resources present */}
          {resources.length > 1 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', background: 'rgba(0,0,0,0.3)', padding: '0.15rem 0.3rem', borderRadius: '7px', border: '1px solid var(--border-subtle)' }}>
              {resources.map((_v, idx) => (
                <button
                  key={idx}
                  onClick={() => { setActiveVideoIndex(idx); setStreamSource('primary'); setHasPlaybackError(false); }}
                  style={{
                    background: activeVideoIndex === idx ? '#ef4444' : 'transparent',
                    color: activeVideoIndex === idx ? '#ffffff' : 'var(--text-secondary)',
                    border: 'none',
                    borderRadius: '5px',
                    fontSize: '0.68rem',
                    fontWeight: 700,
                    padding: '0.2rem 0.55rem',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                >
                  Video {idx + 1}
                </button>
              ))}
            </div>
          )}

          <a
            href={activeVideo.youtube_url || `https://www.youtube.com/watch?v=${currentVideoId}`}
            target="_blank"
            rel="noopener noreferrer"
            title="Open and watch video directly on YouTube"
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.35rem',
              fontSize: '0.72rem',
              fontWeight: 700,
              padding: '0.28rem 0.65rem',
              borderRadius: '7px',
              border: '1px solid rgba(239, 68, 68, 0.4)',
              background: 'rgba(239, 68, 68, 0.12)',
              color: '#f87171',
              textDecoration: 'none',
              cursor: 'pointer',
              transition: 'all 0.15s ease'
            }}
          >
            <Play size={11} fill="#f87171" /> Watch on YouTube <ExternalLink size={11} />
          </a>

          <button
            onClick={handleToggleWatched}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
              fontSize: '0.72rem',
              fontWeight: 700,
              padding: '0.28rem 0.7rem',
              borderRadius: '7px',
              border: isWatched ? '1px solid #10b981' : '1px solid var(--border-subtle)',
              background: isWatched ? 'rgba(16, 185, 129, 0.18)' : 'rgba(255, 255, 255, 0.04)',
              color: isWatched ? '#10b981' : 'var(--text-secondary)',
              cursor: 'pointer',
              transition: 'all 0.15s ease'
            }}
          >
            {isWatched ? <CheckCircle2 size={13} color="#10b981" /> : <Circle size={13} />}
            <span>{isWatched ? 'Watched ✓' : 'Mark Watched'}</span>
          </button>
        </div>
      </div>

      {/* Main Video Body */}
      <div style={{ padding: '1rem', display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
        {/* Responsive 16:9 Video Embed Player or Fallback Recovery Card */}
        <div 
          style={{
            position: 'relative',
            width: '100%',
            paddingTop: '56.25%', // 16:9 Aspect Ratio
            borderRadius: '10px',
            overflow: 'hidden',
            background: '#070b14',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            boxShadow: '0 4px 18px rgba(0,0,0,0.45)'
          }}
        >
          {hasPlaybackError ? (
            /* Resilient Fallback Card if embed playback is restricted or blocked */
            <div
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.85rem',
                padding: '1.5rem',
                textAlign: 'center',
                background: `linear-gradient(rgba(15, 23, 42, 0.88), rgba(15, 23, 42, 0.94)), url(https://img.youtube.com/vi/${currentVideoId}/hqdefault.jpg) center/cover no-repeat`
              }}
            >
              <div 
                style={{
                  width: '46px',
                  height: '46px',
                  borderRadius: '50%',
                  background: 'rgba(239, 68, 68, 0.15)',
                  border: '1px solid rgba(239, 68, 68, 0.35)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#ef4444'
                }}
              >
                <AlertTriangle size={24} />
              </div>

              <div>
                <h5 style={{ margin: '0 0 0.35rem 0', fontSize: '0.98rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                  In-Browser Embed Restricted by Video Owner
                </h5>
                <p style={{ margin: 0, fontSize: '0.78rem', color: 'var(--text-secondary)', maxWidth: '440px', lineHeight: 1.4 }}>
                  This video publisher limits playback to YouTube directly. You can stream this lesson immediately on YouTube or try the backup stream.
                </p>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', flexWrap: 'wrap', justifyContent: 'center' }}>
                <a
                  href={activeVideo.youtube_url || `https://www.youtube.com/watch?v=${currentVideoId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.45rem',
                    padding: '0.55rem 1.15rem',
                    borderRadius: '8px',
                    background: '#ef4444',
                    color: '#ffffff',
                    fontSize: '0.82rem',
                    fontWeight: 700,
                    textDecoration: 'none',
                    boxShadow: '0 4px 14px rgba(239, 68, 68, 0.4)'
                  }}
                >
                  <Play size={14} fill="#ffffff" /> Watch on YouTube Directly <ExternalLink size={13} />
                </a>

                {activeVideo.fallback_video_id && activeVideo.fallback_video_id !== activeVideo.youtube_video_id && (
                  <button
                    onClick={handleSwitchStream}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '0.4rem',
                      padding: '0.55rem 1rem',
                      borderRadius: '8px',
                      background: 'rgba(59, 130, 246, 0.2)',
                      border: '1px solid rgba(59, 130, 246, 0.4)',
                      color: '#60a5fa',
                      fontSize: '0.82rem',
                      fontWeight: 700,
                      cursor: 'pointer'
                    }}
                  >
                    <RefreshCw size={13} /> Try Backup Stream
                  </button>
                )}

                <a
                  href={directSearchUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.4rem',
                    padding: '0.55rem 1rem',
                    borderRadius: '8px',
                    background: 'rgba(255, 255, 255, 0.06)',
                    border: '1px solid var(--border-subtle)',
                    color: 'var(--text-secondary)',
                    fontSize: '0.82rem',
                    fontWeight: 600,
                    textDecoration: 'none'
                  }}
                >
                  <Search size={13} /> Search Alternative Tutorials
                </a>
              </div>
            </div>
          ) : (
            <iframe
              ref={iframeRef}
              src={`https://www.youtube-nocookie.com/embed/${currentVideoId}?enablejsapi=1&rel=0&modestbranding=1`}
              title={activeVideo.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              loading="lazy"
              tabIndex={-1}
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                border: 'none'
              }}
            />
          )}
        </div>

        {/* Video Channel & Metadata Row */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '0.76rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
              📺 {activeVideo.channel_name}
            </span>

            {activeVideo.topic_focus && (
              <span style={{ background: 'rgba(56, 189, 248, 0.12)', color: 'var(--accent-cyan)', border: '1px solid rgba(56, 189, 248, 0.25)', fontSize: '0.68rem', fontWeight: 600, padding: '0.12rem 0.5rem', borderRadius: '5px' }}>
                🎯 {activeVideo.topic_focus}
              </span>
            )}

            <span style={{ display: 'flex', alignItems: 'center', gap: '0.2rem', fontSize: '0.68rem', color: 'var(--text-muted)', background: 'rgba(255,255,255,0.05)', padding: '0.12rem 0.5rem', borderRadius: '5px' }}>
              <Clock size={11} /> {activeVideo.duration}
            </span>

            <span style={{ fontSize: '0.66rem', fontWeight: 700, color: '#a855f7', background: 'rgba(168, 85, 247, 0.12)', border: '1px solid rgba(168, 85, 247, 0.25)', padding: '0.12rem 0.5rem', borderRadius: '5px' }}>
              ⭐ {activeVideo.difficulty} Level
            </span>

            {streamSource === 'backup' && (
              <span style={{ fontSize: '0.66rem', fontWeight: 700, color: '#60a5fa', background: 'rgba(59, 130, 246, 0.15)', border: '1px solid rgba(59, 130, 246, 0.3)', padding: '0.12rem 0.5rem', borderRadius: '5px' }}>
                Stream 2 (Backup Active)
              </span>
            )}
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
            {/* Quick Stream toggle if user encounters any issue */}
            {activeVideo.fallback_video_id && activeVideo.fallback_video_id !== activeVideo.youtube_video_id && (
              <button
                onClick={handleSwitchStream}
                title="Switch between stream 1 and stream 2"
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'var(--text-muted)',
                  fontSize: '0.70rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.25rem',
                  padding: 0
                }}
              >
                <RefreshCw size={11} /> Switch Stream
              </button>
            )}

            <a
              href={directSearchUrl}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.25rem',
                fontSize: '0.70rem',
                color: 'var(--text-muted)',
                fontWeight: 600,
                textDecoration: 'none'
              }}
            >
              <Search size={11} /> Search YouTube
            </a>

            <a
              href={activeVideo.youtube_url}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.3rem',
                fontSize: '0.72rem',
                color: '#ef4444',
                fontWeight: 700,
                textDecoration: 'none'
              }}
            >
              Watch on YouTube <ExternalLink size={12} />
            </a>
          </div>
        </div>

        {/* Key Takeaways & Core Concepts Covered */}
        {activeVideo.key_takeaways && activeVideo.key_takeaways.length > 0 && (
          <div style={{ padding: '0.75rem 0.9rem', background: 'rgba(255, 255, 255, 0.02)', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
            <span style={{ fontSize: '0.68rem', fontWeight: 800, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em', display: 'flex', alignItems: 'center', gap: '0.3rem', marginBottom: '0.4rem' }}>
              <BookOpen size={12} color="var(--accent-cyan)" /> Key Concepts Covered in this Lesson:
            </span>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '0.35rem' }}>
              {activeVideo.key_takeaways.map((takeaway, tIdx) => (
                <div key={tIdx} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.4rem', fontSize: '0.76rem', color: 'var(--text-secondary)', lineHeight: 1.4 }}>
                  <Check size={12} color="#10b981" style={{ flexShrink: 0, marginTop: '0.15rem' }} />
                  <span>{takeaway}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
