from fastapi import APIRouter
from app.api.v1.auth import router as auth_router
from app.api.v1.profiles import router as profiles_router
from app.api.v1.documents import router as documents_router
from app.api.v1.taxonomy import router as taxonomy_router
from app.api.v1.matching import router as matching_router
from app.api.v1.roadmaps import router as roadmaps_router
from app.api.v1.opportunities import router as opportunities_router
from app.api.v1.applications import router as applications_router
from app.api.v1.academia import router as academia_router
from app.api.v1.industry import router as industry_router
from app.api.v1.admin import router as admin_router
from app.api.v1.jobs import router as jobs_router
from app.api.v1.interviews import router as interviews_router
from app.api.v1.payments import router as payments_router

api_router = APIRouter()

api_router.include_router(auth_router)
api_router.include_router(profiles_router)
api_router.include_router(documents_router)
api_router.include_router(taxonomy_router)
api_router.include_router(matching_router)
api_router.include_router(roadmaps_router)
api_router.include_router(opportunities_router)
api_router.include_router(applications_router)
api_router.include_router(academia_router)
api_router.include_router(industry_router)
api_router.include_router(admin_router)
api_router.include_router(jobs_router)
api_router.include_router(interviews_router)
api_router.include_router(payments_router)

