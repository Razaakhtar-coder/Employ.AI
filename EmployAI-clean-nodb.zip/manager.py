import asyncio
import os
from typing import List, Optional, Dict, Any
from app.services.job_providers.base import JobProviderAdapter
from app.services.job_providers.themuse import TheMuseProvider
from app.services.job_providers.weworkremotely import WeWorkRemotelyProvider
from app.services.job_providers.findwork import FindworkProvider
from app.services.job_providers.jooble import JoobleProvider
from app.services.job_providers.usajobs import USAJobsProvider
from app.services.job_providers.arbeitnow import ArbeitnowProvider
from app.services.job_providers.remoteok import RemoteOKProvider
from app.services.job_providers.remotive import RemotiveProvider
from app.services.job_providers.jobicy import JobicyProvider
from app.services.job_providers.himalayas import HimalayasProvider
from app.services.job_providers.adzuna_jsearch import JSearchProvider, AdzunaProvider
from app.services.job_providers.linkedin import LinkedInProvider
from app.services.job_providers.naukri import NaukriProvider
from app.services.job_providers.remote_com import RemoteDotComProvider
from app.services.job_providers.instahyre import InstahyreProvider
from app.services.job_providers.careerhound import CareerhoundProvider
from app.services.job_providers.wellfound import WellfoundProvider
from app.services.job_providers.yc_startup import YCWorkAtAStartupProvider
from app.services.job_providers.cutshort import CutshortProvider
from app.services.job_providers.otta import OttaProvider
from app.schemas.job import RawJobPosting
from app.core.config import settings


class JobProviderManager:
    """
    Coordinator and registry for all external job provider adapters.
    Executes multi-provider aggregation concurrently with timeout safeguards and error isolation.
    """

    def __init__(self):
        self._providers: Dict[str, JobProviderAdapter] = {}

        # 1. Curated Low-Competition & High-Intent Providers
        self.register_provider(RemoteDotComProvider())
        self.register_provider(InstahyreProvider())
        self.register_provider(CareerhoundProvider())
        self.register_provider(WellfoundProvider())
        self.register_provider(YCWorkAtAStartupProvider())
        self.register_provider(CutshortProvider())
        self.register_provider(OttaProvider())

        # 2. Verified Global Remote Providers
        self.register_provider(RemotiveProvider())
        self.register_provider(HimalayasProvider())
        self.register_provider(JobicyProvider())
        self.register_provider(ArbeitnowProvider())
        self.register_provider(RemoteOKProvider())
        self.register_provider(WeWorkRemotelyProvider())

        # 3. Enterprise & High-Volume Portals
        self.register_provider(LinkedInProvider())
        self.register_provider(NaukriProvider())
        self.register_provider(TheMuseProvider())
        self.register_provider(FindworkProvider())
        self.register_provider(JoobleProvider())
        self.register_provider(USAJobsProvider())
        self.register_provider(JSearchProvider())
        self.register_provider(AdzunaProvider())

    def register_provider(self, provider: JobProviderAdapter):
        """Register a new job provider adapter."""
        self._providers[provider.name.lower()] = provider
        print(f"[INFO] Registered Job Provider Adapter: {provider.name} (enabled={provider.is_enabled})")

    def get_provider(self, name: str) -> Optional[JobProviderAdapter]:
        return self._providers.get(name.lower())

    def list_active_providers(self) -> List[str]:
        return [p.name for p in self._providers.values() if p.is_enabled]

    def get_providers_metadata(self) -> List[Dict[str, Any]]:
        """Return rich configuration and operational status for all registered adapters."""
        metadata = []
        low_crowd_names = {"remote.com", "instahyre", "careerhound.io", "wellfound", "yc startups", "cutshort", "otta"}
        key_mapping = {
            "remote.com": "REMOTE_COM_API_KEY",
            "instahyre": "INSTAHYRE_API_KEY",
            "careerhound.io": "CAREERHOUND_API_KEY",
            "wellfound": "WELLFOUND_API_KEY",
            "yc startups": "YC_STARTUP_API_KEY",
            "cutshort": "CUTSHORT_API_KEY",
            "otta": "OTTA_API_KEY",
            "the muse": "THEMUSE_API_KEY",
            "jooble": "JOOBLE_API_KEY",
            "findwork": "FINDWORK_API_KEY",
            "jsearch (linkedin/indeed aggregator)": "RAPIDAPI_KEY",
            "adzuna": "ADZUNA_APP_KEY",
            "usajobs": "USAJOBS_API_KEY"
        }

        for p in self._providers.values():
            n_low = p.name.lower()
            is_low_crowd = n_low in low_crowd_names or getattr(p, "crowd_level", "moderate") == "low"
            api_env_key = key_mapping.get(n_low, "")
            has_custom_key = bool(getattr(p, "api_key", False)) or bool(os.getenv(api_env_key, ""))

            category = "Curated Low-Crowd" if is_low_crowd else (
                "Global Remote" if "remote" in n_low or n_low in ["himalayas", "jobicy", "arbeitnow", "weworkremotely"]
                else "Enterprise Portals"
            )

            metadata.append({
                "name": p.name,
                "key": n_low.replace(" ", "_").replace(".", "_"),
                "category": category,
                "crowd_level": "low" if is_low_crowd else ("moderate" if "remote" in n_low else "standard"),
                "is_enabled": p.is_enabled,
                "is_configured": has_custom_key,
                "has_live_feed": True,
                "description": getattr(p, "description", f"Live verified career integration for {p.name}."),
                "api_key_name": api_env_key
            })

        return metadata

    def update_provider_key(self, provider_key: str, api_key: str) -> bool:
        """Dynamically update an adapter's API key at runtime and persist to .env."""
        clean_key = provider_key.lower().replace("_", " ").replace("-", " ")
        provider = None
        for name, p in self._providers.items():
            if name.replace(".", "").replace(" ", "") == clean_key.replace(".", "").replace(" ", ""):
                provider = p
                break

        if provider and hasattr(provider, "api_key"):
            provider.api_key = api_key
            print(f"[INFO] Dynamically updated API key for provider {provider.name}")

        # Update runtime settings
        key_env_map = {
            "remote_com": "REMOTE_COM_API_KEY",
            "instahyre": "INSTAHYRE_API_KEY",
            "careerhound": "CAREERHOUND_API_KEY",
            "careerhound_io": "CAREERHOUND_API_KEY",
            "wellfound": "WELLFOUND_API_KEY",
            "yc_startups": "YC_STARTUP_API_KEY",
            "cutshort": "CUTSHORT_API_KEY",
            "otta": "OTTA_API_KEY",
            "themuse": "THEMUSE_API_KEY",
            "jooble": "JOOBLE_API_KEY",
            "findwork": "FINDWORK_API_KEY",
            "rapidapi": "RAPIDAPI_KEY",
            "adzuna": "ADZUNA_APP_KEY"
        }

        env_var = key_env_map.get(provider_key.lower())
        if env_var:
            os.environ[env_var] = api_key
            if hasattr(settings, env_var):
                setattr(settings, env_var, api_key)

            # Persist to .env file if it exists
            env_file_path = os.path.join(os.getcwd(), ".env")
            if not os.path.exists(env_file_path):
                env_file_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), ".env")

            if os.path.exists(env_file_path):
                try:
                    with open(env_file_path, "r", encoding="utf-8") as f:
                        lines = f.readlines()
                    found = False
                    new_lines = []
                    for line in lines:
                        if line.startswith(f"{env_var}="):
                            new_lines.append(f'{env_var}="{api_key}"\n')
                            found = True
                        else:
                            new_lines.append(line)
                    if not found:
                        new_lines.append(f'{env_var}="{api_key}"\n')
                    with open(env_file_path, "w", encoding="utf-8") as f:
                        f.writelines(new_lines)
                except Exception as e:
                    print(f"[WARN] Failed to write {env_var} to .env: {e}")

            return True
        return False

    async def _safe_fetch(self, p: JobProviderAdapter, **kwargs) -> List[RawJobPosting]:
        """Wrap provider fetch with strict 8.0s timeout safeguard to guarantee instantaneous response."""
        try:
            return await asyncio.wait_for(p.fetch_jobs(**kwargs), timeout=8.0)
        except asyncio.TimeoutError:
            print(f"[WARN] Provider '{p.name}' timed out after 8.0s; continuing without delay.")
            return []
        except Exception as e:
            print(f"[ERROR] Provider '{p.name}' failed with error: {e}")
            return []

    async def fetch_all(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        """Fetch raw listings concurrently from all active providers with strict timeout safeguards."""
        active_providers = [p for p in self._providers.values() if p.is_enabled]
        if not active_providers:
            return []

        tasks = [
            self._safe_fetch(p, query=query, location=location, remote=remote, job_type=job_type, page=page)
            for p in active_providers
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)
        all_postings: List[RawJobPosting] = []

        for res in results:
            if isinstance(res, list):
                all_postings.extend(res)

        return all_postings


# Global singleton instance
job_provider_manager = JobProviderManager()

