from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user
from app.models.user import User
from app.models.profile import StudentProfile, AcademicProfile, IndustryProfile
from app.models.taxonomy import StudentSkill, Skill
from app.schemas.profile import (
    StudentProfileResponse, StudentProfileUpdate, StudentSkillItem,
    AcademicProfileResponse, AcademicProfileUpdate,
    IndustryProfileResponse, IndustryProfileUpdate
)

router = APIRouter(prefix="/profiles", tags=["Profiles"])


@router.get("/student/me", response_model=StudentProfileResponse)
def get_my_student_profile(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieve current student profile including all verified skills."""
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        profile = StudentProfile(user_id=current_user.id, profile_completion_pct=40)
        db.add(profile)
        db.commit()
        db.refresh(profile)

    # Automatically synchronize candidate department & target_domain from authentic resume analysis
    from app.models.document import AnalysisResult
    latest_analysis = (
        db.query(AnalysisResult)
        .filter(AnalysisResult.student_profile_id == profile.id)
        .order_by(AnalysisResult.created_at.desc())
        .first()
    )
    if latest_analysis and latest_analysis.detected_domain:
        det = latest_analysis.detected_domain.strip()
        if det and det != "General Professional":
            if profile.department in (None, "", "Computer Science & Engineering", "Computer Science") or not profile.department:
                profile.department = det
                profile.target_domain = det
                db.commit()
                db.refresh(profile)

    st_skills = db.query(StudentSkill).filter(StudentSkill.student_profile_id == profile.id).all()
    skills_items = []
    for ss in st_skills:
        skill = db.query(Skill).filter(Skill.id == ss.skill_id).first()
        if skill:
            skills_items.append(StudentSkillItem(
                skill_id=skill.id,
                skill_name=skill.canonical_name,
                domain=skill.domain,
                proficiency=ss.proficiency,
                source=ss.source,
                evidence_snippet=ss.evidence_snippet
            ))

    res = StudentProfileResponse.model_validate(profile)
    res.skills = skills_items
    return res


@router.put("/student/me", response_model=StudentProfileResponse)
def update_my_student_profile(
    data: StudentProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update student profile details."""
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not profile:
        profile = StudentProfile(user_id=current_user.id)
        db.add(profile)

    update_dict = data.model_dump(exclude_unset=True)
    for k, v in update_dict.items():
        setattr(profile, k, v)

    # Recompute completion percentage
    filled_fields = sum(1 for field in [profile.degree, profile.department, profile.cgpa, profile.bio, profile.location, profile.target_domain] if field)
    profile.profile_completion_pct = min(100, int((filled_fields / 6) * 60) + 40)

    db.commit()
    db.refresh(profile)
    return get_my_student_profile(current_user, db)


@router.get("/academic/me", response_model=AcademicProfileResponse)
def get_my_academic_profile(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieve TPO/Academia profile."""
    profile = db.query(AcademicProfile).filter(AcademicProfile.user_id == current_user.id).first()
    if not profile:
        profile = AcademicProfile(user_id=current_user.id)
        db.add(profile)
        db.commit()
        db.refresh(profile)
    return profile


@router.put("/academic/me", response_model=AcademicProfileResponse)
def update_my_academic_profile(
    data: AcademicProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    profile = db.query(AcademicProfile).filter(AcademicProfile.user_id == current_user.id).first()
    if not profile:
        profile = AcademicProfile(user_id=current_user.id)
        db.add(profile)

    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(profile, k, v)
    db.commit()
    db.refresh(profile)
    return profile


@router.get("/industry/me", response_model=IndustryProfileResponse)
def get_my_industry_profile(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieve recruiter/industry profile."""
    profile = db.query(IndustryProfile).filter(IndustryProfile.user_id == current_user.id).first()
    if not profile:
        profile = IndustryProfile(user_id=current_user.id, company_name="Enterprise Partner")
        db.add(profile)
        db.commit()
        db.refresh(profile)
    return profile


@router.put("/industry/me", response_model=IndustryProfileResponse)
def update_my_industry_profile(
    data: IndustryProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    profile = db.query(IndustryProfile).filter(IndustryProfile.user_id == current_user.id).first()
    if not profile:
        profile = IndustryProfile(user_id=current_user.id)
        db.add(profile)

    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(profile, k, v)
    db.commit()
    db.refresh(profile)
    return profile
