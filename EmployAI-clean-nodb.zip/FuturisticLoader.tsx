import React from 'react';
import { Sparkles, Globe, Cpu, RefreshCw, Zap, ShieldCheck } from 'lucide-react';

export interface FuturisticLoaderProps {
  title?: string;
  subtitle?: string;
  size?: 'sm' | 'md' | 'lg';
  icon?: 'sparkles' | 'globe' | 'cpu' | 'refresh' | 'zap' | 'shield' | React.ReactNode;
  showBars?: boolean;
  style?: React.CSSProperties;
  className?: string;
}

export const FuturisticLoader: React.FC<FuturisticLoaderProps> = ({
  title,
  subtitle,
  size = 'md',
  icon = 'sparkles',
  showBars = true,
  style,
  className = ''
}) => {
  const renderIcon = () => {
    if (React.isValidElement(icon)) return icon;
    const iconSize = size === 'sm' ? 14 : size === 'lg' ? 24 : 18;
    switch (icon) {
      case 'globe':
        return <Globe size={iconSize} />;
      case 'cpu':
        return <Cpu size={iconSize} />;
      case 'refresh':
        return <RefreshCw size={iconSize} className="animate-spin" />;
      case 'zap':
        return <Zap size={iconSize} />;
      case 'shield':
        return <ShieldCheck size={iconSize} />;
      case 'sparkles':
      default:
        return <Sparkles size={iconSize} />;
    }
  };

  return (
    <div 
      className={`futuristic-loader-root ${className}`}
      style={style}
    >
      {/* 3D Animated Orbital Stage */}
      <div className={`futuristic-loader-stage size-${size}`}>
        <div className="loader-radar-wave" />
        <div className="loader-orbit-outer" />
        <div className="loader-orbit-inner" />
        <div className="loader-core-orb">
          {renderIcon()}
        </div>
      </div>

      {/* Optional Equalizer Data Frequency Spectrum */}
      {showBars && (
        <div className="loader-freq-bars">
          {[0, 0.2, 0.4, 0.1, 0.35, 0.5, 0.15, 0.3].map((delay, idx) => (
            <div 
              key={idx} 
              className="loader-freq-bar" 
              style={{ animationDelay: `${delay}s` }} 
            />
          ))}
        </div>
      )}

      {/* Informative Modern Headings */}
      {(title || subtitle) && (
        <div style={{ maxWidth: '600px', margin: '0 auto' }}>
          {title && (
            <h4 style={{ 
              fontSize: size === 'sm' ? '0.9rem' : size === 'lg' ? '1.25rem' : '1.05rem', 
              fontWeight: 750, 
              color: 'var(--text-primary)', 
              marginBottom: '0.35rem',
              letterSpacing: '-0.01em',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem'
            }}>
              {title}
            </h4>
          )}
          {subtitle && (
            <p style={{ 
              fontSize: size === 'sm' ? '0.75rem' : '0.825rem', 
              color: 'var(--text-muted)', 
              margin: 0, 
              lineHeight: 1.5 
            }}>
              {subtitle}
            </p>
          )}
        </div>
      )}
    </div>
  );
};

export default FuturisticLoader;
