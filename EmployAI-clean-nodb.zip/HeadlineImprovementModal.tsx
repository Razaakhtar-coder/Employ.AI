import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { documentApi } from '../services/api';
import { 
  Wand2, Check, X, Edit3, RefreshCw, 
  AlertCircle, ShieldCheck
} from 'lucide-react';
import { FuturisticLoader } from './FuturisticLoader';

export interface HeadlineImprovementModalProps {
  isOpen: boolean;
  onClose: () => void;
  name?: string;
  domain?: string;
  skills?: string[];
  experienceRoles?: string[];
  targetJob?: string;
  onApply: (headline: string) => void;
}

export const HeadlineImprovementModal: React.FC<HeadlineImprovementModalProps> = ({
  isOpen,
  onClose,
  name,
  domain,
  skills,
  experienceRoles,
  targetJob,
  onApply,
}) => {
  const [headlines, setHeadlines] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedIdx, setSelectedIdx] = useState<number>(0);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editedText, setEditedText] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const fetchHeadlines = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const res = await documentApi.generateHeadlines({
        name: name,
        domain: domain,
        skills: skills,
        experience_roles: experienceRoles,
        target_job: targetJob
      });
      setHeadlines(res.headlines || []);
      if (res.headlines && res.headlines.length > 0) {
        setSelectedIdx(0);
        setEditedText(res.headlines[0]);
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to generate headlines.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setIsEditing(false);
      fetchHeadlines();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSelect = (idx: number) => {
    setSelectedIdx(idx);
    setEditedText(headlines[idx]);
  };

  const handleApply = () => {
    const textToApply = isEditing ? editedText.trim() : (headlines[selectedIdx] || editedText.trim());
    if (!textToApply) return;
    onApply(textToApply);
    onClose();
  };

  const modalNode = (
    <div 
      className="modal-backdrop" 
      onClick={onClose} 
      style={{ 
        position: 'fixed',
        inset: 0,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100vw',
        height: '100vh',
        backgroundColor: 'rgba(3, 7, 18, 0.82)',
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 99999,
        padding: '1.25rem',
        boxSizing: 'border-box'
      }}
    >
      <div 
        className="glass-card modal-content" 
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '90%',
          maxWidth: '680px',
          maxHeight: '85vh',
          display: 'flex',
          flexDirection: 'column',
          padding: '1.75rem',
          borderRadius: '16px',
          background: 'var(--bg-modal)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-modal)',
          boxSizing: 'border-box'
        }}
      >
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div style={{ padding: '0.45rem', borderRadius: '10px', background: 'rgba(56, 189, 248, 0.12)', color: 'var(--accent-cyan)' }}>
              <Wand2 size={22} />
            </div>
            <div>
              <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                Professional Headline Generator
              </h2>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                AI-crafted headlines optimized for recruiter search and ATS parsing.
              </p>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <button
              type="button"
              onClick={fetchHeadlines}
              className="btn btn-secondary btn-sm"
              disabled={isLoading}
              style={{ fontSize: '0.72rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
            >
              <RefreshCw size={12} className={isLoading ? 'animate-spin-slow' : ''} />
              Regenerate
            </button>
            <button
              type="button"
              onClick={onClose}
              className="btn btn-ghost btn-sm"
              style={{ padding: '0.35rem', color: 'var(--text-muted)' }}
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {error && (
          <div style={{ padding: '0.6rem 0.85rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.1)', border: '1px solid rgba(244, 63, 94, 0.3)', color: '#fb7185', fontSize: '0.78rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <AlertCircle size={14} />
            <span>{error}</span>
          </div>
        )}

        {/* Headlines List */}
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {isLoading ? (
            <div style={{ textAlign: 'center', padding: '2rem 1rem' }}>
              <FuturisticLoader
                size="sm"
                icon="sparkles"
                title="Generating Tailored Headlines..."
                subtitle={`Synthesizing high-impact headlines for ${domain || 'your domain'}`}
              />
            </div>
          ) : (
            headlines.map((hl, idx) => {
              const isSelected = selectedIdx === idx;

              return (
                <div
                  key={idx}
                  onClick={() => handleSelect(idx)}
                  style={{
                    padding: '0.9rem 1.15rem',
                    borderRadius: '10px',
                    background: isSelected ? 'rgba(56, 189, 248, 0.12)' : 'var(--bg-tertiary)',
                    border: isSelected ? '1.5px solid var(--accent-cyan)' : '1px solid var(--border-subtle)',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: '1rem',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: '0.68rem', color: isSelected ? 'var(--accent-cyan)' : 'var(--text-muted)', fontWeight: 700, marginBottom: '0.2rem' }}>
                      Option {idx + 1}
                    </div>
                    <div style={{ fontSize: '0.92rem', fontWeight: 600, color: 'var(--text-primary)', lineHeight: 1.4 }}>
                      {hl}
                    </div>
                  </div>

                  {isSelected ? (
                    <div style={{ color: 'var(--accent-cyan)', display: 'flex', alignItems: 'center', gap: '0.2rem', fontSize: '0.75rem', fontWeight: 700, flexShrink: 0 }}>
                      <Check size={16} /> Selected
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelect(idx);
                      }}
                      className="btn btn-ghost btn-sm"
                      style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}
                    >
                      Select
                    </button>
                  )}
                </div>
              );
            })
          )}

          {isEditing && (
            <div style={{ marginTop: '0.5rem', background: 'var(--bg-tertiary)', padding: '0.85rem', borderRadius: '8px', border: '1px solid var(--border-glass)' }}>
              <label style={{ display: 'block', fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: '0.35rem', fontWeight: 700 }}>
                Customize Headline:
              </label>
              <input
                type="text"
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
                className="resume-doc-input"
                style={{ width: '100%', fontSize: '0.88rem' }}
              />
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '1.25rem', borderTop: '1px solid var(--border-subtle)', marginTop: '0.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.7rem', color: 'var(--text-muted)' }}>
            <ShieldCheck size={13} color="#10b981" />
            <span>Anchored directly to detected skills and verified domain.</span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
            <button
              type="button"
              onClick={onClose}
              className="btn btn-secondary btn-sm"
              style={{ fontSize: '0.75rem' }}
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => setIsEditing(prev => !prev)}
              className="btn btn-ghost btn-sm"
              style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
            >
              <Edit3 size={12} /> {isEditing ? 'Done Editing' : 'Edit Text'}
            </button>
            <button
              type="button"
              onClick={handleApply}
              disabled={isLoading || headlines.length === 0}
              className="btn btn-primary btn-sm"
              style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}
            >
              <Check size={13} /> Apply Headline
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalNode, document.body) : modalNode;
};
