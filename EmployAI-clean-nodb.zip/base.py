from abc import ABC, abstractmethod
from typing import List, Optional
from app.schemas.job import RawJobPosting


class JobProviderAdapter(ABC):
    """
    Standard interface for all external job aggregators.
    Enables pluggable, interchangeable providers without changing core matching logic.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Provider identifier name, e.g. 'arbeitnow', 'remoteok', 'jsearch', 'adzuna'."""
        pass

    @property
    def is_enabled(self) -> bool:
        """Indicates whether this provider is currently configured and active."""
        return True

    @abstractmethod
    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        """
        Fetch raw job listings from the provider's API.
        Must return a list of standardized RawJobPosting objects.
        """
        pass
