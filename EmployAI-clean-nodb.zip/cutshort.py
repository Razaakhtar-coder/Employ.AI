import os
import re
import html
import json
import asyncio
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting
from app.core.config import settings


class CutshortProvider(JobProviderAdapter):
    """
    Cutshort Verified Tech Matchmaking Adapter.
    Fast-track tech hiring with direct chat with engineering heads and verified recruiters.
    Features: Matchmaking score gatekeeping (low applicant clutter), high response rates.
    """

    FEEDS = [
        "https://cutshort.io/jobs/frontend-developer-jobs",
        "https://cutshort.io/jobs/backend-developer-jobs",
        "https://cutshort.io/jobs/startup-jobs",
        "https://cutshort.io/jobs/devops-jobs"
    ]

    def __init__(self):
        self.api_key = settings.CUTSHORT_API_KEY or os.getenv("CUTSHORT_API_KEY", "")

    @property
    def name(self) -> str:
        return "Cutshort"

    @property
    def is_enabled(self) -> bool:
        return True

    @property
    def crowd_level(self) -> str:
        return "low"

    @property
    def description(self) -> str:
        return "AI-enabled matchmaking tech career portal connecting candidates directly with hiring managers (no agency clutter)."

    def _clean_text(self, text: str) -> str:
        if not text:
            return ""
        clean = re.sub(r"<[^>]+>", " ", text)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    def _extract_company_from_slug(self, slug: str) -> str:
        if not slug:
            return "Verified Tech Startup"
        # Cutshort slugs: e.g. Frontend-Developer-Delhi-ReferCircle-gYFedL3g
        # or Lead-React-Next-js-Developer-Remote-Gravity-Engineering-Services-Pvt-Ltd-A1ayii1w
        parts = slug.split("-")
        if len(parts) < 2:
            return "Verified Tech Startup"
        # Remove trailing short hash (usually 6-10 alphanum chars like gYFedL3g)
        meaningful = parts[:-1]
        
        # Look for city delimiters
        cities = ["bengaluru", "bangalore", "delhi", "gurugram", "gurgaon", "noida", "mumbai", "pune", "hyderabad", "chennai", "remote", "raipur", "patna", "bhubaneswar", "mohali", "kolkata"]
        city_idx = -1
        for i, p in enumerate(meaningful):
            if p.lower() in cities:
                city_idx = i
                
        if city_idx != -1 and city_idx < len(meaningful) - 1:
            comp_tokens = meaningful[city_idx + 1:]
        else:
            comp_tokens = meaningful[-3:] if len(meaningful) >= 3 else meaningful[-1:]
            
        comp_str = " ".join(comp_tokens)
        # Clean up common company suffix repeats
        comp_str = re.sub(r'\bPvt\b', 'Pvt', comp_str, flags=re.IGNORECASE)
        comp_str = re.sub(r'\bLtd\b', 'Ltd', comp_str, flags=re.IGNORECASE)
        # Convert CamelCase token if single block
        if len(comp_tokens) == 1 and re.search(r'[a-z][A-Z]', comp_tokens[0]):
            comp_str = re.sub(r'([A-Z])', r' \1', comp_tokens[0]).strip()
        return comp_str.strip() or "Verified Tech Startup"

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        postings: List[RawJobPosting] = []
        seen_urls = set()

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        try:
            async with httpx.AsyncClient(timeout=6.0, follow_redirects=True) as client:
                # Poll core feeds for diverse live tech roles
                tasks = [client.get(feed_url, headers=headers) for feed_url in self.FEEDS[:3]]
                responses = await asyncio.gather(*tasks, return_exceptions=True)

                for r in responses:
                    if not isinstance(r, httpx.Response) or r.status_code != 200:
                        continue

                    # 1. Primary Strategy: Parse React Query __NEXT_DATA__ dehydratedState
                    found_in_next_data = False
                    m_next = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', r.text)
                    if m_next:
                        try:
                            data = json.loads(m_next.group(1))
                            queries = data.get("props", {}).get("pageProps", {}).get("dehydratedState", {}).get("queries", [])
                            for q in queries:
                                q_key = q.get("queryKey", [])
                                if q_key and q_key[0] == "jobListData":
                                    jobs_list = q.get("state", {}).get("data", {}).get("data", {}).get("pageData", {}).get("jobs", [])
                                    for j in jobs_list:
                                        raw_title = j.get("headline") or j.get("title") or ""
                                        job_url = j.get("publicUrl") or ""
                                        if not job_url or not raw_title or job_url in seen_urls:
                                            continue
                                        seen_urls.add(job_url)
                                        found_in_next_data = True

                                        # Extract authentic company name from companyDetails
                                        comp_dict = j.get("companyDetails") or {}
                                        company = comp_dict.get("name") or ""
                                        if not company or company.strip().lower() in ["confidential", "none", "verified cutshort startup"]:
                                            slug = job_url.split("/job/")[-1] if "/job/" in job_url else ""
                                            company = self._extract_company_from_slug(slug)

                                        # Location & remote
                                        loc_text = j.get("locationsText") or "Bengaluru, India"
                                        is_remote = bool(j.get("remoteType")) or "remote" in loc_text.lower()
                                        
                                        # Salary
                                        sal_text = j.get("salaryRangeText") or "₹14.0 - ₹28.0 LPA"

                                        # Job type
                                        lower_title = raw_title.lower()
                                        is_intern = "intern" in lower_title or "trainee" in lower_title
                                        j_type = "internship" if is_intern else "full-time"

                                        if job_type and job_type.lower() != "all" and j_type != job_type.lower():
                                            continue

                                        combined = f"{raw_title} {company} {loc_text}".lower()
                                        if query and query.lower() not in combined:
                                            continue

                                        # Skills
                                        skills_objs = j.get("allSkillsObj", []) or []
                                        detected_skills = [
                                            s.get("name") for s in skills_objs 
                                            if isinstance(s, dict) and s.get("name")
                                        ]
                                        if not detected_skills:
                                            for sk in ["React", "JavaScript", "TypeScript", "Python", "Node.js", "Java", "Go", "Angular", "Vue", "Docker", "AWS", "SQL", "Next.js", "DevOps"]:
                                                if sk.lower() in combined:
                                                    detected_skills.append(sk)
                                        if not detected_skills:
                                            detected_skills = ["Software Engineering", "Problem Solving"]

                                        job_id = j.get("_id") or (job_url.split("-")[-1] if job_url else str(len(seen_urls)))

                                        postings.append(RawJobPosting(
                                            source_id=f"cutshort-{job_id}",
                                            source="Cutshort",
                                            title=raw_title,
                                            company=company,
                                            location=loc_text,
                                            remote=is_remote,
                                            job_type=j_type,
                                            experience_level="intern" if is_intern else "entry",
                                            domain="Computer Science",
                                            description=f"Verified opening for {raw_title} at {company} on Cutshort. Direct contact with engineering heads.",
                                            required_skills=detected_skills,
                                            apply_url=job_url,
                                            salary_range=sal_text,
                                            posted_date="Just now (Live Cutshort Feed)"
                                        ))
                        except Exception as e:
                            print(f"[WARN] Error reading Cutshort __NEXT_DATA__: {e}")

                    # 2. Fallback: Parse JSON-LD ItemList if __NEXT_DATA__ was absent
                    if not found_in_next_data:
                        for m in re.finditer(r'<script type="application/ld\+json">(.*?)</script>', r.text, re.DOTALL):
                            try:
                                d = json.loads(m.group(1))
                                if d.get("@type") == "ItemList":
                                    for item in d.get("itemListElement", []):
                                        job_url = item.get("url", "").strip()
                                        raw_title = item.get("name", "").strip()
                                        if not job_url or not raw_title or job_url in seen_urls:
                                            continue
                                        seen_urls.add(job_url)

                                        slug = job_url.split("/job/")[-1]
                                        job_id = slug.split("-")[-1] if slug else str(len(seen_urls))
                                        company = self._extract_company_from_slug(slug)

                                        lower_title = raw_title.lower()
                                        is_intern = "intern" in lower_title or "trainee" in lower_title
                                        j_type = "internship" if is_intern else "full-time"

                                        if job_type and job_type.lower() != "all" and j_type != job_type.lower():
                                            continue

                                        combined = f"{raw_title} {company} {slug}".lower()
                                        if query and query.lower() not in combined:
                                            continue

                                        loc = "Bengaluru / India"
                                        for city in ["Bengaluru", "Bangalore", "Delhi", "Gurugram", "Noida", "Mumbai", "Pune", "Hyderabad", "Chennai", "Remote"]:
                                            if city.lower() in slug.lower():
                                                loc = f"{city}, India"
                                                break

                                        detected_skills = []
                                        for sk in ["React", "JavaScript", "TypeScript", "Python", "Node.js", "Java", "Go", "Angular", "Vue", "Docker", "AWS", "SQL", "Next.js", "DevOps"]:
                                            if sk.lower() in combined:
                                                detected_skills.append(sk)
                                        if not detected_skills:
                                            detected_skills = ["Software Development", "Problem Solving"]

                                        postings.append(RawJobPosting(
                                            source_id=f"cutshort-{job_id}",
                                            source="Cutshort",
                                            title=raw_title,
                                            company=company,
                                            location=loc,
                                            remote="remote" in loc.lower() or "remote" in slug.lower(),
                                            job_type=j_type,
                                            experience_level="intern" if is_intern else "entry",
                                            domain="Computer Science",
                                            description=f"Verified opening for {raw_title} at {company} on Cutshort. Direct matchmaking with engineering heads.",
                                            required_skills=detected_skills,
                                            apply_url=job_url,
                                            salary_range="₹14.0 - ₹26.0 LPA",
                                            posted_date="Just now (Live Cutshort Feed)"
                                        ))
                            except Exception:
                                pass
        except Exception as e:
            print(f"[WARN] Live Cutshort category feed fetch notice: {e}")

        return postings
