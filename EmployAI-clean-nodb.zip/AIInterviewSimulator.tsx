import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Mic, MicOff, Volume2, VolumeX, Play, RotateCcw, 
  Award, TrendingUp, CheckCircle2, AlertTriangle, AlertCircle, HelpCircle,
  Clock, ArrowRight, ShieldCheck, ChevronDown, ChevronUp,
  Sparkles, Trash2, Layers, Lightbulb, FileText, X,
  BookOpen, Code2, Briefcase, GraduationCap, XCircle,
  Upload, UploadCloud, RefreshCw, Zap, UserCheck, Radio
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { FuturisticLoader } from './FuturisticLoader';
import { useAuth } from '../context/AuthContext';
import { interviewApi, documentApi } from '../services/api';
import type { 
  InterviewSession, InterviewQuestion, 
  QuestionEvaluationResponse, InterviewHistoryData,
  ResumeAnalysisResult
} from '../types';

export interface AIInterviewSimulatorProps {
  onNavigateToResume?: () => void;
}

const AIInterviewSimulatorComponent: React.FC<AIInterviewSimulatorProps> = ({ onNavigateToResume }) => {
  const { isAuthenticated, openAuthModal, user } = useAuth();

  // Navigation & View State
  const [activeTab, setActiveTab] = useState<'studio' | 'history'>('studio');
  const [simulatorState, setSimulatorState] = useState<'setup' | 'active' | 'completed'>('setup');

  // Config State for Setup
  const [targetRole, setTargetRole] = useState<string>('Software Engineer');
  const [interviewType, setInterviewType] = useState<string>('comprehensive');
  const [difficulty, setDifficulty] = useState<string>('intermediate');
  const [numQuestions, setNumQuestions] = useState<number>(5);

  // Resume Grounding Data & Upload State
  const [latestResume, setLatestResume] = useState<ResumeAnalysisResult | null>(null);
  const [resumeFacts, setResumeFacts] = useState<any>(null);
  const [isLoadingResumeData, setIsLoadingResumeData] = useState<boolean>(true);
  const [isUploadingResume, setIsUploadingResume] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isResumeModalOpen, setIsResumeModalOpen] = useState<boolean>(false);
  const [activeResumeTab, setActiveResumeTab] = useState<'projects' | 'skills' | 'experience' | 'education' | 'raw'>('projects');
  const [showUploadResumePrompt, setShowUploadResumePrompt] = useState<boolean>(false);

  // Active Session State
  const [currentSession, setCurrentSession] = useState<InterviewSession | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [userAnswerText, setUserAnswerText] = useState<string>('');
  const [isSubmittingAnswer, setIsSubmittingAnswer] = useState<boolean>(false);
  const [currentEvaluation, setCurrentEvaluation] = useState<QuestionEvaluationResponse | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [isGeneratingInterview, setIsGeneratingInterview] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Pre-interview Countdown & Posture Calibration State
  const [isCountingDown, setIsCountingDown] = useState<boolean>(false);
  const [countdownSeconds, setCountdownSeconds] = useState<number>(3);
  const countdownIntervalRef = useRef<any>(null);
  const countdownCancelledRef = useRef<boolean>(false);

  // Voice & Audio State
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [isSpeakingQuestion, setIsSpeakingQuestion] = useState<boolean>(false);
  const recognitionRef = useRef<any>(null);

  // History & Progression State
  const [historyData, setHistoryData] = useState<InterviewHistoryData | null>(null);
  const [isLoadingHistory, setIsLoadingHistory] = useState<boolean>(false);
  const [selectedPastSession, setSelectedPastSession] = useState<InterviewSession | null>(null);
  const [isDeletingSessionId, setIsDeletingSessionId] = useState<string | null>(null);

  // Expandable review sections
  const [expandedQuestionIdx, setExpandedQuestionIdx] = useState<number | null>(null);

  // Timer Ref
  const timerRef = useRef<any>(null);

  // Load History (defined before useEffect to prevent temporal dead zone)
  const loadHistory = useCallback(async () => {
    setIsLoadingHistory(true);
    try {
      const data = await interviewApi.getHistory();
      setHistoryData(data);
    } catch (err) {
      console.warn('Failed to load interview history:', err);
    } finally {
      setIsLoadingHistory(false);
    }
  }, []);

  // 1. Initial Load: Fetch latest resume analysis & interview history
  useEffect(() => {
    async function initData() {
      setIsLoadingResumeData(true);
      try {
        let resume = await documentApi.getLatestAnalysis().catch(() => null);
        if (!resume) {
          try {
            const cached = localStorage.getItem('employai_active_resume_analysis');
            if (cached) resume = JSON.parse(cached);
          } catch {}
        }
        if (resume) {
          setLatestResume(resume);
          if (resume.detected_domain) {
            setTargetRole(resume.detected_domain.includes('Engineer') || resume.detected_domain.includes('Developer') ? resume.detected_domain : `${resume.detected_domain} Specialist`);
          } else if (resume.structured_resume?.headline) {
            setTargetRole(resume.structured_resume.headline);
          }
        }

        // Also fetch active resume facts from interview API
        const facts = await interviewApi.getActiveResumeFacts().catch(() => null);
        if (facts) {
          setResumeFacts(facts);
          if (!resume && facts.domain && facts.has_resume) {
            setTargetRole(facts.domain.includes('Engineer') || facts.domain.includes('Developer') ? facts.domain : `${facts.domain} Specialist`);
          }
        }
      } catch (err) {
        console.warn('Could not load latest resume facts:', err);
      } finally {
        setIsLoadingResumeData(false);
      }

      loadHistory();
    }

    initData();
  }, [loadHistory]);

  // Handle Direct Resume Upload from AI Mock Section
  const handleResumeFileSelect = async (file: File) => {
    if (!file) return;

    if (!isAuthenticated) {
      openAuthModal('login', 'student');
      return;
    }

    const validTypes = ['.pdf', '.docx', '.doc', '.txt'];
    const hasValidExt = validTypes.some(ext => file.name.toLowerCase().endsWith(ext));
    if (!hasValidExt) {
      setUploadError('Please upload a PDF, DOCX, DOC, or TXT resume file.');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setUploadError('File size exceeds 10MB limit.');
      return;
    }

    setIsUploadingResume(true);
    setUploadError(null);

    try {
      const result = await documentApi.uploadResume(file);
      setLatestResume(result);
      if (result.detected_domain) {
        setTargetRole(result.detected_domain.includes('Engineer') || result.detected_domain.includes('Developer') ? result.detected_domain : `${result.detected_domain} Specialist`);
      } else if (result.structured_resume?.headline) {
        setTargetRole(result.structured_resume.headline);
      }

      // Refresh active resume facts
      const facts = await interviewApi.getActiveResumeFacts().catch(() => null);
      if (facts) {
        setResumeFacts(facts);
      }
      setShowUploadResumePrompt(false);
      setErrorMessage(null);
    } catch (err: any) {
      console.error('Failed to upload resume from mock interview:', err);
      setUploadError(err?.message || 'Failed to upload and analyze resume. Please try again.');
    } finally {
      setIsUploadingResume(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleResumeFileSelect(e.dataTransfer.files[0]);
    }
  };

  // Timer Effect
  useEffect(() => {
    if (simulatorState === 'active') {
      timerRef.current = setInterval(() => {
        setElapsedSeconds(prev => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [simulatorState]);

  // Helper to pronounce posture guidance via Web Speech API
  const speakCountdownGuidance = useCallback(() => {
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance('Sit properly, adjust yourself.');
        utterance.rate = 0.92;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;
        window.speechSynthesis.speak(utterance);
      } catch (e) {
        console.warn('TTS playback error:', e);
      }
    }
  }, []);

  // Cleanup countdown timer & audio on unmount
  useEffect(() => {
    return () => {
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Cancel countdown before interview starts
  const handleCancelCountdown = () => {
    countdownCancelledRef.current = true;
    if (countdownIntervalRef.current) {
      clearInterval(countdownIntervalRef.current);
      countdownIntervalRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsCountingDown(false);
    setIsGeneratingInterview(false);
  };

  // 2. Start Interview Session Grounded in Uploaded Resume with 3-Second Posture Countdown
  const handleStartInterview = async () => {
    // If candidate has NOT uploaded a resume, DO NOT show the 3-second countdown timer!
    // Instead, prompt them to upload their resume first.
    if (!hasUploadedResume) {
      setIsCountingDown(false);
      setIsGeneratingInterview(false);
      setShowUploadResumePrompt(true);
      setErrorMessage(null);
      setTimeout(() => {
        fileInputRef.current?.click();
      }, 150);
      return;
    }

    setErrorMessage(null);
    setShowUploadResumePrompt(false);
    setIsGeneratingInterview(true);
    setIsCountingDown(true);
    setCountdownSeconds(3);
    countdownCancelledRef.current = false;

    // Speak "Sit properly, adjust yourself" immediately
    speakCountdownGuidance();

    // 1. Kick off parallel backend generation so questions are ready with zero delay
    const startSessionPromise = (async () => {
      try {
        const pastQuestionsSet = new Set<string>();
        if (historyData?.history && Array.isArray(historyData.history)) {
          historyData.history.forEach((sess: any) => {
            if (Array.isArray(sess.questions)) {
              sess.questions.forEach((q: any) => {
                if (q?.question) pastQuestionsSet.add(q.question);
              });
            }
            if (Array.isArray(sess.questions_json)) {
              sess.questions_json.forEach((q: any) => {
                if (q?.question) pastQuestionsSet.add(q.question);
              });
            }
          });
        }
        try {
          const cached = localStorage.getItem('employai_asked_interview_questions');
          if (cached) {
            const list = JSON.parse(cached);
            if (Array.isArray(list)) list.forEach((q: string) => pastQuestionsSet.add(q));
          }
        } catch {}

        const session = await interviewApi.startInterview({
          target_role: targetRole,
          interview_type: interviewType,
          difficulty: difficulty,
          num_questions: numQuestions,
          document_id: latestResume?.id,
          previous_questions: Array.from(pastQuestionsSet)
        });

        if (session.questions && Array.isArray(session.questions)) {
          session.questions.forEach((q: any) => {
            if (q?.question) pastQuestionsSet.add(q.question);
          });
          try {
            localStorage.setItem('employai_asked_interview_questions', JSON.stringify(Array.from(pastQuestionsSet).slice(-400)));
          } catch {}
        }

        return session;
      } catch (err: any) {
        throw err;
      }
    })();

    // 2. 3-second countdown loop
    let remaining = 3;
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);

    countdownIntervalRef.current = setInterval(async () => {
      if (countdownCancelledRef.current) {
        clearInterval(countdownIntervalRef.current);
        return;
      }

      remaining -= 1;
      setCountdownSeconds(remaining);

      if (remaining <= 0) {
        clearInterval(countdownIntervalRef.current);
        countdownIntervalRef.current = null;

        try {
          const session = await startSessionPromise;
          if (countdownCancelledRef.current) return;

          setCurrentSession(session);
          if (session.resume_snapshot) {
            setResumeFacts(session.resume_snapshot);
          }
          setCurrentQuestionIndex(0);
          setUserAnswerText('');
          setCurrentEvaluation(null);
          setElapsedSeconds(0);
          setIsCountingDown(false);
          setIsGeneratingInterview(false);
          setSimulatorState('active');
        } catch (err: any) {
          if (countdownCancelledRef.current) return;
          setIsCountingDown(false);
          setIsGeneratingInterview(false);
          setErrorMessage(err?.message || 'Failed to start interview session. Please try again.');
        }
      }
    }, 1000);
  };

  // 3. Speech Recognition (Speech-to-Text)
  const toggleVoiceRecording = () => {
    if (isRecording) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsRecording(false);
    } else {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (!SpeechRecognition) {
        alert('Speech recognition is not supported in this browser. You can type your answer directly in the box.');
        return;
      }

      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'en-US';

        recognition.onresult = (event: any) => {
          let finalTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
              finalTranscript += event.results[i][0].transcript + ' ';
            }
          }
          if (finalTranscript) {
            setUserAnswerText(prev => (prev ? `${prev.trim()} ${finalTranscript.trim()}` : finalTranscript.trim()));
          }
        };

        recognition.onerror = (event: any) => {
          console.warn('Speech recognition error:', event.error);
          setIsRecording(false);
        };

        recognition.onend = () => {
          setIsRecording(false);
        };

        recognition.start();
        recognitionRef.current = recognition;
        setIsRecording(true);
      } catch (e) {
        console.error('Failed to initialize speech recognition:', e);
        setIsRecording(false);
      }
    }
  };

  // 4. Text-to-Speech (AI Voice Reading Question)
  const toggleSpeakQuestion = (text: string) => {
    if (!('speechSynthesis' in window)) {
      alert('Text-to-speech audio is not supported in this browser.');
      return;
    }

    if (isSpeakingQuestion) {
      window.speechSynthesis.cancel();
      setIsSpeakingQuestion(false);
    } else {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      utterance.onend = () => setIsSpeakingQuestion(false);
      utterance.onerror = () => setIsSpeakingQuestion(false);
      window.speechSynthesis.speak(utterance);
      setIsSpeakingQuestion(true);
    }
  };

  // 5. Submit Current Answer for Strict Correctness Evaluation
  const handleSubmitAnswer = async () => {
    if (!currentSession || !userAnswerText.trim()) return;

    if (isRecording && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsRecording(false);
    }
    if (isSpeakingQuestion) {
      window.speechSynthesis.cancel();
      setIsSpeakingQuestion(false);
    }

    const currentQ = currentSession.questions?.[currentQuestionIndex];
    if (!currentQ) return;

    setIsSubmittingAnswer(true);
    setErrorMessage(null);

    try {
      const evalResp = await interviewApi.submitAnswer(currentSession.id, {
        question_id: currentQ.id,
        user_answer: userAnswerText.trim()
      });

      setCurrentEvaluation(evalResp);

      // Update question in local state with correctness & verdict
      const updatedQuestions = [...(currentSession.questions || [])];
      updatedQuestions[currentQuestionIndex] = {
        ...currentQ,
        user_answer: userAnswerText.trim(),
        score: evalResp.score,
        is_correct: evalResp.is_correct,
        verdict: evalResp.verdict,
        feedback: evalResp.feedback,
        strengths: evalResp.strengths,
        improvements: evalResp.improvements,
        star_breakdown: evalResp.star_breakdown,
        model_answer_snippet: evalResp.model_answer_snippet
      };

      const updatedSession = {
        ...currentSession,
        questions: updatedQuestions
      };

      setCurrentSession(updatedSession);

      try {
        if (typeof localStorage !== 'undefined') {
          localStorage.setItem('employai_client_active_session', JSON.stringify(updatedSession));
        }
      } catch (e) {
        console.warn('Failed to persist active session in localStorage:', e);
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to evaluate answer. Please try again.');
    } finally {
      setIsSubmittingAnswer(false);
    }
  };

  // 6. Move to Next Question or Complete Interview
  const handleNextQuestion = async () => {
    if (!currentSession) return;

    if (currentSession.questions && currentQuestionIndex + 1 < currentSession.questions.length) {
      setCurrentQuestionIndex(prev => prev + 1);
      setUserAnswerText('');
      setCurrentEvaluation(null);
      setErrorMessage(null);
    } else {
      // Finalize Interview
      setIsSubmittingAnswer(true);
      try {
        const completed = await interviewApi.completeInterview(
          currentSession.id, 
          elapsedSeconds, 
          currentSession.questions
        );
        setCurrentSession(completed);
        if (completed.resume_snapshot) {
          setResumeFacts(completed.resume_snapshot);
        }
        setSimulatorState('completed');

        // Confetti celebration if high score!
        if ((completed.overall_score || 0) >= 75) {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 }
          });
        }

        // Refresh History
        loadHistory();
      } catch (err: any) {
        setErrorMessage(err?.message || 'Failed to finalize interview scorecard.');
      } finally {
        setIsSubmittingAnswer(false);
      }
    }
  };

  // 7. Delete Past Session
  const handleDeleteSession = async (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this interview record from your score history?')) return;

    setIsDeletingSessionId(sessionId);
    try {
      await interviewApi.deleteSession(sessionId);
      if (selectedPastSession?.id === sessionId) {
        setSelectedPastSession(null);
      }
      loadHistory();
    } catch (err) {
      console.error('Failed to delete session:', err);
    } finally {
      setIsDeletingSessionId(null);
    }
  };

  const formatTime = (secs: number = 0) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  const currentQ: InterviewQuestion | null = 
    currentSession && currentSession.questions && currentSession.questions.length > currentQuestionIndex
      ? currentSession.questions[currentQuestionIndex]
      : null;

  // Determine if candidate has uploaded a valid resume
  const hasUploadedResume = Boolean(
    (latestResume && (latestResume.id || latestResume.document_id || (latestResume.extracted_skills && latestResume.extracted_skills.length > 0))) ||
    (resumeFacts && resumeFacts.has_resume)
  );

  // Derive extracted resume lists
  const displayProjects = Array.isArray(resumeFacts?.projects) && resumeFacts.projects.length 
    ? resumeFacts.projects 
    : (Array.isArray(latestResume?.extracted_projects) ? latestResume.extracted_projects : []);

  const displaySkills = Array.isArray(resumeFacts?.skills) && resumeFacts.skills.length
    ? resumeFacts.skills
    : (Array.isArray(latestResume?.extracted_skills) ? latestResume.extracted_skills : []);

  const displayExperience = Array.isArray(resumeFacts?.experience) && resumeFacts.experience.length
    ? resumeFacts.experience
    : (Array.isArray(latestResume?.extracted_experience) ? latestResume.extracted_experience : []);

  const displayEducation = Array.isArray(resumeFacts?.education) && resumeFacts.education.length
    ? resumeFacts.education
    : (Array.isArray(latestResume?.structured_resume?.education) ? latestResume.structured_resume.education : []);

  const candidateFullName = resumeFacts?.candidate_name 
    || latestResume?.structured_resume?.personal_info?.full_name 
    || user?.full_name
    || 'Candidate';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', width: '100%', maxWidth: '1280px', margin: '0 auto' }}>
      {/* Hidden File Input for Direct Resume Upload */}
      <input 
        type="file"
        ref={fileInputRef}
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            handleResumeFileSelect(e.target.files[0]);
          }
        }}
        accept=".pdf,.docx,.doc,.txt"
        style={{ display: 'none' }}
      />

      {/* Top Banner & Tab Navigation */}
      <div 
        className="glass-card" 
        style={{ 
          padding: '1.5rem 1.75rem', 
          background: 'var(--bg-card)', 
          border: '1px solid var(--border-subtle)',
          boxShadow: 'var(--shadow-md)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '1.25rem'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
          <div style={{
            width: '44px',
            height: '44px',
            borderRadius: '12px',
            background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.2), rgba(168, 85, 247, 0.2))',
            border: '1px solid var(--accent-cyan)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 0 16px rgba(56, 189, 248, 0.25)'
          }}>
            <Mic size={22} color="var(--accent-cyan)" />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
              <h1 style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                AI MOCK INTERVIEW & VOICE PREP ROOM
              </h1>
              {isLoadingResumeData ? (
                <span className="badge badge-cyan" style={{ fontSize: '0.65rem', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}>
                  <RefreshCw size={11} className="animate-spin-slow" /> Connecting Resume...
                </span>
              ) : hasUploadedResume ? (
                <span className="badge badge-cyan" style={{ fontSize: '0.65rem', fontWeight: 700 }}>
                  <Sparkles size={12} /> Strictly Resume-Grounded
                </span>
              ) : (
                <span 
                  className="badge" 
                  style={{ 
                    fontSize: '0.65rem', 
                    fontWeight: 700, 
                    background: 'rgba(245, 158, 11, 0.15)', 
                    color: '#fbbf24', 
                    border: '1px solid rgba(245, 158, 11, 0.35)',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.3rem'
                  }}
                >
                  <AlertCircle size={12} /> No Resume Uploaded
                </span>
              )}
            </div>
            <p style={{ fontSize: '0.825rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
              {hasUploadedResume ? (
                'All questions are generated directly from your uploaded resume. Defend your projects, skills, and track strict scores without baseline floors.'
              ) : (
                'Upload your resume to defend your real projects, skills, and experience with strictly grounded AI interview questions.'
              )}
            </p>
          </div>
        </div>

        {/* View Switcher Tabs & View / Upload Resume Button */}
        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', flexWrap: 'wrap' }}>
          {hasUploadedResume ? (
            <button
              onClick={() => setIsResumeModalOpen(true)}
              className="btn btn-outline-cyan btn-sm"
              style={{ display: 'inline-flex', alignItems: 'center', gap: '0.45rem', fontSize: '0.8rem', fontWeight: 700 }}
              title="View your uploaded resume used for this interview"
            >
              <FileText size={15} /> 📄 View Uploaded Resume
            </button>
          ) : (
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploadingResume}
              className="btn btn-outline-cyan btn-sm"
              style={{ display: 'inline-flex', alignItems: 'center', gap: '0.45rem', fontSize: '0.8rem', fontWeight: 700 }}
              title="Upload your resume to ground mock interview in your real projects"
            >
              {isUploadingResume ? (
                <>
                  <RefreshCw size={14} className="animate-spin-slow" /> Uploading...
                </>
              ) : (
                <>
                  <Upload size={14} /> Upload Resume
                </>
              )}
            </button>
          )}

          <div style={{ display: 'flex', gap: '0.35rem', background: 'rgba(0, 0, 0, 0.3)', padding: '0.3rem', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
            <button
              onClick={() => {
                setActiveTab('studio');
                if (simulatorState === 'completed') setSimulatorState('setup');
              }}
              className={`btn btn-sm ${activeTab === 'studio' ? 'btn-primary' : 'btn-ghost'}`}
              style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.8rem', fontWeight: 600 }}
            >
              <Mic size={15} /> Interview Studio
            </button>
            <button
              onClick={() => {
                setActiveTab('history');
                loadHistory();
              }}
              className={`btn btn-sm ${activeTab === 'history' ? 'btn-primary' : 'btn-ghost'}`}
              style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.8rem', fontWeight: 600 }}
            >
              <TrendingUp size={15} /> Score History & Analytics
              {historyData && historyData.total_interviews > 0 && (
                <span style={{ 
                  background: 'var(--accent-cyan)', 
                  color: '#000', 
                  fontSize: '0.65rem', 
                  padding: '0.1rem 0.4rem', 
                  borderRadius: '10px', 
                  fontWeight: 800 
                }}>
                  {historyData.total_interviews}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Error Message Toast */}
      {errorMessage && !errorMessage.includes('Operating in local mode') && (
        <div style={{ 
          padding: '0.9rem 1.25rem', 
          borderRadius: '10px', 
          background: 'rgba(239, 68, 68, 0.15)', 
          border: '1px solid rgba(239, 68, 68, 0.4)', 
          color: '#f87171',
          display: 'flex',
          alignItems: 'center',
          gap: '0.6rem',
          fontSize: '0.85rem'
        }}>
          <AlertTriangle size={18} />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Upload Resume First Warning Banner */}
      {showUploadResumePrompt && !hasUploadedResume && (
        <div style={{ 
          padding: '1.1rem 1.4rem', 
          borderRadius: '12px', 
          background: 'linear-gradient(135deg, rgba(245, 158, 11, 0.18), rgba(239, 68, 68, 0.12))', 
          border: '1.5px solid rgba(245, 158, 11, 0.55)', 
          color: '#fbbf24',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '1rem',
          fontSize: '0.9rem',
          boxShadow: '0 8px 24px rgba(245, 158, 11, 0.15)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div style={{
              width: '38px',
              height: '38px',
              borderRadius: '8px',
              background: 'rgba(245, 158, 11, 0.25)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0
            }}>
              <AlertCircle size={22} color="#fbbf24" />
            </div>
            <div>
              <div style={{ fontWeight: 800, fontSize: '0.95rem', color: '#fff' }}>
                Please Upload Your Resume First
              </div>
              <div style={{ fontSize: '0.8rem', color: 'rgba(255, 255, 255, 0.85)', marginTop: '0.15rem' }}>
                To start the AI Mock Interview, an uploaded resume is required. Questions are strictly grounded in your actual projects and skills.
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="btn btn-primary btn-sm"
              style={{ display: 'inline-flex', alignItems: 'center', gap: '0.45rem', fontSize: '0.825rem', fontWeight: 700 }}
            >
              <Upload size={14} /> Upload Resume (PDF/DOCX)
            </button>
            <button
              onClick={() => setShowUploadResumePrompt(false)}
              className="btn btn-ghost btn-sm"
              style={{ color: 'var(--text-muted)' }}
            >
              <X size={16} />
            </button>
          </div>
        </div>
      )}

      {/* TAB 1: INTERVIEW STUDIO */}
      {activeTab === 'studio' && (
        <>
          {/* 1. SETUP STAGE */}
          {simulatorState === 'setup' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {/* Clean Notice Banner when No Resume is Uploaded */}
              {!isLoadingResumeData && !hasUploadedResume && (
                <div 
                  className="glass-card" 
                  style={{ 
                    padding: '1.15rem 1.4rem', 
                    borderRadius: '12px',
                    background: 'linear-gradient(135deg, rgba(245, 158, 11, 0.08) 0%, rgba(56, 189, 248, 0.06) 100%)',
                    border: '1px solid rgba(245, 158, 11, 0.3)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    gap: '1rem',
                    boxShadow: '0 4px 16px rgba(0, 0, 0, 0.15)'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
                    <div style={{
                      width: '42px',
                      height: '42px',
                      borderRadius: '10px',
                      background: 'rgba(245, 158, 11, 0.15)',
                      border: '1px solid rgba(245, 158, 11, 0.4)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: '#fbbf24',
                      flexShrink: 0
                    }}>
                      <UploadCloud size={22} />
                    </div>
                    <div>
                      <div style={{ fontSize: '0.925rem', fontWeight: 800, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <span>Upload Your Resume For Personalized Mock Interviews</span>
                        <span className="badge" style={{ background: 'rgba(245, 158, 11, 0.2)', color: '#fbbf24', fontSize: '0.65rem' }}>
                          Recommended
                        </span>
                      </div>
                      <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
                        No resume detected. Upload your resume to unlock questions tailored to your exact projects, tech stack, and achievements, or proceed below with a standard role interview.
                      </div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploadingResume}
                      className="btn btn-outline-cyan btn-sm"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: '0.45rem', fontSize: '0.8rem', fontWeight: 700 }}
                    >
                      {isUploadingResume ? (
                        <>
                          <RefreshCw size={14} className="animate-spin-slow" />
                          Uploading...
                        </>
                      ) : (
                        <>
                          <Upload size={14} /> Upload Resume (PDF/DOCX)
                        </>
                      )}
                    </button>

                    {onNavigateToResume && (
                      <button
                        onClick={onNavigateToResume}
                        className="btn btn-secondary btn-sm"
                        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.8rem' }}
                      >
                        <FileText size={14} /> AI Resume Studio
                      </button>
                    )}
                  </div>
                </div>
              )}

              <div style={{ display: 'grid', gridTemplateColumns: 'minmax(300px, 1.8fr) minmax(280px, 1.2fr)', gap: '1.5rem', alignItems: 'start' }}>
              {/* Left Column: Interview Configuration */}
              <div className="glass-card" style={{ padding: '1.75rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <div style={{ borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0.9rem' }}>
                  <h3 style={{ fontSize: '1.15rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                    Configure Your Mock Interview
                  </h3>
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', margin: '0.25rem 0 0 0' }}>
                    Select your target role and round focus. The AI will strictly craft questions from your uploaded resume.
                  </p>
                </div>

                {/* Target Role Input */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  <label style={{ fontSize: '0.825rem', fontWeight: 600, color: 'var(--text-secondary)' }}>
                    Target Role / Specialization
                  </label>
                  <input
                    type="text"
                    value={targetRole}
                    onChange={(e) => setTargetRole(e.target.value)}
                    placeholder="Enter target role (e.g. Structural Engineer, Resident Doctor, Business Analyst, Full Stack Developer...)"
                    style={{
                      width: '100%',
                      padding: '0.75rem 1rem',
                      borderRadius: '8px',
                      background: 'rgba(255, 255, 255, 0.04)',
                      border: '1px solid var(--border-subtle)',
                      color: 'var(--text-primary)',
                      fontSize: '0.9rem',
                      outline: 'none'
                    }}
                  />
                </div>

                {/* Interview Round Type Selector */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <label style={{ fontSize: '0.825rem', fontWeight: 600, color: 'var(--text-secondary)' }}>
                      Interview Focus / Round Type
                    </label>
                    <span style={{ 
                      fontSize: '0.68rem', 
                      fontWeight: 700, 
                      color: 'var(--accent-cyan)', 
                      background: 'rgba(56, 189, 248, 0.12)', 
                      padding: '0.2rem 0.6rem', 
                      borderRadius: '999px',
                      border: '1px solid rgba(56, 189, 248, 0.3)',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.35rem'
                    }}>
                      <Zap size={11} /> Twisted Zig-Zag Engine
                    </span>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.75rem' }}>
                    {[
                      { 
                        id: 'comprehensive', 
                        title: '⚡ Comprehensive Mock', 
                        badge: 'Zig-Zag Full Spectrum',
                        desc: 'Mix of system bottlenecks, project stress-tests, & high-stakes STAR dilemmas.' 
                      },
                      { 
                        id: 'technical', 
                        title: '💻 Technical Deep-Dive', 
                        badge: 'Adversarial Edge-Cases',
                        desc: 'Cascading hangs, ReDoS attacks, thread starvation, & zero-downtime cutovers.' 
                      },
                      { 
                        id: 'project_deepdive', 
                        title: '🛡️ Resume Projects Defense', 
                        badge: 'Brutal Project Defense',
                        desc: 'Invalidated tech choices, 70% budget slashes, silent data corruption, & trade-offs.' 
                      },
                      { 
                        id: 'behavioral_star', 
                        title: '🌟 Behavioral (STAR)', 
                        badge: 'Real Disaster Dilemmas',
                        desc: 'Personal outage ownership, resisting executive pressure, & peer deadlocks.' 
                      }
                    ].map((item) => (
                      <div
                        key={item.id}
                        onClick={() => setInterviewType(item.id)}
                        style={{
                          padding: '0.85rem 1rem',
                          borderRadius: '10px',
                          background: interviewType === item.id ? 'rgba(56, 189, 248, 0.12)' : 'rgba(255, 255, 255, 0.02)',
                          border: interviewType === item.id ? '1px solid var(--accent-cyan)' : '1px solid var(--border-subtle)',
                          cursor: 'pointer',
                          transition: 'all 0.2s',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '0.3rem'
                        }}
                      >
                        <div style={{ fontSize: '0.85rem', fontWeight: 700, color: interviewType === item.id ? 'var(--accent-cyan)' : 'var(--text-primary)' }}>
                          {item.title}
                        </div>
                        <div style={{ fontSize: '0.675rem', fontWeight: 600, color: interviewType === item.id ? 'var(--accent-cyan)' : 'var(--text-muted)' }}>
                          {item.badge}
                        </div>
                        <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', lineHeight: 1.35 }}>
                          {item.desc}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Anti-Repetition & Zig-Zag Engine Guarantee */}
                  <div style={{
                    padding: '0.6rem 0.85rem',
                    borderRadius: '8px',
                    background: 'linear-gradient(90deg, rgba(56, 189, 248, 0.08), rgba(99, 102, 241, 0.08))',
                    border: '1px solid rgba(56, 189, 248, 0.22)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    fontSize: '0.73rem',
                    color: 'var(--text-secondary)'
                  }}>
                    <Sparkles size={14} color="var(--accent-cyan)" style={{ flexShrink: 0 }} />
                    <span>
                      <strong style={{ color: 'var(--accent-cyan)' }}>Zero-Repetition Adaptive Engine Active:</strong> Each round tests unexpected real-world curveballs and cross-references your past mock sessions so you never see the same or similar question again.
                    </span>
                  </div>
                </div>

                {/* Difficulty & Question Count Row */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                    <label style={{ fontSize: '0.825rem', fontWeight: 600, color: 'var(--text-secondary)' }}>
                      Difficulty Level
                    </label>
                    <select
                      value={difficulty}
                      onChange={(e) => setDifficulty(e.target.value)}
                      style={{
                        padding: '0.65rem 0.85rem',
                        borderRadius: '8px',
                        background: 'var(--bg-secondary)',
                        border: '1px solid var(--border-subtle)',
                        color: 'var(--text-primary)',
                        fontSize: '0.85rem'
                      }}
                    >
                      <option value="beginner">Junior / Campus Placement</option>
                      <option value="intermediate">Intermediate (1-3 yrs)</option>
                      <option value="advanced">Senior / High Stakes</option>
                    </select>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                    <label style={{ fontSize: '0.825rem', fontWeight: 600, color: 'var(--text-secondary)' }}>
                      Number of Questions
                    </label>
                    <select
                      value={numQuestions}
                      onChange={(e) => setNumQuestions(Number(e.target.value))}
                      style={{
                        padding: '0.65rem 0.85rem',
                        borderRadius: '8px',
                        background: 'var(--bg-secondary)',
                        border: '1px solid var(--border-subtle)',
                        color: 'var(--text-primary)',
                        fontSize: '0.85rem'
                      }}
                    >
                      <option value={3}>3 Questions (Quick Warmup ~ 5m)</option>
                      <option value={5}>5 Questions (Standard Round ~ 10m)</option>
                      <option value={7}>7 Questions (Full Deep-Dive ~ 15m)</option>
                    </select>
                  </div>
                </div>

                {/* Scoring / Grounding Notice Banner */}
                <div style={{ 
                  padding: '0.75rem 1rem', 
                  borderRadius: '8px', 
                  background: hasUploadedResume ? 'rgba(56, 189, 248, 0.05)' : 'rgba(245, 158, 11, 0.05)', 
                  border: hasUploadedResume ? '1px solid rgba(56, 189, 248, 0.2)' : '1px solid rgba(245, 158, 11, 0.25)',
                  fontSize: '0.775rem',
                  color: 'var(--text-secondary)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem'
                }}>
                  {hasUploadedResume ? (
                    <>
                      <ShieldCheck size={16} color="var(--accent-cyan)" style={{ flexShrink: 0 }} />
                      <span><strong>Resume Grounding Active:</strong> Questions are strictly derived from your uploaded resume. Minimal or incorrect answers receive <strong>0/100</strong>. Marks are awarded only for factually correct, substantive technical explanations.</span>
                    </>
                  ) : (
                    <>
                      <AlertCircle size={16} color="#fbbf24" style={{ flexShrink: 0 }} />
                      <span><strong>Resume Required:</strong> Please upload your resume first. The AI will strictly craft questions from your uploaded projects, technical skills, and experience.</span>
                    </>
                  )}
                </div>

                {/* Start Button */}
                <button
                  onClick={handleStartInterview}
                  disabled={isGeneratingInterview || !targetRole.trim()}
                  className="btn btn-primary"
                  style={{
                    padding: '0.9rem 1.5rem',
                    fontSize: '1rem',
                    fontWeight: 800,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '0.6rem',
                    boxShadow: 'var(--glow-cyan)',
                    marginTop: '0.25rem'
                  }}
                >
                  {isGeneratingInterview ? (
                    <>
                      <RefreshCw size={18} className="animate-spin" />
                      <span>Synthesizing Twisted Zig-Zag Questions...</span>
                    </>
                  ) : hasUploadedResume ? (
                    <>
                      <Play size={18} /> Start AI Mock Interview
                    </>
                  ) : (
                    <>
                      <UploadCloud size={18} /> Upload Resume First to Start Mock Interview
                    </>
                  )}
                </button>

                {!hasUploadedResume && (
                  <div style={{ textAlign: 'center', fontSize: '0.75rem', color: '#fbbf24', marginTop: '-0.5rem', fontWeight: 600 }}>
                    ⚠️ Resume required: Please upload your resume first to unlock the AI Mock Interview.
                  </div>
                )}
              </div>

              {/* Right Column: Ground-Truth Uploaded Resume Snapshot OR Clean Upload Resume Card */}
              {isLoadingResumeData ? (
                <div className="glass-card" style={{ padding: '2.5rem 1.5rem', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '340px' }}>
                  <FuturisticLoader
                    size="md"
                    icon="sparkles"
                    title="Loading Resume Facts..."
                    subtitle="Verifying uploaded projects and skills for AI interview grounding"
                  />
                </div>
              ) : hasUploadedResume ? (
                <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <ShieldCheck size={18} color="var(--accent-emerald)" />
                      <h4 style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                        Uploaded Resume Snapshot
                      </h4>
                    </div>
                    <button
                      onClick={() => setIsResumeModalOpen(true)}
                      className="btn btn-ghost-cyan btn-sm"
                      style={{
                        fontSize: '0.725rem',
                        fontWeight: 700,
                        color: 'var(--accent-cyan)',
                        padding: '0.25rem 0.65rem',
                        background: 'rgba(2, 132, 199, 0.08)',
                        border: '1px solid var(--border-glass)',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.25rem'
                      }}
                    >
                      View Details ↗
                    </button>
                  </div>

                  <div style={{ padding: '0.75rem', borderRadius: '8px', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)' }}>
                    <div style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                      {candidateFullName}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--accent-cyan)', marginTop: '0.1rem' }}>
                      {targetRole} • {resumeFacts?.domain || latestResume?.detected_domain || 'Technology & Engineering'}
                    </div>
                  </div>

                  {/* Extracted Projects Preview */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                        Resume Projects Grounded
                      </span>
                      <span style={{ fontSize: '0.675rem', color: 'var(--accent-cyan)' }}>
                        {(displayProjects || []).length} Projects Found
                      </span>
                    </div>
                    {(displayProjects || []).slice(0, 3).map((p: any, idx: number) => {
                      const pTitle = typeof p === 'string' ? p : (p?.title || p?.name || 'Featured Project');
                      const pTech = p && typeof p === 'object' ? (p.key_technologies ? (Array.isArray(p.key_technologies) ? p.key_technologies.join(', ') : p.key_technologies) : (p.role_or_tech || '')) : '';
                      return (
                        <div key={idx} style={{ padding: '0.6rem 0.75rem', borderRadius: '6px', background: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--border-subtle)' }}>
                          <div style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                            {pTitle}
                          </div>
                          {pTech && (
                            <div style={{ fontSize: '0.7rem', color: 'var(--accent-cyan)', marginTop: '0.1rem' }}>
                              {pTech}
                            </div>
                          )}
                        </div>
                      );
                    })}
                    {(displayProjects || []).length === 0 && (
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontStyle: 'italic' }}>
                        Standard industry project topics will be applied.
                      </div>
                    )}
                  </div>

                  {/* Extracted Skills Preview */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                    <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                      Verified Resume Skills
                    </span>
                    <div style={{ display: 'flex', gap: '0.35rem', flexWrap: 'wrap' }}>
                      {(displaySkills || []).slice(0, 10).map((s: string, idx: number) => (
                        <span key={idx} className="badge badge-cyan" style={{ fontSize: '0.675rem' }}>
                          {typeof s === 'string' ? s : (s as any)?.name || 'Skill'}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Historical Best Score Card */}
                  {historyData && historyData.total_interviews > 0 && historyData.highest_score > 0 ? (
                    <div style={{ marginTop: 'auto', padding: '0.85rem 1rem', borderRadius: '10px', background: 'rgba(56, 189, 248, 0.05)', border: '1px solid rgba(56, 189, 248, 0.2)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Highest Previous Score:</span>
                        <strong style={{ fontSize: '1.1rem', color: 'var(--accent-cyan)' }}>{historyData.highest_score}/100</strong>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '0.2rem' }}>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Average across {historyData.total_interviews} sessions:</span>
                        <span style={{ fontSize: '0.85rem', color: 'var(--text-primary)', fontWeight: 600 }}>{historyData.average_score}/100</span>
                      </div>
                    </div>
                  ) : (
                    <div style={{ marginTop: 'auto', padding: '0.75rem 0.9rem', borderRadius: '8px', background: 'rgba(255, 255, 255, 0.02)', border: '1px dashed var(--border-subtle)' }}>
                      <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>
                        💡 Complete your first mock interview to record your initial score and track your growth!
                      </span>
                    </div>
                  )}
                </div>
              ) : (
                /* Clean Upload Resume Card */
                <div 
                  className="glass-card" 
                  style={{ 
                    padding: '1.5rem', 
                    display: 'flex', 
                    flexDirection: 'column', 
                    gap: '1.15rem',
                    background: 'linear-gradient(180deg, rgba(255, 255, 255, 0.02) 0%, rgba(56, 189, 248, 0.03) 100%)',
                    border: isDragOver ? '2px dashed var(--accent-cyan)' : '1px solid var(--border-subtle)',
                    boxShadow: isDragOver ? '0 0 20px rgba(56, 189, 248, 0.25)' : 'none',
                    transition: 'all 0.2s ease'
                  }}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                >
                  {/* Header */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <FileText size={18} color="var(--accent-cyan)" />
                      <h4 style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                        Resume Grounding
                      </h4>
                    </div>
                    <span 
                      className="badge" 
                      style={{ 
                        background: 'rgba(245, 158, 11, 0.12)', 
                        color: '#fbbf24', 
                        border: '1px solid rgba(245, 158, 11, 0.3)',
                        fontSize: '0.675rem',
                        fontWeight: 700,
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.3rem'
                      }}
                    >
                      <AlertCircle size={11} /> No Resume Uploaded
                    </span>
                  </div>

                  {/* Dropzone Box */}
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    style={{
                      padding: '1.5rem 1rem',
                      borderRadius: '10px',
                      border: '1.5px dashed rgba(56, 189, 248, 0.35)',
                      background: isDragOver ? 'rgba(56, 189, 248, 0.1)' : 'rgba(0, 0, 0, 0.25)',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      justifyContent: 'center',
                      textAlign: 'center',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease'
                    }}
                  >
                    {isUploadingResume ? (
                      <div style={{ padding: '0.75rem 0' }}>
                        <FuturisticLoader
                          size="sm"
                          icon="zap"
                          title="Parsing & Analyzing Resume..."
                          subtitle="Extracting projects, skills, and work experience for interview grounding"
                        />
                      </div>
                    ) : (
                      <>
                        <div style={{
                          width: '44px',
                          height: '44px',
                          borderRadius: '50%',
                          background: 'rgba(56, 189, 248, 0.12)',
                          border: '1px solid rgba(56, 189, 248, 0.3)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: 'var(--accent-cyan)',
                          marginBottom: '0.75rem'
                        }}>
                          <UploadCloud size={22} />
                        </div>
                        <div style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.25rem' }}>
                          Upload Your Resume
                        </div>
                        <p style={{ fontSize: '0.775rem', color: 'var(--text-muted)', margin: '0 0 0.75rem 0', maxWidth: '240px', lineHeight: 1.4 }}>
                          Drag and drop your file here, or click to browse
                        </p>
                        <button 
                          type="button"
                          className="btn btn-outline-cyan btn-sm"
                          style={{ fontSize: '0.75rem', fontWeight: 700, pointerEvents: 'none' }}
                        >
                          <Upload size={13} /> Select Resume File
                        </button>
                        <span style={{ fontSize: '0.675rem', color: 'var(--text-muted)', marginTop: '0.5rem' }}>
                          PDF, DOCX, DOC, TXT (up to 10MB)
                        </span>
                      </>
                    )}
                  </div>

                  {uploadError && (
                    <div style={{
                      padding: '0.6rem 0.8rem',
                      borderRadius: '8px',
                      background: 'rgba(239, 68, 68, 0.12)',
                      border: '1px solid rgba(239, 68, 68, 0.3)',
                      color: '#f87171',
                      fontSize: '0.75rem',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.4rem'
                    }}>
                      <AlertTriangle size={14} style={{ flexShrink: 0 }} />
                      <span>{uploadError}</span>
                    </div>
                  )}

                  {/* Why Upload Resume Checklist */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.55rem' }}>
                    <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                      Why Upload Your Resume?
                    </span>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.45rem' }}>
                      <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.5rem', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                        <CheckCircle2 size={14} color="#34d399" style={{ flexShrink: 0, marginTop: '2px' }} />
                        <span><strong>Project Defense:</strong> AI challenges your specific portfolio repos, architecture, and design decisions.</span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.5rem', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                        <CheckCircle2 size={14} color="#34d399" style={{ flexShrink: 0, marginTop: '2px' }} />
                        <span><strong>Skill Deep-Dive:</strong> Drills into the exact tools, languages, and frameworks on your resume.</span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.5rem', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                        <CheckCircle2 size={14} color="#34d399" style={{ flexShrink: 0, marginTop: '2px' }} />
                        <span><strong>Strict Accuracy Scoring:</strong> Detailed grading and STAR feedback without artificial baselines.</span>
                      </div>
                    </div>
                  </div>

                  {/* Historical Best Score or Encouragement */}
                  {historyData && historyData.total_interviews > 0 && historyData.highest_score > 0 ? (
                    <div style={{ marginTop: 'auto', padding: '0.85rem 1rem', borderRadius: '10px', background: 'rgba(56, 189, 248, 0.05)', border: '1px solid rgba(56, 189, 248, 0.2)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Highest Previous Score:</span>
                        <strong style={{ fontSize: '1.1rem', color: 'var(--accent-cyan)' }}>{historyData.highest_score}/100</strong>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '0.2rem' }}>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Average across {historyData.total_interviews} sessions:</span>
                        <span style={{ fontSize: '0.85rem', color: 'var(--text-primary)', fontWeight: 600 }}>{historyData.average_score}/100</span>
                      </div>
                    </div>
                  ) : (
                    <div style={{ marginTop: 'auto', padding: '0.75rem 0.9rem', borderRadius: '8px', background: 'rgba(255, 255, 255, 0.02)', border: '1px dashed var(--border-subtle)' }}>
                      <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>
                        💡 Upload your resume or start a general interview to record your initial score and track growth!
                      </span>
                    </div>
                  )}

                  {/* Link to Full Resume Studio */}
                  {onNavigateToResume && (
                    <button
                      onClick={onNavigateToResume}
                      className="btn btn-ghost btn-sm"
                      style={{
                        fontSize: '0.75rem',
                        color: 'var(--accent-cyan)',
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '0.35rem',
                        padding: '0.5rem',
                        borderRadius: '6px',
                        background: 'rgba(56, 189, 248, 0.05)',
                        border: '1px solid rgba(56, 189, 248, 0.15)',
                        marginTop: '0.25rem'
                      }}
                    >
                      <FileText size={14} /> Open AI Resume Studio & ATS Optimizer ↗
                    </button>
                  )}
                </div>
              )}
              </div>
            </div>
          )}

          {/* 2. ACTIVE INTERVIEW STAGE */}
          {simulatorState === 'active' && currentSession && currentQ && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {/* Progress & Live Controls Bar */}
              <div 
                className="glass-card" 
                style={{ 
                  padding: '1rem 1.5rem', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'space-between', 
                  flexWrap: 'wrap', 
                  gap: '1rem' 
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
                  <span className="badge badge-cyan" style={{ fontSize: '0.75rem', padding: '0.25rem 0.6rem', fontWeight: 800 }}>
                    QUESTION {currentQuestionIndex + 1} OF {currentSession.questions?.length || 0}
                  </span>
                  <span className="badge badge-emerald" style={{ fontSize: '0.7rem' }}>
                    {(currentQ.category || 'general').replace(/_/g, ' ').toUpperCase()}
                  </span>
                  {currentQ.resume_reference && (
                    <span style={{ 
                      fontSize: '0.75rem', 
                      color: 'var(--accent-cyan)', 
                      background: 'rgba(56, 189, 248, 0.1)', 
                      padding: '0.2rem 0.5rem', 
                      borderRadius: '6px',
                      border: '1px solid rgba(56, 189, 248, 0.3)',
                      fontWeight: 600
                    }}>
                      📍 Resume Anchor: {currentQ.resume_reference}
                    </span>
                  )}
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  {/* View Resume in Interview Button */}
                  <button
                    onClick={() => setIsResumeModalOpen(true)}
                    className="btn btn-outline-cyan btn-sm"
                    style={{ fontSize: '0.75rem', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}
                  >
                    <FileText size={14} /> View My Resume
                  </button>

                  {/* Live Clock Timer */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem', color: 'var(--accent-cyan)', fontWeight: 700 }}>
                    <Clock size={16} />
                    <span>{formatTime(elapsedSeconds)}</span>
                  </div>

                  {/* Abandon / Restart */}
                  <button
                    onClick={() => {
                      if (window.confirm('Cancel current interview session? Your progress on this session will not be saved.')) {
                        setSimulatorState('setup');
                        setCurrentSession(null);
                      }
                    }}
                    className="btn btn-ghost btn-sm"
                    style={{
                      fontSize: '0.75rem',
                      fontWeight: 600,
                      color: 'var(--text-muted)',
                      padding: '0.35rem 0.75rem',
                      background: 'var(--bg-tertiary)',
                      border: '1px solid var(--border-subtle)',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      transition: 'all var(--transition-fast)'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.color = '#f43f5e';
                      e.currentTarget.style.borderColor = 'rgba(244, 63, 94, 0.4)';
                      e.currentTarget.style.background = 'rgba(244, 63, 94, 0.08)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.color = 'var(--text-muted)';
                      e.currentTarget.style.borderColor = 'var(--border-subtle)';
                      e.currentTarget.style.background = 'var(--bg-tertiary)';
                    }}
                  >
                    Exit Session
                  </button>
                </div>
              </div>

              {/* Question Card with Audio Playback */}
              <div 
                className="glass-card" 
                style={{ 
                  padding: '1.75rem', 
                  border: '1px solid rgba(56, 189, 248, 0.3)',
                  background: 'linear-gradient(180deg, rgba(56, 189, 248, 0.04) 0%, rgba(0, 0, 0, 0.4) 100%)',
                  boxShadow: 'var(--glow-cyan)'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '1rem' }}>
                  <div style={{ display: 'flex', gap: '0.85rem', flex: 1 }}>
                    <div style={{
                      width: '36px',
                      height: '36px',
                      borderRadius: '50%',
                      background: 'rgba(56, 189, 248, 0.15)',
                      border: '1px solid var(--accent-cyan)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0,
                      fontWeight: 800,
                      color: 'var(--accent-cyan)'
                    }}>
                      {currentQuestionIndex + 1}
                    </div>
                    <div>
                      <h2 style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0, lineHeight: 1.4 }}>
                        {currentQ.question}
                      </h2>
                      {currentQ.context_hint && (
                        <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', margin: '0.5rem 0 0 0', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <Lightbulb size={14} color="var(--accent-cyan)" />
                          <span><strong>Interviewer Tip:</strong> {currentQ.context_hint}</span>
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Text to Speech Voice Reader Button */}
                  <button
                    onClick={() => toggleSpeakQuestion(currentQ.question)}
                    className="btn btn-outline-cyan btn-sm"
                    style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', flexShrink: 0 }}
                    title={isSpeakingQuestion ? 'Stop Reading' : 'Listen to Interviewer Question'}
                  >
                    {isSpeakingQuestion ? <VolumeX size={16} /> : <Volume2 size={16} />}
                    <span style={{ fontSize: '0.75rem' }}>{isSpeakingQuestion ? 'Mute AI' : 'Read Aloud'}</span>
                  </button>
                </div>
              </div>

              {/* Answer Input Stage: Voice Recording + Manual Editor */}
              {!currentEvaluation && (
                <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <span style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                        Your Response:
                      </span>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        (Speak aloud using Voice or type below)
                      </span>
                    </div>

                    {/* Microphone Voice Button */}
                    <button
                      onClick={toggleVoiceRecording}
                      className={`btn ${isRecording ? 'btn-danger' : 'btn-outline-cyan'} btn-sm`}
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.45rem',
                        fontSize: '0.8rem',
                        fontWeight: 700,
                        animation: isRecording ? 'pulse 1.5s infinite' : 'none'
                      }}
                    >
                      {isRecording ? <MicOff size={16} /> : <Mic size={16} />}
                      {isRecording ? 'Stop Voice Recording (Live)' : 'Speak Answer with Mic'}
                    </button>
                  </div>

                  {/* Soundwave Waveform Animation when Recording */}
                  {isRecording && (
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '4px',
                      height: '28px',
                      background: 'rgba(239, 68, 68, 0.1)',
                      borderRadius: '6px',
                      border: '1px solid rgba(239, 68, 68, 0.3)'
                    }}>
                      <span style={{ fontSize: '0.75rem', color: '#f87171', fontWeight: 700, marginRight: '8px' }}>
                        🔴 Transcribing your speech in real-time...
                      </span>
                      {[14, 24, 10, 28, 16, 22, 12, 26, 18, 10].map((h, i) => (
                        <div
                          key={i}
                          style={{
                            width: '3px',
                            height: `${h}px`,
                            backgroundColor: '#f87171',
                            borderRadius: '2px',
                            animation: `pulse 0.8s ease-in-out infinite alternate ${i * 0.1}s`
                          }}
                        />
                      ))}
                    </div>
                  )}

                  {/* Textarea for Candidate Answer */}
                  <textarea
                    rows={6}
                    value={userAnswerText}
                    onChange={(e) => setUserAnswerText(e.target.value)}
                    placeholder="Type or dictate your answer here. Provide a detailed, technically accurate response with architecture, tools used, and quantifiable results..."
                    style={{
                      width: '100%',
                      padding: '1rem',
                      borderRadius: '10px',
                      background: 'rgba(255, 255, 255, 0.03)',
                      border: '1px solid var(--border-subtle)',
                      color: 'var(--text-primary)',
                      fontSize: '0.925rem',
                      lineHeight: 1.5,
                      outline: 'none',
                      resize: 'vertical',
                      fontFamily: 'inherit'
                    }}
                  />

                  {/* Word count & STAR Quick Helper Pill */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
                    <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
                      <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)' }}>STAR FORMULA:</span>
                      <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>S: Situation</span>
                      <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>T: Task</span>
                      <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>A: Action</span>
                      <span className="badge badge-emerald" style={{ fontSize: '0.65rem' }}>R: Measurable Result</span>
                    </div>

                    <div style={{ fontSize: '0.75rem', color: userAnswerText.trim().split(/\s+/).filter(Boolean).length < 6 ? '#f87171' : 'var(--accent-cyan)' }}>
                      Word Count: {userAnswerText.trim() ? userAnswerText.trim().split(/\s+/).filter(Boolean).length : 0} words
                      {userAnswerText.trim().split(/\s+/).filter(Boolean).length < 6 && ' (Min 6+ words for scoring)'}
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '0.5rem' }}>
                    <button
                      onClick={handleSubmitAnswer}
                      disabled={isSubmittingAnswer || !userAnswerText.trim()}
                      className="btn btn-primary"
                      style={{
                        padding: '0.75rem 1.5rem',
                        fontSize: '0.9rem',
                        fontWeight: 700,
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.5rem'
                      }}
                    >
                      {isSubmittingAnswer ? (
                        <>
                          <div className="spinner-border" style={{ width: '16px', height: '16px' }} />
                          AI Rigorously Evaluating Response...
                        </>
                      ) : (
                        <>
                          Submit & Evaluate Answer <ArrowRight size={16} />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {/* Instant Evaluation Feedback Card */}
              {currentEvaluation && (
                <div 
                  className="glass-card" 
                  style={{ 
                    padding: '1.75rem', 
                    border: currentEvaluation.score >= 60 
                      ? '1px solid var(--accent-emerald)' 
                      : (currentEvaluation.score > 0 ? '1px solid #f59e0b' : '1px solid #ef4444'),
                    background: currentEvaluation.score >= 60 
                      ? 'rgba(16, 185, 129, 0.05)' 
                      : (currentEvaluation.score > 0 ? 'rgba(245, 158, 11, 0.05)' : 'rgba(239, 68, 68, 0.05)'),
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '1.25rem',
                    animation: 'fadeIn 0.3s ease-out'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                      {currentEvaluation.score >= 60 ? (
                        <CheckCircle2 size={22} color="var(--accent-emerald)" />
                      ) : (
                        <XCircle size={22} color="#ef4444" />
                      )}
                      <div>
                        <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                          AI Correctness & Substance Evaluation
                        </h3>
                        <div style={{ fontSize: '0.75rem', marginTop: '0.1rem' }}>
                          <span style={{ 
                            color: currentEvaluation.score >= 60 ? '#34d399' : (currentEvaluation.score > 0 ? '#fbbf24' : '#f87171'), 
                            fontWeight: 700 
                          }}>
                            {currentEvaluation.verdict || (currentEvaluation.score >= 60 ? 'Correct & Solid' : (currentEvaluation.score > 0 ? 'Partially Correct' : 'Incorrect / Non-Answer (0/100)'))}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.5rem',
                      padding: '0.4rem 0.85rem',
                      borderRadius: '8px',
                      background: currentEvaluation.score >= 80 
                        ? 'rgba(16, 185, 129, 0.2)' 
                        : (currentEvaluation.score >= 50 ? 'rgba(56, 189, 248, 0.2)' : 'rgba(239, 68, 68, 0.2)'),
                      border: currentEvaluation.score >= 80 
                        ? '1px solid var(--accent-emerald)' 
                        : (currentEvaluation.score >= 50 ? '1px solid var(--accent-cyan)' : '1px solid rgba(239, 68, 68, 0.4)')
                    }}>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Score Awarded:</span>
                      <strong style={{ 
                        fontSize: '1.25rem', 
                        color: currentEvaluation.score >= 80 ? '#34d399' : (currentEvaluation.score >= 50 ? '#38bdf8' : '#f87171') 
                      }}>
                        {Math.round(currentEvaluation.score)}/100
                      </strong>
                    </div>
                  </div>

                  {/* Feedback Narrative */}
                  <div style={{ padding: '0.85rem 1rem', borderRadius: '8px', background: 'rgba(0,0,0,0.25)', border: '1px solid var(--border-subtle)' }}>
                    <p style={{ fontSize: '0.875rem', color: 'var(--text-primary)', lineHeight: 1.5, margin: 0 }}>
                      {currentEvaluation.feedback}
                    </p>
                  </div>

                  {/* Strengths & Improvements Grid */}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
                    {/* Strengths */}
                    <div style={{ padding: '0.9rem', borderRadius: '8px', background: 'rgba(16, 185, 129, 0.08)', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
                      <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#34d399', textTransform: 'uppercase', marginBottom: '0.4rem' }}>
                        ✓ Demonstrated Strengths
                      </div>
                      <ul style={{ margin: 0, paddingLeft: '1.2rem', fontSize: '0.775rem', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
                        {(currentEvaluation.strengths || []).length > 0 ? (
                          (currentEvaluation.strengths || []).map((s, idx) => <li key={idx}>{s}</li>)
                        ) : (
                          <li>No substantive technical points demonstrated.</li>
                        )}
                      </ul>
                    </div>

                    {/* Improvements */}
                    <div style={{ padding: '0.9rem', borderRadius: '8px', background: 'rgba(245, 158, 11, 0.08)', border: '1px solid rgba(245, 158, 11, 0.2)' }}>
                      <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#fbbf24', textTransform: 'uppercase', marginBottom: '0.4rem' }}>
                        ▲ Missing & Actionable Points
                      </div>
                      <ul style={{ margin: 0, paddingLeft: '1.2rem', fontSize: '0.775rem', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
                        {(currentEvaluation.improvements || []).map((imp, idx) => (
                          <li key={idx}>{imp}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Model Answer Recommendation */}
                  {currentEvaluation.model_answer_snippet && (
                    <div style={{ padding: '0.85rem', borderRadius: '8px', background: 'rgba(255, 255, 255, 0.02)', border: '1px dashed var(--border-subtle)' }}>
                      <div style={{ fontSize: '0.725rem', fontWeight: 700, color: 'var(--accent-cyan)', textTransform: 'uppercase', marginBottom: '0.25rem' }}>
                        💡 Benchmark Technical Answer
                      </div>
                      <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', margin: 0, fontStyle: 'italic' }}>
                        "{currentEvaluation.model_answer_snippet}"
                      </p>
                    </div>
                  )}

                  {/* Next Question Navigation */}
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '0.5rem' }}>
                    <button
                      onClick={handleNextQuestion}
                      disabled={isSubmittingAnswer}
                      className="btn btn-emerald"
                      style={{
                        padding: '0.75rem 1.5rem',
                        fontSize: '0.9rem',
                        fontWeight: 700,
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.5rem'
                      }}
                    >
                      {currentSession.questions && currentQuestionIndex + 1 < currentSession.questions.length ? (
                        <>
                          Proceed to Question {currentQuestionIndex + 2} <ArrowRight size={16} />
                        </>
                      ) : (
                        <>
                          Finalize Interview & View Scorecard <Award size={16} />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 3. COMPLETED SCORECARD STAGE */}
          {simulatorState === 'completed' && currentSession && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {/* Top Scorecard Hero Card */}
              <div 
                className="glass-card" 
                style={{ 
                  padding: '2rem', 
                  background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.1) 0%, rgba(168, 85, 247, 0.08) 100%)',
                  border: '1px solid var(--border-glass)',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '1.5rem'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.3rem' }}>
                      <Award size={24} color="var(--accent-cyan)" />
                      <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                        Interview Scorecard Completed!
                      </h2>
                    </div>
                    <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', margin: 0 }}>
                      Target Role: <strong style={{ color: 'var(--text-primary)' }}>{currentSession.target_role}</strong> • Duration: {formatTime(currentSession.duration_seconds || 0)}
                    </p>
                  </div>

                  <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
                    <button
                      onClick={() => setIsResumeModalOpen(true)}
                      className="btn btn-outline-cyan btn-sm"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
                    >
                      <FileText size={14} /> View Interviewed Resume
                    </button>
                    <button
                      onClick={() => {
                        setSimulatorState('setup');
                        setCurrentSession(null);
                      }}
                      className="btn btn-primary btn-sm"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
                    >
                      <RotateCcw size={14} /> Practice Another Round
                    </button>
                    <button
                      onClick={() => {
                        setActiveTab('history');
                        loadHistory();
                      }}
                      className="btn btn-secondary btn-sm"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontWeight: 700 }}
                    >
                      <TrendingUp size={14} /> View All Score History
                    </button>
                  </div>
                </div>

                {/* Score Big Meter + Multi-Dimensional Radar Breakdown */}
                <div style={{ display: 'grid', gridTemplateColumns: 'minmax(200px, 1fr) minmax(300px, 2fr)', gap: '1.5rem', alignItems: 'center' }}>
                  {/* Overall Circle Score */}
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
                    <div style={{
                      width: '130px',
                      height: '130px',
                      borderRadius: '50%',
                      background: `conic-gradient(var(--accent-cyan) 0% ${currentSession.overall_score || 0}%, rgba(255, 255, 255, 0.08) ${currentSession.overall_score || 0}% 100%)`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: 'var(--glow-cyan)',
                      marginBottom: '0.75rem'
                    }}>
                      <div style={{
                        width: '106px',
                        height: '106px',
                        borderRadius: '50%',
                        backgroundColor: 'var(--bg-secondary)',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        <span style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--text-primary)', lineHeight: 1 }}>
                          {Math.round(currentSession.overall_score || 0)}
                        </span>
                        <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                          Out of 100
                        </span>
                      </div>
                    </div>
                    <span className="badge badge-emerald" style={{ fontSize: '0.75rem', fontWeight: 700 }}>
                      {currentSession.readiness_level || 'Placement Ready'}
                    </span>
                  </div>

                  {/* Category Progress Meters */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                    {[
                      { label: 'Technical Accuracy & Depth', score: currentSession.technical_score ?? currentSession.overall_score, color: 'var(--grad-primary)' },
                      { label: 'STAR Structure & Communication', score: currentSession.communication_score ?? currentSession.overall_score, color: 'var(--grad-emerald)' },
                      { label: 'Problem Solving & Architecture', score: currentSession.problem_solving_score ?? currentSession.overall_score, color: 'linear-gradient(90deg, #a855f7, #ec4899)' },
                      { label: 'Resume Claim Authenticity', score: currentSession.resume_authenticity_score ?? currentSession.overall_score, color: 'linear-gradient(90deg, #3b82f6, #06b6d4)' }
                    ].map((m, idx) => (
                      <div key={idx}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.78rem', marginBottom: '0.25rem' }}>
                          <span style={{ color: 'var(--text-secondary)', fontWeight: 600 }}>{m.label}</span>
                          <span style={{ color: 'var(--text-primary)', fontWeight: 800 }}>{Math.round(m.score || 0)}%</span>
                        </div>
                        <div style={{ width: '100%', height: '6px', background: 'rgba(255, 255, 255, 0.06)', borderRadius: '3px', overflow: 'hidden' }}>
                          <div style={{ width: `${Math.min(100, Math.max(0, m.score || 0))}%`, height: '100%', background: m.color }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Qualitative Verdict Narrative */}
                {currentSession.summary_verdict && (
                  <div style={{ padding: '1rem 1.25rem', borderRadius: '10px', background: 'rgba(0, 0, 0, 0.3)', border: '1px solid var(--border-subtle)' }}>
                    <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--accent-cyan)', textTransform: 'uppercase', marginBottom: '0.35rem' }}>
                      AI Hiring Verdict & Summary
                    </div>
                    <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                      {currentSession.summary_verdict}
                    </p>
                  </div>
                )}
              </div>

              {/* Strengths and Improvements Summary */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem' }}>
                <div className="glass-card" style={{ padding: '1.5rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.85rem' }}>
                    <CheckCircle2 size={18} color="var(--accent-emerald)" />
                    <h3 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                      Top Demonstrated Strengths
                    </h3>
                  </div>
                  <ul style={{ margin: 0, paddingLeft: '1.2rem', fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    {(currentSession.strengths || []).map((s, idx) => (
                      <li key={idx}>{s}</li>
                    ))}
                  </ul>
                </div>

                <div className="glass-card" style={{ padding: '1.5rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.85rem' }}>
                    <TrendingUp size={18} color="#fbbf24" />
                    <h3 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                      Targeted Placement Action Items
                    </h3>
                  </div>
                  <ul style={{ margin: 0, paddingLeft: '1.2rem', fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    {(currentSession.improvements || []).map((imp, idx) => (
                      <li key={idx}>{imp}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Complete Question-by-Question Review Accordion */}
              <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                    Detailed Question-by-Question Review
                  </h3>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    {(currentSession.questions || []).length} Questions Evaluated
                  </span>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  {(currentSession.questions || []).map((q, idx) => {
                    const isExpanded = expandedQuestionIdx === idx;
                    const isCorrect = q.is_correct ?? ((q.score || 0) >= 50);
                    return (
                      <div 
                        key={idx}
                        style={{
                          borderRadius: '10px',
                          background: 'rgba(255, 255, 255, 0.02)',
                          border: '1px solid var(--border-subtle)',
                          overflow: 'hidden',
                          transition: 'all 0.2s'
                        }}
                      >
                        <div
                          onClick={() => setExpandedQuestionIdx(isExpanded ? null : idx)}
                          style={{
                            padding: '0.9rem 1.25rem',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            cursor: 'pointer',
                            background: isExpanded ? 'rgba(56, 189, 248, 0.04)' : 'transparent'
                          }}
                        >
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flex: 1, paddingRight: '1rem' }}>
                            <span style={{ fontSize: '0.8rem', fontWeight: 800, color: 'var(--accent-cyan)' }}>
                              Q{idx + 1}
                            </span>
                            <span style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-primary)' }}>
                              {q.question}
                            </span>
                          </div>

                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                            <span className={`badge ${isCorrect ? 'badge-emerald' : 'badge-danger'}`} style={{ fontSize: '0.7rem' }}>
                              {q.score !== null && q.score !== undefined ? `${Math.round(q.score)}/100` : '--'}
                            </span>
                            {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                          </div>
                        </div>

                        {isExpanded && (
                          <div style={{ padding: '1.25rem', borderTop: '1px solid var(--border-subtle)', display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                            {/* Resume Grounding Reference */}
                            {q.resume_reference && (
                              <div style={{ fontSize: '0.75rem', color: 'var(--accent-cyan)' }}>
                                📍 <strong>Resume Origin:</strong> {q.resume_reference}
                              </div>
                            )}

                            {/* Candidate Answer */}
                            <div style={{ padding: '0.85rem', borderRadius: '8px', background: 'rgba(0, 0, 0, 0.2)', border: '1px solid var(--border-subtle)' }}>
                              <div style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '0.25rem' }}>
                                Your Answer
                              </div>
                              <p style={{ fontSize: '0.825rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.4 }}>
                                {q.user_answer || '(No answer recorded)'}
                              </p>
                            </div>

                            {/* AI Feedback */}
                            {q.feedback && (
                              <div style={{ padding: '0.85rem', borderRadius: '8px', background: 'rgba(56, 189, 248, 0.05)', border: '1px solid rgba(56, 189, 248, 0.2)' }}>
                                <div style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--accent-cyan)', textTransform: 'uppercase', marginBottom: '0.25rem' }}>
                                  AI Feedback & Correctness Rationale
                                </div>
                                <p style={{ fontSize: '0.825rem', color: 'var(--text-primary)', margin: 0, lineHeight: 1.4 }}>
                                  {q.feedback}
                                </p>
                              </div>
                            )}

                            {/* Ideal Snippet */}
                            {q.model_answer_snippet && (
                              <div style={{ padding: '0.75rem', borderRadius: '8px', background: 'rgba(255, 255, 255, 0.02)', border: '1px dashed var(--border-subtle)' }}>
                                <div style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--accent-emerald)', textTransform: 'uppercase', marginBottom: '0.2rem' }}>
                                  💡 Benchmark Answer
                                </div>
                                <p style={{ fontSize: '0.775rem', color: 'var(--text-muted)', margin: 0, fontStyle: 'italic' }}>
                                  "{q.model_answer_snippet}"
                                </p>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* TAB 2: SCORE HISTORY & PROGRESSION ANALYTICS */}
      {activeTab === 'history' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {isLoadingHistory ? (
            <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-muted)' }}>
              <div className="spinner-border" style={{ width: '28px', height: '28px', margin: '0 auto 0.75rem auto' }} />
              Loading your interview score history...
            </div>
          ) : (!historyData || historyData.total_interviews === 0) ? (
            <div className="glass-card" style={{ padding: '3.5rem 2rem', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem' }}>
              <div style={{
                width: '64px',
                height: '64px',
                borderRadius: '50%',
                background: 'rgba(56, 189, 248, 0.1)',
                border: '1px solid var(--accent-cyan)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--accent-cyan)'
              }}>
                <HelpCircle size={32} />
              </div>
              <div>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  No Interview History Recorded Yet
                </h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', maxWidth: '480px', margin: '0.4rem 0 0 0', lineHeight: 1.5 }}>
                  Take your first AI Mock Interview grounded in your resume to start recording your performance scores, category strengths, and placement progression.
                </p>
              </div>
              <button
                onClick={() => {
                  setActiveTab('studio');
                  setSimulatorState('setup');
                }}
                className="btn btn-primary"
                style={{ marginTop: '0.5rem', display: 'inline-flex', alignItems: 'center', gap: '0.5rem', fontWeight: 700 }}
              >
                <Play size={16} /> Start Your First Mock Interview
              </button>
            </div>
          ) : (
            <>
              {/* Top Analytics Summary Cards */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
                <div className="glass-card" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <div style={{ width: '44px', height: '44px', borderRadius: '10px', background: 'rgba(56, 189, 248, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Layers size={22} color="var(--accent-cyan)" />
                  </div>
                  <div>
                    <div style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1 }}>
                      {historyData.total_interviews}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                      Total Sessions Taken
                    </div>
                  </div>
                </div>

                <div className="glass-card" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <div style={{ width: '44px', height: '44px', borderRadius: '10px', background: 'rgba(168, 85, 247, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Award size={22} color="#c084fc" />
                  </div>
                  <div>
                    <div style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1 }}>
                      {historyData.highest_score}<span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>/100</span>
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                      Personal Best Record
                    </div>
                  </div>
                </div>

                <div className="glass-card" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <div style={{ width: '44px', height: '44px', borderRadius: '10px', background: 'rgba(16, 185, 129, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <TrendingUp size={22} color="var(--accent-emerald)" />
                  </div>
                  <div>
                    <div style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1 }}>
                      {historyData.average_score}<span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>/100</span>
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                      Average Interview Score
                    </div>
                  </div>
                </div>

                <div className="glass-card" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <div style={{ width: '44px', height: '44px', borderRadius: '10px', background: 'rgba(245, 158, 11, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <ShieldCheck size={22} color="#fbbf24" />
                  </div>
                  <div>
                    <div style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-primary)', lineHeight: 1 }}>
                      {historyData.average_score >= 80 ? 'Placement Ready' : historyData.average_score >= 65 ? 'Strong Candidate' : 'Developing'}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                      Readiness Classification
                    </div>
                  </div>
                </div>
              </div>

              {/* Visual Progression Trend Chart */}
              {historyData.score_trend && historyData.score_trend.length > 0 && (
                <div className="glass-card" style={{ padding: '1.75rem', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
                    <div>
                      <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                        Score Evolution & Performance Progression
                      </h3>
                      <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
                        Track your placement readiness improvement across sequential mock interview sessions.
                      </p>
                    </div>
                    <span className="badge badge-emerald" style={{ fontSize: '0.75rem' }}>
                      <TrendingUp size={14} /> Chronological Growth
                    </span>
                  </div>

                  {/* Score Trend Bar / Line Visualization */}
                  <div style={{ 
                    display: 'flex', 
                    alignItems: 'flex-end', 
                    gap: '1.5rem', 
                    height: '180px', 
                    padding: '1rem 1rem 0.5rem 1rem', 
                    background: 'rgba(0, 0, 0, 0.25)', 
                    borderRadius: '10px', 
                    border: '1px solid var(--border-subtle)',
                    overflowX: 'auto'
                  }}>
                    {historyData.score_trend.map((t, idx) => {
                      const pct = Math.min(100, Math.max(10, t.score));
                      return (
                        <div 
                          key={idx} 
                          style={{ 
                            display: 'flex', 
                            flexDirection: 'column', 
                            alignItems: 'center', 
                            gap: '0.4rem', 
                            flex: 1, 
                            minWidth: '60px',
                            height: '100%',
                            justifyContent: 'flex-end'
                          }}
                        >
                          <span style={{ fontSize: '0.75rem', fontWeight: 800, color: t.score >= 80 ? '#34d399' : '#38bdf8' }}>
                            {Math.round(t.score)}
                          </span>
                          <div 
                            style={{ 
                              width: '100%', 
                              maxWidth: '36px', 
                              height: `${pct}%`, 
                              background: t.score >= 80 ? 'var(--grad-emerald)' : 'var(--grad-primary)', 
                              borderRadius: '6px 6px 0 0',
                              transition: 'height 0.5s ease-out'
                            }} 
                          />
                          <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                            {t.date}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Historical Session List */}
              <div className="glass-card" style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                    All Recorded Interview Sessions
                  </h3>
                  <button
                    onClick={() => {
                      setActiveTab('studio');
                      setSimulatorState('setup');
                    }}
                    className="btn btn-primary btn-sm"
                    style={{ fontSize: '0.8rem', fontWeight: 700 }}
                  >
                    + New Mock Interview
                  </button>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  {(historyData?.history || []).map((s) => (
                    <div
                      key={s.id}
                      onClick={async () => {
                        try {
                          const full = await interviewApi.getSession(s.id);
                          setSelectedPastSession(full);
                        } catch (e) {
                          console.error('Failed to load session details:', e);
                        }
                      }}
                      style={{
                        padding: '1rem 1.25rem',
                        borderRadius: '10px',
                        background: 'rgba(255, 255, 255, 0.02)',
                        border: '1px solid var(--border-subtle)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        flexWrap: 'wrap',
                        gap: '1rem',
                        cursor: 'pointer',
                        transition: 'all 0.2s'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.borderColor = 'var(--accent-cyan)';
                        e.currentTarget.style.background = 'rgba(56, 189, 248, 0.04)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.borderColor = 'var(--border-subtle)';
                        e.currentTarget.style.background = 'rgba(255, 255, 255, 0.02)';
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                        <div style={{
                          width: '46px',
                          height: '46px',
                          borderRadius: '50%',
                          background: s.overall_score >= 80 ? 'rgba(16, 185, 129, 0.15)' : 'rgba(56, 189, 248, 0.15)',
                          border: s.overall_score >= 80 ? '1px solid var(--accent-emerald)' : '1px solid var(--accent-cyan)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontWeight: 900,
                          fontSize: '1rem',
                          color: s.overall_score >= 80 ? '#34d399' : '#38bdf8'
                        }}>
                          {Math.round(s.overall_score)}
                        </div>

                        <div>
                          <div style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                            {s.target_role}
                          </div>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '0.15rem' }}>
                            <span className="badge badge-cyan" style={{ fontSize: '0.625rem' }}>{s.interview_type}</span>
                            <span>•</span>
                            <span>{s.total_questions} Questions</span>
                            <span>•</span>
                            <span>{new Date(s.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                          </div>
                        </div>
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                        <span className="badge badge-emerald" style={{ fontSize: '0.7rem' }}>
                          {s.readiness_level || 'Placement Ready'}
                        </span>
                        <button
                          onClick={(e) => handleDeleteSession(s.id, e)}
                          disabled={isDeletingSessionId === s.id}
                          className="btn btn-ghost btn-sm"
                          style={{ padding: '0.35rem', color: '#f87171' }}
                          title="Delete record from history"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Detailed Past Session Inspection Modal */}
          {selectedPastSession && (
            <div 
              style={{
                position: 'fixed',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: 'rgba(0, 0, 0, 0.8)',
                backdropFilter: 'blur(8px)',
                zIndex: 9999,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: '1.5rem'
              }}
              onClick={() => setSelectedPastSession(null)}
            >
              <div 
                className="glass-card"
                style={{
                  maxWidth: '850px',
                  width: '100%',
                  maxHeight: '90vh',
                  overflowY: 'auto',
                  padding: '2rem',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '1.25rem',
                  background: 'var(--bg-secondary)',
                  border: '1px solid var(--accent-cyan)'
                }}
                onClick={(e) => e.stopPropagation()}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <h3 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                      Past Scorecard: {selectedPastSession.target_role}
                    </h3>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
                      Recorded on {new Date(selectedPastSession.created_at).toLocaleString()}
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedPastSession(null)}
                    className="btn btn-ghost btn-sm"
                    style={{ fontSize: '1.25rem', padding: '0.2rem 0.5rem' }}
                  >
                    ✕
                  </button>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', padding: '1rem', borderRadius: '8px', background: 'rgba(56, 189, 248, 0.06)', border: '1px solid rgba(56, 189, 248, 0.2)' }}>
                  <div style={{ fontSize: '1.8rem', fontWeight: 900, color: 'var(--accent-cyan)' }}>
                    {Math.round(selectedPastSession.overall_score || 0)}/100
                  </div>
                  <div>
                    <div style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                      Status: {selectedPastSession.readiness_level || 'Placement Ready'}
                    </div>
                    <p style={{ fontSize: '0.775rem', color: 'var(--text-muted)', margin: 0 }}>
                      {selectedPastSession.summary_verdict}
                    </p>
                  </div>
                </div>

                {/* Questions Review */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                  {(selectedPastSession.questions || []).length > 0 ? (
                    (selectedPastSession.questions || []).map((q, idx) => (
                      <div key={idx} style={{ padding: '1rem', borderRadius: '8px', background: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--border-subtle)' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.4rem' }}>
                          <strong style={{ fontSize: '0.85rem', color: 'var(--text-primary)' }}>
                            Q{idx + 1}: {q.question}
                          </strong>
                          <span className={`badge ${((q.score || 0) >= 50) ? 'badge-emerald' : 'badge-danger'}`} style={{ fontSize: '0.65rem' }}>
                            Score: {q.score !== null && q.score !== undefined ? `${Math.round(q.score)}/100` : '--'}
                          </span>
                        </div>
                        <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', background: 'rgba(0,0,0,0.2)', padding: '0.5rem 0.75rem', borderRadius: '6px', margin: '0.4rem 0' }}>
                          <strong>Your Answer:</strong> {q.user_answer || '(No answer recorded)'}
                        </p>
                        {q.feedback && (
                          <p style={{ fontSize: '0.775rem', color: 'var(--accent-cyan)', margin: '0.25rem 0 0 0' }}>
                            <strong>Coaching:</strong> {q.feedback}
                          </p>
                        )}
                      </div>
                    ))
                  ) : (
                    <div style={{ padding: '1.5rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                      No question breakdown recorded for this session.
                    </div>
                  )}
                </div>

                <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '0.5rem' }}>
                  <button
                    onClick={() => setSelectedPastSession(null)}
                    className="btn btn-secondary btn-sm"
                  >
                    Close Scorecard
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* FULL UPLOADED RESUME VIEWER MODAL / DRAWER */}
      {isResumeModalOpen && (
        <div 
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.85)',
            backdropFilter: 'blur(10px)',
            zIndex: 10000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '1.5rem'
          }}
          onClick={() => setIsResumeModalOpen(false)}
        >
          <div 
            className="glass-card"
            style={{
              maxWidth: '900px',
              width: '100%',
              maxHeight: '88vh',
              overflowY: 'auto',
              padding: '2rem',
              display: 'flex',
              flexDirection: 'column',
              gap: '1.25rem',
              background: 'var(--bg-secondary)',
              border: '1px solid var(--accent-cyan)',
              boxShadow: '0 0 30px rgba(56, 189, 248, 0.2)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '1rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <div style={{
                  width: '38px',
                  height: '38px',
                  borderRadius: '10px',
                  background: 'rgba(56, 189, 248, 0.15)',
                  border: '1px solid var(--accent-cyan)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  <FileText size={20} color="var(--accent-cyan)" />
                </div>
                <div>
                  <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                    Uploaded Resume Reference
                  </h3>
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                    Candidate: <strong style={{ color: 'var(--accent-cyan)' }}>{candidateFullName}</strong> • Grounding reference for AI interview questions
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsResumeModalOpen(false)}
                className="btn btn-ghost btn-sm"
                style={{ fontSize: '1.2rem', padding: '0.3rem 0.6rem' }}
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Body: Either Clean Upload Resume Prompt OR Sub-Tabs */}
            {!hasUploadedResume ? (
              <div style={{ padding: '2.5rem 1.5rem', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.85rem' }}>
                <div style={{
                  width: '56px',
                  height: '56px',
                  borderRadius: '50%',
                  background: 'rgba(56, 189, 248, 0.12)',
                  border: '1px solid rgba(56, 189, 248, 0.3)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'var(--accent-cyan)'
                }}>
                  <UploadCloud size={28} />
                </div>
                <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  No Resume Uploaded Yet
                </h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', margin: 0, maxWidth: '440px', lineHeight: 1.5 }}>
                  You haven't uploaded a resume yet. Upload your PDF or DOCX resume to view extracted projects, verified technical skills, work history, and ground your AI mock interview in your actual experience.
                </p>
                <div style={{ display: 'flex', gap: '0.75rem', marginTop: '0.75rem', flexWrap: 'wrap', justifyContent: 'center' }}>
                  <button
                    onClick={() => {
                      setIsResumeModalOpen(false);
                      fileInputRef.current?.click();
                    }}
                    className="btn btn-primary btn-sm"
                    style={{ display: 'inline-flex', alignItems: 'center', gap: '0.45rem', fontSize: '0.825rem', fontWeight: 700 }}
                  >
                    <Upload size={14} /> Upload Resume Now
                  </button>
                  {onNavigateToResume && (
                    <button
                      onClick={() => {
                        setIsResumeModalOpen(false);
                        onNavigateToResume();
                      }}
                      className="btn btn-secondary btn-sm"
                      style={{ display: 'inline-flex', alignItems: 'center', gap: '0.45rem', fontSize: '0.825rem' }}
                    >
                      <FileText size={14} /> Open AI Resume Studio
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <>
                {/* Resume Section Sub-Tabs */}
                <div style={{ display: 'flex', gap: '0.4rem', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0.5rem', flexWrap: 'wrap' }}>
                  {[
                    { id: 'projects', label: `Projects (${(displayProjects || []).length})`, icon: Code2 },
                    { id: 'skills', label: `Skills (${(displaySkills || []).length})`, icon: Sparkles },
                    { id: 'experience', label: `Experience (${(displayExperience || []).length})`, icon: Briefcase },
                    { id: 'education', label: `Education (${(displayEducation || []).length})`, icon: GraduationCap },
                    { id: 'raw', label: 'Raw Resume Text', icon: BookOpen }
                  ].map((tab) => {
                    const Icon = tab.icon;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveResumeTab(tab.id as any)}
                        className={`btn btn-sm ${activeResumeTab === tab.id ? 'btn-primary' : 'btn-ghost'}`}
                        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.78rem' }}
                      >
                        <Icon size={14} /> {tab.label}
                      </button>
                    );
                  })}
                </div>

                {/* TAB: PROJECTS */}
                {activeResumeTab === 'projects' && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    {(displayProjects || []).length > 0 ? (
                      (displayProjects || []).map((p: any, idx: number) => {
                        const title = typeof p === 'string' ? p : (p?.title || p?.name || `Project ${idx + 1}`);
                        const tech = p && typeof p === 'object' ? (p.key_technologies ? (Array.isArray(p.key_technologies) ? p.key_technologies.join(', ') : p.key_technologies) : (p.role_or_tech || '')) : '';
                        const desc = p && typeof p === 'object' ? (p.description || '') : '';
                        const metrics = p && typeof p === 'object' ? (p.quantifiable_metrics || p.quantified_impact || '') : '';
                        return (
                          <div 
                            key={idx} 
                            style={{ 
                              padding: '1.2rem', 
                              borderRadius: '10px', 
                              background: 'rgba(255, 255, 255, 0.02)', 
                              border: '1px solid var(--border-subtle)',
                              display: 'flex',
                              flexDirection: 'column',
                              gap: '0.5rem'
                            }}
                          >
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '0.5rem' }}>
                              <h4 style={{ fontSize: '1rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                                {title}
                              </h4>
                              {tech && (
                                <span className="badge badge-cyan" style={{ fontSize: '0.7rem' }}>
                                  {tech}
                                </span>
                              )}
                            </div>

                            {desc && (
                              <p style={{ fontSize: '0.825rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                                {desc}
                              </p>
                            )}

                            {metrics && (
                              <div style={{ fontSize: '0.775rem', color: '#34d399', background: 'rgba(16, 185, 129, 0.08)', padding: '0.35rem 0.6rem', borderRadius: '6px', width: 'fit-content' }}>
                                📊 <strong>Measurable Metric:</strong> {metrics}
                              </div>
                            )}
                          </div>
                        );
                      })
                    ) : (
                      <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                        No specific projects extracted from the uploaded document.
                      </div>
                    )}
                  </div>
                )}

                {/* TAB: SKILLS */}
                {activeResumeTab === 'skills' && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <h4 style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                      Extracted Technical & Domain Skills
                    </h4>
                    <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                      {(displaySkills || []).map((s: string, idx: number) => (
                        <span 
                          key={idx} 
                          className="badge badge-cyan" 
                          style={{ 
                            fontSize: '0.8rem', 
                            padding: '0.35rem 0.75rem', 
                            borderRadius: '8px',
                            fontWeight: 600
                          }}
                        >
                          {typeof s === 'string' ? s : (s as any)?.name || 'Skill'}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* TAB: EXPERIENCE */}
                {activeResumeTab === 'experience' && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    {(displayExperience || []).length > 0 ? (
                      (displayExperience || []).map((exp: any, idx: number) => {
                        const role = typeof exp === 'string' ? exp : (exp?.role || exp?.title || 'Role');
                        const company = exp && typeof exp === 'object' ? (exp.company_or_org || exp.company || '') : '';
                        const duration = exp && typeof exp === 'object' ? (exp.duration || '') : '';
                        const highlights = exp && typeof exp === 'object' && Array.isArray(exp.highlights) ? exp.highlights : [];
                        return (
                          <div 
                            key={idx} 
                            style={{ 
                              padding: '1.2rem', 
                              borderRadius: '10px', 
                              background: 'rgba(255, 255, 255, 0.02)', 
                              border: '1px solid var(--border-subtle)',
                              display: 'flex',
                              flexDirection: 'column',
                              gap: '0.4rem'
                            }}
                          >
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                              <h4 style={{ fontSize: '0.95rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                                {role} {company ? `• ${company}` : ''}
                              </h4>
                              {duration && (
                                <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                                  {duration}
                                </span>
                              )}
                            </div>
                            {highlights && highlights.length > 0 && (
                              <ul style={{ margin: '0.3rem 0 0 0', paddingLeft: '1.2rem', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                                {highlights.map((h: string, hIdx: number) => (
                                  <li key={hIdx}>{h}</li>
                                ))}
                              </ul>
                            )}
                          </div>
                        );
                      })
                    ) : (
                      <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                        No work experience or internships recorded.
                      </div>
                    )}
                  </div>
                )}

                {/* TAB: EDUCATION */}
                {activeResumeTab === 'education' && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    {(displayEducation || []).length > 0 ? (
                      (displayEducation || []).map((edu: any, idx: number) => (
                        <div 
                          key={idx} 
                          style={{ 
                            padding: '1rem', 
                            borderRadius: '10px', 
                            background: 'rgba(255, 255, 255, 0.02)', 
                            border: '1px solid var(--border-subtle)' 
                          }}
                        >
                          <h4 style={{ fontSize: '0.95rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                            {edu?.degree || edu?.institution || 'Academic Program'}
                          </h4>
                          <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
                            {edu?.institution} {edu?.dates_or_grade ? `• ${edu.dates_or_grade}` : ''}
                          </p>
                        </div>
                      ))
                    ) : (
                      <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                        No specific education records found.
                      </div>
                    )}
                  </div>
                )}

                {/* TAB: RAW RESUME TEXT */}
                {activeResumeTab === 'raw' && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                      Parsed Resume Content
                    </span>
                    <pre style={{
                      padding: '1rem',
                      borderRadius: '8px',
                      background: 'rgba(0, 0, 0, 0.4)',
                      border: '1px solid var(--border-subtle)',
                      color: 'var(--text-secondary)',
                      fontSize: '0.78rem',
                      whiteSpace: 'pre-wrap',
                      maxHeight: '300px',
                      overflowY: 'auto',
                      fontFamily: 'monospace'
                    }}>
                      {resumeFacts?.raw_text_snippet || latestResume?.raw_text || 'No raw text snippet available.'}
                    </pre>
                  </div>
                )}
              </>
            )}

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '0.5rem' }}>
              <button
                onClick={() => setIsResumeModalOpen(false)}
                className="btn btn-secondary btn-sm"
              >
                Close Resume Viewer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload Resume First Modal Prompt */}
      {showUploadResumePrompt && !hasUploadedResume && (
        <div 
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(3, 7, 18, 0.88)',
            backdropFilter: 'blur(16px)',
            zIndex: 99999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '1.5rem',
            animation: 'fadeIn 0.2s ease-out'
          }}
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowUploadResumePrompt(false);
          }}
        >
          <div 
            className="glass-card" 
            style={{
              maxWidth: '500px',
              width: '100%',
              padding: '2.25rem 2rem',
              borderRadius: '24px',
              background: 'var(--bg-secondary)',
              border: '1.5px solid rgba(245, 158, 11, 0.45)',
              boxShadow: 'var(--shadow-modal), 0 0 35px rgba(245, 158, 11, 0.25)',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              textAlign: 'center',
              gap: '1.25rem',
              position: 'relative'
            }}
          >
            <button
              onClick={() => setShowUploadResumePrompt(false)}
              className="btn btn-ghost btn-sm"
              style={{ position: 'absolute', top: '1.2rem', right: '1.2rem', color: 'var(--text-muted)' }}
            >
              <X size={20} />
            </button>

            <div style={{
              width: '64px',
              height: '64px',
              borderRadius: '50%',
              background: 'rgba(245, 158, 11, 0.15)',
              border: '2px solid rgba(245, 158, 11, 0.5)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#fbbf24',
              boxShadow: '0 0 20px rgba(245, 158, 11, 0.25)'
            }}>
              <UploadCloud size={32} />
            </div>

            <div>
              <h3 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)', margin: '0 0 0.5rem 0' }}>
                Please Upload Your Resume First
              </h3>
              <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)', lineHeight: 1.5, margin: 0 }}>
                To conduct an AI Mock Interview, an uploaded resume is required. The AI Proctor will ground technical questions, project defenses, and STAR dilemmas in your actual uploaded experience.
              </p>
            </div>

            <div style={{
              width: '100%',
              padding: '1rem',
              borderRadius: '12px',
              background: 'rgba(255, 255, 255, 0.02)',
              border: '1px dashed var(--border-subtle)',
              display: 'flex',
              flexDirection: 'column',
              gap: '0.5rem',
              fontSize: '0.8rem',
              textAlign: 'left'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--accent-emerald)', fontWeight: 600 }}>
                <CheckCircle2 size={15} /> 100% Resume-Grounded Project Defense
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--accent-emerald)', fontWeight: 600 }}>
                <CheckCircle2 size={15} /> Real Technical Skill Testing (No Generic Prompts)
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--accent-emerald)', fontWeight: 600 }}>
                <CheckCircle2 size={15} /> Strict STAR Placement Scoring & Metrics
              </div>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', width: '100%', marginTop: '0.25rem' }}>
              <button
                onClick={() => {
                  setShowUploadResumePrompt(false);
                  fileInputRef.current?.click();
                }}
                className="btn btn-primary"
                style={{
                  flex: 1,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '0.5rem',
                  padding: '0.85rem',
                  fontSize: '0.9rem',
                  fontWeight: 700
                }}
              >
                <Upload size={16} /> Select Resume File (PDF/DOCX)
              </button>
              {onNavigateToResume && (
                <button
                  onClick={() => {
                    setShowUploadResumePrompt(false);
                    onNavigateToResume();
                  }}
                  className="btn btn-secondary"
                  style={{
                    padding: '0.85rem 1rem',
                    fontSize: '0.85rem',
                    fontWeight: 600
                  }}
                >
                  AI Resume Studio
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3-Second Posture & Calibration Countdown Overlay */}
      {isCountingDown && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(3, 7, 18, 0.84)',
            backdropFilter: 'blur(16px)',
            zIndex: 99999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '1.5rem',
            animation: 'fadeIn 0.2s ease-out'
          }}
        >
          <div
            className="glass-card"
            style={{
              maxWidth: '540px',
              width: '100%',
              padding: '2.5rem 2rem',
              borderRadius: '24px',
              background: 'var(--bg-secondary)',
              border: '1.5px solid var(--border-glass)',
              boxShadow: 'var(--shadow-modal), var(--glow-cyan)',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              textAlign: 'center',
              gap: '1.4rem',
              position: 'relative'
            }}
          >
            {/* Top Calibration Badge */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span className="badge badge-cyan" style={{ fontSize: '0.75rem', fontWeight: 800, padding: '0.35rem 0.85rem' }}>
                <Radio size={14} className="animate-pulse" /> AI PROCTOR CALIBRATION
              </span>
            </div>

            {/* Giant Circular 3-2-1 Countdown */}
            <div style={{
              position: 'relative',
              width: '136px',
              height: '136px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              {/* Outer pulsing ring */}
              <div style={{
                position: 'absolute',
                inset: 0,
                borderRadius: '50%',
                border: '3px solid var(--accent-cyan)',
                opacity: 0.35,
                animation: 'ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite'
              }} />
              <div style={{
                position: 'absolute',
                inset: '6px',
                borderRadius: '50%',
                border: '2px solid rgba(56, 189, 248, 0.4)',
                background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.12) 0%, rgba(16, 185, 129, 0.08) 100%)',
                backdropFilter: 'blur(8px)',
                boxShadow: 'var(--glow-cyan)'
              }} />
              <span style={{
                position: 'relative',
                fontSize: '4.2rem',
                fontWeight: 900,
                fontFamily: 'var(--font-mono, monospace)',
                lineHeight: 1,
                background: 'var(--grad-primary)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent'
              }}>
                {countdownSeconds > 0 ? countdownSeconds : 'GO!'}
              </span>
            </div>

            {/* Spoken Posture Guidance Header & Dynamic Tips */}
            <div>
              <h2 style={{
                fontSize: '1.6rem',
                fontWeight: 900,
                color: 'var(--text-primary)',
                letterSpacing: '-0.02em',
                margin: '0 0 0.5rem 0'
              }}>
                Sit properly, adjust yourself
              </h2>
              <p style={{
                fontSize: '0.9rem',
                color: 'var(--text-muted)',
                maxWidth: '430px',
                margin: '0 auto',
                lineHeight: 1.5
              }}>
                {countdownSeconds === 3 && 'Position yourself upright, face the camera directly, and straighten your shoulders.'}
                {countdownSeconds === 2 && 'Ensure your room lighting is clear and your microphone is unobstructed.'}
                {countdownSeconds === 1 && 'Take a steady breath. Synthesizing interview question 1 now!'}
                {countdownSeconds <= 0 && 'Connecting to AI Interview Proctor... Starting now!'}
              </p>
            </div>

            {/* Posture & Alignment Indicator Card */}
            <div style={{
              width: '100%',
              maxWidth: '430px',
              padding: '0.85rem 1rem',
              borderRadius: '12px',
              background: 'var(--bg-tertiary)',
              border: '1px solid var(--border-subtle)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: '0.75rem'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', textAlign: 'left' }}>
                <div style={{
                  width: '40px',
                  height: '40px',
                  borderRadius: '10px',
                  background: 'rgba(2, 132, 199, 0.12)',
                  border: '1px solid var(--border-glass)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'var(--accent-cyan)',
                  flexShrink: 0
                }}>
                  <UserCheck size={20} />
                </div>
                <div>
                  <div style={{ fontSize: '0.825rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                    Posture & Microphone Calibration
                  </div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    Voice guidance active: "Sit properly, adjust yourself"
                  </div>
                </div>
              </div>

              {/* Audio Replay Button */}
              <button
                onClick={speakCountdownGuidance}
                className="btn btn-ghost-cyan btn-sm"
                style={{
                  fontSize: '0.725rem',
                  fontWeight: 600,
                  color: 'var(--accent-cyan)',
                  background: 'rgba(2, 132, 199, 0.08)',
                  border: '1px solid var(--border-glass)',
                  borderRadius: '6px',
                  padding: '0.35rem 0.6rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  flexShrink: 0
                }}
                title="Replay voice guidance"
              >
                <Volume2 size={13} /> Replay
              </button>
            </div>

            {/* Target Role & Difficulty Info */}
            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              Interviewing for <strong style={{ color: 'var(--accent-cyan)' }}>{targetRole}</strong> ({difficulty} level)
            </div>

            {/* Cancel Button */}
            <button
              onClick={handleCancelCountdown}
              className="btn btn-ghost btn-sm"
              style={{
                fontSize: '0.78rem',
                color: 'var(--text-muted)',
                padding: '0.4rem 0.9rem',
                border: '1px solid var(--border-subtle)',
                borderRadius: '6px',
                background: 'var(--bg-tertiary)',
                cursor: 'pointer'
              }}
            >
              Cancel Preparation
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export const AIInterviewSimulator = React.memo(AIInterviewSimulatorComponent);
export default AIInterviewSimulator;
