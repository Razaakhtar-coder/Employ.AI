import os
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting


class JSearchProvider(JobProviderAdapter):
    """
    JSearch API Provider (via RapidAPI).
    Aggregates job postings from LinkedIn, Indeed, Glassdoor, and ZipRecruiter under license.
    """

    RAPIDAPI_HOST = "jsearch.p.rapidapi.com"
    API_URL = "https://jsearch.p.rapidapi.com/search"

    def __init__(self):
        self.api_key = os.getenv("RAPIDAPI_KEY", "")

    @property
    def name(self) -> str:
        return "JSearch (LinkedIn/Indeed Aggregator)"

    @property
    def is_enabled(self) -> bool:
        return bool(self.api_key)

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        if not self.is_enabled:
            return []

        postings: List[RawJobPosting] = []
        search_query = query or "Software Engineer Intern"
        if location:
            search_query += f" in {location}"

        headers = {
            "X-RapidAPI-Key": self.api_key,
            "X-RapidAPI-Host": self.RAPIDAPI_HOST
        }
        params = {
            "query": search_query,
            "page": str(page),
            "num_pages": "1"
        }

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(self.API_URL, headers=headers, params=params)
                if response.status_code == 200:
                    data = response.json().get("data", [])
                    for item in data:
                        raw_title = item.get("job_title", "")
                        raw_desc = item.get("job_description", "")
                        company = item.get("employer_name", "Global Enterprise")
                        apply_link = item.get("job_apply_link") or item.get("job_google_link", "")

                        postings.append(RawJobPosting(
                            source_id=f"jsearch-{item.get('job_id', raw_title)}",
                            source="JSearch (LinkedIn/Indeed)",
                            title=raw_title,
                            company=company,
                            location=item.get("job_city", "") or item.get("job_country", "Global"),
                            remote=bool(item.get("job_is_remote", False)),
                            job_type="internship" if item.get("job_employment_type") == "INTERN" else "full-time",
                            experience_level="intern" if "intern" in raw_title.lower() else "entry",
                            description=raw_desc[:3000],
                            required_skills=item.get("job_required_skills") or [],
                            apply_url=apply_link,
                            salary_range=item.get("job_salary") or None,
                            posted_date=item.get("job_posted_at_datetime_utc", "Recently")
                        ))
        except Exception as e:
            print(f"[WARN] Error fetching from JSearch provider: {e}")

        return postings


class AdzunaProvider(JobProviderAdapter):
    """
    Adzuna Job Search API Provider.
    Legal, licensed aggregator for UK, US, India, and global job boards.
    """

    def __init__(self):
        self.app_id = os.getenv("ADZUNA_APP_ID", "")
        self.app_key = os.getenv("ADZUNA_APP_KEY", "")
        self.country = os.getenv("ADZUNA_COUNTRY", "in")

    @property
    def name(self) -> str:
        return "Adzuna"

    @property
    def is_enabled(self) -> bool:
        return bool(self.app_id and self.app_key)

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        if not self.is_enabled:
            return []

        postings: List[RawJobPosting] = []
        url = f"https://api.adzuna.com/v1/api/jobs/{self.country}/search/{page}"
        params = {
            "app_id": self.app_id,
            "app_key": self.app_key,
            "what": query or "Engineering Graduate",
            "results_per_page": 20
        }
        if location:
            params["where"] = location

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(url, params=params)
                if response.status_code == 200:
                    results = response.json().get("results", [])
                    for item in results:
                        title = item.get("title", "")
                        company = item.get("company", {}).get("display_name", "Industry Partner")
                        desc = item.get("description", "")
                        apply_url = item.get("redirect_url", "")
                        salary_min = item.get("salary_min")
                        salary_max = item.get("salary_max")
                        salary_str = None
                        if salary_min or salary_max:
                            salary_str = f"₹{int(salary_min):,} - ₹{int(salary_max):,}" if salary_min and salary_max else f"₹{int(salary_min or salary_max):,}"

                        postings.append(RawJobPosting(
                            source_id=f"adzuna-{item.get('id', title)}",
                            source="Adzuna",
                            title=title,
                            company=company,
                            location=item.get("location", {}).get("display_name", "India / Remote"),
                            remote="remote" in (title + " " + desc).lower(),
                            job_type="internship" if "intern" in title.lower() else "full-time",
                            experience_level="intern" if "intern" in title.lower() else "entry",
                            description=desc,
                            required_skills=[],
                            apply_url=apply_url,
                            salary_range=salary_str,
                            posted_date=item.get("created", "Recently")
                        ))
        except Exception as e:
            print(f"[WARN] Error fetching from Adzuna provider: {e}")

        return postings
