import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  X, AlertCircle, Loader2, ShieldCheck, CheckCircle2, Sparkles, KeyRound
} from 'lucide-react';
import { BrandLogo } from './BrandLogo';

const GOOGLE_CLIENT_ID = (
  ((import.meta as any).env?.VITE_GOOGLE_CLIENT_ID || '').trim() ||
  '478210219727-5f0gv41g125sfb1fcrobo9e5k0m8vbgg.apps.googleusercontent.com'
);

const ADMIN_EMAIL = 'akhtarrakeeb52@gmail.com';

const GoogleLogoSvg: React.FC<{ size?: number }> = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={{ flexShrink: 0 }}>
    <path
      fill="#4285F4"
      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
    />
    <path
      fill="#34A853"
      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
    />
    <path
      fill="#FBBC05"
      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
    />
    <path
      fill="#EA4335"
      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
    />
  </svg>
);

function parseJwtPayload(token: string) {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
    return JSON.parse(jsonPayload);
  } catch {
    return null;
  }
}

export const AuthModal: React.FC = () => {
  const { 
    isAuthModalOpen, closeAuthModal,
    loginWithGoogle, error: authError, clearError 
  } = useAuth();

  const [localError, setLocalError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showAdminFallback, setShowAdminFallback] = useState(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState('');

  // Sanitize address bar on modal change
  useEffect(() => {
    if (typeof window !== 'undefined' && window.location && window.location.search) {
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [isAuthModalOpen]);

  // Clean state when modal opens
  useEffect(() => {
    if (isAuthModalOpen) {
      setLocalError(null);
      if (clearError) clearError();
      setShowAdminFallback(false);
      setAdminPasswordInput('');
    }
  }, [isAuthModalOpen, clearError]);

  const handleGoogleSuccess = async (response: any) => {
    if (!response || !response.credential) {
      setLocalError('Google Sign-In was cancelled or did not return credentials.');
      return;
    }

    setIsSubmitting(true);
    setLocalError(null);

    try {
      const payload = parseJwtPayload(response.credential);
      const googleEmail = payload?.email || '';
      const googleName = payload?.name || payload?.given_name || (googleEmail ? googleEmail.split('@')[0] : 'Google User');
      const googleAvatar = payload?.picture || undefined;

      await loginWithGoogle({
        id_token: response.credential,
        email: googleEmail,
        full_name: googleName,
        avatar_url: googleAvatar,
      });
    } catch (err: any) {
      console.error('Google Auth Handler Error:', err);
      const msg = err?.message || 'Google Sign-In failed. Please try again.';
      setLocalError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleButtonClick = () => {
    if (typeof window === 'undefined') return;

    if ((window as any).google?.accounts?.id) {
      try {
        (window as any).google.accounts.id.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: handleGoogleSuccess,
          auto_select: false,
          cancel_on_tap_outside: true,
        });

        // Trigger Google One-Tap or native prompt
        (window as any).google.accounts.id.prompt((notification: any) => {
          if (notification?.isNotDisplayed() || notification?.isSkippedMoment()) {
            const renderedBtn = document.querySelector('#google-btn-rendered-wrapper div[role="button"]') as HTMLElement;
            if (renderedBtn) {
              renderedBtn.click();
            }
          }
        });
      } catch (err: any) {
        console.warn('Google prompt error:', err);
      }
    } else {
      setLocalError('Connecting to Google services. Please try clicking again in a few seconds.');
    }
  };

  // Google GSI button renderer
  useEffect(() => {
    if (!isAuthModalOpen) return;

    const setupGoogleGsi = () => {
      if (typeof window === 'undefined' || !(window as any).google?.accounts?.id) return;

      try {
        (window as any).google.accounts.id.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: handleGoogleSuccess,
          auto_select: false,
          cancel_on_tap_outside: true,
        });

        const target = document.getElementById('google-btn-rendered-wrapper');
        if (target) {
          target.innerHTML = '';
          (window as any).google.accounts.id.renderButton(target, {
            type: 'standard',
            theme: 'filled_black',
            size: 'large',
            text: 'continue_with',
            shape: 'rectangular',
            logo_alignment: 'left',
            width: 360,
          });
        }
      } catch (err) {
        console.warn('Google GSI render error:', err);
      }
    };

    setupGoogleGsi();
    const t1 = setTimeout(setupGoogleGsi, 250);
    const t2 = setTimeout(setupGoogleGsi, 800);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [isAuthModalOpen]);

  // Admin Direct Login fallback handler
  const handleAdminPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminPasswordInput.trim()) {
      setLocalError('Please enter the admin password.');
      return;
    }
    setIsSubmitting(true);
    setLocalError(null);
    try {
      await loginWithGoogle({
        email: ADMIN_EMAIL,
        password: adminPasswordInput.trim(),
        full_name: 'Administrator',
      });
    } catch (err: any) {
      setLocalError(err?.message || 'Admin authentication failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const activeErrorMessage = localError || (authError && !authError.includes('502') ? authError : null);

  if (!isAuthModalOpen) return null;

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      background: 'rgba(3, 7, 18, 0.88)',
      backdropFilter: 'blur(12px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: '1rem',
      overflowY: 'auto'
    }}>
      <div 
        className="glass-card" 
        style={{
          width: '100%',
          maxWidth: '440px',
          padding: '2.5rem 2rem 2rem 2rem',
          borderRadius: '16px',
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.9), 0 0 40px rgba(56, 189, 248, 0.22)',
          border: '1px solid rgba(56, 189, 248, 0.2)',
          position: 'relative',
          animation: 'fadeIn 0.2s ease-out',
          margin: 'auto',
          background: 'linear-gradient(180deg, rgba(15, 23, 42, 0.95) 0%, rgba(7, 11, 20, 0.98) 100%)'
        }}
      >
        {/* Close Button */}
        <button
          onClick={closeAuthModal}
          style={{
            position: 'absolute',
            top: '1.25rem',
            right: '1.25rem',
            background: 'rgba(255, 255, 255, 0.06)',
            border: 'none',
            borderRadius: '50%',
            width: '32px',
            height: '32px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--text-muted)',
            cursor: 'pointer',
            transition: 'all 0.15s'
          }}
          title="Close"
        >
          <X size={16} />
        </button>

        {/* Brand Header */}
        <div style={{ textAlign: 'center', marginBottom: '1.75rem' }}>
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1rem' }}>
            <div style={{
              padding: '10px',
              borderRadius: '14px',
              background: 'radial-gradient(circle, rgba(56, 189, 248, 0.15) 0%, rgba(168, 85, 247, 0.05) 100%)',
              border: '1px solid rgba(56, 189, 248, 0.25)',
              boxShadow: '0 0 20px rgba(56, 189, 248, 0.25)'
            }}>
              <BrandLogo size={42} showBadge={false} />
            </div>
          </div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: '#f8fafc', margin: '0 0 0.5rem 0', letterSpacing: '-0.02em' }}>
            Sign in to Employ.AI
          </h2>
          <p style={{ fontSize: '0.875rem', color: '#94a3b8', margin: 0, lineHeight: 1.5 }}>
            Unlock AI Mock Interviews, 3D Skill Radars, and instant ATS Resume Scoring with 1 click.
          </p>
        </div>

        {/* Feature Pills */}
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '0.55rem',
          marginBottom: '1.75rem',
          background: 'rgba(255, 255, 255, 0.03)',
          border: '1px solid rgba(255, 255, 255, 0.06)',
          borderRadius: '12px',
          padding: '0.85rem 1rem'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <CheckCircle2 size={16} style={{ color: '#38bdf8', flexShrink: 0 }} />
            <span style={{ fontSize: '0.815rem', color: '#cbd5e1', fontWeight: 600 }}>
              Instant 1-Click login — no passwords to remember
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <Sparkles size={16} style={{ color: '#a855f7', flexShrink: 0 }} />
            <span style={{ fontSize: '0.815rem', color: '#cbd5e1', fontWeight: 600 }}>
              Real-time placement opportunities & ATS evaluation
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <ShieldCheck size={16} style={{ color: '#10b981', flexShrink: 0 }} />
            <span style={{ fontSize: '0.815rem', color: '#cbd5e1', fontWeight: 600 }}>
              End-to-end verified Google account security
            </span>
          </div>
        </div>

        {/* Error Banner */}
        {activeErrorMessage && (
          <div 
            id="auth-error-banner"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.65rem',
              padding: '0.8rem 1rem',
              borderRadius: '10px',
              background: 'rgba(239, 68, 68, 0.12)',
              border: '1.5px solid #ef4444',
              color: '#ef4444',
              fontSize: '0.825rem',
              fontWeight: 700,
              marginBottom: '1.25rem',
              lineHeight: 1.45
            }}
          >
            <AlertCircle size={16} style={{ color: '#ef4444', flexShrink: 0 }} />
            <span style={{ color: '#ef4444', fontWeight: 700 }}>{activeErrorMessage}</span>
          </div>
        )}

        {/* 1-CLICK GOOGLE BUTTON CONTAINER */}
        <div style={{ marginBottom: '1.25rem' }}>
          <div 
            id="google-btn-rendered-wrapper" 
            style={{ 
              width: '100%', 
              display: 'flex', 
              justifyContent: 'center', 
              minHeight: '48px' 
            }}
          >
            {/* Branded 1-Click Fallback Button */}
            <button
              type="button"
              onClick={handleGoogleButtonClick}
              disabled={isSubmitting}
              id="google-continue-button"
              style={{
                width: '100%',
                padding: '0.85rem 1.25rem',
                borderRadius: '10px',
                background: '#ffffff',
                color: '#1e293b',
                border: '1px solid #e2e8f0',
                fontSize: '0.975rem',
                fontWeight: 700,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.75rem',
                cursor: isSubmitting ? 'not-allowed' : 'pointer',
                boxShadow: '0 4px 14px rgba(0, 0, 0, 0.35)',
                transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.background = '#f8fafc';
                (e.currentTarget as HTMLElement).style.boxShadow = '0 6px 20px rgba(56, 189, 248, 0.3)';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.background = '#ffffff';
                (e.currentTarget as HTMLElement).style.boxShadow = '0 4px 14px rgba(0, 0, 0, 0.35)';
              }}
            >
              {isSubmitting ? (
                <>
                  <Loader2 size={19} className="spin" style={{ color: '#0284c7' }} />
                  <span>Connecting to Google...</span>
                </>
              ) : (
                <>
                  <GoogleLogoSvg size={20} />
                  <span>Continue with Google</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Optional Collapsible Admin Password Access */}
        <div style={{ marginTop: '1.25rem', textAlign: 'center' }}>
          {!showAdminFallback ? (
            <button
              type="button"
              onClick={() => setShowAdminFallback(true)}
              style={{
                background: 'transparent',
                border: 'none',
                color: '#64748b',
                fontSize: '0.75rem',
                fontWeight: 600,
                cursor: 'pointer',
                padding: '0.35rem 0.65rem',
                borderRadius: '6px',
                transition: 'color 0.15s',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.35rem'
              }}
              onMouseEnter={e => (e.currentTarget.style.color = '#94a3b8')}
              onMouseLeave={e => (e.currentTarget.style.color = '#64748b')}
            >
              <KeyRound size={12} />
              <span>Admin password access</span>
            </button>
          ) : (
            <form onSubmit={handleAdminPasswordSubmit} style={{
              background: 'rgba(255, 255, 255, 0.03)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              borderRadius: '10px',
              padding: '0.85rem',
              textAlign: 'left'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#38bdf8' }}>
                  Admin Password ({ADMIN_EMAIL})
                </span>
                <button
                  type="button"
                  onClick={() => setShowAdminFallback(false)}
                  style={{ background: 'transparent', border: 'none', color: '#64748b', fontSize: '0.725rem', cursor: 'pointer' }}
                >
                  Cancel
                </button>
              </div>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <input
                  type="password"
                  placeholder="Enter admin password"
                  value={adminPasswordInput}
                  onChange={e => setAdminPasswordInput(e.target.value)}
                  style={{
                    flex: 1,
                    padding: '0.55rem 0.75rem',
                    borderRadius: '6px',
                    background: 'rgba(0, 0, 0, 0.4)',
                    border: '1px solid var(--border-subtle)',
                    color: '#ffffff',
                    fontSize: '0.825rem',
                    outline: 'none'
                  }}
                />
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="btn btn-primary"
                  style={{ padding: '0.55rem 0.9rem', fontSize: '0.8rem', fontWeight: 700, borderRadius: '6px' }}
                >
                  {isSubmitting ? <Loader2 size={14} className="spin" /> : 'Log In'}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Security / Privacy Footnote */}
        <div style={{
          marginTop: '1.5rem',
          paddingTop: '1rem',
          borderTop: '1px solid rgba(255, 255, 255, 0.06)',
          textAlign: 'center'
        }}>
          <p style={{
            margin: 0,
            fontSize: '0.72rem',
            color: '#64748b',
            lineHeight: 1.5
          }}>
            By continuing, you accept the Employ.AI Terms of Service. Your data is encrypted and protected by Google Identity Services.
          </p>
        </div>
      </div>
    </div>
  );
};
