/**
 * Safe URL sanitization and formatting helper for resume links.
 * Guarantees 100% valid, clickable, standards-compliant hyperlinks in both
 * live browser preview and exported PDF / DOC documents.
 */

/**
 * Strips accidental mailto: prefix, surrounding brackets/quotes, and whitespace from email.
 */
export const sanitizeEmail = (rawEmail?: string | null): string => {
  if (!rawEmail) return '';
  let email = String(rawEmail).trim();
  // Strip surrounding quotes, brackets, or angle brackets
  email = email.replace(/^["'<(\[]+|[>"')\]]+$/g, '').trim();
  // Strip leading mailto:
  email = email.replace(/^mailto:\s*/i, '').trim();
  return email;
};

/**
 * Produces a clean, valid mailto: link for anchor hrefs.
 */
export const formatMailto = (rawEmail?: string | null): string => {
  const clean = sanitizeEmail(rawEmail);
  if (!clean || !clean.includes('@')) return '';
  return `mailto:${clean}`;
};

/**
 * Produces a clean, valid tel: link for phone numbers.
 */
export const formatTel = (rawPhone?: string | null): string => {
  if (!rawPhone) return '';
  let phone = String(rawPhone).trim().replace(/^tel:\s*/i, '');
  // Keep digits, plus, dashes, and parentheses for tel scheme
  const cleanPhone = phone.replace(/[^\d+]/g, '');
  if (!cleanPhone || cleanPhone.length < 5) return '';
  return `tel:${cleanPhone}`;
};

/**
 * Formats platform-specific handles or full URLs into verified https:// links.
 */
export const formatSocialUrl = (
  rawVal?: string | null,
  type: 'linkedin' | 'github' | 'leetcode' | 'codeforces' | 'portfolio' | 'generic' = 'generic'
): string => {
  if (!rawVal) return '';
  let val = String(rawVal).trim().replace(/^["'<(\[]+|[>"')\]]+$/g, '').trim();
  if (!val) return '';

  if (type === 'linkedin') {
    if (/linkedin\.com/i.test(val)) {
      return sanitizeAndFormatUrl(val);
    }
    // Clean handle like "in/username" or "@username" or "username"
    const handle = val.replace(/^@/, '').replace(/^in\//i, '').replace(/^linkedin\//i, '').trim();
    if (!handle) return '';
    return `https://www.linkedin.com/in/${handle}`;
  }

  if (type === 'github') {
    if (/github\.com/i.test(val)) {
      return sanitizeAndFormatUrl(val);
    }
    const handle = val.replace(/^@/, '').replace(/^github\//i, '').trim();
    if (!handle) return '';
    return `https://github.com/${handle}`;
  }

  if (type === 'leetcode') {
    if (/leetcode\.com/i.test(val)) {
      return sanitizeAndFormatUrl(val);
    }
    const handle = val.replace(/^@/, '').replace(/^u\//i, '').trim();
    if (!handle) return '';
    return `https://leetcode.com/u/${handle}`;
  }

  if (type === 'codeforces') {
    if (/codeforces\.com/i.test(val)) {
      return sanitizeAndFormatUrl(val);
    }
    const handle = val.replace(/^@/, '').replace(/^profile\//i, '').trim();
    if (!handle) return '';
    return `https://codeforces.com/profile/${handle}`;
  }

  return sanitizeAndFormatUrl(val);
};

export const sanitizeAndFormatUrl = (rawUrl?: string | null): string => {
  if (!rawUrl) return '';
  let url = String(rawUrl).trim();
  if (!url) return '';

  // Remove surrounding quotes, parentheses, brackets, or markdown syntax
  url = url.replace(/^["'<(\[]+|[>"')\]]+$/g, '').trim();
  if (!url) return '';

  // Handle mailto: and tel: schemes
  if (url.startsWith('mailto:')) {
    return formatMailto(url);
  }
  if (url.startsWith('tel:')) {
    return formatTel(url);
  }

  // Remove accidental duplicate or stacked schemes like https://https:// or http://https://
  while (/^https?:\/\/(https?:\/\/)+/i.test(url)) {
    url = url.replace(/^https?:\/\//i, '');
  }

  // Strip leading extra slashes after scheme, and reject naked schemes
  url = url.replace(/^(https?:\/\/)\/+/i, '$1');
  if (/^https?:\/\/+$/i.test(url) || url.toLowerCase() === 'http' || url.toLowerCase() === 'https') {
    return '';
  }

  // Upgrade http:// to https://
  if (url.startsWith('http://')) {
    url = url.replace(/^http:\/\//i, 'https://');
  }

  // Prepend https:// if no protocol exists
  if (!/^https?:\/\//i.test(url)) {
    url = `https://${url}`;
  }

  // Replace raw whitespace with %20 to prevent browser URL truncation / about:blank#blocked
  url = url.replace(/\s+/g, '%20');

  try {
    const parsed = new URL(url);
    // Validate that the host has at least a domain dot (e.g. site.com) or is localhost
    if (!parsed.hostname || (!parsed.hostname.includes('.') && parsed.hostname !== 'localhost')) {
      return '';
    }
    if (parsed.hostname.length < 3) {
      return '';
    }
    let res = parsed.toString();
    // Normalize: remove trailing slash if original URL didn't have a path or trailing slash
    if (res.endsWith('/') && !url.endsWith('/') && (parsed.pathname === '/' || parsed.pathname === '')) {
      res = res.slice(0, -1);
    }
    return res;
  } catch {
    return '';
  }
};

/**
 * Robust click handler that safely opens links in a new window/tab,
 * avoiding browser popup blockers or blocked navigation.
 */
export const handleSafeLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, rawUrl?: string) => {
  e.stopPropagation();
  const validUrl = sanitizeAndFormatUrl(rawUrl);
  if (!validUrl) {
    e.preventDefault();
    return;
  }

  // Don't intercept mailto: or tel: links with window.open
  if (validUrl.startsWith('mailto:') || validUrl.startsWith('tel:')) {
    return;
  }

  try {
    const opened = window.open(validUrl, '_blank', 'noopener,noreferrer');
    if (opened) {
      opened.opener = null;
      e.preventDefault();
    }
  } catch (err) {
    // If window.open is blocked by strict browser policy, default <a href="..."> navigation will proceed safely
  }
};

/**
 * Strips accidental leading bullet symbols (•, ◦, ▪, ▫, ●, ○, ◆, ◈, ⁃, ‣, -, *, –, —),
 * unicode markers, and extraneous whitespace from bullet point strings.
 * This ensures that when the text is rendered inside an HTML <li> element or exported,
 * only a single, perfectly aligned bullet appears without double-bullet artifacts (• • ).
 */
export const cleanBulletText = (text?: string | null): string => {
  if (!text) return '';
  let s = String(text).trim();
  // Strip nested or combined bullet markers like "• • ", "- • ", "* • "
  for (let i = 0; i < 3; i++) {
    s = s.replace(/^[\s\u2022\u2023\u25E6\u2043\u2219\u25AA\u25AB\u25CF\u25CB\u25C6\u25C8\u25D8\u00B7\u2013\u2014\*\-]+\s*/u, '');
  }
  return s.trim();
};
