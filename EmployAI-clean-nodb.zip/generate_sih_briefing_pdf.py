import os
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether, HRFlowable
)
from reportlab.pdfgen import canvas

class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super(NumberedCanvas, self).__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_number(num_pages)
            super(NumberedCanvas, self).showPage()
        super(NumberedCanvas, self).save()

    def draw_page_number(self, page_count):
        self.saveState()
        self.setFont("Helvetica", 8)
        self.setFillColor(colors.HexColor("#64748b"))
        
        # Header (pages > 1)
        if self._pageNumber > 1:
            self.drawString(54, 750, "Employ.AI — Smart India Hackathon (SIH) Presentation Briefing")
            self.setStrokeColor(colors.HexColor("#cbd5e1"))
            self.setLineWidth(0.5)
            self.line(54, 742, 558, 742)
        
        # Footer
        text = f"Page {self._pageNumber} of {page_count}"
        self.drawRightString(558, 36, text)
        self.drawString(54, 36, "CONFIDENTIAL — Team Presentation Briefing & Speaker Script")
        self.setStrokeColor(colors.HexColor("#cbd5e1"))
        self.setLineWidth(0.5)
        self.line(54, 48, 558, 48)
        
        self.restoreState()

def generate_pdf(output_path: str):
    doc = SimpleDocTemplate(
        output_path,
        pagesize=letter,
        leftMargin=54,
        rightMargin=54,
        topMargin=54,
        bottomMargin=54
    )

    styles = getSampleStyleSheet()
    
    # Custom Color Palette
    PRIMARY = colors.HexColor("#0f172a")     # Deep Slate
    SECONDARY = colors.HexColor("#0284c7")   # Electric Cyan / Sky
    ACCENT = colors.HexColor("#10b981")      # Emerald Green
    VIOLET = colors.HexColor("#8b5cf6")      # Vibrant Violet
    TEXT_DARK = colors.HexColor("#1e293b")   # Slate 800
    TEXT_MUTED = colors.HexColor("#475569")  # Slate 600
    BG_LIGHT = colors.HexColor("#f8fafc")    # Off-white / light slate
    BORDER_COLOR = colors.HexColor("#cbd5e1")# Slate 300

    # Custom Typography Styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=22,
        leading=26,
        textColor=PRIMARY,
        spaceAfter=4
    )
    
    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=SECONDARY,
        spaceAfter=12
    )

    h1_style = ParagraphStyle(
        'Header1',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=14,
        leading=18,
        textColor=PRIMARY,
        spaceBefore=14,
        spaceAfter=6,
        keepWithNext=True
    )

    h2_style = ParagraphStyle(
        'Header2',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=15,
        textColor=SECONDARY,
        spaceBefore=10,
        spaceAfter=4,
        keepWithNext=True
    )

    body_style = ParagraphStyle(
        'BodyDark',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=13.5,
        textColor=TEXT_DARK,
        spaceAfter=6
    )

    bullet_style = ParagraphStyle(
        'BulletText',
        parent=body_style,
        leftIndent=12,
        firstLineIndent=-8,
        spaceAfter=3
    )

    callout_style = ParagraphStyle(
        'CalloutText',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=9,
        leading=13,
        textColor=colors.HexColor("#0369a1")
    )

    badge_style = ParagraphStyle(
        'BadgeText',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8,
        leading=10,
        textColor=colors.white
    )

    story = []

    # ================= PAGE 1: TITLE & EXECUTIVE SUMMARY =================
    story.append(Paragraph("Employ.AI — Platform Architecture & SIH Presentation Guide", title_style))
    story.append(Paragraph("Smart India Hackathon (SIH) • 6-Member Team Role Division (2-2-2 Structure)", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=SECONDARY, spaceAfter=10))

    # Meta Info Card Table
    info_data = [
        [
            Paragraph("<b>Project Name:</b> Employ.AI", body_style),
            Paragraph("<b>Target Domain:</b> AI Career Readiness & Education 4.0", body_style)
        ],
        [
            Paragraph("<b>Architecture:</b> React 19 + Three.js + FastAPI + Gemini 1.5", body_style),
            Paragraph("<b>Team Structure:</b> 3 Domain Pillars (2 Speakers per Pillar)", body_style)
        ]
    ]
    info_table = Table(info_data, colWidths=[240, 264])
    info_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), BG_LIGHT),
        ('BOX', (0,0), (-1,-1), 1, BORDER_COLOR),
        ('INNERGRID', (0,0), (-1,-1), 0.5, BORDER_COLOR),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 10))

    story.append(Paragraph("1. Executive Summary & 30-Second Elevator Pitch", h1_style))
    story.append(Paragraph(
        "<b>The Challenge:</b> In Indian higher education and campus recruitment, over 70% of engineering graduates face skill mismatches because standard resumes are static text files that ATS algorithms either reject or fail to verify. Universities lack real-time curriculum alignment with industry, and recruiters spend weeks filtering unverified claims.",
        body_style
    ))
    story.append(Paragraph(
        "<b>The Solution:</b> <b>Employ.AI</b> is an end-to-end intelligent career ecosystem uniting <b>Students, Universities, and Recruiters</b>. It combines high-DPI OCR resume vectorization, WebGL 3D volumetric laser scanning, generative AI STAR formula enhancements, personalized 6-week learning roadmaps, and instant job tailoring with 6 ATS-compliant design templates.",
        body_style
    ))

    # Pitch Box
    pitch_text = Paragraph(
        "<b>🎯 30-Second Opening Pitch for Judges:</b><br/>"
        "<i>\"Respected Judges, traditional campus placements rely on static PDF resumes that cannot prove competency. Employ.AI transforms career readiness into a dynamic, 3-dimensional verified skill ecosystem. From 3D volumetric holographic mesh inspection and Gemini-powered STAR rewrites to curriculum taxonomy vectorization and automated job tailoring, Employ.AI guarantees that every student is verifiably placement-ready and industry-aligned on Day 1.\"</i>",
        callout_style
    )
    pitch_table = Table([[pitch_text]], colWidths=[504])
    pitch_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#f0f9ff")),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor("#38bdf8")),
        ('LEFTPADDING', (0,0), (-1,-1), 10),
        ('RIGHTPADDING', (0,0), (-1,-1), 10),
        ('TOPPADDING', (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(pitch_table)
    story.append(Spacer(1, 12))

    # ================= TEAM ROLE MATRIX TABLE =================
    story.append(Paragraph("2. Team Role Division Matrix (2-2-2 Structure)", h1_style))
    
    role_data = [
        [
            Paragraph("<b>Domain & Pillar</b>", body_style),
            Paragraph("<b>Speakers</b>", body_style),
            Paragraph("<b>Key Core Responsibilities & Focus</b>", body_style)
        ],
        [
            Paragraph("<b>Pillar 1:<br/>Auth & Security</b>", body_style),
            Paragraph("<b>Member 1 &<br/>Member 2</b>", body_style),
            Paragraph("• JWT dual-token flow & bcrypt password hashing<br/>• 3-Tier Enterprise Role-Based Access Control (Student/University/Recruiter)<br/>• Department-level data sandboxing & FERPA/GDPR compliance", body_style)
        ],
        [
            Paragraph("<b>Pillar 2:<br/>Frontend & UI/UX</b>", body_style),
            Paragraph("<b>Member 3 &<br/>Member 4</b>", body_style),
            Paragraph("• React 19 + TypeScript + Vite + Glassmorphic Design<br/>• Three.js WebGL 3D Hologram Volumetric Scanner & Raycast Camera<br/>• Interactive Job Tailoring Studio & 6 ATS Resume Design Templates", body_style)
        ],
        [
            Paragraph("<b>Pillar 3:<br/>Backend & AI Logic</b>", body_style),
            Paragraph("<b>Member 5 &<br/>Member 6</b>", body_style),
            Paragraph("• FastAPI async microservices + Pydantic v2 schemas<br/>• Dual-engine PDF extraction (pypdfium2 + pdfplumber)<br/>• Gemini 1.5 Pro/Flash STAR rewriting & 6-week adaptive roadmaps", body_style)
        ]
    ]

    role_table = Table(role_data, colWidths=[110, 85, 309])
    role_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#0f172a")),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('BOX', (0,0), (-1,-1), 1, BORDER_COLOR),
        ('INNERGRID', (0,0), (-1,-1), 0.5, BORDER_COLOR),
        ('BACKGROUND', (0,1), (-1,1), colors.HexColor("#f8fafc")),
        ('BACKGROUND', (0,2), (-1,2), colors.HexColor("#ffffff")),
        ('BACKGROUND', (0,3), (-1,3), colors.HexColor("#f8fafc")),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(role_table)

    # ================= PAGE 2: DEEP DIVE DOMAINS 1 & 2 =================
    story.append(PageBreak())

    story.append(Paragraph("3. Deep-Dive Speaker Scripts & Technical Mastery", h1_style))
    story.append(HRFlowable(width="100%", thickness=1, color=SECONDARY, spaceAfter=8))

    # DOMAIN 1: AUTHENTICATION & SECURITY
    story.append(Paragraph("🔒 Domain 1: Authentication, Authorization & Enterprise Security (Speakers 1 & 2)", h1_style))
    
    story.append(Paragraph("<b>Speaker 1 Focus: Cryptographic Token Pipeline & Zero-Trust Sessions</b>", h2_style))
    story.append(Paragraph("• <b>Dual-Token JWT Lifecycle:</b> Short-lived HMAC-SHA256 Access Tokens paired with secure Refresh Tokens, preventing replay attacks.", bullet_style))
    story.append(Paragraph("• <b>Password Security:</b> 12-round salted Bcrypt password hashing safeguarding student and recruiter credentials.", bullet_style))
    story.append(Paragraph("• <b>Transport & API Protection:</b> Strict CORS origin validation, HTTP-only cookie support, rate-limiting, and Pydantic input sanitization.", bullet_style))
    story.append(Paragraph("• <i>Speaking Script Cue:</i> \"We engineered zero-trust authentication using salted bcrypt encryption and dual-token JWTs, ensuring enterprise-grade isolation across all candidate records.\"", callout_style))

    story.append(Spacer(1, 4))
    story.append(Paragraph("<b>Speaker 2 Focus: 3-Tier Enterprise Role-Based Access Control (RBAC)</b>", h2_style))
    story.append(Paragraph("• <b>3 Distinct Portal Ecosystems:</b><br/>"
                           "  1. <i>Student Portal:</i> Resume studio, 3D scanner, gap analysis, and 1-click verified placement applications.<br/>"
                           "  2. <i>Recruiter / Industry Portal:</i> Candidate search, automated ranking against JD, and shortlisting pipeline.<br/>"
                           "  3. <i>Academic / University Portal:</i> Department batch analytics, syllabus ingestion, and curriculum taxonomy vectorization.", bullet_style))
    story.append(Paragraph("• <b>Data Privacy & Compliance:</b> Department-level isolation and FERPA/GDPR aligned audit logging.", bullet_style))
    story.append(Paragraph("• <i>Speaking Script Cue:</i> \"Our RBAC engine dynamically enforces permission gates for students, recruiters, and university deans with single-click role switching.\"", callout_style))

    story.append(Spacer(1, 10))

    # DOMAIN 2: FRONTEND & UI/UX
    story.append(Paragraph("🎨 Domain 2: Frontend Architecture, 3D Hologram & UI/UX (Speakers 3 & 4)", h1_style))
    
    story.append(Paragraph("<b>Speaker 3 Focus: Modern React 19 Architecture & Design System</b>", h2_style))
    story.append(Paragraph("• <b>Core Stack:</b> React 19, TypeScript, Vite 8.2 (sub-second HMR & 1.1s production builds), and modular Vanilla CSS design tokens.", bullet_style))
    story.append(Paragraph("• <b>Glassmorphism Design System:</b> Tailored HSL color palette featuring Cyber Cyan (<code>#00f2fe</code>), Emerald Matrix (<code>#10b981</code>), and Deep Obsidian (<code>#0b112c</code>).", bullet_style))
    story.append(Paragraph("• <b>Web Audio Synthesized Sound Engine:</b> Zero-dependency synthesized audio FX (laser sweeps, section lock-on chimes) with persistent mute controls.", bullet_style))
    story.append(Paragraph("• <i>Speaking Script Cue:</i> \"The frontend is built on React 19 and Vite for instant 60 FPS rendering, featuring an immersive dark/light glassmorphic HUD designed to wow users at first glance.\"", callout_style))

    story.append(Spacer(1, 4))
    story.append(Paragraph("<b>Speaker 4 Focus: Three.js 3D WebGL Hologram & Resume Template Studio</b>", h2_style))
    story.append(Paragraph("• <b>3D Holographic Volumetric Scanner:</b> Three.js WebGL canvas rendering a 3D document mesh, animated laser sweep line, and direct raycasting allowing users to click any resume section in 3D space with smooth camera zooming.", bullet_style))
    story.append(Paragraph("• <b>Neural ATS Heatmap Mode:</b> Highlights keyword density, competency clusters, and quantifiable metrics in glowing emerald/cyan.", bullet_style))
    story.append(Paragraph("• <b>6-Template Resume Design Studio:</b> 1-click live switching between ATS Classic (Harvard Standard), Modern Tech, Corporate Professional, Minimalist Swiss, Executive Leadership, and Student/Fresher templates.", bullet_style))
    story.append(Paragraph("• <b>Unified Job Tailoring Studio:</b> Interactive screencast simulation showing copy-paste from job boards, neural keyword extraction, and instant +32% ATS score surge.", bullet_style))
    story.append(Paragraph("• <i>Speaking Script Cue:</i> \"Our 3D Hologram isn't just visual eye-candy—it is an interactive raycasted mesh that lets candidates inspect their resume's spatial ATS keyword density in real-time.\"", callout_style))

    # ================= PAGE 3: DOMAIN 3 & PRESENTATION SCRIPT =================
    story.append(PageBreak())

    # DOMAIN 3: BACKEND & AI LOGIC
    story.append(Paragraph("⚙️ Domain 3: Backend Microservices, AI Logic & System Integration (Speakers 5 & 6)", h1_style))
    story.append(HRFlowable(width="100%", thickness=1, color=SECONDARY, spaceAfter=8))

    story.append(Paragraph("<b>Speaker 5 Focus: Asynchronous FastAPI Microservices & Robust Ingestion Pipeline</b>", h2_style))
    story.append(Paragraph("• <b>FastAPI Async Engine:</b> High-throughput async REST endpoints delivering sub-150ms response times under concurrent loads.", bullet_style))
    story.append(Paragraph("• <b>Dual-Engine Document Ingestion:</b> Combines <code>pypdfium2</code> for high-resolution vector text rendering and <code>pdfplumber</code> for bounding-box spatial geometry extraction.", bullet_style))
    story.append(Paragraph("• <b>Pydantic v2 Contract Validation:</b> Strict type enforcement and JSON serialization guaranteeing 100% structured schema integrity across all API payloads.", bullet_style))
    story.append(Paragraph("• <i>Speaking Script Cue:</i> \"Our backend pipeline utilizes dual-engine PDF vectorization and Pydantic v2 schemas to ensure zero text loss during document ingestion.\"", callout_style))

    story.append(Spacer(1, 4))
    story.append(Paragraph("<b>Speaker 6 Focus: Google Gemini 1.5 AI Orchestration & Adaptive Learning Logic</b>", h2_style))
    story.append(Paragraph("• <b>Google Gemini 1.5 Pro / Flash Integration:</b> Orchestrates deep contextual understanding, domain detection across 8+ engineering disciplines, and deterministic JSON generation.", bullet_style))
    story.append(Paragraph("• <b>STAR Formula AI Bullet Optimization:</b> Transforms weak, generic bullet points into high-impact accomplishments: <i>Accomplished [X], as measured by [Y], by doing [Z]</i> with quantified metrics.", bullet_style))
    story.append(Paragraph("• <b>6-Week Adaptive Learning Roadmaps:</b> Identifies skill gaps between the student's profile and target job descriptions, generating milestone-based weekly tasks and curated GitHub learning repositories.", bullet_style))
    story.append(Paragraph("• <b>Curriculum Taxonomy Vectorization:</b> Ingests university syllabus files to map academic modules directly against corporate skill demand.", bullet_style))
    story.append(Paragraph("• <i>Speaking Script Cue:</i> \"We leverage Gemini 1.5 to perform deterministic STAR transformations and automatically construct personalized 6-week roadmaps that close competency gaps.\"", callout_style))

    story.append(Spacer(1, 10))

    # ================= MINUTE-BY-MINUTE PITCH PLAN =================
    story.append(Paragraph("4. Minute-by-Minute Pitch Plan (6-Minute Total Allotment)", h1_style))
    
    pitch_plan_data = [
        [
            Paragraph("<b>Time</b>", body_style),
            Paragraph("<b>Speaker</b>", body_style),
            Paragraph("<b>Stage & On-Screen Action</b>", body_style),
            Paragraph("<b>Key Message Delivered</b>", body_style)
        ],
        [
            Paragraph("0:00 - 0:45", body_style),
            Paragraph("Lead / Speaker 1", body_style),
            Paragraph("Landing Page & Overview HUD", body_style),
            Paragraph("Problem Statement: Why traditional resumes fail Indian graduates & recruiters.", body_style)
        ],
        [
            Paragraph("0:45 - 1:45", body_style),
            Paragraph("Speakers 1 & 2", body_style),
            Paragraph("Auth Modal & Role Switching", body_style),
            Paragraph("Enterprise Security: JWT tokens, Bcrypt, 3-tier RBAC (Student/University/Recruiter).", body_style)
        ],
        [
            Paragraph("1:45 - 3:15", body_style),
            Paragraph("Speakers 3 & 4", body_style),
            Paragraph("3D Hologram & Resume Studio", body_style),
            Paragraph("UI/UX & WebGL: Raycasting, ATS Heatmap, 6 Templates, Live Screencast tailoring.", body_style)
        ],
        [
            Paragraph("3:15 - 4:45", body_style),
            Paragraph("Speakers 5 & 6", body_style),
            Paragraph("FastAPI, STAR AI & Roadmaps", body_style),
            Paragraph("AI Engine: Gemini 1.5 STAR optimization, 6-week adaptive roadmaps, taxonomy alignment.", body_style)
        ],
        [
            Paragraph("4:45 - 6:00", body_style),
            Paragraph("All Members", body_style),
            Paragraph("Recruiter Portal & Q&A", body_style),
            Paragraph("Value proposition, scalability, and closing statement for SIH judges.", body_style)
        ]
    ]

    pitch_table = Table(pitch_plan_data, colWidths=[65, 80, 155, 204])
    pitch_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#0f172a")),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('BOX', (0,0), (-1,-1), 1, BORDER_COLOR),
        ('INNERGRID', (0,0), (-1,-1), 0.5, BORDER_COLOR),
        ('BACKGROUND', (0,1), (-1,1), colors.HexColor("#f8fafc")),
        ('BACKGROUND', (0,2), (-1,2), colors.HexColor("#ffffff")),
        ('BACKGROUND', (0,3), (-1,3), colors.HexColor("#f8fafc")),
        ('BACKGROUND', (0,4), (-1,4), colors.HexColor("#ffffff")),
        ('BACKGROUND', (0,5), (-1,5), colors.HexColor("#f8fafc")),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('LEFTPADDING', (0,0), (-1,-1), 5),
        ('RIGHTPADDING', (0,0), (-1,-1), 5),
    ]))
    story.append(pitch_table)

    # ================= PAGE 4: JUDGE QUESTIONS & ANSWERS =================
    story.append(PageBreak())

    story.append(Paragraph("5. Anticipated Judge Questions & Bulletproof Answers", h1_style))
    story.append(HRFlowable(width="100%", thickness=1, color=SECONDARY, spaceAfter=8))

    qa_list = [
        (
            "Q1: How is Employ.AI different from standard ATS checkers like ResumeWorded or Jobscan?",
            "<b>Answer:</b> Standard ATS checkers only perform shallow string matching on text. Employ.AI is a full-stack career platform that (1) parses resumes with high-DPI vector extraction, (2) visualizes density via Three.js 3D raycast heatmaps, (3) uses Gemini 1.5 to perform real-time STAR formula rewriting, and (4) connects students directly with University deans and verified Recruiter pipelines in a single closed-loop ecosystem."
        ),
        (
            "Q2: How do you prevent AI hallucinations in resume enhancement?",
            "<b>Answer:</b> We enforce strict ground-truth fact preservation: the AI is explicitly constrained to only elevate phrasing, STAR action verbs, and quantifiable metrics based on the student's verified experience. It never invents fictional employers, degrees, or certifications. All changes are tracked in an interactive audit diff ledger where students can accept, edit, or revert single modifications."
        ),
        (
            "Q3: How does your 3D Hologram improve user experience without causing browser lag?",
            "<b>Answer:</b> Our Three.js renderer uses hardware-accelerated WebGL instanced geometries, texture caching, and automatic pause triggers when the document tab is inactive. By implementing raycasting directly on the 3D plane, clicking any section smoothly interpolates the camera to exact coordinates (z=2.95) with zero UI obstruction."
        ),
        (
            "Q4: How does the system scale to thousands of university students simultaneously?",
            "<b>Answer:</b> FastAPI's asynchronous non-blocking event loop handles thousands of concurrent requests. Database queries are indexed on student IDs and skill taxonomies. PDF processing and LLM calls run asynchronously with client-side optimistic UI updates, ensuring sub-second perceived response times."
        ),
        (
            "Q5: What is the business model and real-world deployment feasibility?",
            "<b>Answer:</b> Employ.AI follows a B2B2C model: (1) SaaS subscription for Universities for institutional NAAC/NIRF placement analytics and syllabus gap detection, (2) Enterprise hiring tier for Recruiters for verified candidate matching, and (3) Freemium tier for Students with premium 1-on-1 AI interview simulations."
        )
    ]

    for q, a in qa_list:
        story.append(Paragraph(f"<b>{q}</b>", h2_style))
        story.append(Paragraph(a, body_style))
        story.append(Spacer(1, 4))

    story.append(Spacer(1, 8))
    
    # Final Encouragement Box
    final_box = Table([[
        Paragraph(
            "<b>🌟 Final Words for Tomorrow's Presentation:</b><br/>"
            "• Speak with confidence and clear handoffs between speakers: <i>\"Now I pass over to Speaker 3 to showcase our 3D UI/UX...\"</i><br/>"
            "• Keep the live application running on localhost:5173 with a pre-loaded resume ready for instant switching.<br/>"
            "• Highlight that Employ.AI addresses real NEP 2020 & Education 4.0 goals for Indian youth!",
            callout_style
        )
    ]], colWidths=[504])
    final_box.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#f0fdf4")),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor("#10b981")),
        ('LEFTPADDING', (0,0), (-1,-1), 10),
        ('RIGHTPADDING', (0,0), (-1,-1), 10),
        ('TOPPADDING', (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(final_box)

    # Build Document
    doc.build(story, canvasmaker=NumberedCanvas)
    print(f"Successfully generated SIH PDF at: {output_path}")

if __name__ == "__main__":
    out_dir = r"c:\Users\RAZA AKHTAR\Desktop\Employ.AI"
    pdf_path = os.path.join(out_dir, "EmployAI_SIH_Presentation_Briefing.pdf")
    generate_pdf(pdf_path)
