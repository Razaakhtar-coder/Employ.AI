from datetime import datetime, timezone, timedelta
import hashlib
import hmac
import logging
import re
import time
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.dependencies import get_db, get_current_user, require_admin_user, ADMIN_EMAIL
from app.core.rate_limit import enforce_rate_limit
from app.models.user import User
from app.models.payment import Payment
from app.schemas.payment import (
    PaymentSubmitRequest, PaymentResponse, PaymentStatusResponse,
    PaymentVerifyInstantRequest, AdminVerifyPaymentRequest, AdminGrantPremiumRequest,
    RazorpayCreateOrderRequest, RazorpayOrderResponse, RazorpayVerifyRequest, RazorpayConfigResponse
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/payments", tags=["Payments & Premium Subscription"])


def _clean_utr(utr: str) -> str:
    """Normalize UTR to uppercase with spaces and dashes stripped."""
    return re.sub(r"[\s\-_]+", "", utr).strip().upper()


def _is_valid_utr_format(utr: str) -> bool:
    """
    Validates standard Indian UPI UTR / Transaction Reference ID.
    Usually 12 digits (or alphanumeric transaction references 8-30 characters).
    """
    cleaned = _clean_utr(utr)
    if len(cleaned) < 8 or len(cleaned) > 35:
        return False
    # Typical UPI UTR is numeric or alphanumeric (e.g. 402837492819 or T2409...)
    return bool(re.match(r"^[A-Z0-9]{8,35}$", cleaned))


def _format_payment_response(
    p: Payment,
    user_email: Optional[str] = None,
    user_name: Optional[str] = None
) -> PaymentResponse:
    """Helper to convert Payment ORM entity to API response schema."""
    return PaymentResponse(
        id=p.id,
        user_id=p.user_id,
        user_email=user_email or (p.user.email if getattr(p, "user", None) else None),
        user_name=user_name or (p.user.full_name if getattr(p, "user", None) else None),
        amount=p.amount,
        currency=p.currency,
        upi_id=p.upi_id,
        utr_number=p.utr_number,
        payer_name=p.payer_name,
        payer_upi=p.payer_upi,
        payment_app=p.payment_app,
        screenshot_url=p.screenshot_url,
        status=p.status,
        verified_at=p.verified_at,
        verified_by=p.verified_by,
        notes=p.notes,
        razorpay_order_id=getattr(p, "razorpay_order_id", None),
        razorpay_payment_id=getattr(p, "razorpay_payment_id", None),
        plan_type=getattr(p, "plan_type", "monthly") or "monthly",
        valid_until=getattr(p, "valid_until", None),
        created_at=p.created_at
    )


def get_razorpay_client():
    """Initializes official Razorpay SDK client if credentials are configured."""
    try:
        import razorpay
        if settings.RAZORPAY_KEY_ID and settings.RAZORPAY_KEY_SECRET:
            return razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
    except Exception as exc:
        logger.warning("Could not initialize razorpay client: %s", exc)
    return None


def verify_razorpay_signature(order_id: str, payment_id: str, signature: str) -> bool:
    """
    Cryptographically verifies the Razorpay HMAC SHA256 payment signature.
    """
    # 1. Try Razorpay official SDK verification if available
    client = get_razorpay_client()
    if client and not settings.RAZORPAY_KEY_ID.startswith("rzp_test_employai_demo"):
        try:
            client.utility.verify_payment_signature({
                'razorpay_order_id': order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature
            })
            return True
        except Exception as e:
            logger.info("Razorpay SDK verification exception, verifying with HMAC SHA256: %s", e)

    # 2. Direct HMAC SHA256 verification (standard Razorpay algorithm)
    try:
        msg = f"{order_id}|{payment_id}".encode("utf-8")
        secret = settings.RAZORPAY_KEY_SECRET.encode("utf-8")
        expected_signature = hmac.new(secret, msg, hashlib.sha256).hexdigest()
        if hmac.compare_digest(expected_signature, signature):
            return True
    except Exception as e:
        logger.error("HMAC SHA256 check error: %s", e)

    # 3. Sandbox / Test mode fallback:
    # Strictly disabled in production or if live key is active
    is_live = settings.RAZORPAY_KEY_ID.startswith("rzp_live_") or not settings.DEBUG
    is_sandbox = (
        not is_live
        and ("test" in settings.RAZORPAY_KEY_ID.lower() or not settings.RAZORPAY_KEY_ID)
        and (
            signature.startswith("sig_test_")
            or signature.startswith("rzp_test_sig_")
            or signature == "sandbox_verified"
        )
    )
    if is_sandbox:
        return True

    return False


# -------------------------------------------------------------
# RAZORPAY GATEWAY ENDPOINTS
# -------------------------------------------------------------

@router.get("/razorpay/config", response_model=RazorpayConfigResponse)
def get_razorpay_config():
    """
    Public Razorpay Gateway parameters (Key ID, currency, monthly & annual plan prices).
    Allows frontend to dynamically initialize Razorpay Standard Checkout.
    """
    is_test = "test" in settings.RAZORPAY_KEY_ID.lower()
    return RazorpayConfigResponse(
        key_id=settings.RAZORPAY_KEY_ID,
        amount=settings.RAZORPAY_AMOUNT_MONTHLY_INR,
        monthly_amount=settings.RAZORPAY_AMOUNT_MONTHLY_INR,
        annual_amount=settings.RAZORPAY_AMOUNT_ANNUAL_INR,
        currency=settings.RAZORPAY_CURRENCY,
        is_test_mode=is_test,
        enabled=bool(settings.RAZORPAY_KEY_ID),
        company_name=settings.RAZORPAY_COMPANY_NAME
    )


@router.post(
    "/razorpay/create-order",
    response_model=RazorpayOrderResponse,
    dependencies=[Depends(enforce_rate_limit("payment_create_order", max_requests=10, window_seconds=60))]
)
def create_razorpay_order(
    req: RazorpayCreateOrderRequest = RazorpayCreateOrderRequest(),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Securely initiates a Razorpay Order for PRO unlock on the server.
    - Monthly charge: ₹49 (4900 paise, 30 days validity)
    - Annual charge: ₹499 (49900 paise, 365 days validity)
    Amount is strictly fixed server-side to prevent client-side tampering.
    Persists an internal 'pending' Payment record for full state machine integrity.
    """
    is_annual = (req.plan_type == "annual")
    if is_annual:
        amount_in_paise = int(settings.RAZORPAY_AMOUNT_ANNUAL_INR * 100)
        amount_formatted = f"₹{settings.RAZORPAY_AMOUNT_ANNUAL_INR:.2f}"
        duration_days = 365
        plan_code = "EmployAI_PRO_Annual"
        plan_desc = f"Employ.AI PRO Annual Access (365 Days) (Unlocked: {req.target_feature or 'All Features'})"
        charge_amount = settings.RAZORPAY_AMOUNT_ANNUAL_INR
    else:
        amount_in_paise = int(settings.RAZORPAY_AMOUNT_MONTHLY_INR * 100)
        amount_formatted = f"₹{settings.RAZORPAY_AMOUNT_MONTHLY_INR:.2f}"
        duration_days = 30
        plan_code = "EmployAI_PRO_Monthly"
        plan_desc = f"Employ.AI PRO Monthly Access (30 Days) (Unlocked: {req.target_feature or 'All Features'})"
        charge_amount = settings.RAZORPAY_AMOUNT_MONTHLY_INR

    receipt_id = f"rcpt_{current_user.id[:8]}_{int(time.time())}"
    order_id = None

    client = get_razorpay_client()
    if client and not settings.RAZORPAY_KEY_ID.startswith("rzp_test_employai_demo"):
        try:
            order_data = {
                "amount": amount_in_paise,
                "currency": settings.RAZORPAY_CURRENCY,
                "receipt": receipt_id,
                "notes": {
                    "user_id": current_user.id,
                    "email": current_user.email,
                    "user_name": current_user.full_name or "",
                    "feature": req.target_feature or "all",
                    "plan": plan_code,
                    "plan_type": "annual" if is_annual else "monthly",
                    "duration_days": str(duration_days)
                }
            }
            rz_order = client.order.create(data=order_data)
            order_id = rz_order.get("id")
        except Exception as e:
            logger.error("Razorpay API order creation failed: %s", e)
            if settings.RAZORPAY_KEY_ID.startswith("rzp_live_"):
                raise HTTPException(
                    status_code=status.HTTP_502_BAD_GATEWAY,
                    detail=f"Razorpay live order creation failed: {str(e)}"
                )

    if not order_id:
        # Cryptographically deterministic test order ID for reliable sandbox testing
        timestamp_part = int(time.time())
        order_id = f"order_test_{current_user.id[:8]}_{timestamp_part}"

    # Persist pending payment record for internal state tracking & audit logs
    try:
        existing_order = db.query(Payment).filter(Payment.razorpay_order_id == order_id).first()
        if not existing_order:
            pending_record = Payment(
                user_id=current_user.id,
                amount=charge_amount,
                currency=settings.RAZORPAY_CURRENCY,
                upi_id="razorpay_gateway",
                utr_number=order_id,
                payer_name=current_user.full_name or "Razorpay Customer",
                payment_app="Razorpay",
                status="pending",
                razorpay_order_id=order_id,
                plan_type="annual" if is_annual else "monthly",
                notes=f"Order initiated: {plan_code} | Duration: {duration_days} days"
            )
            db.add(pending_record)
            db.commit()
    except Exception as db_err:
        logger.warning("Could not persist pending order record: %s", db_err)
        db.rollback()

    return RazorpayOrderResponse(
        order_id=order_id,
        amount=amount_in_paise,
        amount_formatted=amount_formatted,
        currency=settings.RAZORPAY_CURRENCY,
        key_id=settings.RAZORPAY_KEY_ID,
        user_name=current_user.full_name or "",
        user_email=current_user.email,
        business_name=settings.RAZORPAY_COMPANY_NAME,
        description=plan_desc,
        theme_color="#00f2fe",
        target_feature=req.target_feature,
        plan_type="annual" if is_annual else "monthly",
        duration_days=duration_days
    )


@router.post("/razorpay/verify", response_model=PaymentStatusResponse)
def verify_razorpay_payment(
    req: RazorpayVerifyRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Verifies Razorpay payment signature cryptographically using HMAC SHA-256.
    Upon successful validation, activates user PRO status with chosen duration:
    - Monthly: 30 days validity
    - Annual: 365 days validity
    """
    if not req.razorpay_payment_id or not req.razorpay_order_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing razorpay_payment_id or razorpay_order_id."
        )

    # 1. Cryptographic HMAC-SHA256 signature verification
    is_valid_sig = verify_razorpay_signature(
        order_id=req.razorpay_order_id,
        payment_id=req.razorpay_payment_id,
        signature=req.razorpay_signature
    )
    if not is_valid_sig:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid Razorpay payment signature. Payment cannot be verified."
        )

    # 2. Check if this payment ID or order was already recorded
    existing = db.query(Payment).filter(
        (Payment.utr_number == req.razorpay_payment_id) |
        (Payment.razorpay_order_id == req.razorpay_order_id)
    ).first()
    if existing:
        if existing.user_id == current_user.id and existing.status == "verified":
            # Idempotent response: payment already completed and unlocked
            current_user.is_premium = True
            db.commit()
            return get_payment_status(current_user, db)
        elif existing.user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="This Razorpay payment reference is associated with another account."
            )

    # 3. Determine plan type and validity
    is_annual = (req.plan_type == "annual")
    duration_days = 365 if is_annual else 30
    plan_type = "annual" if is_annual else "monthly"
    charge_amount = settings.RAZORPAY_AMOUNT_ANNUAL_INR if is_annual else settings.RAZORPAY_AMOUNT_MONTHLY_INR
    now_utc = datetime.now(timezone.utc)

    # If current user already has an active, unexpired subscription, stack the renewal duration
    if current_user.is_premium and getattr(current_user, "subscription_valid_until", None):
        cur_end = current_user.subscription_valid_until
        if cur_end.tzinfo is None:
            cur_end = cur_end.replace(tzinfo=timezone.utc)
        if cur_end > now_utc:
            valid_until = cur_end + timedelta(days=duration_days)
        else:
            valid_until = now_utc + timedelta(days=duration_days)
    else:
        valid_until = now_utc + timedelta(days=duration_days)

    # Create or update payment record
    if existing:
        payment = existing
        payment.status = "verified"
        payment.verified_at = now_utc
        payment.verified_by = "razorpay_secure_gateway"
        payment.razorpay_order_id = req.razorpay_order_id
        payment.razorpay_payment_id = req.razorpay_payment_id
        payment.razorpay_signature = req.razorpay_signature
        payment.plan_type = plan_type
        payment.valid_until = valid_until
        payment.amount = charge_amount
        payment.utr_number = req.razorpay_payment_id
    else:
        payment = Payment(
            user_id=current_user.id,
            amount=charge_amount,
            currency=settings.RAZORPAY_CURRENCY,
            upi_id="razorpay_gateway",
            utr_number=req.razorpay_payment_id,
            payer_name=current_user.full_name or "Razorpay Customer",
            payer_upi=None,
            payment_app="Razorpay",
            status="verified",
            verified_at=now_utc,
            verified_by="razorpay_secure_gateway",
            razorpay_order_id=req.razorpay_order_id,
            razorpay_payment_id=req.razorpay_payment_id,
            razorpay_signature=req.razorpay_signature,
            plan_type=plan_type,
            valid_until=valid_until,
            notes=f"Razorpay Secure Checkout | Plan: {plan_type.upper()} ({duration_days} days) | Order: {req.razorpay_order_id} | Feature: {req.target_feature or 'all'}"
        )
        db.add(payment)

    # 4. Instant unlock for user with analyzed expiration
    current_user.is_premium = True
    current_user.premium_since = now_utc
    current_user.subscription_plan = plan_type
    current_user.subscription_valid_until = valid_until

    db.commit()
    db.refresh(current_user)
    db.refresh(payment)

    # Save to persistent backup
    from app.services.auth_service import AuthService
    AuthService._save_backup_user(current_user)

    return get_payment_status(current_user, db)


@router.post("/razorpay/webhook")
async def razorpay_webhook(
    request: Request,
    db: Session = Depends(get_db)
):
    """
    Official Razorpay Webhook listener with raw request body HMAC-SHA256 signature verification.
    Handles idempotent event processing for 'order.paid', 'payment.captured', 'payment.failed'.
    """
    # 1. Read raw body bytes
    raw_body = await request.body()
    signature = request.headers.get("X-Razorpay-Signature", "")

    # 2. Cryptographic signature verification against RAZORPAY_WEBHOOK_SECRET
    if settings.RAZORPAY_WEBHOOK_SECRET:
        try:
            expected_sig = hmac.new(
                settings.RAZORPAY_WEBHOOK_SECRET.encode("utf-8"),
                raw_body,
                hashlib.sha256
            ).hexdigest()
            if not hmac.compare_digest(expected_sig, signature):
                logger.warning("Razorpay webhook signature verification failed.")
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid webhook signature."
                )
        except HTTPException:
            raise
        except Exception as sig_err:
            logger.error("Webhook signature check error: %s", sig_err)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Webhook signature verification error."
            )
    else:
        logger.info("RAZORPAY_WEBHOOK_SECRET not configured; accepting event with payload validation.")

    # 3. Parse JSON payload
    try:
        import json
        event_data = json.loads(raw_body.decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Malformed JSON in webhook.")

    event_type = event_data.get("event")
    payload = event_data.get("payload", {})
    payment_entity = payload.get("payment", {}).get("entity", {})
    order_entity = payload.get("order", {}).get("entity", {})

    order_id = payment_entity.get("order_id") or order_entity.get("id")
    payment_id = payment_entity.get("id")
    notes = payment_entity.get("notes", {}) or order_entity.get("notes", {})
    user_id = notes.get("user_id")

    logger.info("Processing Razorpay webhook: event=%s, order=%s, payment=%s", event_type, order_id, payment_id)

    if event_type in ("payment.captured", "order.paid"):
        payment_record = None
        if order_id:
            payment_record = db.query(Payment).filter(Payment.razorpay_order_id == order_id).first()
        if not payment_record and payment_id:
            payment_record = db.query(Payment).filter(Payment.utr_number == payment_id).first()

        # Idempotency check: if already verified, acknowledge immediately
        if payment_record and payment_record.status == "verified":
            return {"status": "ok", "message": "Event already processed idempotently"}

        target_user = None
        if payment_record:
            target_user = db.query(User).filter(User.id == payment_record.user_id).first()
        elif user_id:
            target_user = db.query(User).filter(User.id == user_id).first()

        if target_user:
            plan_type = notes.get("plan_type", "monthly")
            is_annual = (plan_type == "annual")
            duration_days = 365 if is_annual else 30
            charge_amount = float(payment_entity.get("amount", 4900)) / 100.0
            now_utc = datetime.now(timezone.utc)
            if target_user.is_premium and getattr(target_user, "subscription_valid_until", None):
                cur_end = target_user.subscription_valid_until
                if cur_end.tzinfo is None:
                    cur_end = cur_end.replace(tzinfo=timezone.utc)
                if cur_end > now_utc:
                    valid_until = cur_end + timedelta(days=duration_days)
                else:
                    valid_until = now_utc + timedelta(days=duration_days)
            else:
                valid_until = now_utc + timedelta(days=duration_days)

            if payment_record:
                payment_record.status = "verified"
                payment_record.verified_at = now_utc
                payment_record.verified_by = "razorpay_webhook"
                payment_record.razorpay_payment_id = payment_id
                payment_record.utr_number = payment_id or payment_record.utr_number
                payment_record.valid_until = valid_until
            else:
                payment_record = Payment(
                    user_id=target_user.id,
                    amount=charge_amount,
                    currency=settings.RAZORPAY_CURRENCY,
                    upi_id="razorpay_gateway",
                    utr_number=payment_id or f"WH_{int(time.time())}",
                    payer_name=target_user.full_name or "Razorpay Customer",
                    payment_app="Razorpay",
                    status="verified",
                    verified_at=now_utc,
                    verified_by="razorpay_webhook",
                    razorpay_order_id=order_id,
                    razorpay_payment_id=payment_id,
                    plan_type=plan_type,
                    valid_until=valid_until,
                    notes=f"Verified via Webhook event: {event_type}"
                )
                db.add(payment_record)

            target_user.is_premium = True
            target_user.premium_since = now_utc
            target_user.subscription_plan = plan_type
            target_user.subscription_valid_until = valid_until

            db.commit()

            try:
                from app.services.auth_service import AuthService
                AuthService._save_backup_user(target_user)
            except Exception:
                pass

            return {"status": "ok", "event": event_type, "user_id": target_user.id, "verified": True}

    elif event_type == "payment.failed":
        if order_id:
            p_rec = db.query(Payment).filter(Payment.razorpay_order_id == order_id).first()
            if p_rec and p_rec.status == "pending":
                p_rec.status = "failed"
                p_rec.notes = (p_rec.notes or "") + " | Payment failed on Razorpay"
                db.commit()
        return {"status": "ok", "event": event_type, "marked_failed": True}

    return {"status": "ok", "event": event_type, "action": "ignored"}


# -------------------------------------------------------------
# MANUAL UPI / PHONEPE QR FALLBACK ENDPOINTS
# -------------------------------------------------------------

@router.post("/submit", response_model=PaymentResponse, status_code=status.HTTP_201_CREATED)
def submit_payment(
    req: PaymentSubmitRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Submit UPI payment transaction details after scanning PhonePe QR or paying to 9415962079@ybl.
    """
    cleaned_utr = _clean_utr(req.utr_number)
    if not _is_valid_utr_format(cleaned_utr):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid UPI Transaction ID / UTR. Please enter a valid 12-digit reference number from your PhonePe/GPay/Paytm app."
        )

    # Check if this UTR already exists in system
    existing = db.query(Payment).filter(Payment.utr_number == cleaned_utr).first()
    if existing:
        if existing.user_id == current_user.id and existing.status == "verified":
            return _format_payment_response(existing, current_user.email, current_user.full_name)
        elif existing.user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="This UPI Transaction ID (UTR) has already been submitted by another user. Each payment must be unique."
            )

    # Is user the designated super admin?
    is_admin = current_user.email.strip().lower() == ADMIN_EMAIL.lower()

    payment = Payment(
        user_id=current_user.id,
        amount=settings.RAZORPAY_AMOUNT_INR,
        currency="INR",
        upi_id="9415962079@ybl",
        utr_number=cleaned_utr,
        payer_name=req.payer_name or current_user.full_name,
        payer_upi=req.payer_upi,
        payment_app=req.payment_app or "PhonePe",
        screenshot_url=req.screenshot_url,
        status="verified" if is_admin else "pending",
        verified_at=datetime.now(timezone.utc) if is_admin else None,
        verified_by="admin_bypass" if is_admin else None,
        notes=req.notes
    )
    db.add(payment)

    if is_admin:
        current_user.is_premium = True
        current_user.premium_since = datetime.now(timezone.utc)

    db.commit()
    db.refresh(payment)

    return _format_payment_response(payment, current_user.email, current_user.full_name)


@router.post("/verify-instant", response_model=PaymentStatusResponse)
def verify_payment_instant(
    req: PaymentVerifyInstantRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Secure manual verification endpoint:
    - Super Admin can instantly approve and verify transactions.
    - Regular users' manual UPI submissions are saved as 'pending' for Super Admin approval
      to prevent unauthorized free premium bypass.
    """
    cleaned_utr = _clean_utr(req.utr_number)
    if not _is_valid_utr_format(cleaned_utr):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid UPI Transaction ID format. Must be at least 8-12 alphanumeric characters."
        )

    is_admin = current_user.email.strip().lower() == ADMIN_EMAIL.lower()

    # Check for payment record
    payment = db.query(Payment).filter(
        Payment.utr_number == cleaned_utr,
        Payment.user_id == current_user.id
    ).first()

    if not payment:
        # Check if already redeemed by another user
        existing_other = db.query(Payment).filter(
            Payment.utr_number == cleaned_utr,
            Payment.user_id != current_user.id
        ).first()
        if existing_other:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="This UPI Transaction ID has already been redeemed by another account."
            )

        payment = Payment(
            user_id=current_user.id,
            amount=settings.RAZORPAY_AMOUNT_INR,
            currency="INR",
            upi_id="9415962079@ybl",
            utr_number=cleaned_utr,
            payer_name=current_user.full_name,
            payment_app="PhonePe",
            status="verified" if is_admin else "pending",
            verified_at=datetime.now(timezone.utc) if is_admin else None,
            verified_by="super_admin_instant" if is_admin else None,
            notes="Submitted via Instant Verification Engine"
        )
        db.add(payment)
    else:
        if is_admin:
            payment.status = "verified"
            payment.verified_at = datetime.now(timezone.utc)
            payment.verified_by = "super_admin_instant"

    if is_admin:
        current_user.is_premium = True
        current_user.premium_since = datetime.now(timezone.utc)

    db.commit()
    db.refresh(current_user)
    db.refresh(payment)

    return get_payment_status(current_user, db)


@router.get("/status", response_model=PaymentStatusResponse)
def get_payment_status(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get user's current subscription status and payment history.
    Analyses user's subscription time: if monthly (30 days) or annual (365 days)
    time is over, automatically resets PRO active status back to regular user.
    """
    is_admin = current_user.email.strip().lower() == ADMIN_EMAIL.lower()
    if is_admin:
        if not current_user.is_premium or current_user.role != "admin":
            current_user.is_premium = True
            current_user.role = "admin"
            db.commit()
            db.refresh(current_user)

    payments = db.query(Payment).filter(Payment.user_id == current_user.id).order_by(Payment.created_at.desc()).all()
    history = []
    active_payment = None
    has_pending = False

    for p in payments:
        p_resp = _format_payment_response(p, current_user.email, current_user.full_name)
        history.append(p_resp)
        if p.status == "verified" and not active_payment:
            active_payment = p_resp
        elif p.status == "pending":
            has_pending = True

    # 1. Admin is always permanent lifetime PRO
    if is_admin:
        return PaymentStatusResponse(
            is_premium=True,
            is_admin=True,
            email=current_user.email,
            role="admin",
            has_pending=has_pending,
            active_payment=active_payment,
            history=history,
            plan_type="admin_lifetime",
            subscription_valid_until=None,
            days_remaining=9999,
            is_expired=False
        )

    # 2. Time analysis for regular users
    now_utc = datetime.now(timezone.utc)

    if current_user.is_premium:
        # Determine valid_until timestamp
        valid_dt = current_user.subscription_valid_until
        if not valid_dt and active_payment and getattr(active_payment, "valid_until", None):
            valid_dt = active_payment.valid_until
            current_user.subscription_valid_until = valid_dt
            current_user.subscription_plan = getattr(active_payment, "plan_type", "monthly") or "monthly"

        if not valid_dt:
            # Fallback for earlier active subscriptions: default 30 days from premium_since
            base = current_user.premium_since or now_utc
            if base.tzinfo is None:
                base = base.replace(tzinfo=timezone.utc)
            valid_dt = base + timedelta(days=30)
            current_user.subscription_valid_until = valid_dt
            current_user.subscription_plan = current_user.subscription_plan or "monthly"

        # Compare with current UTC time
        if valid_dt.tzinfo is None:
            valid_dt = valid_dt.replace(tzinfo=timezone.utc)

        if now_utc > valid_dt:
            # USER TIME IS OVER!
            # Automatically reset PRO active back to standard user (prompt upgrade)
            current_user.is_premium = False
            db.commit()
            db.refresh(current_user)

            try:
                from app.services.auth_service import AuthService
                AuthService._save_backup_user(current_user)
            except Exception:
                pass

            return PaymentStatusResponse(
                is_premium=False,
                is_admin=False,
                email=current_user.email,
                role=current_user.role,
                has_pending=has_pending,
                active_payment=active_payment,
                history=history,
                plan_type=current_user.subscription_plan,
                subscription_valid_until=current_user.subscription_valid_until,
                days_remaining=0,
                is_expired=True
            )
        else:
            # Active subscription
            days_rem = max(1, (valid_dt - now_utc).days)
            return PaymentStatusResponse(
                is_premium=True,
                is_admin=False,
                email=current_user.email,
                role=current_user.role,
                has_pending=has_pending,
                active_payment=active_payment,
                history=history,
                plan_type=current_user.subscription_plan or "monthly",
                subscription_valid_until=current_user.subscription_valid_until,
                days_remaining=days_rem,
                is_expired=False
            )

    # 3. User is not premium
    is_exp = False
    if current_user.subscription_valid_until:
        v_dt = current_user.subscription_valid_until
        if v_dt.tzinfo is None:
            v_dt = v_dt.replace(tzinfo=timezone.utc)
        is_exp = now_utc > v_dt

    return PaymentStatusResponse(
        is_premium=False,
        is_admin=False,
        email=current_user.email,
        role=current_user.role,
        has_pending=has_pending,
        active_payment=active_payment,
        history=history,
        plan_type=current_user.subscription_plan,
        subscription_valid_until=current_user.subscription_valid_until,
        days_remaining=0,
        is_expired=is_exp
    )



# -------------------------------------------------------------
# ADMIN ONLY ENDPOINTS (STRICTLY akhtarrakeeb52@gmail.com)
# -------------------------------------------------------------

@router.get("/admin/all", response_model=List[PaymentResponse])
def admin_get_all_payments(
    admin_user: User = Depends(require_admin_user),
    db: Session = Depends(get_db)
):
    """
    Super Admin endpoint to list all user payment submissions with status.
    Strictly authorized only for akhtarrakeeb52@gmail.com.
    """
    payments = db.query(Payment).order_by(Payment.created_at.desc()).all()
    result = []
    for p in payments:
        u = db.query(User).filter(User.id == p.user_id).first()
        result.append(_format_payment_response(p, u.email if u else "unknown", u.full_name if u else "Unknown"))
    return result


@router.post("/admin/{payment_id}/verify", response_model=PaymentResponse)
def admin_verify_payment(
    payment_id: str,
    req: AdminVerifyPaymentRequest = AdminVerifyPaymentRequest(),
    admin_user: User = Depends(require_admin_user),
    db: Session = Depends(get_db)
):
    """
    Super Admin manually approves payment and unlocks user premium features.
    """
    payment = db.query(Payment).filter(Payment.id == payment_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment record not found.")

    payment.status = "verified"
    payment.verified_at = datetime.now(timezone.utc)
    payment.verified_by = admin_user.email
    if req.notes:
        payment.notes = req.notes

    # Unlock the paying user's subscription
    user = db.query(User).filter(User.id == payment.user_id).first()
    if user:
        user.is_premium = True
        user.premium_since = datetime.now(timezone.utc)

    db.commit()
    db.refresh(payment)

    return _format_payment_response(payment, user.email if user else "unknown", user.full_name if user else "Unknown")


@router.post("/admin/{payment_id}/reject", response_model=PaymentResponse)
def admin_reject_payment(
    payment_id: str,
    req: AdminVerifyPaymentRequest = AdminVerifyPaymentRequest(),
    admin_user: User = Depends(require_admin_user),
    db: Session = Depends(get_db)
):
    """
    Super Admin rejects invalid or fake UTR payment submission.
    """
    payment = db.query(Payment).filter(Payment.id == payment_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment record not found.")

    payment.status = "rejected"
    payment.verified_by = admin_user.email
    if req.notes:
        payment.notes = req.notes

    # If user has no other verified payments, revert premium
    other_verified = db.query(Payment).filter(
        Payment.user_id == payment.user_id,
        Payment.id != payment.id,
        Payment.status == "verified"
    ).first()

    user = db.query(User).filter(User.id == payment.user_id).first()
    if user and user.email.strip().lower() != ADMIN_EMAIL.lower() and not other_verified:
        user.is_premium = False

    db.commit()
    db.refresh(payment)

    return _format_payment_response(payment, user.email if user else "unknown", user.full_name if user else "Unknown")



@router.post("/admin/grant-premium")
def admin_grant_premium(
    req: AdminGrantPremiumRequest,
    admin_user: User = Depends(require_admin_user),
    db: Session = Depends(get_db)
):
    """
    Super Admin directly grants or revokes premium for any user email.
    """
    target = db.query(User).filter(User.email.ilike(req.email.strip())).first()
    if not target:
        raise HTTPException(status_code=404, detail=f"User with email '{req.email}' not found.")

    target.is_premium = req.grant
    if req.grant:
        target.premium_since = datetime.now(timezone.utc)
    else:
        target.premium_since = None

    db.commit()
    return {
        "status": "success",
        "email": target.email,
        "is_premium": target.is_premium,
        "message": f"Premium status set to {req.grant} for {target.email}"
    }
