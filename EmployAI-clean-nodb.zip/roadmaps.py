from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, require_premium_user
from app.models.user import User
from app.models.profile import StudentProfile
from app.models.matching import LearningRoadmap, Role
from app.schemas.roadmap import LearningRoadmapResponse, RoadmapMilestone, RoadmapGenerateRequest
from app.services.roadmap_service import RoadmapService

router = APIRouter(prefix="/roadmaps", tags=["Upskilling Roadmaps"])


@router.post("/generate", response_model=LearningRoadmapResponse, status_code=status.HTTP_201_CREATED)
def generate_roadmap(
    data: RoadmapGenerateRequest,
    current_user: User = Depends(require_premium_user),
    db: Session = Depends(get_db)
):
    """Generate or refresh a personalized 6-week upskilling roadmap for a target role."""
    student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not student_profile:
        raise HTTPException(status_code=404, detail="Student profile not found.")

    return RoadmapService.generate_personalized_roadmap(
        db, student_profile, data.target_role_id, data.weeks_available or 6
    )


@router.get("/active", response_model=LearningRoadmapResponse)
def get_active_roadmap(
    current_user: User = Depends(require_premium_user),
    db: Session = Depends(get_db)
):
    """Retrieve current student's active upskilling roadmap or generate default for top matching role."""
    student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not student_profile:
        raise HTTPException(status_code=404, detail="Student profile not found.")

    roadmap_rec = db.query(LearningRoadmap).filter(
        LearningRoadmap.student_profile_id == student_profile.id
    ).order_by(LearningRoadmap.created_at.desc()).first()

    if not roadmap_rec:
        # Pick top role
        role = db.query(Role).first()
        if not role:
            raise HTTPException(status_code=404, detail="No roles found in system.")
        return RoadmapService.generate_personalized_roadmap(db, student_profile, role.id, 6)

    role = db.query(Role).filter(Role.id == roadmap_rec.target_role_id).first()
    role_title = role.title if role else "Target Career Role"
    role_domain = role.domain if role else "Engineering"

    milestones_list = [RoadmapMilestone(**m) for m in roadmap_rec.milestones_json]

    return LearningRoadmapResponse(
        id=roadmap_rec.id,
        student_profile_id=student_profile.id,
        target_role_id=roadmap_rec.target_role_id,
        target_role_title=role_title,
        target_domain=role_domain,
        title=roadmap_rec.title,
        estimated_weeks=roadmap_rec.estimated_weeks,
        milestones=milestones_list,
        created_at=roadmap_rec.created_at
    )


@router.post("/task-toggle/{task_id}")
def toggle_roadmap_task(
    task_id: str,
    current_user: User = Depends(require_premium_user),
    db: Session = Depends(get_db)
):
    """Toggle completion status of a roadmap task."""
    student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not student_profile:
        raise HTTPException(status_code=404, detail="Student profile not found.")

    roadmap_rec = db.query(LearningRoadmap).filter(
        LearningRoadmap.student_profile_id == student_profile.id
    ).order_by(LearningRoadmap.created_at.desc()).first()

    if not roadmap_rec:
        raise HTTPException(status_code=404, detail="No roadmap found.")

    milestones = roadmap_rec.milestones_json or []
    updated = False
    for m in milestones:
        for t in m.get("tasks", []):
            if t.get("id") == task_id:
                t["is_completed"] = not t.get("is_completed", False)
                updated = True
                break

    if updated:
        roadmap_rec.milestones_json = milestones
        db.commit()

    return {"status": "success", "task_id": task_id, "updated": updated}
