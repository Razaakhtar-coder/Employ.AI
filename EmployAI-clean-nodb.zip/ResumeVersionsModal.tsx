import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import type { ResumeVersionItem, StructuredResume } from '../types';
import { documentApi } from '../services/api';
import { 
  Layers, Plus, Check, X, Clock, Target, 
  RefreshCw, AlertCircle, ArrowRight
} from 'lucide-react';
import { FuturisticLoader } from './FuturisticLoader';

export interface ResumeVersionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  documentId?: string;
  activeVersionId?: string | null;
  currentStructuredResume?: StructuredResume | null;
  onSwitchVersion: (version: ResumeVersionItem) => void;
  onSaveNewVersion: (versionName: string, targetJob?: string) => Promise<void>;
}

export const ResumeVersionsModal: React.FC<ResumeVersionsModalProps> = ({
  isOpen,
  onClose,
  documentId,
  activeVersionId,
  onSwitchVersion,
  onSaveNewVersion,
}) => {
  const [versions, setVersions] = useState<ResumeVersionItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [showCreateForm, setShowCreateForm] = useState<boolean>(false);
  const [newVersionName, setNewVersionName] = useState<string>('');
  const [newTargetJob, setNewTargetJob] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const fetchVersions = async () => {
    if (!documentId) return;
    try {
      setIsLoading(true);
      setError(null);
      const list = await documentApi.listResumeVersions(documentId);
      setVersions(list);
    } catch (err: any) {
      setError(err?.message || 'Failed to load versions.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && documentId) {
      fetchVersions();
    }
  }, [isOpen, documentId]);

  if (!isOpen) return null;

  const handleCreateVersion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVersionName.trim()) return;

    try {
      setIsSaving(true);
      setError(null);
      await onSaveNewVersion(newVersionName.trim(), newTargetJob.trim() || undefined);
      setNewVersionName('');
      setNewTargetJob('');
      setShowCreateForm(false);
      await fetchVersions();
    } catch (err: any) {
      setError(err?.message || 'Failed to create new version.');
    } finally {
      setIsSaving(false);
    }
  };

  const modalNode = (
    <div 
      className="modal-backdrop" 
      onClick={onClose} 
      style={{ 
        position: 'fixed',
        inset: 0,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100vw',
        height: '100vh',
        backgroundColor: 'rgba(3, 7, 18, 0.82)',
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 99999,
        padding: '1.25rem',
        boxSizing: 'border-box'
      }}
    >
      <div 
        className="glass-card modal-content" 
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '90%',
          maxWidth: '700px',
          maxHeight: '85vh',
          display: 'flex',
          flexDirection: 'column',
          padding: '1.75rem',
          borderRadius: '16px',
          background: 'var(--bg-modal)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-modal)',
          boxSizing: 'border-box'
        }}
      >
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div style={{ padding: '0.45rem', borderRadius: '10px', background: 'rgba(56, 189, 248, 0.12)', color: 'var(--accent-cyan)' }}>
              <Layers size={22} />
            </div>
            <div>
              <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                Resume Versions
              </h2>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                Keep multiple customized versions for specific job targets without overwriting originals.
              </p>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <button
              type="button"
              onClick={() => setShowCreateForm(prev => !prev)}
              className="btn btn-primary btn-sm"
              style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}
            >
              <Plus size={13} /> {showCreateForm ? 'Cancel' : 'New Version'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="btn btn-ghost btn-sm"
              style={{ padding: '0.35rem', color: 'var(--text-muted)' }}
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Create Version Form */}
        {showCreateForm && (
          <form onSubmit={handleCreateVersion} style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-glass)', borderRadius: '10px', padding: '1rem', marginBottom: '1.25rem' }}>
            <h4 style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.65rem' }}>
              Create Snapshot from Current Resume
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem', marginBottom: '0.85rem' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>
                  Version Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Target: Data Engineer, or Post-AI Polish v2"
                  value={newVersionName}
                  onChange={(e) => setNewVersionName(e.target.value)}
                  className="resume-doc-input"
                  style={{ width: '100%', fontSize: '0.82rem' }}
                  required
                />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>
                  Target Job / Company (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Senior Frontend Developer @ Stripe"
                  value={newTargetJob}
                  onChange={(e) => setNewTargetJob(e.target.value)}
                  className="resume-doc-input"
                  style={{ width: '100%', fontSize: '0.82rem' }}
                />
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.4rem' }}>
              <button
                type="button"
                onClick={() => setShowCreateForm(false)}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.75rem' }}
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSaving || !newVersionName.trim()}
                className="btn btn-emerald btn-sm"
                style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}
              >
                {isSaving ? <RefreshCw size={12} className="animate-spin-slow" /> : <Check size={12} />}
                {isSaving ? 'Creating...' : 'Save as New Version'}
              </button>
            </div>
          </form>
        )}

        {error && (
          <div style={{ padding: '0.6rem 0.85rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.1)', border: '1px solid rgba(244, 63, 94, 0.3)', color: '#fb7185', fontSize: '0.78rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <AlertCircle size={14} />
            <span>{error}</span>
          </div>
        )}

        {/* Versions List */}
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
          {isLoading ? (
            <div style={{ textAlign: 'center', padding: '2rem 1rem' }}>
              <FuturisticLoader
                size="sm"
                icon="refresh"
                title="Loading Versions..."
                subtitle="Fetching saved resume revisions"
              />
            </div>
          ) : versions.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '2.5rem 1rem', color: 'var(--text-muted)' }}>
              <Layers size={32} style={{ margin: '0 auto 0.5rem auto', opacity: 0.4 }} />
              <p style={{ fontSize: '0.85rem' }}>No alternate versions created yet.</p>
              <button
                type="button"
                onClick={() => setShowCreateForm(true)}
                className="btn btn-primary btn-sm"
                style={{ marginTop: '0.5rem' }}
              >
                <Plus size={12} /> Create First Version
              </button>
            </div>
          ) : (
            versions.map((ver, idx) => {
              const isActive = activeVersionId ? ver.version_id === activeVersionId : idx === versions.length - 1;

              return (
                <div
                  key={ver.version_id}
                  style={{
                    padding: '0.9rem 1.15rem',
                    borderRadius: '10px',
                    background: isActive ? 'rgba(56, 189, 248, 0.12)' : 'var(--bg-tertiary)',
                    border: isActive ? '1.5px solid var(--accent-cyan)' : '1px solid var(--border-subtle)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: '1rem',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
                      <span className="badge badge-secondary" style={{ fontSize: '0.62rem', padding: '0.1rem 0.35rem' }}>
                        v{ver.version_num}
                      </span>
                      <h4 style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                        {ver.version_name}
                      </h4>
                      {isActive && (
                        <span className="badge badge-emerald" style={{ fontSize: '0.62rem', padding: '0.1rem 0.35rem' }}>
                          Current Active
                        </span>
                      )}
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', flexWrap: 'wrap', fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                      {ver.target_job && (
                        <span style={{ color: '#a78bfa', display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
                          <Target size={10} /> {ver.target_job}
                        </span>
                      )}
                      <span style={{ display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
                        <Clock size={10} />
                        {new Date(ver.updated_at || ver.created_at).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                    <div style={{ textAlign: 'center', padding: '0.2rem 0.5rem', borderRadius: '6px', background: 'rgba(16, 185, 129, 0.08)' }}>
                      <span style={{ fontSize: '0.95rem', fontWeight: 800, color: '#34d399' }}>
                        {Math.round(ver.resume_quality_score || 80)}
                      </span>
                      <span style={{ fontSize: '0.62rem', color: 'var(--text-muted)', display: 'block' }}>ATS</span>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        onSwitchVersion(ver);
                        onClose();
                      }}
                      className={`btn btn-sm ${isActive ? 'btn-secondary' : 'btn-primary'}`}
                      disabled={isActive}
                      style={{ fontSize: '0.75rem', padding: '0.3rem 0.65rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                    >
                      {isActive ? 'Active' : <>Switch <ArrowRight size={11} /></>}
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalNode, document.body) : modalNode;
};
