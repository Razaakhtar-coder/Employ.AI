import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import type { StructuredResume, AppliedChangeItem } from '../types';
import { 
  GitCompare, ArrowRight, Undo2, X, 
  Sparkles, TrendingUp, RotateCcw
} from 'lucide-react';

export interface ResumeComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
  originalStructuredResume: StructuredResume | null;
  currentStructuredResume: StructuredResume | null;
  originalATSScore?: number;
  currentATSScore?: number;
  appliedChanges?: AppliedChangeItem[];
  onUndoChange?: (changeId: string) => void;
  onRevertAll?: () => void;
}

export const ResumeComparisonModal: React.FC<ResumeComparisonModalProps> = ({
  isOpen,
  onClose,
  originalStructuredResume,
  currentStructuredResume,
  originalATSScore = 74,
  currentATSScore = 88,
  appliedChanges = [],
  onUndoChange,
  onRevertAll,
}) => {
  const [activeTab, setActiveTab] = useState<'matrix' | 'changelog'>('matrix');

  if (!isOpen) return null;

  const origSkills = originalStructuredResume?.skills || [];
  const currSkills = currentStructuredResume?.skills || [];

  const origExpBullets = (originalStructuredResume?.experience || []).flatMap(e => e.bullets || []);
  const currExpBullets = (currentStructuredResume?.experience || []).flatMap(e => e.bullets || []);

  const origProjBullets = (originalStructuredResume?.projects || []).flatMap(p => p.bullets || []);
  const currProjBullets = (currentStructuredResume?.projects || []).flatMap(p => p.bullets || []);

  const scoreLift = Math.max(0, Math.round(currentATSScore - originalATSScore));

  const modalNode = (
    <div 
      className="modal-backdrop" 
      onClick={onClose} 
      style={{ 
        position: 'fixed',
        inset: 0,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100vw',
        height: '100vh',
        backgroundColor: 'rgba(3, 7, 18, 0.82)',
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 99999,
        padding: '1.25rem',
        boxSizing: 'border-box'
      }}
    >
      <div 
        className="glass-card modal-content" 
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '92%',
          maxWidth: '920px',
          maxHeight: '88vh',
          display: 'flex',
          flexDirection: 'column',
          padding: '1.75rem',
          borderRadius: '16px',
          background: 'var(--bg-modal)',
          border: '1px solid var(--border-glass)',
          boxShadow: 'var(--shadow-modal)',
          boxSizing: 'border-box'
        }}
      >
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div style={{ padding: '0.45rem', borderRadius: '10px', background: 'rgba(56, 189, 248, 0.12)', color: 'var(--accent-cyan)' }}>
              <GitCompare size={22} />
            </div>
            <div>
              <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                Resume Comparison: Original vs Optimized
              </h2>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                Review before and after changes, measurable ATS score lift, and applied AI improvements.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="btn btn-ghost btn-sm"
            style={{ padding: '0.35rem', color: 'var(--text-muted)' }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Score Lift Summary Banner */}
        <div style={{ background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(56, 189, 248, 0.12))', border: '1px solid var(--border-glass)', borderRadius: '12px', padding: '1.15rem 1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
            <div>
              <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>Original ATS Score</div>
              <div style={{ fontSize: '1.6rem', fontWeight: 900, color: 'var(--text-muted)' }}>{Math.round(originalATSScore)}/100</div>
            </div>

            <ArrowRight size={22} style={{ color: 'var(--accent-cyan)' }} />

            <div>
              <div style={{ fontSize: '0.7rem', color: 'var(--accent-emerald)', textTransform: 'uppercase', fontWeight: 700 }}>Optimized ATS Score</div>
              <div style={{ fontSize: '1.6rem', fontWeight: 900, color: 'var(--accent-emerald)' }}>{Math.round(currentATSScore)}/100</div>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(16, 185, 129, 0.15)', padding: '0.45rem 0.85rem', borderRadius: '8px', border: '1px solid rgba(16, 185, 129, 0.35)' }}>
            <TrendingUp size={16} color="var(--accent-emerald)" />
            <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--accent-emerald)' }}>
              +{scoreLift} Points Lift
            </span>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '1rem' }}>
          <button
            type="button"
            onClick={() => setActiveTab('matrix')}
            className={`btn btn-sm ${activeTab === 'matrix' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ fontSize: '0.75rem' }}
          >
            Comparison Matrix
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('changelog')}
            className={`btn btn-sm ${activeTab === 'changelog' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
          >
            Applied AI Improvements ({appliedChanges.length})
          </button>
        </div>

        {/* Content Body */}
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '1rem', paddingRight: '0.35rem' }}>
          {activeTab === 'matrix' ? (
            <>
              {/* Metrics Table */}
              <div style={{ background: 'var(--bg-tertiary)', borderRadius: '10px', border: '1px solid var(--border-subtle)', overflow: 'hidden' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8rem', textAlign: 'left' }}>
                  <thead>
                    <tr style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border-subtle)' }}>
                      <th style={{ padding: '0.65rem 1rem', color: 'var(--text-muted)', fontWeight: 700 }}>Resume Metric</th>
                      <th style={{ padding: '0.65rem 1rem', color: 'var(--text-muted)', fontWeight: 700 }}>Original Baseline</th>
                      <th style={{ padding: '0.65rem 1rem', color: 'var(--accent-emerald)', fontWeight: 700 }}>Optimized Version</th>
                      <th style={{ padding: '0.65rem 1rem', color: 'var(--accent-cyan)', fontWeight: 700 }}>Improvement</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--text-primary)', fontWeight: 600 }}>ATS Quality Score</td>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--text-muted)' }}>{Math.round(originalATSScore)}%</td>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--accent-emerald)', fontWeight: 700 }}>{Math.round(currentATSScore)}%</td>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--accent-emerald)', fontWeight: 700 }}>+{scoreLift}%</td>
                    </tr>
                    <tr style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--text-primary)', fontWeight: 600 }}>Identified Skills</td>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--text-muted)' }}>{origSkills.length} skills</td>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--accent-emerald)', fontWeight: 700 }}>{currSkills.length} skills</td>
                      <td style={{ padding: '0.65rem 1rem', color: currSkills.length >= origSkills.length ? 'var(--accent-emerald)' : 'var(--text-muted)' }}>
                        {currSkills.length >= origSkills.length ? `+${currSkills.length - origSkills.length}` : `${currSkills.length - origSkills.length}`}
                      </td>
                    </tr>
                    <tr style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--text-primary)', fontWeight: 600 }}>Experience Bullets</td>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--text-muted)' }}>{origExpBullets.length} bullets</td>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--accent-emerald)', fontWeight: 700 }}>{currExpBullets.length} bullets</td>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--accent-cyan)' }}>STAR-Optimized</td>
                    </tr>
                    <tr>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--text-primary)', fontWeight: 600 }}>Project Bullet Statements</td>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--text-muted)' }}>{origProjBullets.length} statements</td>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--accent-emerald)', fontWeight: 700 }}>{currProjBullets.length} statements</td>
                      <td style={{ padding: '0.65rem 1rem', color: 'var(--accent-cyan)' }}>Quantified Impact</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Summary Comparison */}
              {(originalStructuredResume?.summary || currentStructuredResume?.summary) && (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                  <div style={{ background: 'var(--bg-tertiary)', borderRadius: '10px', padding: '1rem', border: '1px solid var(--border-subtle)' }}>
                    <span style={{ display: 'block', fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700, marginBottom: '0.35rem' }}>
                      Original Summary
                    </span>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.45 }}>
                      {originalStructuredResume?.summary || 'No summary provided in original upload.'}
                    </p>
                  </div>

                  <div style={{ background: 'rgba(16, 185, 129, 0.08)', borderRadius: '10px', padding: '1rem', border: '1.5px solid rgba(16, 185, 129, 0.3)' }}>
                    <span style={{ display: 'block', fontSize: '0.7rem', color: 'var(--accent-emerald)', textTransform: 'uppercase', fontWeight: 700, marginBottom: '0.35rem' }}>
                      Optimized Summary
                    </span>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-primary)', margin: 0, lineHeight: 1.45, fontWeight: 500 }}>
                      {currentStructuredResume?.summary || 'No summary configured.'}
                    </p>
                  </div>
                </div>
              )}
            </>
          ) : (
            /* Applied Improvements Changelog */
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
              {appliedChanges.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '3rem 1rem', color: 'var(--text-muted)' }}>
                  <Sparkles size={32} style={{ margin: '0 auto 0.5rem auto', opacity: 0.4 }} />
                  <p style={{ fontSize: '0.85rem' }}>No AI changes applied to this session yet.</p>
                  <p style={{ fontSize: '0.75rem' }}>Use the AI Wand beside any bullet to test and apply improvements.</p>
                </div>
              ) : (
                appliedChanges.map((change) => (
                  <div
                    key={change.id}
                    style={{
                      padding: '0.85rem 1rem',
                      borderRadius: '8px',
                      background: 'var(--bg-tertiary)',
                      border: '1px solid var(--border-subtle)',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '0.35rem'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <span className="badge badge-emerald" style={{ fontSize: '0.65rem' }}>
                        {change.section.toUpperCase()} AI IMPROVEMENT
                      </span>
                      {onUndoChange && (
                        <button
                          type="button"
                          onClick={() => onUndoChange(change.id)}
                          className="btn btn-secondary btn-sm"
                          style={{ fontSize: '0.68rem', padding: '0.15rem 0.45rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                          title="Undo this change"
                        >
                          <Undo2 size={10} /> Undo
                        </button>
                      )}
                    </div>

                    <div style={{ fontSize: '0.76rem', color: 'var(--text-muted)', textDecoration: 'line-through' }}>
                      {change.originalText}
                    </div>

                    <div style={{ fontSize: '0.8rem', color: 'var(--accent-emerald)', fontWeight: 600 }}>
                      {change.newText}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: '1.25rem', borderTop: '1px solid var(--border-subtle)', marginTop: '0.75rem' }}>
          {onRevertAll && (
            <button
              type="button"
              onClick={onRevertAll}
              className="btn btn-outline-danger btn-sm"
              style={{ fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
            >
              <RotateCcw size={12} /> Reset to Original Baseline
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            className="btn btn-primary btn-sm"
            style={{ fontSize: '0.75rem', marginLeft: 'auto' }}
          >
            Close Comparison
          </button>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalNode, document.body) : modalNode;
};
