import type {
  StructuredResume, ResumeAnalysisResult, ResumeLearningGuideResponse,
  ResumeLearningSkillItem, ResumeLearningProjectItem,
  ResumeLearningExperienceItem, ResumeLearningEducationItem,
  ResumeLearningCertificationItem, ResumeLearningAchievementItem,
  ResumeLearningClaimItem, ResumeLearningSectionSummary, ResumeLearningSummarySection,
  ResumeLearningLineBreakdown, DeepDiveTopicDetail
} from '../types';

interface SkillKBEntry {
  what_it_is: string;
  what_it_is_used_for: string;
  what_it_means_on_resume: string;
  what_you_should_know: string[];
  how_to_explain_it: string;
  beginner: string;
  deeper: string;
  architecture_breakdown: string;
  deeper_topics: DeepDiveTopicDetail[];
  trade_offs_and_pitfalls: string[];
}

// ============================================================================
// CANONICAL KNOWLEDGE BASE FOR COMMON SKILLS
// ============================================================================

const CLIENT_SKILL_KB: Record<string, SkillKBEntry> = {
  // --- TECH & SOFTWARE ---
  python: {
    what_it_is: 'A high-level, dynamically-typed interpreted programming language known for readability, clean syntax, and rich ecosystem.',
    what_it_is_used_for: 'Building backend web APIs, data analysis, automation pipelines, machine learning models, and scientific computing.',
    what_it_means_on_resume: 'You understand core algorithmic logic, data structures, and object-oriented or functional programming to build working services and automation.',
    what_you_should_know: [
      'Mutable (lists, dicts, sets) vs immutable (tuples, strings, ints) types & memory reference semantics',
      'Execution runtime: CPython bytecode compilation, GIL (Global Interpreter Lock), and multi-threading vs multi-processing',
      'Asynchronous programming: asyncio event loop, coroutines (async/await), and non-blocking I/O',
      'Advanced language features: generators (yield), context managers (with), decorators (@), and dunder methods',
      'Package management, virtual environments (venv/poetry), and PEP 8 best practices'
    ],
    how_to_explain_it: 'I use Python to engineer backend services and data workflows. I leverage its standard library and frameworks to deliver clean, maintainable logic while understanding memory references and asynchronous I/O.',
    beginner: 'Python is a versatile programming language with English-like syntax that makes writing code and automating tasks straightforward.',
    deeper: 'Python compiles source code to bytecode (.pyc) and executes on the CPython Virtual Machine. Memory is managed via reference counting combined with a cyclic garbage collector.',
    architecture_breakdown: 'CPython executes code line-by-line using an interpreter loop over bytecode instructions. Everything in Python is a first-class heap-allocated PyObject containing a type pointer and reference counter.',
    deeper_topics: [
      {
        title: 'Memory Management & Garbage Collection',
        summary: 'How Python allocates memory and reclaims unreferenced objects.',
        architecture_mechanism: 'CPython tracks PyObject reference counts. When a count reaches 0, memory is immediately deallocated. Generational GC cleans circular references.',
        why_it_matters: 'Failing to break circular references or holding global collections can lead to memory leaks.',
        interview_defense: 'Explain how reference counting gives deterministic deallocation, while generational GC prevents cycle-induced leaks.',
        common_pitfalls: 'Using mutable default arguments (e.g., def func(items=[])) which persist across all function calls.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Rapid developer velocity and extensive library ecosystem vs slower raw CPU execution speed compared to C++ or Go.',
      'Pitfall: Modifying collections while iterating over them, causing unpredictable iteration skips or RuntimeError.'
    ]
  },

  javascript: {
    what_it_is: 'A dynamic, prototype-based scripting language that is the universal execution engine of web browsers and Node.js servers.',
    what_it_is_used_for: 'Building interactive client-side web applications, single-page apps (SPAs), backend web servers, and full-stack systems.',
    what_it_means_on_resume: 'You can build dynamic UIs, handle asynchronous network I/O, manipulate the DOM, and structure clean event-driven code.',
    what_you_should_know: [
      'The JavaScript Event Loop: Call Stack, Web APIs, Microtask Queue (Promises), and Macrotask Queue (setTimeout)',
      'Scope, Closures, Hoisting, and Lexical Environment (var vs let/const)',
      'Asynchronous patterns: Callbacks, Promises (.then/.catch), and async/await error propagation',
      'Modern ES6+ idioms: destructuring, spread/rest, optional chaining (?.), and array functional methods'
    ],
    how_to_explain_it: 'I use JavaScript to create fast, reactive user interfaces and server APIs, structuring non-blocking asynchronous requests using modern async/await and modular ES6 patterns.',
    beginner: 'JavaScript is the programming language that makes web pages interactive with clicks, forms, animations, and live data fetching.',
    deeper: 'JavaScript runs on single-threaded engines (like Google V8) featuring a Just-In-Time (JIT) compiler and an event loop orchestrating non-blocking concurrency.',
    architecture_breakdown: 'V8 parses JavaScript into an AST, generates bytecode, and hot-compiles frequently executed functions into machine code.',
    deeper_topics: [
      {
        title: 'Event Loop & Task Scheduling',
        summary: 'How single-threaded JavaScript processes concurrent asynchronous operations.',
        architecture_mechanism: 'Microtasks (Promises) have absolute priority and drain completely before macrotasks (timers, I/O) are processed.',
        why_it_matters: 'Prevents UI frame drops and subtle race conditions.',
        interview_defense: 'Walk through the execution order of synchronous code, Promises, and setTimeout.',
        common_pitfalls: 'Creating infinite microtask recursive chains that lock up the browser renderer completely.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Extreme ubiquity and ecosystem size vs dynamic type coercion quirks.',
      'Pitfall: Unhandled Promise rejections causing silent failures or server process termination.'
    ]
  },

  typescript: {
    what_it_is: 'A strongly-typed, compile-time syntactical superset of JavaScript developed by Microsoft that compiles to clean JavaScript.',
    what_it_is_used_for: 'Building enterprise-scale, maintainable frontend and backend codebases with static type safety and autocomplete.',
    what_it_means_on_resume: 'You write structured, bug-resistant code by defining precise domain data models, interfaces, and generic utility types.',
    what_you_should_know: [
      'Type inference vs explicit typing, Type Aliases vs Interfaces',
      'Structural typing ("Duck Typing") vs Nominal typing',
      'Generics (<T>), Union & Intersection types, and Discriminated Unions',
      'tsconfig.json compiler options: strict: true, noImplicitAny'
    ],
    how_to_explain_it: 'I use TypeScript to model domain types explicitly, preventing runtime null/undefined errors during compilation and ensuring reliable developer handoffs.',
    beginner: 'TypeScript adds an intelligent type-checker to JavaScript so that mistakes and typos are flagged in your editor before the code ever runs.',
    deeper: 'TypeScript performs static analysis entirely at compile-time via structural subtyping without adding any runtime overhead.',
    architecture_breakdown: 'Scanner -> Parser (AST) -> Binder (Symbols) -> Type Checker -> Emitter (.js files).',
    deeper_topics: [
      {
        title: 'Discriminated Unions & Type Narrowing',
        summary: 'Pattern for modeling robust state machines with compile-time safety.',
        architecture_mechanism: 'Using a literal discriminator property allows compiler control-flow analysis to narrow polymorphic payloads within switch branches.',
        why_it_matters: 'Eliminates impossible UI states and guarantees exhaustive handling of all cases.',
        interview_defense: 'Demonstrate writing an exhaustive switch statement with a never check in default.',
        common_pitfalls: 'Using any or as type assertions to bypass compiler checks instead of proper type narrowing.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Initial setup boilerplate and build compilation step vs drastic reduction in production runtime bugs.',
      'Pitfall: Over-relying on any or non-null assertions (!) which undermine compile-time safety.'
    ]
  },

  react: {
    what_it_is: 'A declarative, component-based frontend library developed by Meta for building modular user interfaces.',
    what_it_is_used_for: 'Building responsive Single-Page Applications (SPAs), dynamic dashboard views, and rich interactive web clients.',
    what_it_means_on_resume: 'You know how to architect UI components, manage component state and side effects, and synchronize frontend views with backend REST/GraphQL APIs.',
    what_you_should_know: [
      'Virtual DOM & the React Fiber Reconciliation algorithm',
      'React Hooks: useState, useEffect, useRef, useMemo, useCallback',
      'Unidirectional data flow, Props Drilling vs Context API vs State Management',
      'Component Lifecycle: Render phase (pure) vs Commit phase (DOM mutation)'
    ],
    how_to_explain_it: 'I build modular UIs with React, decomposing screens into reusable components and managing state lifecycles with hooks.',
    beginner: 'React lets you build web apps out of Lego-like blocks called components that update automatically when data changes.',
    deeper: 'React utilizes Fiber reconciliation to compute minimal real DOM mutations during render cycles.',
    architecture_breakdown: 'JSX transforms to React.createElement -> creates Virtual DOM tree -> diffs against previous Fiber tree -> commits batch updates to real DOM.',
    deeper_topics: [
      {
        title: 'Hooks Dependency Arrays & Referential Equality',
        summary: 'Avoiding stale closures and infinite re-render loops in useEffect.',
        architecture_mechanism: 'React compares dependency array elements using Object.is() referential equality between render cycles.',
        why_it_matters: 'Prevents infinite re-render loops and stale closure bugs.',
        interview_defense: 'Explain when and why to wrap objects and functions in useMemo and useCallback.',
        common_pitfalls: 'Omitting required dependencies or creating fresh object/array literals inside component render bodies.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Unmatched component ecosystem vs state management complexity in large SPAs.',
      'Pitfall: Mutating state directly instead of returning immutable state copies.'
    ]
  },

  sql: {
    what_it_is: 'Structured Query Language, the standardized declarative language for managing and querying relational database management systems (RDBMS).',
    what_it_is_used_for: 'Extracting business intelligence, joining multi-table entities, defining schemas with constraints, and aggregating reporting metrics.',
    what_it_means_on_resume: 'You can write performant queries, understand relational normalization, create primary/foreign keys, and optimize slow queries using indexes.',
    what_you_should_know: [
      'Query execution order: FROM/JOIN -> WHERE -> GROUP BY -> HAVING -> SELECT -> ORDER BY -> LIMIT',
      'JOIN types: INNER, LEFT, RIGHT, FULL OUTER, CROSS',
      'ACID Properties: Atomicity, Consistency, Isolation, Durability',
      'Database Indexing: B-Tree indexes, Composite Indexes, and EXPLAIN query plans'
    ],
    how_to_explain_it: 'I write SQL queries to extract and transform relational data, using joins, aggregations, and window functions while analyzing execution plans to optimize queries.',
    beginner: 'SQL is the universal language used to ask questions to tables of data stored in relational databases like PostgreSQL and MySQL.',
    deeper: 'RDBMS engines parse SQL text into relational algebra trees, which cost-based optimizers transform into execution plans utilizing index scans.',
    architecture_breakdown: 'SQL Parser -> Query Rewriter -> Cost-Based Optimizer -> Execution Engine -> Lock Manager & WAL.',
    deeper_topics: [
      {
        title: 'B-Tree Indexing & Query Plans',
        summary: 'How indexes accelerate search from O(n) sequential scan to O(log n).',
        architecture_mechanism: 'A B-Tree index is a balanced search tree stored on disk pages pointing to heap table rows.',
        why_it_matters: 'Transforms queries scanning millions of rows in seconds into sub-millisecond lookups.',
        interview_defense: 'Explain how to read EXPLAIN output (Sequential Scan vs Index Scan).',
        common_pitfalls: 'Applying functions to indexed columns in WHERE clauses which disables index usage.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Strong consistency and ACID safety vs horizontal sharding complexity.',
      'Pitfall: The N+1 query problem when fetching relational entities without eager loading.'
    ]
  },

  // --- LAW & LEGAL SKILLS ---
  'corporate law': {
    what_it_is: 'The body of law governing the formation, governance, financing, and dissolution of corporations and commercial entities.',
    what_it_is_used_for: 'Advising businesses on statutory compliance, board resolutions, shareholder agreements, mergers & acquisitions, and corporate governance.',
    what_it_means_on_resume: 'You understand the Companies Act, corporate structuring, directors’ fiduciary duties, regulatory filings, and shareholder rights.',
    what_you_should_know: [
      'Key provisions of the Companies Act (e.g., Board meetings, Director duties, Related Party Transactions)',
      'Incorporation workflows, memorandum (MoA), and articles of association (AoA)',
      'Shareholder agreements (SHA), Share Purchase Agreements (SPA), and voting covenants',
      'Corporate dispute mechanisms under the National Company Law Tribunal (NCLT)'
    ],
    how_to_explain_it: 'I assist in corporate legal advisory by reviewing statutory compliance under the Companies Act, drafting corporate resolutions and commercial agreements, and conducting regulatory filings.',
    beginner: 'Corporate law deals with the rules and regulations that companies must follow to operate legally and protect investors and shareholders.',
    deeper: 'Corporate law balances corporate entity separateness (the corporate veil) with statutory accountability, piercing of the veil in fraud, and rigorous compliance under SEBI and Ministry of Corporate Affairs regulations.',
    architecture_breakdown: 'Board & Shareholder Resolution -> Statutory Compliance Audit -> Filings via Regulatory Portals (MCA/SEBI) -> Agreement Execution & Governance Record Maintenance.',
    deeper_topics: [
      {
        title: 'Corporate Veil & Fiduciary Accountability',
        summary: 'When courts disregard the separate legal personality of a company.',
        architecture_mechanism: 'Under Salomon v Salomon and modern statutory exceptions, courts pierce the corporate veil where the entity is used as a cloak for fraud or tax evasion.',
        why_it_matters: 'Essential for structuring transactions and understanding director liabilities.',
        interview_defense: 'Discuss the grounds on which courts or tribunals pierce the corporate veil in corporate disputes.',
        common_pitfalls: 'Assuming limited liability provides absolute immunity to directors for statutory fraud or negligence.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: High commercial transaction speed vs exhaustive regulatory due diligence.',
      'Pitfall: Failing to identify undisclosed encumbrances or related-party transaction approvals in corporate audits.'
    ]
  },

  'contract drafting': {
    what_it_is: 'The professional practice of formulating written agreements that legally bind parties and delineate rights, duties, and remedies.',
    what_it_is_used_for: 'Creating commercial contracts, non-disclosure agreements (NDAs), master service agreements (MSAs), employment contracts, and vendor agreements.',
    what_it_means_on_resume: 'You can draft clear, enforceable clauses, anticipate breach scenarios, and allocate commercial risk through indemnity and limitation of liability provisions.',
    what_you_should_know: [
      'Essential elements of a valid contract (Offer, Acceptance, Lawful Consideration, Free Consent, Legal Object)',
      'Standard boilerplate clauses: Governing Law, Dispute Resolution/Arbitration, Severability, Force Majeure, Confidentiality',
      'Risk allocation clauses: Indemnification, Limitation of Liability, Representations & Warranties, Liquidated Damages',
      'Termination triggers: Material breach, insolvency, convenience, and post-termination transition obligations'
    ],
    how_to_explain_it: 'I draft and review commercial agreements by defining precise rights and obligations, structuring clear indemnities, and ensuring dispute resolution mechanisms safeguard the client.',
    beginner: 'Contract drafting is creating written legal agreements that clearly state what each party promises to do and what happens if someone breaks their word.',
    deeper: 'Contract drafting requires precise syntactical clarity, avoiding ambiguous recitals, ensuring conditions precedent are strictly defined, and establishing unambiguous liquidated damages that adhere to statutory contract law.',
    architecture_breakdown: 'Commercial Term Sheet -> Clause Drafting & Risk Allocation -> Adversarial Redlining & Negotiation -> Execution, Notarization & Stamping.',
    deeper_topics: [
      {
        title: 'Indemnity vs Liquidated Damages & Limitation of Liability',
        summary: 'Balancing legal remedies for contractual breach.',
        architecture_mechanism: 'Indemnities provide full compensation for defined third-party or direct losses; limitation of liability caps overall exposure, often excluding fraud or gross negligence.',
        why_it_matters: 'The single most contentious negotiation point in corporate and commercial contracting.',
        interview_defense: 'Walk through how you negotiate a balanced limitation of liability clause without creating unlimited client exposure.',
        common_pitfalls: 'Drafting liquidated damages clauses that courts might strike down as unenforceable penalty clauses.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Exhaustive legal protection vs commercial deal velocity and closing timelines.',
      'Pitfall: Using generic boilerplate templates without customizing governing law and dispute forums to client jurisdiction.'
    ]
  },

  'legal research': {
    what_it_is: 'The methodical identification, analysis, and synthesis of statutory enactments, judicial precedents, and legal commentaries.',
    what_it_is_used_for: 'Preparing court pleadings, case briefs, advisory opinions, due diligence reports, and moot court memorials.',
    what_it_means_on_resume: 'You can navigate legal databases (SCC Online, Manupatra), extract the ratio decidendi of judgments, and distinguish adverse precedents.',
    what_you_should_know: [
      'Boolean search query formulation in SCC Online, Manupatra, and Westlaw',
      'Hierarchy of binding precedents (Supreme Court, High Courts, Tribunals) under constitutional law',
      'Distinguishing ratio decidendi (binding holding) from obiter dicta (persuasive observation)',
      'Tracking citators to verify whether a judgment has been affirmed, overruled, or distinguished'
    ],
    how_to_explain_it: 'I conduct comprehensive legal research using databases like SCC Online and Manupatra, identifying on-point precedents and structuring case briefs to substantiate submissions.',
    beginner: 'Legal research is finding the exact laws, previous court decisions, and legal rules that support your client’s case.',
    deeper: 'Legal research synthesizes legislative history, statutory text, and judicial authority to formulate cogent propositions of law capable of withstanding bench interrogation.',
    architecture_breakdown: 'Fact Matrix Analysis -> Legal Issue Formulation -> Database Boolean Query -> Precedent Filtering & Citator Check -> Synthesis into Written Submission.',
    deeper_topics: [
      {
        title: 'Ratio Decidendi vs Obiter Dicta Analysis',
        summary: 'Extracting the binding legal rule from lengthy judicial judgments.',
        architecture_mechanism: 'Applying the Wambaugh inversion test and Goodhart material facts test to isolate the necessary legal reasoning supporting the judgment.',
        why_it_matters: 'Prevents relying on non-binding passing remarks that opposing counsel can easily dismantle.',
        interview_defense: 'Explain how you determine whether a paragraph in a Supreme Court judgment constitutes binding ratio.',
        common_pitfalls: 'Citing headnotes or obiter remarks without cross-checking the actual bench holding.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Fast preliminary research summaries vs thorough deep-dive precedent citator verification.',
      'Pitfall: Failing to verify if a cited High Court precedent has been overturned by a subsequent Supreme Court bench.'
    ]
  },

  litigation: {
    what_it_is: 'The formal process of resolving disputes through courtroom proceedings, civil or criminal trials, and appellate advocacy.',
    what_it_is_used_for: 'Representing clients in courts, filing plaints, written statements, writ petitions, injunction applications, and leading evidence.',
    what_it_means_on_resume: 'You are familiar with court procedures (CPC, CrPC), filing deadlines, bench decorum, evidence presentation, and drafting courtroom pleadings.',
    what_you_should_know: [
      'Civil Procedure: Plaint filing, Written Statement within 30/120 days, Order 39 interim injunctions, Execution of Decrees',
      'Criminal Procedure: FIR, Bail applications (regular vs anticipatory), framing of charges, trial stages',
      'Law of Evidence: Admissibility of electronic records (Sec 65B), burden of proof, examination-in-chief and cross-examination',
      'Writ Jurisdiction: Habeas Corpus, Mandamus, Quo Warranto, Prohibition, and Certiorari under Arts 32 & 226'
    ],
    how_to_explain_it: 'I assist in litigation by preparing case briefs, drafting pleadings and interim applications, organizing document annexures, and observing bench hearings.',
    beginner: 'Litigation is the process of taking a dispute to court before a judge to reach a formal legal decision.',
    deeper: 'Litigation demands procedural precision, mastery of evidence law, and strategic timing for interim reliefs to preserve the subject matter of the dispute.',
    architecture_breakdown: 'Cause of Action -> Jurisdiction & Limitation Check -> Pleading Drafting & Filing -> Notice / Summons -> Interim Hearings -> Trial & Arguments -> Decree / Judgment.',
    deeper_topics: [
      {
        title: 'Interim Injunctions & Irreparable Injury Test',
        summary: 'Securing urgent protective orders before final trial.',
        architecture_mechanism: 'Satisfying the tripartite test: (1) Prima facie case, (2) Balance of convenience, and (3) Irreparable injury not compensable in damages.',
        why_it_matters: 'The outcome of interim injunction hearings frequently dictates settlement leverage.',
        interview_defense: 'Walk through how you argue the balance of convenience in a commercial dispute.',
        common_pitfalls: 'Failing to establish clean hands or suppressing material facts in ex-parte injunction applications.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Aggressive litigation proceedings vs confidential, cost-effective out-of-court dispute settlement.',
      'Pitfall: Missing statutory limitation periods, leading to dismissal of claims at the preliminary stage.'
    ]
  },

  arbitration: {
    what_it_is: 'A private, binding alternative dispute resolution mechanism where parties submit their dispute to an independent arbitrator or tribunal.',
    what_it_is_used_for: 'Resolving high-value commercial, construction, and cross-border contractual disputes without public court proceedings.',
    what_it_means_on_resume: 'You understand the Arbitration and Conciliation Act, drafting arbitration clauses, statement of claims, and enforcement of arbitral awards.',
    what_you_should_know: [
      'Arbitration Agreements: Drafting valid clauses, seat vs venue distinction, governing law',
      'Interim Relief: Section 9 (Court-ordered interim measures) vs Section 17 (Tribunal-ordered interim measures)',
      'Challenge and Enforcement: Section 34 (grounds for setting aside awards) and Section 36 (execution)',
      'Institutional vs Ad-hoc arbitration (e.g., SIAC, ICC, LCIA, MCIA)'
    ],
    how_to_explain_it: 'I work on arbitration matters by analyzing contractual dispute clauses, drafting statements of claim and defense, and researching grounds for award enforcement or challenge.',
    beginner: 'Arbitration is like a private trial where disputing parties hire an agreed-upon expert judge called an arbitrator instead of going to public court.',
    deeper: 'Arbitration emphasizes party autonomy, minimal judicial intervention under Section 5, and expeditious resolution with strictly limited grounds for judicial appeal under Section 34.',
    architecture_breakdown: 'Notice of Dispute -> Arbitrator Appointment -> Section 9/17 Interim Relief -> Statement of Claim & Defense -> Evidentiary Hearings -> Arbitral Award -> Section 34/36 Enforcement.',
    deeper_topics: [
      {
        title: 'Seat vs Venue Jurisdictional Distinction',
        summary: 'The critical legal distinction governing supervisory court jurisdiction.',
        architecture_mechanism: 'The Seat designates the legal domicile of the arbitration, granting exclusive supervisory jurisdiction to courts at the seat; the Venue is merely the physical meeting place.',
        why_it_matters: 'Selecting the wrong seat can expose parties to unintended judicial intervention or hostile foreign court oversight.',
        interview_defense: 'Explain the landmark judicial rulings (e.g., BALCO) establishing the primacy of the arbitral seat.',
        common_pitfalls: 'Using ambiguous contract clauses like "venue and jurisdiction in Delhi, seat in London".'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Speed, confidentiality, and technical tribunal expertise vs significant arbitrator and institutional fee costs.',
      'Pitfall: Drafting defective arbitration clauses (pathological clauses) that cause preliminary jurisdictional delays.'
    ]
  },

  'due diligence': {
    what_it_is: 'A comprehensive investigation and audit of legal, regulatory, contractual, and financial risks associated with a target entity or transaction.',
    what_it_is_used_for: 'Mergers and acquisitions (M&A), private equity investments, real estate purchases, joint ventures, and IPO filings.',
    what_it_means_on_resume: 'You know how to inspect corporate registers, analyze material contracts, identify title encumbrances, and prepare red-flag due diligence reports.',
    what_you_should_know: [
      'Scope of legal due diligence: Corporate structure, material contracts, employment, litigation, IP, real estate, environmental licenses',
      'Red-flag reporting vs full-form legal due diligence reports',
      'Condition Precedents (CPs) vs Conditions Subsequent (CSs) derived from diligence findings',
      'Virtual Data Room (VDR) index management and statutory searches via public registry portals'
    ],
    how_to_explain_it: 'I conduct legal due diligence by reviewing corporate records, verifying title and licenses, red-flagging compliance gaps, and synthesizing findings into executive transaction memos.',
    beginner: 'Due diligence is a thorough background check on a company or property before buying or investing in it, finding hidden debts, lawsuits, or legal risks.',
    deeper: 'Due diligence translates legal risk into transaction mechanics: identifying whether red flags warrant valuation haircuts, indemnity escrows, or closing condition precedents.',
    architecture_breakdown: 'Information Request List (RFI) -> VDR Document Ingestion -> Verification against Statutory Registries -> Red-Flag Matrix Preparation -> Final Due Diligence Report.',
    deeper_topics: [
      {
        title: 'Material Contracts & Change of Control Triggers',
        summary: 'Auditing whether a transaction triggers termination of key customer or vendor contracts.',
        architecture_mechanism: 'Reviewing change-of-control, assignment, and non-compete clauses in major client contracts to prevent post-acquisition contract cancellations.',
        why_it_matters: 'Uncovering change-of-control triggers prevents catastrophic revenue loss after closing a buyout.',
        interview_defense: 'Walk through how you categorize diligence findings into deal-breakers, valuation adjustments, and standard CPs.',
        common_pitfalls: 'Relying exclusively on representations in management letters without verifying original underlying statutory filings.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Rigorous exhaustive document verification vs tight transaction closing deadlines.',
      'Pitfall: Failing to identify pending labour/tax litigations that carry uncapped successor liabilities.'
    ]
  },

  'scc online': {
    what_it_is: 'A premier legal research and case law database in India offering comprehensive reporting of Supreme Court, High Court, and Tribunal judgments.',
    what_it_is_used_for: 'Conducting case law research, verifying precedent history, finding statutory notifications, and retrieving law report citations (SCC citations).',
    what_it_means_on_resume: 'You can efficiently research case authorities, navigate citators, locate parallel citations, and ensure cited precedents are current.',
    what_you_should_know: [
      'Topic search, citation search, and party name search syntax',
      'The TruePrint mechanism for official court reporter submissions',
      'Using the Case Tracker / Citator to see if a judgment was referred, overruled, or affirmed',
      'Accessing Central and State statutory enactments, rules, and government notifications'
    ],
    how_to_explain_it: 'I use SCC Online to perform targeted legal research, tracking judicial citations and bench composition to support courtroom submissions with binding precedents.',
    beginner: 'SCC Online is an online digital library where legal professionals search for past court judgments, legal citations, and official laws.',
    deeper: 'SCC Online enables advanced Boolean querying, parallel citation tracking, and historical statutory analysis to construct ironclad legal propositions.',
    architecture_breakdown: 'Search Query Formulation -> Topic/Citation Index Query -> Case History & Citator Verification -> TruePrint Verification -> Proposition Memo Integration.',
    deeper_topics: [
      {
        title: 'Citator Verification & Bench Composition',
        summary: 'Verifying that a cited precedent remains binding good law.',
        architecture_mechanism: 'Checking whether subsequent larger benches have reconsidered or overruled the proposition.',
        why_it_matters: 'Citing an overruled judgment damages credibility before the bench.',
        interview_defense: 'Describe your step-by-step process in SCC Online to verify that a judgment has not been overturned.',
        common_pitfalls: 'Relying on single-judge bench decisions when conflicting division bench authorities exist.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Quick keyword searching vs rigorous Boolean structured querying.',
      'Pitfall: Failing to verify if a reported interim order was modified at the final hearing stage.'
    ]
  },

  manupatra: {
    what_it_is: 'A comprehensive Indian legal research portal providing access to case law, statutes, notifications, ordinances, and international tribunal decisions.',
    what_it_is_used_for: 'Conducting cross-jurisdictional legal research, case map visualization, and statutory compliance verification.',
    what_it_means_on_resume: 'You possess proven skills in digital legal research, precedent cross-referencing, and case law analytics.',
    what_you_should_know: [
      'Manu Search and Boolean operators (AND, OR, NOT, NEAR)',
      'Visual case maps showing precedent relationships and citation clusters',
      'Accessing circulars from regulatory bodies (SEBI, RBI, MCA, TRAI)',
      'Parallel citation converters across various legal journals (AIR, CompCas, Scale)'
    ],
    how_to_explain_it: 'I use Manupatra to research case law and regulatory circulars, utilizing visual citation maps and Boolean queries to uncover persuasive precedents.',
    beginner: 'Manupatra is an online database of court rulings and government rules that legal researchers use to find legal solutions and case citations.',
    deeper: 'Manupatra provides algorithmic citation mapping that illustrates how later courts applied, distinguished, or relied on a seminal precedent over decades.',
    architecture_breakdown: 'Legal Query Formulation -> Boolean Search -> Citation Map Visualizer -> Regulatory Circular Cross-Check -> Case Note Synthesis.',
    deeper_topics: [
      {
        title: 'Citation Mapping & Jurisprudential Trajectory',
        summary: 'Tracing how a legal concept evolves through case law clusters.',
        architecture_mechanism: 'Analyzing citation frequency and treatment tags (followed, distinguished, doubted) across High Courts.',
        why_it_matters: 'Reveals emerging judicial trends before they are formalized in Supreme Court rulings.',
        interview_defense: 'Explain how you use citation clustering to find persuasive High Court rulings on novel statutory questions.',
        common_pitfalls: 'Searching with overly broad keywords that return thousands of irrelevant hits.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Comprehensive search breadth vs manual filtering of extraneous judgments.',
      'Pitfall: Overlooking tribunal-specific nuances (e.g. ITAT, NCLAT) when researching general commercial principles.'
    ]
  },

  // --- FINANCE & COMMERCE SKILLS ---
  'financial analysis': {
    what_it_is: 'The quantitative assessment of the viability, stability, and profitability of a business, project, or investment.',
    what_it_is_used_for: 'Evaluating financial statements, computing financial ratios, forecasting earnings, and supporting credit or investment decisions.',
    what_it_means_on_resume: 'You can read P&L, Balance Sheet, and Cash Flow statements, calculate profitability and liquidity ratios, and identify financial trends.',
    what_you_should_know: [
      'Core Financial Statements: Income Statement, Balance Sheet, Cash Flow Statement (Operating, Investing, Financing)',
      'Key Ratios: Liquidity (Current, Quick), Solvency (Debt-to-Equity), Profitability (Gross Margin, ROE, ROCE), Efficiency (Asset Turnover)',
      'Horizontal and vertical financial statement analysis',
      'Working capital management and cash conversion cycle'
    ],
    how_to_explain_it: 'I perform financial analysis by assessing statements, computing profitability and solvency ratios, and building variance models to evaluate performance.',
    beginner: 'Financial analysis is examining a company’s financial records and numbers to understand if it is making money and operating healthily.',
    deeper: 'Financial analysis evaluates underlying cash earnings quality, adjusting for non-operating items, working capital fluctuations, and capital expenditure obligations.',
    architecture_breakdown: 'Data Ingestion -> Statement Normalization -> Financial Ratio Computation -> Variance & Trend Analysis -> Executive Report.',
    deeper_topics: [
      {
        title: 'Cash Flow Quality & Working Capital Dynamics',
        summary: 'Evaluating true operational cash generation beyond accounting profit.',
        architecture_mechanism: 'Reconciling net profit to Operating Cash Flow by analyzing changes in receivables, payables, and inventory balances.',
        why_it_matters: 'A profitable company on paper can still experience liquidity failure if working capital is mismanaged.',
        interview_defense: 'Explain how you evaluate whether a company’s reported net income is backed by genuine operating cash flow.',
        common_pitfalls: 'Treating EBITDA as pure cash flow without accounting for working capital requirements and tax payments.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: Fast automated ratio summaries vs in-depth accounting footnotes analysis.',
      'Pitfall: Comparing financial ratios across companies using different revenue recognition accounting policies.'
    ]
  },

  'auditing': {
    what_it_is: 'The systematic, independent examination of financial records, statements, and operational procedures to ensure accuracy and regulatory compliance.',
    what_it_is_used_for: 'Verifying financial statements (statutory audit), evaluating internal controls, detecting discrepancies or fraud, and reporting to audit committees.',
    what_it_means_on_resume: 'You understand auditing standards (Standards on Auditing), sample testing, voucher verification, inventory counts, and internal financial controls.',
    what_you_should_know: [
      'Auditing Standards (SAs) and statutory audit reporting guidelines',
      'Audit procedures: Substantive testing, analytical procedures, test of controls, walk-through tests',
      'Vouching, ledger verification, bank reconciliations, and third-party balance confirmations',
      'Reporting under CARO (Companies Auditor\'s Report Order) and identifying material misstatements'
    ],
    how_to_explain_it: 'I conduct audit engagements by testing internal controls, verifying transaction vouchers against ledgers, and evaluating disclosures under statutory standards.',
    beginner: 'Auditing is an independent check on a company\'s financial records to make sure there are no errors, mistakes, or cheating in their numbers.',
    deeper: 'Auditing evaluates audit risk (Inherent Risk x Control Risk x Detection Risk) to design substantive testing procedures that provide reasonable assurance against material misstatements.',
    architecture_breakdown: 'Audit Planning & Risk Assessment -> Internal Control Testing -> Substantive Voucher Sampling -> Review of Disclosures -> Independent Audit Report.',
    deeper_topics: [
      {
        title: 'Audit Sampling & Materiality Thresholds',
        summary: 'Designing statistically valid testing without inspecting every single transaction.',
        architecture_mechanism: 'Setting overall materiality, performance materiality, and threshold testing for high-risk accounts.',
        why_it_matters: 'Balances audit cost and time with professional duty to detect material reporting errors.',
        interview_defense: 'Explain how you determine performance materiality when auditing revenue and receivables.',
        common_pitfalls: 'Failing to independently corroborate third-party balances and relying solely on internal client vouchers.'
      }
    ],
    trade_offs_and_pitfalls: [
      'Trade-off: High-speed sample auditing vs detection risk for specialized irregularities.',
      'Pitfall: Failing to evaluate subsequent balance sheet events occurring between year-end and audit sign-off.'
    ]
  }
};

// ============================================================================
// DYNAMIC DOMAIN DETECTOR & MULTI-DOMAIN PROFILES
// ============================================================================

export type DomainClassification =
  | 'Law & Legal'
  | 'Finance & Commerce'
  | 'Management & Operations'
  | 'Healthcare & Medicine'
  | 'Civil Engineering'
  | 'Mechanical Engineering'
  | 'Electrical & Electronics'
  | 'Computer Science & Engineering'
  | 'General Professional';

/**
 * Accurately detects the resume's true domain by analyzing degrees, institutions,
 * job roles, skills, and summary text. Never defaults to tech when clear
 * legal, financial, or operational credentials exist.
 */
export function detectResumeDomain(
  structuredResume: StructuredResume | null,
  analysis: ResumeAnalysisResult | null
): DomainClassification {
  // Aggregate all raw text evidence from the resume
  const textCorpus: string[] = [];

  if (analysis?.filename) textCorpus.push(analysis.filename);
  if (analysis?.detected_domain) textCorpus.push(analysis.detected_domain);

  if (structuredResume) {
    if (structuredResume.headline) textCorpus.push(structuredResume.headline);
    if (structuredResume.title) textCorpus.push(structuredResume.title);
    if (structuredResume.summary) textCorpus.push(structuredResume.summary);
    if (structuredResume.personal_info?.title) textCorpus.push(structuredResume.personal_info.title);
    if (structuredResume.personal_info?.headline) textCorpus.push(structuredResume.personal_info.headline);
    if (structuredResume.personal_info?.summary) textCorpus.push(structuredResume.personal_info.summary);

    // Education entries
    (structuredResume.education || []).forEach(e => {
      if (e.degree) textCorpus.push(e.degree);
      if (e.institution) textCorpus.push(e.institution);
      if (e.field_of_study) textCorpus.push(e.field_of_study);
      if (e.coursework) textCorpus.push(e.coursework.join(' '));
    });

    // Experience entries
    (structuredResume.experience || []).forEach(e => {
      if (e.role) textCorpus.push(e.role);
      if (e.company) textCorpus.push(e.company);
      if ((e as any).description) textCorpus.push((e as any).description);
      if (e.bullets) textCorpus.push(e.bullets.join(' '));
    });

    // Projects
    (structuredResume.projects || []).forEach(p => {
      if (p.title) textCorpus.push(p.title);
      if (p.description) textCorpus.push(p.description);
      if (p.technologies) textCorpus.push(p.technologies.join(' '));
      if (p.bullets) textCorpus.push(p.bullets.join(' '));
    });

    // Skills
    if (structuredResume.skills) {
      textCorpus.push(structuredResume.skills.join(' '));
    }
  }

  const fullText = textCorpus.join(' ').toLowerCase();

  // Scoring matrix
  const scores: Record<DomainClassification, number> = {
    'Law & Legal': 0,
    'Finance & Commerce': 0,
    'Management & Operations': 0,
    'Healthcare & Medicine': 0,
    'Civil Engineering': 0,
    'Mechanical Engineering': 0,
    'Electrical & Electronics': 0,
    'Computer Science & Engineering': 0,
    'General Professional': 0
  };

  // 1. Law & Legal Check
  if (/\b(ba\s*llb|bba\s*llb|b\.a\.\s*ll\.?b\.?|ll\.?b\.?|ll\.?m\.?|faculty of law|law faculty|national law university|nlu|advocate|law firm|chambers of|high court|supreme court|district court|bar council|legal intern|judicial clerk|legal associate|moot court)\b/i.test(fullText)) {
    scores['Law & Legal'] += 40;
  }
  if (/\b(legal research|litigation|arbitration|contract drafting|due diligence|scc online|manupatra|intellectual property|corporate law|cpc|crpc|ipc|constitution of india|tort law|commercial law|pleadings|memorials|statutory compliance|affidavit|petition|writ jurisdiction|jurisprudence)\b/i.test(fullText)) {
    scores['Law & Legal'] += 25;
  }

  // 2. Finance & Commerce Check
  if (/\b(b\.?com|m\.?com|chartered accountant|ca inter|ca final|cfa|auditing|taxation|gst compliance|tally prime|balance sheet analysis|statutory audit|income tax|cost accounting|financial accounting)\b/i.test(fullText)) {
    scores['Finance & Commerce'] += 35;
  }
  if (/\b(financial modeling|dcf|corporate finance|financial analyst|equity research|account reconciliation|working capital|variance analysis|balance sheet|profit and loss|ledger)\b/i.test(fullText)) {
    scores['Finance & Commerce'] += 20;
  }

  // 3. Healthcare & Medicine Check
  if (/\b(mbbs|b\.?pharm|m\.?pharm|bds|md medicine|clinical research|pharmacology|pharmacovigilance|patient care|nursing|hospital resident|pathology|medical diagnostics)\b/i.test(fullText)) {
    scores['Healthcare & Medicine'] += 35;
  }

  // 4. Civil Engineering Check
  if (/\b(civil engineering|b\.?tech civil|staad\.?pro|revit|etabs|structural analysis|quantity surveying|bim modeling|surveying|construction management)\b/i.test(fullText)) {
    scores['Civil Engineering'] += 35;
  }

  // 5. Mechanical Engineering Check
  if (/\b(mechanical engineering|b\.?tech mechanical|solidworks|catia|ansys|thermodynamics|cad\/cam|hvac design|finite element analysis|fea|cfd)\b/i.test(fullText)) {
    scores['Mechanical Engineering'] += 35;
  }

  // 6. Electrical & Electronics Check
  if (/\b(electrical engineering|electronics|b\.?tech ece|b\.?tech eee|vlsi|verilog|vhdl|embedded c|pcb design|altium|microcontroller|circuit design|plc \/ scada)\b/i.test(fullText)) {
    scores['Electrical & Electronics'] += 35;
  }

  // 7. Management & Operations Check
  if (/\b(supply chain management|procurement|logistics|operations executive|operations manager|hr operations|talent acquisition|digital marketing|gem portal|mba|bba)\b/i.test(fullText)) {
    scores['Management & Operations'] += 25;
  }

  // 8. Computer Science & Engineering Check
  if (/\b(b\.?tech cse|b\.?tech it|bca|mca|software developer|software engineer|frontend developer|backend developer|full stack|data scientist|machine learning engineer|devops engineer)\b/i.test(fullText)) {
    scores['Computer Science & Engineering'] += 30;
  }
  if (/\b(react|python|javascript|typescript|fastapi|django|docker|kubernetes|node\.?js|sql|aws|git|html|css|ci\/cd|rest api)\b/i.test(fullText)) {
    // Only give points if not heavily outweighed by Law, Finance, etc.
    scores['Computer Science & Engineering'] += 10;
  }

  // Find max scored domain
  let bestDomain: DomainClassification = 'General Professional';
  let maxScore = 0;

  for (const [dom, score] of Object.entries(scores)) {
    if (score > maxScore) {
      maxScore = score;
      bestDomain = dom as DomainClassification;
    }
  }

  // If score is 0, check analysis.detected_domain
  if (maxScore === 0 && analysis?.detected_domain) {
    const rawDom = analysis.detected_domain.toLowerCase();
    if (rawDom.includes('law') || rawDom.includes('legal')) return 'Law & Legal';
    if (rawDom.includes('finance') || rawDom.includes('commerce') || rawDom.includes('account')) return 'Finance & Commerce';
    if (rawDom.includes('manage') || rawDom.includes('operat') || rawDom.includes('market')) return 'Management & Operations';
    if (rawDom.includes('civil')) return 'Civil Engineering';
    if (rawDom.includes('mech')) return 'Mechanical Engineering';
    if (rawDom.includes('elect')) return 'Electrical & Electronics';
    if (rawDom.includes('health') || rawDom.includes('medic') || rawDom.includes('pharm')) return 'Healthcare & Medicine';
    if (rawDom.includes('computer') || rawDom.includes('software') || rawDom.includes('tech')) return 'Computer Science & Engineering';
  }

  return bestDomain;
}

// ============================================================================
// DOMAIN PROFILE DEFINITIONS
// ============================================================================

interface DomainProfile {
  title: string;
  educationKeyConceptsTitle: string;
  educationKeyConcepts: string[];
  educationDeeperFoundations: DeepDiveTopicDetail[];
  experienceImportantTerminology: { term: string; definition: string }[];
  experienceOperationalContext: string;
  experienceDeeperLearnings: DeepDiveTopicDetail[];
  projectSystemArchitectureLabel: string;
  projectSystemArchitecture: (projectName: string, techs: string[]) => string;
  projectDeeperConcepts: (projectName: string, techs: string[]) => DeepDiveTopicDetail[];
  projectDeeperDefense: (projectName: string, techs: string[]) => DeepDiveTopicDetail[];
}

const DOMAIN_PROFILES: Record<DomainClassification, DomainProfile> = {
  'Law & Legal': {
    title: 'Law & Legal Studies',
    educationKeyConceptsTitle: 'Academic Core Concepts & Jurisprudential Theory',
    educationKeyConcepts: [
      'Constitutional Law & Judicial Review (Fundamental Rights, Writ Jurisdiction under Arts 32 & 226)',
      'Law of Contracts & Specific Relief (Formation, Breach, Liquidated Damages & Indemnity)',
      'Civil & Criminal Procedural Frameworks (Code of Civil Procedure, Criminal Procedure, Law of Evidence)',
      'Statutory Interpretation & Ratio Decidendi (Precedent Analysis, Harmonious Construction & Legislative Intent)',
      'Corporate Law & Regulatory Governance (Companies Act, Corporate Due Diligence, Board Governance)'
    ],
    educationDeeperFoundations: [
      {
        title: 'Jurisprudential Reasoning & Precedent Distinguishing',
        summary: 'Extracting the binding ratio decidendi from judgments and distinguishing divergent bench authorities.',
        architecture_mechanism: 'Applying material facts analysis to isolate the necessary legal principle from non-binding obiter dicta in high court and supreme court rulings.',
        why_it_matters: 'Forms the universal foundation for oral arguments and written advisory memorandums.',
        interview_defense: 'Be ready to discuss leading precedents in your practice area, explaining how you apply ratio decidendi to factual client scenarios.',
        common_pitfalls: 'Citing headnotes or obiter dicta as binding law without analyzing underlying facts.'
      },
      {
        title: 'Statutory Interpretation & Harmonious Construction',
        summary: 'Reconciling overlapping statutory provisions and legislative notifications.',
        architecture_mechanism: 'Applying the Literal Rule, Mischief Rule, and Golden Rule alongside internal aids (definitions, provisos) and external legislative records.',
        why_it_matters: 'Crucial for complex regulatory compliance, corporate dispute strategy, and writ petitions.',
        interview_defense: 'Explain how you resolve conflicting statutory clauses using harmonious construction.',
        common_pitfalls: 'Assuming plain literal meaning applies when a purposive interpretation is required to prevent absurdity.'
      }
    ],
    experienceImportantTerminology: [
      { term: 'Legal Due Diligence', definition: 'Rigorous audit of corporate records, material contracts, liabilities, and statutory filings to quantify legal risk.' },
      { term: 'Ratio Decidendi', definition: 'The essential legal principle or rationale upon which a court bases its binding judgment.' },
      { term: 'Pleadings & Memorials', definition: 'Formal written arguments, petitions, and legal submissions drafted for trial or appellate benches.' },
      { term: 'Bench Precedent Analysis', definition: 'Cross-referencing primary case citations via databases like SCC Online and Manupatra to verify binding authority.' },
      { term: 'Indemnity & Remedies', definition: 'Contractual risk allocation mechanisms and legal remedies (injunctions, damages, specific performance).' }
    ],
    experienceOperationalContext:
      'Legal workflows conducted within chambers, corporate counsel, or law firms involving statutory research, case briefing, draft pleadings, client advisory, and court appearances.',
    experienceDeeperLearnings: [
      {
        title: 'Legal Due Diligence & Risk Mitigation',
        summary: 'Identifying non-compliance, encumbrances, and litigation exposure in commercial matters.',
        architecture_mechanism: 'Reviewing title deeds, material contracts, regulatory licenses, and employment policies against statutory benchmarks.',
        why_it_matters: 'Demonstrates professional competence in transaction advisory and liability containment.',
        interview_defense: 'Describe a due diligence issue or contract anomaly you discovered and how you advised partners on mitigating it.',
        common_pitfalls: 'Relying exclusively on representations without verifying underlying statutory registry filings.'
      },
      {
        title: 'Case Law Synthesis & Courtroom Briefing',
        summary: 'Translating complex jurisprudence into actionable arguments for senior counsel and bench hearings.',
        architecture_mechanism: 'Building structured argument outlines with primary citations, distinguishing adverse rulings, and preparing proposition binders.',
        why_it_matters: 'Shows readiness to manage high-stakes client matters with meticulous factual and statutory preparation.',
        interview_defense: 'Explain your strategy when briefing a case where precedent appears initially unfavorable to your position.',
        common_pitfalls: 'Failing to verify subsequent appellate history or amendments to cited statutory sections.'
      }
    ],
    projectSystemArchitectureLabel: 'Legal Research & Advisory Pipeline',
    projectSystemArchitecture: (_name, _techs) =>
      `Client Matter / Dispute Intake -> Statutory & Precedent Research (SCC Online / Manupatra) -> Issue Formulation & Legal Analysis -> Draft Petition / Contract / Advisory Memo -> Bench / Client Presentation.`,
    projectDeeperConcepts: (_name, _techs) => [
      {
        title: 'Framing Legal Issues & Jurisdictional Grounds',
        summary: 'Establishing locus standi, forum jurisdiction, and substantive causes of action.',
        architecture_mechanism: 'Formulating precise legal questions and structuring alternative prayers supported by statutory provisions.',
        why_it_matters: 'If preliminary jurisdictional maintainability fails, substantive arguments are never considered.',
        interview_defense: 'Explain why you framed the issues in this sequence and how you established jurisdiction.',
        common_pitfalls: 'Conflating pure questions of fact with substantial questions of law.'
      },
      {
        title: 'Contractual Enforceability & Dispute Strategy',
        summary: 'Ensuring contractual clauses or legal petitions withstand adversarial challenge.',
        architecture_mechanism: 'Eliminating syntactical ambiguities, incorporating dispute resolution clauses (arbitration/mediation), and safeguarding statutory remedies.',
        why_it_matters: 'Poor drafting leads to costly arbitration, ambiguous liabilities, and litigation losses.',
        interview_defense: 'How did you ensure that the terms or remedies you drafted would be enforceable under judicial scrutiny?',
        common_pitfalls: 'Using generic boilerplate clauses that conflict with the governing law jurisdiction.'
      }
    ],
    projectDeeperDefense: (_name, _techs) => [
      {
        title: 'Authority Research & Database Verification',
        summary: 'Ensuring cited authorities are binding good law and have not been overruled.',
        architecture_mechanism: 'Checking citators, bench size, subsequent revisions, and constitutional bench judgments.',
        why_it_matters: 'Citing overturned authorities damages credibility before judges and partners.',
        interview_defense: 'How do you verify whether a precedent cited by opposing counsel has been diluted or distinguished?',
        common_pitfalls: 'Relying on single-judge bench decisions when conflicting division bench authorities exist.'
      }
    ]
  },

  'Finance & Commerce': {
    title: 'Finance & Commerce',
    educationKeyConceptsTitle: 'Academic Core Concepts & Financial Theory',
    educationKeyConcepts: [
      'Financial Statement Analysis (Income Statement, Balance Sheet, Cash Flow Dynamics)',
      'Corporate Finance & Capital Budgeting (NPV, IRR, WACC, Capital Structure Optimization)',
      'Auditing Standards & Internal Financial Controls (Statutory Audits, GAAP/IFRS Standards)',
      'Taxation & Statutory Regulatory Compliance (Direct Tax, GST Frameworks, Withholding)',
      'Financial Modeling & Valuation (Discounted Cash Flow, Comparable Multiples, Ratio Metrics)'
    ],
    educationDeeperFoundations: [
      {
        title: 'Working Capital Management & Cash Conversion Cycle',
        summary: 'Balancing operational liquidity against profitability.',
        architecture_mechanism: 'Measuring Day Sales Outstanding (DSO), Days Inventory Outstanding (DIO), and Days Payable Outstanding (DPO).',
        why_it_matters: 'Guarantees operational solvency and prevents liquidity traps.',
        interview_defense: 'Explain how optimizing the cash conversion cycle releases tied-up capital.',
        common_pitfalls: 'Focusing exclusively on net income without examining operating cash flows.'
      }
    ],
    experienceImportantTerminology: [
      { term: 'Working Capital Cycle', definition: 'The time required to convert net current assets into cash inflows.' },
      { term: 'Variance Analysis', definition: 'Evaluating the difference between planned budget targets and actual results.' },
      { term: 'Internal Financial Controls', definition: 'Processes ensuring data integrity, fraud prevention, and GAAP compliance.' },
      { term: 'EBITDA', definition: 'Earnings Before Interest, Taxes, Depreciation, and Amortization used as an operational cash flow proxy.' }
    ],
    experienceOperationalContext:
      'Financial workflows conducted within corporate finance, accounting firms, or audit practices involving ledger reconciliation, statement compilation, tax filings, and variance modeling.',
    experienceDeeperLearnings: [
      {
        title: 'Audit Trail & Financial Reconciliation',
        summary: 'Verifying underlying vouchers and third-party confirmations against general ledger entries.',
        architecture_mechanism: 'Substantive testing, bank reconciliations, and discrepancy root-cause isolation.',
        why_it_matters: 'Ensures books provide a true and fair view free from material misstatements.',
        interview_defense: 'Walk through how you resolved a major ledger discrepancy or reconciliation gap.',
        common_pitfalls: 'Relying on client-provided summary spreadsheets without verifying raw bank statements.'
      }
    ],
    projectSystemArchitectureLabel: 'Financial Modeling & Reporting Architecture',
    projectSystemArchitecture: (_name, _techs) =>
      `Transaction Data / General Ledger -> Reconciliation & Validation -> Financial Statement Aggregation -> Variance & Ratio Modeling -> Executive & Audit Reporting.`,
    projectDeeperConcepts: (_name, _techs) => [
      {
        title: 'Model Sensitivity & Stress Testing',
        summary: 'Evaluating financial models under adverse economic scenarios.',
        architecture_mechanism: 'Building dynamic sensitivity tables varying revenue growth, cost of capital, and margin compression.',
        why_it_matters: 'Shows maturity in risk assessment beyond single-point estimates.',
        interview_defense: 'Discuss the key assumptions in your model and how you stress-tested them.',
        common_pitfalls: 'Hardcoding numbers in Excel formulas instead of using dynamic reference inputs.'
      }
    ],
    projectDeeperDefense: (_name, _techs) => [
      {
        title: 'Valuation & Capital Structure Trade-offs',
        summary: 'Balancing debt vs equity financing and cost of capital.',
        architecture_mechanism: 'Evaluating WACC minimization against financial distress costs.',
        why_it_matters: 'Demonstrates strategic corporate finance thinking.',
        interview_defense: 'Explain how you selected comparable peer companies for multiples valuation.',
        common_pitfalls: 'Using historical multiples without adjusting for forward earnings guidance.'
      }
    ]
  },

  'Management & Operations': {
    title: 'Management & Operations',
    educationKeyConceptsTitle: 'Academic Core Concepts & Management Principles',
    educationKeyConcepts: [
      'Operations Management & Process Flow (Throughput, Bottleneck Analysis, Lean Principles)',
      'Supply Chain Logistics & Procurement (Vendor Evaluation, Inventory Optimization, SLA Tracking)',
      'Strategic Planning & Performance Metrics (Balanced Scorecard, OKRs, ROI Tracking)',
      'Organizational Leadership & Change Management (Cross-functional Alignment, Stakeholder Engagement)'
    ],
    educationDeeperFoundations: [
      {
        title: 'Process Optimization & Waste Elimination',
        summary: 'Applying Lean methodologies to eliminate operational bottlenecks.',
        architecture_mechanism: 'Value stream mapping to identify non-value-adding delays and streamline throughput.',
        why_it_matters: 'Directly drives bottom-line profitability and customer satisfaction.',
        interview_defense: 'Describe how you identified and resolved an operational bottleneck.',
        common_pitfalls: 'Optimizing a single step locally while worsening the broader system bottleneck.'
      }
    ],
    experienceImportantTerminology: [
      { term: 'SLA Governance', definition: 'Service Level Agreement benchmarks ensuring operational delivery speed and quality.' },
      { term: 'Kaizen / Lean', definition: 'Principles of continuous incremental process improvement.' },
      { term: 'Stakeholder Matrix', definition: 'Mapping internal and external stakeholders by influence and interest.' }
    ],
    experienceOperationalContext:
      'Operations and business workflows involving process mapping, resource coordination, vendor management, and KPI tracking.',
    experienceDeeperLearnings: [
      {
        title: 'Operational Risk & Vendor Governance',
        summary: 'Managing third-party supply chain risks and contract deliverables.',
        architecture_mechanism: 'Structured supplier audits, performance scorecards, and contingency sourcing.',
        why_it_matters: 'Prevents business disruptions and unbudgeted operational costs.',
        interview_defense: 'How did you handle a vendor failing to meet critical delivery deadlines?',
        common_pitfalls: 'Single-sourcing critical supplies without qualified fallback vendors.'
      }
    ],
    projectSystemArchitectureLabel: 'Operational Workflow Framework',
    projectSystemArchitecture: (_name, _techs) =>
      `Demand / Requirement Intake -> Process Mapping & Resource Allocation -> Execution & Workflow Automation -> SLA Tracking -> Performance Review.`,
    projectDeeperConcepts: (_name, _techs) => [
      {
        title: 'Root Cause Analysis & Corrective Actions',
        summary: 'Investigating operational failures using 5-Whys and Fishbone diagrams.',
        architecture_mechanism: 'Systematic failure mode isolation and preventative process controls.',
        why_it_matters: 'Prevents recurrence of costly operational breakdowns.',
        interview_defense: 'Walk through an operational failure you investigated and the permanent fix you introduced.',
        common_pitfalls: 'Treating surface symptoms rather than underlying procedural root causes.'
      }
    ],
    projectDeeperDefense: (_name, _techs) => [
      {
        title: 'Change Management & Stakeholder Buy-in',
        summary: 'Rolling out new processes across resistant teams.',
        architecture_mechanism: 'Structured pilot testing, transparent communication, and targeted training.',
        why_it_matters: 'Even the best operational process fails without user adoption.',
        interview_defense: 'How do you convince skeptical team members to adopt a new operating workflow?',
        common_pitfalls: 'Imposing process changes top-down without consulting front-line workers.'
      }
    ]
  },

  'Healthcare & Medicine': {
    title: 'Healthcare & Clinical Sciences',
    educationKeyConceptsTitle: 'Academic Core Concepts & Clinical Foundations',
    educationKeyConcepts: [
      'Pathophysiology & Disease Mechanisms',
      'Pharmacotherapeutics & Adverse Drug Reactions',
      'Clinical Care Protocols, Triage & Patient Safety Standards',
      'Medical Ethics, Patient Confidentiality & Regulatory Health Governance'
    ],
    educationDeeperFoundations: [
      {
        title: 'Evidence-Based Clinical Practice',
        summary: 'Applying peer-reviewed clinical trials and guidelines to patient care decisions.',
        architecture_mechanism: 'Synthesizing systematic reviews and clinical trial endpoints.',
        why_it_matters: 'Ensures optimal therapeutic efficacy while minimizing adverse drug events.',
        interview_defense: 'Explain how you stay updated with clinical guidelines and evidence.',
        common_pitfalls: 'Relying on outdated clinical routines without verifying recent clinical trials.'
      }
    ],
    experienceImportantTerminology: [
      { term: 'Patient Triage', definition: 'Prioritizing patients based on severity of condition and urgency of care.' },
      { term: 'Pharmacovigilance', definition: 'Monitoring and evaluating adverse drug events to ensure patient safety.' },
      { term: 'Confidentiality (HIPAA)', definition: 'Strict standards protecting patient medical records and private health information.' }
    ],
    experienceOperationalContext:
      'Clinical and healthcare workflows conducted in hospitals, clinics, or research labs involving patient assessment, diagnostic evaluation, and treatment protocol adherence.',
    experienceDeeperLearnings: [
      {
        title: 'Patient Safety & Clinical Protocol Adherence',
        summary: 'Executing standardized protocols to prevent clinical errors.',
        architecture_mechanism: 'Dual-check medication verification and structured handover checklists.',
        why_it_matters: 'Directly impacts patient survival and clinical recovery rates.',
        interview_defense: 'Describe how you handle a near-miss clinical error or medication discrepancy.',
        common_pitfalls: 'Rushing clinical handovers during shift changes.'
      }
    ],
    projectSystemArchitectureLabel: 'Clinical Care Workflow',
    projectSystemArchitecture: (_name, _techs) =>
      `Patient Presentation / Intake -> Diagnostic Evaluation -> Treatment Formulation -> Care Delivery & Monitoring -> Clinical Outcome Review.`,
    projectDeeperConcepts: (_name, _techs) => [
      {
        title: 'Diagnostic Reasoning & Differential Diagnosis',
        summary: 'Systematically narrowing down potential causes of clinical symptoms.',
        architecture_mechanism: 'Synthesizing history, physical exam findings, lab panels, and imaging.',
        why_it_matters: 'Prevents misdiagnosis and delays in critical therapy.',
        interview_defense: 'Walk through your diagnostic approach when presented with non-specific symptoms.',
        common_pitfalls: 'Premature diagnostic closure without ruling out high-risk alternative causes.'
      }
    ],
    projectDeeperDefense: (_name, _techs) => [
      {
        title: 'Ethical Decision-Making & Patient Advocacy',
        summary: 'Navigating informed consent and complex patient autonomy dilemmas.',
        architecture_mechanism: 'Balancing beneficence, non-maleficence, autonomy, and justice.',
        why_it_matters: 'Forms the ethical bedrock of medical practice.',
        interview_defense: 'Discuss an ethically complex clinical situation and how you navigated it.',
        common_pitfalls: 'Disregarding patient autonomy or cultural preferences in treatment planning.'
      }
    ]
  },

  'Civil Engineering': {
    title: 'Civil & Structural Engineering',
    educationKeyConceptsTitle: 'Academic Core Concepts & Structural Engineering Principles',
    educationKeyConcepts: [
      'Structural Analysis & Mechanics of Solids (Bending Moments, Shear Forces, Deflection)',
      'Geotechnical & Foundation Engineering (Soil Mechanics, Bearing Capacity, Settlement)',
      'Concrete & Steel Design (Limit State Method, IS 456 / AISC Standards)',
      'BIM Modeling & Surveying (Revit, Total Station, Leveling, GIS Spatial Analysis)'
    ],
    educationDeeperFoundations: [
      {
        title: 'Limit State Design & Safety Factors',
        summary: 'Balancing structural strength and serviceability under extreme loads.',
        architecture_mechanism: 'Calculating partial safety factors for loads and materials under Limit State of Collapse and Serviceability.',
        why_it_matters: 'Prevents structural collapse while optimizing construction materials.',
        interview_defense: 'Explain the difference between working stress and limit state design methods.',
        common_pitfalls: 'Neglecting serviceability deflection and crack-width criteria while focusing only on strength.'
      }
    ],
    experienceImportantTerminology: [
      { term: 'BIM (Building Information Modeling)', definition: 'Digital 3D representation of physical and functional building characteristics.' },
      { term: 'Limit State Method', definition: 'Design methodology ensuring structures do not reach failure under probabilistic load combinations.' },
      { term: 'Soil Bearing Capacity', definition: 'The maximum load per unit area that foundation soil can support without shear failure.' }
    ],
    experienceOperationalContext:
      'Civil engineering workflows involving site surveying, structural drafting, quantity estimation, and quality inspection on construction projects.',
    experienceDeeperLearnings: [
      {
        title: 'Site Safety & Material Quality Assurance',
        summary: 'Conducting slump tests, cube compressive tests, and reinforcement bar inspections.',
        architecture_mechanism: 'Standardized testing following ASTM / IS testing protocols.',
        why_it_matters: 'Ensures constructed elements match structural engineering blueprints.',
        interview_defense: 'How did you handle a batch of concrete failing 28-day compressive strength tests?',
        common_pitfalls: 'Allowing concrete pouring before inspecting bar binding and cover blocks.'
      }
    ],
    projectSystemArchitectureLabel: 'Structural Design & Execution Pipeline',
    projectSystemArchitecture: (_name, _techs) =>
      `Architectural Drawings -> Load Computation (Dead/Live/Wind/Seismic) -> Structural Analysis (STAAD.Pro / ETABS) -> Reinforcement Detailing -> Construction Execution.`,
    projectDeeperConcepts: (_name, _techs) => [
      {
        title: 'Seismic & Lateral Load Resistance',
        summary: 'Designing shear walls and moment-resisting frames to withstand earthquake loads.',
        architecture_mechanism: 'Applying response spectrum method and ductility detailing (IS 13920).',
        why_it_matters: 'Essential for structural resilience and life safety in seismic zones.',
        interview_defense: 'Explain how shear walls resist lateral base shear in multi-story structures.',
        common_pitfalls: 'Creating soft-story irregularities in ground-floor parking levels without strengthening.'
      }
    ],
    projectDeeperDefense: (_name, _techs) => [
      {
        title: 'Quantity Takeoff & Cost Estimation',
        summary: 'Translating design blueprints into accurate bills of quantities (BOQ).',
        architecture_mechanism: 'Detailed measurement sheets, rate analysis, and contingency budgeting.',
        why_it_matters: 'Prevents massive budget overruns during construction execution.',
        interview_defense: 'How do you account for steel wastage and formwork reuse in your estimates?',
        common_pitfalls: 'Using broad thumb-rules instead of exact schedule-of-rates itemization.'
      }
    ]
  },

  'Mechanical Engineering': {
    title: 'Mechanical Engineering',
    educationKeyConceptsTitle: 'Academic Core Concepts & Mechanical Engineering Principles',
    educationKeyConcepts: [
      'Thermodynamics & Heat Transfer (Conduction, Convection, Radiation, Carnot Cycles)',
      'Fluid Mechanics & Aerodynamics (Navier-Stokes, Bernoulli, Boundary Layer Theory)',
      'Mechanics of Materials & Machine Design (Stress Concentrations, Fatigue, Von Mises Yield)',
      'CAD / CAM & Manufacturing Processes (GD&T, CNC Machining, Casting, Welding)'
    ],
    educationDeeperFoundations: [
      {
        title: 'Failure Theories & Fatigue Life Analysis',
        summary: 'Predicting component failure under cyclic loading.',
        architecture_mechanism: 'Applying Von Mises stress criteria for ductile materials and S-N endurance limit curves.',
        why_it_matters: 'Prevents catastrophic machine failure in automotive and aerospace assemblies.',
        interview_defense: 'Explain how stress concentration factors (Kt) affect component fatigue life.',
        common_pitfalls: 'Relying on static yield strength for components subjected to cyclic vibration.'
      }
    ],
    experienceImportantTerminology: [
      { term: 'GD&T', definition: 'Geometric Dimensioning and Tolerancing system specifying exact part geometry and allowable variation.' },
      { term: 'FEA (Finite Element Analysis)', definition: 'Numerical simulation method for predicting how a part reacts to real-world forces and heat.' },
      { term: 'Von Mises Stress', definition: 'Yield criterion used to predict yielding of ductile materials under complex multiaxial loading.' }
    ],
    experienceOperationalContext:
      'Mechanical design and manufacturing workflows involving 3D CAD modeling, FEA simulations, prototyping, and factory floor quality inspection.',
    experienceDeeperLearnings: [
      {
        title: 'Design for Manufacturability (DFM)',
        summary: 'Optimizing CAD geometries to minimize production tooling costs and cycle time.',
        architecture_mechanism: 'Incorporating draft angles, uniform wall thicknesses, and standard tool radii.',
        why_it_matters: 'Reduces scrap rates and accelerates mass production launch.',
        interview_defense: 'Describe a design modification you made to improve manufacturing feasibility.',
        common_pitfalls: 'Designing deep internal corners that cannot be machined with standard end-mills.'
      }
    ],
    projectSystemArchitectureLabel: 'Product Design & FEA Simulation Pipeline',
    projectSystemArchitecture: (_name, _techs) =>
      `Design Requirements -> 3D CAD Modeling (SolidWorks/CATIA) -> FEA Meshing & Boundary Constraints -> Stress/Thermal Simulation -> Prototyping & Testing.`,
    projectDeeperConcepts: (_name, _techs) => [
      {
        title: 'Meshing Quality & FEA Convergence',
        summary: 'Ensuring finite element simulations yield numerically accurate stress results.',
        architecture_mechanism: 'Mesh refinement studies around stress concentrators until stresses converge.',
        why_it_matters: 'Coarse meshing leads to dangerously inaccurate stress predictions.',
        interview_defense: 'How do you verify whether an FEA stress peak is real or a mathematical singularity?',
        common_pitfalls: 'Applying point loads directly to nodes, causing artificial stress singularities.'
      }
    ],
    projectDeeperDefense: (_name, _techs) => [
      {
        title: 'Thermal Management & Heat Dissipation',
        summary: 'Sizing heat sinks and coolant flows to maintain operating temperatures.',
        architecture_mechanism: 'Calculating thermal resistance networks and convective heat transfer coefficients.',
        why_it_matters: 'Prevents thermal runaway and overheating in mechanical systems.',
        interview_defense: 'Walk through how you calculated heat dissipation requirements for your project.',
        common_pitfalls: 'Neglecting thermal contact resistance between mating interfaces.'
      }
    ]
  },

  'Electrical & Electronics': {
    title: 'Electrical & Electronics Engineering',
    educationKeyConceptsTitle: 'Academic Core Concepts & Electrical Engineering Principles',
    educationKeyConcepts: [
      'Circuit Theory & Network Analysis (Kirchhoff\'s Laws, Thevenin / Norton Equivalence)',
      'Semiconductor Physics & Analog Electronics (MOSFETs, Op-Amps, Feedback Circuits)',
      'Digital Systems & VLSI (Verilog / VHDL, Finite State Machines, FPGA Implementation)',
      'Embedded Systems & Microcontrollers (C/C++, Interrupts, Timers, I2C / SPI / UART Protocols)'
    ],
    educationDeeperFoundations: [
      {
        title: 'Signal Integrity & PCB Impedance Matching',
        summary: 'Preventing reflections and cross-talk in high-speed digital traces.',
        architecture_mechanism: 'Calculating characteristic trace impedance (Z0) and terminating lines properly.',
        why_it_matters: 'Prevents bit errors and clock jitter in modern microcontrollers and FPGAs.',
        interview_defense: 'Explain how you design controlled impedance traces on a 4-layer PCB.',
        common_pitfalls: 'Routing high-speed traces over split ground planes, causing major EMI radiation.'
      }
    ],
    experienceImportantTerminology: [
      { term: 'I2C / SPI / UART', definition: 'Standard serial communication protocols used between microcontrollers and sensors.' },
      { term: 'PWM (Pulse Width Modulation)', definition: 'Technique for controlling analog circuits and motors with digital outputs.' },
      { term: 'Decoupling Capacitor', definition: 'Capacitor placed near IC power pins to suppress high-frequency supply noise.' }
    ],
    experienceOperationalContext:
      'Hardware and firmware workflows involving schematic capture, PCB layout, microcontroller firmware programming, and oscilloscope debugging.',
    experienceDeeperLearnings: [
      {
        title: 'Firmware Interrupt Handling & Non-Blocking Loops',
        summary: 'Writing responsive embedded code without freezing the microcontroller in delay loops.',
        architecture_mechanism: 'Utilizing hardware timers, Interrupt Service Routines (ISRs), and ring buffers.',
        why_it_matters: 'Ensures real-time responsiveness and low power consumption.',
        interview_defense: 'Explain why heavy computation or printf statements should never be placed inside an ISR.',
        common_pitfalls: 'Using blocking delay() functions inside communication state machines.'
      }
    ],
    projectSystemArchitectureLabel: 'Hardware & Firmware Architecture',
    projectSystemArchitecture: (_name, _techs) =>
      `Sensor / Input Signals -> Analog Conditioning -> Microcontroller / ADC -> Firmware Processing (State Machine) -> Communication (SPI/I2C/UART) -> Actuators / UI Output.`,
    projectDeeperConcepts: (_name, _techs) => [
      {
        title: 'Power Supply Decoupling & Ground Plane Design',
        summary: 'Minimizing ground bounce and voltage dips during high-speed switching.',
        architecture_mechanism: 'Placing low-ESR ceramic bypass capacitors adjacent to IC power pins connected to continuous ground planes.',
        why_it_matters: 'Prevents random microcontroller brown-outs and spurious resets.',
        interview_defense: 'How did you size and place decoupling capacitors on your circuit board?',
        common_pitfalls: 'Connecting bypass capacitors through long traces rather than directly to power/ground vias.'
      }
    ],
    projectDeeperDefense: (_name, _techs) => [
      {
        title: 'Timing Constraints & Setup/Hold Time',
        summary: 'Ensuring digital logic signals are stable before clock edges arrive.',
        architecture_mechanism: 'Verifying setup time (Tsu) and hold time (Th) across clock domains.',
        why_it_matters: 'Prevents metastability states in digital registers and FPGAs.',
        interview_defense: 'Explain what happens when a signal violates setup time and how two-flop synchronizers fix metastability.',
        common_pitfalls: 'Connecting asynchronous external inputs directly to combinational logic.'
      }
    ]
  },

  'Computer Science & Engineering': {
    title: 'Computer Science & Software Engineering',
    educationKeyConceptsTitle: 'Academic Core Concepts & Complexity Theory',
    educationKeyConcepts: [
      'Data Structures & Algorithms (Big-O time/space complexity analysis)',
      'Object-Oriented Design & Software Engineering Principles (SOLID, Design Patterns)',
      'Database Management Systems & Relational Theory (Normalization, ACID Transactions)',
      'Operating Systems, Concurrency & Networking Foundations (Processes, Threads, TCP/IP)'
    ],
    educationDeeperFoundations: [
      {
        title: 'Theoretical Problem-Solving & Computational Complexity',
        summary: 'Applying algorithmic thinking to optimize software performance.',
        architecture_mechanism: 'Evaluating trade-offs between Time Complexity (O(1), O(log n), O(n), O(n^2)) and Space Complexity (memory footprint).',
        why_it_matters: 'Forms the universal foundation for technical interviews and efficient system design.',
        interview_defense: 'Be ready to analyze the Big-O complexity of any algorithm or query you wrote in your projects.',
        common_pitfalls: 'Writing nested O(n^2) loops over large datasets when O(n) hash lookups could be used.'
      }
    ],
    experienceImportantTerminology: [
      { term: 'CI/CD Pipeline', definition: 'Automated Continuous Integration and Continuous Deployment pipelines for testing and shipping code.' },
      { term: 'Code Review & QA', definition: 'Peer inspection of pull requests to ensure code cleanliness, security, and test coverage.' },
      { term: 'Cross-functional Collaboration', definition: 'Partnering across engineering, design, and product management to ship cohesive features.' },
      { term: 'Deliverable', definition: 'A tested, documented software module or service submitted against project requirements.' }
    ],
    experienceOperationalContext:
      'Work conducted within an engineering lifecycle involving requirement gathering, sprint planning, feature branching, pull requests, automated testing, and release cycles.',
    experienceDeeperLearnings: [
      {
        title: 'Engineering Process & Delivery Hygiene',
        summary: 'How code moves from local development to production.',
        architecture_mechanism: 'Feature branching (Git flow), unit testing, code reviews, automated CI verification, and staging environments.',
        why_it_matters: 'Proves you can integrate seamlessly into professional software engineering teams without breaking main branches.',
        interview_defense: 'Describe your day-to-day workflow: how you received tasks, wrote tests, created pull requests, and handled feedback.',
        common_pitfalls: 'Describing tasks purely as isolated code changes without acknowledging team collaboration and review processes.'
      },
      {
        title: 'Quantifying Business & Technical Impact',
        summary: 'Connecting engineering effort to organizational outcomes.',
        architecture_mechanism: 'Translating code changes into metrics: latency reduction, user efficiency gains, bug count reduction, or time saved.',
        why_it_matters: 'Companies hire engineers who create measurable value, not just write lines of code.',
        interview_defense: 'Articulate the "before and after" of your contributions—what was improved by your work?',
        common_pitfalls: 'Stating "I built a feature" without explaining what problem it solved or who used it.'
      }
    ],
    projectSystemArchitectureLabel: 'System Architecture & Data Flow',
    projectSystemArchitecture: (_name, techs) =>
      `Client UI / Frontend Layer -> REST API / Backend Services (${techs.slice(0, 2).join(', ') || 'Node/Python'}) -> Data Persistence / Storage Layer -> External APIs.`,
    projectDeeperConcepts: (name, _techs) => [
      {
        title: 'System Architecture & Data Flow',
        summary: 'End-to-end flow of data from user interaction to storage.',
        architecture_mechanism: `Components in '${name}' communicate via structured interfaces (REST / HTTP). Inputs are validated, processed through business logic, and persisted.`,
        why_it_matters: 'Interviewers evaluate your mental model of how components connect and manage state.',
        interview_defense: `Trace the journey of a single user request through '${name}' from frontend UI to database write and response.`,
        common_pitfalls: 'Failing to separate UI concerns from business and data access layers.'
      },
      {
        title: 'Error Handling, Failure Modes & Edge Cases',
        summary: 'How the application behaves when external services fail or bad inputs arrive.',
        architecture_mechanism: 'Defensive validation, structured try/catch blocks, error logging, and user-friendly fallback responses.',
        why_it_matters: 'Demonstrates engineering maturity beyond happy-path tutorials.',
        interview_defense: `Explain what happens in '${name}' when the database is unreachable or a user submits invalid data.`,
        common_pitfalls: 'Assuming network requests will always succeed with zero latency.'
      }
    ],
    projectDeeperDefense: (_name, techs) => [
      {
        title: 'Tool Selection & Architectural Trade-offs',
        summary: 'Defending why you chose these technologies vs alternatives.',
        architecture_mechanism: `Evaluated performance, library maturity, developer productivity, and ecosystem support for ${techs[0] || 'the core tool'}.`,
        why_it_matters: 'Shows you choose tools based on engineering requirements rather than random hype.',
        interview_defense: `Explain why ${techs[0] || 'your core tool'} was the right choice for this problem compared to alternatives.`,
        common_pitfalls: 'Saying "I used it because it was the only one I knew".'
      },
      {
        title: 'Scaling to 10x / 100x Traffic',
        summary: 'How to evolve this project for production-scale loads.',
        architecture_mechanism: 'Implementing caching (Redis), database indexing, asynchronous queues, and horizontal auto-scaling.',
        why_it_matters: 'Directly tests system design and capacity planning capabilities.',
        interview_defense: 'Identify the first bottleneck in your current architecture and outline how you would cache or decouple it.',
        common_pitfalls: 'Suggesting complex distributed microservices before optimizing database queries and caching.'
      }
    ]
  },

  'General Professional': {
    title: 'Professional Disciplines & Practice',
    educationKeyConceptsTitle: 'Academic Core Concepts & Foundational Principles',
    educationKeyConcepts: [
      'Critical Analytical Thinking & Problem Deconstruction',
      'Research Methodology, Data Verification & Evidence Synthesis',
      'Professional Communication, Ethics & Stakeholder Reporting',
      'Project Planning, Execution Discipline & Time Management'
    ],
    educationDeeperFoundations: [
      {
        title: 'Critical Thinking & Analytical Problem Solving',
        summary: 'Systematically breaking down complex, unstructured problems.',
        architecture_mechanism: 'Defining the core problem, gathering verified empirical data, evaluating alternatives, and testing solutions.',
        why_it_matters: 'Forms the core capability sought by all employers across disciplines.',
        interview_defense: 'Describe how you approached an ambiguous challenge with limited initial guidance.',
        common_pitfalls: 'Jumping to premature conclusions without verifying underlying assumptions.'
      }
    ],
    experienceImportantTerminology: [
      { term: 'Stakeholder Management', definition: 'Engaging, communicating with, and aligning key individuals affected by project outcomes.' },
      { term: 'Deliverable', definition: 'A verified, tangible result, report, or output produced against defined requirements.' },
      { term: 'Key Performance Indicator (KPI)', definition: 'A quantifiable metric tracking progress toward vital organizational goals.' }
    ],
    experienceOperationalContext:
      'Professional workflows involving project planning, collaborative team delivery, documentation, stakeholder reporting, and deadline execution.',
    experienceDeeperLearnings: [
      {
        title: 'Accountability & Milestone Execution',
        summary: 'Delivering results under real-world time and resource constraints.',
        architecture_mechanism: 'Prioritization frameworks, risk identification, and proactive stakeholder updates.',
        why_it_matters: 'Proves high reliability and execution discipline.',
        interview_defense: 'Walk through how you managed competing priorities to deliver an important assignment on schedule.',
        common_pitfalls: 'Waiting until the deadline has passed before notifying stakeholders of delays.'
      }
    ],
    projectSystemArchitectureLabel: 'Project Execution Workflow',
    projectSystemArchitecture: (_name, _techs) =>
      `Objective Definition & Research -> Planning & Methodology Formulation -> Execution & Data Gathering -> Synthesis & Quality Review -> Stakeholder Delivery.`,
    projectDeeperConcepts: (name, _techs) => [
      {
        title: 'Problem Framing & Execution Rigor',
        summary: 'Translating high-level goals into concrete, actionable milestones.',
        architecture_mechanism: 'Structuring workflow phases, managing deliverables, and validating output accuracy.',
        why_it_matters: 'Shows capacity to manage initiatives independently.',
        interview_defense: `Explain the origin and execution steps of '${name}'.`,
        common_pitfalls: 'Starting execution before defining clear evaluation criteria.'
      }
    ],
    projectDeeperDefense: (name, _techs) => [
      {
        title: 'Continuous Improvement & Retrospectives',
        summary: 'Evaluating outcomes and implementing lessons learned.',
        architecture_mechanism: 'Structured post-project review isolating successes and improvement areas.',
        why_it_matters: 'Demonstrates a growth mindset and commitment to professional excellence.',
        interview_defense: `What would you do differently if you were to repeat '${name}' today?`,
        common_pitfalls: 'Claiming a project was 100% flawless with zero lessons learned.'
      }
    ]
  }
};

// ============================================================================
// DYNAMIC LINE-BY-LINE BREAKDOWN GENERATOR
// ============================================================================

/**
 * Generates an insightful, plain-English explanation, demonstrable competency,
 * and interview defense for ANY individual line on the resume.
 */
export function generateLineBreakdown(
  rawLine: string,
  sectionType: 'summary' | 'experience' | 'project' | 'education' | 'certification' | 'achievement',
  domain: string,
  label?: string
): ResumeLearningLineBreakdown {
  const cleanLine = rawLine.replace(/^[•\-\*\d\.\s]+/, '').trim();

  if (!cleanLine) {
    return {
      raw_line: rawLine,
      line_label: label || 'Entry',
      brief_explanation: 'Standard professional resume entry.',
      what_it_demonstrates: 'Professional Documentation',
      interview_angle: 'Can you provide more detail on this item?',
      key_talking_point: 'I can explain the background and execution of this point in detail.'
    };
  }

  // --- 1. SUMMARY SECTION LINES ---
  if (sectionType === 'summary') {
    let demonstrates = 'Professional Identity & Value';
    let angle = 'How would you summarize your core value proposition?';
    let defense = `This line establishes my background in ${domain} and summarizes the strengths I bring to this position.`;
    let expl = `Concise statement framing your core specialization and career focus in ${domain}.`;

    if (/years|experience|background|proven track/i.test(cleanLine)) {
      demonstrates = 'Seniority & Track Record';
      angle = 'Walk me through the progression of your experience in this field.';
      defense = `I frame my career around hands-on execution and progressive responsibility in ${domain}.`;
      expl = 'Communicates your breadth of experience and establishes your domain credibility with hiring teams.';
    } else if (/skills?|expert|proficient|knowledgeable|specializ/i.test(cleanLine)) {
      demonstrates = 'Core Domain Competency';
      angle = 'Which of these core competencies do you consider your primary superpower?';
      defense = `My primary strength lies in applying these core domain competencies to deliver accurate, compliant, and impactful results.`;
      expl = 'Pinpoints the specific tools, subject areas, and operational strengths you lead with.';
    }

    return {
      raw_line: cleanLine,
      line_label: label || 'Summary Statement',
      brief_explanation: expl,
      what_it_demonstrates: demonstrates,
      interview_angle: angle,
      key_talking_point: defense
    };
  }

  // --- 2. EXPERIENCE SECTION BULLETS ---
  if (sectionType === 'experience') {
    let demonstrates = 'Execution Rigor & Professional Impact';
    let angle = 'Can you describe your day-to-day workflow and role in this responsibility?';
    let defense = `In this role, I focused on executing this responsibility with high accuracy and measurable impact for the team.`;
    let expl = `Describes your direct operational contribution and standard practices within ${domain}.`;

    if (/draft|research|brief|scc|manupatra|petition|court|advocat|legal|compliance|audit|due diligence/i.test(cleanLine)) {
      demonstrates = 'Legal Analysis & Statutory Diligence';
      angle = 'Walk me through your research and drafting methodology for this matter.';
      defense = `I verified primary statutory authorities and bench precedents to ensure the draft was legally sound and protected client interests.`;
      expl = 'Demonstrates rigorous case preparation, statutory research, and attention to legal precision.';
    } else if (/\b(\d+%|\$\d+|₹\d+|\d+x|reduced|increased|improved|saved|optimized)\b/i.test(cleanLine)) {
      demonstrates = 'Quantified Business Outcome';
      angle = 'How did you measure these specific metrics and what was your individual contribution?';
      defense = `I tracked the baseline metrics and applied targeted optimizations to achieve this measurable improvement.`;
      expl = 'Provides empirical evidence of your ability to create tangible value and efficiency.';
    } else if (/collaborat|led|coordinated|managed|trained|mentored|liaised/i.test(cleanLine)) {
      demonstrates = 'Leadership & Stakeholder Coordination';
      angle = 'How did you handle differing stakeholder viewpoints or deadlines during this work?';
      defense = `I kept stakeholders aligned through transparent communication and structured progress check-ins.`;
      expl = 'Demonstrates interpersonal leadership, teamwork, and cross-functional coordination.';
    } else if (/built|developed|implemented|designed|architected|engineered/i.test(cleanLine)) {
      demonstrates = 'Technical Execution & Problem Solving';
      angle = 'What technical trade-offs or hurdles did you navigate while delivering this?';
      defense = `I evaluated alternative approaches and implemented this solution with a focus on maintainability and reliability.`;
      expl = 'Shows hands-on problem-solving and implementation competence.';
    }

    return {
      raw_line: cleanLine,
      line_label: label || 'Experience Bullet',
      brief_explanation: expl,
      what_it_demonstrates: demonstrates,
      interview_angle: angle,
      key_talking_point: defense
    };
  }

  // --- 3. PROJECT SECTION BULLETS ---
  if (sectionType === 'project') {
    let demonstrates = 'Practical Domain Application';
    let angle = 'What inspired this project and what was the main technical or analytical hurdle?';
    let defense = `I developed this to solve a concrete problem in ${domain}, structuring the workflow to ensure correctness and modularity.`;
    let expl = `Highlights a functional deliverable or milestone demonstrating applied competence in ${domain}.`;

    if (/legal|moot|court|draft|statut|precedent|brief/i.test(cleanLine)) {
      demonstrates = 'Jurisprudential & Advocacy Rigor';
      angle = 'How did you frame the arguments and respond to conflicting case law?';
      defense = `I grounded my arguments in binding statutory text and distinguished unfavorable rulings on their factual matrix.`;
      expl = 'Validates your legal reasoning, case preparation, and ability to formulate persuasive propositions.';
    } else if (/model|dcf|valuation|financial|balance|p&l/i.test(cleanLine)) {
      demonstrates = 'Financial Modeling & Valuation Depth';
      angle = 'What assumptions drove your model and how did you stress-test them?';
      defense = `I built sensitivity tables around cost of capital and growth rates to establish a realistic valuation range.`;
      expl = 'Demonstrates quantitative rigor, financial analysis, and scenario modeling.';
    }

    return {
      raw_line: cleanLine,
      line_label: label || 'Project Milestone',
      brief_explanation: expl,
      what_it_demonstrates: demonstrates,
      interview_angle: angle,
      key_talking_point: defense
    };
  }

  // --- 4. EDUCATION SECTION LINES ---
  if (sectionType === 'education') {
    return {
      raw_line: cleanLine,
      line_label: label || 'Academic Credential',
      brief_explanation: `Academic milestone validating accredited coursework and foundational mastery in ${domain}.`,
      what_it_demonstrates: 'Academic Foundations & Theoretical Depth',
      interview_angle: 'How has this academic training prepared you for professional practice in your field?',
      key_talking_point: `My academic coursework gave me the core analytical principles and theoretical frameworks that I now apply to practical client and industry challenges.`
    };
  }

  // --- 5. CERTIFICATION & ACHIEVEMENTS ---
  return {
    raw_line: cleanLine,
    line_label: label || 'Resume Entry',
    brief_explanation: `Validated credential or achievement supporting your professional profile in ${domain}.`,
    what_it_demonstrates: 'Verified Competence & Continuous Learning',
    interview_angle: 'Can you share an example of applying the knowledge gained from this entry?',
    key_talking_point: `This validates formal training and practical understanding that reinforces my execution capability in ${domain}.`
  };
}

// ============================================================================
// DYNAMIC SKILL GENERATOR
// ============================================================================

function generateDynamicDeepSkill(skillName: string, domain: string): SkillKBEntry {
  const cleanName = skillName.trim();
  const isLaw = domain.toLowerCase().includes('law') || domain.toLowerCase().includes('legal');
  const isFinance = domain.toLowerCase().includes('finance') || domain.toLowerCase().includes('commerce');

  if (isLaw) {
    return {
      what_it_is: `A specialized legal competency and practice area in ${domain}.`,
      what_it_is_used_for: `Applied in courtroom advocacy, corporate compliance, drafting agreements, due diligence, and statutory analysis.`,
      what_it_means_on_resume: `Listing '${cleanName}' indicates you are familiar with the governing statutory framework, bench precedents, and legal documentation standards.`,
      what_you_should_know: [
        `Governing legislative acts and statutory provisions related to ${cleanName}`,
        `Landmark Supreme Court and High Court precedents shaping ${cleanName}`,
        `Standard procedural filings, drafting conventions, and client advisory workflows`,
        `Risk mitigation, regulatory compliance obligations, and dispute resolution options`
      ],
      how_to_explain_it: `I have practical experience with ${cleanName} from my academic coursework and legal internships, where I researched case authorities and drafted relevant pleadings or clauses.`,
      beginner: `${cleanName} is a recognized legal competency listed on your resume demonstrating specialized domain capability in ${domain}.`,
      deeper: `${cleanName} requires synthesizing primary statutes, navigating regulatory notifications, and applying precedent ratio decidendi to client fact scenarios.`,
      architecture_breakdown: `Statutory Review -> Precedent Bench Analysis -> Draft Pleading / Advisory Formulation -> Quality & Compliance Check.`,
      deeper_topics: [
        {
          title: `Statutory Foundations of ${cleanName}`,
          summary: `Core legislative provisions and regulatory oversight.`,
          architecture_mechanism: `How statutory sections define duties, limitations, and liabilities for ${cleanName}.`,
          why_it_matters: 'Forms the baseline requirement for legal advisory and dispute resolution.',
          interview_defense: `Discuss the essential statutory requirements governing ${cleanName}.`,
          common_pitfalls: 'Overlooking recent legislative amendments or notifications.'
        }
      ],
      trade_offs_and_pitfalls: [
        'Trade-off: Comprehensive legal risk protection vs commercial transaction speed.',
        'Pitfall: Failing to identify conflicting High Court precedents without checking appellate status.'
      ]
    };
  }

  if (isFinance) {
    return {
      what_it_is: `A key financial and accounting capability in ${domain}.`,
      what_it_is_used_for: `Applied in financial statement reporting, auditing, ledger reconciliation, variance modeling, and tax compliance.`,
      what_it_means_on_resume: `Listing '${cleanName}' indicates you understand underlying accounting principles, financial ratios, and regulatory compliance requirements.`,
      what_you_should_know: [
        `Core accounting standards (GAAP/IFRS) governing ${cleanName}`,
        `Reconciliation, voucher verification, and variance analysis procedures`,
        `Standard tools and software (Tally, Advanced Excel, ERPs) paired with ${cleanName}`,
        `Audit trail preservation, tax compliance, and financial reporting accuracy`
      ],
      how_to_explain_it: `I have hands-on experience applying ${cleanName} to prepare accurate financial reports, reconcile ledgers, and analyze performance metrics.`,
      beginner: `${cleanName} is a recognized financial skill on your resume showing technical competence in financial management and reporting.`,
      deeper: `${cleanName} involves assessing underlying cash flows, ensuring compliance with statutory disclosure standards, and evaluating internal financial controls.`,
      architecture_breakdown: `Transaction Ingestion -> Reconciliation -> Ratio & Variance Analysis -> Compliance & Management Reporting.`,
      deeper_topics: [
        {
          title: `Financial Standards & Controls for ${cleanName}`,
          summary: `Regulatory compliance and error prevention frameworks.`,
          architecture_mechanism: `Applying double-entry integrity, segregation of duties, and reconciliation controls.`,
          why_it_matters: 'Ensures statements present a true and fair view free from material discrepancies.',
          interview_defense: `Explain how you verify the accuracy of calculations involving ${cleanName}.`,
          common_pitfalls: 'Failing to reconcile timing differences between ledgers and bank statements.'
        }
      ],
      trade_offs_and_pitfalls: [
        'Trade-off: Fast automated summary reporting vs detailed voucher-level reconciliation.',
        'Pitfall: Misinterpreting accounting standards across different fiscal periods.'
      ]
    };
  }

  // General / Engineering fallback
  return {
    what_it_is: `A core technical skill and tool applied within ${domain}.`,
    what_it_is_used_for: `Applied in professional workflows to design, build, automate, or optimize deliverables in ${domain}.`,
    what_it_means_on_resume: `Claiming '${cleanName}' signals that you understand its core paradigms, practical APIs/syntax, and how to integrate it into real-world project solutions.`,
    what_you_should_know: [
      `Core syntax, conventions, and foundational lifecycle patterns of ${cleanName}`,
      `How ${cleanName} manages data flow, state, or execution resources`,
      `Standard integration patterns, testing strategies, and common companion libraries`,
      `Performance bottlenecks, edge cases, and debugging methodologies for ${cleanName}`
    ],
    how_to_explain_it: `I have hands-on practical experience with ${cleanName}. I understand its core architecture, where it fits in the workflow, and how to troubleshoot and optimize it.`,
    beginner: `${cleanName} is a recognized skill on your resume demonstrating technical competency in ${domain}.`,
    deeper: `${cleanName} operates under specific operational paradigms. Mastering it requires understanding its resource management, integration boundaries, and how it handles edge-case failure modes in production.`,
    architecture_breakdown: `${cleanName} processes inputs through structured execution pipelines, interacting with system memory, I/O protocols, and external dependencies.`,
    deeper_topics: [
      {
        title: `Core Principles of ${cleanName}`,
        summary: `Fundamental execution and design paradigms governing ${cleanName}.`,
        architecture_mechanism: `How ${cleanName} coordinates internal state, handles operations, and interfaces with surrounding workflows.`,
        why_it_matters: `Ensures that implementations built with ${cleanName} are modular, maintainable, and aligned with standard industry practices.`,
        interview_defense: `Explain the end-to-end workflow in ${cleanName} and describe how you structured components in your project.`,
        common_pitfalls: `Misconfiguring baseline parameters or failing to follow standard lifecycle conventions.`
      }
    ],
    trade_offs_and_pitfalls: [
      `Trade-off: Fast implementation speed vs resource overhead or specialized configuration requirements.`,
      `Pitfall: Using ${cleanName} for use cases where simpler, lightweight alternatives would reduce complexity.`
    ]
  };
}

// ============================================================================
// MAIN GENERATOR: BUILD CLIENT RESUME LEARNING GUIDE
// ============================================================================

export function buildClientResumeLearningGuide(
  structuredResume: StructuredResume | null,
  analysis: ResumeAnalysisResult | null
): ResumeLearningGuideResponse {
  const candidateName =
    structuredResume?.personal_info?.full_name ||
    analysis?.filename?.replace(/\.[^/.]+$/, '') ||
    'Candidate';

  // 1. Accurately detect domain without blindly defaulting to tech
  const domainClassification = detectResumeDomain(structuredResume, analysis);
  const profile = DOMAIN_PROFILES[domainClassification] || DOMAIN_PROFILES['General Professional'];
  const domainTitle = profile.title;

  // 2. Summary Section
  const summaryText = (
    structuredResume?.summary ||
    structuredResume?.personal_info?.summary ||
    (analysis?.strengths && analysis.strengths.length > 0 ? analysis.strengths.join(' ') : '')
  ).trim();

  let summarySection: ResumeLearningSummarySection | null = null;
  if (summaryText) {
    // Generate line-by-line breakdown of summary sentences
    const summarySentences = summaryText
      .split(/(?<=[.!?])\s+/)
      .map(s => s.trim())
      .filter(s => s.length > 10);

    const summaryLineBreakdown: ResumeLearningLineBreakdown[] = summarySentences.map((sent, idx) =>
      generateLineBreakdown(sent, 'summary', domainTitle, `Sentence ${idx + 1}`)
    );

    summarySection = {
      what_you_wrote: summaryText,
      understand_it: `Your summary introduces you as a candidate in ${domainTitle}. It provides the high-level positioning and core strengths stated in your resume.`,
      key_things_to_know: [
        `Domain Positioning: Frames your profile around ${domainTitle} to establish immediate professional credibility`,
        'Core Value Proposition: Highlights your primary execution capabilities, methodology, and career direction',
        'Professional Narrative: Anchors interviewer expectations before they inspect specific project and experience details'
      ],
      why_it_matters: 'The summary is often the first 6-second hook scanned by screeners to confirm your discipline alignment and career trajectory.',
      what_you_should_explain: `Deliver a concise 30-second elevator pitch that covers your focus in ${domainTitle}, top skills, and what kind of problems you enjoy solving.`,
      beginner_explanation: `Your summary is your personal 2-sentence teaser explaining who you are and what you deliver in ${domainTitle}.`,
      deeper_explanation: `A high-impact summary establishes domain alignment, signals key competencies, and anchors professional expectations before deep-diving into individual accomplishments.`,
      deeper_positioning_topics: [
        {
          title: 'Executive Alignment & First-Pass Screening',
          summary: 'How recruiters and hiring leads parse your professional summary.',
          architecture_mechanism: 'Screeners look for 3 core pillars: primary domain/practice area, depth of practical experience, and unique focus areas.',
          why_it_matters: 'Sets the context and difficulty level of questions in subsequent interview stages.',
          interview_defense: 'Be ready to articulate your professional journey smoothly without reading off the resume bullet-by-bullet.',
          common_pitfalls: 'Using generic clichés like "hardworking team player" instead of concrete domain competencies.'
        },
        {
          title: 'Elevator Pitch Formula',
          summary: 'Structuring a 30-to-60 second spoken overview.',
          architecture_mechanism: 'Formula: [Who you are] + [Your core domain focus] + [What high-impact work you have executed] + [What challenges you want to take on next].',
          why_it_matters: 'Answers the opening interview question "Tell me about yourself" with confidence and authority.',
          interview_defense: 'Deliver a crisp, practiced answer that transitions naturally into your best project or experience.',
          common_pitfalls: 'Reciting entire resume chronology rather than focusing on core strengths and passions.'
        }
      ],
      line_by_line_breakdown: summaryLineBreakdown
    };
  }

  // 3. Skills Section
  const rawSkills: string[] =
    (structuredResume?.skills && structuredResume.skills.length > 0)
      ? structuredResume.skills
      : (analysis?.extracted_skills && analysis.extracted_skills.length > 0)
        ? analysis.extracted_skills
        : ['Analytical Thinking', 'Problem Solving', 'Communication', 'Research'];

  const skills: ResumeLearningSkillItem[] = rawSkills.map((sk) => {
    const norm = sk.toLowerCase().trim();
    let kb = CLIENT_SKILL_KB[norm];

    if (!kb) {
      // Check partial matches in static KB
      const match = Object.keys(CLIENT_SKILL_KB).find(k => norm.includes(k) || k.includes(norm));
      if (match) {
        kb = CLIENT_SKILL_KB[match];
      }
    }

    if (!kb) {
      kb = generateDynamicDeepSkill(sk, domainTitle);
    }

    const skillLineBreakdown: ResumeLearningLineBreakdown = {
      raw_line: sk,
      line_label: `Skill: ${sk}`,
      brief_explanation: kb.what_it_is,
      what_it_demonstrates: `Verified competence in ${sk}`,
      interview_angle: `How have you practically applied ${sk} in your past work or projects?`,
      key_talking_point: kb.how_to_explain_it
    };

    return {
      skill_name: sk,
      what_it_is: kb.what_it_is,
      what_it_is_used_for: kb.what_it_is_used_for,
      what_it_means_on_resume: kb.what_it_means_on_resume,
      what_you_should_know: kb.what_you_should_know,
      how_to_explain_it: kb.how_to_explain_it,
      beginner_explanation: kb.beginner,
      deeper_explanation: kb.deeper,
      architecture_breakdown: kb.architecture_breakdown,
      deeper_topics: kb.deeper_topics,
      trade_offs_and_pitfalls: kb.trade_offs_and_pitfalls,
      line_by_line_breakdown: [skillLineBreakdown]
    };
  });

  // 4. Projects Section
  const rawProjects: any[] =
    (structuredResume?.projects && structuredResume.projects.length > 0)
      ? structuredResume.projects
      : (analysis?.extracted_projects || []);

  const projects: ResumeLearningProjectItem[] = rawProjects.map((prj) => {
    const title = prj.title || 'Project';
    const bullets: string[] = prj.bullets || [];
    const rawDesc = prj.description || '';
    const whatYouWrote = bullets.length > 0
      ? bullets.map((b: string) => `• ${b}`).join('\n')
      : (rawDesc || 'Project details listed on resume.');

    const techs: string[] = prj.technologies || prj.key_technologies || [];
    const primaryTech = techs.length > 0 ? techs.join(', ') : `${domainTitle} principles`;

    // Line-by-line breakdown for every project line/bullet
    const projectLines = bullets.length > 0
      ? bullets
      : rawDesc.split(/(?<=[.!?])\s+/).filter((s: string) => s.trim().length > 10);

    const projectLineBreakdown: ResumeLearningLineBreakdown[] = projectLines.map((line: string, idx: number) =>
      generateLineBreakdown(line, 'project', domainTitle, `Milestone ${idx + 1}`)
    );

    return {
      project_name: title,
      what_you_wrote: whatYouWrote,
      project_explanation: `This project represents practical work where you applied ${primaryTech} to solve a concrete problem.`,
      technologies_mentioned: techs,
      concepts_to_understand: [
        'The primary problem this project addresses and why it matters',
        `The workflow methodology applied across ${primaryTech}`,
        'How outcomes or data were validated and cross-checked',
        'Key hurdles encountered during execution and how you resolved them'
      ],
      your_contribution: `Based on your resume, your contribution was executing the responsibilities and deliverables described in '${title}'.`,
      what_you_should_know: [
        'Why you selected this specific methodology or tools over alternatives',
        'How you verified the accuracy and quality of the final deliverable',
        'What constraints or trade-offs existed during execution',
        'How you would expand or optimize it with additional time or resources'
      ],
      beginner_explanation: `'${title}' is a project demonstrating your hands-on ability to deliver results using ${primaryTech}.`,
      deeper_explanation: `In interviews, '${title}' will be evaluated on methodology choices, modularity, quality control, problem-solving under constraints, and measurable impact.`,
      system_architecture: profile.projectSystemArchitecture(title, techs),
      deeper_concepts: profile.projectDeeperConcepts(title, techs),
      deeper_defense_points: profile.projectDeeperDefense(title, techs),
      trade_offs_and_pitfalls: [
        'Trade-off: Fast execution speed vs exhaustive edge-case verification or additional optimization.',
        'Pitfall: Being unable to substantiate individual contribution versus group partner input.'
      ],
      line_by_line_breakdown: projectLineBreakdown
    };
  });

  // 5. Experience & Internships Section
  const rawExp: any[] =
    (structuredResume?.experience && structuredResume.experience.length > 0)
      ? structuredResume.experience
      : (analysis?.extracted_experience || []);

  const experience: ResumeLearningExperienceItem[] = [];
  const internships: ResumeLearningExperienceItem[] = [];

  rawExp.forEach((exp) => {
    const role = exp.role || 'Role';
    const comp = exp.company || exp.company_or_org || 'Organization';
    const duration = exp.duration || null;
    const bullets: string[] = exp.bullets || exp.highlights || [];
    const whatYouWrote = bullets.length > 0
      ? bullets.map((b: string) => `• ${b}`).join('\n')
      : (exp.description || 'Experience listed on resume.');

    const isIntern =
      role.toLowerCase().includes('intern') ||
      comp.toLowerCase().includes('intern') ||
      role.toLowerCase().includes('trainee');

    // Extract demonstrated skills matching text
    const demoSkills: string[] = [];
    rawSkills.forEach(sk => {
      if (whatYouWrote.toLowerCase().includes(sk.toLowerCase())) {
        demoSkills.push(sk);
      }
    });

    // Line-by-line breakdown for every experience bullet
    const expLines = bullets.length > 0
      ? bullets
      : exp.description ? exp.description.split(/(?<=[.!?])\s+/).filter((s: string) => s.trim().length > 10) : [];

    const expLineBreakdown: ResumeLearningLineBreakdown[] = expLines.map((line: string, idx: number) =>
      generateLineBreakdown(line, 'experience', domainTitle, `Bullet ${idx + 1}`)
    );

    const item: ResumeLearningExperienceItem = {
      role,
      company: comp,
      dates: duration,
      description: whatYouWrote,
      is_internship: isIntern,
      what_you_claimed: `You claimed responsibilities and milestones as ${role} at ${comp}.`,
      skills_demonstrated: demoSkills.length > 0 ? demoSkills : ['Professional Delivery', 'Collaboration', 'Problem Solving'],
      important_terminology: profile.experienceImportantTerminology,
      what_you_should_understand: [
        `Your exact individual responsibilities vs the broader team scope at ${comp}`,
        'The business objective and context behind your assignments',
        'How the quality and impact of your work were measured',
        'How you resolved roadblocks, managed deadlines, and collaborated with teammates/mentors'
      ],
      beginner_explanation: `This entry highlights your professional responsibilities, contributions, and milestones at ${comp}.`,
      deeper_explanation: `Interviewers inspect this role to evaluate your operational reliability, professional rigor, collaborative communication, and ability to execute under real-world constraints.`,
      operational_context: profile.experienceOperationalContext,
      deeper_learnings: profile.experienceDeeperLearnings,
      line_by_line_breakdown: expLineBreakdown
    };

    if (isIntern) {
      internships.push(item);
    } else {
      experience.push(item);
    }
  });

  // 6. Education Section
  const rawEdu = structuredResume?.education || [];
  const education: ResumeLearningEducationItem[] = rawEdu.map((edu) => {
    const degree = edu.degree ? `${edu.degree}${edu.field_of_study ? ` in ${edu.field_of_study}` : ''}` : 'Academic Degree';
    const inst = edu.institution || 'University';

    // Clean duplicate CGPA / Grade prefixes (e.g. prevent "CGPA: CGPA: 8.4")
    const rawGrade = edu.grade_or_cgpa || '';
    const cleanGrade = rawGrade.replace(/^(?:cgpa|grade|score|percentage)[:\s-]*/i, '').trim();
    const datesOrGrade = cleanGrade
      ? (cleanGrade.toLowerCase().includes('cgpa') ? cleanGrade : `CGPA: ${cleanGrade}`)
      : (edu.end_year ? `Year: ${edu.end_year}` : ((edu as any).duration || null));

    const coursework = edu.coursework || [];
    const achievements = edu.academic_achievements || [];

    // Line-by-line breakdown for every single line of this education entry
    const eduLineBreakdown: ResumeLearningLineBreakdown[] = [
      {
        raw_line: degree,
        line_label: 'Degree & Program',
        brief_explanation: `Validates formal completion of your accredited academic curriculum in ${degree}.`,
        what_it_demonstrates: 'Accredited Degree Qualification',
        interview_angle: `How did your coursework in ${degree} prepare you for practical work in your field?`,
        key_talking_point: `My degree provided comprehensive training in foundational theory and analytical methodology, which I now apply to practical industry challenges.`
      },
      {
        raw_line: inst,
        line_label: 'Institution / University',
        brief_explanation: `Academic training from ${inst}, demonstrating structured academic rigor and peer collaboration.`,
        what_it_demonstrates: 'Institutional Rigor & Credibility',
        interview_angle: `What key projects, seminars, or competitions at ${inst} shaped your perspective?`,
        key_talking_point: `At ${inst}, I participated in demanding coursework, collaborative research, and academic evaluations that sharpened my critical problem-solving.`
      }
    ];

    if (cleanGrade) {
      eduLineBreakdown.push({
        raw_line: datesOrGrade || cleanGrade,
        line_label: 'Academic Standing / Grade',
        brief_explanation: `Achieved academic standing of ${cleanGrade}, reflecting consistent academic discipline and performance.`,
        what_it_demonstrates: 'Academic Consistency & Work Ethic',
        interview_angle: 'Which subjects or modules contributed most to your academic performance?',
        key_talking_point: `I maintained strong discipline across core foundational subjects, ensuring high standards in exams and assignments.`
      });
    }

    if (coursework.length > 0) {
      coursework.forEach((c: string, idx: number) => {
        eduLineBreakdown.push({
          raw_line: c,
          line_label: `Coursework ${idx + 1}`,
          brief_explanation: `Formal academic course in ${c} covering theoretical principles and standard frameworks.`,
          what_it_demonstrates: 'Subject-Matter Competence',
          interview_angle: `Can you discuss a key concept or case study you analyzed in ${c}?`,
          key_talking_point: `In ${c}, I learned the core theories and analytical frameworks, which gave me the foundation to handle real-world challenges.`
        });
      });
    }

    if (achievements.length > 0) {
      achievements.forEach((ach: string, idx: number) => {
        eduLineBreakdown.push({
          raw_line: ach,
          line_label: `Academic Award ${idx + 1}`,
          brief_explanation: `Recognized for exceptional academic performance: ${ach}.`,
          what_it_demonstrates: 'Academic Excellence & Merit',
          interview_angle: 'What specific effort or milestone led to this academic recognition?',
          key_talking_point: `This award recognized my dedication and performance in competitive academic benchmarks.`
        });
      });
    }

    return {
      degree,
      institution: inst,
      dates_or_grade: datesOrGrade,
      relevant_coursework: coursework,
      academic_achievements: achievements,
      what_it_demonstrates: `Provides the foundational academic credentials and theoretical knowledge supporting your career in ${edu.field_of_study || domainTitle}.`,
      key_concepts: profile.educationKeyConcepts,
      key_concepts_title: profile.educationKeyConceptsTitle,
      deeper_foundations: profile.educationDeeperFoundations,
      line_by_line_breakdown: eduLineBreakdown
    };
  });

  // 7. Certifications Section
  const rawCerts = structuredResume?.certifications || [];
  const certifications: ResumeLearningCertificationItem[] = rawCerts.map((c) => {
    const certName = c.name || 'Certification';
    const certLineBreakdown: ResumeLearningLineBreakdown = {
      raw_line: certName + (c.issuer ? ` (Issued by: ${c.issuer})` : ''),
      line_label: 'Credential',
      brief_explanation: `Formal certification validating standardized competence in ${certName}.`,
      what_it_demonstrates: 'Verified Competence & Continuous Learning',
      interview_angle: `What practical skills from ${certName} do you use in your daily workflow?`,
      key_talking_point: `Pursuing ${certName} allowed me to master standardized industry best practices and apply them directly to my projects.`
    };

    return {
      name: certName,
      issuer: c.issuer || null,
      what_it_represents: `A formal credential validating standardized knowledge in '${certName}'.`,
      knowledge_covered: [
        `Foundational principles and standard frameworks covered in the ${certName} syllabus`,
        'Industry best practices and standard workflows tested by the certifying body',
        'Operational and ethical guidelines endorsed by the credentialing authority'
      ],
      important_concepts: [
        'Core terminology and standardized service definitions',
        'Practical implementation patterns emphasized in certification exams'
      ],
      what_you_should_understand: `Be ready to explain why you pursued '${certName}', what key concepts you mastered, and give concrete examples of applying them.`,
      deeper_standards: [
        {
          title: `Standardized Competencies in ${certName}`,
          summary: 'Professional capabilities verified by this credential.',
          architecture_mechanism: 'Structured verification of core industry methodologies and operational standards.',
          why_it_matters: 'Provides objective proof of competence that passes screening filters.',
          interview_defense: `Connect the knowledge from '${certName}' to a concrete project or matter on your resume.`,
          common_pitfalls: 'Treating the certification as a paper credential without being able to discuss the underlying concepts.'
        }
      ],
      line_by_line_breakdown: [certLineBreakdown]
    };
  });

  // 8. Achievements Section
  const rawAchievements: string[] = structuredResume?.achievements || structuredResume?.awards || [];
  const achievements: ResumeLearningAchievementItem[] = rawAchievements.map((ach, idx) => {
    const achLineBreakdown: ResumeLearningLineBreakdown = {
      raw_line: ach,
      line_label: `Achievement ${idx + 1}`,
      brief_explanation: `Distinguished competitive, academic, or professional recognition from your resume.`,
      what_it_demonstrates: 'Competitive Excellence & Merit',
      interview_angle: 'What was the background, scale, or selection criteria for this recognition?',
      key_talking_point: `I earned this through dedicated preparation and high-impact performance in a competitive environment.`
    };

    return {
      id: `ach-${idx + 1}`,
      title: ach.length > 50 ? `${ach.substring(0, 47)}...` : ach,
      what_you_wrote: ach,
      understand_it: 'This entry highlights distinguished competitive, academic, or professional recognition from your resume.',
      key_things_to_know: [
        'The competitive scope, context, and criteria of this recognition',
        'The specific individual performance or innovation that earned the award',
        'How this achievement reinforces your domain dedication and resilience'
      ],
      why_it_matters: 'Achievements signal standout performance, competitive drive, and external validation of your capabilities.',
      what_you_should_explain: [
        'What was the background, scale, or selection ratio for this recognition?',
        'What specific preparation or individual work contributed to winning/earning it?',
        'What key domain or leadership lessons did you take away from this experience?'
      ],
      beginner_explanation: 'This achievement demonstrates that your work was recognized as noteworthy by external evaluators or organizations.',
      deeper_explanation: 'In interviews, discussing specific achievements provides concrete evidence of your execution rigor and resilience under competitive benchmarks.',
      deeper_context: [
        {
          title: 'Standout Differentiation & Competitive Rigor',
          summary: 'Leveraging achievements to stand out from other candidates.',
          architecture_mechanism: 'Demonstrates ability to perform under pressure, meet strict judging criteria, and deliver above-average results.',
          why_it_matters: 'Proves high initiative and intrinsic motivation.',
          interview_defense: `Describe the specific challenge, your strategy, and the final outcome in a humble, factual format.`,
          common_pitfalls: 'Exaggerating individual contribution in group competitions.'
        }
      ],
      line_by_line_breakdown: [achLineBreakdown]
    };
  });

  // 9. Claims Section
  const claims: ResumeLearningClaimItem[] = [];
  let claimId = 1;

  rawExp.forEach((e) => {
    const bullets: string[] = e.bullets || e.highlights || [];
    bullets.forEach((b: string) => {
      if (b.length > 20 && claims.length < 6) {
        claims.push({
          id: `claim-${claimId++}`,
          claim_text: b,
          source_section: `Experience (${e.role || 'Role'} at ${e.company || e.company_or_org || 'Company'})`,
          what_you_should_understand: [
            'What specific methods, statutes, or tools were used to accomplish this?',
            'What was your direct individual role vs the broader team\'s scope?',
            'How did you verify that this was accurate and compliant?',
            'What challenges arose while doing this and how did you resolve them?'
          ],
          deeper_claim_breakdown: [
            {
              title: 'Professional Rationale & Verification',
              summary: 'Deep defense of the methods, research, and decisions behind this claim.',
              architecture_mechanism: 'Specific operational workflows, citations, or metrics employed.',
              why_it_matters: 'Interviewers verify whether you executed the work yourself or merely observed it.',
              interview_defense: 'Be ready to explain the step-by-step lifecycle of how you executed this claim.',
              common_pitfalls: 'Being unable to substantiate details or metrics mentioned in the bullet.'
            }
          ]
        });
      }
    });
  });

  rawProjects.forEach((p) => {
    const bullets: string[] = p.bullets || (p.description ? [p.description] : []);
    bullets.forEach((b: string) => {
      if (b.length > 20 && claims.length < 8) {
        claims.push({
          id: `claim-${claimId++}`,
          claim_text: b,
          source_section: `Projects (${p.title || 'Project'})`,
          what_you_should_understand: [
            'What specific tools, methods, or guidelines were used to accomplish this?',
            'What was your direct individual role vs the broader team\'s scope?',
            'How did you verify that the deliverable met quality standards?',
            'What challenges arose while doing this and how did you resolve them?'
          ],
          deeper_claim_breakdown: [
            {
              title: 'Implementation Architecture & Verification',
              summary: 'Deep defense of the decisions behind this project claim.',
              architecture_mechanism: 'Methodology, factual validation, and testing assertions used.',
              why_it_matters: 'Validates professional credibility and depth.',
              interview_defense: 'Explain the exact trade-offs made when executing this deliverable.',
              common_pitfalls: 'Inventing numbers or details that cannot be substantiated.'
            }
          ]
        });
      }
    });
  });

  // 10. Sections list - Only include sections that actually exist on resume!
  const sections: ResumeLearningSectionSummary[] = [];
  if (summarySection) sections.push({ id: 'summary', title: 'Summary', total_items: 1, reviewed_items: 0, is_present: true });
  if (skills.length > 0) sections.push({ id: 'skills', title: 'Skills', total_items: skills.length, reviewed_items: 0, is_present: true });
  if (experience.length > 0) sections.push({ id: 'experience', title: 'Experience', total_items: experience.length, reviewed_items: 0, is_present: true });
  if (internships.length > 0) sections.push({ id: 'internship', title: 'Internship', total_items: internships.length, reviewed_items: 0, is_present: true });
  if (projects.length > 0) sections.push({ id: 'projects', title: 'Projects', total_items: projects.length, reviewed_items: 0, is_present: true });
  if (education.length > 0) sections.push({ id: 'education', title: 'Education', total_items: education.length, reviewed_items: 0, is_present: true });
  if (certifications.length > 0) sections.push({ id: 'certifications', title: 'Certifications', total_items: certifications.length, reviewed_items: 0, is_present: true });
  if (achievements.length > 0) sections.push({ id: 'achievements', title: 'Achievements', total_items: achievements.length, reviewed_items: 0, is_present: true });
  if (claims.length > 0) sections.push({ id: 'claims', title: 'Resume Claims', total_items: claims.length, reviewed_items: 0, is_present: true });

  return {
    candidate_name: candidateName,
    detected_domain: domainTitle,
    headline: domainTitle,
    summary_section: summarySection,
    skills,
    projects,
    experience,
    internships,
    education,
    certifications,
    achievements,
    claims,
    sections,
    overall_progress_pct: 0
  };
}
