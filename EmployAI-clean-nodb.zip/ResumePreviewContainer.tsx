import React, { useState, useRef, useEffect } from 'react';
import type { StructuredResume, ResumeLinkItem, STARImprovement, ResumeTemplateId } from '../types';
import { RESUME_TEMPLATES } from '../types';
import { OriginalResumeCanvasViewer } from './OriginalResumeCanvasViewer';
import { ResumeDocument } from './ResumeDocument';
import { 
  Sparkles, FileText, Download, Copy, Check, 
  Edit3, FileCheck, Layout
} from 'lucide-react';
import { cleanBulletText } from '../utils/urlHelper';
import './ResumePreview.css';

export interface ResumePreviewContainerProps {
  structuredResume?: StructuredResume | null;
  originalStructuredResume?: StructuredResume | null;
  templateId?: ResumeTemplateId;
  onTemplateChange?: (t: ResumeTemplateId) => void;
  onUpdateResume?: (updated: StructuredResume) => void;
  improvements?: STARImprovement[];
  editHistory?: Array<{ id: string; originalText: string; currentText: string; section: string }>;
  onOpenEnhancer?: (
    section: 'experience' | 'projects' | 'summary' | 'skills',
    itemId: string | null,
    content: any,
    defaultInstruction?: string
  ) => void;
  onOpenHeadlineEnhancer?: () => void;
  onOpenSummaryEnhancer?: () => void;
  onOpenBulletEnhancer?: (
    bullet: string,
    roleOrProject?: string,
    targetDomain?: string,
    onApply?: (newBullet: string) => void
  ) => void;
  onRevertBullet?: (
    section: 'experience' | 'projects' | 'portfolio' | 'summary',
    itemId: string | null,
    bullet: string
  ) => void;
  onRevertSummary?: () => void;
  file?: File | Blob | null;
  fileUrl?: string | null;
  filename?: string;
  detectedLinks?: ResumeLinkItem[];
  onDownloadOriginal?: () => void;
  rawText?: string;
  isDarkMode?: boolean;
  isScratch?: boolean;
  onUploadNew?: () => void;
  onFileSelected?: (file: File) => void;
}

const ResumePreviewContainerComponent: React.FC<ResumePreviewContainerProps> = ({
  structuredResume,
  originalStructuredResume,
  templateId = 'ats_classic',
  onTemplateChange,
  onUpdateResume,
  improvements = [],
  editHistory = [],
  onOpenEnhancer,
  onOpenHeadlineEnhancer,
  onOpenSummaryEnhancer,
  onOpenBulletEnhancer,
  onRevertBullet,
  onRevertSummary,
  file,
  fileUrl,
  filename = 'Resume_Document.pdf',
  detectedLinks = [],
  onDownloadOriginal,
  rawText,
  isDarkMode = false,
  isScratch = false,
  onUploadNew,
  onFileSelected
}) => {
  const [internalTemplateId, setInternalTemplateId] = useState<ResumeTemplateId>(templateId);
  const activeTemplateId = onTemplateChange ? templateId : internalTemplateId;
  const handleTemplateSelect = (newT: ResumeTemplateId) => {
    if (onTemplateChange) onTemplateChange(newT);
    else setInternalTemplateId(newT);
  };
  const [activeTab, setActiveTab] = useState<'enhanced' | 'original'>('enhanced');
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [draftResume, setDraftResume] = useState<StructuredResume | null>(null);
  const draftRef = useRef<StructuredResume | null>(null);
  const [copiedNotification, setCopiedNotification] = useState<boolean>(false);
  const [zoom, setZoom] = useState<number>(1.0);
  const deskScrollRef = useRef<HTMLDivElement>(null);

  // Keep draft in sync if external structuredResume changes while not editing
  useEffect(() => {
    if (!isEditMode && structuredResume) {
      draftRef.current = structuredResume;
      setDraftResume(structuredResume);
    }
  }, [structuredResume, isEditMode]);

  const handleStartEdit = () => {
    if (!structuredResume) return;
    const p = structuredResume.personal_info || {};
    const safeDraft: StructuredResume = {
      ...structuredResume,
      personal_info: {
        ...p,
        full_name: p.full_name || '',
        headline: p.headline || structuredResume.headline || structuredResume.title || '',
        email: p.email || '',
        phone: p.phone || '',
        location: p.location || '',
        linkedin: p.linkedin || '',
        github: p.github || '',
        portfolio: p.portfolio || '',
        leetcode: p.leetcode || '',
        codeforces: p.codeforces || ''
      },
      summary: structuredResume.summary || p.summary || '',
      skills: Array.isArray(structuredResume.skills) ? [...structuredResume.skills] : [],
      experience: Array.isArray(structuredResume.experience)
        ? structuredResume.experience.map(e => ({
            ...e,
            bullets: Array.isArray(e.bullets) ? [...e.bullets] : []
          }))
        : [],
      projects: Array.isArray(structuredResume.projects)
        ? structuredResume.projects.map(pr => ({
            ...pr,
            bullets: Array.isArray(pr.bullets) ? [...pr.bullets] : []
          }))
        : [],
      portfolio: Array.isArray(structuredResume.portfolio)
        ? structuredResume.portfolio.map(pt => ({
            ...pt,
            bullets: Array.isArray(pt.bullets) ? [...pt.bullets] : []
          }))
        : [],
      education: Array.isArray(structuredResume.education)
        ? structuredResume.education.map(ed => ({ ...ed }))
        : [],
      certifications: Array.isArray(structuredResume.certifications)
        ? structuredResume.certifications.map(c => ({ ...c }))
        : []
    };
    draftRef.current = safeDraft;
    setDraftResume(safeDraft);
    setIsEditMode(true);
  };

  const handleDoneEdit = () => {
    const finalData = draftRef.current || draftResume;
    if (finalData) {
      const cloned = JSON.parse(JSON.stringify(finalData));
      if (onUpdateResume) {
        onUpdateResume(cloned);
      }
      setDraftResume(cloned);
      draftRef.current = cloned;
    }
    setIsEditMode(false);
  };

  const handleCancelEdit = () => {
    setIsEditMode(false);
    const reverted = structuredResume ? JSON.parse(JSON.stringify(structuredResume)) : null;
    draftRef.current = reverted;
    setDraftResume(reverted);
  };

  const handleResumeUpdate = (updated: StructuredResume) => {
    if (isEditMode) {
      draftRef.current = updated;
      setDraftResume(updated);
    } else if (onUpdateResume) {
      onUpdateResume(updated);
    }
  };

  const activeStructuredResume = isEditMode 
    ? (draftResume || structuredResume) 
    : (structuredResume || draftResume);

  const handleFitWidth = () => {
    if (deskScrollRef.current) {
      const containerWidth = deskScrollRef.current.clientWidth - 48;
      const targetScale = Math.min(1.4, Math.max(0.45, containerWidth / 794));
      setZoom(Number(targetScale.toFixed(2)));
    }
  };

  const handleCopyText = async () => {
    if (!structuredResume) return;
    try {
      const p = structuredResume.personal_info || {};
      const lines: string[] = [];
      if (p.full_name) lines.push(p.full_name);
      const headline = p.headline || p.title || structuredResume.headline || structuredResume.title;
      if (headline) lines.push(headline);
      const contacts = [p.email, p.phone, p.location].filter(Boolean).join(' | ');
      if (contacts) lines.push(contacts);
      lines.push('\n');

      if (structuredResume.summary || p.summary) {
        lines.push('--- PROFESSIONAL SUMMARY ---');
        lines.push(structuredResume.summary || p.summary || '');
        lines.push('\n');
      }

      if (structuredResume.skills && structuredResume.skills.length > 0) {
        lines.push('--- CORE COMPETENCIES & SKILLS ---');
        lines.push(structuredResume.skills.join(', '));
        lines.push('\n');
      }

      if (structuredResume.experience && structuredResume.experience.length > 0) {
        lines.push('--- PROFESSIONAL EXPERIENCE ---');
        structuredResume.experience.forEach(exp => {
          lines.push(`${exp.role} | ${exp.company} (${exp.duration || ''})`);
          (exp.bullets || []).forEach(b => lines.push(`• ${cleanBulletText(b)}`));
          lines.push('');
        });
      }

      if (structuredResume.projects && structuredResume.projects.length > 0) {
        lines.push('--- TECHNICAL PROJECTS ---');
        structuredResume.projects.forEach(proj => {
          lines.push(`${proj.title} [${proj.role_or_tech || ''}] (${proj.duration || ''})`);
          if (proj.description) lines.push(proj.description);
          (proj.bullets || []).forEach(b => lines.push(`• ${cleanBulletText(b)}`));
          lines.push('');
        });
      }

      if (structuredResume.portfolio && structuredResume.portfolio.length > 0) {
        lines.push('--- PORTFOLIO & SHOWCASE ---');
        structuredResume.portfolio.forEach(port => {
          lines.push(`${port.title} [${port.role_or_tech || ''}] (${port.duration || ''})`);
          if (port.url) lines.push(`Live: ${port.url}`);
          if (port.code_url) lines.push(`Code: ${port.code_url}`);
          if (port.description) lines.push(port.description);
          (port.bullets || []).forEach(b => lines.push(`• ${cleanBulletText(b)}`));
          lines.push('');
        });
      }

      await navigator.clipboard.writeText(lines.join('\n'));
      setCopiedNotification(true);
      setTimeout(() => setCopiedNotification(false), 3000);
    } catch (e) {
      console.warn('Failed to copy text:', e);
    }
  };

  const zoomPresets = [0.65, 0.8, 1.0, 1.15, 1.3];

  return (
    <div className="resume-preview-container" id="resume-preview-workspace">
      {/* Top Header Mode Switcher Bar */}
      <div 
        className="no-print"
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0.65rem 1rem',
          background: 'var(--bg-secondary)',
          borderBottom: '1px solid var(--border-subtle)',
          flexWrap: 'wrap',
          gap: '0.5rem',
          zIndex: 20
        }}
      >
        {/* Left: View Mode Tabs */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', background: 'var(--bg-tertiary)', padding: '0.2rem', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
          <button
            type="button"
            onClick={() => setActiveTab('enhanced')}
            className={`btn btn-sm ${activeTab === 'enhanced' ? 'btn-primary' : 'btn-ghost'}`}
            style={{
              fontSize: '0.75rem',
              padding: '0.3rem 0.65rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
              fontWeight: activeTab === 'enhanced' ? 700 : 500
            }}
          >
            <Sparkles size={13} /> Live AI-Enhanced Resume
            <span className="badge badge-emerald" style={{ fontSize: '0.6rem', padding: '0.1rem 0.35rem' }}>
              Real-Time
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('original')}
            className={`btn btn-sm ${activeTab === 'original' ? 'btn-primary' : 'btn-ghost'}`}
            style={{
              fontSize: '0.75rem',
              padding: '0.3rem 0.65rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
              fontWeight: activeTab === 'original' ? 700 : 500
            }}
          >
            <FileText size={13} /> Original Uploaded File
          </button>
        </div>

        {/* Right: Quick Action Controls & Zoom for Enhanced View */}
        <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '0.4rem' }}>
          {activeTab === 'enhanced' && (
            <>
              {/* Template Switcher Dropdown */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', background: 'rgba(0, 0, 0, 0.3)', padding: '0.15rem 0.4rem', borderRadius: '6px', border: '1px solid var(--border-subtle)' }}>
                <Layout size={12} style={{ color: 'var(--accent-cyan)' }} />
                <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 600 }}>Template:</span>
                <select
                  value={activeTemplateId}
                  onChange={(e) => handleTemplateSelect(e.target.value as ResumeTemplateId)}
                  className="resume-doc-input"
                  style={{
                    fontSize: '0.72rem',
                    padding: '0.15rem 0.4rem',
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--text-primary)',
                    fontWeight: 600,
                    cursor: 'pointer',
                    outline: 'none'
                  }}
                  title="Switch between 6 ATS-friendly resume templates"
                >
                  {RESUME_TEMPLATES.map(t => (
                    <option key={t.id} value={t.id} style={{ background: '#0f172a', color: '#f8fafc' }}>
                      {t.label} ({t.tag})
                    </option>
                  ))}
                </select>
              </div>

              {/* Zoom Controls */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', background: 'rgba(0, 0, 0, 0.3)', padding: '0.15rem 0.35rem', borderRadius: '6px', border: '1px solid var(--border-subtle)' }}>
                <button
                  type="button"
                  onClick={() => setZoom(prev => Math.max(0.5, Number((prev - 0.1).toFixed(2))))}
                  className="resume-zoom-btn"
                  title="Zoom Out"
                >
                  -
                </button>

                {zoomPresets.map(preset => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setZoom(preset)}
                    className={`resume-zoom-btn ${zoom === preset ? 'active' : ''}`}
                  >
                    {Math.round(preset * 100)}%
                  </button>
                ))}

                <button
                  type="button"
                  onClick={() => setZoom(prev => Math.min(1.5, Number((prev + 0.1).toFixed(2))))}
                  className="resume-zoom-btn"
                  title="Zoom In"
                >
                  +
                </button>

                <button
                  type="button"
                  onClick={handleFitWidth}
                  className="resume-zoom-btn"
                  title="Fit to Page Width"
                >
                  Fit
                </button>
              </div>

              {!isEditMode ? (
                <button
                  type="button"
                  onClick={handleStartEdit}
                  className="btn btn-secondary btn-sm"
                  style={{
                    fontSize: '0.75rem',
                    padding: '0.25rem 0.65rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.35rem',
                    fontWeight: 600,
                    color: 'var(--accent-cyan)',
                    borderColor: 'rgba(56, 189, 248, 0.35)',
                    background: 'rgba(56, 189, 248, 0.08)'
                  }}
                  title="Directly edit resume data and sections in this panel"
                >
                  <Edit3 size={13} /> Edit Data Manually
                </button>
              ) : (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                  <button
                    type="button"
                    onClick={handleCancelEdit}
                    className="btn btn-secondary btn-sm"
                    style={{ fontSize: '0.72rem', padding: '0.25rem 0.55rem' }}
                    title="Discard changes and exit edit mode"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleDoneEdit}
                    className="btn btn-emerald btn-sm"
                    style={{
                      fontSize: '0.75rem',
                      padding: '0.25rem 0.75rem',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.35rem',
                      fontWeight: 700,
                      boxShadow: '0 0 10px rgba(16, 185, 129, 0.35)'
                    }}
                    title="Finish editing and render changes"
                  >
                    <Check size={13} /> Done
                  </button>
                </div>
              )}

              <button
                type="button"
                onClick={handleCopyText}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.72rem', padding: '0.25rem 0.55rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                title="Copy Resume Plain Text"
              >
                {copiedNotification ? <Check size={12} color="#10b981" /> : <Copy size={12} />}
                {copiedNotification ? 'Copied!' : 'Copy'}
              </button>
            </>
          )}

          {activeTab === 'original' && onDownloadOriginal && (
            <button
              type="button"
              onClick={onDownloadOriginal}
              className="btn btn-secondary btn-sm"
              style={{ fontSize: '0.72rem', padding: '0.25rem 0.55rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
            >
              <Download size={12} /> Download Original
            </button>
          )}
        </div>
      </div>

      {/* Main Workspace Area */}
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {activeTab === 'enhanced' ? (
          <div 
            ref={deskScrollRef}
            className="resume-desk-scroll-area" 
            style={{ 
              flex: 1, 
              overflowY: 'auto', 
              overflowX: 'auto', 
              padding: '2rem 1rem 4rem 1rem',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center'
            }}
          >
            {isEditMode && (
              <div
                className="no-print"
                style={{
                  width: '100%',
                  maxWidth: '794px',
                  marginBottom: '1.25rem',
                  padding: '0.75rem 1rem',
                  background: 'linear-gradient(90deg, rgba(16, 185, 129, 0.15), rgba(56, 189, 248, 0.15))',
                  border: '1px solid rgba(16, 185, 129, 0.4)',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '0.75rem',
                  boxShadow: '0 4px 15px rgba(0, 0, 0, 0.25)'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                  <div style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '50%',
                    background: 'rgba(16, 185, 129, 0.25)',
                    color: '#10b981',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0
                  }}>
                    <Edit3 size={16} />
                  </div>
                  <div>
                    <div style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                      In-Panel Direct Edit Mode Active
                    </div>
                    <div style={{ fontSize: '0.73rem', color: 'var(--text-secondary)' }}>
                      Edit fields directly on the resume below. When finished, click the <strong>Done</strong> button in the top toolbar to render your changes.
                    </div>
                  </div>
                </div>
              </div>
            )}

            {structuredResume ? (
              <>
                <div 
                  className="resume-document-zoom-wrapper"
                  style={{ 
                    transform: `scale(${zoom})`, 
                    transformOrigin: 'top center',
                    transition: 'transform 0.15s ease-out',
                    marginBottom: `${(zoom - 1) * 600}px`
                  }}
                >
                  <ResumeDocument
                    structuredResume={activeStructuredResume!}
                    originalStructuredResume={originalStructuredResume}
                    templateId={activeTemplateId}
                    isDarkMode={isDarkMode}
                    isEditMode={isEditMode}
                    showDiffHighlights={!isEditMode}
                    improvements={improvements}
                    editHistory={editHistory}
                    onUpdateResume={handleResumeUpdate}
                    onOpenEnhancer={onOpenEnhancer}
                    onOpenHeadlineEnhancer={onOpenHeadlineEnhancer}
                    onOpenSummaryEnhancer={onOpenSummaryEnhancer}
                    onOpenBulletEnhancer={onOpenBulletEnhancer}
                    onRevertBullet={onRevertBullet}
                    onRevertSummary={onRevertSummary}
                  />
                </div>
              </>
            ) : (
              <div style={{ textAlign: 'center', padding: '3rem 1rem', color: 'var(--text-muted)' }}>
                <FileCheck size={40} style={{ margin: '0 auto 1rem auto', opacity: 0.5 }} />
                <p>Upload a resume to generate your live interactive AI-enhanced resume.</p>
              </div>
            )}
          </div>
        ) : (
          <OriginalResumeCanvasViewer
            file={file}
            fileUrl={fileUrl}
            filename={filename}
            detectedLinks={detectedLinks}
            onDownloadOriginal={onDownloadOriginal}
            rawText={rawText}
            isScratch={isScratch}
            onUploadClick={onUploadNew}
            onFileSelected={onFileSelected}
          />
        )}
      </div>
    </div>
  );
};

export const ResumePreviewContainer = React.memo(ResumePreviewContainerComponent);
