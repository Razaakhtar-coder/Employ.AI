import unittest
from datetime import datetime, timezone, timedelta
from fastapi.testclient import TestClient

from app.main import app
from app.core.config import settings
from app.core.security import create_access_token, get_password_hash
from app.core.database import SessionLocal
from app.models.user import User
from app.models.payment import Payment


class TestSubscriptionExpiryAndTimer(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)
        cls.db = SessionLocal()

        cls.user_email = "expiry_test_user@gmail.com"
        cls.user = cls.db.query(User).filter(User.email == cls.user_email).first()
        if not cls.user:
            cls.user = User(
                email=cls.user_email,
                hashed_password=get_password_hash("TestPass@123"),
                full_name="Expiry Test Candidate",
                role="student",
                is_active=True,
                is_premium=False
            )
            cls.db.add(cls.user)
            cls.db.commit()
            cls.db.refresh(cls.user)

        cls.user_token = create_access_token(
            subject=cls.user.id,
            role=cls.user.role,
            email=cls.user.email,
            full_name=cls.user.full_name
        )

    @classmethod
    def tearDownClass(cls):
        cls.db.close()

    def test_monthly_subscription_grants_30_days(self):
        """Monthly plan (₹49) grants 30 days validity and is_premium=True."""
        now_utc = datetime.now(timezone.utc)
        self.user.is_premium = True
        self.user.subscription_plan = "monthly"
        self.user.subscription_valid_until = now_utc + timedelta(days=30)
        self.db.commit()

        headers = {"Authorization": f"Bearer {self.user_token}"}
        res = self.client.get("/api/v1/payments/status", headers=headers)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue(data["is_premium"])
        self.assertFalse(data["is_expired"])
        self.assertEqual(data["plan_type"], "monthly")
        self.assertGreaterEqual(data["days_remaining"], 29)
        self.assertLessEqual(data["days_remaining"], 30)

    def test_annual_subscription_grants_365_days(self):
        """Annual plan (₹499) grants 365 days validity and is_premium=True."""
        now_utc = datetime.now(timezone.utc)
        self.user.is_premium = True
        self.user.subscription_plan = "annual"
        self.user.subscription_valid_until = now_utc + timedelta(days=365)
        self.db.commit()

        headers = {"Authorization": f"Bearer {self.user_token}"}
        res = self.client.get("/api/v1/payments/status", headers=headers)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue(data["is_premium"])
        self.assertFalse(data["is_expired"])
        self.assertEqual(data["plan_type"], "annual")
        self.assertGreaterEqual(data["days_remaining"], 364)
        self.assertLessEqual(data["days_remaining"], 365)

    def test_expired_subscription_automatically_resets_pro(self):
        """When 1 month or 1 year passes, user loses PRO, is_expired=True, days_remaining=0."""
        past_time = datetime.now(timezone.utc) - timedelta(days=2)
        self.user.is_premium = True
        self.user.subscription_plan = "monthly"
        self.user.subscription_valid_until = past_time
        self.db.commit()

        headers = {"Authorization": f"Bearer {self.user_token}"}
        res = self.client.get("/api/v1/payments/status", headers=headers)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertFalse(data["is_premium"])
        self.assertTrue(data["is_expired"])
        self.assertEqual(data["days_remaining"], 0)

        # Refresh from db and confirm database state was updated
        self.db.refresh(self.user)
        self.assertFalse(self.user.is_premium)

    def test_expired_user_blocked_at_require_premium_gate(self):
        """Protected endpoints return 403 Forbidden with prompt to renew when subscription lapsed."""
        past_time = datetime.now(timezone.utc) - timedelta(hours=5)
        self.user.is_premium = True
        self.user.subscription_valid_until = past_time
        self.db.commit()

        headers = {"Authorization": f"Bearer {self.user_token}"}
        # Roadmaps endpoint is strictly protected by require_premium_user
        res = self.client.get("/api/v1/roadmaps/active", headers=headers)
        self.assertEqual(res.status_code, 403)
        self.assertIn("expired", res.json()["detail"].lower())

    def test_admin_is_always_lifetime_and_never_expired(self):
        """Admin (akhtarrakeeb52@gmail.com) is permanently lifetime active and exempt from timers."""
        admin_user = self.db.query(User).filter(User.email == "akhtarrakeeb52@gmail.com").first()
        admin_id = admin_user.id if admin_user else "admin_seed_id"
        admin_token = create_access_token(
            subject=admin_id,
            role="admin",
            email="akhtarrakeeb52@gmail.com",
            full_name="Admin"
        )
        headers = {"Authorization": f"Bearer {admin_token}"}
        res = self.client.get("/api/v1/payments/status", headers=headers)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue(data["is_premium"])
        self.assertTrue(data["is_admin"])
        self.assertFalse(data["is_expired"])
        self.assertEqual(data["plan_type"], "admin_lifetime")


if __name__ == "__main__":
    unittest.main()
