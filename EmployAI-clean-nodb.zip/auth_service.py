import json
import os
import requests
from datetime import datetime, timezone, timedelta
from typing import Optional, Tuple, Dict, Any
from fastapi import HTTPException, status
from sqlalchemy.orm import Session
import secrets
from app.core.config import settings
from app.core.security import verify_password, get_password_hash, create_access_token
from app.core.exceptions import UnauthorizedException, ForbiddenException
from app.models.user import User
from app.models.profile import StudentProfile, AcademicProfile, IndustryProfile
from app.schemas.auth import UserRegister, UserLogin, GoogleAuthRequest, Token


ADMIN_EMAIL = "akhtarrakeeb52@gmail.com"
BUNDLED_BACKUP_FILE = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "employai_users_backup.json")
)
BACKUP_FILE = "/tmp/employai_users_backup.json" if os.getenv("VERCEL") else BUNDLED_BACKUP_FILE


class AuthService:
    @staticmethod
    def is_admin_email(email: Optional[str]) -> bool:
        if not email:
            return False
        return email.strip().lower() == ADMIN_EMAIL.lower()

    @classmethod
    def evaluate_user_subscription(cls, user: User, db: Session):
        """Enforces live subscription duration (30 days for monthly, 365 for annual) and auto-expires."""
        if not user:
            return
        is_admin = cls.is_admin_email(user.email)
        if is_admin:
            user.role = "admin"
            user.is_premium = True
            user.subscription_plan = "lifetime"
            return

        if user.is_premium:
            now_utc = datetime.now(timezone.utc)
            valid_until = getattr(user, "subscription_valid_until", None)
            is_lapsed = False
            if valid_until:
                if valid_until.tzinfo is None:
                    valid_until = valid_until.replace(tzinfo=timezone.utc)
                if now_utc > valid_until:
                    is_lapsed = True
            else:
                base = getattr(user, "premium_since", None) or getattr(user, "created_at", None)
                if base:
                    if base.tzinfo is None:
                        base = base.replace(tzinfo=timezone.utc)
                    if now_utc > (base + timedelta(days=30)):
                        is_lapsed = True

            if is_lapsed:
                user.is_premium = False
                db.commit()
                db.refresh(user)
                cls._save_backup_user(user)


    @staticmethod
    def _load_backup_users() -> Dict[str, Dict[str, Any]]:
        """Load user credentials backup dictionary."""
        target_path = BACKUP_FILE
        if not os.path.exists(target_path) and os.path.exists(BUNDLED_BACKUP_FILE):
            target_path = BUNDLED_BACKUP_FILE
        if not os.path.exists(target_path):
            return {}
        try:
            with open(target_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    @staticmethod
    def _save_backup_user(user: User):
        """Append or update a user in the persistent serverless backup file."""
        try:
            users = AuthService._load_backup_users()
            norm_email = user.email.strip().lower()
            valid_until_iso = None
            if getattr(user, "subscription_valid_until", None):
                try:
                    valid_until_iso = user.subscription_valid_until.isoformat()
                except Exception:
                    valid_until_iso = str(user.subscription_valid_until)

            users[norm_email] = {
                "id": str(user.id),
                "email": norm_email,
                "hashed_password": user.hashed_password,
                "full_name": user.full_name,
                "role": user.role,
                "is_premium": user.is_premium,
                "subscription_plan": getattr(user, "subscription_plan", None),
                "subscription_valid_until": valid_until_iso,
                "institution_or_company": "State Technological University",
                "department_or_domain": "Computer Science & Engineering"
            }
            os.makedirs(os.path.dirname(BACKUP_FILE), exist_ok=True)
            with open(BACKUP_FILE, "w", encoding="utf-8") as f:
                json.dump(users, f, indent=2)
        except Exception as e:
            print(f"[WARN] Failed to write backup user: {e}")

    @classmethod
    def ensure_default_seed(cls, db: Session):
        """Pre-seeds standard test accounts and restores any registered accounts."""
        try:
            # 1. Ensure Super Admin user
            admin_norm = ADMIN_EMAIL.lower()
            admin_user = db.query(User).filter(User.email.ilike(admin_norm)).first()
            if not admin_user:
                admin_user = User(
                    email=admin_norm,
                    hashed_password=get_password_hash("RazaRakeeb#$"),
                    full_name="Raza Akhtar (Admin)",
                    role="admin",
                    auth_provider="email",
                    is_active=True,
                    is_premium=True
                )
                db.add(admin_user)
                db.flush()
                db.add(StudentProfile(
                    user_id=admin_user.id,
                    institution_name="Integral University",
                    department="Computer Science & Engineering",
                    target_domain="AI & System Architecture",
                    profile_completion_pct=100
                ))
                db.commit()
                cls._save_backup_user(admin_user)
            else:
                admin_user.hashed_password = get_password_hash("RazaRakeeb#$")
                admin_user.role = "admin"
                admin_user.is_premium = True
                db.commit()
                cls._save_backup_user(admin_user)

            # 2. Ensure test demo student account
            test_norm = "testuser123@gmail.com"
            test_user = db.query(User).filter(User.email.ilike(test_norm)).first()
            if not test_user:
                test_user = User(
                    email=test_norm,
                    hashed_password=get_password_hash("Password123!"),
                    full_name="Alex Hunter",
                    role="student",
                    auth_provider="email",
                    is_active=True,
                    is_premium=False
                )
                db.add(test_user)
                db.flush()
                db.add(StudentProfile(
                    user_id=test_user.id,
                    institution_name="National Institute of Technology",
                    department="Computer Science & Engineering",
                    target_domain="Full Stack Development",
                    profile_completion_pct=85
                ))
                db.commit()
                cls._save_backup_user(test_user)

            # 3. Restore any previously registered users from backup file
            backup_users = cls._load_backup_users()
            for norm_email, data in backup_users.items():
                existing = db.query(User).filter(User.email.ilike(norm_email)).first()
                if not existing:
                    val_until = None
                    if data.get("subscription_valid_until"):
                        try:
                            val_until = datetime.fromisoformat(data["subscription_valid_until"])
                        except Exception:
                            pass
                    new_u = User(
                        id=data.get("id"),
                        email=norm_email,
                        hashed_password=data.get("hashed_password") or get_password_hash("Restore@123"),
                        full_name=data.get("full_name") or norm_email.split("@")[0],
                        role=data.get("role") or "student",
                        auth_provider="email",
                        is_active=True,
                        is_premium=bool(data.get("is_premium", False)),
                        subscription_plan=data.get("subscription_plan"),
                        subscription_valid_until=val_until
                    )
                    db.add(new_u)
                    db.flush()
                    db.add(StudentProfile(
                        user_id=new_u.id,
                        institution_name=data.get("institution_or_company") or "State Technological University",
                        department=data.get("department_or_domain") or "Computer Science",
                        target_domain="Computer Science",
                        profile_completion_pct=50
                    ))
                    db.commit()
        except Exception as e:
            print(f"[WARN] Error in ensure_default_seed: {e}")

    @classmethod
    def register_user(cls, db: Session, reg_data: UserRegister) -> Tuple[User, str]:
        """Register a new user and create corresponding role profile."""
        norm_email = reg_data.email.strip().lower()
        is_admin = cls.is_admin_email(norm_email)

        # Check in DB
        existing_user = db.query(User).filter(User.email.ilike(norm_email)).first()
        if not existing_user:
            # Check in persistent backup
            backups = cls._load_backup_users()
            if norm_email in backups:
                cls.ensure_default_seed(db)
                existing_user = db.query(User).filter(User.email.ilike(norm_email)).first()

        if existing_user:
            password_matches = False
            if existing_user.hashed_password:
                password_matches = verify_password(reg_data.password, existing_user.hashed_password)
            if not password_matches and is_admin and reg_data.password in ["RazaRakeeb#$"]:
                password_matches = True
                existing_user.hashed_password = get_password_hash(reg_data.password)

            if not password_matches:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="incorrect password"
                )

            if reg_data.full_name and reg_data.full_name.strip():
                existing_user.full_name = reg_data.full_name.strip()
            if is_admin:
                existing_user.role = "admin"
                existing_user.is_premium = True
            db.commit()
            db.refresh(existing_user)
            cls._save_backup_user(existing_user)
            token = create_access_token(
                subject=existing_user.id,
                role=existing_user.role,
                email=existing_user.email,
                full_name=existing_user.full_name,
                is_premium=existing_user.is_premium
            )
            return existing_user, token

        # Strict Admin rule: Only akhtarrakeeb52@gmail.com can be admin
        is_admin = cls.is_admin_email(norm_email)
        if is_admin:
            role = "admin"
            is_premium = True
        else:
            role = reg_data.role if reg_data.role in ["student", "academia"] else "student"
            is_premium = False

        user = User(
            email=norm_email,
            hashed_password=get_password_hash(reg_data.password),
            full_name=(reg_data.full_name.strip() if (reg_data.full_name and reg_data.full_name.strip()) else norm_email.split('@')[0].replace('.', ' ').title()),
            role=role,
            auth_provider="email",
            is_active=True,
            is_premium=is_premium
        )
        db.add(user)
        db.flush()

        # Create role-specific profile
        if user.role in ["student", "admin"]:
            profile = StudentProfile(
                user_id=user.id,
                institution_name=reg_data.institution_or_company or "Technological University",
                department=reg_data.department_or_domain or "Computer Science & Engineering",
                target_domain=reg_data.department_or_domain or "Computer Science & Engineering",
                profile_completion_pct=40
            )
            db.add(profile)
        elif user.role == "academia":
            profile = AcademicProfile(
                user_id=user.id,
                institution_name=reg_data.institution_or_company or "Technological University",
                department=reg_data.department_or_domain or "Training & Placement Cell",
                designation="Training & Placement Officer"
            )
            db.add(profile)
        elif user.role == "industry":
            profile = IndustryProfile(
                user_id=user.id,
                company_name=reg_data.institution_or_company or "Enterprise Partner",
                domain=reg_data.department_or_domain or "Technology",
                is_verified=True
            )
            db.add(profile)

        db.commit()
        db.refresh(user)

        # Save to backup store for serverless cross-instance resilience
        cls._save_backup_user(user)

        token = create_access_token(
            subject=user.id,
            role=user.role,
            email=user.email,
            full_name=user.full_name,
            is_premium=user.is_premium
        )
        return user, token

    @classmethod
    def authenticate_user(cls, db: Session, login_data: UserLogin) -> Tuple[User, str]:
        """Authenticate user with Gmail and password. Strictly rejects incorrect passwords."""
        norm_email = login_data.email.strip().lower()
        is_admin = cls.is_admin_email(norm_email)
        user = db.query(User).filter(User.email.ilike(norm_email)).first()

        # If user not found in local DB instance, attempt reload from backup
        if not user:
            backups = cls._load_backup_users()
            if norm_email in backups:
                cls.ensure_default_seed(db)
                user = db.query(User).filter(User.email.ilike(norm_email)).first()

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No Employ.AI account found with this Gmail. Please check the email address or register."
            )
        else:
            # STRICT PASSWORD VERIFICATION FOR EXISTING USER
            password_matches = False
            if user.hashed_password:
                password_matches = verify_password(login_data.password, user.hashed_password)

            # Master fallback for admin initial seed
            if not password_matches and is_admin and login_data.password in ["RazaRakeeb#$"]:
                password_matches = True
                user.hashed_password = get_password_hash(login_data.password)

            if not password_matches:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="incorrect password"
                )

            if not user.is_active:
                raise ForbiddenException("This account is currently deactivated.")

            if is_admin:
                user.role = "admin"
                user.is_premium = True
                user.subscription_plan = "lifetime"
            elif user.role == "admin":
                user.role = "student"

            # Check and auto-expire subscription if period has ended
            cls.evaluate_user_subscription(user, db)

            if login_data.username and login_data.username.strip():
                user.full_name = login_data.username.strip()

            db.commit()
            db.refresh(user)
            cls._save_backup_user(user)

        token = create_access_token(
            subject=user.id,
            role=user.role,
            email=user.email,
            full_name=user.full_name,
            is_premium=user.is_premium
        )
        return user, token

    @classmethod
    def reset_password(cls, db: Session, email: str, new_password: str) -> Tuple[User, str]:
        """Reset password for an existing Gmail account and return authenticated session."""
        norm_email = email.strip().lower()
        is_admin = cls.is_admin_email(norm_email)
        if is_admin:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admin password cannot be reset via the public reset endpoint."
            )
        user = db.query(User).filter(User.email.ilike(norm_email)).first()
        if not user:
            backups = cls._load_backup_users()
            if norm_email in backups:
                cls.ensure_default_seed(db)
                user = db.query(User).filter(User.email.ilike(norm_email)).first()

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No account found with Gmail '{norm_email}'."
            )

        if len(new_password) < 6:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="New password must be at least 6 characters long."
            )

        user.hashed_password = get_password_hash(new_password)
        db.commit()
        db.refresh(user)
        cls._save_backup_user(user)

        token = create_access_token(
            subject=user.id,
            role=user.role,
            email=user.email,
            full_name=user.full_name,
            is_premium=user.is_premium
        )
        return user, token

    @classmethod
    def authenticate_google(cls, db: Session, google_data: GoogleAuthRequest) -> Tuple[User, str]:
        """
        Official Google Identity Services (GSI) authentication handler.
        1. If id_token is provided: Cryptographically verifies the token via Google OAuth2 tokeninfo API.
           Extracts verified email, name, and picture directly from Google.
           Authenticates or provisions the user WITHOUT demanding a password.
        2. Fallback mode: If no id_token is provided, uses in-app credentials.
           If the user doesn't exist and isRegister is False, returns a clean 404 error instead of auto-creating.
        """
        email = google_data.email
        name = google_data.full_name
        picture = google_data.avatar_url
        is_google_verified = False

        # 1. Official Google Identity Services ID Token Verification
        if google_data.id_token and google_data.id_token.strip():
            try:
                resp = requests.get(
                    f"https://oauth2.googleapis.com/tokeninfo?id_token={google_data.id_token.strip()}",
                    timeout=8
                )
                if resp.status_code == 200:
                    payload = resp.json()

                    # Verify email_verified status from Google
                    email_verified = payload.get("email_verified")
                    if email_verified not in (True, "true", "True", 1):
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Google account email is not verified by Google."
                        )

                    # Audience check if GOOGLE_CLIENT_ID configured
                    configured_client_id = (settings.GOOGLE_CLIENT_ID or "").strip()
                    if configured_client_id and not configured_client_id.startswith("your-google"):
                        token_aud = payload.get("aud")
                        if token_aud != configured_client_id:
                            print(f"[WARN] Google id_token aud mismatch: got {token_aud}, expected {configured_client_id}")

                    email = payload.get("email")
                    name = payload.get("name") or (email.split("@")[0] if email else "Google User")
                    picture = payload.get("picture")
                    is_google_verified = True
                else:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Invalid Google OAuth ID token from Google Identity Services."
                    )
            except HTTPException:
                raise
            except Exception as e:
                print(f"[ERROR] Google tokeninfo verification failed: {e}")
                raise HTTPException(
                    status_code=status.HTTP_502_BAD_GATEWAY,
                    detail="Could not reach Google verification servers. Please try again."
                )

        norm_email = (email or "").strip().lower()
        if norm_email and "@" not in norm_email:
            norm_email = f"{norm_email}@gmail.com"
        if not norm_email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="A valid Gmail address is required."
            )

        display_name = name or norm_email.split("@")[0].replace(".", " ").title()
        is_admin = cls.is_admin_email(norm_email)

        # Check existing user in DB
        user = db.query(User).filter(User.email.ilike(norm_email)).first()
        if not user:
            backups = cls._load_backup_users()
            if norm_email in backups:
                cls.ensure_default_seed(db)
                user = db.query(User).filter(User.email.ilike(norm_email)).first()

        # Handle Admin security
        if is_admin:
            if not is_google_verified:
                if not google_data.password:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Admin password is required to access the admin account."
                    )
                password_matches = False
                if user and user.hashed_password:
                    password_matches = verify_password(google_data.password, user.hashed_password)
                if not password_matches and google_data.password in ["RazaRakeeb#$"]:
                    password_matches = True
                    if user:
                        user.hashed_password = get_password_hash(google_data.password)
                if not password_matches:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="incorrect password"
                    )

        # 2. User Does Not Exist in Database -> Automatically provision with given password
        if not user:
            if not is_google_verified:
                if not google_data.password or len(google_data.password) < 6:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Password must be at least 6 characters long."
                    )
                user_pw = google_data.password
            else:
                # Verified by official Google 1-Click OAuth: generate secure internal random hash
                user_pw = secrets.token_urlsafe(32)

            role = "admin" if is_admin else (google_data.role or "student")
            user = User(
                email=norm_email,
                hashed_password=get_password_hash(user_pw),
                full_name=display_name,
                role=role,
                auth_provider="google" if is_google_verified else "email",
                avatar_url=picture,
                is_active=True,
                is_premium=True if is_admin else False
            )
            db.add(user)
            db.flush()

            db.add(StudentProfile(
                user_id=user.id,
                institution_name="Technological University",
                department="Computer Science & Engineering",
                target_domain="Software Engineering",
                profile_completion_pct=50
            ))

            db.commit()
            db.refresh(user)
            cls._save_backup_user(user)

        # 3. User Exists in Database
        else:
            if not is_google_verified and not is_admin:
                # Fallback password check
                if not google_data.password:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Password is required for this registered Gmail account."
                    )
                if not user.hashed_password or not verify_password(google_data.password, user.hashed_password):
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="incorrect password"
                    )

            if is_admin:
                user.role = "admin"
                user.is_premium = True
                user.subscription_plan = "lifetime"
            elif user.role == "admin":
                user.role = "student"

            # Check and auto-expire subscription if period has ended
            cls.evaluate_user_subscription(user, db)

            if is_google_verified:
                user.auth_provider = "google"
                if picture:
                    user.avatar_url = picture
                if display_name and not user.full_name:
                    user.full_name = display_name
            elif google_data.full_name and google_data.full_name.strip():
                user.full_name = google_data.full_name.strip()

            db.commit()
            db.refresh(user)
            cls._save_backup_user(user)

        token = create_access_token(
            subject=user.id,
            role=user.role,
            email=user.email,
            full_name=user.full_name,
            is_premium=user.is_premium
        )
        return user, token

