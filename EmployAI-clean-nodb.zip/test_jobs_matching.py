import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.services.job_normalization_service import JobNormalizationService
from app.services.job_matching_service import JobMatchingService


def test_job_normalization_dedup():
    key1 = JobNormalizationService.generate_dedup_key(
        title="Software Engineer Intern",
        company="Google Inc.",
        location="Bengaluru",
        remote=False
    )
    key2 = JobNormalizationService.generate_dedup_key(
        title="software engineer intern",
        company="google inc",
        location="Bengaluru",
        remote=False
    )
    assert key1 == key2


def test_job_normalization_skill_extraction():
    desc = """
    We are looking for a Python and React developer with experience in PostgreSQL, Docker, and REST APIs.
    Knowledge of Git and CI/CD is a huge plus.
    """
    skills = JobNormalizationService.extract_required_skills(desc, raw_tags=["fastapi"])
    assert "Python" in skills
    assert "React" in skills
    assert "PostgreSQL" in skills
    assert "Docker" in skills
    assert "FastAPI" in skills


def test_honest_mba_vs_software_job_match():
    """
    Test MBA graduate profile evaluated against a technical Forward Deployed Engineer role.
    Must produce an honest low match percentage (< 15%) and identify missing technical skills.
    """
    mba_student_ctx = {
        "skills": {"financial modeling", "corporate finance", "financial accounting", "excel", "strategic planning", "marketing", "human resources"},
        "domain": "Management & Business",
        "department": "Master of Business Administration (MBA)",
        "grad_year": 2025,
        "ats_score": 85.0,
        "cgpa": 8.8,
        "has_resume": True
    }

    # 1. Forward Deployed Engineer (Software / Computer Science role)
    score, breakdown, matched, missing, meta = JobMatchingService.compute_match(
        student_ctx=mba_student_ctx,
        job_title="Forward Deployed Engineer",
        job_domain="Computer Science",
        job_exp_level="entry",
        required_skills=["Python", "FastAPI", "React", "Docker", "PostgreSQL", "Data Structures", "Git"]
    )

    print(f"MBA vs Forward Deployed Engineer Match Score: {score}%")
    assert score <= 15.0, f"Expected MBA vs Software match <= 15%, got {score}%"
    assert len(matched) == 0, f"Expected 0 matched technical skills, got {len(matched)}"
    assert len(missing) == 7

    # 2. Financial Analyst (Finance & Commerce role) - Should match strongly
    fin_score, fin_breakdown, fin_matched, fin_missing, _ = JobMatchingService.compute_match(
        student_ctx=mba_student_ctx,
        job_title="Financial Analyst - Valuation & Modeling",
        job_domain="Finance & Commerce",
        job_exp_level="entry",
        required_skills=["Financial Modeling", "Financial Analysis", "Advanced Excel", "Corporate Finance", "Financial Accounting", "Auditing"]
    )

    print(f"MBA vs Financial Analyst Match Score: {fin_score}%")
    assert fin_score >= 70.0, f"Expected MBA vs Financial Analyst >= 70%, got {fin_score}%"
    assert len(fin_matched) >= 4


def test_honest_cs_vs_software_job_match():
    """
    Test Computer Science graduate profile evaluated against Software role.
    Must produce a high match percentage (> 80%).
    """
    cs_student_ctx = {
        "skills": {"python", "fastapi", "react", "postgresql", "docker", "git", "data structures"},
        "domain": "Computer Science",
        "department": "Computer Science & Engineering",
        "grad_year": 2025,
        "ats_score": 88.0,
        "cgpa": 8.5,
        "has_resume": True
    }

    score, breakdown, matched, missing, meta = JobMatchingService.compute_match(
        student_ctx=cs_student_ctx,
        job_title="Forward Deployed Engineer",
        job_domain="Computer Science",
        job_exp_level="entry",
        required_skills=["Python", "FastAPI", "React", "Docker", "PostgreSQL", "Data Structures", "Git"]
    )

    print(f"CS vs Forward Deployed Engineer Match Score: {score}%")
    assert score >= 80.0, f"Expected CS vs Software match >= 80%, got {score}%"
    assert len(matched) == 7
    assert len(missing) == 0


def test_no_substring_false_positives():
    """
    Ensure single letters like 'C', 'R', 'Go', 'IT', 'Git' do not falsely match unrelated words.
    """
    # Candidate with 'Digital Marketing' and 'Corporate Finance'
    cand_skills = {"digital marketing", "corporate finance", "communication", "economics"}

    # 'git' should NOT match 'digital marketing'
    assert not JobMatchingService.check_skill_match("Git", cand_skills)

    # 'c' should NOT match 'corporate finance'
    assert not JobMatchingService.check_skill_match("C", cand_skills)

def test_senior_social_designer_vs_software_developer():
    """
    Test real Senior Social Designer job description against a Software Developer resume.
    Must produce low honest match score (< 12%) and correctly extract Design & Creative Media skills/domain.
    """
    desc = """This is a senior, hands-on design role in a high-volume social studio, working on the account for one of our brand new FMCG clients.
    You'll be responsible for the quality and consistency of visual output across always-on and campaign work.
    As Senior Social Designer, you'll drive the visual craft of the studio — translating ideas into platform-native assets.
    Proficiency with Adobe Creative Suite (Photoshop, Illustrator, After Effects, Premiere Pro), CapCut, Canva, Figma, or equivalent tools.
    Experience building and maintaining design systems, templates, and modular asset libraries.
    Advanced use of Gen AI tools relevant to social design.
    Experience designing AI-assisted workflows."""

    skills = JobNormalizationService.extract_required_skills(desc)
    exp = JobNormalizationService.determine_experience_level("Senior Social Designer", desc)
    domain = JobNormalizationService.classify_domain("Senior Social Designer", desc, skills)

    assert domain == "Design & Creative Media"
    assert exp == "senior"
    assert "Photoshop" in skills
    assert "Figma" in skills
    assert "After Effects" in skills

    # 1. Evaluate Software Developer against this Design Role
    sw_ctx = {
        "skills": {"python", "react", "fastapi", "postgresql", "docker", "git", "data structures"},
        "domain": "Computer Science",
        "department": "Computer Science & Engineering",
        "grad_year": 2025,
        "ats_score": 85.0,
        "cgpa": 8.5,
        "has_resume": True
    }

    score, breakdown, matched, missing, meta = JobMatchingService.compute_match(
        student_ctx=sw_ctx,
        job_title="Senior Social Designer",
        job_domain=domain,
        job_exp_level=exp,
        required_skills=skills
    )

    print(f"Software Developer vs Senior Social Designer Match Score: {score}%")
    assert score <= 12.0, f"Expected Software Developer vs Senior Social Designer <= 12%, got {score}%"
    assert len(matched) == 0, f"Expected 0 matched skills, got {len(matched)}"
    assert len(missing) == len(skills)

    # 2. Evaluate Genuine Senior Designer against this Design Role
    designer_ctx = {
        "skills": {"photoshop", "illustrator", "after effects", "figma", "canva", "premiere pro", "design systems", "motion graphics", "video editing"},
        "domain": "Design & Creative Media",
        "department": "Visual Arts & Design",
        "grad_year": 2021,
        "ats_score": 90.0,
        "cgpa": 8.8,
        "has_resume": True
    }

    des_score, des_breakdown, des_matched, des_missing, _ = JobMatchingService.compute_match(
        student_ctx=designer_ctx,
        job_title="Senior Social Designer",
        job_domain=domain,
        job_exp_level=exp,
        required_skills=skills
    )

    print(f"Senior Designer vs Senior Social Designer Match Score: {des_score}%")
    assert des_score >= 70.0, f"Expected Senior Designer vs Senior Social Designer >= 70%, got {des_score}%"
    assert len(des_matched) >= 6


if __name__ == "__main__":
    test_job_normalization_dedup()
    test_job_normalization_skill_extraction()
    test_no_substring_false_positives()
    test_honest_mba_vs_software_job_match()
    test_honest_cs_vs_software_job_match()
    test_senior_social_designer_vs_software_developer()
    print("All Honest Job Engine tests passed successfully!")
