import React, { useState } from 'react';
import type { 
  StructuredResume, 
  STARImprovement, 
  ResumeExperienceItem, 
  ResumeProjectItem, 
  ResumeEducationItem, 
  ResumeCertificationItem,
  ResumeTemplateId
} from '../types';
import { 
  Mail, Phone, MapPin, Sparkles, Globe, Link2, ExternalLink, 
  Code, Terminal, Trophy, Plus, Trash2, Wand2, Undo2,
  GraduationCap, Award, Briefcase, User
} from 'lucide-react';
import { 
  sanitizeAndFormatUrl, 
  handleSafeLinkClick, 
  sanitizeEmail, 
  formatMailto, 
  formatTel, 
  formatSocialUrl,
  cleanBulletText
} from '../utils/urlHelper';

export interface ResumeDocumentProps {
  structuredResume: StructuredResume;
  originalStructuredResume?: StructuredResume | null;
  templateId?: ResumeTemplateId;
  isDarkMode?: boolean;
  isEditMode?: boolean;
  showDiffHighlights?: boolean;
  improvements?: STARImprovement[];
  editHistory?: Array<{ id: string; originalText: string; currentText: string; section: string }>;
  onUpdateResume?: (updated: StructuredResume) => void;
  onOpenEnhancer?: (
    section: 'experience' | 'projects' | 'summary' | 'skills',
    itemId: string | null,
    content: any,
    defaultInstruction?: string
  ) => void;
  onOpenHeadlineEnhancer?: () => void;
  onOpenSummaryEnhancer?: () => void;
  onOpenBulletEnhancer?: (
    bullet: string,
    roleOrProject?: string,
    targetDomain?: string,
    onApply?: (newBullet: string) => void
  ) => void;
  onRevertBullet?: (
    section: 'experience' | 'projects' | 'portfolio' | 'summary',
    itemId: string | null,
    bullet: string
  ) => void;
  onRevertSummary?: () => void;
  pageNumber?: number;
  totalPages?: number;
}

// Helper to auto-link URLs and emails in text
const renderWithLinks = (text: string): React.ReactNode => {
  if (!text) return null;
  const linkOrEmailRegex = /((?:https?:\/\/|www\.)[^\s)\]">]+|[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/gi;
  const parts = text.split(linkOrEmailRegex);

  if (parts.length === 1) return text;

  return parts.map((part, i) => {
    if (part.includes('@') && !part.startsWith('http')) {
      const mailto = formatMailto(part);
      if (mailto) {
        return (
          <a
            key={i}
            href={mailto}
            className="resume-doc-inline-link"
          >
            {part}
          </a>
        );
      }
    }
    if (part.match(/^(?:https?:\/\/|www\.)/i)) {
      const href = sanitizeAndFormatUrl(part);
      if (!href) return part;
      return (
        <a
          key={i}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="resume-doc-inline-link"
          onClick={(e) => handleSafeLinkClick(e, href)}
        >
          {part}
        </a>
      );
    }
    return part;
  });
};

const ResumeDocumentComponent: React.FC<ResumeDocumentProps> = ({
  structuredResume,
  originalStructuredResume,
  templateId = 'ats_classic',
  isDarkMode = false,
  isEditMode = false,
  showDiffHighlights = true,
  improvements = [],
  editHistory = [],
  onUpdateResume,
  onOpenEnhancer,
  onOpenHeadlineEnhancer,
  onOpenSummaryEnhancer,
  onOpenBulletEnhancer,
  onRevertBullet,
  onRevertSummary,
  pageNumber = 1,
  totalPages = 1
}) => {
  const { personal_info, summary, skills = [], experience = [], projects = [], portfolio = [], education = [], certifications = [] } = structuredResume;
  const [newSkillInput, setNewSkillInput] = useState('');

  // Helper to check if a bullet was optimized by AI
  const isBulletOptimized = (bullet: string): boolean => {
    if (!bullet) return false;
    const inImprovements = improvements.some(
      imp => imp.is_applied && (imp.suggested_bullet === bullet || imp.improved_bullet === bullet)
    );
    if (inImprovements) return true;
    const inHistory = (editHistory || []).some(
      h => h.currentText === bullet || (bullet.includes(h.currentText) && h.currentText.length > 10)
    );
    return inHistory;
  };

  // State update handlers for manual editing
  const updatePersonalInfo = (field: string, val: string) => {
    if (!onUpdateResume) return;
    const updated: StructuredResume = {
      ...structuredResume,
      personal_info: {
        ...(structuredResume.personal_info || {}),
        [field]: val
      }
    };
    if (field === 'headline' || field === 'title') {
      updated.headline = val;
      updated.title = val;
    }
    onUpdateResume(updated);
  };

  const updateSummary = (val: string) => {
    if (!onUpdateResume) return;
    const updated: StructuredResume = {
      ...structuredResume,
      summary: val,
      personal_info: {
        ...(structuredResume.personal_info || {}),
        summary: val
      }
    };
    onUpdateResume(updated);
  };

  const handleAddSkill = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newSkillInput.trim() || !onUpdateResume) return;
    const trimmed = newSkillInput.trim();
    if (!skills.some(s => s.toLowerCase() === trimmed.toLowerCase())) {
      onUpdateResume({
        ...structuredResume,
        skills: [...skills, trimmed]
      });
    }
    setNewSkillInput('');
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    if (!onUpdateResume) return;
    const cleanTarget = skillToRemove.trim().toLowerCase();
    onUpdateResume({
      ...structuredResume,
      skills: skills.filter(s => s.trim().toLowerCase() !== cleanTarget)
    });
  };


  const updateExperienceItem = (idx: number, field: keyof ResumeExperienceItem, val: any) => {
    if (!onUpdateResume) return;
    const nextExp = [...experience];
    nextExp[idx] = { ...nextExp[idx], [field]: val };
    onUpdateResume({ ...structuredResume, experience: nextExp });
  };

  const addExperienceItem = () => {
    if (!onUpdateResume) return;
    const newExp: ResumeExperienceItem = {
      id: `exp-${Date.now()}`,
      role: 'New Role Title',
      company: 'Company / Organization',
      duration: 'Month Year - Present',
      bullets: ['Spearheaded core deliverables and achieved measurable outcomes.']
    };
    onUpdateResume({ ...structuredResume, experience: [newExp, ...experience] });
  };

  const deleteExperienceItem = (idx: number) => {
    if (!onUpdateResume) return;
    onUpdateResume({
      ...structuredResume,
      experience: experience.filter((_, i) => i !== idx)
    });
  };

  const addExperienceBullet = (expIdx: number) => {
    if (!onUpdateResume || !experience[expIdx]) return;
    const nextExp = [...experience];
    nextExp[expIdx] = {
      ...nextExp[expIdx],
      bullets: [...(nextExp[expIdx].bullets || []), 'Delivered impactful technical solution resulting in high efficiency.']
    };
    onUpdateResume({ ...structuredResume, experience: nextExp });
  };

  const updateProjectItem = (idx: number, field: keyof ResumeProjectItem, val: any) => {
    if (!onUpdateResume) return;
    const nextProj = [...projects];
    nextProj[idx] = { ...nextProj[idx], [field]: val };
    onUpdateResume({ ...structuredResume, projects: nextProj });
  };

  const addProjectItem = () => {
    if (!onUpdateResume) return;
    const newProj: ResumeProjectItem = {
      id: `proj-${Date.now()}`,
      title: 'New Technical Project',
      role_or_tech: 'React, Node.js, Python',
      duration: '2026',
      description: 'Engineered a scalable fullstack application solving real-world domain challenges.',
      bullets: ['Built responsive interface and optimized backend endpoints for high throughput.']
    };
    onUpdateResume({ ...structuredResume, projects: [newProj, ...projects] });
  };

  const deleteProjectItem = (idx: number) => {
    if (!onUpdateResume) return;
    onUpdateResume({
      ...structuredResume,
      projects: projects.filter((_, i) => i !== idx)
    });
  };

  const addProjectBullet = (projIdx: number) => {
    if (!onUpdateResume || !projects[projIdx]) return;
    const nextProj = [...projects];
    nextProj[projIdx] = {
      ...nextProj[projIdx],
      bullets: [...(nextProj[projIdx].bullets || []), 'Implemented modern architectural design reducing latency.']
    };
    onUpdateResume({ ...structuredResume, projects: nextProj });
  };

  const updatePortfolioItem = (idx: number, field: keyof ResumeProjectItem, val: any) => {
    if (!onUpdateResume) return;
    const nextPort = [...portfolio];
    nextPort[idx] = { ...nextPort[idx], [field]: val };
    onUpdateResume({ ...structuredResume, portfolio: nextPort });
  };

  const addPortfolioItem = () => {
    if (!onUpdateResume) return;
    const newPort: ResumeProjectItem = {
      id: `port-${Date.now()}`,
      title: 'New Portfolio Showcase',
      role_or_tech: 'AI/ML & Full Stack Development',
      duration: '2026',
      url: 'https://myportfolio.dev',
      description: 'Production showcase highlighting end-to-end applications and technical deliverables.',
      bullets: ['Developed responsive web interfaces and deployed production models with high throughput.']
    };
    onUpdateResume({ ...structuredResume, portfolio: [newPort, ...portfolio] });
  };

  const deletePortfolioItem = (idx: number) => {
    if (!onUpdateResume) return;
    onUpdateResume({
      ...structuredResume,
      portfolio: portfolio.filter((_, i) => i !== idx)
    });
  };

  const addPortfolioBullet = (portIdx: number) => {
    if (!onUpdateResume || !portfolio[portIdx]) return;
    const nextPort = [...portfolio];
    nextPort[portIdx] = {
      ...nextPort[portIdx],
      bullets: [...(nextPort[portIdx].bullets || []), 'Engineered high-performance systems and interactive components.']
    };
    onUpdateResume({ ...structuredResume, portfolio: nextPort });
  };

  const updateEducationItem = (idx: number, field: keyof ResumeEducationItem, val: any) => {
    if (!onUpdateResume) return;
    const nextEdu = [...education];
    nextEdu[idx] = { ...nextEdu[idx], [field]: val };
    onUpdateResume({ ...structuredResume, education: nextEdu });
  };

  const addEducationItem = () => {
    if (!onUpdateResume) return;
    const newEdu: ResumeEducationItem = {
      degree: 'Bachelor of Technology',
      field_of_study: 'Engineering',
      institution: 'University / Institute Name',
      start_year: '2022',
      end_year: '2026',
      grade_or_cgpa: '8.8 CGPA'
    };
    onUpdateResume({ ...structuredResume, education: [...education, newEdu] });
  };

  const deleteEducationItem = (idx: number) => {
    if (!onUpdateResume) return;
    onUpdateResume({
      ...structuredResume,
      education: education.filter((_, i) => i !== idx)
    });
  };

  const addCertificationItem = () => {
    if (!onUpdateResume) return;
    const newCert: ResumeCertificationItem = {
      name: 'Certified Professional',
      issuer: 'Certification Authority',
      year: '2026'
    };
    onUpdateResume({ ...structuredResume, certifications: [...certifications, newCert] });
  };

  const updateCertificationItem = (idx: number, field: keyof ResumeCertificationItem, val: any) => {
    if (!onUpdateResume) return;
    const nextCert = [...certifications];
    nextCert[idx] = { ...nextCert[idx], [field]: val };
    onUpdateResume({ ...structuredResume, certifications: nextCert });
  };

  const deleteCertificationItem = (idx: number) => {
    if (!onUpdateResume) return;
    onUpdateResume({
      ...structuredResume,
      certifications: certifications.filter((_, i) => i !== idx)
    });
  };

  const getCleanHandle = (url?: string, type?: string) => {
    if (!url) return '';
    let cleaned = url.trim().replace(/^https?:\/\/(?:www\.)?/i, '').replace(/\/$/, '');
    if (type === 'linkedin') {
      const handle = cleaned.replace(/^linkedin\.com\/in\//i, '').replace(/^in\//i, '').replace(/^@/, '').split('?')[0];
      return handle || 'Profile';
    }
    if (type === 'github') {
      const handle = cleaned.replace(/^github\.com\//i, '').replace(/^@/, '').split('?')[0];
      return handle || 'Profile';
    }
    if (type === 'leetcode') {
      const handle = cleaned.replace(/^leetcode\.com\/(?:u\/)?/i, '').replace(/^@/, '').split('?')[0];
      return handle || 'Profile';
    }
    if (type === 'codeforces') {
      const handle = cleaned.replace(/^codeforces\.com\/profile\//i, '').replace(/^@/, '').split('?')[0];
      return handle || 'Profile';
    }
    return cleaned;
  };

  const formatLink = (url?: string) => sanitizeAndFormatUrl(url);
  const formatSocial = (url?: string, type?: 'linkedin' | 'github' | 'leetcode' | 'codeforces' | 'portfolio') => 
    formatSocialUrl(url, type);

  const candidateHeadline = personal_info?.headline || personal_info?.title || structuredResume.headline || structuredResume.title;
  const candidateName = personal_info?.full_name || 'Candidate Name';
  const nameInitials = (candidateName || 'Candidate Name')
    .split(' ')
    .map(n => n[0])
    .filter(Boolean)
    .slice(0, 2)
    .join('')
    .toUpperCase() || 'CA';

  // -------------------------------------------------------------
  // TEMPLATE 1: EMERALD FOREST SIDEBAR (Michael Johnson Style)
  // -------------------------------------------------------------
  // -------------------------------------------------------------
  // TEMPLATE 1: EMERALD FOREST SIDEBAR (Michael Johnson Style)
  // -------------------------------------------------------------
  if (templateId === 'emerald_sidebar' && !isEditMode) {
    return (
      <article
        className={`resume-document-page template-emerald_sidebar template-emerald-sidebar ${isDarkMode ? 'dark-mode' : ''} ${isEditMode ? 'edit-mode-active' : ''}`}
        id={`resume-document-page-${pageNumber}`}
      >
        {totalPages > 1 && (
          <div className="resume-page-tag no-print">Page {pageNumber} of {totalPages}</div>
        )}

        {/* Left Green Sidebar */}
        <aside className="emerald-sidebar">
          <div className="emerald-avatar-wrap">
            <div className="emerald-avatar-circle">
              {nameInitials}
            </div>
            <h1 className="emerald-name">{candidateName}</h1>

            {candidateHeadline && (
              <div className="emerald-headline">{candidateHeadline}</div>
            )}
          </div>

          {/* Contact Details */}
          <div>
            <div className="emerald-side-section-title">Contact</div>
            {personal_info?.location && (
              <div className="emerald-contact-item">
                <span className="emerald-contact-label">Address</span>
                <span>{personal_info.location}</span>
              </div>
            )}
            {personal_info?.phone && formatTel(personal_info.phone) && (
              <div className="emerald-contact-item">
                <span className="emerald-contact-label">Phone</span>
                <a href={formatTel(personal_info.phone)} style={{ color: '#fff', textDecoration: 'none' }}>
                  {personal_info.phone}
                </a>
              </div>
            )}
            {personal_info?.email && formatMailto(personal_info.email) && (
              <div className="emerald-contact-item">
                <span className="emerald-contact-label">E-mail</span>
                <a href={formatMailto(personal_info.email)} style={{ color: '#fff', textDecoration: 'underline' }}>
                  {sanitizeEmail(personal_info.email)}
                </a>
              </div>
            )}
            {personal_info?.linkedin && formatSocial(personal_info.linkedin, 'linkedin') && (
              <div className="emerald-contact-item">
                <span className="emerald-contact-label">LinkedIn</span>
                <a
                  href={formatSocial(personal_info.linkedin, 'linkedin')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.linkedin, 'linkedin'))}
                  style={{ color: '#86efac', textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: '0.2rem' }}
                >
                  {getCleanHandle(personal_info.linkedin, 'linkedin')}
                  <ExternalLink size={9} />
                </a>
              </div>
            )}
            {personal_info?.github && formatSocial(personal_info.github, 'github') && (
              <div className="emerald-contact-item">
                <span className="emerald-contact-label">GitHub</span>
                <a
                  href={formatSocial(personal_info.github, 'github')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.github, 'github'))}
                  style={{ color: '#86efac', textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: '0.2rem' }}
                >
                  {getCleanHandle(personal_info.github, 'github')}
                  <ExternalLink size={9} />
                </a>
              </div>
            )}
            {personal_info?.leetcode && formatSocial(personal_info.leetcode, 'leetcode') && (
              <div className="emerald-contact-item">
                <span className="emerald-contact-label">LeetCode</span>
                <a
                  href={formatSocial(personal_info.leetcode, 'leetcode')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.leetcode, 'leetcode'))}
                  style={{ color: '#86efac', textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: '0.2rem' }}
                >
                  {getCleanHandle(personal_info.leetcode, 'leetcode')}
                  <ExternalLink size={9} />
                </a>
              </div>
            )}
            {personal_info?.codeforces && formatSocial(personal_info.codeforces, 'codeforces') && (
              <div className="emerald-contact-item">
                <span className="emerald-contact-label">Codeforces</span>
                <a
                  href={formatSocial(personal_info.codeforces, 'codeforces')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.codeforces, 'codeforces'))}
                  style={{ color: '#86efac', textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: '0.2rem' }}
                >
                  {getCleanHandle(personal_info.codeforces, 'codeforces')}
                  <ExternalLink size={9} />
                </a>
              </div>
            )}
            {personal_info?.portfolio && formatSocial(personal_info.portfolio, 'portfolio') && (
              <div className="emerald-contact-item">
                <span className="emerald-contact-label">Portfolio</span>
                <a
                  href={formatSocial(personal_info.portfolio, 'portfolio')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.portfolio, 'portfolio'))}
                  style={{ color: '#86efac', textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: '0.2rem' }}
                >
                  Portfolio
                  <ExternalLink size={9} />
                </a>
              </div>
            )}
          </div>

          {/* All Skills with Capsule Pills (No Truncation) */}
          {skills.length > 0 && (
            <div>
              <div className="emerald-side-section-title">Skills</div>
              <div style={{ display: 'flex', flexWrap: 'wrap' }}>
                {skills.map((s, idx) => (
                  <span key={idx} className="emerald-capsule-pill">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Languages - Only rendered if user actually has languages specified */}
          {structuredResume.languages && structuredResume.languages.length > 0 && (
            <div>
              <div className="emerald-side-section-title">Languages</div>
              <div style={{ display: 'flex', flexWrap: 'wrap' }}>
                {structuredResume.languages.map((lang, idx) => (
                  <span key={idx} className="emerald-capsule-pill">
                    {lang}
                  </span>
                ))}
              </div>
            </div>
          )}
        </aside>

        {/* Right Main Body */}
        <main className="emerald-main">
          {/* Dynamic Summary */}
          {(summary || personal_info?.summary) && (
            <div className="emerald-summary">
              {summary || personal_info?.summary}
            </div>
          )}

          {/* Work History */}
          {experience.length > 0 && (
            <div>
              <div className="emerald-main-section-title">Work History</div>
              {experience.map((exp, idx) => (
                <div key={idx} className="emerald-timeline-row">
                  <div className="emerald-timeline-dates">{exp.duration || ''}</div>
                  <div className="emerald-timeline-body">
                    <div className="emerald-item-role">{exp.role}</div>
                    <div className="emerald-item-company">{exp.company}</div>
                    <ul className="resume-doc-bullets" style={{ margin: 0, paddingLeft: '1.2rem' }}>
                      {(exp.bullets || []).map((b, bIdx) => {
                        const isOpt = isBulletOptimized(b);
                        return (
                          <li
                            key={bIdx}
                            className={`resume-doc-bullet ${isOpt && showDiffHighlights ? 'ai-optimized' : ''}`}
                            style={{ fontSize: '0.78rem', marginBottom: '0.2rem', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem' }}
                          >
                            <span style={{ flex: 1 }}>{renderWithLinks(cleanBulletText(b))}</span>
                            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem', flexShrink: 0 }} className="no-print">
                              {isOpt && showDiffHighlights && (
                                <span className="resume-doc-diff-badge" style={{ fontSize: '0.62rem', padding: '0.1rem 0.35rem' }}>
                                  <Sparkles size={8} /> AI STAR Impact
                                </span>
                              )}
                              {isOpt && onRevertBullet && (
                                <button
                                  type="button"
                                  onClick={() => onRevertBullet('experience', exp.id || exp.company, b)}
                                  className="btn btn-sm btn-secondary"
                                  style={{ padding: '0.1rem 0.35rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                                  title="Undo AI enhancement and restore original wording"
                                >
                                  <Undo2 size={8} /> Remove
                                </button>
                              )}
                              {onOpenBulletEnhancer ? (
                                <button
                                  type="button"
                                  onClick={() => onOpenBulletEnhancer(
                                    b,
                                    exp.role ? `${exp.role} at ${exp.company}` : exp.company,
                                    undefined,
                                    (newB) => {
                                      const newBullets = [...(exp.bullets || [])];
                                      newBullets[bIdx] = newB;
                                      updateExperienceItem(idx, 'bullets', newBullets);
                                    }
                                  )}
                                  className="btn btn-sm btn-outline-emerald"
                                  style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                                  title="Improve this bullet point with 3 AI options"
                                >
                                  <Wand2 size={8} /> AI Polish
                                </button>
                              ) : onOpenEnhancer ? (
                                <button
                                  type="button"
                                  onClick={() => onOpenEnhancer('experience', exp.id || exp.company, b, 'Rewrite with strong action verbs and quantifiable STAR impact.')}
                                  className="btn btn-sm btn-outline-emerald"
                                  style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2 }}
                                  title="Enhance wording with AI"
                                >
                                  <Wand2 size={8} /> AI Enhance
                                </button>
                              ) : null}
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Key Projects */}
          {projects.length > 0 && (
            <div>
              <div className="emerald-main-section-title">Key Projects</div>
              {projects.map((prj, idx) => (
                <div key={idx} className="emerald-timeline-row">
                  <div className="emerald-timeline-dates">{prj.duration || ''}</div>
                  <div className="emerald-timeline-body">
                    <div className="emerald-item-role" style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '0.35rem' }}>
                      <span>{prj.title}</span>
                      {prj.code_url && formatLink(prj.code_url) && (
                        <a
                          href={formatLink(prj.code_url)}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => handleSafeLinkClick(e, prj.code_url)}
                          style={{ color: '#059669', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}
                          title="Open Project Code"
                        >
                          <Code size={10} /> Code
                        </a>
                      )}
                      {prj.url && formatLink(prj.url) && (
                        <a
                          href={formatLink(prj.url)}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => handleSafeLinkClick(e, prj.url)}
                          style={{ color: '#059669', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}
                          title="Open Live Demo"
                        >
                          <Globe size={10} /> Demo
                        </a>
                      )}
                    </div>
                    {prj.role_or_tech && <div className="emerald-item-company">{prj.role_or_tech}</div>}
                    {prj.description && (
                      <p style={{ fontSize: '0.78rem', color: '#475569', margin: '0.1rem 0 0.25rem 0' }}>
                        {renderWithLinks(prj.description)}
                      </p>
                    )}
                    <ul className="resume-doc-bullets" style={{ margin: 0, paddingLeft: '1.2rem' }}>
                      {(prj.bullets || []).map((b, bIdx) => {
                        const isOpt = isBulletOptimized(b);
                        return (
                          <li
                            key={bIdx}
                            className={`resume-doc-bullet ${isOpt && showDiffHighlights ? 'ai-optimized' : ''}`}
                            style={{ fontSize: '0.78rem', marginBottom: '0.2rem', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem' }}
                          >
                            <span style={{ flex: 1 }}>{renderWithLinks(cleanBulletText(b))}</span>
                            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem', flexShrink: 0 }} className="no-print">
                              {isOpt && showDiffHighlights && (
                                <span className="resume-doc-diff-badge" style={{ fontSize: '0.62rem', padding: '0.1rem 0.35rem' }}>
                                  <Sparkles size={8} /> AI STAR Impact
                                </span>
                              )}
                              {isOpt && onRevertBullet && (
                                <button
                                  type="button"
                                  onClick={() => onRevertBullet('projects', prj.id || prj.title, b)}
                                  className="btn btn-sm btn-secondary"
                                  style={{ padding: '0.1rem 0.35rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                                  title="Undo AI enhancement and restore original wording"
                                >
                                  <Undo2 size={8} /> Remove
                                </button>
                              )}
                              {onOpenBulletEnhancer ? (
                                <button
                                  type="button"
                                  onClick={() => onOpenBulletEnhancer(
                                    b,
                                    prj.title,
                                    undefined,
                                    (newB) => {
                                      const newBullets = [...(prj.bullets || [])];
                                      newBullets[bIdx] = newB;
                                      updateProjectItem(idx, 'bullets', newBullets);
                                    }
                                  )}
                                  className="btn btn-sm btn-outline-emerald"
                                  style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                                  title="Improve this bullet point with 3 AI options"
                                >
                                  <Wand2 size={8} /> AI Polish
                                </button>
                              ) : onOpenEnhancer ? (
                                <button
                                  type="button"
                                  onClick={() => onOpenEnhancer('projects', prj.id || prj.title, b, `Enhance technical architecture phrasing for ${prj.title}.`)}
                                  className="btn btn-sm btn-outline-emerald"
                                  style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2 }}
                                  title="Enhance wording with AI"
                                >
                                  <Wand2 size={8} /> AI Enhance
                                </button>
                              ) : null}
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Portfolio & Live Showcase */}
          {portfolio && portfolio.length > 0 && (
            <div>
              <div className="emerald-main-section-title">Portfolio & Live Showcase</div>
              {portfolio.map((port, idx) => (
                <div key={idx} className="emerald-timeline-row">
                  <div className="emerald-timeline-dates">{port.duration || ''}</div>
                  <div className="emerald-timeline-body">
                    <div className="emerald-item-role" style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '0.35rem' }}>
                      <span>{port.title}</span>
                      {port.code_url && formatLink(port.code_url) && (
                        <a
                          href={formatLink(port.code_url)}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => handleSafeLinkClick(e, port.code_url)}
                          style={{ color: '#059669', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}
                          title="Open Code Repository"
                        >
                          <Code size={10} /> Code
                        </a>
                      )}
                      {port.url && formatLink(port.url) && (
                        <a
                          href={formatLink(port.url)}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => handleSafeLinkClick(e, port.url)}
                          style={{ color: '#059669', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}
                          title="Open Live Showcase"
                        >
                          <Globe size={10} /> Live
                        </a>
                      )}
                    </div>
                    {port.role_or_tech && <div className="emerald-item-company">{port.role_or_tech}</div>}
                    {port.description && (
                      <p style={{ fontSize: '0.78rem', color: '#475569', margin: '0.1rem 0 0.25rem 0' }}>
                        {renderWithLinks(port.description)}
                      </p>
                    )}
                    <ul className="resume-doc-bullets" style={{ margin: 0, paddingLeft: '1.2rem' }}>
                      {(port.bullets || []).map((b, bIdx) => (
                        <li key={bIdx} className="resume-doc-bullet" style={{ fontSize: '0.78rem', marginBottom: '0.2rem' }}>
                          {renderWithLinks(cleanBulletText(b))}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Education */}
          {education.length > 0 && (
            <div>
              <div className="emerald-main-section-title">Education</div>
              {education.map((edu, idx) => (
                <div key={idx} className="emerald-timeline-row">
                  <div className="emerald-timeline-dates">
                    {edu.end_year ? (edu.start_year ? `${edu.start_year} - ${edu.end_year}` : edu.end_year) : (edu.start_year || '')}
                  </div>
                  <div className="emerald-timeline-body">
                    <div className="emerald-item-role">{edu.degree} {edu.field_of_study ? `in ${edu.field_of_study}` : ''}</div>
                    <div className="emerald-item-company">{edu.institution} {edu.grade_or_cgpa ? `• ${edu.grade_or_cgpa}` : ''}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Certifications */}
          {certifications.length > 0 && (
            <div>
              <div className="emerald-main-section-title">Certifications</div>
              <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', margin: 0 }}>
                {certifications.map((c, idx) => (
                  <li key={idx} className="resume-doc-bullet" style={{ fontSize: '0.78rem', marginBottom: '0.25rem' }}>
                    <strong>{c.name}</strong> {c.issuer ? `— ${c.issuer}` : ''} {c.year ? `(${c.year})` : ''}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </main>
      </article>
    );
  }

  // -------------------------------------------------------------
  // TEMPLATE 2: LAVENDER PASTEL MINIMAL (Chris Johnson Style)
  // -------------------------------------------------------------
  if (templateId === 'lavender_lilac' && !isEditMode) {
    return (
      <article
        className={`resume-document-page template-lavender_lilac template-lavender-lilac ${isDarkMode ? 'dark-mode' : ''} ${isEditMode ? 'edit-mode-active' : ''}`}
        id={`resume-document-page-${pageNumber}`}
      >
        {totalPages > 1 && (
          <div className="resume-page-tag no-print">Page {pageNumber} of {totalPages}</div>
        )}

        {/* Left Sidebar with Lilac Hero */}
        <aside className="lavender-sidebar">
          <div className="lavender-top-hero">
            <div className="lavender-monogram">
              <span>{nameInitials}</span>
            </div>
            <h1 className="lavender-name">{candidateName}</h1>
            {candidateHeadline && (
              <div style={{ fontSize: '0.78rem', color: '#4c1d95', fontWeight: 600 }}>{candidateHeadline}</div>
            )}
            <div style={{ height: '1px', background: 'rgba(30, 27, 75, 0.2)', margin: '0.3rem 0' }} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem', fontSize: '0.72rem', color: '#1e1b4b' }}>
              {personal_info?.email && formatMailto(personal_info.email) && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <Mail size={11} color="#6d28d9" />
                  <a
                    href={formatMailto(personal_info.email)}
                    style={{ color: '#1e1b4b', textDecoration: 'underline' }}
                  >
                    {sanitizeEmail(personal_info.email)}
                  </a>
                </div>
              )}
              {personal_info?.phone && formatTel(personal_info.phone) && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <Phone size={11} color="#6d28d9" />
                  <a
                    href={formatTel(personal_info.phone)}
                    style={{ color: '#1e1b4b', textDecoration: 'none' }}
                  >
                    {personal_info.phone}
                  </a>
                </div>
              )}
              {personal_info?.location && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <MapPin size={11} color="#6d28d9" />
                  <span>{personal_info.location}</span>
                </div>
              )}
              {personal_info?.linkedin && formatSocial(personal_info.linkedin, 'linkedin') && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <Link2 size={11} color="#6d28d9" />
                  <a
                    href={formatSocial(personal_info.linkedin, 'linkedin')}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.linkedin, 'linkedin'))}
                    style={{ color: '#6d28d9', textDecoration: 'underline' }}
                  >
                    LinkedIn: {getCleanHandle(personal_info.linkedin, 'linkedin')}
                  </a>
                </div>
              )}
              {personal_info?.github && formatSocial(personal_info.github, 'github') && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <Code size={11} color="#6d28d9" />
                  <a
                    href={formatSocial(personal_info.github, 'github')}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.github, 'github'))}
                    style={{ color: '#6d28d9', textDecoration: 'underline' }}
                  >
                    GitHub: {getCleanHandle(personal_info.github, 'github')}
                  </a>
                </div>
              )}
              {personal_info?.leetcode && formatSocial(personal_info.leetcode, 'leetcode') && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <Terminal size={11} color="#6d28d9" />
                  <a
                    href={formatSocial(personal_info.leetcode, 'leetcode')}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.leetcode, 'leetcode'))}
                    style={{ color: '#6d28d9', textDecoration: 'underline' }}
                  >
                    LeetCode: {getCleanHandle(personal_info.leetcode, 'leetcode')}
                  </a>
                </div>
              )}
              {personal_info?.codeforces && formatSocial(personal_info.codeforces, 'codeforces') && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <Trophy size={11} color="#6d28d9" />
                  <a
                    href={formatSocial(personal_info.codeforces, 'codeforces')}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.codeforces, 'codeforces'))}
                    style={{ color: '#6d28d9', textDecoration: 'underline' }}
                  >
                    Codeforces: {getCleanHandle(personal_info.codeforces, 'codeforces')}
                  </a>
                </div>
              )}
              {personal_info?.portfolio && formatSocial(personal_info.portfolio, 'portfolio') && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <Globe size={11} color="#6d28d9" />
                  <a
                    href={formatSocial(personal_info.portfolio, 'portfolio')}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.portfolio, 'portfolio'))}
                    style={{ color: '#6d28d9', textDecoration: 'underline' }}
                  >
                    Portfolio
                  </a>
                </div>
              )}
            </div>
          </div>

          <div className="lavender-side-body">
            {/* Education */}
            {education.length > 0 && (
              <div>
                <div className="lavender-section-title">EDUCATION</div>
                {education.map((edu, idx) => (
                  <div key={idx} style={{ marginBottom: '0.65rem', fontSize: '0.74rem' }}>
                    <div style={{ fontWeight: 800, color: '#1e1b4b' }}>{edu.institution}</div>
                    <div style={{ color: '#64748b', fontSize: '0.68rem' }}>
                      {edu.end_year ? `Graduation: ${edu.end_year}` : (edu.start_year || '')}
                      {edu.grade_or_cgpa ? ` • ${edu.grade_or_cgpa}` : ''}
                    </div>
                    <div style={{ fontWeight: 600, color: '#6d28d9', marginTop: '0.1rem' }}>{edu.degree} {edu.field_of_study ? `in ${edu.field_of_study}` : ''}</div>
                  </div>
                ))}
              </div>
            )}

            {/* All Skills (No Slicing) */}
            {skills.length > 0 && (
              <div>
                <div className="lavender-section-title">SKILLS</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                  {skills.map((s, idx) => {
                    const dotsCount = 4 + (idx % 2);
                    return (
                      <div key={idx} className="lavender-rating-row">
                        <span>{s}</span>
                        <div className="lavender-dots">
                          {[1, 2, 3, 4, 5].map((d) => (
                            <div key={d} className={`lavender-dot ${d <= dotsCount ? 'filled' : ''}`} />
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Languages - Only rendered if user actually has languages */}
            {structuredResume.languages && structuredResume.languages.length > 0 && (
              <div>
                <div className="lavender-section-title">LANGUAGES</div>
                {structuredResume.languages.map((lang, idx) => (
                  <div key={idx} className="lavender-rating-row">
                    <span>{lang}</span>
                    <div className="lavender-dots">
                      <div className="lavender-dot filled" /><div className="lavender-dot filled" /><div className="lavender-dot filled" /><div className="lavender-dot filled" /><div className="lavender-dot filled" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </aside>

        {/* Right Main Content */}
        <main className="lavender-main">
          {(summary || personal_info?.summary) && (
            <div>
              <div className="lavender-main-title">RESUME OBJECTIVE</div>
              <p style={{ fontSize: '0.8rem', lineHeight: 1.6, color: '#334155', margin: 0 }}>
                {summary || personal_info?.summary}
              </p>
            </div>
          )}

          {experience.length > 0 && (
            <div>
              <div className="lavender-main-title">EXPERIENCE & INTERNSHIPS</div>
              {experience.map((exp, idx) => (
                <div key={idx} style={{ marginBottom: '1rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span style={{ fontWeight: 800, fontSize: '0.86rem', color: '#1e1b4b' }}>
                      {exp.role} <span style={{ fontWeight: 400, color: '#6d28d9' }}>— {exp.company}</span>
                    </span>
                    <span style={{ fontSize: '0.7rem', color: '#64748b' }}>{exp.duration}</span>
                  </div>
                  <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', marginTop: '0.3rem' }}>
                    {(exp.bullets || []).map((b, bIdx) => {
                      const isOpt = isBulletOptimized(b);
                      return (
                        <li
                          key={bIdx}
                          className={`resume-doc-bullet ${isOpt && showDiffHighlights ? 'ai-optimized' : ''}`}
                          style={{ fontSize: '0.78rem', marginBottom: '0.2rem', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem' }}
                        >
                          <span style={{ flex: 1 }}>{renderWithLinks(cleanBulletText(b))}</span>
                          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem', flexShrink: 0 }} className="no-print">
                            {isOpt && showDiffHighlights && (
                              <span className="resume-doc-diff-badge" style={{ fontSize: '0.62rem', padding: '0.1rem 0.35rem' }}>
                                <Sparkles size={8} /> AI STAR Impact
                              </span>
                            )}
                            {isOpt && onRevertBullet && (
                              <button
                                type="button"
                                onClick={() => onRevertBullet('experience', exp.id || exp.company, b)}
                                className="btn btn-sm btn-secondary"
                                style={{ padding: '0.1rem 0.35rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                                title="Undo AI enhancement and restore original wording"
                              >
                                <Undo2 size={8} /> Remove
                              </button>
                            )}
                            {onOpenBulletEnhancer && (
                              <button
                                type="button"
                                onClick={() => onOpenBulletEnhancer(
                                  b,
                                  exp.role ? `${exp.role} at ${exp.company}` : exp.company,
                                  undefined,
                                  (newB) => {
                                    const newBullets = [...(exp.bullets || [])];
                                    newBullets[bIdx] = newB;
                                    updateExperienceItem(idx, 'bullets', newBullets);
                                  }
                                )}
                                className="btn btn-sm btn-outline-violet"
                                style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                                title="Improve this bullet point with 3 AI options"
                              >
                                <Wand2 size={8} /> AI Polish
                              </button>
                            )}
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {projects.length > 0 && (
            <div>
              <div className="lavender-main-title">TECHNICAL PROJECTS & ACCOMPLISHMENTS</div>
              {projects.map((prj, idx) => (
                <div key={idx} style={{ marginBottom: '0.85rem' }}>
                  <div style={{ fontWeight: 800, fontSize: '0.84rem', color: '#1e1b4b', display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '0.35rem' }}>
                    <span>{prj.title} {prj.role_or_tech ? <span style={{ fontWeight: 400, color: '#6d28d9' }}>({prj.role_or_tech})</span> : ''}</span>
                    {prj.code_url && formatLink(prj.code_url) && (
                      <a
                        href={formatLink(prj.code_url)}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => handleSafeLinkClick(e, prj.code_url)}
                        style={{ color: '#6d28d9', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}
                      >
                        <Code size={10} /> Code
                      </a>
                    )}
                    {prj.url && formatLink(prj.url) && (
                      <a
                        href={formatLink(prj.url)}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => handleSafeLinkClick(e, prj.url)}
                        style={{ color: '#6d28d9', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}
                      >
                        <Globe size={10} /> Live
                      </a>
                    )}
                  </div>
                  {prj.description && (
                    <p style={{ fontSize: '0.78rem', color: '#475569', margin: '0.15rem 0' }}>
                      {renderWithLinks(prj.description)}
                    </p>
                  )}
                  <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', marginTop: '0.25rem' }}>
                    {(prj.bullets || []).map((b, bIdx) => {
                      const isOpt = isBulletOptimized(b);
                      return (
                        <li
                          key={bIdx}
                          className={`resume-doc-bullet ${isOpt && showDiffHighlights ? 'ai-optimized' : ''}`}
                          style={{ fontSize: '0.78rem', marginBottom: '0.2rem', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem' }}
                        >
                          <span style={{ flex: 1 }}>{renderWithLinks(cleanBulletText(b))}</span>
                          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem', flexShrink: 0 }} className="no-print">
                            {isOpt && showDiffHighlights && (
                              <span className="resume-doc-diff-badge" style={{ fontSize: '0.62rem', padding: '0.1rem 0.35rem' }}>
                                <Sparkles size={8} /> AI STAR Impact
                              </span>
                            )}
                            {isOpt && onRevertBullet && (
                              <button
                                type="button"
                                onClick={() => onRevertBullet('projects', prj.id || prj.title, b)}
                                className="btn btn-sm btn-secondary"
                                style={{ padding: '0.1rem 0.35rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                                title="Undo AI enhancement and restore original wording"
                              >
                                <Undo2 size={8} /> Remove
                              </button>
                            )}
                            {onOpenBulletEnhancer && (
                              <button
                                type="button"
                                onClick={() => onOpenBulletEnhancer(
                                  b,
                                  prj.title,
                                  undefined,
                                  (newB) => {
                                    const newBullets = [...(prj.bullets || [])];
                                    newBullets[bIdx] = newB;
                                    updateProjectItem(idx, 'bullets', newBullets);
                                  }
                                )}
                                className="btn btn-sm btn-outline-violet"
                                style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                                title="Improve this bullet point with 3 AI options"
                              >
                                <Wand2 size={8} /> AI Polish
                              </button>
                            )}
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {portfolio && portfolio.length > 0 && (
            <div>
              <div className="lavender-main-title">PORTFOLIO & LIVE SHOWCASE</div>
              {portfolio.map((port, idx) => (
                <div key={idx} style={{ marginBottom: '0.85rem' }}>
                  <div style={{ fontWeight: 800, fontSize: '0.84rem', color: '#1e1b4b', display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '0.35rem' }}>
                    <span>{port.title} {port.role_or_tech ? <span style={{ fontWeight: 400, color: '#6d28d9' }}>({port.role_or_tech})</span> : ''}</span>
                    {port.code_url && formatLink(port.code_url) && (
                      <a href={formatLink(port.code_url)} target="_blank" rel="noopener noreferrer" onClick={(e) => handleSafeLinkClick(e, port.code_url)} style={{ color: '#6d28d9', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}>
                        <Code size={10} /> Code
                      </a>
                    )}
                    {port.url && formatLink(port.url) && (
                      <a href={formatLink(port.url)} target="_blank" rel="noopener noreferrer" onClick={(e) => handleSafeLinkClick(e, port.url)} style={{ color: '#6d28d9', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}>
                        <Globe size={10} /> Live
                      </a>
                    )}
                  </div>
                  {port.description && <p style={{ fontSize: '0.78rem', color: '#475569', margin: '0.15rem 0' }}>{renderWithLinks(port.description)}</p>}
                  <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', marginTop: '0.25rem' }}>
                    {(port.bullets || []).map((b, bIdx) => (
                      <li key={bIdx} className="resume-doc-bullet" style={{ fontSize: '0.78rem', marginBottom: '0.2rem' }}>
                        {renderWithLinks(cleanBulletText(b))}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {certifications.length > 0 && (
            <div>
              <div className="lavender-main-title">CERTIFICATIONS</div>
              <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', margin: 0 }}>
                {certifications.map((c, idx) => (
                  <li key={idx} className="resume-doc-bullet" style={{ fontSize: '0.78rem', marginBottom: '0.2rem' }}>
                    <strong>{c.name}</strong> {c.issuer ? `— ${c.issuer}` : ''} {c.year ? `(${c.year})` : ''}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </main>
      </article>
    );
  }

  // -------------------------------------------------------------
  // TEMPLATE 3: MIDNIGHT NAVY & GOLD (Jessica Blakely Style)
  // -------------------------------------------------------------
  if (templateId === 'midnight_gold' && !isEditMode) {
    return (
      <article
        className={`resume-document-page template-midnight_gold ${isDarkMode ? 'dark-mode' : ''} ${isEditMode ? 'edit-mode-active' : ''}`}
        id={`resume-document-page-${pageNumber}`}
      >
        {totalPages > 1 && (
          <div className="resume-page-tag no-print">Page {pageNumber} of {totalPages}</div>
        )}

        {/* Top Navy Header Banner */}
        <header className="midnight-header-banner">
          <div className="midnight-banner-top">
            <div>
              <h1 className="midnight-name">{candidateName}</h1>
              {candidateHeadline && (
                <div className="midnight-headline">{candidateHeadline}</div>
              )}
              {(summary || personal_info?.summary) && (
                <div className="midnight-summary-banner">
                  {summary || personal_info?.summary}
                </div>
              )}
            </div>
            <div className="midnight-avatar-circle">
              {nameInitials}
            </div>
          </div>

          <div className="midnight-contact-bar">
            {personal_info?.email && formatMailto(personal_info.email) && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <Mail size={12} color="#fbbf24" />
                <a
                  href={formatMailto(personal_info.email)}
                  style={{ color: '#ffffff', textDecoration: 'underline' }}
                >
                  {sanitizeEmail(personal_info.email)}
                </a>
              </div>
            )}
            {personal_info?.phone && formatTel(personal_info.phone) && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <Phone size={12} color="#fbbf24" />
                <a
                  href={formatTel(personal_info.phone)}
                  style={{ color: '#ffffff', textDecoration: 'none' }}
                >
                  {personal_info.phone}
                </a>
              </div>
            )}
            {personal_info?.location && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <MapPin size={12} color="#fbbf24" />
                <span>{personal_info.location}</span>
              </div>
            )}
            {personal_info?.linkedin && formatSocial(personal_info.linkedin, 'linkedin') && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <Link2 size={12} color="#fbbf24" />
                <a
                  href={formatSocial(personal_info.linkedin, 'linkedin')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.linkedin, 'linkedin'))}
                  style={{ color: '#fbbf24', textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: '0.2rem' }}
                >
                  {getCleanHandle(personal_info.linkedin, 'linkedin')}
                  <ExternalLink size={9} />
                </a>
              </div>
            )}
            {personal_info?.github && formatSocial(personal_info.github, 'github') && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <Code size={12} color="#fbbf24" />
                <a
                  href={formatSocial(personal_info.github, 'github')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.github, 'github'))}
                  style={{ color: '#fbbf24', textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: '0.2rem' }}
                >
                  {getCleanHandle(personal_info.github, 'github')}
                  <ExternalLink size={9} />
                </a>
              </div>
            )}
            {personal_info?.leetcode && formatSocial(personal_info.leetcode, 'leetcode') && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <Terminal size={12} color="#fbbf24" />
                <a
                  href={formatSocial(personal_info.leetcode, 'leetcode')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.leetcode, 'leetcode'))}
                  style={{ color: '#fbbf24', textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: '0.2rem' }}
                >
                  {getCleanHandle(personal_info.leetcode, 'leetcode')}
                  <ExternalLink size={9} />
                </a>
              </div>
            )}
            {personal_info?.codeforces && formatSocial(personal_info.codeforces, 'codeforces') && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <Trophy size={12} color="#fbbf24" />
                <a
                  href={formatSocial(personal_info.codeforces, 'codeforces')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.codeforces, 'codeforces'))}
                  style={{ color: '#fbbf24', textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: '0.2rem' }}
                >
                  {getCleanHandle(personal_info.codeforces, 'codeforces')}
                  <ExternalLink size={9} />
                </a>
              </div>
            )}
            {personal_info?.portfolio && formatSocial(personal_info.portfolio, 'portfolio') && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <Globe size={12} color="#fbbf24" />
                <a
                  href={formatSocial(personal_info.portfolio, 'portfolio')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.portfolio, 'portfolio'))}
                  style={{ color: '#fbbf24', textDecoration: 'underline', display: 'inline-flex', alignItems: 'center', gap: '0.2rem' }}
                >
                  Portfolio
                  <ExternalLink size={9} />
                </a>
              </div>
            )}
          </div>
        </header>

        {/* 2-Column Main Split */}
        <div className="midnight-body-split">
          {/* Left Column (60%) */}
          <div>
            {experience.length > 0 && (
              <div style={{ marginBottom: '1.25rem' }}>
                <div className="midnight-section-title">WORK EXPERIENCE</div>
                {experience.map((exp, idx) => (
                  <div key={idx} style={{ marginBottom: '0.9rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <span style={{ fontWeight: 800, fontSize: '0.88rem', color: '#0f172a' }}>{exp.role}</span>
                      <span style={{ fontSize: '0.7rem', color: '#b45309', fontWeight: 600 }}>{exp.duration}</span>
                    </div>
                    <div style={{ fontSize: '0.78rem', color: '#475569', fontStyle: 'italic', marginBottom: '0.25rem' }}>
                      {exp.company}
                    </div>
                    <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', margin: 0 }}>
                      {(exp.bullets || []).map((b, bIdx) => {
                        const isOpt = isBulletOptimized(b);
                        return (
                          <li
                            key={bIdx}
                            className={`resume-doc-bullet ${isOpt && showDiffHighlights ? 'ai-optimized' : ''}`}
                            style={{ fontSize: '0.78rem', marginBottom: '0.2rem', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem' }}
                          >
                            <span style={{ flex: 1 }}>{renderWithLinks(cleanBulletText(b))}</span>
                            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem', flexShrink: 0 }} className="no-print">
                              {isOpt && showDiffHighlights && (
                                <span className="resume-doc-diff-badge" style={{ fontSize: '0.62rem', padding: '0.1rem 0.35rem' }}>
                                  <Sparkles size={8} /> AI STAR Impact
                                </span>
                              )}
                              {isOpt && onRevertBullet && (
                                <button
                                  type="button"
                                  onClick={() => onRevertBullet('experience', exp.id || exp.company, b)}
                                  className="btn btn-sm btn-secondary"
                                  style={{ padding: '0.1rem 0.35rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                                  title="Undo AI enhancement and restore original wording"
                                >
                                  <Undo2 size={8} /> Remove
                                </button>
                              )}
                              {onOpenBulletEnhancer && (
                                <button
                                  type="button"
                                  onClick={() => onOpenBulletEnhancer(
                                    b,
                                    exp.role ? `${exp.role} at ${exp.company}` : exp.company,
                                    undefined,
                                    (newB) => {
                                      const newBullets = [...(exp.bullets || [])];
                                      newBullets[bIdx] = newB;
                                      updateExperienceItem(idx, 'bullets', newBullets);
                                    }
                                  )}
                                  className="btn btn-sm btn-outline-warning"
                                  style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem', color: '#b45309', borderColor: '#d97706' }}
                                  title="Improve this bullet point with 3 AI options"
                                >
                                  <Wand2 size={8} /> AI Polish
                                </button>
                              )}
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                ))}
              </div>
            )}

            {projects.length > 0 && (
              <div style={{ marginBottom: '1.25rem' }}>
                <div className="midnight-section-title">FEATURED PROJECTS</div>
                {projects.map((prj, idx) => (
                  <div key={idx} style={{ marginBottom: '0.85rem' }}>
                    <div style={{ fontWeight: 800, fontSize: '0.85rem', color: '#0f172a', display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '0.35rem' }}>
                      <span>{prj.title}</span>
                      {prj.code_url && formatLink(prj.code_url) && (
                        <a
                          href={formatLink(prj.code_url)}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => handleSafeLinkClick(e, prj.code_url)}
                          style={{ color: '#b45309', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}
                        >
                          <Code size={10} /> Code
                        </a>
                      )}
                      {prj.url && formatLink(prj.url) && (
                        <a
                          href={formatLink(prj.url)}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => handleSafeLinkClick(e, prj.url)}
                          style={{ color: '#b45309', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}
                        >
                          <Globe size={10} /> Live
                        </a>
                      )}
                    </div>
                    {prj.role_or_tech && <div style={{ fontSize: '0.74rem', color: '#b45309', marginBottom: '0.2rem' }}>{prj.role_or_tech}</div>}
                    {prj.description && (
                      <p style={{ fontSize: '0.78rem', color: '#475569', margin: '0.1rem 0 0.25rem 0' }}>
                        {renderWithLinks(prj.description)}
                      </p>
                    )}
                    <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', margin: 0 }}>
                      {(prj.bullets || []).map((b, bIdx) => {
                        const isOpt = isBulletOptimized(b);
                        return (
                          <li
                            key={bIdx}
                            className={`resume-doc-bullet ${isOpt && showDiffHighlights ? 'ai-optimized' : ''}`}
                            style={{ fontSize: '0.78rem', marginBottom: '0.2rem', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem' }}
                          >
                            <span style={{ flex: 1 }}>{renderWithLinks(cleanBulletText(b))}</span>
                            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem', flexShrink: 0 }} className="no-print">
                              {isOpt && showDiffHighlights && (
                                <span className="resume-doc-diff-badge" style={{ fontSize: '0.62rem', padding: '0.1rem 0.35rem' }}>
                                  <Sparkles size={8} /> AI STAR Impact
                                </span>
                              )}
                              {isOpt && onRevertBullet && (
                                <button
                                  type="button"
                                  onClick={() => onRevertBullet('projects', prj.id || prj.title, b)}
                                  className="btn btn-sm btn-secondary"
                                  style={{ padding: '0.1rem 0.35rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                                  title="Undo AI enhancement and restore original wording"
                                >
                                  <Undo2 size={8} /> Remove
                                </button>
                              )}
                              {onOpenBulletEnhancer && (
                                <button
                                  type="button"
                                  onClick={() => onOpenBulletEnhancer(
                                    b,
                                    prj.title,
                                    undefined,
                                    (newB) => {
                                      const newBullets = [...(prj.bullets || [])];
                                      newBullets[bIdx] = newB;
                                      updateProjectItem(idx, 'bullets', newBullets);
                                    }
                                  )}
                                  className="btn btn-sm btn-outline-warning"
                                  style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem', color: '#b45309', borderColor: '#d97706' }}
                                  title="Improve this bullet point with 3 AI options"
                                >
                                  <Wand2 size={8} /> AI Polish
                                </button>
                              )}
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                ))}
              </div>
            )}

            {portfolio && portfolio.length > 0 && (
              <div style={{ marginBottom: '1.25rem' }}>
                <div className="midnight-section-title">PORTFOLIO SHOWCASE</div>
                {portfolio.map((port, idx) => (
                  <div key={idx} style={{ marginBottom: '0.85rem' }}>
                    <div style={{ fontWeight: 800, fontSize: '0.85rem', color: '#0f172a', display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '0.35rem' }}>
                      <span>{port.title}</span>
                      {port.code_url && formatLink(port.code_url) && (
                        <a href={formatLink(port.code_url)} target="_blank" rel="noopener noreferrer" onClick={(e) => handleSafeLinkClick(e, port.code_url)} style={{ color: '#b45309', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}>
                          <Code size={10} /> Code
                        </a>
                      )}
                      {port.url && formatLink(port.url) && (
                        <a href={formatLink(port.url)} target="_blank" rel="noopener noreferrer" onClick={(e) => handleSafeLinkClick(e, port.url)} style={{ color: '#b45309', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}>
                          <Globe size={10} /> Live
                        </a>
                      )}
                    </div>
                    {port.role_or_tech && <div style={{ fontSize: '0.74rem', color: '#b45309', marginBottom: '0.2rem' }}>{port.role_or_tech}</div>}
                    {port.description && <p style={{ fontSize: '0.78rem', color: '#475569', margin: '0.1rem 0' }}>{renderWithLinks(port.description)}</p>}
                    <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', margin: 0 }}>
                      {(port.bullets || []).map((b, bIdx) => (
                        <li key={bIdx} className="resume-doc-bullet" style={{ fontSize: '0.78rem', marginBottom: '0.2rem' }}>
                          {renderWithLinks(cleanBulletText(b))}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            )}

            {certifications.length > 0 && (
              <div>
                <div className="midnight-section-title">CERTIFICATES</div>
                <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', margin: 0 }}>
                  {certifications.map((c, idx) => (
                    <li key={idx} className="resume-doc-bullet" style={{ fontSize: '0.78rem', marginBottom: '0.2rem' }}>
                      <strong>{c.name}</strong> {c.issuer ? `— ${c.issuer}` : ''} {c.year ? `(${c.year})` : ''}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Right Column (40%) */}
          <div>
            {/* All Skills (No Slicing) */}
            {skills.length > 0 && (
              <div style={{ marginBottom: '1.25rem' }}>
                <div className="midnight-section-title">HARD SKILLS</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                  {skills.map((s, idx) => (
                    <span key={idx} className="midnight-navy-pill">{s}</span>
                  ))}
                </div>
              </div>
            )}

            {education.length > 0 && (
              <div style={{ marginBottom: '1.25rem' }}>
                <div className="midnight-section-title">EDUCATION</div>
                {education.map((edu, idx) => (
                  <div key={idx} style={{ marginBottom: '0.65rem' }}>
                    <div style={{ fontWeight: 800, fontSize: '0.82rem', color: '#0f172a' }}>
                      {edu.degree} {edu.field_of_study ? `in ${edu.field_of_study}` : ''}
                    </div>
                    <div style={{ fontSize: '0.74rem', color: '#475569' }}>{edu.institution}</div>
                    <div style={{ fontSize: '0.68rem', color: '#b45309' }}>
                      {edu.end_year ? (edu.start_year ? `${edu.start_year} - ${edu.end_year}` : edu.end_year) : (edu.start_year || '')}
                      {edu.grade_or_cgpa ? ` • ${edu.grade_or_cgpa}` : ''}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Languages - Only rendered if user has languages */}
            {structuredResume.languages && structuredResume.languages.length > 0 && (
              <div>
                <div className="midnight-section-title">LANGUAGES</div>
                <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
                  {structuredResume.languages.map((lang, idx) => (
                    <span key={idx} className="midnight-navy-pill">{lang}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </article>
    );
  }

  // -------------------------------------------------------------
  // TEMPLATE 4: GOLDEN MODERN EXECUTIVE (Joshua Freedman Style)
  // -------------------------------------------------------------
  if (templateId === 'executive_yellow' && !isEditMode) {
    return (
      <article
        className={`resume-document-page template-executive_yellow ${isDarkMode ? 'dark-mode' : ''} ${isEditMode ? 'edit-mode-active' : ''}`}
        id={`resume-document-page-${pageNumber}`}
      >
        {totalPages > 1 && (
          <div className="resume-page-tag no-print">Page {pageNumber} of {totalPages}</div>
        )}

        {/* Hero Top with Yellow Circle Badge */}
        <header className="exec-yellow-hero">
          <div>
            <h1 className="exec-yellow-name">{candidateName}</h1>
            {candidateHeadline && (
              <div className="exec-yellow-title-badge">
                {candidateHeadline}
              </div>
            )}
            <div style={{ fontSize: '0.85rem', color: '#475569', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
              <Sparkles size={13} color="#ca8a04" />
              <span>Verified Placement Ready Profile • Employ.AI</span>
            </div>
          </div>
          <div className="exec-yellow-circle-frame">
            {nameInitials}
          </div>
        </header>

        {/* 2 Balanced Executive Columns */}
        <div className="exec-yellow-grid">
          {/* Left Column: Education & Experience */}
          <div className="exec-yellow-col">
            {/* Card 1: Education & Credentials */}
            <div className="exec-yellow-card">
              <div className="exec-yellow-card-header">
                <div className="exec-yellow-icon-badge"><GraduationCap size={18} /></div>
                <h3 className="exec-yellow-card-title">Education & Credentials</h3>
              </div>
              {education.map((edu, idx) => (
                <div key={idx} style={{ fontSize: '0.78rem', color: '#334155', marginBottom: '0.4rem' }}>
                  <strong>{idx + 1}. {edu.degree} {edu.field_of_study ? `in ${edu.field_of_study}` : ''}</strong>
                  <div style={{ color: '#64748b', fontSize: '0.72rem' }}>
                    {edu.institution} {edu.end_year ? `(${edu.end_year})` : (edu.start_year ? `(${edu.start_year})` : '')} {edu.grade_or_cgpa ? `• ${edu.grade_or_cgpa}` : ''}
                  </div>
                </div>
              ))}
            </div>

            {/* Card 3: Experience & Key Achievements (All bullets mapped) */}
            {experience.length > 0 && (
              <div className="exec-yellow-card">
                <div className="exec-yellow-card-header">
                  <div className="exec-yellow-icon-badge"><Award size={18} /></div>
                  <h3 className="exec-yellow-card-title">Career Milestones & Roles</h3>
                </div>
                {experience.map((exp, idx) => (
                  <div key={idx} style={{ fontSize: '0.78rem', color: '#334155', marginBottom: '0.6rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <strong>{exp.role}</strong>
                      <span style={{ color: '#64748b', fontSize: '0.7rem' }}>{exp.duration}</span>
                    </div>
                    <div style={{ color: '#475569', fontSize: '0.74rem', fontStyle: 'italic', marginBottom: '0.2rem' }}>
                      {exp.company}
                    </div>
                    <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', margin: '0.2rem 0 0 0' }}>
                      {(exp.bullets || []).map((b, bIdx) => {
                        const isOpt = isBulletOptimized(b);
                        return (
                          <li key={bIdx} className={`resume-doc-bullet ${isOpt && showDiffHighlights ? 'ai-optimized' : ''}`} style={{ fontSize: '0.74rem', marginBottom: '0.15rem' }}>
                            {renderWithLinks(cleanBulletText(b))}
                            {isOpt && showDiffHighlights && (
                              <span className="resume-doc-diff-badge" style={{ fontSize: '0.58rem', padding: '0.05rem 0.3rem', marginLeft: '0.3rem' }}>
                                <Sparkles size={8} /> AI STAR
                              </span>
                            )}
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Skills & Projects */}
          <div className="exec-yellow-col">
            {/* Card 2: Core Competencies & Skills (All skills rendered) */}
            <div className="exec-yellow-card">
              <div className="exec-yellow-card-header">
                <div className="exec-yellow-icon-badge"><Briefcase size={18} /></div>
                <h3 className="exec-yellow-card-title">Core Competencies & Skills</h3>
              </div>
              {(summary || personal_info?.summary) && (
                <p style={{ fontSize: '0.78rem', color: '#334155', lineHeight: 1.5, margin: '0 0 0.5rem 0' }}>
                  {summary || personal_info?.summary}
                </p>
              )}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.3rem' }}>
                {skills.map((s, idx) => (
                  <span key={idx} style={{ background: '#fef08a', color: '#713f12', padding: '0.2rem 0.5rem', borderRadius: '4px', fontSize: '0.7rem', fontWeight: 700 }}>
                    {s}
                  </span>
                ))}
              </div>
            </div>

            {/* Card 4: Technical Projects & Initiatives (All bullets mapped) */}
            {projects.length > 0 && (
              <div className="exec-yellow-card">
                <div className="exec-yellow-card-header">
                  <div className="exec-yellow-icon-badge"><User size={18} /></div>
                  <h3 className="exec-yellow-card-title">Projects & Portfolio</h3>
                </div>
                {projects.map((prj, idx) => (
                  <div key={idx} style={{ fontSize: '0.78rem', color: '#334155', marginBottom: '0.6rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '0.35rem' }}>
                      <strong>{prj.title}</strong> {prj.role_or_tech ? `(${prj.role_or_tech})` : ''}
                      {prj.code_url && formatLink(prj.code_url) && (
                        <a href={formatLink(prj.code_url)} target="_blank" rel="noopener noreferrer" onClick={(e) => handleSafeLinkClick(e, prj.code_url)} style={{ color: '#854d0e', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}>
                          <Code size={10} /> Code
                        </a>
                      )}
                      {prj.url && formatLink(prj.url) && (
                        <a href={formatLink(prj.url)} target="_blank" rel="noopener noreferrer" onClick={(e) => handleSafeLinkClick(e, prj.url)} style={{ color: '#854d0e', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}>
                          <Globe size={10} /> Live
                        </a>
                      )}
                    </div>
                    {prj.description && (
                      <div style={{ fontSize: '0.73rem', color: '#475569', margin: '0.1rem 0' }}>
                        {renderWithLinks(prj.description)}
                      </div>
                    )}
                    <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', margin: '0.2rem 0 0 0' }}>
                      {(prj.bullets || []).map((b, bIdx) => {
                        const isOpt = isBulletOptimized(b);
                        return (
                          <li key={bIdx} className={`resume-doc-bullet ${isOpt && showDiffHighlights ? 'ai-optimized' : ''}`} style={{ fontSize: '0.74rem', marginBottom: '0.15rem' }}>
                            {renderWithLinks(cleanBulletText(b))}
                            {isOpt && showDiffHighlights && (
                              <span className="resume-doc-diff-badge" style={{ fontSize: '0.58rem', padding: '0.05rem 0.3rem', marginLeft: '0.3rem' }}>
                                <Sparkles size={8} /> AI STAR
                              </span>
                            )}
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Additional Sections: Portfolio & Certifications for Executive Yellow */}
        {portfolio && portfolio.length > 0 && (
          <div className="exec-yellow-card" style={{ marginTop: '1rem' }}>
            <div className="exec-yellow-card-header">
              <div className="exec-yellow-icon-badge"><Globe size={18} /></div>
              <h3 className="exec-yellow-card-title">Portfolio & Live Showcase</h3>
            </div>
            {portfolio.map((port, idx) => (
              <div key={idx} style={{ fontSize: '0.78rem', color: '#334155', marginBottom: '0.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '0.35rem' }}>
                  <strong>{port.title}</strong> {port.role_or_tech ? `(${port.role_or_tech})` : ''}
                  {port.code_url && formatLink(port.code_url) && (
                    <a href={formatLink(port.code_url)} target="_blank" rel="noopener noreferrer" onClick={(e) => handleSafeLinkClick(e, port.code_url)} style={{ color: '#854d0e', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}>
                      <Code size={10} /> Code
                    </a>
                  )}
                  {port.url && formatLink(port.url) && (
                    <a href={formatLink(port.url)} target="_blank" rel="noopener noreferrer" onClick={(e) => handleSafeLinkClick(e, port.url)} style={{ color: '#854d0e', fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.15rem' }}>
                      <Globe size={10} /> Live
                    </a>
                  )}
                </div>
                {port.description && <p style={{ fontSize: '0.73rem', color: '#475569', margin: '0.1rem 0' }}>{renderWithLinks(port.description)}</p>}
                <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', margin: '0.15rem 0 0 0' }}>
                  {(port.bullets || []).map((b, bIdx) => (
                    <li key={bIdx} className="resume-doc-bullet" style={{ fontSize: '0.74rem', marginBottom: '0.15rem' }}>
                      {renderWithLinks(cleanBulletText(b))}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}

        {certifications.length > 0 && (
          <div className="exec-yellow-card" style={{ marginTop: '1rem' }}>
            <div className="exec-yellow-card-header">
              <div className="exec-yellow-icon-badge"><Award size={18} /></div>
              <h3 className="exec-yellow-card-title">Certifications & Accreditations</h3>
            </div>
            <ul className="resume-doc-bullets" style={{ paddingLeft: '1.2rem', margin: 0 }}>
              {certifications.map((c, idx) => (
                <li key={idx} className="resume-doc-bullet" style={{ fontSize: '0.76rem', marginBottom: '0.2rem' }}>
                  <strong>{c.name}</strong> {c.issuer ? `— ${c.issuer}` : ''} {c.year ? `(${c.year})` : ''}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Languages - Only rendered if candidate has languages */}
        {structuredResume.languages && structuredResume.languages.length > 0 && (
          <div style={{ marginTop: '0.85rem', display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '0.72rem', fontWeight: 800, color: '#713f12', textTransform: 'uppercase' }}>Languages:</span>
            {structuredResume.languages.map((lang, idx) => (
              <span key={idx} style={{ background: '#fef08a', color: '#713f12', padding: '0.15rem 0.45rem', borderRadius: '4px', fontSize: '0.7rem', fontWeight: 700 }}>
                {lang}
              </span>
            ))}
          </div>
        )}

        {/* Footer 2-Column Contact */}
        <footer className="exec-yellow-footer">
          {personal_info?.email && formatMailto(personal_info.email) && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <div className="exec-yellow-icon-badge" style={{ width: 22, height: 22 }}><Mail size={12} /></div>
              <a
                href={formatMailto(personal_info.email)}
                style={{ color: '#0f172a', fontWeight: 600, textDecoration: 'underline' }}
              >
                {sanitizeEmail(personal_info.email)}
              </a>
            </div>
          )}
          {personal_info?.phone && formatTel(personal_info.phone) && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <div className="exec-yellow-icon-badge" style={{ width: 22, height: 22 }}><Phone size={12} /></div>
              <a
                href={formatTel(personal_info.phone)}
                style={{ color: '#0f172a', fontWeight: 600, textDecoration: 'none' }}
              >
                {personal_info.phone}
              </a>
            </div>
          )}
          {personal_info?.linkedin && formatSocial(personal_info.linkedin, 'linkedin') && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <div className="exec-yellow-icon-badge" style={{ width: 22, height: 22 }}><Link2 size={12} /></div>
              <a
                href={formatSocial(personal_info.linkedin, 'linkedin')}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.linkedin, 'linkedin'))}
                style={{ color: '#0f172a', fontWeight: 600, textDecoration: 'underline' }}
              >
                {getCleanHandle(personal_info.linkedin, 'linkedin')}
              </a>
            </div>
          )}
          {personal_info?.github && formatSocial(personal_info.github, 'github') && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <div className="exec-yellow-icon-badge" style={{ width: 22, height: 22 }}><Code size={12} /></div>
              <a
                href={formatSocial(personal_info.github, 'github')}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.github, 'github'))}
                style={{ color: '#0f172a', fontWeight: 600, textDecoration: 'underline' }}
              >
                {getCleanHandle(personal_info.github, 'github')}
              </a>
            </div>
          )}
          {personal_info?.portfolio && formatSocial(personal_info.portfolio, 'portfolio') && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <div className="exec-yellow-icon-badge" style={{ width: 22, height: 22 }}><Globe size={12} /></div>
              <a
                href={formatSocial(personal_info.portfolio, 'portfolio')}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.portfolio, 'portfolio'))}
                style={{ color: '#0f172a', fontWeight: 600, textDecoration: 'underline' }}
              >
                Portfolio
              </a>
            </div>
          )}
          {personal_info?.location && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <div className="exec-yellow-icon-badge" style={{ width: 22, height: 22 }}><MapPin size={12} /></div>
              <span>{personal_info.location}</span>
            </div>
          )}
        </footer>
      </article>
    );
  }

  // -------------------------------------------------------------
  // DEFAULT STANDARD TEMPLATE (ATS Classic, Modern, Professional, Minimal, Executive, Student Fresher)
  // -------------------------------------------------------------
  return (
    <article 
      className={`resume-document-page template-${templateId} ${isDarkMode ? 'dark-mode' : ''} ${isEditMode ? 'edit-mode-active' : ''}`}
      id={`resume-document-page-${pageNumber}`}
    >
      {/* Page Badge Indicator for Studio preview */}
      {totalPages > 1 && (
        <div className="resume-page-tag no-print">
          Page {pageNumber} of {totalPages}
        </div>
      )}

      {/* 1. DOCUMENT HEADER: PERSONAL INFO & CONTACTS */}
      <header className="resume-doc-header">
        {isEditMode ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem', marginBottom: '0.6rem' }}>
            <input
              type="text"
              value={personal_info?.full_name || ''}
              onChange={(e) => updatePersonalInfo('full_name', e.target.value)}
              className="resume-doc-input"
              style={{ fontSize: '1.65rem', fontWeight: 800, textAlign: 'center', color: isDarkMode ? '#f8fafc' : '#0f172a' }}
              placeholder="Candidate Full Name"
            />
            <input
              type="text"
              value={candidateHeadline || ''}
              onChange={(e) => updatePersonalInfo('headline', e.target.value)}
              className="resume-doc-input"
              style={{ fontSize: '1rem', fontWeight: 600, textAlign: 'center', color: '#0284c7' }}
              placeholder="Candidate Role / Professional Headline (e.g. AI/ML Engineer | Software Developer)"
            />
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: '0.4rem' }}>
              <input
                type="text"
                value={personal_info?.email || ''}
                onChange={(e) => updatePersonalInfo('email', e.target.value)}
                className="resume-doc-input"
                placeholder="Email Address"
              />
              <input
                type="text"
                value={personal_info?.phone || ''}
                onChange={(e) => updatePersonalInfo('phone', e.target.value)}
                className="resume-doc-input"
                placeholder="Phone Number"
              />
              <input
                type="text"
                value={personal_info?.location || ''}
                onChange={(e) => updatePersonalInfo('location', e.target.value)}
                className="resume-doc-input"
                placeholder="Location (City, Country)"
              />
              <input
                type="text"
                value={personal_info?.linkedin || ''}
                onChange={(e) => updatePersonalInfo('linkedin', e.target.value)}
                className="resume-doc-input"
                placeholder="LinkedIn URL"
              />
              <input
                type="text"
                value={personal_info?.github || ''}
                onChange={(e) => updatePersonalInfo('github', e.target.value)}
                className="resume-doc-input"
                placeholder="GitHub URL"
              />
              <input
                type="text"
                value={personal_info?.leetcode || ''}
                onChange={(e) => updatePersonalInfo('leetcode', e.target.value)}
                className="resume-doc-input"
                placeholder="LeetCode URL"
              />
              <input
                type="text"
                value={personal_info?.portfolio || ''}
                onChange={(e) => updatePersonalInfo('portfolio', e.target.value)}
                className="resume-doc-input"
                placeholder="Portfolio URL"
              />
            </div>
          </div>
        ) : (
          <>
            <h1 className="resume-doc-name">
              {personal_info?.full_name || 'Candidate Name'}
            </h1>
            {candidateHeadline && (
              <div className="resume-doc-headline" style={{ display: 'flex', alignItems: 'center', justifyContent: templateId === 'professional' || templateId === 'minimal' || templateId === 'student_fresher' ? 'flex-start' : 'center', gap: '0.4rem' }}>
                <span>{candidateHeadline}</span>
                {onOpenHeadlineEnhancer && !isEditMode && (
                  <button
                    type="button"
                    onClick={onOpenHeadlineEnhancer}
                    className="btn btn-sm btn-ghost no-print"
                    style={{ fontSize: '0.65rem', padding: '0.1rem 0.35rem', color: '#0284c7', border: '1px solid rgba(2, 132, 199, 0.3)', borderRadius: '4px', display: 'inline-flex', alignItems: 'center', gap: '0.2rem' }}
                    title="Generate professional headline options with AI"
                  >
                    <Wand2 size={9} /> AI Headline
                  </button>
                )}
              </div>
            )}
            {!candidateHeadline && onOpenHeadlineEnhancer && !isEditMode && (
              <div style={{ textAlign: templateId === 'professional' || templateId === 'minimal' || templateId === 'student_fresher' ? 'left' : 'center', marginBottom: '0.4rem' }} className="no-print">
                <button
                  type="button"
                  onClick={onOpenHeadlineEnhancer}
                  className="btn btn-sm btn-outline-cyan"
                  style={{ fontSize: '0.68rem', padding: '0.15rem 0.45rem', display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}
                >
                  <Wand2 size={10} /> Add AI Headline
                </button>
              </div>
            )}
            <div className="resume-doc-contacts">
              {personal_info?.email && formatMailto(personal_info.email) && (
                <a href={formatMailto(personal_info.email)} className="resume-doc-contact-item" title="Send Email">
                  <Mail size={12} color="#0284c7" />
                  <span>{sanitizeEmail(personal_info.email)}</span>
                </a>
              )}
              {personal_info?.phone && formatTel(personal_info.phone) && (
                <a href={formatTel(personal_info.phone)} className="resume-doc-contact-item" title="Call Phone">
                  <Phone size={12} color="#10b981" />
                  <span>{personal_info.phone}</span>
                </a>
              )}
              {personal_info?.location && (
                <span className="resume-doc-contact-item">
                  <MapPin size={12} color="#f59e0b" />
                  <span>{personal_info.location}</span>
                </span>
              )}
              {personal_info?.linkedin && formatSocial(personal_info.linkedin, 'linkedin') && (
                <a
                  href={formatSocial(personal_info.linkedin, 'linkedin')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.linkedin, 'linkedin'))}
                  className="resume-doc-contact-item interactive-link"
                  title="Open LinkedIn Profile"
                >
                  <Link2 size={12} color="#0284c7" />
                  <span>LinkedIn: {getCleanHandle(personal_info.linkedin, 'linkedin')}</span>
                  <ExternalLink size={10} style={{ opacity: 0.7 }} />
                </a>
              )}
              {personal_info?.github && formatSocial(personal_info.github, 'github') && (
                <a
                  href={formatSocial(personal_info.github, 'github')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.github, 'github'))}
                  className="resume-doc-contact-item interactive-link"
                  title="Open GitHub Profile"
                >
                  <Code size={12} color="#64748b" />
                  <span>GitHub: {getCleanHandle(personal_info.github, 'github')}</span>
                  <ExternalLink size={10} style={{ opacity: 0.7 }} />
                </a>
              )}
              {personal_info?.leetcode && formatSocial(personal_info.leetcode, 'leetcode') && (
                <a
                  href={formatSocial(personal_info.leetcode, 'leetcode')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.leetcode, 'leetcode'))}
                  className="resume-doc-contact-item interactive-link"
                  title="Open LeetCode Profile"
                >
                  <Terminal size={12} color="#f59e0b" />
                  <span>LeetCode: {getCleanHandle(personal_info.leetcode, 'leetcode')}</span>
                  <ExternalLink size={10} style={{ opacity: 0.7 }} />
                </a>
              )}
              {personal_info?.codeforces && formatSocial(personal_info.codeforces, 'codeforces') && (
                <a
                  href={formatSocial(personal_info.codeforces, 'codeforces')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.codeforces, 'codeforces'))}
                  className="resume-doc-contact-item interactive-link"
                  title="Open Codeforces"
                >
                  <Trophy size={12} color="#3b82f6" />
                  <span>Codeforces: {getCleanHandle(personal_info.codeforces, 'codeforces')}</span>
                  <ExternalLink size={10} style={{ opacity: 0.7 }} />
                </a>
              )}
              {personal_info?.portfolio && formatSocial(personal_info.portfolio, 'portfolio') && (
                <a
                  href={formatSocial(personal_info.portfolio, 'portfolio')}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => handleSafeLinkClick(e, formatSocial(personal_info.portfolio, 'portfolio'))}
                  className="resume-doc-contact-item interactive-link"
                  title="Open Portfolio Website"
                >
                  <Globe size={12} color="#06b6d4" />
                  <span>Portfolio</span>
                  <ExternalLink size={10} style={{ opacity: 0.7 }} />
                </a>
              )}
            </div>
          </>
        )}
      </header>

      {/* 2. PROFESSIONAL SUMMARY */}
      {(summary || personal_info?.summary || isEditMode) && (
        <section className="resume-doc-section">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
            <h2 className="resume-doc-section-title" style={{ margin: 0 }}>Professional Summary</h2>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }} className="no-print">
              {onOpenSummaryEnhancer && !isEditMode && (
                <button
                  type="button"
                  onClick={onOpenSummaryEnhancer}
                  className="btn btn-emerald btn-sm"
                  style={{ padding: '0.15rem 0.45rem', fontSize: '0.65rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                  title="Improve Summary with 3 AI alternatives"
                >
                  <Wand2 size={10} /> Improve Summary
                </button>
              )}
              {onRevertSummary && !isEditMode && (editHistory.some(h => h.section === 'summary') || (originalStructuredResume?.summary && summary !== originalStructuredResume.summary)) && (
                <button
                  type="button"
                  onClick={onRevertSummary}
                  className="btn btn-secondary btn-sm"
                  style={{ padding: '0.15rem 0.45rem', fontSize: '0.65rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                  title="Undo AI suggestion and restore original summary"
                >
                  <Undo2 size={10} /> Remove AI Summary
                </button>
              )}
            </div>
          </div>
          {isEditMode ? (
            <textarea
              rows={3}
              value={summary || personal_info?.summary || ''}
              onChange={(e) => updateSummary(e.target.value)}
              className="resume-doc-input"
              style={{ width: '100%', lineHeight: 1.5 }}
              placeholder="Executive / Professional summary highlighting your technical strengths and background..."
            />
          ) : (
            <p className="resume-doc-summary-text">
              {summary || personal_info?.summary}
            </p>
          )}
        </section>
      )}

      {/* 3. CORE COMPETENCIES & SKILLS */}
      {(skills.length > 0 || isEditMode) && (
        <section className="resume-doc-section">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
            <h2 className="resume-doc-section-title" style={{ margin: 0 }}>Core Competencies & Skills</h2>
            <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }} className="no-print">
              ({skills.length} skills listed)
            </span>
          </div>

          <div className="resume-doc-skills-wrap">
            {skills.map((skill, idx) => (
              <span key={idx} className="resume-doc-skill-pill" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}>
                {skill}
                {isEditMode && (
                  <button
                    type="button"
                    onClick={() => handleRemoveSkill(skill)}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: '#fb7185',
                      cursor: 'pointer',
                      fontWeight: 800,
                      fontSize: '0.9rem',
                      lineHeight: 1,
                      padding: 0
                    }}
                    title="Remove skill"
                  >
                    ×
                  </button>
                )}
              </span>
            ))}
          </div>

          {isEditMode && (
            <div style={{ display: 'flex', gap: '0.4rem', marginTop: '0.5rem', alignItems: 'center' }}>
              <input
                type="text"
                value={newSkillInput}
                onChange={(e) => setNewSkillInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSkill())}
                placeholder="Type new skill & press Enter (e.g. Docker, PyTorch, GD&T)..."
                className="resume-doc-input"
                style={{ maxWidth: '320px', fontSize: '0.75rem' }}
              />
              <button
                type="button"
                onClick={() => handleAddSkill()}
                className="btn btn-emerald btn-sm"
                style={{ padding: '0.25rem 0.6rem', fontSize: '0.72rem' }}
              >
                <Plus size={12} /> Add Skill
              </button>
            </div>
          )}
        </section>
      )}

      {/* 4. PROFESSIONAL EXPERIENCE */}
      {(experience.length > 0 || isEditMode) && (
        <section className="resume-doc-section">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
            <h2 className="resume-doc-section-title" style={{ margin: 0 }}>Professional Experience & Internships</h2>
            {isEditMode && (
              <button
                type="button"
                onClick={addExperienceItem}
                className="btn btn-emerald btn-sm"
                style={{ padding: '0.2rem 0.5rem', fontSize: '0.7rem' }}
              >
                <Plus size={11} /> Add Experience
              </button>
            )}
          </div>

          <div>
            {experience.map((exp, eIdx) => (
              <div key={exp.id || eIdx} className="resume-doc-item" style={{ position: 'relative', marginBottom: isEditMode ? '1.25rem' : '0.75rem' }}>
                {isEditMode ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem', marginBottom: '0.4rem', background: 'rgba(56, 189, 248, 0.04)', padding: '0.5rem', borderRadius: '6px', border: '1px solid rgba(56, 189, 248, 0.15)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.4rem' }}>
                      <input
                        type="text"
                        value={exp.role || ''}
                        onChange={(e) => updateExperienceItem(eIdx, 'role', e.target.value)}
                        className="resume-doc-input"
                        placeholder="Job Title / Role"
                        style={{ fontWeight: 700, flex: 1 }}
                      />
                      <input
                        type="text"
                        value={exp.company || ''}
                        onChange={(e) => updateExperienceItem(eIdx, 'company', e.target.value)}
                        className="resume-doc-input"
                        placeholder="Company / Organization"
                        style={{ flex: 1 }}
                      />
                      <input
                        type="text"
                        value={exp.duration || ''}
                        onChange={(e) => updateExperienceItem(eIdx, 'duration', e.target.value)}
                        className="resume-doc-input"
                        placeholder="Duration (e.g. Jun 2025 - Aug 2025)"
                        style={{ width: '180px' }}
                      />
                      <button
                        type="button"
                        onClick={() => deleteExperienceItem(eIdx)}
                        className="btn btn-outline-danger btn-sm"
                        style={{ padding: '0.25rem 0.45rem' }}
                        title="Delete this experience entry"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="resume-doc-item-header">
                    <span className="resume-doc-item-role">
                      {exp.role} <span style={{ fontWeight: 400, opacity: 0.6 }}>|</span> <span className="resume-doc-item-company">{exp.company}</span>
                    </span>
                    <span className="resume-doc-item-dates">{exp.duration}</span>
                  </div>
                )}

                {/* Bullets */}
                <ul className="resume-doc-bullets">
                  {(exp.bullets || []).map((bullet, bIdx) => {
                    const isOpt = isBulletOptimized(bullet);
                    return isEditMode ? (
                      <div key={bIdx} style={{ display: 'flex', gap: '0.35rem', marginBottom: '0.35rem', alignItems: 'center' }}>
                        <span style={{ color: 'var(--text-muted)' }}>•</span>
                        <input
                          type="text"
                          value={bullet}
                          onChange={(e) => {
                            const newBullets = [...(exp.bullets || [])];
                            newBullets[bIdx] = e.target.value;
                            updateExperienceItem(eIdx, 'bullets', newBullets);
                          }}
                          className="resume-doc-input"
                          style={{ flex: 1, fontSize: '0.75rem' }}
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const newBullets = (exp.bullets || []).filter((_, i) => i !== bIdx);
                            updateExperienceItem(eIdx, 'bullets', newBullets);
                          }}
                          style={{ background: 'none', border: 'none', color: '#fb7185', cursor: 'pointer', padding: '0.2rem' }}
                          title="Delete bullet"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    ) : (
                      <li
                        key={bIdx}
                        className={`resume-doc-bullet ${isOpt && showDiffHighlights ? 'ai-optimized' : ''}`}
                        style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem' }}
                      >
                        <span style={{ flex: 1 }}>{renderWithLinks(cleanBulletText(bullet))}</span>
                        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', flexShrink: 0 }} className="no-print">
                          {isOpt && showDiffHighlights && (
                            <span className="resume-doc-diff-badge">
                              <Sparkles size={9} /> AI STAR Impact
                            </span>
                          )}
                          {isOpt && onRevertBullet && (
                            <button
                              type="button"
                              onClick={() => onRevertBullet('experience', exp.id || exp.company, bullet)}
                              className="btn btn-sm btn-secondary"
                              style={{ padding: '0.1rem 0.35rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                              title="Undo AI enhancement and restore original wording"
                            >
                              <Undo2 size={9} /> Remove
                            </button>
                          )}
                          {onOpenBulletEnhancer ? (
                            <button
                              type="button"
                              onClick={() => onOpenBulletEnhancer(
                                bullet,
                                exp.role ? `${exp.role} at ${exp.company}` : exp.company,
                                undefined,
                                (newB) => {
                                  const newBullets = [...(exp.bullets || [])];
                                  newBullets[bIdx] = newB;
                                  updateExperienceItem(eIdx, 'bullets', newBullets);
                                }
                              )}
                              className="btn btn-sm btn-outline-emerald"
                              style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                              title="Improve this bullet point with 3 AI options"
                            >
                              <Wand2 size={9} /> AI Polish
                            </button>
                          ) : onOpenEnhancer ? (
                            <button
                              type="button"
                              onClick={() => onOpenEnhancer('experience', exp.id || exp.company, bullet, 'Rewrite with strong action verbs and quantifiable STAR impact.')}
                              className="btn btn-sm btn-outline-violet"
                              style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2 }}
                              title="Enhance wording with AI"
                            >
                              <Wand2 size={9} /> AI Enhance
                            </button>
                          ) : null}
                        </div>
                      </li>
                    );
                  })}
                </ul>

                {isEditMode && (
                  <button
                    type="button"
                    onClick={() => addExperienceBullet(eIdx)}
                    className="btn btn-secondary btn-sm"
                    style={{ padding: '0.15rem 0.45rem', fontSize: '0.68rem', marginTop: '0.2rem' }}
                  >
                    <Plus size={10} /> Add Bullet
                  </button>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 5. PROJECTS */}
      {(projects.length > 0 || isEditMode) && (
        <section className="resume-doc-section">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
            <h2 className="resume-doc-section-title" style={{ margin: 0 }}>Projects & Technical Initiatives</h2>
            {isEditMode && (
              <button
                type="button"
                onClick={addProjectItem}
                className="btn btn-emerald btn-sm"
                style={{ padding: '0.2rem 0.5rem', fontSize: '0.7rem' }}
              >
                <Plus size={11} /> Add Project
              </button>
            )}
          </div>

          <div>
            {projects.map((proj, pIdx) => (
              <div key={proj.id || pIdx} className="resume-doc-item" style={{ position: 'relative', marginBottom: isEditMode ? '1.25rem' : '0.75rem' }}>
                {isEditMode ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem', marginBottom: '0.4rem', background: 'rgba(16, 185, 129, 0.04)', padding: '0.5rem', borderRadius: '6px', border: '1px solid rgba(16, 185, 129, 0.15)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.4rem' }}>
                      <input
                        type="text"
                        value={proj.title || ''}
                        onChange={(e) => updateProjectItem(pIdx, 'title', e.target.value)}
                        className="resume-doc-input"
                        placeholder="Project Title"
                        style={{ fontWeight: 700, flex: 1 }}
                      />
                      <input
                        type="text"
                        value={proj.role_or_tech || (proj.technologies || []).join(', ') || ''}
                        onChange={(e) => updateProjectItem(pIdx, 'role_or_tech', e.target.value)}
                        className="resume-doc-input"
                        placeholder="Technologies / Tech Stack"
                        style={{ flex: 1 }}
                      />
                      <input
                        type="text"
                        value={proj.duration || ''}
                        onChange={(e) => updateProjectItem(pIdx, 'duration', e.target.value)}
                        className="resume-doc-input"
                        placeholder="Year / Duration"
                        style={{ width: '130px' }}
                      />
                      <button
                        type="button"
                        onClick={() => deleteProjectItem(pIdx)}
                        className="btn btn-outline-danger btn-sm"
                        style={{ padding: '0.25rem 0.45rem' }}
                        title="Delete project"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.4rem' }}>
                      <input
                        type="text"
                        value={proj.code_url || ''}
                        onChange={(e) => updateProjectItem(pIdx, 'code_url', e.target.value)}
                        className="resume-doc-input"
                        placeholder="GitHub / Code Link"
                      />
                      <input
                        type="text"
                        value={proj.url || ''}
                        onChange={(e) => updateProjectItem(pIdx, 'url', e.target.value)}
                        className="resume-doc-input"
                        placeholder="Live Deployed Demo URL"
                      />
                    </div>

                    <textarea
                      rows={2}
                      value={proj.description || ''}
                      onChange={(e) => updateProjectItem(pIdx, 'description', e.target.value)}
                      className="resume-doc-input"
                      placeholder="Project Overview / Abstract..."
                      style={{ fontSize: '0.75rem' }}
                    />
                  </div>
                ) : (
                  <div className="resume-doc-item-header">
                    <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '0.4rem' }}>
                      <span className="resume-doc-item-role">
                        {proj.title} {proj.role_or_tech && (
                          <span style={{ fontSize: '0.8rem', fontWeight: 600, color: isDarkMode ? '#38bdf8' : '#0284c7' }}>
                            [{proj.role_or_tech}]
                          </span>
                        )}
                      </span>

                      {/* Project Demo and Code Links */}
                      {proj.code_url && formatLink(proj.code_url) && (
                        <a 
                          href={formatLink(proj.code_url)} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          onClick={(e) => handleSafeLinkClick(e, proj.code_url)}
                          className="resume-doc-project-link-badge"
                          title="Open Project GitHub / Code Repository"
                        >
                          <Code size={11} /> Code Link
                          <ExternalLink size={9} />
                        </a>
                      )}
                      {proj.url && formatLink(proj.url) && (
                        <a 
                          href={formatLink(proj.url)} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          onClick={(e) => handleSafeLinkClick(e, proj.url)}
                          className="resume-doc-project-link-badge demo-badge"
                          title="Open Live Deployed Project Demo"
                        >
                          <Globe size={11} /> Live Demo
                          <ExternalLink size={9} />
                        </a>
                      )}
                    </div>
                    <span className="resume-doc-item-dates">{proj.duration}</span>
                  </div>
                )}

                {proj.description && !isEditMode && (
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem', margin: '0.15rem 0 0.3rem 0' }}>
                    <p style={{ fontSize: '0.8rem', margin: 0, opacity: 0.85, flex: 1 }}>
                      {renderWithLinks(proj.description)}
                    </p>
                    {onOpenEnhancer && (
                      <button
                        type="button"
                        onClick={() => onOpenEnhancer('projects', proj.id || proj.title, proj.description, `Enhance technical architecture overview for ${proj.title}.`)}
                        className="btn btn-sm btn-outline-emerald no-print"
                        style={{ padding: '0.1rem 0.35rem', fontSize: '0.62rem', flexShrink: 0 }}
                        title="Enhance project overview with AI"
                      >
                        <Wand2 size={9} /> AI Enhance
                      </button>
                    )}
                  </div>
                )}

                {/* Bullets */}
                <ul className="resume-doc-bullets">
                  {(proj.bullets || []).map((bullet, bIdx) => {
                    const isOpt = isBulletOptimized(bullet);
                    return isEditMode ? (
                      <div key={bIdx} style={{ display: 'flex', gap: '0.35rem', marginBottom: '0.35rem', alignItems: 'center' }}>
                        <span style={{ color: 'var(--text-muted)' }}>•</span>
                        <input
                          type="text"
                          value={bullet}
                          onChange={(e) => {
                            const newBullets = [...(proj.bullets || [])];
                            newBullets[bIdx] = e.target.value;
                            updateProjectItem(pIdx, 'bullets', newBullets);
                          }}
                          className="resume-doc-input"
                          style={{ flex: 1, fontSize: '0.75rem' }}
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const newBullets = (proj.bullets || []).filter((_, i) => i !== bIdx);
                            updateProjectItem(pIdx, 'bullets', newBullets);
                          }}
                          style={{ background: 'none', border: 'none', color: '#fb7185', cursor: 'pointer', padding: '0.2rem' }}
                          title="Delete bullet"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    ) : (
                      <li
                        key={bIdx}
                        className={`resume-doc-bullet ${isOpt && showDiffHighlights ? 'ai-optimized' : ''}`}
                        style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem' }}
                      >
                        <span style={{ flex: 1 }}>{renderWithLinks(cleanBulletText(bullet))}</span>
                        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', flexShrink: 0 }} className="no-print">
                          {isOpt && showDiffHighlights && (
                            <span className="resume-doc-diff-badge">
                              <Sparkles size={9} /> AI STAR Impact
                            </span>
                          )}
                          {isOpt && onRevertBullet && (
                            <button
                              type="button"
                              onClick={() => onRevertBullet('projects', proj.id || proj.title, bullet)}
                              className="btn btn-sm btn-secondary"
                              style={{ padding: '0.1rem 0.35rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                              title="Undo AI enhancement and restore original wording"
                            >
                              <Undo2 size={9} /> Remove
                            </button>
                          )}
                          {onOpenBulletEnhancer ? (
                            <button
                              type="button"
                              onClick={() => onOpenBulletEnhancer(
                                bullet,
                                proj.title,
                                undefined,
                                (newB) => {
                                  const newBullets = [...(proj.bullets || [])];
                                  newBullets[bIdx] = newB;
                                  updateProjectItem(pIdx, 'bullets', newBullets);
                                }
                              )}
                              className="btn btn-sm btn-outline-emerald"
                              style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                              title="Improve this bullet point with 3 AI options"
                            >
                              <Wand2 size={9} /> AI Polish
                            </button>
                          ) : onOpenEnhancer ? (
                            <button
                              type="button"
                              onClick={() => onOpenEnhancer('projects', proj.id || proj.title, bullet, `Enhance technical architecture phrasing for ${proj.title}.`)}
                              className="btn btn-sm btn-outline-emerald"
                              style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2 }}
                              title="Enhance wording with AI"
                            >
                              <Wand2 size={9} /> AI Enhance
                            </button>
                          ) : null}
                        </div>
                      </li>
                    );
                  })}
                </ul>

                {isEditMode && (
                  <button
                    type="button"
                    onClick={() => addProjectBullet(pIdx)}
                    className="btn btn-secondary btn-sm"
                    style={{ padding: '0.15rem 0.45rem', fontSize: '0.68rem', marginTop: '0.2rem' }}
                  >
                    <Plus size={10} /> Add Project Bullet
                  </button>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 5B. PORTFOLIO & LIVE SHOWCASE */}
      {(portfolio.length > 0 || isEditMode) && (
        <section className="resume-doc-section">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
            <h2 className="resume-doc-section-title" style={{ margin: 0 }}>Portfolio & Live Showcase</h2>
            {isEditMode && (
              <button
                type="button"
                onClick={addPortfolioItem}
                className="btn btn-emerald btn-sm"
                style={{ padding: '0.2rem 0.5rem', fontSize: '0.7rem' }}
              >
                <Plus size={11} /> Add Portfolio Showcase
              </button>
            )}
          </div>

          <div>
            {portfolio.map((port, portIdx) => (
              <div key={port.id || portIdx} className="resume-doc-item" style={{ position: 'relative', marginBottom: isEditMode ? '1.25rem' : '0.75rem' }}>
                {isEditMode ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem', marginBottom: '0.4rem', background: 'rgba(6, 182, 212, 0.04)', padding: '0.5rem', borderRadius: '6px', border: '1px solid rgba(6, 182, 212, 0.2)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.4rem' }}>
                      <input
                        type="text"
                        value={port.title || ''}
                        onChange={(e) => updatePortfolioItem(portIdx, 'title', e.target.value)}
                        className="resume-doc-input"
                        placeholder="Portfolio Showcase Title"
                        style={{ fontWeight: 700, flex: 1 }}
                      />
                      <input
                        type="text"
                        value={port.role_or_tech || (port.technologies || []).join(', ') || ''}
                        onChange={(e) => updatePortfolioItem(portIdx, 'role_or_tech', e.target.value)}
                        className="resume-doc-input"
                        placeholder="Technologies / Tech Stack"
                        style={{ flex: 1 }}
                      />
                      <input
                        type="text"
                        value={port.duration || ''}
                        onChange={(e) => updatePortfolioItem(portIdx, 'duration', e.target.value)}
                        className="resume-doc-input"
                        placeholder="Year / Duration"
                        style={{ width: '130px' }}
                      />
                      <button
                        type="button"
                        onClick={() => deletePortfolioItem(portIdx)}
                        className="btn btn-outline-danger btn-sm"
                        style={{ padding: '0.25rem 0.45rem' }}
                        title="Delete portfolio entry"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.4rem' }}>
                      <input
                        type="text"
                        value={port.code_url || ''}
                        onChange={(e) => updatePortfolioItem(portIdx, 'code_url', e.target.value)}
                        className="resume-doc-input"
                        placeholder="GitHub / Code Repository Link"
                      />
                      <input
                        type="text"
                        value={port.url || ''}
                        onChange={(e) => updatePortfolioItem(portIdx, 'url', e.target.value)}
                        className="resume-doc-input"
                        placeholder="Live Portfolio / Demo URL"
                      />
                    </div>

                    <textarea
                      rows={2}
                      value={port.description || ''}
                      onChange={(e) => updatePortfolioItem(portIdx, 'description', e.target.value)}
                      className="resume-doc-input"
                      placeholder="Portfolio overview and key technical architecture..."
                      style={{ fontSize: '0.75rem' }}
                    />
                  </div>
                ) : (
                  <div className="resume-doc-item-header">
                    <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '0.4rem' }}>
                      <span className="resume-doc-item-role">
                        {port.title} {port.role_or_tech && (
                          <span style={{ fontSize: '0.8rem', fontWeight: 600, color: isDarkMode ? '#38bdf8' : '#0284c7' }}>
                            [{port.role_or_tech}]
                          </span>
                        )}
                      </span>

                      {/* Portfolio Demo and Code Links */}
                      {port.code_url && formatLink(port.code_url) && (
                        <a 
                          href={formatLink(port.code_url)} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          onClick={(e) => handleSafeLinkClick(e, port.code_url)}
                          className="resume-doc-project-link-badge"
                          title="Open Code Repository"
                        >
                          <Code size={11} /> Code
                          <ExternalLink size={9} />
                        </a>
                      )}
                      {port.url && formatLink(port.url) && (
                        <a 
                          href={formatLink(port.url)} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          onClick={(e) => handleSafeLinkClick(e, port.url)}
                          className="resume-doc-project-link-badge demo-badge"
                          title="Open Live Deployed Showcase"
                        >
                          <Globe size={11} /> Live Demo
                          <ExternalLink size={9} />
                        </a>
                      )}
                    </div>
                    <span className="resume-doc-item-dates">{port.duration}</span>
                  </div>
                )}

                {port.description && !isEditMode && (
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem', margin: '0.15rem 0 0.3rem 0' }}>
                    <p style={{ fontSize: '0.8rem', margin: 0, opacity: 0.85, flex: 1 }}>
                      {renderWithLinks(port.description)}
                    </p>
                    {onOpenEnhancer && (
                      <button
                        type="button"
                        onClick={() => onOpenEnhancer('projects', port.id || port.title, port.description, `Enhance portfolio overview for ${port.title}.`)}
                        className="btn btn-sm btn-outline-cyan no-print"
                        style={{ padding: '0.1rem 0.35rem', fontSize: '0.62rem', flexShrink: 0 }}
                        title="Enhance portfolio description with AI"
                      >
                        <Wand2 size={9} /> AI Enhance
                      </button>
                    )}
                  </div>
                )}

                {/* Bullets */}
                <ul className="resume-doc-bullets">
                  {(port.bullets || []).map((bullet, bIdx) => {
                    const isOpt = isBulletOptimized(bullet);
                    return isEditMode ? (
                      <div key={bIdx} style={{ display: 'flex', gap: '0.35rem', marginBottom: '0.35rem', alignItems: 'center' }}>
                        <span style={{ color: 'var(--text-muted)' }}>•</span>
                        <input
                          type="text"
                          value={bullet}
                          onChange={(e) => {
                            const newBullets = [...(port.bullets || [])];
                            newBullets[bIdx] = e.target.value;
                            updatePortfolioItem(portIdx, 'bullets', newBullets);
                          }}
                          className="resume-doc-input"
                          style={{ flex: 1, fontSize: '0.75rem' }}
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const newBullets = (port.bullets || []).filter((_, i) => i !== bIdx);
                            updatePortfolioItem(portIdx, 'bullets', newBullets);
                          }}
                          style={{ background: 'none', border: 'none', color: '#fb7185', cursor: 'pointer', padding: '0.2rem' }}
                          title="Delete bullet"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    ) : (
                      <li
                        key={bIdx}
                        className={`resume-doc-bullet ${isOpt && showDiffHighlights ? 'ai-optimized' : ''}`}
                        style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.4rem' }}
                      >
                        <span style={{ flex: 1 }}>{renderWithLinks(cleanBulletText(bullet))}</span>
                        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', flexShrink: 0 }} className="no-print">
                          {isOpt && showDiffHighlights && (
                            <span className="resume-doc-diff-badge">
                              <Sparkles size={9} /> AI STAR Impact
                            </span>
                          )}
                          {isOpt && onRevertBullet && (
                            <button
                              type="button"
                              onClick={() => onRevertBullet('portfolio', port.id || port.title, bullet)}
                              className="btn btn-sm btn-secondary"
                              style={{ padding: '0.1rem 0.35rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2, display: 'flex', alignItems: 'center', gap: '0.2rem' }}
                              title="Undo AI enhancement and restore original wording"
                            >
                              <Undo2 size={9} /> Remove
                            </button>
                          )}
                          {onOpenEnhancer && (
                            <button
                              type="button"
                              onClick={() => onOpenEnhancer('projects', port.id || port.title, bullet, `Enhance technical portfolio phrasing for ${port.title}.`)}
                              className="btn btn-sm btn-outline-cyan"
                              style={{ padding: '0.1rem 0.4rem', fontSize: '0.62rem', height: 'auto', lineHeight: 1.2 }}
                              title="Enhance wording with AI"
                            >
                              <Wand2 size={9} /> AI Enhance
                            </button>
                          )}
                        </div>
                      </li>
                    );
                  })}
                </ul>

                {isEditMode && (
                  <button
                    type="button"
                    onClick={() => addPortfolioBullet(portIdx)}
                    className="btn btn-secondary btn-sm"
                    style={{ padding: '0.15rem 0.45rem', fontSize: '0.68rem', marginTop: '0.2rem' }}
                  >
                    <Plus size={10} /> Add Portfolio Bullet
                  </button>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 6. EDUCATION */}
      {(education.length > 0 || isEditMode) && (
        <section className="resume-doc-section">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
            <h2 className="resume-doc-section-title" style={{ margin: 0 }}>Education & Academics</h2>
            {isEditMode && (
              <button
                type="button"
                onClick={addEducationItem}
                className="btn btn-emerald btn-sm"
                style={{ padding: '0.2rem 0.5rem', fontSize: '0.7rem' }}
              >
                <Plus size={11} /> Add Education
              </button>
            )}
          </div>

          <div>
            {education.length === 0 && isEditMode && (
              <div style={{ padding: '0.6rem', color: 'var(--text-muted)', fontSize: '0.75rem', fontStyle: 'italic' }}>
                No education entries added yet. Click &quot;+ Add Education&quot; above to add your degree.
              </div>
            )}
            {education.map((edu, eduIdx) => (
              <div key={eduIdx} className="resume-doc-item" style={{ position: 'relative', marginBottom: isEditMode ? '0.75rem' : '0.4rem' }}>
                {isEditMode ? (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', background: 'rgba(255, 255, 255, 0.02)', padding: '0.4rem', borderRadius: '6px', border: '1px solid var(--border-subtle)' }}>
                    <input
                      type="text"
                      value={edu.degree || ''}
                      onChange={(e) => updateEducationItem(eduIdx, 'degree', e.target.value)}
                      className="resume-doc-input"
                      placeholder="Degree (e.g. B.Tech)"
                      style={{ flex: 1 }}
                    />
                    <input
                      type="text"
                      value={edu.field_of_study || ''}
                      onChange={(e) => updateEducationItem(eduIdx, 'field_of_study', e.target.value)}
                      className="resume-doc-input"
                      placeholder="Field of Study / Major"
                      style={{ flex: 1 }}
                    />
                    <input
                      type="text"
                      value={edu.institution || ''}
                      onChange={(e) => updateEducationItem(eduIdx, 'institution', e.target.value)}
                      className="resume-doc-input"
                      placeholder="Institution Name"
                      style={{ flex: 1.2 }}
                    />
                    <input
                      type="text"
                      value={edu.grade_or_cgpa || ''}
                      onChange={(e) => updateEducationItem(eduIdx, 'grade_or_cgpa', e.target.value)}
                      className="resume-doc-input"
                      placeholder="CGPA / Grade"
                      style={{ width: '100px' }}
                    />
                    <input
                      type="text"
                      value={`${edu.start_year || ''}${edu.end_year ? ' - ' + edu.end_year : ''}`}
                      onChange={(e) => {
                        const parts = e.target.value.split('-');
                        updateEducationItem(eduIdx, 'start_year', parts[0]?.trim());
                        if (parts[1]) updateEducationItem(eduIdx, 'end_year', parts[1]?.trim());
                      }}
                      className="resume-doc-input"
                      placeholder="Years (2022 - 2026)"
                      style={{ width: '130px' }}
                    />
                    <button
                      type="button"
                      onClick={() => deleteEducationItem(eduIdx)}
                      className="btn btn-outline-danger btn-sm"
                      style={{ padding: '0.2rem 0.4rem' }}
                      title="Delete education entry"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                ) : (
                  <div className="resume-doc-item-header">
                    <div>
                      <span className="resume-doc-item-role">
                        {edu.degree} {edu.field_of_study ? `in ${edu.field_of_study}` : ''}
                      </span>
                      <div className="resume-doc-item-company" style={{ fontSize: '0.8rem' }}>
                        {edu.institution}
                      </div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      {edu.grade_or_cgpa && (
                        <div style={{ fontSize: '0.8rem', fontWeight: 700, color: '#10b981' }}>
                          {edu.grade_or_cgpa}
                        </div>
                      )}
                      <div className="resume-doc-item-dates">
                        {edu.start_year ? `${edu.start_year} - ` : ''}{edu.end_year || ''}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 7. CERTIFICATIONS */}
      {(certifications.length > 0 || isEditMode) && (
        <section className="resume-doc-section">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
            <h2 className="resume-doc-section-title" style={{ margin: 0 }}>Certifications & Credentials</h2>
            {isEditMode && (
              <button
                type="button"
                onClick={addCertificationItem}
                className="btn btn-emerald btn-sm"
                style={{ padding: '0.2rem 0.5rem', fontSize: '0.7rem' }}
              >
                <Plus size={11} /> Add Certification
              </button>
            )}
          </div>

          <ul className="resume-doc-bullets">
            {certifications.length === 0 && isEditMode && (
              <div style={{ padding: '0.6rem', color: 'var(--text-muted)', fontSize: '0.75rem', fontStyle: 'italic' }}>
                No certifications added yet. Click &quot;+ Add Certification&quot; above to add credentials.
              </div>
            )}
            {certifications.map((cert, cIdx) => (
              <li key={cIdx} className="resume-doc-bullet">
                {isEditMode ? (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', width: '100%', marginBottom: '0.25rem' }}>
                    <input
                      type="text"
                      value={cert.name || ''}
                      onChange={(e) => updateCertificationItem(cIdx, 'name', e.target.value)}
                      className="resume-doc-input"
                      placeholder="Certification Name"
                      style={{ flex: 1 }}
                    />
                    <input
                      type="text"
                      value={cert.issuer || ''}
                      onChange={(e) => updateCertificationItem(cIdx, 'issuer', e.target.value)}
                      className="resume-doc-input"
                      placeholder="Issuing Organization"
                      style={{ flex: 1 }}
                    />
                    <input
                      type="text"
                      value={cert.year || ''}
                      onChange={(e) => updateCertificationItem(cIdx, 'year', e.target.value)}
                      className="resume-doc-input"
                      placeholder="Year"
                      style={{ width: '80px' }}
                    />
                    <button
                      type="button"
                      onClick={() => deleteCertificationItem(cIdx)}
                      className="btn btn-outline-danger btn-sm"
                      style={{ padding: '0.2rem 0.4rem' }}
                      title="Delete certification"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                ) : (
                  <>
                    <strong>{cert.name}</strong> {cert.issuer ? `— ${cert.issuer}` : ''} {cert.year ? `(${cert.year})` : ''}
                  </>
                )}
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* 8. LANGUAGES (Only rendered if candidate specified languages) */}
      {structuredResume.languages && structuredResume.languages.length > 0 && (
        <section className="resume-doc-section">
          <h2 className="resume-doc-section-title" style={{ margin: '0 0 0.35rem 0' }}>Languages</h2>
          <div className="resume-doc-skills-wrap">
            {structuredResume.languages.map((lang, lIdx) => (
              <span key={lIdx} className="resume-doc-skill-pill">
                {lang}
              </span>
            ))}
          </div>
        </section>
      )}

      {/* 9. KEY ACHIEVEMENTS & AWARDS */}
      {((structuredResume.achievements && structuredResume.achievements.length > 0) || (structuredResume.awards && structuredResume.awards.length > 0)) && (
        <section className="resume-doc-section">
          <h2 className="resume-doc-section-title" style={{ margin: '0 0 0.35rem 0' }}>Key Achievements & Honors</h2>
          <ul className="resume-doc-bullets">
            {[...(structuredResume.achievements || []), ...(structuredResume.awards || [])].map((item, aIdx) => (
              <li key={aIdx} className="resume-doc-bullet">
                {renderWithLinks(cleanBulletText(item))}
              </li>
            ))}
          </ul>
        </section>
      )}
    </article>
  );
};

export const ResumeDocument = React.memo(ResumeDocumentComponent);
