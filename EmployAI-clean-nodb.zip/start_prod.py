"""
Production startup entrypoint for Employ.AI Backend.

Usage:
  python start_prod.py

Or via Gunicorn (recommended for multi-worker production):
  gunicorn app.main:app -k uvicorn.workers.UvicornWorker \
    --workers 4 --bind 0.0.0.0:8000 --timeout 120

Environment:
  Copy backend/.env.production.example → backend/.env and fill in all secrets.
"""

import uvicorn
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if sys.platform.startswith("win"):
    try:
        if sys.stdout and hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if sys.stderr and hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

if __name__ == "__main__":
    workers = int(os.environ.get("WEB_CONCURRENCY", 1))
    host    = os.environ.get("HOST", "0.0.0.0")
    port    = int(os.environ.get("PORT", 8000))

    print("=" * 65)
    print("  [EmployAI] Production Server Starting")
    print(f"  Host: {host}:{port}  |  Workers: {workers}")
    print(f"  API:  http://{host}:{port}/api/v1")
    print("=" * 65)

    uvicorn.run(
        "app.main:app",
        host=host,
        port=port,
        workers=workers,     # >1 workers disables reload automatically
        reload=False,        # NEVER enable reload in production
        access_log=True,
        log_level="info",
    )
