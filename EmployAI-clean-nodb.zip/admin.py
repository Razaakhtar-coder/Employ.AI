from typing import List, Dict, Any
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user, require_roles
from app.models.user import User
from app.models.document import Document
from app.models.matching import Role
from app.models.opportunity import Opportunity, Application
from app.models.taxonomy import Skill

router = APIRouter(prefix="/admin", tags=["Admin & System"])


@router.get("/stats")
def get_system_stats(
    current_user: User = Depends(require_roles(["admin", "academia"])),
    db: Session = Depends(get_db)
):
    """Retrieve platform health and aggregate counts."""
    total_users = db.query(User).count()
    total_students = db.query(User).filter(User.role == "student").count()
    total_academia = db.query(User).filter(User.role == "academia").count()
    total_industry = db.query(User).filter(User.role == "industry").count()
    total_skills = db.query(Skill).count()
    total_roles = db.query(Role).count()
    total_documents = db.query(Document).count()
    total_opportunities = db.query(Opportunity).count()
    total_applications = db.query(Application).count()

    return {
        "status": "healthy",
        "total_users": total_users,
        "role_breakdown": {
            "students": total_students,
            "academia": total_academia,
            "industry": total_industry
        },
        "taxonomy_metrics": {
            "total_canonical_skills": total_skills,
            "total_industry_roles": total_roles
        },
        "activity_metrics": {
            "resumes_analyzed": total_documents,
            "opportunities_posted": total_opportunities,
            "applications_submitted": total_applications
        }
    }
