import React, { useState, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import type { 
  StructuredResume, 
  JobTailoringAnalysisResponse
} from '../types';
import { documentApi } from '../services/api';
import { calculateATSScore } from '../services/atsScoring';
import { 
  Sparkles, AlertCircle, 
  Check, X, Plus,
  Zap, CreditCard,
  RefreshCw, Cpu, Play,
  Briefcase, Award, Layers, RotateCcw,
  ShieldCheck, CheckCircle
} from 'lucide-react';
import { ErrorBoundary } from './ErrorBoundary';
import { JobTailoringExplainerVideo } from './JobTailoringExplainerVideo';
import { 
  extractJobDetails, 
  generateTailoredProfessionalSummary,
  type ExtractedJobDetails 
} from '../utils/jobTailoringExtractor';
import { useAuth } from '../context/AuthContext';
import { useRazorpay } from '../hooks/useRazorpay';

export interface JobTailoringModalProps {
  isOpen: boolean;
  onClose: () => void;
  documentId?: string;
  currentStructuredResume: StructuredResume | null;
  rawResumeText?: string;
  initialJobDescription?: string;
  initialJobTitle?: string;
  initialTab?: 'workspace' | 'video';
  onApplyTailoredResume: (tailoredResume: StructuredResume, targetJobTitle: string, atsScore: number) => void;
  onSaveAsNewVersion?: (versionName: string, targetJob: string, structuredResume: StructuredResume, atsScore: number) => Promise<void>;
}

export const JobTailoringModal: React.FC<JobTailoringModalProps> = ({
  isOpen,
  onClose,
  documentId,
  currentStructuredResume,
  initialJobDescription = '',
  initialJobTitle = '',
  initialTab = 'workspace',
  onApplyTailoredResume,
  onSaveAsNewVersion: _onSaveAsNewVersion
}) => {
  const { isPremium, isAdmin, openSubscriptionModal, checkSubscription } = useAuth();

  const [rzpGateSuccess, setRzpGateSuccess] = React.useState<string | null>(null);
  const { startPayment: startGatePayment, isLoading: gateRzpLoading, error: gateRzpError, isSuccess: gateRzpSuccess, setError: setGateRzpError } = useRazorpay({
    targetFeature: 'Job Tailoring Panel',
    onSuccess: async (data) => {
      if (data.is_premium) {
        setRzpGateSuccess('Payment verified! Tailoring Panel is now unlocked.');
        await checkSubscription();
        setTimeout(() => { onClose(); }, 1800);
      }
    },
  });

  // Active Tab inside unified panel: 'workspace' | 'video'
  const [activeTab, setActiveTab] = useState<'workspace' | 'video'>('workspace');

  // Input states
  const [jobTitle, setJobTitle] = useState<string>(initialJobTitle || 'AI Engineer');
  const [jobDescription, setJobDescription] = useState<string>(initialJobDescription || '');
  const [customPhraseInput, setCustomPhraseInput] = useState<string>('');
  const [extractedPhrases, setExtractedPhrases] = useState<string[]>([]);
  const [selectedPhrases, setSelectedPhrases] = useState<Set<string>>(new Set());

  // Deep Job Details (Experience, Qualities, Work)
  const [jobDetails, setJobDetails] = useState<ExtractedJobDetails | null>(null);
  const [styleVariation, setStyleVariation] = useState<number>(0);

  // Editable summary
  const [targetSummary, setTargetSummary] = useState<string>('');
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Sync initial tab and data on open
  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      if (initialJobDescription) setJobDescription(initialJobDescription);
      if (initialJobTitle) setJobTitle(initialJobTitle);
      setError(null);
    }
  }, [isOpen, initialTab, initialJobDescription, initialJobTitle]);

  // Auto-extract details whenever job description changes
  useEffect(() => {
    if (!jobDescription.trim()) {
      setExtractedPhrases([]);
      setSelectedPhrases(new Set());
      setJobDetails(null);
      return;
    }

    const details = extractJobDetails(jobDescription, jobTitle || 'Target Role');
    setJobDetails(details);

    // Populate skills
    setExtractedPhrases(details.skills);
    setSelectedPhrases(new Set(details.skills));

    // Update job title if found and not manually overridden
    if (details.targetJobTitle && (!jobTitle || jobTitle === 'AI Engineer' || jobTitle === 'Target Role')) {
      setJobTitle(details.targetJobTitle);
    }

    // Generate comprehensive summary incorporating experience, qualities, work, and skills
    const synthesizedSummary = generateTailoredProfessionalSummary({
      jobTitle: details.targetJobTitle || jobTitle || 'Target Professional',
      skills: details.skills,
      experienceDetails: details.experienceDetails,
      qualities: details.qualities,
      workResponsibilities: details.workResponsibilities,
      existingSummary: currentStructuredResume?.summary || currentStructuredResume?.personal_info?.summary,
      styleVariation: 0
    });
    setTargetSummary(synthesizedSummary);
  }, [jobDescription]);

  // Regenerate summary on style variation toggle or selected phrase change
  const handleRegenerateSummary = useCallback(() => {
    const nextStyle = (styleVariation + 1) % 3;
    setStyleVariation(nextStyle);

    const activeSkills = Array.from(selectedPhrases);
    const expDetails = jobDetails?.experienceDetails || {
      yearsText: null,
      seniority: null,
      domain: null,
      rawSnippets: []
    };
    const quals = jobDetails?.qualities || [];
    const work = jobDetails?.workResponsibilities || [];

    const newSummary = generateTailoredProfessionalSummary({
      jobTitle: jobTitle.trim() || jobDetails?.targetJobTitle || 'Target Professional',
      skills: activeSkills.length > 0 ? activeSkills : (jobDetails?.skills || []),
      experienceDetails: expDetails,
      qualities: quals,
      workResponsibilities: work,
      existingSummary: currentStructuredResume?.summary || currentStructuredResume?.personal_info?.summary,
      styleVariation: nextStyle
    });
    setTargetSummary(newSummary);
  }, [styleVariation, selectedPhrases, jobDetails, jobTitle, currentStructuredResume]);

  if (!isOpen) return null;

  // Toggle phrase selection
  const togglePhrase = (phrase: string) => {
    setSelectedPhrases(prev => {
      const next = new Set(prev);
      if (next.has(phrase)) {
        next.delete(phrase);
      } else {
        next.add(phrase);
      }
      return next;
    });
  };

  // Add custom phrase/word from input
  const handleAddCustomPhrase = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = customPhraseInput.trim();
    if (!clean) return;

    if (!extractedPhrases.includes(clean)) {
      setExtractedPhrases(prev => [clean, ...prev]);
    }
    setSelectedPhrases(prev => new Set(prev).add(clean));
    setCustomPhraseInput('');
  };

  // Remove a phrase completely
  const handleRemovePhrase = (phraseToRemove: string) => {
    setExtractedPhrases(prev => prev.filter(p => p !== phraseToRemove));
    setSelectedPhrases(prev => {
      const next = new Set(prev);
      next.delete(phraseToRemove);
      return next;
    });
  };

  // Apply directly to active resume
  const handleApplyToResume = () => {
    if (!currentStructuredResume) {
      setError('No active resume loaded in workspace.');
      return;
    }

    const updated: StructuredResume = JSON.parse(JSON.stringify(currentStructuredResume));
    const activePhrases = Array.from(selectedPhrases);

    // 1. Merge selected phrases into skills section
    const existingSkillsLower = new Set((updated.skills || []).map(s => s.toLowerCase()));
    const newSkillsToAdd = activePhrases.filter(p => !existingSkillsLower.has(p.toLowerCase()));
    
    if (newSkillsToAdd.length > 0) {
      updated.skills = [...newSkillsToAdd, ...(updated.skills || [])];
    }

    // 2. Update Headline & Title
    const finalJobTitle = jobTitle.trim() || jobDetails?.targetJobTitle || 'Target Professional';
    if (finalJobTitle) {
      if (!updated.personal_info) updated.personal_info = {};
      updated.personal_info.title = finalJobTitle;
      const topSkillsTag = (updated.skills || []).slice(0, 3).join(' • ');
      const newHeadline = topSkillsTag ? `${finalJobTitle} | ${topSkillsTag}` : finalJobTitle;
      updated.personal_info.headline = newHeadline;
      updated.headline = newHeadline;
    }

    // 3. Update Summary with the synthesized Experience, Qualities, Work, and Skills
    if (targetSummary.trim()) {
      updated.summary = targetSummary.trim();
      if (!updated.personal_info) updated.personal_info = {};
      updated.personal_info.summary = targetSummary.trim();
    }

    // 4. Update Experience with Target Keywords & Responsibilities
    const topKeywordsInline = activePhrases.slice(0, 3).join(', ');
    const workItems = jobDetails?.workResponsibilities || [];
    const primaryWork = workItems[0] || `key ${finalJobTitle} initiatives`;
    const existingExp = updated.experience || [];
    
    if (existingExp.length > 0) {
      const expCopy = [...existingExp];
      const firstExp = { ...expCopy[0] };
      const bullets = [...(firstExp.bullets || [])];
      const tailoredBullet = `Spearheaded ${primaryWork} utilizing ${topKeywordsInline || 'industry standard frameworks'}, boosting operational delivery and throughput by 25%.`;
      if (!bullets.some(b => activePhrases[0] && b.toLowerCase().includes(activePhrases[0].toLowerCase()))) {
        firstExp.bullets = [tailoredBullet, ...bullets];
        expCopy[0] = firstExp;
        updated.experience = expCopy;
      }
    } else {
      updated.experience = [{
        id: `exp-tailored-${Date.now()}`,
        role: finalJobTitle,
        company: 'Industry Practice & Applied Technical Initiatives',
        duration: '2025 - Present',
        bullets: [
          `Spearheaded ${primaryWork} utilizing ${topKeywordsInline || 'specialized domain tooling'}, accelerating milestone turnaround by 30%.`,
          `Collaborated cross-functionally to engineer robust, scalable solutions maintaining 99.9% uptime.`,
          `Automated reporting and workflow processes, reducing operational overhead by 25%.`
        ]
      }];
    }

    const atsResult = calculateATSScore(updated, 85, jobDescription, finalJobTitle);
    onApplyTailoredResume(updated, finalJobTitle, atsResult.overall_score);
    onClose();
  };

  // Deep AI auto-tailoring via backend API
  const handleDeepAiTailor = async () => {
    if (!jobDescription.trim()) {
      setError('Please provide a target job description.');
      return;
    }

    setIsAiLoading(true);
    setError(null);

    try {
      const result: JobTailoringAnalysisResponse = await documentApi.tailorResumeToJob({
        document_id: documentId,
        job_description: jobDescription,
        structured_resume: currentStructuredResume || undefined
      });

      const finalStruct: StructuredResume = result.tailored_structured_resume || 
        (currentStructuredResume ? JSON.parse(JSON.stringify(currentStructuredResume)) : {
          personal_info: { full_name: 'Candidate' },
          skills: [],
          experience: [],
          projects: [],
          education: []
        });

      // Merge newly extracted keywords into skills section
      const skillsToAdd: string[] = [];
      const incomingSkills: string[] = [
        ...(result.added_skills || []),
        ...(result.tailored_skills_order || []),
        ...(jobDetails?.skills || [])
      ];
      incomingSkills.forEach((s: string) => {
        if (!finalStruct.skills?.some(ex => ex.toLowerCase() === s.toLowerCase())) {
          skillsToAdd.push(s);
        }
      });

      if (skillsToAdd.length > 0) {
        finalStruct.skills = [...skillsToAdd, ...(finalStruct.skills || [])];
      }

      // Summary synthesis: prioritize API tailored summary or rich synthesized summary
      const sumText = typeof result.tailored_summary === 'string'
        ? result.tailored_summary
        : result.tailored_summary?.tailored_summary || targetSummary || finalStruct.summary;
      
      if (sumText) {
        finalStruct.summary = sumText;
        if (finalStruct.personal_info) finalStruct.personal_info.summary = sumText;
        setTargetSummary(sumText);
      }

      const finalTitle = result.target_job_title || jobTitle || 'Target Role';
      if (finalStruct.personal_info) {
        finalStruct.personal_info.title = finalTitle;
        finalStruct.personal_info.headline = `${finalTitle} | ${(finalStruct.skills || []).slice(0, 3).join(' • ')}`;
      }
      finalStruct.headline = `${finalTitle} | ${(finalStruct.skills || []).slice(0, 3).join(' • ')}`;

      // Experience: Ensure tailored experience bullets and entries are applied
      if (result.tailored_structured_resume?.experience && result.tailored_structured_resume.experience.length > 0) {
        finalStruct.experience = result.tailored_structured_resume.experience;
      } else {
        const topKeywordsInline = (finalStruct.skills || []).slice(0, 3).join(', ');
        const existingExp = finalStruct.experience || [];
        if (existingExp.length > 0) {
          const expCopy = [...existingExp];
          const firstExp = { ...expCopy[0] };
          const bullets = [...(firstExp.bullets || [])];
          const tailoredBullet = `Spearheaded ${finalTitle} deliverables utilizing ${topKeywordsInline || 'specialized frameworks'}, boosting delivery velocity by 25%.`;
          firstExp.bullets = [tailoredBullet, ...bullets];
          expCopy[0] = firstExp;
          finalStruct.experience = expCopy;
        } else {
          finalStruct.experience = [{
            id: `exp-tailored-${Date.now()}`,
            role: finalTitle,
            company: `${result.company_name || 'Enterprise'} Applied Practice & Solutions`,
            duration: '2025 - Present',
            bullets: [
              `Spearheaded ${finalTitle} technical workflows utilizing ${topKeywordsInline || 'modern tooling'}, accelerating milestone turnaround by 30%.`,
              `Architected and optimized end-to-end deliverables to ensure seamless stakeholder integration and high system performance.`,
              `Automated reporting and workflow processes, reducing operational overhead by 25%.`
            ]
          }];
        }
      }

      const atsResult = calculateATSScore(finalStruct, result.tailored_ats_score || 90, jobDescription, finalTitle);
      onApplyTailoredResume(finalStruct, finalTitle, atsResult.overall_score);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to auto-tailor with AI. You can still use the direct "Apply Wording & Skills" button above!');
    } finally {
      setIsAiLoading(false);
    }
  };

  // Sample Presets with realistic Experience, Qualities, Work & Skills
  const samplePresets = [
    {
      title: 'Full-Stack AI Engineer',
      desc: 'Job Title: Senior Full-Stack AI Engineer\nRequirements: 4+ years experience with Python, FastAPI, React 19, LangChain, RAG architectures, Docker containerization, PostgreSQL, System Design.\nResponsibilities: Architecting and deploying scalable web services, leading end-to-end AI workflows, and optimizing system latency.\nQualities: Strong analytical problem-solving, dedication to high code quality and engineering standards, and proactive cross-functional collaboration in agile teams.'
    },
    {
      title: 'Senior Frontend Developer',
      desc: 'Job Title: Senior Frontend Developer\nRequirements: 5+ years experience with TypeScript, React 19, Next.js, Tailwind CSS, WebGL, Redux Toolkit, Performance Optimization.\nResponsibilities: Designing responsive, high-performance UI architectures, building reusable component design systems, and conducting peer code reviews.\nQualities: Meticulous attention to detail, user-centric product mindset, and strong cross-functional communication.'
    },
    {
      title: 'Data Science / ML Specialist',
      desc: 'Job Title: Lead Data Scientist\nRequirements: 4+ years experience in Python, SQL, Pandas, NumPy, Scikit-learn, PyTorch, Machine Learning, Data Pipelines, Tableau.\nResponsibilities: Developing predictive ML models, architecting automated ETL pipelines, and delivering data-driven business insights.\nQualities: Analytical problem-solving, data-driven rigor, and self-directed ownership.'
    }
  ];

  if (!isOpen) return null;

  if (!isPremium && !isAdmin) {
    const lockedNode = (
      <div 
        className="modal-backdrop" 
        onClick={onClose} 
        style={{ 
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(3, 7, 18, 0.85)',
          backdropFilter: 'blur(12px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 99999,
          padding: '1rem',
          boxSizing: 'border-box'
        }}
      >
        <div 
          className="glass-card" 
          onClick={(e) => e.stopPropagation()}
          style={{
            maxWidth: '540px',
            width: '100%',
            padding: '2.5rem 2rem',
            textAlign: 'center',
            borderRadius: '24px',
            border: '1px solid rgba(56, 189, 248, 0.35)',
            background: 'linear-gradient(145deg, #0d1527, #070c18)',
            position: 'relative'
          }}
        >
          <button
            onClick={onClose}
            type="button"
            aria-label="Close"
            style={{
              position: 'absolute',
              top: '1rem',
              right: '1rem',
              background: 'rgba(255, 255, 255, 0.05)',
              border: 'none',
              borderRadius: '50%',
              width: '32px',
              height: '32px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--text-secondary)',
              cursor: 'pointer'
            }}
          >
            <X size={18} />
          </button>

          <div style={{
            width: '60px',
            height: '60px',
            borderRadius: '18px',
            background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.15), rgba(16, 185, 129, 0.15))',
            border: '1px solid var(--accent-cyan)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 1.25rem auto'
          }}>
            <Sparkles size={28} color="var(--accent-cyan)" />
          </div>

          <span className="badge badge-cyan" style={{ fontSize: '0.72rem', fontWeight: 800, marginBottom: '0.65rem' }}>
            PRO Feature Locked
          </span>

          <h3 style={{ fontSize: '1.45rem', fontWeight: 900, color: 'var(--text-primary)', margin: '0.4rem 0 0.5rem 0' }}>
            Job Tailoring Panel
          </h3>

          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '1.5rem', lineHeight: 1.55 }}>
            Neural job description keyword extraction, STAR phrase alignment, and ATS match score surge require Employ.AI PRO access.
          </p>

          {/* Razorpay primary */}
          {rzpGateSuccess || gateRzpSuccess ? (
            <div style={{ padding: '0.8rem 1rem', borderRadius: '10px', background: 'rgba(16,185,129,0.15)', border: '1px solid rgba(16,185,129,0.4)', color: '#34d399', fontWeight: 700, fontSize: '0.875rem', display: 'flex', alignItems: 'center', gap: '0.5rem', justifyContent: 'center' }}>
              <CheckCircle size={16} /> {rzpGateSuccess}
            </div>
          ) : (
            <>
              <button
                id="razorpay-tailor-unlock-btn"
                type="button"
                disabled={gateRzpLoading}
                onClick={async () => { setGateRzpError(null); await startGatePayment(); }}
                className="btn btn-primary"
                style={{ width: '100%', padding: '0.8rem', fontWeight: 800, fontSize: '0.9rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', background: gateRzpLoading ? 'rgba(51,149,255,0.3)' : 'linear-gradient(135deg, #072654, #3395FF, #00f2fe)', boxShadow: gateRzpLoading ? 'none' : '0 4px 20px rgba(51,149,255,0.4)', cursor: gateRzpLoading ? 'not-allowed' : 'pointer' }}
              >
                {gateRzpLoading
                  ? <><div className="spinner-border" style={{ width: '16px', height: '16px', borderWidth: '2px' }} /> Initiating...</>
                  : <><CreditCard size={16} /> Pay ₹49 / Month — Unlock PRO via Razorpay</>}
              </button>
              {gateRzpError && (
                <div style={{ fontSize: '0.75rem', color: '#f87171', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                  <AlertCircle size={13} />{gateRzpError}
                </div>
              )}
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.67rem', color: 'var(--text-muted)', justifyContent: 'center' }}>
                <ShieldCheck size={12} color="var(--accent-emerald)" /> 256-bit SSL · PCI-DSS · Razorpay Verified
              </div>
              <button
                onClick={() => { onClose(); openSubscriptionModal(); }}
                type="button"
                style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '0.75rem', textDecoration: 'underline', marginTop: '0.25rem' }}
              >
                <Zap size={11} style={{ display: 'inline', marginRight: '0.25rem' }} />View Annual Plan (₹499/yr — Save 15%) & other options
              </button>
            </>
          )}
        </div>
      </div>
    );
    return typeof document !== 'undefined' ? createPortal(lockedNode, document.body) : lockedNode;
  }

  const modalNode = (
    <ErrorBoundary fallbackTitle="Resume Tailoring Studio">
      <div 
        className="modal-backdrop" 
        onClick={onClose} 
        style={{ 
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(3, 7, 18, 0.85)',
          backdropFilter: 'blur(12px)',
          WebkitBackdropFilter: 'blur(12px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 99999,
          padding: '1rem',
          boxSizing: 'border-box'
        }}
      >
        <div 
          className="glass-card modal-content" 
          onClick={(e) => e.stopPropagation()}
          style={{
            width: '98%',
            maxWidth: '1020px',
            maxHeight: '94vh',
            display: 'flex',
            flexDirection: 'column',
            padding: '1.25rem 1.5rem',
            borderRadius: '16px',
            background: 'var(--bg-modal)',
            border: '1.5px solid var(--border-glass)',
            boxShadow: 'var(--shadow-modal)',
            boxSizing: 'border-box',
            overflow: 'hidden'
          }}
        >
          {/* TOP UNIFIED HEADER WITH TAB SWITCHER */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0.75rem', flexWrap: 'wrap', gap: '0.75rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
              <div style={{ padding: '0.5rem', borderRadius: '10px', background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.25), rgba(168, 85, 247, 0.25))', color: 'var(--accent-cyan)' }}>
                <Sparkles size={22} />
              </div>
              <div>
                <h2 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  Tailor Resume to Job Description
                </h2>
                <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                  Adds job skills to your Skills section and synthesizes experience, qualities, and work scope into your Professional Summary.
                </p>
              </div>
            </div>

            {/* Panel Tabs & Close Button */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <div style={{ display: 'flex', background: 'var(--bg-tertiary)', padding: '0.2rem', borderRadius: '8px', border: '1px solid var(--border-subtle)', gap: '0.25rem' }}>
                <button
                  type="button"
                  onClick={() => setActiveTab('workspace')}
                  className={`btn btn-sm ${activeTab === 'workspace' ? 'btn-primary' : 'btn-ghost'}`}
                  style={{
                    fontSize: '0.74rem',
                    padding: '0.3rem 0.65rem',
                    fontWeight: 700,
                    borderRadius: '6px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.35rem'
                  }}
                >
                  <Zap size={13} />
                  <span>Live Workspace</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('video')}
                  className={`btn btn-sm ${activeTab === 'video' ? 'btn-primary' : 'btn-ghost'}`}
                  style={{
                    fontSize: '0.74rem',
                    padding: '0.3rem 0.65rem',
                    fontWeight: 700,
                    borderRadius: '6px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.35rem'
                  }}
                >
                  <Play size={13} />
                  <span>🎬 How It Works Demo</span>
                </button>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="btn btn-ghost btn-sm"
                style={{ padding: '0.4rem', color: 'var(--text-muted)' }}
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {error && (
            <div style={{ padding: '0.6rem 0.9rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.12)', border: '1px solid rgba(244, 63, 94, 0.3)', color: '#fb7185', fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.75rem' }}>
              <AlertCircle size={15} />
              <span>{error}</span>
            </div>
          )}

          {/* TAB 1: HOW IT WORKS VIDEO DEMO */}
          {activeTab === 'video' && (
            <div style={{ overflowY: 'auto', flex: 1, paddingRight: '0.25rem', paddingBottom: '0.5rem', animation: 'fadeIn 0.2s ease-out' }}>
              <JobTailoringExplainerVideo 
                onOpenTailoring={() => setActiveTab('workspace')}
                onUseExample={(title, desc) => {
                  setJobTitle(title);
                  setJobDescription(desc);
                  setActiveTab('workspace');
                }}
              />
            </div>
          )}

          {/* TAB 2: LIVE TAILOR WORKSPACE */}
          {activeTab === 'workspace' && (
            <>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '1.25rem', overflowY: 'auto', flex: 1, paddingRight: '0.25rem', paddingBottom: '0.5rem' }}>
                
                {/* LEFT COLUMN: JOB DESCRIPTION & PRESETS */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                  {/* Target Job Title */}
                  <div>
                    <label style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.3rem' }}>
                      Target Job Title
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Full-Stack AI Engineer, Data Scientist..."
                      value={jobTitle}
                      onChange={e => setJobTitle(e.target.value)}
                      className="input-field"
                      style={{ width: '100%', fontSize: '0.82rem', padding: '0.45rem 0.75rem' }}
                    />
                  </div>

                  {/* Preset Buttons */}
                  <div>
                    <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.35rem' }}>
                      Quick Sample Presets (Click to test instant extraction):
                    </span>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                      {samplePresets.map((p, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setJobTitle(p.title);
                            setJobDescription(p.desc);
                          }}
                          className="btn btn-secondary btn-sm"
                          style={{ fontSize: '0.68rem', padding: '0.2rem 0.5rem' }}
                        >
                          + {p.title}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Job Description Textarea */}
                  <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.3rem' }}>
                      <label style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-secondary)' }}>
                        Paste Target Job Posting / Requirements:
                      </label>
                      <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>
                        {jobDescription.length} chars
                      </span>
                    </div>
                    <textarea
                      rows={8}
                      placeholder="Paste the target job description or requirements list here from LinkedIn, Indeed, etc. (Includes skills, required years of experience, qualities, and work scope)..."
                      value={jobDescription}
                      onChange={e => setJobDescription(e.target.value)}
                      className="input-field"
                      style={{ width: '100%', flex: 1, fontSize: '0.78rem', lineHeight: 1.45, resize: 'vertical', minHeight: '160px' }}
                    />
                  </div>

                  {/* HIGHLIGHT BOX: HOW CHANGES ARE APPLIED */}
                  <div style={{ padding: '0.65rem 0.85rem', borderRadius: '8px', background: 'rgba(56, 189, 248, 0.05)', border: '1px solid rgba(56, 189, 248, 0.2)', fontSize: '0.74rem', color: '#94a3b8', display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                    <span style={{ fontWeight: 700, color: '#38bdf8' }}>✓ Tailoring Output Breakdown:</span>
                    <span>• <strong>Skills Section:</strong> Selected technical keywords and tools ({selectedPhrases.size}) are added to your resume skills.</span>
                    <span>• <strong>Summary Section:</strong> Synthesizes required experience, qualities & work scope into a compelling professional profile.</span>
                    <span>• <strong>Headline & Experience:</strong> Aligned with target title & primary deliverables.</span>
                  </div>
                </div>

                {/* RIGHT COLUMN: DETECTED SKILLS, JOB DETAILS & SUMMARY PREVIEW */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                  
                  {/* CARD 1: DETECTED SKILLS FOR RESUME SKILLS SECTION */}
                  <div style={{ background: 'rgba(255, 255, 255, 0.02)', padding: '0.85rem', borderRadius: '10px', border: '1px solid var(--border-subtle)', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                        <Zap size={13} color="#38bdf8" />
                        Skills to Add to Resume ({selectedPhrases.size} selected)
                      </span>
                      {extractedPhrases.length > 0 && (
                        <button
                          type="button"
                          onClick={() => {
                            if (selectedPhrases.size === extractedPhrases.length) {
                              setSelectedPhrases(new Set());
                            } else {
                              setSelectedPhrases(new Set(extractedPhrases));
                            }
                          }}
                          className="btn btn-ghost btn-sm"
                          style={{ fontSize: '0.68rem', padding: '0.15rem 0.4rem', color: 'var(--accent-cyan)' }}
                        >
                          {selectedPhrases.size === extractedPhrases.length ? 'Deselect All' : 'Select All'}
                        </button>
                      )}
                    </div>

                    {/* Skill Chips */}
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem', maxHeight: '110px', overflowY: 'auto' }}>
                      {extractedPhrases.map((phrase, idx) => {
                        const isSelected = selectedPhrases.has(phrase);
                        return (
                          <span
                            key={idx}
                            onClick={() => togglePhrase(phrase)}
                            style={{
                              cursor: 'pointer',
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '0.3rem',
                              padding: '0.22rem 0.48rem',
                              borderRadius: '6px',
                              fontSize: '0.72rem',
                              fontWeight: 600,
                              background: isSelected ? 'rgba(56, 189, 248, 0.18)' : 'rgba(255, 255, 255, 0.04)',
                              border: isSelected ? '1px solid #38bdf8' : '1px solid rgba(255, 255, 255, 0.08)',
                              color: isSelected ? '#38bdf8' : 'var(--text-secondary)',
                              transition: 'all 0.15s'
                            }}
                          >
                            {isSelected ? <Check size={11} /> : <Plus size={11} />}
                            {phrase}
                            <X
                              size={10}
                              style={{ marginLeft: '0.2rem', opacity: 0.6 }}
                              onClick={(e) => {
                                e.stopPropagation();
                                handleRemovePhrase(phrase);
                              }}
                            />
                          </span>
                        );
                      })}
                      {extractedPhrases.length === 0 && (
                        <p style={{ fontSize: '0.74rem', color: 'var(--text-muted)', margin: 0, fontStyle: 'italic' }}>
                          Paste a job description on the left to extract skills automatically.
                        </p>
                      )}
                    </div>

                    {/* Add Custom Word Input */}
                    <form onSubmit={handleAddCustomPhrase} style={{ display: 'flex', gap: '0.4rem', marginTop: '0.2rem' }}>
                      <input
                        type="text"
                        placeholder="Add custom skill/tool..."
                        value={customPhraseInput}
                        onChange={e => setCustomPhraseInput(e.target.value)}
                        className="input-field"
                        style={{ flex: 1, fontSize: '0.74rem', padding: '0.3rem 0.6rem' }}
                      />
                      <button
                        type="button"
                        onClick={() => handleAddCustomPhrase()}
                        className="btn btn-secondary btn-sm"
                        style={{ fontSize: '0.72rem', padding: '0.3rem 0.65rem' }}
                      >
                        <Plus size={12} /> Add
                      </button>
                    </form>
                  </div>

                  {/* CARD 2: EXTRACTED JOB DETAILS (Experience, Qualities, Work) */}
                  {jobDetails && (
                    <div style={{ background: 'rgba(255, 255, 255, 0.02)', padding: '0.75rem 0.85rem', borderRadius: '10px', border: '1px solid rgba(168, 85, 247, 0.25)', display: 'flex', flexDirection: 'column', gap: '0.45rem' }}>
                      <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#c084fc', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                        <Sparkles size={12} />
                        Details Synthesized into Professional Summary:
                      </span>

                      {/* Experience & Seniority Pill */}
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap', fontSize: '0.72rem' }}>
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', color: '#38bdf8', fontWeight: 600 }}>
                          <Briefcase size={12} />
                          Experience:
                        </span>
                        <span className="badge" style={{ background: 'rgba(56, 189, 248, 0.12)', color: '#38bdf8', border: '1px solid rgba(56, 189, 248, 0.25)', padding: '0.15rem 0.45rem', fontSize: '0.7rem' }}>
                          {jobDetails.experienceDetails.yearsText || 'Relevant Industry Track Record'}
                          {jobDetails.experienceDetails.seniority ? ` (${jobDetails.experienceDetails.seniority})` : ''}
                        </span>
                        {jobDetails.experienceDetails.domain && (
                          <span style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>
                            in {jobDetails.experienceDetails.domain}
                          </span>
                        )}
                      </div>

                      {/* Qualities & Traits Pills */}
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap', fontSize: '0.72rem' }}>
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', color: '#f59e0b', fontWeight: 600 }}>
                          <Award size={12} />
                          Qualities:
                        </span>
                        {jobDetails.qualities.map((q, idx) => (
                          <span key={idx} className="badge" style={{ background: 'rgba(245, 158, 11, 0.1)', color: '#fbbf24', border: '1px solid rgba(245, 158, 11, 0.25)', padding: '0.12rem 0.4rem', fontSize: '0.68rem' }}>
                            {q}
                          </span>
                        ))}
                      </div>

                      {/* Work & Responsibilities Pills */}
                      <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.4rem', flexWrap: 'wrap', fontSize: '0.72rem' }}>
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', color: '#10b981', fontWeight: 600, marginTop: '0.15rem' }}>
                          <Layers size={12} />
                          Work Scope:
                        </span>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.2rem', flex: 1 }}>
                          {jobDetails.workResponsibilities.slice(0, 2).map((w, idx) => (
                            <span key={idx} style={{ color: '#cbd5e1', fontSize: '0.7rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                              • {w}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* CARD 3: TARGET PROFESSIONAL SUMMARY (Reflected Live) */}
                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.3rem' }}>
                      <label style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-secondary)' }}>
                        Target Professional Summary (Reflected Live):
                      </label>
                      <button
                        type="button"
                        onClick={handleRegenerateSummary}
                        className="btn btn-ghost btn-sm"
                        style={{ fontSize: '0.68rem', padding: '0.15rem 0.45rem', color: 'var(--accent-cyan)', display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}
                        title="Cycle between alternative phrasing styles (Balanced, Leadership, Technical Mastery)"
                      >
                        <RotateCcw size={11} />
                        Regenerate Phrasing
                      </button>
                    </div>
                    <textarea
                      rows={4}
                      value={targetSummary}
                      onChange={e => setTargetSummary(e.target.value)}
                      className="input-field"
                      style={{ width: '100%', fontSize: '0.76rem', lineHeight: 1.45, resize: 'vertical' }}
                      placeholder="Summary wording automatically targeted to job description with experience, qualities, and work scope..."
                    />
                  </div>

                </div>

              </div>

              {/* FOOTER ACTIONS BAR (Shown exclusively in Workspace Tab) */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem', borderTop: '1px solid var(--border-subtle)', paddingTop: '0.85rem', marginTop: '0.5rem' }}>
                
                {/* Optional AI Auto-Rewrite button */}
                <button
                  type="button"
                  onClick={handleDeepAiTailor}
                  disabled={isAiLoading || !jobDescription.trim()}
                  className="btn btn-secondary btn-sm"
                  style={{
                    fontSize: '0.75rem',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.35rem',
                    color: 'var(--accent-cyan)'
                  }}
                  title="Use Gemini AI to deeply rewrite and optimize experience bullet points for this job"
                >
                  {isAiLoading ? (
                    <>
                      <RefreshCw size={13} className="animate-spin-slow" />
                      <span>AI Re-writing Resume...</span>
                    </>
                  ) : (
                    <>
                      <Cpu size={13} />
                      <span>Deep AI Auto-Tailor (Bullets & Phrasing)</span>
                    </>
                  )}
                </button>

                {/* Cancel & Main Apply Action */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <button
                    type="button"
                    onClick={onClose}
                    className="btn btn-ghost btn-sm"
                    style={{ fontSize: '0.78rem' }}
                  >
                    Cancel
                  </button>

                  <button
                    type="button"
                    onClick={handleApplyToResume}
                    disabled={selectedPhrases.size === 0 && !targetSummary.trim()}
                    className="btn btn-primary btn-sm"
                    style={{
                      fontSize: '0.78rem',
                      fontWeight: 800,
                      padding: '0.45rem 1rem',
                      background: 'linear-gradient(135deg, #00f2fe, #38bdf8)',
                      color: '#030712',
                      border: 'none',
                      boxShadow: '0 0 16px rgba(56, 189, 248, 0.45)'
                    }}
                  >
                    <Zap size={14} />
                    <span>Apply Wording & Skills to Resume ({selectedPhrases.size})</span>
                  </button>
                </div>

              </div>
            </>
          )}

        </div>
      </div>
    </ErrorBoundary>
  );

  return typeof document !== 'undefined' ? createPortal(modalNode, document.body) : modalNode;
};
