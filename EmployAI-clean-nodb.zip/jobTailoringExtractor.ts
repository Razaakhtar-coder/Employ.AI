/**
 * Job Tailoring Extractor & Summary Synthesizer
 * 
 * Extracts from Job Descriptions:
 * 1. Skills (for Resume Skills section)
 * 2. Experience Requirements (years, seniority, domain)
 * 3. Professional Qualities & Attributes (e.g., problem-solving, code standards, ownership, agility)
 * 4. Work Scope & Responsibilities (e.g., architecting systems, deploying pipelines, optimizing workflows)
 * 
 * Synthesizes an ATS-dense, high-impact Professional Summary that weaves
 * Experience, Qualities, Work deliverables, and target Skills together.
 */

export interface ExtractedExperienceDetails {
  yearsText: string | null;
  seniority: string | null;
  domain: string | null;
  rawSnippets: string[];
}

export interface ExtractedJobDetails {
  targetJobTitle: string;
  skills: string[];
  experienceDetails: ExtractedExperienceDetails;
  qualities: string[];
  workResponsibilities: string[];
}

// Built-in technical terms & common keywords for instant client-side extraction
export const COMMON_TECH_TERMS = [
  'Python', 'FastAPI', 'PyTorch', 'TensorFlow', 'LangChain', 'LlamaIndex', 'RAG', 
  'Vector Databases', 'ChromaDB', 'Pinecone', 'FAISS', 'OpenAI API', 'Hugging Face',
  'Docker', 'Kubernetes', 'AWS', 'GCP', 'Azure', 'PostgreSQL', 'SQL', 'MongoDB', 'Redis',
  'TypeScript', 'JavaScript', 'React', 'Node.js', 'Next.js', 'Tailwind CSS', 'GraphQL',
  'Prompt Engineering', 'Fine-tuning', 'Large Language Models', 'LLMs', 'AI Agents',
  'CI/CD', 'Git', 'GitHub Actions', 'REST APIs', 'Microservices', 'System Design',
  'Data Pipelines', 'Pandas', 'NumPy', 'Scikit-learn', 'NLP', 'Computer Vision',
  'Financial Modeling', 'Excel', 'Power BI', 'Tableau', 'Data Analysis',
  'SolidWorks', 'CAD', 'AutoCAD', 'MATLAB', 'Mechanical Design', 'DFM', 'FEA',
  'Agile', 'Scrum', 'Cross-functional Collaboration', 'Semantic Search', 'Embeddings'
];

// Curated dictionary of professional qualities and traits
const QUALITY_PATTERNS: Array<{ trait: string; regex: RegExp }> = [
  { trait: 'Analytical Problem-Solving', regex: /\b(analytical|problem[-\s]?solv|troubleshoot|root[-\s]?cause|critical[-\s]?think)\b/i },
  { trait: 'High Code Quality & Standards', regex: /\b(code\s*quality|clean\s*code|best\s*practices|engineering\s*standards|code\s*review|robust\s*architecture|test[-\s]?driven|qa)\b/i },
  { trait: 'Cross-Functional Collaboration', regex: /\b(cross[-\s]?functional|collaborat|team\s*player|stakeholder|partner\s*with|interpersonal)\b/i },
  { trait: 'Proactive Ownership & Accountability', regex: /\b(ownership|accountab|self[-\s]?starter|proactive|initiative|autonomous|independently)\b/i },
  { trait: 'Agile Adaptability & Velocity', regex: /\b(agile|scrum|fast[-\s]?paced|adaptab|dynamic\s*environment|rapid\s*prototyp|pivot)\b/i },
  { trait: 'Attention to Detail & Precision', regex: /\b(attention\s*to\s*detail|meticulous|precision|accuracy|rigorous|rigour)\b/i },
  { trait: 'Leadership & Mentorship', regex: /\b(leader|mentorship|mentor|guidance|steer|inspire|coach)\b/i },
  { trait: 'User-Centric & Product Mindset', regex: /\b(user[-\s]?centric|customer[-\s]?focused|product\s*mindset|business\s*impact|business\s*value)\b/i }
];

// Seniority keywords
const SENIORITY_LEVELS = [
  { level: 'Lead', regex: /\b(lead|tech\s*lead|team\s*lead)\b/i },
  { level: 'Staff', regex: /\b(staff)\b/i },
  { level: 'Principal', regex: /\b(principal)\b/i },
  { level: 'Senior', regex: /\b(senior|sr\.?)\b/i },
  { level: 'Mid-Level', regex: /\b(mid[-\s]?level|intermediate)\b/i },
  { level: 'Entry-Level', regex: /\b(entry[-\s]?level|junior|jr\.?|associate)\b/i },
  { level: 'Director / Head', regex: /\b(director|head\s*of|vp)\b/i }
];

// Action verbs to detect work responsibilities
const ACTION_VERBS_REGEX = /\b(architect|architecting|develop|developing|build|building|design|designing|implement|implementing|scale|scaling|deploy|deploying|optimize|optimizing|engineer|engineering|automate|automating|lead|leading|orchestrate|orchestrating|spearhead|spearheading|maintain|maintaining|integrate|integrating|deliver|delivering)\b/i;

/**
 * Extracts skills, experience requirements, qualities, and work scope from a Job Description.
 */
export function extractJobDetails(
  jobDescription: string,
  fallbackTitle: string = 'Target Role'
): ExtractedJobDetails {
  if (!jobDescription || !jobDescription.trim()) {
    return {
      targetJobTitle: fallbackTitle,
      skills: [],
      experienceDetails: {
        yearsText: null,
        seniority: null,
        domain: null,
        rawSnippets: []
      },
      qualities: [],
      workResponsibilities: []
    };
  }

  const jdText = jobDescription.trim();
  const jdLower = jdText.toLowerCase();
  const jdLines = jdText.split(/[\r\n]+/).map(l => l.trim()).filter(Boolean);

  // 1. Detect Job Title
  let detectedTitle = '';
  for (const line of jdLines.slice(0, 10)) {
    const titleMatch = line.match(/(?:Job Title|Role|Position|Designation)[:\s]+([^\n\r,•|]+)/i);
    if (titleMatch && titleMatch[1]) {
      let t = titleMatch[1].split(/(?:Requirements|Responsibilities|Company|Location|About|Skills|Qualities|Overview|Qualifications)[:\s]/i)[0].replace(/[\r\n\\]+n?/g, ' ').trim();
      if (t.length >= 2 && t.length <= 60) {
        detectedTitle = t;
        break;
      }
    }
  }
  if (!detectedTitle) {
    const knownRoles = [
      'Full-Stack AI Engineer', 'AI/ML Engineer', 'Full Stack Developer', 'Software Engineer',
      'Senior Software Engineer', 'Frontend Developer', 'Backend Developer', 'Data Scientist',
      'Data Analyst', 'DevOps Engineer', 'Cloud Architect', 'Financial Analyst', 'Business Analyst',
      'Product Manager', 'Mechanical Engineer', 'Civil Engineer', 'Systems Engineer'
    ];
    for (const r of knownRoles) {
      if (jdLower.includes(r.toLowerCase())) {
        detectedTitle = r;
        break;
      }
    }
  }
  const finalTitle = detectedTitle || fallbackTitle || 'Target Role';

  // 2. Extract Skills (Technical & Domain Keywords)
  const skillsFound = new Set<string>();

  // 2a. Common tech terms match
  for (const term of COMMON_TECH_TERMS) {
    const escaped = term.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    const regex = new RegExp(`\\b${escaped}\\b`, 'i');
    if (regex.test(jdText)) {
      skillsFound.add(term);
    }
  }

  const cleanSkillItem = (raw: string): string => {
    return raw
      .replace(/^[\s•\-\*\d\.\)\:]+/, '')
      .replace(/^(?:and|or|with|in|including|knowledge of|experience with|proficient in)\s+/i, '')
      .replace(/[\(\)\[\]]/g, '')
      .trim();
  };

  // 2b. Extract bullet points / lines from "Requirements", "Skills", "Qualifications"
  const listMatches = jdText.match(/(?:Requirements|Skills|Technologies|Proficient in|Experience with|Knowledge of|Qualifications)[:\s]+([^.\n]+)/gi);
  if (listMatches) {
    for (const m of listMatches) {
      const afterColon = m.replace(/^(?:Requirements|Skills|Technologies|Proficient in|Experience with|Knowledge of|Qualifications)[:\s]+/i, '');
      const parts = afterColon.split(/[,|;/•]+/);
      for (const p of parts) {
        const clean = cleanSkillItem(p);
        if (clean.length >= 2 && clean.length <= 35 && !clean.includes('http') && !clean.toLowerCase().includes('year') && !clean.toLowerCase().includes('experience')) {
          skillsFound.add(clean);
        }
      }
    }
  }

  // 2c. Short clean requirement lines
  for (const line of jdLines) {
    if (/^(?:Job Title|Company|Location|Salary|About|Overview|Requirements|Responsibilities|Qualifications)[:\s]/i.test(line)) {
      continue;
    }
    const clean = cleanSkillItem(line);
    if (clean.length >= 3 && clean.length <= 35 && !clean.includes('.') && !clean.toLowerCase().startsWith('http')) {
      if (ACTION_VERBS_REGEX.test(clean)) {
        continue;
      }
      skillsFound.add(clean);
    }
  }

  // 3. Extract Experience Details (Years, Seniority, Domain)
  const experienceSnippets: string[] = [];
  let extractedYears: string | null = null;
  let extractedSeniority: string | null = null;
  let extractedDomain: string | null = null;

  // 3a. Years of experience pattern
  const yearsRegex = /(?:at\s*least|minimum|min\.?|\b)\s*(\d{1,2}(?:\s*(?:to|-|\+)\s*\d{1,2}|\+)?)\s*(?:years?|yrs?)(?:\s+(?:of\s+)?(?:proven\s+|hands-on\s+|demonstrated\s+|relevant\s+)?(?:professional\s+)?experience)?(?:\s+(?:in|with)\s+([a-zA-Z0-9\s,\/&-]{3,40}))?/gi;
  let ym: RegExpExecArray | null;
  while ((ym = yearsRegex.exec(jdText)) !== null) {
    const yrs = ym[1].trim();
    const formattedYrs = yrs.includes('+') || yrs.includes('-') || yrs.toLowerCase().includes('to') ? `${yrs} years` : `${yrs}+ years`;
    if (!extractedYears) {
      extractedYears = formattedYrs;
    }
    const domainSnippet = ym[2]?.trim();
    if (domainSnippet && !extractedDomain && domainSnippet.length < 35 && !domainSnippet.toLowerCase().includes('required')) {
      extractedDomain = domainSnippet;
    }
    experienceSnippets.push(ym[0].trim());
  }

  // 3b. Seniority Level detection
  for (const item of SENIORITY_LEVELS) {
    if (item.regex.test(jdText)) {
      extractedSeniority = item.level;
      break;
    }
  }

  // 3c. Fallback domain from title
  if (!extractedDomain) {
    if (/ai|ml|machine\s*learning|data/i.test(finalTitle)) {
      extractedDomain = 'AI & Machine Learning Systems';
    } else if (/software|full[-\s]?stack|frontend|backend|web/i.test(finalTitle)) {
      extractedDomain = 'Scalable Software Engineering';
    } else if (/cloud|devops|infrastructure|platform/i.test(finalTitle)) {
      extractedDomain = 'Cloud Architecture & DevOps';
    } else if (/finance|financial|account/i.test(finalTitle)) {
      extractedDomain = 'Financial Analysis & Planning';
    } else {
      extractedDomain = `${finalTitle} initiatives`;
    }
  }

  // 4. Extract Qualities & Professional Traits
  const detectedQualities: string[] = [];
  for (const item of QUALITY_PATTERNS) {
    if (item.regex.test(jdText)) {
      detectedQualities.push(item.trait);
    }
  }
  // Default fallback qualities if JD was sparse
  if (detectedQualities.length === 0) {
    detectedQualities.push('Analytical Problem-Solving', 'High Code Quality & Standards', 'Cross-Functional Collaboration');
  }

  // 5. Extract Work Scope & Core Responsibilities
  const responsibilities: string[] = [];
  for (const line of jdLines) {
    const clean = line.replace(/^[\s•\-\*\d\.\)\:]+/, '').trim();
    if (/^(?:Job Title|Company|Location|Requirements|Qualifications|Must demonstrate|Must have|Required)/i.test(clean)) {
      continue;
    }
    if (clean.length >= 25 && clean.length <= 160 && !clean.toLowerCase().startsWith('http')) {
      if (ACTION_VERBS_REGEX.test(clean) && !clean.toLowerCase().includes('requirement') && !clean.toLowerCase().includes('years of') && !clean.toLowerCase().includes('years experience')) {
        responsibilities.push(clean.replace(/[;.]+$/, ''));
      }
    }
  }
  // Fallbacks if no full bullet lines found
  if (responsibilities.length === 0) {
    responsibilities.push(
      `Architecting and deploying scalable, high-performance solutions aligned with ${finalTitle} best practices`,
      'Leading end-to-end technical deliverables and automating mission-critical workflows',
      'Collaborating cross-functionally with stakeholders to drive continuous system optimization and reliability'
    );
  }

  return {
    targetJobTitle: finalTitle,
    skills: Array.from(skillsFound).slice(0, 30),
    experienceDetails: {
      yearsText: extractedYears,
      seniority: extractedSeniority,
      domain: extractedDomain,
      rawSnippets: experienceSnippets.slice(0, 3)
    },
    qualities: detectedQualities.slice(0, 4),
    workResponsibilities: responsibilities.slice(0, 5)
  };
}

/**
 * Synthesizes an ATS-dense, natural Professional Summary incorporating:
 * 1. Experience & Seniority
 * 2. Key Qualities & Professional Traits
 * 3. Core Work Deliverables & Responsibilities
 * 4. Target Technical Skills
 */
export function generateTailoredProfessionalSummary(options: {
  jobTitle: string;
  skills: string[];
  experienceDetails: ExtractedExperienceDetails;
  qualities: string[];
  workResponsibilities: string[];
  existingSummary?: string | null;
  styleVariation?: number;
}): string {
  const {
    jobTitle,
    skills,
    experienceDetails,
    qualities,
    workResponsibilities,
    styleVariation = 0
  } = options;

  const rawTitle = jobTitle.trim() || 'Industry Professional';
  let fullRoleTitle = rawTitle;
  if (experienceDetails.seniority && !rawTitle.toLowerCase().includes(experienceDetails.seniority.toLowerCase())) {
    fullRoleTitle = `${experienceDetails.seniority} ${rawTitle}`;
  }
  const yearsText = experienceDetails.yearsText || 'demonstrated';
  const domain = experienceDetails.domain || 'high-impact enterprise initiatives';

  const topSkills = skills.slice(0, 5).join(', ');
  const topQualities = qualities.slice(0, 3);
  
  // Format qualities phrase
  const qualitiesPhrase = topQualities.length > 0 
    ? topQualities.join(', ').toLowerCase().replace(/,\s*([^,]+)$/, ', and $1')
    : 'analytical problem-solving, collaborative leadership, and dedication to engineering excellence';

  // Format work responsibilities phrase
  let workPhrase = '';
  if (workResponsibilities.length > 0) {
    // Pick 1-2 representative work lines
    const cleanWork = workResponsibilities[styleVariation % workResponsibilities.length]
      .replace(/^(spearheaded|architected|developed|engineered|built|designed|led|managed|implemented|optimized|collaborated to|responsible for)\s+/i, '')
      .replace(/[.;]+$/, '');
    
    // Convert to gerund phrasing for fluent flow
    const firstWord = cleanWork.split(' ')[0] || '';
    let gerundWork = cleanWork;
    if (firstWord && !firstWord.endsWith('ing')) {
      gerundWork = `delivering ${cleanWork}`;
    }
    workPhrase = gerundWork;
  } else {
    workPhrase = 'architecting scalable systems, streamlining technical workflows, and deploying mission-critical deliverables';
  }

  // Generate varied, fluid styles for user exploration
  switch (styleVariation % 3) {
    case 1:
      // High-Velocity / Leadership Focus
      return `Results-driven ${fullRoleTitle} with ${yearsText} experience delivering scalable solutions across ${domain}. Proven track record in ${workPhrase}. Recognized for ${qualitiesPhrase}, with demonstrated proficiency in ${topSkills || 'modern technical architectures'}.`;

    case 2:
      // Technical Mastery & Delivery Focus
      return `Accomplished ${fullRoleTitle} offering ${yearsText} hands-on expertise in ${domain}. Deep technical specialization in ${topSkills || 'industry-standard frameworks'} coupled with a strong track record of ${workPhrase}. Highly valued for ${qualitiesPhrase} to drive reliable business outcomes.`;

    case 0:
    default:
      // Balanced ATS Standard (Experience + Work + Qualities + Skills)
      return `Results-oriented ${fullRoleTitle} with ${yearsText} background specializing in ${domain}. Proven capability in ${workPhrase}. Combines ${qualitiesPhrase} with deep hands-on expertise across ${topSkills || 'core technical competencies'} to deliver measurable business impact.`;
  }
}
