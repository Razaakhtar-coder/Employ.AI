import React, { useState, useMemo } from 'react';
import { createPortal } from 'react-dom';
import type { 
  StructuredResume, 
  ResumeProjectItem, 
  ResumeExperienceItem, 
  ResumeEducationItem, 
  ResumeCertificationItem 
} from '../types';
import { calculateATSScore } from '../services/atsScoring';
import { 
  Sparkles, X, Plus, Trash2, User, 
  FileText, Code, Briefcase, GraduationCap, 
  Check, Zap, Globe, Link2, 
  Mail, Phone, MapPin, 
  ChevronRight, RefreshCw, Wand2, Star, CheckCircle2,
  Terminal, Trophy
} from 'lucide-react';
import { sanitizeAndFormatUrl } from '../utils/urlHelper';

interface CreateResumeScratchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (newStructuredResume: StructuredResume, filename?: string) => Promise<void> | void;
  initialRolePreset?: string;
}

const PRESET_TEMPLATES: Record<string, { label: string; icon: string; data: StructuredResume }> = {
  fullstack: {
    label: 'Full-Stack Web Developer',
    icon: '🌐',
    data: {
      personal_info: {
        full_name: 'Rahul Sharma',
        headline: 'Full-Stack Software Engineer | React, Node.js, Cloud Architectures',
        email: 'rahul.sharma@example.edu',
        phone: '+91 98765 43210',
        location: 'Bengaluru, India',
        linkedin: 'https://linkedin.com/in/rahul-sharma-dev',
        github: 'https://github.com/rahulsharma-dev',
        portfolio: 'https://rahulsharma.dev'
      },
      summary: 'Proactive Full-Stack Software Engineer with strong foundations in React, TypeScript, Node.js, and distributed microservices. Proven track record in architecting high-performance web applications, optimizing database queries by 45%, and deploying scalable containerized backends on AWS.',
      skills: [
        'TypeScript', 'React.js', 'Next.js', 'Node.js', 'Express.js', 
        'Python', 'PostgreSQL', 'MongoDB', 'Redis', 'Docker', 
        'AWS (S3, EC2, Lambda)', 'GraphQL', 'REST APIs', 'Git', 'CI/CD Pipelines'
      ],
      projects: [
        {
          id: 'proj-1',
          title: 'CloudScale - Distributed Task Queue & Telemetry Platform',
          role_or_tech: 'Lead Architect | Next.js, Node.js, Redis, Docker, PostgreSQL',
          description: 'Engineered high-throughput background processing system capable of queuing and executing asynchronous workflows with live telemetry dashboards.',
          technologies: ['TypeScript', 'Next.js', 'Redis', 'Node.js', 'Docker', 'PostgreSQL'],
          bullets: [
            'Architected asynchronous message processing pipeline using Redis and BullMQ, handling 15,000+ jobs/min with 99.98% uptime.',
            'Optimized relational query patterns and indexing in PostgreSQL, slashing database p95 response latencies by 42%.',
            'Implemented real-time WebSocket telemetry stream delivering instantaneous status feedback to over 1,200 concurrent web clients.',
            'Containerized services using Docker multi-stage builds and automated CI/CD deployment workflows via GitHub Actions.'
          ],
          url: 'https://cloudscale-demo.app',
          code_url: 'https://github.com/rahulsharma-dev/cloudscale'
        },
        {
          id: 'proj-2',
          title: 'AI Portfolio & Resume STAR Generator',
          role_or_tech: 'Full-Stack Developer | React, FastAPI, Python, Vector DB',
          description: 'AI-driven candidate preparation tool analyzing technical skill gaps and enhancing resume STAR bullet metrics in real time.',
          technologies: ['React', 'Python', 'FastAPI', 'TailwindCSS', 'ChromaDB'],
          bullets: [
            'Engineered responsive interactive UI utilizing React and TailwindCSS with zero-latency client state management.',
            'Integrated LLM embeddings pipeline with Vector Search to match candidate projects against 500+ active industry roles.',
            'Implemented quantifiable bullet scoring algorithm increasing average applicant ATS parse rates from 62% to 94%.'
          ],
          url: 'https://employai-preview.app',
          code_url: 'https://github.com/rahulsharma-dev/employai'
        }
      ],
      experience: [
        {
          id: 'exp-1',
          company: 'Nexus Infotech Solutions',
          role: 'Software Development Engineering Intern',
          location: 'Bengaluru, India',
          duration: 'Jan 2025 – Jul 2025',
          technologies: ['React', 'TypeScript', 'Node.js', 'PostgreSQL'],
          bullets: [
            'Developed 8+ reusable core dashboard widgets in React/TypeScript, improving front-end page load velocity by 35%.',
            'Refactored legacy REST endpoints into modular micro-services, cutting server response payload sizes by 28%.',
            'Collaborated with senior engineering team in agile sprints, participating in code reviews and test-driven development (Jest).'
          ]
        }
      ],
      education: [
        {
          institution: 'National Institute of Technology',
          degree: 'Bachelor of Technology (B.Tech)',
          field_of_study: 'Computer Science and Engineering',
          start_year: '2022',
          end_year: '2026',
          grade_or_cgpa: '8.8 / 10.0',
          location: 'Karnataka, India'
        }
      ],
      certifications: [
        { name: 'AWS Certified Solutions Architect – Associate', issuer: 'Amazon Web Services', year: '2025' },
        { name: 'Meta Front-End Developer Professional Certificate', issuer: 'Meta / Coursera', year: '2024' }
      ]
    }
  },
  ai_ml: {
    label: 'AI & Machine Learning Engineer',
    icon: '🤖',
    data: {
      personal_info: {
        full_name: 'Ananya Verma',
        headline: 'AI/ML Engineer | PyTorch, Transformers, LLM Fine-Tuning & Computer Vision',
        email: 'ananya.verma@example.edu',
        phone: '+91 91234 56789',
        location: 'Hyderabad, India',
        linkedin: 'https://linkedin.com/in/ananya-verma-ai',
        github: 'https://github.com/ananyaverma-ai',
        portfolio: 'https://ananyaverma.dev'
      },
      summary: 'Passionate Machine Learning Engineer specializing in Natural Language Processing, Transformer architectures, and MLOps deployment. Experienced in training deep learning models, fine-tuning open-source LLMs using LoRA/QLoRA, and serving low-latency inference APIs with ONNX and TensorRT.',
      skills: [
        'Python', 'PyTorch', 'TensorFlow', 'Hugging Face Transformers', 
        'FastAPI', 'LangChain', 'OpenCV', 'Pandas', 'NumPy', 'Scikit-Learn', 
        'MLflow', 'Docker', 'CUDA', 'Vector Databases (Chroma, Pinecone)', 'Git'
      ],
      projects: [
        {
          id: 'proj-1',
          title: 'DocuSense - Multimodal Document Q&A with RAG & LoRA',
          role_or_tech: 'ML Engineer | PyTorch, Hugging Face, LangChain, FastAPI',
          description: 'End-to-end Retrieval-Augmented Generation system allowing enterprise users to query dense PDF manuals and receive verifiable citations.',
          technologies: ['Python', 'PyTorch', 'Hugging Face', 'LangChain', 'FastAPI', 'Qdrant'],
          bullets: [
            'Fine-tuned Llama-3-8B model using QLoRA on 25k domain technical documents, boosting domain accuracy by 28%.',
            'Implemented hybrid dense-sparse retrieval pipeline with BM25 and vector embeddings, reducing hallucination rate below 3%.',
            'Optimized model inference with vLLM and TensorRT-LLM, achieving 3.5x higher token throughput on single GPU instance.'
          ],
          url: 'https://docusense-demo.io',
          code_url: 'https://github.com/ananyaverma-ai/docusense'
        },
        {
          id: 'proj-2',
          title: 'VisionPulse - Real-Time Autonomous Defect Detection',
          role_or_tech: 'Computer Vision Developer | YOLOv9, OpenCV, PyTorch',
          description: 'Edge-deployed computer vision model for manufacturing anomaly detection running at 60 FPS on embedded edge hardware.',
          technologies: ['Python', 'YOLOv9', 'OpenCV', 'PyTorch', 'ONNX Runtime'],
          bullets: [
            'Trained custom YOLOv9 vision model on 12,000 annotated industrial parts, achieving 96.4% mean Average Precision (mAP@50).',
            'Quantized FP32 weights to INT8 via TensorRT, cutting model footprint by 65% while maintaining 98.8% baseline precision.'
          ],
          url: 'https://visionpulse.ai',
          code_url: 'https://github.com/ananyaverma-ai/visionpulse'
        }
      ],
      experience: [
        {
          id: 'exp-1',
          company: 'Cerebral AI Labs',
          role: 'Machine Learning Research Intern',
          location: 'Hyderabad, India',
          duration: 'May 2025 – Jul 2025',
          technologies: ['Python', 'PyTorch', 'Transformers', 'FastAPI'],
          bullets: [
            'Curated and synthetic-augmented 50,000+ domain instruction-tuning datasets for semantic search evaluation.',
            'Benchmarked latency vs quality trade-offs across quantized open-source models, authoring internal evaluation harness.'
          ]
        }
      ],
      education: [
        {
          institution: 'Indian Institute of Information Technology',
          degree: 'Bachelor of Technology (B.Tech)',
          field_of_study: 'Data Science & Artificial Intelligence',
          start_year: '2022',
          end_year: '2026',
          grade_or_cgpa: '9.1 / 10.0',
          location: 'Telangana, India'
        }
      ],
      certifications: [
        { name: 'Deep Learning Specialization', issuer: 'DeepLearning.AI / Andrew Ng', year: '2024' },
        { name: 'TensorFlow Developer Certificate', issuer: 'Google', year: '2024' }
      ]
    }
  },
  data_analytics: {
    label: 'Data Analyst & Engineer',
    icon: '📊',
    data: {
      personal_info: {
        full_name: 'Pooja Nair',
        headline: 'Data Analyst & BI Specialist | SQL, Python, Tableau, ETL Pipelines',
        email: 'pooja.nair@example.edu',
        phone: '+91 97654 32109',
        location: 'Pune, India',
        linkedin: 'https://linkedin.com/in/pooja-nair-data',
        github: 'https://github.com/poojanair-data',
        portfolio: 'https://poojanair-analytics.dev'
      },
      summary: 'Analytical and results-oriented Data Analyst with expertise in SQL query optimization, Python data processing (Pandas, NumPy), and executive Tableau visualization. Experienced in building automated ETL pipelines and extracting actionable business intelligence from complex multi-source datasets.',
      skills: [
        'Advanced SQL (PostgreSQL, Snowflake)', 'Python (Pandas, NumPy, Seaborn)', 
        'Tableau', 'Power BI', 'ETL Pipeline Design', 'dbt', 'Data Modeling', 
        'Excel (VBA, Power Query)', 'Statistical Analysis', 'A/B Testing', 'Git'
      ],
      projects: [
        {
          id: 'proj-1',
          title: 'MarketPulse - E-Commerce Churn & Revenue Intelligence',
          role_or_tech: 'Data Analyst | SQL, Python, Tableau, PostgreSQL',
          description: 'Comprehensive business intelligence analytics suite analyzing 250,000+ customer transactions to identify churn triggers.',
          technologies: ['SQL', 'Python', 'Tableau', 'PostgreSQL'],
          bullets: [
            'Extracted and transformed 250,000+ raw transactional records using complex SQL window functions and CTEs.',
            'Built predictive customer lifetime value (CLV) model in Python, identifying segment drivers accounting for 65% of revenue.',
            'Designed 6 interactive executive Tableau dashboards adopted by marketing leadership for weekly campaign reviews.'
          ],
          url: 'https://public.tableau.com/profile/pooja-marketpulse',
          code_url: 'https://github.com/poojanair-data/marketpulse'
        }
      ],
      experience: [
        {
          id: 'exp-1',
          company: 'Vertex Analytics Group',
          role: 'Data Analytics Intern',
          location: 'Pune, India',
          duration: 'Jan 2025 – May 2025',
          technologies: ['SQL', 'Python', 'Power BI'],
          bullets: [
            'Automated weekly data reconciliation scripts in Python, saving 8 hours of manual analysis per week.',
            'Cleaned and standardized multi-channel customer feedback data, improving downstream analytics reliability by 92%.'
          ]
        }
      ],
      education: [
        {
          institution: 'Pune Institute of Computer Technology',
          degree: 'Bachelor of Engineering (B.E.)',
          field_of_study: 'Information Technology',
          start_year: '2022',
          end_year: '2026',
          grade_or_cgpa: '8.7 / 10.0',
          location: 'Maharashtra, India'
        }
      ],
      certifications: [
        { name: 'Google Data Analytics Professional Certificate', issuer: 'Google', year: '2024' }
      ]
    }
  },
  blank: {
    label: 'Custom Blank Slate',
    icon: '📄',
    data: {
      personal_info: {
        full_name: '',
        headline: '',
        email: '',
        phone: '',
        location: '',
        linkedin: '',
        github: '',
        portfolio: ''
      },
      summary: '',
      skills: [],
      projects: [
        {
          id: 'proj-1',
          title: '',
          role_or_tech: '',
          description: '',
          technologies: [],
          bullets: ['']
        }
      ],
      experience: [
        {
          id: 'exp-1',
          company: '',
          role: '',
          location: '',
          duration: '',
          technologies: [],
          bullets: ['']
        }
      ],
      education: [
        {
          institution: '',
          degree: 'Bachelor of Technology (B.Tech)',
          field_of_study: '',
          start_year: '2022',
          end_year: '2026',
          grade_or_cgpa: '',
          location: ''
        }
      ],
      certifications: []
    }
  }
};

const SUGGESTED_SKILL_CATEGORIES = [
  {
    category: 'Core Languages',
    skills: ['Python', 'JavaScript', 'TypeScript', 'Java', 'C++', 'Go', 'SQL', 'Rust']
  },
  {
    category: 'Web & Frameworks',
    skills: ['React', 'Next.js', 'Node.js', 'Express.js', 'FastAPI', 'Spring Boot', 'Django', 'TailwindCSS']
  },
  {
    category: 'Cloud, DevOps & DB',
    skills: ['AWS', 'Docker', 'Kubernetes', 'PostgreSQL', 'MongoDB', 'Redis', 'CI/CD', 'Git', 'Linux']
  },
  {
    category: 'AI, Data & Tools',
    skills: ['PyTorch', 'TensorFlow', 'Pandas', 'REST APIs', 'GraphQL', 'Microservices', 'Jest', 'System Design']
  }
];

const SUMMARY_TEMPLATES = [
  {
    label: '💡 High-Impact Software Engineer',
    text: 'Results-driven Software Engineer with solid foundations in data structures, algorithms, full-stack architecture, and cloud services. Proven ability to build performant web applications, optimize APIs, and collaborate in agile engineering sprints.'
  },
  {
    label: '🤖 AI & Data Science Specialist',
    text: 'Forward-thinking AI & Machine Learning specialist with hands-on experience in building and deploying predictive models, deep learning architectures, and scalable data processing pipelines. Passionate about applying cutting-edge AI to solve real-world problems.'
  },
  {
    label: '🎯 Ambitious College Graduate / Fresher',
    text: 'Motivated Computer Science undergraduate with hands-on project experience in modern web technologies, backend API development, and database management. Eager to contribute strong problem-solving abilities and rapid learning skills to a high-velocity engineering team.'
  }
];

export const CreateResumeScratchModal: React.FC<CreateResumeScratchModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialRolePreset = 'fullstack'
}) => {
  const [activeTab, setActiveTab] = useState<'info' | 'summary' | 'skills' | 'projects' | 'experience' | 'education'>('info');
  const [resumeData, setResumeData] = useState<StructuredResume>(() => {
    return JSON.parse(JSON.stringify(PRESET_TEMPLATES[initialRolePreset]?.data || PRESET_TEMPLATES.fullstack.data));
  });

  const [newSkillInput, setNewSkillInput] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // Real-time ATS score calculation (must be called unconditionally)
  const calculatedATS = useMemo(() => {
    if (!isOpen) return { overall_score: 85, score_breakdown: { structure: 85, content_impact: 85, skill_density: 85, formatting_clarity: 90, overall_quality: 85 } };
    return calculateATSScore(resumeData, 85);
  }, [resumeData, isOpen]);

  if (!isOpen) return null;

  const loadPreset = (presetKey: string) => {
    const preset = PRESET_TEMPLATES[presetKey];
    if (preset) {
      setResumeData(JSON.parse(JSON.stringify(preset.data)));
    }
  };

  // Helper updates
  const updatePersonalInfo = (field: string, val: string) => {
    setResumeData(prev => ({
      ...prev,
      personal_info: {
        ...(prev.personal_info || {}),
        [field]: val
      }
    }));
  };

  const handleAddSkill = (skill: string) => {
    const trimmed = skill.trim();
    if (!trimmed) return;
    if (!resumeData.skills.includes(trimmed)) {
      setResumeData(prev => ({
        ...prev,
        skills: [...prev.skills, trimmed]
      }));
    }
    setNewSkillInput('');
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setResumeData(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s !== skillToRemove)
    }));
  };

  // Projects helpers
  const handleAddProject = () => {
    const newProj: ResumeProjectItem = {
      id: `proj-${Date.now()}`,
      title: 'New Project Title',
      role_or_tech: 'Full-Stack Developer | React, Node.js',
      description: 'Brief overview of project architecture and primary user value.',
      technologies: ['React', 'Node.js'],
      bullets: [
        'Engineered scalable microservice handling real-time user requests with 99.9% uptime.',
        'Optimized core database query execution, reducing latency by 35%.'
      ]
    };
    setResumeData(prev => ({
      ...prev,
      projects: [...prev.projects, newProj]
    }));
  };

  const handleUpdateProject = (index: number, field: keyof ResumeProjectItem, val: any) => {
    setResumeData(prev => {
      const nextProjs = [...prev.projects];
      nextProjs[index] = { ...nextProjs[index], [field]: val };
      return { ...prev, projects: nextProjs };
    });
  };

  const handleDeleteProject = (index: number) => {
    setResumeData(prev => ({
      ...prev,
      projects: prev.projects.filter((_, i) => i !== index)
    }));
  };

  const handleAddProjectBullet = (projIndex: number) => {
    setResumeData(prev => {
      const nextProjs = [...prev.projects];
      const curBullets = nextProjs[projIndex].bullets || [];
      nextProjs[projIndex] = {
        ...nextProjs[projIndex],
        bullets: [...curBullets, 'Achieved measurable impact by implementing key technical optimization.']
      };
      return { ...prev, projects: nextProjs };
    });
  };

  const handleUpdateProjectBullet = (projIndex: number, bulletIndex: number, val: string) => {
    setResumeData(prev => {
      const nextProjs = [...prev.projects];
      const curBullets = [...(nextProjs[projIndex].bullets || [])];
      curBullets[bulletIndex] = val;
      nextProjs[projIndex] = { ...nextProjs[projIndex], bullets: curBullets };
      return { ...prev, projects: nextProjs };
    });
  };

  const handleDeleteProjectBullet = (projIndex: number, bulletIndex: number) => {
    setResumeData(prev => {
      const nextProjs = [...prev.projects];
      const curBullets = (nextProjs[projIndex].bullets || []).filter((_, i) => i !== bulletIndex);
      nextProjs[projIndex] = { ...nextProjs[projIndex], bullets: curBullets };
      return { ...prev, projects: nextProjs };
    });
  };

  // Experience helpers
  const handleAddExperience = () => {
    const newExp: ResumeExperienceItem = {
      id: `exp-${Date.now()}`,
      company: 'Organization Name',
      role: 'Software Engineering Intern',
      location: 'City, Country',
      duration: 'May 2025 – Aug 2025',
      technologies: ['React', 'TypeScript'],
      bullets: [
        'Developed performant user interface components, improving user engagement metrics by 25%.',
        'Collaborated with cross-functional engineering teams in daily standups and sprint planning.'
      ]
    };
    setResumeData(prev => ({
      ...prev,
      experience: [...prev.experience, newExp]
    }));
  };

  const handleUpdateExperience = (index: number, field: keyof ResumeExperienceItem, val: any) => {
    setResumeData(prev => {
      const nextExps = [...prev.experience];
      nextExps[index] = { ...nextExps[index], [field]: val };
      return { ...prev, experience: nextExps };
    });
  };

  const handleDeleteExperience = (index: number) => {
    setResumeData(prev => ({
      ...prev,
      experience: prev.experience.filter((_, i) => i !== index)
    }));
  };

  const handleAddExperienceBullet = (expIndex: number) => {
    setResumeData(prev => {
      const nextExps = [...prev.experience];
      const curBullets = nextExps[expIndex].bullets || [];
      nextExps[expIndex] = {
        ...nextExps[expIndex],
        bullets: [...curBullets, 'Implemented critical workflow optimization boosting operational throughput by 30%.']
      };
      return { ...prev, experience: nextExps };
    });
  };

  const handleUpdateExperienceBullet = (expIndex: number, bulletIndex: number, val: string) => {
    setResumeData(prev => {
      const nextExps = [...prev.experience];
      const curBullets = [...(nextExps[expIndex].bullets || [])];
      curBullets[bulletIndex] = val;
      nextExps[expIndex] = { ...nextExps[expIndex], bullets: curBullets };
      return { ...prev, experience: nextExps };
    });
  };

  const handleDeleteExperienceBullet = (expIndex: number, bulletIndex: number) => {
    setResumeData(prev => {
      const nextExps = [...prev.experience];
      const curBullets = (nextExps[expIndex].bullets || []).filter((_, i) => i !== bulletIndex);
      nextExps[expIndex] = { ...nextExps[expIndex], bullets: curBullets };
      return { ...prev, experience: nextExps };
    });
  };

  // Education helpers
  const handleAddEducation = () => {
    const newEdu: ResumeEducationItem = {
      institution: 'University / Institute Name',
      degree: 'Bachelor of Technology (B.Tech)',
      field_of_study: 'Computer Science & Engineering',
      start_year: '2022',
      end_year: '2026',
      grade_or_cgpa: '8.5 / 10.0',
      location: 'City, Country'
    };
    setResumeData(prev => ({
      ...prev,
      education: [...prev.education, newEdu]
    }));
  };

  const handleUpdateEducation = (index: number, field: keyof ResumeEducationItem, val: any) => {
    setResumeData(prev => {
      const nextEdus = [...prev.education];
      nextEdus[index] = { ...nextEdus[index], [field]: val };
      return { ...prev, education: nextEdus };
    });
  };

  const handleDeleteEducation = (index: number) => {
    setResumeData(prev => ({
      ...prev,
      education: prev.education.filter((_, i) => i !== index)
    }));
  };

  // Certifications helpers
  const handleAddCertification = () => {
    const newCert: ResumeCertificationItem = {
      name: 'Certification Title (e.g. AWS Certified Developer)',
      issuer: 'Issuing Body (e.g. Amazon Web Services)',
      year: '2025'
    };
    setResumeData(prev => ({
      ...prev,
      certifications: [...(prev.certifications || []), newCert]
    }));
  };

  const handleUpdateCertification = (index: number, field: keyof ResumeCertificationItem, val: any) => {
    setResumeData(prev => {
      const nextCerts = [...(prev.certifications || [])];
      nextCerts[index] = { ...nextCerts[index], [field]: val };
      return { ...prev, certifications: nextCerts };
    });
  };

  const handleDeleteCertification = (index: number) => {
    setResumeData(prev => ({
      ...prev,
      certifications: (prev.certifications || []).filter((_, i) => i !== index)
    }));
  };

  // Final Submit
  const handleSaveAndLaunch = async () => {
    setIsSaving(true);
    try {
      const sanitizedData: StructuredResume = {
        ...resumeData,
        personal_info: {
          ...(resumeData.personal_info || {}),
          linkedin: sanitizeAndFormatUrl(resumeData.personal_info?.linkedin) || undefined,
          github: sanitizeAndFormatUrl(resumeData.personal_info?.github) || undefined,
          portfolio: sanitizeAndFormatUrl(resumeData.personal_info?.portfolio) || undefined,
          leetcode: sanitizeAndFormatUrl(resumeData.personal_info?.leetcode) || undefined,
          codeforces: sanitizeAndFormatUrl(resumeData.personal_info?.codeforces) || undefined
        },
        projects: (resumeData.projects || []).map(p => ({
          ...p,
          url: sanitizeAndFormatUrl(p.url) || undefined,
          code_url: sanitizeAndFormatUrl(p.code_url) || undefined
        }))
      };
      const candidateName = (sanitizedData.personal_info?.full_name || 'My_Resume').trim().replace(/\s+/g, '_');
      const filename = `${candidateName}_ATS_Resume.pdf`;
      await onSave(sanitizedData, filename);
      onClose();
    } catch (err) {
      console.error('Error saving resume:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const score = calculatedATS.overall_score || 85;

  const modalNode = (
    <div 
      className="modal-backdrop"
      style={{
        position: 'fixed',
        inset: 0,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100vw',
        height: '100vh',
        backgroundColor: 'rgba(3, 7, 18, 0.88)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 99999,
        padding: '1rem',
        boxSizing: 'border-box'
      }}
    >
      <div 
        className="glass-card" 
        style={{
          width: '100%',
          maxWidth: '1080px',
          maxHeight: '92vh',
          display: 'flex',
          flexDirection: 'column',
          borderRadius: 'var(--radius-lg)',
          background: 'var(--bg-card)',
          border: '1px solid rgba(56, 189, 248, 0.45)',
          boxShadow: '0 25px 60px -15px rgba(0, 0, 0, 0.9), 0 0 40px rgba(56, 189, 248, 0.2)',
          overflow: 'hidden',
          position: 'relative'
        }}
      >
        {/* Top Header */}
        <div style={{
          padding: '1.25rem 1.75rem',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: 'rgba(255, 255, 255, 0.02)',
          flexWrap: 'wrap',
          gap: '1rem'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
            <div style={{
              width: '42px',
              height: '42px',
              borderRadius: '12px',
              background: 'linear-gradient(135deg, rgba(56, 189, 248, 0.25), rgba(16, 185, 129, 0.25))',
              border: '1px solid var(--accent-cyan)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--accent-cyan)'
            }}>
              <Wand2 size={22} />
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                  Make Resume From Scratch
                </h2>
                <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>
                  <Sparkles size={11} /> AI STAR Builder
                </span>
              </div>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0.15rem 0 0 0' }}>
                Build an authentic ATS-optimized resume section by section with live STAR quantified impacts.
              </p>
            </div>
          </div>

          {/* Top Actions: Live ATS Score Badge + Close Button */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.6rem',
              padding: '0.4rem 0.8rem',
              borderRadius: '8px',
              background: 'rgba(56, 189, 248, 0.08)',
              border: '1px solid rgba(56, 189, 248, 0.3)'
            }}>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
                <span style={{ fontSize: '0.65rem', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Live ATS Score</span>
                <span style={{ fontSize: '0.95rem', fontWeight: 800, color: score >= 85 ? '#34d399' : '#38bdf8' }}>
                  {score}/100
                </span>
              </div>
              <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#10b981', boxShadow: '0 0 8px #10b981' }} />
            </div>

            <button
              onClick={onClose}
              style={{
                background: 'rgba(255, 255, 255, 0.05)',
                border: 'none',
                borderRadius: '50%',
                width: '32px',
                height: '32px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--text-muted)',
                cursor: 'pointer',
                transition: 'all 0.15s'
              }}
              title="Close modal"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Quickstart Presets Bar */}
        <div style={{
          padding: '0.65rem 1.75rem',
          background: 'rgba(255, 255, 255, 0.015)',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '0.5rem'
        }}>
          <span style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
            <Zap size={13} color="#f59e0b" /> Starter Presets:
          </span>
          <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
            {Object.entries(PRESET_TEMPLATES).map(([key, item]) => (
              <button
                key={key}
                onClick={() => loadPreset(key)}
                className="btn btn-secondary btn-sm"
                style={{
                  fontSize: '0.72rem',
                  padding: '0.25rem 0.6rem',
                  borderRadius: '6px',
                  background: 'rgba(255, 255, 255, 0.03)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.3rem'
                }}
                title={`Load ${item.label} Starter Template`}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Main Content Area (Tabs on Left, Form on Right) */}
        <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
          {/* Left Section Tabs */}
          <div style={{
            width: '230px',
            borderRight: '1px solid var(--border-subtle)',
            background: 'var(--bg-tertiary)',
            padding: '1rem 0.75rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.35rem',
            flexShrink: 0
          }}>
            {[
              { id: 'info', label: '1. Personal & Links', icon: User, count: (resumeData.personal_info?.full_name ? '✓' : '•') },
              { id: 'summary', label: '2. Summary Pitch', icon: FileText, count: (resumeData.summary ? '✓' : '•') },
              { id: 'skills', label: '3. Technical Skills', icon: Code, count: resumeData.skills?.length || 0 },
              { id: 'projects', label: '4. Projects (STAR)', icon: Star, count: resumeData.projects?.length || 0 },
              { id: 'experience', label: '5. Internships & Work', icon: Briefcase, count: resumeData.experience?.length || 0 },
              { id: 'education', label: '6. Education & Certs', icon: GraduationCap, count: (resumeData.education?.length || 0) + (resumeData.certifications?.length || 0) }
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '0.65rem 0.8rem',
                    borderRadius: '8px',
                    border: isActive ? '1px solid var(--accent-cyan)' : '1px solid transparent',
                    background: isActive ? 'rgba(56, 189, 248, 0.12)' : 'transparent',
                    color: isActive ? 'var(--accent-cyan)' : 'var(--text-secondary)',
                    fontWeight: isActive ? 700 : 500,
                    fontSize: '0.78rem',
                    cursor: 'pointer',
                    textAlign: 'left',
                    transition: 'all 0.15s'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.55rem' }}>
                    <Icon size={16} />
                    <span>{tab.label}</span>
                  </div>
                  <span className="badge badge-secondary" style={{ fontSize: '0.65rem', padding: '0.1rem 0.4rem' }}>
                    {tab.count}
                  </span>
                </button>
              );
            })}

            {/* Live ATS Completeness Checklist */}
            <div style={{ marginTop: 'auto', padding: '0.85rem', borderRadius: '10px', background: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--border-subtle)' }}>
              <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', display: 'block', marginBottom: '0.4rem' }}>
                ATS Readiness Checklist
              </span>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.3rem', fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: resumeData.personal_info?.full_name ? '#34d399' : 'inherit' }}>
                  <CheckCircle2 size={12} /> Contact & Headline
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: (resumeData.summary?.length || 0) > 30 ? '#34d399' : 'inherit' }}>
                  <CheckCircle2 size={12} /> Executive Summary
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: (resumeData.skills?.length || 0) >= 8 ? '#34d399' : 'inherit' }}>
                  <CheckCircle2 size={12} /> 8+ Core Technical Skills
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: (resumeData.projects?.length || 0) >= 1 ? '#34d399' : 'inherit' }}>
                  <CheckCircle2 size={12} /> Quantified Projects
                </div>
              </div>
            </div>
          </div>

          {/* Right Active Tab Content */}
          <div style={{ flex: 1, padding: '1.5rem', overflowY: 'auto', maxHeight: 'calc(92vh - 160px)' }}>
            
            {/* 1. PERSONAL INFO TAB */}
            {activeTab === 'info' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <div>
                  <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 0.25rem 0' }}>
                    Candidate Contact & Social Links
                  </h3>
                  <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: 0 }}>
                    Enter your authentic contact information and verifiable profile links (GitHub, LinkedIn, Portfolio).
                  </p>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '0.85rem' }}>
                  <div>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.3rem' }}>
                      Full Name *
                    </label>
                    <div style={{ position: 'relative' }}>
                      <User size={15} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                      <input
                        type="text"
                        required
                        value={resumeData.personal_info?.full_name || ''}
                        onChange={e => updatePersonalInfo('full_name', e.target.value)}
                        placeholder="e.g. Rahul Sharma"
                        className="input-field"
                        style={{ paddingLeft: '2.2rem', width: '100%', fontSize: '0.825rem' }}
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.3rem' }}>
                      Professional Headline / Target Title *
                    </label>
                    <div style={{ position: 'relative' }}>
                      <Briefcase size={15} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                      <input
                        type="text"
                        value={resumeData.personal_info?.headline || resumeData.headline || ''}
                        onChange={e => {
                          updatePersonalInfo('headline', e.target.value);
                          setResumeData(prev => ({ ...prev, headline: e.target.value }));
                        }}
                        placeholder="e.g. Full-Stack Software Engineer | React, Node.js"
                        className="input-field"
                        style={{ paddingLeft: '2.2rem', width: '100%', fontSize: '0.825rem' }}
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.3rem' }}>
                      Email Address *
                    </label>
                    <div style={{ position: 'relative' }}>
                      <Mail size={15} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                      <input
                        type="email"
                        required
                        value={resumeData.personal_info?.email || ''}
                        onChange={e => updatePersonalInfo('email', e.target.value)}
                        placeholder="e.g. rahul.sharma@example.edu"
                        className="input-field"
                        style={{ paddingLeft: '2.2rem', width: '100%', fontSize: '0.825rem' }}
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.3rem' }}>
                      Phone Number
                    </label>
                    <div style={{ position: 'relative' }}>
                      <Phone size={15} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                      <input
                        type="tel"
                        value={resumeData.personal_info?.phone || ''}
                        onChange={e => updatePersonalInfo('phone', e.target.value)}
                        placeholder="e.g. +91 98765 43210"
                        className="input-field"
                        style={{ paddingLeft: '2.2rem', width: '100%', fontSize: '0.825rem' }}
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.3rem' }}>
                      Location (City, Country)
                    </label>
                    <div style={{ position: 'relative' }}>
                      <MapPin size={15} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                      <input
                        type="text"
                        value={resumeData.personal_info?.location || ''}
                        onChange={e => updatePersonalInfo('location', e.target.value)}
                        placeholder="e.g. Bengaluru, India"
                        className="input-field"
                        style={{ paddingLeft: '2.2rem', width: '100%', fontSize: '0.825rem' }}
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.3rem' }}>
                      LinkedIn Profile URL
                    </label>
                    <div style={{ position: 'relative' }}>
                      <Link2 size={15} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                      <input
                        type="text"
                        value={resumeData.personal_info?.linkedin || ''}
                        onChange={e => updatePersonalInfo('linkedin', e.target.value)}
                        onBlur={e => {
                          const formatted = sanitizeAndFormatUrl(e.target.value);
                          if (formatted) updatePersonalInfo('linkedin', formatted);
                        }}
                        placeholder="https://linkedin.com/in/username"
                        className="input-field"
                        style={{ paddingLeft: '2.2rem', width: '100%', fontSize: '0.825rem' }}
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.3rem' }}>
                      GitHub Profile URL
                    </label>
                    <div style={{ position: 'relative' }}>
                      <Code size={15} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                      <input
                        type="text"
                        value={resumeData.personal_info?.github || ''}
                        onChange={e => updatePersonalInfo('github', e.target.value)}
                        onBlur={e => {
                          const formatted = sanitizeAndFormatUrl(e.target.value);
                          if (formatted) updatePersonalInfo('github', formatted);
                        }}
                        placeholder="https://github.com/username"
                        className="input-field"
                        style={{ paddingLeft: '2.2rem', width: '100%', fontSize: '0.825rem' }}
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.3rem' }}>
                      Portfolio / Personal Website URL
                    </label>
                    <div style={{ position: 'relative' }}>
                      <Globe size={15} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                      <input
                        type="text"
                        value={resumeData.personal_info?.portfolio || ''}
                        onChange={e => updatePersonalInfo('portfolio', e.target.value)}
                        onBlur={e => {
                          const formatted = sanitizeAndFormatUrl(e.target.value);
                          if (formatted) updatePersonalInfo('portfolio', formatted);
                        }}
                        placeholder="https://yourportfolio.dev"
                        className="input-field"
                        style={{ paddingLeft: '2.2rem', width: '100%', fontSize: '0.825rem' }}
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.3rem' }}>
                      LeetCode Profile URL (Optional)
                    </label>
                    <div style={{ position: 'relative' }}>
                      <Terminal size={15} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                      <input
                        type="text"
                        value={resumeData.personal_info?.leetcode || ''}
                        onChange={e => updatePersonalInfo('leetcode', e.target.value)}
                        onBlur={e => {
                          const formatted = sanitizeAndFormatUrl(e.target.value);
                          if (formatted) updatePersonalInfo('leetcode', formatted);
                        }}
                        placeholder="https://leetcode.com/username"
                        className="input-field"
                        style={{ paddingLeft: '2.2rem', width: '100%', fontSize: '0.825rem' }}
                      />
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: '0.3rem' }}>
                      Codeforces Profile URL (Optional)
                    </label>
                    <div style={{ position: 'relative' }}>
                      <Trophy size={15} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                      <input
                        type="text"
                        value={resumeData.personal_info?.codeforces || ''}
                        onChange={e => updatePersonalInfo('codeforces', e.target.value)}
                        onBlur={e => {
                          const formatted = sanitizeAndFormatUrl(e.target.value);
                          if (formatted) updatePersonalInfo('codeforces', formatted);
                        }}
                        placeholder="https://codeforces.com/profile/username"
                        className="input-field"
                        style={{ paddingLeft: '2.2rem', width: '100%', fontSize: '0.825rem' }}
                      />
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '1rem' }}>
                  <button onClick={() => setActiveTab('summary')} className="btn btn-primary btn-sm">
                    Next: Professional Summary <ChevronRight size={14} />
                  </button>
                </div>
              </div>
            )}

            {/* 2. SUMMARY TAB */}
            {activeTab === 'summary' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <div>
                  <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 0.25rem 0' }}>
                    Professional Summary & Executive Pitch
                  </h3>
                  <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: 0 }}>
                    A 2-4 sentence executive summary detailing your core technical competencies, target domain, and measurable achievements.
                  </p>
                </div>

                {/* AI Templates Quick Ingestion */}
                <div>
                  <span style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--accent-cyan)', display: 'block', marginBottom: '0.4rem' }}>
                    ✨ AI One-Click Starters:
                  </span>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '0.5rem' }}>
                    {SUMMARY_TEMPLATES.map((tmpl, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          setResumeData(prev => ({
                            ...prev,
                            summary: tmpl.text,
                            personal_info: { ...(prev.personal_info || {}), summary: tmpl.text }
                          }));
                        }}
                        style={{
                          padding: '0.65rem 0.8rem',
                          borderRadius: '8px',
                          background: 'rgba(255, 255, 255, 0.03)',
                          border: '1px solid var(--border-subtle)',
                          color: 'var(--text-secondary)',
                          fontSize: '0.75rem',
                          textAlign: 'left',
                          cursor: 'pointer',
                          lineHeight: 1.4,
                          transition: 'all 0.15s'
                        }}
                        onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent-cyan)'}
                        onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border-subtle)'}
                      >
                        <strong style={{ display: 'block', color: 'var(--text-primary)', marginBottom: '0.2rem' }}>{tmpl.label}</strong>
                        <span style={{ color: 'var(--text-muted)' }}>{tmpl.text.slice(0, 110)}...</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.35rem' }}>
                    <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)' }}>
                      Summary Content
                    </label>
                    <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                      {(resumeData.summary || '').length} characters
                    </span>
                  </div>
                  <textarea
                    rows={6}
                    value={resumeData.summary || ''}
                    onChange={e => {
                      const val = e.target.value;
                      setResumeData(prev => ({
                        ...prev,
                        summary: val,
                        personal_info: { ...(prev.personal_info || {}), summary: val }
                      }));
                    }}
                    placeholder="Write a concise 2-4 sentence pitch describing your technical focus, core tools, and engineering accomplishments..."
                    className="input-field"
                    style={{ width: '100%', fontSize: '0.85rem', lineHeight: 1.5, resize: 'vertical' }}
                  />
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem' }}>
                  <button onClick={() => setActiveTab('info')} className="btn btn-secondary btn-sm">
                    Back: Personal Info
                  </button>
                  <button onClick={() => setActiveTab('skills')} className="btn btn-primary btn-sm">
                    Next: Technical Skills <ChevronRight size={14} />
                  </button>
                </div>
              </div>
            )}

            {/* 3. SKILLS TAB */}
            {activeTab === 'skills' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <div>
                  <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 0.25rem 0' }}>
                    Core Technical Skills & Stack
                  </h3>
                  <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: 0 }}>
                    Add key programming languages, frameworks, cloud databases, and development utilities. ATS parsers match these directly against job descriptions.
                  </p>
                </div>

                {/* Input New Skill Field */}
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <input
                    type="text"
                    value={newSkillInput}
                    onChange={e => setNewSkillInput(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddSkill(newSkillInput);
                      }
                    }}
                    placeholder="Type a skill and press Enter (e.g. Python, Docker, Redis)..."
                    className="input-field"
                    style={{ flex: 1, fontSize: '0.825rem' }}
                  />
                  <button
                    type="button"
                    onClick={() => handleAddSkill(newSkillInput)}
                    className="btn btn-primary btn-sm"
                  >
                    <Plus size={14} /> Add Skill
                  </button>
                </div>

                {/* Current Active Skills Chips */}
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
                    <span style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)' }}>
                      Active Skills ({resumeData.skills?.length || 0})
                    </span>
                    {resumeData.skills?.length > 0 && (
                      <button
                        onClick={() => setResumeData(prev => ({ ...prev, skills: [] }))}
                        style={{ background: 'none', border: 'none', color: '#fb7185', fontSize: '0.7rem', cursor: 'pointer' }}
                      >
                        Clear All
                      </button>
                    )}
                  </div>
                  <div style={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    gap: '0.45rem',
                    padding: '0.85rem',
                    borderRadius: '8px',
                    background: 'rgba(255, 255, 255, 0.02)',
                    border: '1px solid var(--border-subtle)',
                    minHeight: '80px',
                    alignContent: 'flex-start'
                  }}>
                    {(!resumeData.skills || resumeData.skills.length === 0) ? (
                      <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                        No skills added yet. Type above or click suggested tags below!
                      </span>
                    ) : (
                      resumeData.skills.map((s, idx) => (
                        <span
                          key={idx}
                          className="badge badge-cyan"
                          style={{
                            fontSize: '0.75rem',
                            padding: '0.3rem 0.6rem',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '0.35rem'
                          }}
                        >
                          {s}
                          <button
                            type="button"
                            onClick={() => handleRemoveSkill(s)}
                            style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer', padding: 0, display: 'flex' }}
                          >
                            <X size={12} />
                          </button>
                        </span>
                      ))
                    )}
                  </div>
                </div>

                {/* Categorized Quick Suggestions */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--accent-cyan)' }}>
                    ⚡ Suggested Industry Skills (Click to Add):
                  </span>
                  {SUGGESTED_SKILL_CATEGORIES.map((cat, cIdx) => (
                    <div key={cIdx}>
                      <span style={{ fontSize: '0.7rem', fontWeight: 600, color: 'var(--text-muted)', display: 'block', marginBottom: '0.25rem' }}>
                        {cat.category}
                      </span>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                        {cat.skills.map((sk, sIdx) => {
                          const isAdded = resumeData.skills.includes(sk);
                          return (
                            <button
                              key={sIdx}
                              type="button"
                              onClick={() => isAdded ? handleRemoveSkill(sk) : handleAddSkill(sk)}
                              style={{
                                padding: '0.25rem 0.55rem',
                                borderRadius: '6px',
                                fontSize: '0.72rem',
                                fontWeight: 500,
                                border: isAdded ? '1px solid #10b981' : '1px solid var(--border-subtle)',
                                background: isAdded ? 'rgba(16, 185, 129, 0.15)' : 'rgba(255, 255, 255, 0.03)',
                                color: isAdded ? '#34d399' : 'var(--text-secondary)',
                                cursor: 'pointer',
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '0.25rem',
                                transition: 'all 0.15s'
                              }}
                            >
                              {isAdded && <Check size={11} />}
                              <span>{sk}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem' }}>
                  <button onClick={() => setActiveTab('summary')} className="btn btn-secondary btn-sm">
                    Back: Summary
                  </button>
                  <button onClick={() => setActiveTab('projects')} className="btn btn-primary btn-sm">
                    Next: Technical Projects <ChevronRight size={14} />
                  </button>
                </div>
              </div>
            )}

            {/* 4. PROJECTS TAB */}
            {activeTab === 'projects' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <div>
                    <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 0.25rem 0' }}>
                      Technical Projects & STAR Evidence
                    </h3>
                    <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: 0 }}>
                      Add your engineering projects with verifiable links, tech stack, and quantified action bullets (STAR).
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddProject}
                    className="btn btn-emerald btn-sm"
                  >
                    <Plus size={14} /> Add New Project
                  </button>
                </div>

                {/* Project Cards List */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                  {resumeData.projects.map((proj, pIdx) => (
                    <div
                      key={proj.id || pIdx}
                      style={{
                        padding: '1.25rem',
                        borderRadius: '10px',
                        background: 'rgba(255, 255, 255, 0.02)',
                        border: '1px solid var(--border-subtle)',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '0.85rem'
                      }}
                    >
                      {/* Project Header Row */}
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <span style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--accent-cyan)' }}>
                          Project #{pIdx + 1}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleDeleteProject(pIdx)}
                          className="btn btn-outline-danger btn-sm"
                          style={{ padding: '0.2rem 0.45rem', fontSize: '0.7rem' }}
                        >
                          <Trash2 size={12} /> Remove
                        </button>
                      </div>

                      {/* Project Fields */}
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '0.65rem' }}>
                        <div>
                          <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                            Project Title *
                          </label>
                          <input
                            type="text"
                            value={proj.title}
                            onChange={e => handleUpdateProject(pIdx, 'title', e.target.value)}
                            placeholder="e.g. CloudScale Distributed Task Engine"
                            className="input-field"
                            style={{ width: '100%', fontSize: '0.8rem' }}
                          />
                        </div>

                        <div>
                          <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                            Role / Technologies Used
                          </label>
                          <input
                            type="text"
                            value={proj.role_or_tech || ''}
                            onChange={e => handleUpdateProject(pIdx, 'role_or_tech', e.target.value)}
                            placeholder="e.g. Lead Architect | Next.js, Node.js, Redis, Docker"
                            className="input-field"
                            style={{ width: '100%', fontSize: '0.8rem' }}
                          />
                        </div>

                        <div>
                          <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                            Live Demo URL (Optional)
                          </label>
                          <input
                            type="text"
                            value={proj.url || ''}
                            onChange={e => handleUpdateProject(pIdx, 'url', e.target.value)}
                            onBlur={e => {
                              const formatted = sanitizeAndFormatUrl(e.target.value);
                              if (formatted) handleUpdateProject(pIdx, 'url', formatted);
                            }}
                            placeholder="https://project-demo.app"
                            className="input-field"
                            style={{ width: '100%', fontSize: '0.8rem' }}
                          />
                        </div>

                        <div>
                          <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                            GitHub / Source Code URL (Optional)
                          </label>
                          <input
                            type="text"
                            value={proj.code_url || ''}
                            onChange={e => handleUpdateProject(pIdx, 'code_url', e.target.value)}
                            onBlur={e => {
                              const formatted = sanitizeAndFormatUrl(e.target.value);
                              if (formatted) handleUpdateProject(pIdx, 'code_url', formatted);
                            }}
                            placeholder="https://github.com/user/repo"
                            className="input-field"
                            style={{ width: '100%', fontSize: '0.8rem' }}
                          />
                        </div>
                      </div>

                      {/* Project Overview */}
                      <div>
                        <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                          Short Overview Description
                        </label>
                        <input
                          type="text"
                          value={proj.description || ''}
                          onChange={e => handleUpdateProject(pIdx, 'description', e.target.value)}
                          placeholder="Engineered high-throughput background processing system capable of queuing and executing asynchronous workflows."
                          className="input-field"
                          style={{ width: '100%', fontSize: '0.8rem' }}
                        />
                      </div>

                      {/* Project Bullets (STAR Quantified) */}
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
                          <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)' }}>
                            STAR Action Bullets (Action Verb + What you built + Measurable Metric %)
                          </label>
                          <button
                            type="button"
                            onClick={() => handleAddProjectBullet(pIdx)}
                            className="btn btn-secondary btn-sm"
                            style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem' }}
                          >
                            <Plus size={12} /> Add Bullet
                          </button>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                          {(proj.bullets || []).map((b, bIdx) => (
                            <div key={bIdx} style={{ display: 'flex', gap: '0.4rem', alignItems: 'center' }}>
                              <span style={{ color: 'var(--accent-cyan)', fontSize: '0.8rem' }}>•</span>
                              <input
                                type="text"
                                value={b}
                                onChange={e => handleUpdateProjectBullet(pIdx, bIdx, e.target.value)}
                                placeholder="Architected asynchronous pipeline with Redis, handling 15,000+ jobs/min with 99.9% uptime."
                                className="input-field"
                                style={{ flex: 1, fontSize: '0.8rem' }}
                              />
                              <button
                                type="button"
                                onClick={() => handleDeleteProjectBullet(pIdx, bIdx)}
                                style={{ background: 'none', border: 'none', color: '#fb7185', cursor: 'pointer', padding: '0.2rem' }}
                                title="Remove bullet"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem' }}>
                  <button onClick={() => setActiveTab('skills')} className="btn btn-secondary btn-sm">
                    Back: Skills
                  </button>
                  <button onClick={() => setActiveTab('experience')} className="btn btn-primary btn-sm">
                    Next: Internships & Work <ChevronRight size={14} />
                  </button>
                </div>
              </div>
            )}

            {/* 5. EXPERIENCE TAB */}
            {activeTab === 'experience' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <div>
                    <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 0.25rem 0' }}>
                      Professional Experience & Internships
                    </h3>
                    <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: 0 }}>
                      Add your internships, open-source contributions, or student technical roles.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddExperience}
                    className="btn btn-emerald btn-sm"
                  >
                    <Plus size={14} /> Add Experience / Internship
                  </button>
                </div>

                {/* Experience Cards List */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                  {resumeData.experience.map((exp, eIdx) => (
                    <div
                      key={exp.id || eIdx}
                      style={{
                        padding: '1.25rem',
                        borderRadius: '10px',
                        background: 'rgba(255, 255, 255, 0.02)',
                        border: '1px solid var(--border-subtle)',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '0.85rem'
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <span style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--accent-cyan)' }}>
                          Experience #{eIdx + 1}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleDeleteExperience(eIdx)}
                          className="btn btn-outline-danger btn-sm"
                          style={{ padding: '0.2rem 0.45rem', fontSize: '0.7rem' }}
                        >
                          <Trash2 size={12} /> Remove
                        </button>
                      </div>

                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '0.65rem' }}>
                        <div>
                          <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                            Organization / Company Name *
                          </label>
                          <input
                            type="text"
                            value={exp.company}
                            onChange={e => handleUpdateExperience(eIdx, 'company', e.target.value)}
                            placeholder="e.g. Nexus Infotech Solutions"
                            className="input-field"
                            style={{ width: '100%', fontSize: '0.8rem' }}
                          />
                        </div>

                        <div>
                          <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                            Role / Job Title *
                          </label>
                          <input
                            type="text"
                            value={exp.role}
                            onChange={e => handleUpdateExperience(eIdx, 'role', e.target.value)}
                            placeholder="e.g. Software Development Engineering Intern"
                            className="input-field"
                            style={{ width: '100%', fontSize: '0.8rem' }}
                          />
                        </div>

                        <div>
                          <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                            Duration / Dates
                          </label>
                          <input
                            type="text"
                            value={exp.duration || ''}
                            onChange={e => handleUpdateExperience(eIdx, 'duration', e.target.value)}
                            placeholder="e.g. Jan 2025 – Jul 2025"
                            className="input-field"
                            style={{ width: '100%', fontSize: '0.8rem' }}
                          />
                        </div>

                        <div>
                          <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                            Location (City, Country)
                          </label>
                          <input
                            type="text"
                            value={exp.location || ''}
                            onChange={e => handleUpdateExperience(eIdx, 'location', e.target.value)}
                            placeholder="e.g. Bengaluru, India"
                            className="input-field"
                            style={{ width: '100%', fontSize: '0.8rem' }}
                          />
                        </div>
                      </div>

                      {/* Bullets */}
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
                          <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)' }}>
                            Achievement & Impact Bullets
                          </label>
                          <button
                            type="button"
                            onClick={() => handleAddExperienceBullet(eIdx)}
                            className="btn btn-secondary btn-sm"
                            style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem' }}
                          >
                            <Plus size={12} /> Add Bullet
                          </button>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                          {(exp.bullets || []).map((b, bIdx) => (
                            <div key={bIdx} style={{ display: 'flex', gap: '0.4rem', alignItems: 'center' }}>
                              <span style={{ color: 'var(--accent-cyan)', fontSize: '0.8rem' }}>•</span>
                              <input
                                type="text"
                                value={b}
                                onChange={e => handleUpdateExperienceBullet(eIdx, bIdx, e.target.value)}
                                placeholder="Engineered 8+ reusable core dashboard widgets in React/TypeScript, improving front-end page load velocity by 35%."
                                className="input-field"
                                style={{ flex: 1, fontSize: '0.8rem' }}
                              />
                              <button
                                type="button"
                                onClick={() => handleDeleteExperienceBullet(eIdx, bIdx)}
                                style={{ background: 'none', border: 'none', color: '#fb7185', cursor: 'pointer', padding: '0.2rem' }}
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem' }}>
                  <button onClick={() => setActiveTab('projects')} className="btn btn-secondary btn-sm">
                    Back: Projects
                  </button>
                  <button onClick={() => setActiveTab('education')} className="btn btn-primary btn-sm">
                    Next: Education & Certifications <ChevronRight size={14} />
                  </button>
                </div>
              </div>
            )}

            {/* 6. EDUCATION & CERTS TAB */}
            {activeTab === 'education' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <div>
                  <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 0.25rem 0' }}>
                    Education & Certifications
                  </h3>
                  <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: 0 }}>
                    Add your university/college degree, academic branch, graduation year, and professional certifications.
                  </p>
                </div>

                {/* Education Section */}
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.6rem' }}>
                    <span style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--accent-cyan)' }}>
                      Academic Degree & University
                    </span>
                    <button
                      type="button"
                      onClick={handleAddEducation}
                      className="btn btn-secondary btn-sm"
                      style={{ fontSize: '0.72rem' }}
                    >
                      <Plus size={12} /> Add University
                    </button>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                    {resumeData.education.map((edu, edIdx) => (
                      <div
                        key={edIdx}
                        style={{
                          padding: '1rem',
                          borderRadius: '8px',
                          background: 'rgba(255, 255, 255, 0.02)',
                          border: '1px solid var(--border-subtle)',
                          display: 'grid',
                          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                          gap: '0.65rem'
                        }}
                      >
                        <div>
                          <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                            University / College *
                          </label>
                          <input
                            type="text"
                            value={edu.institution}
                            onChange={e => handleUpdateEducation(edIdx, 'institution', e.target.value)}
                            placeholder="e.g. National Institute of Technology"
                            className="input-field"
                            style={{ width: '100%', fontSize: '0.8rem' }}
                          />
                        </div>

                        <div>
                          <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                            Degree *
                          </label>
                          <input
                            type="text"
                            value={edu.degree}
                            onChange={e => handleUpdateEducation(edIdx, 'degree', e.target.value)}
                            placeholder="e.g. Bachelor of Technology (B.Tech)"
                            className="input-field"
                            style={{ width: '100%', fontSize: '0.8rem' }}
                          />
                        </div>

                        <div>
                          <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                            Major / Branch
                          </label>
                          <input
                            type="text"
                            value={edu.field_of_study || ''}
                            onChange={e => handleUpdateEducation(edIdx, 'field_of_study', e.target.value)}
                            placeholder="e.g. Computer Science & Engineering"
                            className="input-field"
                            style={{ width: '100%', fontSize: '0.8rem' }}
                          />
                        </div>

                        <div>
                          <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.2rem' }}>
                            Graduation Year & CGPA
                          </label>
                          <div style={{ display: 'flex', gap: '0.4rem' }}>
                            <input
                              type="text"
                              value={edu.end_year || ''}
                              onChange={e => handleUpdateEducation(edIdx, 'end_year', e.target.value)}
                              placeholder="e.g. 2026"
                              className="input-field"
                              style={{ width: '80px', fontSize: '0.8rem' }}
                            />
                            <input
                              type="text"
                              value={edu.grade_or_cgpa || ''}
                              onChange={e => handleUpdateEducation(edIdx, 'grade_or_cgpa', e.target.value)}
                              placeholder="e.g. 8.8 / 10.0"
                              className="input-field"
                              style={{ flex: 1, fontSize: '0.8rem' }}
                            />
                            {resumeData.education.length > 1 && (
                              <button
                                type="button"
                                onClick={() => handleDeleteEducation(edIdx)}
                                style={{ background: 'none', border: 'none', color: '#fb7185', cursor: 'pointer' }}
                              >
                                <Trash2 size={14} />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Certifications Section */}
                <div style={{ marginTop: '0.5rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.6rem' }}>
                    <span style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--accent-cyan)' }}>
                      Professional Certifications
                    </span>
                    <button
                      type="button"
                      onClick={handleAddCertification}
                      className="btn btn-secondary btn-sm"
                      style={{ fontSize: '0.72rem' }}
                    >
                      <Plus size={12} /> Add Certification
                    </button>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    {(!resumeData.certifications || resumeData.certifications.length === 0) ? (
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        No certifications added. Click "Add Certification" to highlight verified credentials.
                      </span>
                    ) : (
                      resumeData.certifications.map((cert, cIdx) => (
                        <div
                          key={cIdx}
                          style={{
                            display: 'flex',
                            gap: '0.5rem',
                            alignItems: 'center',
                            padding: '0.65rem 0.8rem',
                            borderRadius: '6px',
                            background: 'rgba(255, 255, 255, 0.02)',
                            border: '1px solid var(--border-subtle)'
                          }}
                        >
                          <input
                            type="text"
                            value={cert.name}
                            onChange={e => handleUpdateCertification(cIdx, 'name', e.target.value)}
                            placeholder="e.g. AWS Certified Solutions Architect"
                            className="input-field"
                            style={{ flex: 2, fontSize: '0.8rem' }}
                          />
                          <input
                            type="text"
                            value={cert.issuer || ''}
                            onChange={e => handleUpdateCertification(cIdx, 'issuer', e.target.value)}
                            placeholder="e.g. Amazon Web Services"
                            className="input-field"
                            style={{ flex: 1.5, fontSize: '0.8rem' }}
                          />
                          <input
                            type="text"
                            value={cert.year || ''}
                            onChange={e => handleUpdateCertification(cIdx, 'year', e.target.value)}
                            placeholder="e.g. 2025"
                            className="input-field"
                            style={{ width: '75px', fontSize: '0.8rem' }}
                          />
                          <button
                            type="button"
                            onClick={() => handleDeleteCertification(cIdx)}
                            style={{ background: 'none', border: 'none', color: '#fb7185', cursor: 'pointer' }}
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem' }}>
                  <button onClick={() => setActiveTab('experience')} className="btn btn-secondary btn-sm">
                    Back: Experience
                  </button>
                  <button onClick={handleSaveAndLaunch} disabled={isSaving} className="btn btn-primary btn-sm">
                    {isSaving ? 'Building Resume...' : '🚀 Finalize & Launch in AI Studio'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Footer Actions Bar */}
        <div style={{
          padding: '0.9rem 1.75rem',
          borderTop: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: 'rgba(3, 7, 18, 0.6)',
          flexWrap: 'wrap',
          gap: '0.75rem'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              Candidate: <strong style={{ color: 'var(--text-primary)' }}>{resumeData.personal_info?.full_name || 'Anonymous Candidate'}</strong>
            </span>
            <span style={{ color: 'var(--border-subtle)' }}>•</span>
            <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              {resumeData.skills?.length || 0} Skills • {resumeData.projects?.length || 0} Projects • {resumeData.experience?.length || 0} Experiences
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <button
              type="button"
              onClick={onClose}
              className="btn btn-secondary btn-sm"
              disabled={isSaving}
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveAndLaunch}
              disabled={isSaving}
              className="btn btn-primary btn-sm"
              style={{
                background: 'linear-gradient(135deg, #00f2fe, #38bdf8)',
                color: '#030712',
                fontWeight: 800,
                boxShadow: '0 0 16px rgba(56, 189, 248, 0.4)'
              }}
            >
              {isSaving ? (
                <>
                  <RefreshCw size={13} className="animate-spin-slow" /> Building & Optimizing...
                </>
              ) : (
                <>
                  <Sparkles size={14} /> SAVE & OPEN IN AI RESUME STUDIO
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalNode, document.body) : modalNode;
};
