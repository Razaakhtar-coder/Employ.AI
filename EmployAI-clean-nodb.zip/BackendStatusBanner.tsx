import React, { useState, useEffect, useCallback, useRef } from 'react';
import { checkBackendHealth, getApiBaseUrl, isLocalHost, type HealthCheckResult } from '../services/api';
import { BackendConfigModal } from './BackendConfigModal';
import { WifiOff, RefreshCw, Terminal, Check, Settings, Cloud } from 'lucide-react';

interface BackendStatusBannerProps {
  onStatusChange?: (isOnline: boolean) => void;
}

export const BackendStatusBanner: React.FC<BackendStatusBannerProps> = ({ onStatusChange }) => {
  const [isOnline, setIsOnline] = useState<boolean | null>(null);
  const [healthData, setHealthData] = useState<HealthCheckResult | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [copied, setCopied] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState(false);

  const consecutiveFailures = useRef(0);
  const isLocal = isLocalHost();

  const verifyHealth = useCallback(async () => {
    setIsChecking(true);
    const res = await checkBackendHealth();
    setHealthData(res);
    if (res.online) {
      consecutiveFailures.current = 0;
      setIsOnline(true);
      if (onStatusChange) onStatusChange(true);
    } else {
      consecutiveFailures.current += 1;
      // Require at least 2 consecutive failed health checks before showing offline banner
      if (consecutiveFailures.current >= 2) {
        setIsOnline(false);
        if (onStatusChange) onStatusChange(false);
      }
    }
    setIsChecking(false);
  }, [onStatusChange]);

  useEffect(() => {
    verifyHealth();

    // Check periodically: every 10s if offline or waking up, every 45s if online
    const intervalTime = isOnline === false || healthData?.isWakingUp ? 10000 : 45000;
    const timer = setInterval(() => {
      verifyHealth();
    }, intervalTime);

    return () => clearInterval(timer);
  }, [verifyHealth, isOnline, healthData?.isWakingUp]);

  // Re-verify immediately if custom API URL changed in modal
  useEffect(() => {
    const handleUrlChange = () => {
      verifyHealth();
    };
    window.addEventListener('employai:api-url-changed', handleUrlChange);
    return () => window.removeEventListener('employai:api-url-changed', handleUrlChange);
  }, [verifyHealth]);

  const copyCommand = () => {
    navigator.clipboard.writeText('python run.py');
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // If online, still loading, dismissed, or in production cloud deployment, do not show alert banner
  if (isOnline === true || isOnline === null || dismissed || !isLocal) {
    return (
      <BackendConfigModal
        isOpen={showConfigModal}
        onClose={() => setShowConfigModal(false)}
        onConnectionSuccess={() => {
          verifyHealth();
          setDismissed(false);
        }}
      />
    );
  }

  const activeUrl = getApiBaseUrl();
  const isWakingUp = healthData?.isWakingUp;

  return (
    <>
      <div className="no-print backend-status-banner banner-offline">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flex: '1 1 280px', minWidth: 0 }}>
          <div
            style={{
              width: '32px',
              height: '32px',
              borderRadius: '50%',
              background: isWakingUp ? 'rgba(245, 158, 11, 0.2)' : 'rgba(239, 68, 68, 0.2)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: isWakingUp ? '#f59e0b' : '#ef4444',
              flexShrink: 0
            }}
          >
            {isWakingUp ? (
              <RefreshCw size={16} className="animate-spin" />
            ) : isLocal ? (
              <WifiOff size={16} />
            ) : (
              <Cloud size={16} />
            )}
          </div>

          <div style={{ minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap' }}>
              <span className="banner-title" style={{ fontSize: '0.85rem', fontWeight: 800 }}>
                {isWakingUp 
                  ? 'Cloud Backend Waking Up (~30s)' 
                  : isLocal 
                  ? 'Local Backend Server Offline' 
                  : 'EmployAI Production API Offline'}
              </span>
              <span className="banner-badge" style={{ fontSize: '0.675rem', padding: '0.1rem 0.45rem', borderRadius: '4px', fontWeight: 600 }}>
                {activeUrl}
              </span>
            </div>

            <p className="banner-subtitle" style={{ margin: '0.15rem 0 0 0', fontSize: '0.76rem', lineHeight: 1.4 }}>
              {isWakingUp 
                ? 'Render free-tier server is spinning up from cold sleep. Instant cached snapshots remain active.'
                : isLocal 
                ? 'Local server not detected. Run "python run.py" in terminal or connect to Cloud Backend.'
                : 'Live server is warming up or unreachable. Verified offline data and ATS engine remain active.'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap' }}>
          {isLocal && (
            <button
              onClick={copyCommand}
              style={{
                background: 'rgba(15, 23, 42, 0.6)',
                border: '1px solid rgba(239, 68, 68, 0.3)',
                borderRadius: '6px',
                padding: '0.35rem 0.65rem',
                color: '#f1f5f9',
                fontSize: '0.75rem',
                fontFamily: 'monospace',
                display: 'flex',
                alignItems: 'center',
                gap: '0.4rem',
                cursor: 'pointer',
                transition: 'all 0.2s'
              }}
              title="Copy terminal command to launch local backend"
            >
              <Terminal size={12} color="#94a3b8" />
              <span>python run.py</span>
              {copied ? <Check size={12} color="#34d399" /> : null}
            </button>
          )}

          {/* Configure Endpoint Button */}
          <button
            onClick={() => setShowConfigModal(true)}
            style={{
              background: 'rgba(6, 182, 212, 0.15)',
              border: '1px solid var(--accent-cyan, #0284c7)',
              borderRadius: '6px',
              padding: '0.35rem 0.75rem',
              color: 'var(--accent-cyan, #0284c7)',
              fontSize: '0.75rem',
              fontWeight: 700,
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
              cursor: 'pointer',
              transition: 'all 0.2s'
            }}
            title="Configure backend server URL or switch to Cloud Backend"
          >
            <Settings size={13} />
            <span>Server Settings</span>
          </button>

          {/* Retry Ping Button */}
          <button
            onClick={verifyHealth}
            disabled={isChecking}
            style={{
              background: isWakingUp ? '#f59e0b' : '#ef4444',
              border: 'none',
              borderRadius: '6px',
              padding: '0.35rem 0.75rem',
              color: '#ffffff',
              fontSize: '0.75rem',
              fontWeight: 700,
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
              cursor: isChecking ? 'wait' : 'pointer',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.2)',
              transition: 'all 0.2s'
            }}
          >
            <RefreshCw size={12} className={isChecking ? 'animate-spin' : ''} />
            <span>{isChecking ? 'Checking...' : 'Retry'}</span>
          </button>

          <button
            onClick={() => setDismissed(true)}
            style={{
              background: 'transparent',
              border: 'none',
              color: 'var(--text-muted, #94a3b8)',
              fontSize: '0.75rem',
              padding: '0.35rem 0.5rem',
              cursor: 'pointer',
              fontWeight: 600
            }}
            title="Dismiss notification"
          >
            Dismiss
          </button>
        </div>
      </div>

      <BackendConfigModal
        isOpen={showConfigModal}
        onClose={() => setShowConfigModal(false)}
        onConnectionSuccess={() => {
          verifyHealth();
          setDismissed(false);
        }}
      />
    </>
  );
};

export const BackendStatusPill: React.FC = () => {
  const [isOnline, setIsOnline] = useState<boolean | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const failuresRef = useRef(0);

  const check = useCallback(async () => {
    setIsChecking(true);
    const res = await checkBackendHealth();
    if (res.online) {
      failuresRef.current = 0;
      setIsOnline(true);
    } else {
      failuresRef.current += 1;
      if (failuresRef.current >= 2) {
        setIsOnline(false);
      }
    }
    setIsChecking(false);
  }, []);

  useEffect(() => {
    check();
    const timer = setInterval(check, 30000);
    return () => clearInterval(timer);
  }, [check]);

  // Re-check when API URL changes
  useEffect(() => {
    const handleUrlChange = () => check();
    window.addEventListener('employai:api-url-changed', handleUrlChange);
    return () => window.removeEventListener('employai:api-url-changed', handleUrlChange);
  }, [check]);

  const activeUrl = getApiBaseUrl();

  return (
    <>
      <button
        onClick={() => setShowConfigModal(true)}
        title={isOnline === true ? `Backend Server: Online (${activeUrl})` : `EmployAI Engine: Active (Client Intelligence Mode) - Click to configure`}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.4rem',
          padding: '0.35rem 0.65rem',
          borderRadius: '20px',
          border: '1px solid',
          borderColor: isOnline === true ? 'rgba(16, 185, 129, 0.35)' : 'rgba(56, 189, 248, 0.35)',
          background: isOnline === true ? 'rgba(16, 185, 129, 0.12)' : 'rgba(56, 189, 248, 0.10)',
          color: isOnline === true ? 'var(--accent-emerald, #059669)' : 'var(--accent-cyan, #0284c7)',
          fontSize: '0.725rem',
          fontWeight: 700,
          cursor: 'pointer',
          transition: 'all 0.2s'
        }}
      >
        <span
          style={{
            width: '7px',
            height: '7px',
            borderRadius: '50%',
            backgroundColor: isOnline === true ? '#10b981' : '#38bdf8',
            boxShadow: isOnline === true ? '0 0 8px #10b981' : '0 0 8px rgba(56, 189, 248, 0.5)',
            display: 'inline-block',
            animation: isChecking ? 'pulse 1s infinite' : 'none'
          }}
        />
        <span>{isOnline === true ? 'API Online' : 'Client Engine Active'}</span>
        <Settings size={10} style={{ opacity: 0.7 }} />
      </button>

      <BackendConfigModal
        isOpen={showConfigModal}
        onClose={() => setShowConfigModal(false)}
        onConnectionSuccess={() => check()}
      />
    </>
  );
};
