import type { StructuredResume, ResumeScoreBreakdown } from '../types';

export const ACTION_VERBS = [
  'architected', 'engineered', 'spearheaded', 'orchestrated', 'optimized',
  'streamlined', 'deployed', 'implemented', 'designed', 'developed',
  'automated', 'reduced', 'increased', 'accelerated', 'formulated',
  'executed', 'pioneered', 'established', 'delivered', 'managed',
  'directed', 'constructed', 'programmed', 'scaled', 'transformed',
  'integrated', 'solved', 'mentored', 'authored', 'built',
  'championed', 'mobilized', 'synthesized', 'devised', 'conceptualized',
  'modernized', 'prototyped', 'overhauled', 'revitalized', 'standardized',
  'consolidated', 'expedited', 'amplified', 'diagnosed', 'benchmarked',
  'modeled', 'evaluated', 'quantified', 'decoded', 'audited',
  'uncovered', 'resolved', 'galvanized', 'cultivated', 'maximized',
  'enhanced', 'surpassed', 'catalyzed', 'elevated', 'captured',
  'boosted', 'operationalized', 'steered', 'propelled', 'commissioned',
  'dispatched', 'refactored', 'navigated', 'forged', 'enacted'
];

export const COMMON_TECH_TERMS = [
  'python', 'java', 'c++', 'c#', 'golang', 'rust', 'ruby', 'php', 'scala',
  'javascript', 'typescript', 'react', 'react native', 'angular', 'vue', 'next.js',
  'node.js', 'express', 'fastapi', 'flask', 'django', 'spring boot', 'graphql', 'rest api',
  'sql', 'mysql', 'postgresql', 'mongodb', 'redis', 'elasticsearch', 'cassandra',
  'docker', 'kubernetes', 'aws', 'azure', 'gcp', 'terraform', 'ci/cd', 'git', 'github actions',
  'linux', 'bash', 'powershell', 'kafka', 'rabbitmq', 'microservices', 'distributed systems',
  'machine learning', 'deep learning', 'pytorch', 'tensorflow', 'scikit-learn', 'pandas', 'numpy',
  'nlp', 'llm', 'rag', 'langchain', 'computer vision', 'opencv', 'generative ai',
  'data structures', 'algorithms', 'system design', 'agile', 'scrum', 'jira',
  'excel', 'power bi', 'tableau', 'financial modeling', 'gaap', 'ifrs', 'variance analysis',
  'budgeting', 'forecasting', 'tally', 'sap', 'salesforce', 'crm',
  'autocad', 'solidworks', 'matlab', 'ansys', 'catia', 'gd&t', 'plc', 'scada',
  'seo', 'sem', 'google analytics', 'copywriting', 'content strategy', 'product management'
];

// Pre-compile regexes for high performance across repeated evaluations
const TECH_TERM_REGEX_MAP = new Map<string, RegExp>(
  COMMON_TECH_TERMS.map(term => {
    const escaped = term.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    return [term, new RegExp(`(?<![a-z0-9])${escaped}(?![a-z0-9])`, 'i')];
  })
);

const METRIC_REGEX = /(\b\d+(?:\.\d+)?%|\$\d+(?:\.\d+)?|\b\d+\s*(?:ms|seconds|minutes|hours|days|x|users|clients|records|req\/s|rps|gb|mb|tb|k|m|million|billion|lakh|crore)\b|\b\d{2,}\b)/i;
const JD_LIST_REGEX = /(?:Requirements|Skills|Technologies|Experience with|Knowledge of|Qualifications|Responsibilities)[:\s]+([^.\n]+)/gi;
const JD_TITLE_REGEX = /(?:job\s*title|position|role|designation)\s*[:\-]\s*(.+)/i;

export interface ATSTierInfo {
  tier: 'Tier 1' | 'Tier 2' | 'Tier 3';
  label: string;
  description: string;
  color: string;
  bg: string;
  borderColor: string;
}

/**
 * Returns standardized ATS readiness tier metadata for consistent display across all dashboards.
 */
export function getATSTier(score: number): ATSTierInfo {
  if (score >= 85) {
    return {
      tier: 'Tier 1',
      label: 'Interview Ready (85%+)',
      description: 'Excellent ATS optimization. High pass rate through recruiter automated screening filters.',
      color: '#10b981',
      bg: 'rgba(16, 185, 129, 0.12)',
      borderColor: 'rgba(16, 185, 129, 0.3)'
    };
  } else if (score >= 70) {
    return {
      tier: 'Tier 2',
      label: 'Competitive (70-84%)',
      description: 'Good foundation. Add more quantified STAR metrics and target keywords to reach Tier 1.',
      color: '#38bdf8',
      bg: 'rgba(56, 189, 248, 0.12)',
      borderColor: 'rgba(56, 189, 248, 0.3)'
    };
  } else {
    return {
      tier: 'Tier 3',
      label: 'Needs Optimization (<70%)',
      description: 'Requires structural and keyword enhancements to pass enterprise ATS parsing engines.',
      color: '#f59e0b',
      bg: 'rgba(245, 158, 11, 0.12)',
      borderColor: 'rgba(245, 158, 11, 0.3)'
    };
  }
}

// Caching layer to avoid recalculating on every re-render
const JD_KEYWORD_CACHE = new Map<string, {
  targetJobTitle: string;
  keywords: string[];
  responsibilities: string[];
  actionVerbs: string[];
}>();

const ATS_SCORE_CACHE = new Map<string, ATSAnalysisResult>();
const MAX_CACHE_SIZE = 80;

function trimCache<K, V>(cache: Map<K, V>, max: number) {
  if (cache.size > max) {
    const firstKey = cache.keys().next().value;
    if (firstKey !== undefined) cache.delete(firstKey);
  }
}

export interface ATSAnalysisResult {
  overall_score: number;
  score_breakdown: ResumeScoreBreakdown & {
    keyword_match?: number;
    experience_relevance?: number;
  };
  metrics: {
    skill_count: number;
    action_verb_count: number;
    quantified_bullet_count: number;
    total_bullet_count: number;
    has_contact_complete: boolean;
    has_links: boolean;
    has_summary: boolean;
    experience_count: number;
    project_count: number;
    education_count: number;
    // Job Description Tailoring Metrics
    is_job_tailored?: boolean;
    target_job_title?: string;
    jd_keyword_match_percentage?: number;
    jd_experience_relevance_percentage?: number;
    matched_jd_keywords?: string[];
    missing_jd_keywords?: string[];
    total_jd_keywords_count?: number;
  };
}

/**
 * Extracts target job title, core skills, tools, and requirements from a job description with LRU memoization.
 */
export function extractJDKeywords(jobDescription: string, jobTitleHint?: string | null): {
  targetJobTitle: string;
  keywords: string[];
  responsibilities: string[];
  actionVerbs: string[];
} {
  if (!jobDescription || !jobDescription.trim()) {
    return { targetJobTitle: jobTitleHint || 'Target Role', keywords: [], responsibilities: [], actionVerbs: [] };
  }

  const cacheKey = `${jobTitleHint || ''}:::${jobDescription.trim()}`;
  if (JD_KEYWORD_CACHE.has(cacheKey)) {
    return JD_KEYWORD_CACHE.get(cacheKey)!;
  }

  const jdLower = jobDescription.toLowerCase();
  const jdLines = jobDescription.split(/[\r\n]+/).map(l => l.trim()).filter(Boolean);

  // 1. Infer Target Job Title
  let targetJobTitle = jobTitleHint || '';
  if (!targetJobTitle) {
    for (const line of jdLines.slice(0, 8)) {
      const match = line.match(JD_TITLE_REGEX);
      if (match && match[1]) {
        targetJobTitle = match[1].trim();
        break;
      }
    }
  }
  if (!targetJobTitle) {
    const commonRoles = [
      'Full-Stack AI Engineer', 'AI/ML Engineer', 'Full Stack Developer', 'Software Engineer',
      'Frontend Developer', 'Backend Developer', 'Data Scientist', 'Data Analyst', 'DevOps Engineer',
      'Financial Analyst', 'Business Analyst', 'Product Manager', 'Mechanical Engineer', 'Civil Engineer',
      'Marketing Specialist', 'Cybersecurity Engineer', 'Cloud Architect', 'System Administrator'
    ];
    for (const r of commonRoles) {
      if (jdLower.includes(r.toLowerCase())) {
        targetJobTitle = r;
        break;
      }
    }
  }
  if (!targetJobTitle) targetJobTitle = 'Target Role';

  // 2. Extract technical terms & keywords using pre-compiled regexes
  const keywordsSet = new Set<string>();
  for (const [term, regex] of TECH_TERM_REGEX_MAP.entries()) {
    if (regex.test(jdLower)) {
      keywordsSet.add(term);
    }
  }

  // 3. Extract phrases from Requirements / Skills bullet points
  const listMatches = jobDescription.match(JD_LIST_REGEX);
  if (listMatches) {
    for (const m of listMatches) {
      const afterColon = m.replace(/^(?:Requirements|Skills|Technologies|Experience with|Knowledge of|Qualifications|Responsibilities)[:\s]+/i, '');
      const parts = afterColon.split(/[,|;/•]+/);
      for (const p of parts) {
        const clean = p.trim().toLowerCase();
        if (clean.length >= 2 && clean.length <= 35 && !clean.includes('http')) {
          keywordsSet.add(clean);
        }
      }
    }
  }

  // 4. Extract Action Verbs present in the JD
  const actionVerbsFound: string[] = [];
  for (const v of ACTION_VERBS) {
    if (jdLower.includes(v)) {
      actionVerbsFound.push(v);
    }
  }

  // 5. Extract core responsibility phrases from lines starting with bullets
  const responsibilities: string[] = [];
  for (const line of jdLines) {
    const clean = line.replace(/^[\s•\-\*\d\.\)\:]+/, '').trim();
    if (clean.length > 20 && clean.length < 180 && !clean.toLowerCase().startsWith('http')) {
      responsibilities.push(clean);
    }
  }

  const result = {
    targetJobTitle,
    keywords: Array.from(keywordsSet),
    responsibilities: responsibilities.slice(0, 8),
    actionVerbs: actionVerbsFound
  };

  trimCache(JD_KEYWORD_CACHE, MAX_CACHE_SIZE);
  JD_KEYWORD_CACHE.set(cacheKey, result);
  return result;
}

/**
 * Helper to reliably normalize any raw analysis or partial structured resume object into a standard StructuredResume format.
 */
export function normalizeResumeForATS(raw: any): StructuredResume {
  if (!raw) {
    return {
      personal_info: {},
      summary: '',
      skills: [],
      experience: [],
      projects: [],
      education: [],
      certifications: []
    };
  }

  // If already structured
  if (raw.structured_resume && typeof raw.structured_resume === 'object') {
    return {
      ...raw.structured_resume,
      certifications: raw.structured_resume.certifications || []
    };
  }
  if (raw.personal_info || raw.skills || raw.experience || raw.projects) {
    return {
      ...raw,
      certifications: raw.certifications || []
    } as StructuredResume;
  }

  // Normalize from ResumeAnalysisResult
  return {
    personal_info: {
      full_name: raw.filename ? raw.filename.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ') : undefined,
      title: raw.detected_domain || undefined,
      summary: (raw.strengths || []).slice(0, 2).join(' ') || undefined,
      links: raw.detected_links || []
    },
    headline: raw.detected_domain || undefined,
    summary: (raw.strengths || []).slice(0, 2).join(' ') || '',
    skills: raw.extracted_skills || [],
    experience: (raw.extracted_experience || []).map((e: any, idx: number) => ({
      id: `exp-${idx + 1}`,
      company: e.company_or_org || e.company,
      role: e.role,
      duration: e.duration || '',
      bullets: e.highlights || e.bullets || []
    })),
    projects: (raw.extracted_projects || []).map((p: any, idx: number) => ({
      id: `proj-${idx + 1}`,
      title: p.title,
      role_or_tech: p.role_or_tech,
      description: p.description,
      technologies: p.key_technologies || p.technologies || [],
      bullets: p.bullets || [p.description].filter(Boolean) as string[]
    })),
    education: raw.education || [],
    certifications: (raw.certifications || raw.extracted_certifications || []).map((c: any) =>
      typeof c === 'string' ? { name: c } : c
    )
  };
}

/**
 * Calculates a nuanced, real-time ATS quality score synchronized directly with the structured resume content.
 * Features fast LRU memoization to prevent redundant calculations on UI re-renders.
 */
export function calculateATSScore(
  resume: StructuredResume | null | undefined,
  _baseAnchorScore: number = 72,
  targetJobDescription?: string | null,
  targetJobTitle?: string | null
): ATSAnalysisResult {
  if (!resume) {
    return {
      overall_score: 50,
      score_breakdown: {
        structure: 50,
        content_impact: 50,
        skill_density: 50,
        formatting_clarity: 50,
        keyword_match: 50,
        experience_relevance: 50,
        overall_quality: 50
      },
      metrics: {
        skill_count: 0,
        action_verb_count: 0,
        quantified_bullet_count: 0,
        total_bullet_count: 0,
        has_contact_complete: false,
        has_links: false,
        has_summary: false,
        experience_count: 0,
        project_count: 0,
        education_count: 0
      }
    };
  }

  // Fast deterministic caching based on content fingerprint
  const rawSkills = Array.isArray(resume.skills) ? resume.skills : [];
  const rawExp = Array.isArray(resume.experience) ? resume.experience : [];
  const rawProj = Array.isArray(resume.projects) ? resume.projects : [];
  const rawEdu = Array.isArray(resume.education) ? resume.education : [];
  const rawCerts = Array.isArray(resume.certifications) ? resume.certifications : [];

  const skillDigest = rawSkills.map(s => (typeof s === 'string' ? s : '')).join(',');
  const expBulletCount = rawExp.reduce((acc, e) => acc + (e?.bullets?.length || 0), 0);
  const projBulletCount = rawProj.reduce((acc, p) => acc + (p?.bullets?.length || 0), 0);
  const nameDigest = `${resume.personal_info?.full_name || ''}_${resume.personal_info?.email || ''}`;
  const jdDigest = targetJobDescription ? targetJobDescription.slice(0, 120).trim() : 'none';
  const cacheKey = `${nameDigest}:::${skillDigest}:::${expBulletCount}:::${projBulletCount}:::${resume.summary?.length || 0}:::${jdDigest}:::${targetJobTitle || ''}`;

  if (ATS_SCORE_CACHE.has(cacheKey)) {
    return ATS_SCORE_CACHE.get(cacheKey)!;
  }

  const personal_info = resume.personal_info || {};
  const summary = resume.summary || '';
  const skills = rawSkills;
  const experience = rawExp;
  const projects = rawProj;
  const education = rawEdu;

  // 1. Structure Audit (Max 100)
  let structurePts = 20;
  const hasName = !!personal_info?.full_name?.trim();
  const hasEmail = !!personal_info?.email?.trim();
  const hasPhone = !!personal_info?.phone?.trim();
  const hasLocation = !!personal_info?.location?.trim();
  const hasLinks = !!(
    personal_info?.linkedin ||
    personal_info?.github ||
    personal_info?.leetcode ||
    personal_info?.portfolio ||
    (personal_info?.links && personal_info.links.length > 0)
  );
  const hasSummary = !!(summary?.trim() || personal_info?.summary?.trim());

  if (hasName) structurePts += 15;
  if (hasEmail) structurePts += 15;
  if (hasPhone) structurePts += 10;
  if (hasLocation) structurePts += 5;
  if (hasLinks) structurePts += 15;
  if (hasSummary) structurePts += 10;
  if (experience.length > 0) structurePts += 5;
  if (projects.length > 0) structurePts += 5;
  if (rawCerts.length > 0) structurePts += 5;
  const structure = Math.min(98, Math.max(30, structurePts));

  // 2. Skill Density (Max 100)
  const distinctSkills = Array.from(
    new Set(
      skills
        .map(s => (typeof s === 'string' ? s.trim().toLowerCase() : ''))
        .filter(Boolean)
    )
  );
  const skillCount = distinctSkills.length;
  let skillPts = 40 + Math.min(50, Math.round(skillCount * 2.2));
  if (skillCount >= 8) skillPts += 5;
  if (skillCount >= 14) skillPts += 3;
  const skill_density = Math.min(98, Math.max(35, skillPts));

  // 3. Content Impact & STAR Quantification (Max 100)
  let totalBullets = 0;
  let actionVerbCount = 0;
  let quantifiedCount = 0;

  const checkBullet = (text: string) => {
    if (!text || typeof text !== 'string') return;
    totalBullets++;
    const lower = text.toLowerCase();
    
    const hasVerb = ACTION_VERBS.some(v => lower.includes(v));
    if (hasVerb) actionVerbCount++;

    if (METRIC_REGEX.test(text)) {
      quantifiedCount++;
    }
  };

  experience.forEach(exp => {
    if (!exp) return;
    (exp.bullets || []).forEach(checkBullet);
  });

  projects.forEach(proj => {
    if (!proj) return;
    if (proj.description) checkBullet(proj.description);
    (proj.bullets || []).forEach(checkBullet);
  });

  let impactPts = 45;
  impactPts += Math.min(25, actionVerbCount * 3.5);
  impactPts += Math.min(25, quantifiedCount * 4.5);
  if (hasSummary && (summary || personal_info?.summary || '').length > 60) {
    impactPts += 5;
  }
  const content_impact = Math.min(98, Math.max(35, Math.round(impactPts)));

  // 4. Formatting & Readability (Max 100)
  let formatPts = 60;
  if (totalBullets > 0) {
    const avgLen = totalBullets > 0 ? (actionVerbCount + quantifiedCount) / totalBullets : 0;
    if (avgLen > 0.4) formatPts += 15;
    if (avgLen > 0.7) formatPts += 15;
  }
  if (education.length > 0) formatPts += 10;
  const formatting_clarity = Math.min(98, Math.max(40, formatPts));

  // 5. Build Aggregated Full Resume Text for Keyword & Experience Examination
  const resumeFullText = [
    personal_info?.full_name || '',
    personal_info?.headline || personal_info?.title || resume.headline || resume.title || '',
    summary || personal_info?.summary || '',
    skills.map(s => (typeof s === 'string' ? s : '')).join(' '),
    experience.map(e => e ? `${e.role || ''} ${e.company || ''} ${(e.bullets || []).join(' ')}` : '').join(' '),
    projects.map(p => p ? `${p.title || ''} ${p.role_or_tech || ''} ${p.description || ''} ${(p.bullets || []).join(' ')}` : '').join(' ')
  ].join(' ').toLowerCase();

  const experienceOnlyText = experience.map(e => e ? `${e.role || ''} ${e.company || ''} ${(e.bullets || []).join(' ')}` : '').join(' ').toLowerCase();

  // 6. Job Description Specific Examination (If JD provided)
  const hasTargetJD = !!(targetJobDescription && targetJobDescription.trim().length > 15);
  let keyword_match = content_impact;
  let experience_relevance = content_impact;
  let matched_jd_keywords: string[] = [];
  let missing_jd_keywords: string[] = [];
  let jdTargetTitle = targetJobTitle || 'Target Role';

  if (hasTargetJD) {
    const jdData = extractJDKeywords(targetJobDescription!, targetJobTitle);
    jdTargetTitle = jdData.targetJobTitle || targetJobTitle || 'Target Role';

    const targetKeywords = jdData.keywords;
    if (targetKeywords.length > 0) {
      targetKeywords.forEach(kw => {
        if (resumeFullText.includes(kw.toLowerCase())) {
          matched_jd_keywords.push(kw);
        } else {
          missing_jd_keywords.push(kw);
        }
      });

      const matchRatio = matched_jd_keywords.length / targetKeywords.length;
      keyword_match = Math.min(98, Math.max(35, Math.round(40 + (matchRatio * 58))));

      // Check experience relevance against JD keywords & action verbs
      let expMatchedKeywords = 0;
      targetKeywords.forEach(kw => {
        if (experienceOnlyText.includes(kw.toLowerCase())) {
          expMatchedKeywords++;
        }
      });

      let expActionVerbsFound = 0;
      jdData.actionVerbs.forEach(v => {
        if (experienceOnlyText.includes(v)) {
          expActionVerbsFound++;
        }
      });

      // Also check if target title is reflected in experience or headline
      const titleLower = jdTargetTitle.toLowerCase();
      const hasTitleInExp = experienceOnlyText.includes(titleLower) || (personal_info?.headline || '').toLowerCase().includes(titleLower);

      let expRelBase = 45;
      if (experience.length > 0) expRelBase += 10;
      if (hasTitleInExp) expRelBase += 15;
      expRelBase += Math.min(20, (expMatchedKeywords / Math.max(targetKeywords.length, 1)) * 40);
      expRelBase += Math.min(10, expActionVerbsFound * 2);

      experience_relevance = Math.min(98, Math.max(35, Math.round(expRelBase)));
    } else {
      keyword_match = skill_density;
      experience_relevance = content_impact;
    }
  }

  // 7. Overall Composite ATS Score Calculation
  let overall_score: number;
  if (hasTargetJD) {
    // When tailored to a target JD:
    // 35% Keyword Match, 25% Experience Relevance, 20% Content Impact, 10% Skill Density, 10% Structure
    const tailoredComposite = Math.round(
      keyword_match * 0.35 +
      experience_relevance * 0.25 +
      content_impact * 0.20 +
      skill_density * 0.10 +
      structure * 0.10
    );
    overall_score = Math.min(98, Math.max(48, tailoredComposite));
  } else {
    // Standard baseline when no specific JD is provided
    const calculatedComposite = Math.round(
      content_impact * 0.35 +
      skill_density * 0.30 +
      structure * 0.20 +
      formatting_clarity * 0.15
    );
    overall_score = Math.min(98, Math.max(45, calculatedComposite));
  }

  const analysisResult: ATSAnalysisResult = {
    overall_score,
    score_breakdown: {
      structure,
      content_impact,
      skill_density,
      formatting_clarity,
      keyword_match,
      experience_relevance,
      overall_quality: overall_score
    },
    metrics: {
      skill_count: skillCount,
      action_verb_count: actionVerbCount,
      quantified_bullet_count: quantifiedCount,
      total_bullet_count: totalBullets,
      has_contact_complete: hasName && hasEmail && hasPhone,
      has_links: hasLinks,
      has_summary: hasSummary,
      experience_count: experience.length,
      project_count: projects.length,
      education_count: education.length,
      is_job_tailored: hasTargetJD,
      target_job_title: jdTargetTitle,
      jd_keyword_match_percentage: keyword_match,
      jd_experience_relevance_percentage: experience_relevance,
      matched_jd_keywords: matched_jd_keywords,
      missing_jd_keywords: missing_jd_keywords,
      total_jd_keywords_count: hasTargetJD ? (matched_jd_keywords.length + missing_jd_keywords.length) : undefined
    }
  };

  trimCache(ATS_SCORE_CACHE, MAX_CACHE_SIZE);
  ATS_SCORE_CACHE.set(cacheKey, analysisResult);
  return analysisResult;
}
