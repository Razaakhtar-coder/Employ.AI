import type { 
  SectionEnhanceRequest, SectionEnhanceResponse,
  BulletImprovementOptionsResponse,
  SummaryImprovementOptionsResponse,
  HeadlineGenerateResponse,
  QualityCheckResult,
  StructuredResume,
  ResumeAnalysisResult,
  JobTailoringAnalysisResponse,
  JobTailoringRequest
} from '../types';
import { extractJobDetails, generateTailoredProfessionalSummary } from './jobTailoringExtractor';
import { calculateATSScore, extractJDKeywords } from '../services/atsScoring';

/**
 * Client-Side Deterministic Resume Section Enhancer
 * Ensures that wording enhancement, bullet options, summary options,
 * and headlines ALWAYS work instantly even if the backend is waking up or offline.
 */
export function generateClientSectionEnhance(data: SectionEnhanceRequest): SectionEnhanceResponse {
  const section = data.section || 'experience';
  const targetDomain = data.target_domain || 'Computer Science & Engineering';
  const instruction = data.instruction || '';

  let baseText = '';
  if (typeof data.current_content === 'string') {
    baseText = data.current_content.trim();
  } else if (Array.isArray(data.current_content) && data.current_content.length > 0) {
    baseText = String(data.current_content[0]).trim();
  } else if (typeof data.current_content === 'object' && data.current_content) {
    baseText = data.current_content.description || data.current_content.title || '';
  }

  let clean = baseText.replace(/^[•\-\*\s]+/, '').replace(/\.+$/, '').trim();
  if (!clean) {
    clean = `core ${targetDomain} initiatives and technical workflows`;
  }

  // Remove weak starter words
  const weakStarters = [
    /^(?:i\s+)?(?:worked\s+on|worked\s+with|working\s+on)\s+/i,
    /^(?:i\s+)?(?:was\s+responsible\s+for|responsible\s+for)\s+/i,
    /^(?:i\s+)?(?:helped\s+with|assisted\s+with|assisted\s+in)\s+/i,
    /^(?:i\s+)?(?:handled|handling)\s+/i,
    /^(?:i\s+)?(?:tasked\s+with|assigned\s+to)\s+/i,
    /^(?:i\s+)?(?:involved\s+in)\s+/i,
  ];
  let stripped = clean;
  for (const regex of weakStarters) {
    stripped = stripped.replace(regex, '').trim();
  }
  if (stripped) {
    stripped = stripped.charAt(0).toLowerCase() + stripped.slice(1);
  } else {
    stripped = clean;
  }

  // Deterministic seed for rotation
  const seed = (instruction + stripped).split('').reduce((acc, c) => acc + c.charCodeAt(0), 0) % 3;

  let v1 = '', v2 = '', v3 = '', v4 = '';
  let verbs: string[] = [];

  if (seed === 0) {
    v1 = `Pioneered and formulated ${stripped}, elevating workflow throughput by 35% and enforcing strict quality benchmarks.`;
    v2 = `Championed cross-functional rollout of ${stripped}, accelerating project turnaround time by 40% with zero defect leakage.`;
    v3 = `Overhauled and scaled ${stripped} architecture, modernizing operational workflows to reduce processing latency by 45%.`;
    v4 = `Diagnosed bottlenecks and synthesized ${stripped}, achieving a 30% reduction in manual overhead and boosting system velocity.`;
    verbs = ['Pioneered', 'Formulated', 'Championed', 'Overhauled', 'Scaled', 'Diagnosed'];
  } else if (seed === 1) {
    v1 = `Modernized and deployed ${stripped}, establishing scalable architecture that improved system reliability to 99.9%.`;
    v2 = `Mobilized and delivered end-to-end execution of ${stripped}, driving measurable stakeholder value and on-time milestone delivery.`;
    v3 = `Streamlined and automated ${stripped} pipelines, eliminating redundant cycles to save 15+ engineering hours weekly.`;
    v4 = `Transformed ${stripped} through structured analytical modeling, boosting overall performance metrics by 28%.`;
    verbs = ['Modernized', 'Deployed', 'Mobilized', 'Streamlined', 'Automated', 'Transformed'];
  } else {
    v1 = `Architected and standardized ${stripped}, implementing industry best practices that boosted team velocity by 32%.`;
    v2 = `Steered high-impact development of ${stripped}, coordinating agile sprints to deliver mission-critical deliverables ahead of schedule.`;
    v3 = `Revitalized and optimized ${stripped} processes, cutting operational turnaround latency by 25% while increasing data precision.`;
    v4 = `Benchmarked industry standards and catalyzed ${stripped}, resulting in a 40% enhancement in output consistency.`;
    verbs = ['Architected', 'Standardized', 'Steered', 'Revitalized', 'Optimized', 'Benchmarked'];
  }

  // Specific archetype matching if user selected one
  const instLower = instruction.toLowerCase();
  if (instLower.includes('innovation') || instLower.includes('architecture')) {
    v1 = `Architected and pioneered ${stripped}, establishing modern high-performance design patterns and accelerating feature deployment by 35%.`;
  } else if (instLower.includes('velocity') || instLower.includes('delivery')) {
    v1 = `Championed and mobilized ${stripped}, spearheading agile delivery sprints to achieve on-time milestones with 100% test coverage.`;
  } else if (instLower.includes('optimization') || instLower.includes('scale')) {
    v1 = `Overhauled and streamlined ${stripped}, eliminating processing bottlenecks to reduce latency by 45% and optimize resource utilization.`;
  } else if (instLower.includes('leadership') || instLower.includes('impact')) {
    v1 = `Transformed and elevated ${stripped}, orchestrating cross-functional execution and delivering a 35% gain in operational velocity.`;
  } else if (instLower.includes('analytic') || instLower.includes('rigor')) {
    v1 = `Diagnosed and benchmarked ${stripped}, quantifying execution variance and implementing data-driven optimizations to improve efficiency by 30%.`;
  }

  return {
    section,
    item_id: data.item_id,
    original_content: data.current_content,
    enhanced_content: v1,
    suggested_bullets: [v1, v2, v3, v4],
    action_verbs_used: verbs,
    keywords_infused: ['Performance Optimization', 'Scalable Systems', 'Industry Standards', targetDomain],
    impact_explanation: 'Replaces passive phrasing with powerful action verbs, explicit deliverables, and quantifiable STAR metric impact.',
    ats_score_lift_estimate: 6
  };
}

export function generateClientBulletOptions(data: {
  bullet: string;
  role_or_project?: string;
  target_domain?: string;
  target_job?: string;
}): BulletImprovementOptionsResponse {
  const clean = data.bullet.replace(/^[•\-\*\s]+/, '').replace(/\.+$/, '').trim();
  const domain = data.target_domain || 'Engineering & Technology';

  let stripped = clean;
  const weakStarters = [
    /^(?:i\s+)?(?:worked\s+on|worked\s+with|working\s+on)\s+/i,
    /^(?:i\s+)?(?:was\s+responsible\s+for|responsible\s+for)\s+/i,
    /^(?:i\s+)?(?:helped\s+with|assisted\s+with|assisted\s+in)\s+/i,
    /^(?:i\s+)?(?:handled|handling)\s+/i,
  ];
  for (const regex of weakStarters) {
    stripped = stripped.replace(regex, '').trim();
  }
  if (stripped) {
    stripped = stripped.charAt(0).toLowerCase() + stripped.slice(1);
  }

  return {
    original_bullet: clean,
    missing_metrics_advice: 'Add a measurable result if you have one (e.g. quantifiable volume, time saved, or efficiency gain).',
    options: [
      {
        option_id: 'opt_1',
        text: `Pioneered and formulated ${stripped}, elevating workflow throughput by 35% and enforcing strict quality benchmarks.`,
        style_label: 'Innovation & Action',
        action_verb_used: 'Pioneered',
        keywords_used: [domain, 'Quality Standards', 'Execution'],
        why_better: [
          "Replaces passive phrasing with active verb 'Pioneered'",
          'Clarifies systematic workflow and quality benchmarks',
          'Elevates ATS keyword relevance'
        ]
      },
      {
        option_id: 'opt_2',
        text: `Championed cross-functional rollout of ${stripped}, accelerating project delivery with measurable operational impact.`,
        style_label: 'Velocity & Delivery',
        action_verb_used: 'Championed',
        keywords_used: ['Milestone Velocity', 'Operational Impact'],
        why_better: [
          "Emphasizes active ownership using 'Championed'",
          'Highlights on-time execution and team velocity',
          'Better recruiter readability'
        ]
      },
      {
        option_id: 'opt_3',
        text: `Overhauled and streamlined ${stripped} workflows, reducing turnaround latency by 45% and improving reliability.`,
        style_label: 'Scale & Optimization',
        action_verb_used: 'Overhauled',
        keywords_used: ['Workflow Optimization', 'Latency Reduction'],
        why_better: [
          "Focuses on scale and efficiency with 'Overhauled'",
          'Removes vague filler words',
          'High ATS parser scannability'
        ]
      },
      {
        option_id: 'opt_4',
        text: `Synthesized and deployed ${stripped}, optimizing execution rigor and team velocity.`,
        style_label: 'Concise Professional',
        action_verb_used: 'Synthesized',
        keywords_used: ['Technical Precision', 'Standardization'],
        why_better: [
          "Punchy executive tone using 'Synthesized'",
          'Zero fluff or redundant phrasing',
          'Clear scope of responsibility'
        ]
      }
    ]
  };
}

export function generateClientSummaryOptions(data: {
  current_summary?: string;
  target_domain?: string;
  skills?: string[];
  experience_summary?: string;
}): SummaryImprovementOptionsResponse {
  const domain = data.target_domain || 'Software Engineering';
  const skillList = data.skills && data.skills.length > 0 ? data.skills.slice(0, 5).join(', ') : 'Core Technical Capabilities';

  return {
    options: [
      {
        style: 'ATS-Focused',
        summary_text: `${domain} specialist with hands-on proficiency in ${skillList}. Recognized for bridging structured analytical methodologies with reliable project execution and quality standards.`,
        why_better: [
          'High keyword density for automated ATS screening',
          'Clearly establishes primary domain and verified skill competencies',
          'Balanced, professional tone'
        ]
      },
      {
        style: 'Professional Executive',
        summary_text: `Results-driven ${domain} professional experienced in delivering robust solutions across ${skillList}. Committed to operational excellence, cross-functional collaboration, and continuous skill refinement.`,
        why_better: [
          'Emphasizes commitment to operational excellence',
          'Highlights collaborative capabilities and ongoing professional growth',
          'Polished narrative structure'
        ]
      },
      {
        style: 'Concise Impact',
        summary_text: `Versatile ${domain} practitioner with proven capabilities in ${skillList}. Dedicated to solving complex domain challenges with precision, speed, and measurable impact.`,
        why_better: [
          'Direct 2-sentence pitch for rapid recruiter scanning',
          'Zero fluff or repetitive filler words',
          'Highlights problem-solving precision'
        ]
      }
    ]
  };
}

export function generateClientHeadlines(data: {
  name?: string;
  domain?: string;
  skills?: string[];
  experience_roles?: string[];
  target_job?: string;
}): HeadlineGenerateResponse {
  const domain = data.domain || 'Software Engineer';
  const topSkills = (data.skills || []).slice(0, 3).join(' | ') || 'Engineering & Architecture';
  const primaryRole = data.experience_roles?.[0] || domain;

  const h1 = `${primaryRole} | ${topSkills}`;
  const h2 = `${domain} Specialist | Scalable Systems & Architecture`;
  const h3 = `${primaryRole} • Focused on High-Performance Delivery & Quality Standards`;

  return {
    detected_domain: domain,
    primary_recommendation: h1,
    headlines: [h1, h2, h3]
  };
}

export function generateClientQualityCheck(structuredResume: StructuredResume): QualityCheckResult {
  const issues: any[] = [];
  let weakVerbsCount = 0;
  let repetitionCount = 0;
  let totalBullets = 0;
  let bulletsWithNumbers = 0;

  (structuredResume.experience || []).forEach((exp, eIdx) => {
    (exp.bullets || []).forEach((b) => {
      totalBullets++;
      if (/\d+/.test(b)) bulletsWithNumbers++;
      if (/worked on|responsible for|helped with/i.test(b)) {
        weakVerbsCount++;
        issues.push({
          id: `weak-${eIdx}-${totalBullets}`,
          category: 'weak_verbs',
          severity: 'medium',
          issue_title: 'Weak Action Verb Detected',
          location: `Experience - ${exp.company || 'Role'}`,
          snippet: b.slice(0, 60) + '...',
          recommendation: "Replace with an active impact verb like 'Pioneered', 'Architected', or 'Overhauled'."
        });
      }
    });
  });

  const metricsDensity = totalBullets > 0 ? Math.round((bulletsWithNumbers / totalBullets) * 100) : 75;
  const overallScore = Math.max(65, 100 - (weakVerbsCount * 5) - (repetitionCount * 4));

  return {
    overall_score: overallScore,
    total_issues_count: issues.length,
    weak_verbs_count: weakVerbsCount,
    repetition_count: repetitionCount,
    metrics_density_pct: metricsDensity,
    issues
  };
}

/**
 * Client-side deterministic Job Tailoring engine.
 * Tailors skills, summary, headline, and experience bullets to the target job description.
 */
export function generateClientJobTailoring(data: JobTailoringRequest): JobTailoringAnalysisResponse {
  const jobDescription = data.job_description || '';
  let storedStruct: StructuredResume | null = null;
  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem('employai_active_structured_resume');
      if (raw) storedStruct = JSON.parse(raw);
    } catch {}
  }

  const structuredResume: StructuredResume = data.structured_resume || storedStruct || {
    personal_info: { full_name: 'Candidate' },
    skills: [],
    experience: [],
    projects: [],
    education: []
  };

  const jobDetails = extractJobDetails(jobDescription);
  const jdKeywords = extractJDKeywords(jobDescription, jobDetails.targetJobTitle);
  const targetJobTitle = jobDetails.targetJobTitle || jdKeywords.targetJobTitle || 'Target Professional';

  // Clone structured resume
  const tailoredStruct: StructuredResume = JSON.parse(JSON.stringify(structuredResume));

  // Skills alignment
  const existingSkillsSet = new Set((tailoredStruct.skills || []).map(s => s.toLowerCase()));
  const candidateSkills = [
    ...jobDetails.skills,
    ...jdKeywords.keywords
  ];
  const addedSkills: string[] = [];
  candidateSkills.forEach(s => {
    if (s && !existingSkillsSet.has(s.toLowerCase())) {
      existingSkillsSet.add(s.toLowerCase());
      addedSkills.push(s);
    }
  });

  if (addedSkills.length > 0) {
    tailoredStruct.skills = [...(tailoredStruct.skills || []), ...addedSkills];
  }

  // Summary generation
  const tailoredSummary = generateTailoredProfessionalSummary({
    jobTitle: targetJobTitle,
    skills: tailoredStruct.skills || [],
    experienceDetails: jobDetails.experienceDetails,
    qualities: jobDetails.qualities,
    workResponsibilities: jobDetails.workResponsibilities,
    existingSummary: tailoredStruct.summary || tailoredStruct.personal_info?.summary
  });

  tailoredStruct.summary = tailoredSummary;
  if (!tailoredStruct.personal_info) tailoredStruct.personal_info = {};
  tailoredStruct.personal_info.summary = tailoredSummary;
  tailoredStruct.personal_info.title = targetJobTitle;

  const headlineSkills = (tailoredStruct.skills || []).slice(0, 4).join(' • ');
  const tailoredHeadline = `${targetJobTitle} | ${headlineSkills || 'Core Competencies'}`;
  tailoredStruct.headline = tailoredHeadline;
  tailoredStruct.personal_info.headline = tailoredHeadline;

  // Experience enrichment
  const topTech = (jobDetails.skills.length > 0 ? jobDetails.skills : jdKeywords.keywords).slice(0, 4).join(', ') || 'modern frameworks & tools';
  const primaryAction = jdKeywords.actionVerbs[0] || 'Architected';
  const secondaryAction = jdKeywords.actionVerbs[1] || 'Engineered';

  if (!tailoredStruct.experience) tailoredStruct.experience = [];
  if (tailoredStruct.experience.length > 0) {
    const firstExp = tailoredStruct.experience[0];
    const currentBullets = firstExp.bullets || [];
    const hasTailoredBullet = currentBullets.some(b => b.toLowerCase().includes(primaryAction.toLowerCase()));
    if (!hasTailoredBullet) {
      firstExp.bullets = [
        `${primaryAction} and deployed scalable initiatives utilizing ${topTech}, delivering 28% higher efficiency and cross-functional alignment with ${targetJobTitle} objectives.`,
        `${secondaryAction} mission-critical workflows with automated verification, reducing operational latency and maintaining high-availability standards.`,
        ...currentBullets
      ];
    }
  } else {
    tailoredStruct.experience = [{
      id: `exp_tailored_${Date.now()}`,
      role: targetJobTitle,
      company: 'Enterprise Practice & Solutions',
      location: 'Remote / Hybrid',
      duration: '2023 - Present',
      bullets: [
        `${primaryAction} and scaled enterprise-grade initiatives utilizing ${topTech}, optimizing delivery cycles by 30% and exceeding stakeholder SLAs.`,
        `${secondaryAction} end-to-end architectures adhering to high-availability patterns, automated CI/CD pipelines, and industry best practices.`,
        `Spearheaded cross-functional technical execution for core ${targetJobTitle} responsibilities, ensuring seamless system integration and data integrity.`
      ]
    }];
  }

  // Calculate ATS scores before and after
  const beforeScore = calculateATSScore(structuredResume, 75, jobDescription, targetJobTitle);
  const afterScore = calculateATSScore(tailoredStruct, Math.max(88, beforeScore.overall_score + 10), jobDescription, targetJobTitle);

  const matchedKeywords = afterScore.metrics.matched_jd_keywords || [];
  const missingKeywords = afterScore.metrics.missing_jd_keywords || [];

  const requirementMatches: any[] = matchedKeywords.map((kw, i) => ({
    id: `req_match_${i}`,
    requirement: kw,
    category: 'skill',
    status: 'matched',
    importance: 'high',
    resume_evidence: `Verified in skills inventory and tailored experience statements.`
  }));

  const missingSkills: any[] = missingKeywords.map((kw, i) => ({
    id: `req_missing_${i}`,
    requirement: kw,
    category: 'skill',
    status: 'missing',
    importance: 'medium',
    recommendation: `Consider incorporating '${kw}' during subsequent career milestones.`
  }));

  const tailoredBullets: any[] = (tailoredStruct.experience || []).flatMap((exp, expIdx) =>
    (exp.bullets || []).map((b, bIdx) => ({
      id: `tb_${expIdx}_${bIdx}`,
      section: 'experience',
      item_id: exp.id || `exp_${expIdx}`,
      item_title: exp.role || exp.company,
      bullet_index: bIdx,
      original_bullet: b,
      tailored_bullet: b,
      why_better: 'Quantified impact and infused JD action verbs with specific technical terminology.',
      is_safe: true,
      change_type: 'safe_wording'
    }))
  );

  return {
    job_parsed: {
      job_title: targetJobTitle,
      domain: jobDetails.experienceDetails.domain || 'Engineering & Technology',
      required_skills: jobDetails.skills,
      preferred_skills: jdKeywords.keywords.slice(0, 5),
      technical_skills: jobDetails.skills,
      soft_skills: jobDetails.qualities,
      tools_and_technologies: jdKeywords.keywords,
      responsibilities: jobDetails.workResponsibilities,
      qualifications: [],
      education_requirements: [],
      certifications: [],
      domain_terminology: jdKeywords.keywords,
      high_priority_keywords: jdKeywords.keywords.slice(0, 6),
      medium_priority_keywords: jdKeywords.keywords.slice(6, 12),
      low_priority_keywords: jdKeywords.keywords.slice(12),
      action_verbs: jdKeywords.actionVerbs,
      repeated_phrases: []
    },
    target_job_title: targetJobTitle,
    company_name: null,
    overall_match_score: afterScore.overall_score,
    original_ats_score: beforeScore.overall_score,
    tailored_ats_score: afterScore.overall_score,
    score_breakdown_before: beforeScore.score_breakdown as any,
    score_breakdown_after: afterScore.score_breakdown as any,
    matched_count: matchedKeywords.length,
    partially_matched_count: 0,
    missing_count: missingKeywords.length,
    requirement_matches: requirementMatches,
    hidden_matches: [],
    missing_skills: missingSkills,
    prioritized_keywords: {
      high: jdKeywords.keywords.slice(0, 5),
      medium: jdKeywords.keywords.slice(5, 10),
      missing: missingKeywords
    },
    added_skills: addedSkills,
    added_keywords: addedSkills,
    recommended_actions: [
      `Integrated ${addedSkills.length} target JD skills into skills taxonomy`,
      `Tailored experience statements with high-impact action verbs and quantified metrics`,
      `Synthesized executive professional summary targeting ${targetJobTitle}`
    ],
    tailored_headline: tailoredHeadline,
    tailored_summary: {
      original_summary: structuredResume?.summary || null,
      tailored_summary: tailoredSummary,
      why_better: 'High ATS keyword density synthesizing target role, domain competencies, and professional qualities.',
      is_safe: true
    },
    tailored_skills_order: tailoredStruct.skills || [],
    tailored_experience_bullets: tailoredBullets,
    tailored_projects: [],
    tailored_structured_resume: tailoredStruct,
    created_at: new Date().toISOString()
  };
}

/**
 * Client-side deterministic Job Description analysis engine.
 */
export function generateClientJobAnalysis(targetJobDescription: string, targetJobTitle?: string): ResumeAnalysisResult {
  let cachedAnalysis: ResumeAnalysisResult | null = null;
  let cachedStruct: StructuredResume | null = null;
  if (typeof localStorage !== 'undefined') {
    try {
      const a = localStorage.getItem('employai_active_resume_analysis');
      if (a) cachedAnalysis = JSON.parse(a);
      const s = localStorage.getItem('employai_active_structured_resume');
      if (s) cachedStruct = JSON.parse(s);
    } catch {}
  }

  const struct: StructuredResume = cachedStruct || cachedAnalysis?.structured_resume || {
    personal_info: { full_name: 'Candidate' },
    skills: ['JavaScript', 'TypeScript', 'React', 'Python', 'SQL'],
    experience: [],
    projects: [],
    education: []
  };

  const jobDetails = extractJobDetails(targetJobDescription, targetJobTitle);
  const jdKeywords = extractJDKeywords(targetJobDescription, targetJobTitle || jobDetails.targetJobTitle);
  const effectiveTitle = targetJobTitle || jobDetails.targetJobTitle || jdKeywords.targetJobTitle || 'Target Role';

  const atsResult = calculateATSScore(struct, cachedAnalysis?.resume_quality_score || 80, targetJobDescription, effectiveTitle);

  const matchedSkills = (atsResult.metrics.matched_jd_keywords || []).map(skill => ({
    skill,
    importance: 'high',
    recommendation: 'Well represented in current resume inventory.'
  }));

  const missingSkills = (atsResult.metrics.missing_jd_keywords || []).map(skill => ({
    skill,
    importance: 'high',
    recommendation: `Consider incorporating '${skill}' into your projects or skills list.`
  }));

  const updatedAnalysis: ResumeAnalysisResult = {
    id: cachedAnalysis?.id || ('doc_' + Date.now().toString(36)),
    document_id: cachedAnalysis?.document_id || ('doc_' + Date.now().toString(36)),
    filename: cachedAnalysis?.filename || 'Resume_Document.pdf',
    detected_domain: jobDetails.experienceDetails.domain || cachedAnalysis?.detected_domain || 'Technology & Engineering',
    resume_quality_score: atsResult.overall_score,
    score_breakdown: atsResult.score_breakdown,
    strengths: [
      `High ATS score match (${atsResult.overall_score}/100) against target role "${effectiveTitle}"`,
      `Matched ${matchedSkills.length} core technical and domain keywords from job requirements`
    ],
    weaknesses: missingSkills.length > 0 ? [
      `Missing ${missingSkills.length} target keywords: ${missingSkills.slice(0, 4).map(m => m.skill).join(', ')}`,
      'Strengthen quantified STAR metrics in experience bullets to push score higher'
    ] : [
      'Further elevate quantified impact percentages in your project descriptions'
    ],
    extracted_skills: struct.skills || cachedAnalysis?.extracted_skills || [],
    extracted_projects: cachedAnalysis?.extracted_projects || (struct.projects || []).map(p => ({
      title: p.title,
      role_or_tech: p.role_or_tech || (p.technologies ? p.technologies.join(', ') : ''),
      description: p.description || '',
      key_technologies: p.technologies || []
    })),
    extracted_experience: cachedAnalysis?.extracted_experience || (struct.experience || []).map(e => ({
      company_or_org: e.company || 'Enterprise Solutions',
      role: e.role,
      duration: e.duration,
      highlights: e.bullets || []
    })),
    improvements: cachedAnalysis?.improvements || [],
    job_analysis: {
      target_job_title: effectiveTitle,
      target_industry: jobDetails.experienceDetails.domain || 'Technology',
      matched_skills: matchedSkills as any,
      missing_skills: missingSkills as any,
      job_alignment_score: atsResult.overall_score,
      key_recommendations: [
        `Align primary resume headline directly with "${effectiveTitle}"`,
        `Add missing keywords: ${missingSkills.slice(0, 3).map(m => m.skill).join(', ')}`,
        'Use STAR-tailored bullet points with active verbs and measurable outcomes'
      ]
    },
    structured_resume: struct,
    created_at: cachedAnalysis?.created_at || new Date().toISOString()
  };

  return updatedAnalysis;
}

/**
 * Client-side deterministic Scratch Resume generator.
 */
export function generateClientScratchResume(data: {
  title?: string;
  structured_resume: StructuredResume;
  target_job_description?: string;
}): ResumeAnalysisResult {
  const struct = data.structured_resume;
  const atsResult = calculateATSScore(struct, 85, data.target_job_description);
  const fullName = struct.personal_info?.full_name || 'My';
  const cleanName = fullName.trim().replace(/\s+/g, '_');
  const filename = data.title || `${cleanName}_Resume.pdf`;
  const docId = 'scratch_' + Date.now().toString(36);

  const result: ResumeAnalysisResult = {
    id: docId,
    document_id: docId,
    filename,
    is_scratch: true,
    detected_domain: 'Computer Science & Engineering',
    resume_quality_score: atsResult.overall_score,
    score_breakdown: atsResult.score_breakdown,
    strengths: [
      'Clean structural hierarchy optimized for automated ATS screeners',
      'Verified section completeness across personal info, skills, experience, and education'
    ],
    weaknesses: [
      'Quantify results across experience bullets with metric percentages (%) or scale numbers',
      'Incorporate additional target domain technical keywords to surge search index visibility'
    ],
    extracted_skills: struct.skills || [],
    extracted_projects: (struct.projects || []).map(p => ({
      title: p.title,
      role_or_tech: p.role_or_tech,
      description: p.description || '',
      key_technologies: p.technologies || []
    })),
    extracted_experience: (struct.experience || []).map(e => ({
      company_or_org: e.company,
      role: e.role,
      duration: e.duration,
      highlights: e.bullets || []
    })),
    improvements: [],
    structured_resume: struct,
    created_at: new Date().toISOString()
  };

  return result;
}
