from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field


class DocumentResponse(BaseModel):
    id: str
    user_id: str
    original_filename: str
    file_type: str
    file_size_bytes: int
    upload_status: str
    created_at: datetime

    class Config:
        from_attributes = True


class ScoreBreakdown(BaseModel):
    structure: float = Field(..., description="ATS document structure score out of 100")
    content_impact: float = Field(..., description="Action verbs and measurable results score")
    skill_density: float = Field(..., description="Domain skills presence score")
    formatting_clarity: float = Field(..., description="Layout and parseability score")
    overall_quality: float = Field(..., description="Aggregate ATS quality score out of 100")


class ExtractedProject(BaseModel):
    title: str
    role_or_tech: Optional[str] = None
    description: str
    key_technologies: List[str] = []
    quantifiable_metrics: Optional[str] = None


class ExtractedExperience(BaseModel):
    company_or_org: str
    role: str
    duration: Optional[str] = None
    highlights: List[str] = []


class ResumeImprovementItem(BaseModel):
    section: str  # e.g., "Project Experience", "Work Experience", "Summary"
    original_bullet: str
    improved_bullet: str
    rationale: str
    framework_used: str = "STAR Method (Situation, Task, Action, Result)"
    is_applied: Optional[bool] = False
    is_safe_change: Optional[bool] = True
    requires_user_confirmation: Optional[bool] = False


class ResumeLinkItem(BaseModel):
    label: str
    url: str
    type: Optional[str] = "other"  # linkedin, github, leetcode, codeforces, codechef, hackerrank, kaggle, portfolio, repo, demo, other


class ResumePersonalInfo(BaseModel):
    full_name: Optional[str] = None
    headline: Optional[str] = None
    title: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    location: Optional[str] = None
    linkedin: Optional[str] = None
    github: Optional[str] = None
    leetcode: Optional[str] = None
    codeforces: Optional[str] = None
    codechef: Optional[str] = None
    hackerrank: Optional[str] = None
    kaggle: Optional[str] = None
    portfolio: Optional[str] = None
    other_links: List[str] = []
    links: List[ResumeLinkItem] = []
    summary: Optional[str] = None


class ResumeEducationItem(BaseModel):
    institution: str
    degree: str
    field_of_study: Optional[str] = None
    start_year: Optional[str] = None
    end_year: Optional[str] = None
    grade_or_cgpa: Optional[str] = None
    location: Optional[str] = None


class ResumeExperienceItem(BaseModel):
    id: Optional[str] = None
    company: str
    role: str
    location: Optional[str] = None
    duration: Optional[str] = None
    bullets: List[str] = []
    technologies: List[str] = []


class ResumeProjectItem(BaseModel):
    id: Optional[str] = None
    title: str
    role_or_tech: Optional[str] = None
    duration: Optional[str] = None
    description: Optional[str] = None
    technologies: List[str] = []
    bullets: List[str] = []
    url: Optional[str] = None  # Live demo link
    code_url: Optional[str] = None  # GitHub / Code repository link
    links: List[ResumeLinkItem] = []


class ResumeCertificationItem(BaseModel):
    name: str
    issuer: Optional[str] = None
    year: Optional[str] = None


class StructuredResumeData(BaseModel):
    personal_info: ResumePersonalInfo = Field(default_factory=ResumePersonalInfo)
    headline: Optional[str] = None
    title: Optional[str] = None
    summary: Optional[str] = None
    skills: List[str] = []
    technical_skills: Dict[str, List[str]] = Field(default_factory=dict)
    experience: List[ResumeExperienceItem] = []
    projects: List[ResumeProjectItem] = []
    portfolio: List[ResumeProjectItem] = Field(default_factory=list)
    education: List[ResumeEducationItem] = []
    certifications: List[ResumeCertificationItem] = []
    achievements: List[str] = []
    publications: List[str] = []
    awards: List[str] = []
    volunteering: List[str] = []
    languages: List[str] = []


class KeywordRecommendationItem(BaseModel):
    keyword: str
    category: str  # "EXISTING STRONG", "EXISTING UNDERUSED", "RECOMMENDED IF TRUE", "DOMAIN KEYWORD", "ACTION VERB"
    reason: str
    status: str  # "present", "missing", "underused"


class JobSkillMatchItem(BaseModel):
    skill: str
    status: str  # "matched", "partial", "missing"
    resume_evidence: Optional[str] = None
    recommendation: Optional[str] = None


class JobDescriptionAnalysis(BaseModel):
    target_job_title: Optional[str] = None
    target_industry: Optional[str] = None
    matched_skills: List[JobSkillMatchItem] = []
    missing_skills: List[JobSkillMatchItem] = []
    job_alignment_score: Optional[float] = None
    key_recommendations: List[str] = []


class ResumeExtractionVerification(BaseModel):
    filename: str
    file_type: str
    char_count: int
    word_count: int
    alpha_count: int
    extraction_method: str
    is_valid: bool


class SkillGapAuditItem(BaseModel):
    skill: str
    category: str = "Core Competency"
    importance: str = "high"  # critical, high, medium
    reason: str
    suggested_action: str


class SectionAuditItem(BaseModel):
    status: str = "needs_modification"  # needs_modification, good, strong
    section_name: str
    issues_detected: List[str] = []
    modifications_needed: List[str] = []
    ai_recommendation: str


class ResumeSectionAudits(BaseModel):
    skill_gaps: List[SkillGapAuditItem] = []
    experience_audit: SectionAuditItem
    projects_audit: SectionAuditItem
    skills_audit: SectionAuditItem
    summary_audit: SectionAuditItem


class SectionEnhanceRequest(BaseModel):
    section: str = Field(..., description="Section to enhance: experience, projects, summary, skills, education")
    item_id: Optional[str] = None
    current_content: Optional[Any] = None  # text, bullet list, or dict
    target_domain: Optional[str] = None
    target_role: Optional[str] = None
    instruction: Optional[str] = None  # e.g., 'Make it more quantifiable with STAR method'


class SectionEnhanceResponse(BaseModel):
    section: str
    item_id: Optional[str] = None
    original_content: Optional[Any] = None
    enhanced_content: Optional[str] = None
    suggested_bullets: List[str] = []
    action_verbs_used: List[str] = []
    keywords_infused: List[str] = []
    impact_explanation: str
    ats_score_lift_estimate: int = 4


class AnalysisResultResponse(BaseModel):
    id: str
    document_id: str
    student_profile_id: str
    resume_quality_score: float
    score_breakdown: ScoreBreakdown
    detected_domain: str
    strengths: List[str]
    weaknesses: List[str]
    extracted_skills: List[str]
    extracted_projects: List[ExtractedProject]
    extracted_experience: List[ExtractedExperience]
    improvement_suggestions: List[ResumeImprovementItem]
    structured_resume: Optional[StructuredResumeData] = None
    keyword_recommendations: List[KeywordRecommendationItem] = []
    job_analysis: Optional[JobDescriptionAnalysis] = None
    section_audits: Optional[ResumeSectionAudits] = None
    skill_gaps: List[SkillGapAuditItem] = []
    raw_text: Optional[str] = None
    filename: Optional[str] = None
    file_url: Optional[str] = None
    detected_links: List[ResumeLinkItem] = []
    is_scratch: Optional[bool] = False
    created_at: datetime


class ApplyImprovementRequest(BaseModel):
    analysis_id: str
    applied_improvements: List[Dict[str, str]]


class JobAnalysisRequest(BaseModel):
    target_job_description: str
    target_job_title: Optional[str] = None


class ResumeVersionItemSchema(BaseModel):
    version_id: str
    version_num: int
    version_name: str
    target_job: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    structured_resume: Optional[StructuredResumeData] = None
    resume_quality_score: Optional[float] = 80.0


class SavedResumeSummary(BaseModel):
    id: str
    title: str
    original_filename: str
    detected_domain: str
    ats_score: float
    created_at: datetime
    updated_at: datetime
    version_count: int
    active_version_id: Optional[str] = None
    target_job: Optional[str] = None
    versions: List[ResumeVersionItemSchema] = []


class ResumeVersionCreateRequest(BaseModel):
    document_id: str
    version_name: str
    target_job: Optional[str] = None
    structured_resume: StructuredResumeData


class ResumeRenameRequest(BaseModel):
    title: str


class HeadlineGenerateRequest(BaseModel):
    name: Optional[str] = None
    domain: Optional[str] = None
    skills: List[str] = []
    experience_roles: List[str] = []
    target_job: Optional[str] = None


class HeadlineGenerateResponse(BaseModel):
    headlines: List[str]
    detected_domain: str
    primary_recommendation: str


class BulletImprovementOption(BaseModel):
    option_id: str
    text: str
    style_label: str  # e.g., "Action-Focused", "Impact & Metrics", "Concise Technical"
    why_better: List[str]
    action_verb_used: str
    keywords_used: List[str]


class BulletImprovementOptionsRequest(BaseModel):
    bullet: str
    role_or_project: Optional[str] = None
    target_domain: Optional[str] = None
    target_job: Optional[str] = None


class BulletImprovementOptionsResponse(BaseModel):
    original_bullet: str
    options: List[BulletImprovementOption]
    missing_metrics_advice: Optional[str] = None


class SummaryImprovementOption(BaseModel):
    style: str  # "ATS-Focused", "Professional Executive", "Concise Impact"
    summary_text: str
    why_better: List[str]


class SummaryImprovementOptionsRequest(BaseModel):
    current_summary: Optional[str] = None
    target_domain: Optional[str] = None
    skills: List[str] = []
    experience_summary: Optional[str] = None


class SummaryImprovementOptionsResponse(BaseModel):
    options: List[SummaryImprovementOption]


class QualityIssueItem(BaseModel):
    id: str
    category: str  # "weak_verbs", "repetition", "overly_long", "missing_metrics", "formatting", "vague_words"
    severity: str  # "high", "medium", "low", "info"
    issue_title: str
    location: str  # e.g., "Experience - Bullet #2"
    snippet: str
    recommendation: str
    suggested_fix: Optional[str] = None


class QualityCheckRequest(BaseModel):
    structured_resume: StructuredResumeData
    target_job_description: Optional[str] = None


class QualityCheckResponse(BaseModel):
    overall_score: float
    total_issues_count: int
    weak_verbs_count: int
    repetition_count: int
    metrics_density_pct: float
    issues: List[QualityIssueItem]


# -------------------------------------------------------------
# JOB-SPECIFIC RESUME TAILORING SCHEMAS
# -------------------------------------------------------------

class JobDescriptionParsedData(BaseModel):
    job_title: str
    company_name: Optional[str] = None
    domain: str = "General Professional"
    seniority: Optional[str] = "Mid-Level"
    required_skills: List[str] = []
    preferred_skills: List[str] = []
    technical_skills: List[str] = []
    soft_skills: List[str] = []
    tools_and_technologies: List[str] = []
    responsibilities: List[str] = []
    qualifications: List[str] = []
    education_requirements: List[str] = []
    experience_requirements: Optional[str] = None
    certifications: List[str] = []
    domain_terminology: List[str] = []
    high_priority_keywords: List[str] = []
    medium_priority_keywords: List[str] = []
    low_priority_keywords: List[str] = []
    action_verbs: List[str] = []
    repeated_phrases: List[str] = []


class JobRequirementMatchItem(BaseModel):
    id: str
    requirement: str
    category: str = "skill"  # skill, responsibility, qualification, tool, education
    status: str = "matched"  # matched, partially_matched, missing, hidden_match
    importance: str = "high"  # high, medium, low
    resume_evidence: Optional[str] = None  # Verbatim quote from resume
    recommendation: Optional[str] = None
    action_note: Optional[str] = None  # e.g. "Add only if you genuinely have this experience"


class TailoredBulletSuggestion(BaseModel):
    id: str
    section: str = "experience"  # experience, projects, portfolio
    item_id: Optional[str] = None
    item_title: Optional[str] = None  # Company name or project title
    bullet_index: int = 0
    original_bullet: str
    tailored_bullet: str
    why_better: str  # Rationale for why this terminology matches target JD while preserving truth
    is_safe: bool = True  # Safe = clarity/phrasing/keyword placement. Requires confirmation = adds fact/metric
    change_type: str = "safe_wording"  # safe_wording, keyword_alignment, structure, requires_confirmation


class TailoredSummarySuggestion(BaseModel):
    original_summary: Optional[str] = None
    tailored_summary: str
    why_better: str
    is_safe: bool = True


class TailoredProjectSuggestion(BaseModel):
    id: str
    project_id: Optional[str] = None
    original_title: str
    tailored_title: Optional[str] = None
    original_bullets: List[str] = []
    tailored_bullets: List[str] = []
    why_better: str
    is_safe: bool = True


class JobTailoringAnalysisResponse(BaseModel):
    job_parsed: JobDescriptionParsedData
    target_job_title: str
    company_name: Optional[str] = None
    overall_match_score: float  # e.g. 84.0%
    original_ats_score: float
    tailored_ats_score: float
    score_breakdown_before: Dict[str, float] = Field(default_factory=dict)
    score_breakdown_after: Dict[str, float] = Field(default_factory=dict)
    matched_count: int
    partially_matched_count: int
    missing_count: int
    requirement_matches: List[JobRequirementMatchItem] = []
    hidden_matches: List[JobRequirementMatchItem] = []
    missing_skills: List[JobRequirementMatchItem] = []
    prioritized_keywords: Dict[str, List[str]] = Field(default_factory=dict)  # high, medium, missing
    recommended_actions: List[str] = []
    added_skills: List[str] = []
    added_keywords: List[str] = []
    tailored_headline: Optional[str] = None
    tailored_summary: Optional[TailoredSummarySuggestion] = None
    tailored_skills_order: List[str] = []
    tailored_experience_bullets: List[TailoredBulletSuggestion] = []
    tailored_projects: List[TailoredProjectSuggestion] = []
    tailored_structured_resume: StructuredResumeData
    created_at: datetime



class JobTailoringRequest(BaseModel):
    document_id: Optional[str] = None
    job_description: str
    structured_resume: Optional[StructuredResumeData] = None


class JobAnalysisHistoryItem(BaseModel):
    id: str
    document_id: str
    job_title: str
    company_name: Optional[str] = None
    match_score: float
    created_at: datetime
    job_description_snippet: str
    tailored_version_id: Optional[str] = None


class SaveTailoredVersionRequest(BaseModel):
    version_name: str
    target_job: str
    company_name: Optional[str] = None
    structured_resume: StructuredResumeData
    job_description: Optional[str] = None
    ats_score: Optional[float] = 85.0


# =========================================================================
# READ & LEARN MY RESUME SCHEMAS (Truthful Ground-Truth Learning Engine)
# =========================================================================

class ResumeLearningSkillItem(BaseModel):
    skill_name: str
    what_it_is: str
    what_it_is_used_for: str
    what_it_means_on_resume: str
    what_you_should_know: List[str] = []
    how_to_explain_it: str
    beginner_explanation: str
    deeper_explanation: str
    is_reviewed: bool = False


class ResumeLearningProjectItem(BaseModel):
    project_name: str
    what_you_wrote: str
    project_explanation: str
    technologies_mentioned: List[str] = []
    concepts_to_understand: List[str] = []
    your_contribution: str
    what_you_should_know: List[str] = []
    beginner_explanation: str
    deeper_explanation: str
    is_reviewed: bool = False


class ResumeLearningExperienceItem(BaseModel):
    role: str
    company: str
    dates: Optional[str] = None
    description: str
    is_internship: bool = False
    what_you_claimed: str
    skills_demonstrated: List[str] = []
    important_terminology: List[Dict[str, str]] = []  # term, definition
    what_you_should_understand: List[str] = []
    beginner_explanation: str
    deeper_explanation: str
    is_reviewed: bool = False


class ResumeLearningEducationItem(BaseModel):
    degree: str
    institution: str
    dates_or_grade: Optional[str] = None
    relevant_coursework: List[str] = []
    academic_achievements: List[str] = []
    what_it_demonstrates: str
    key_concepts: List[str] = []
    is_reviewed: bool = False


class ResumeLearningCertificationItem(BaseModel):
    name: str
    issuer: Optional[str] = None
    what_it_represents: str
    knowledge_covered: List[str] = []
    important_concepts: List[str] = []
    what_you_should_understand: str
    is_reviewed: bool = False


class ResumeLearningClaimItem(BaseModel):
    id: str
    claim_text: str
    source_section: str  # e.g., "Experience", "Projects", "Summary"
    what_you_should_understand: List[str] = []
    is_reviewed: bool = False


class ResumeLearningSectionSummary(BaseModel):
    id: str  # summary, skills, experience, internship, projects, education, certifications, claims
    title: str
    total_items: int
    reviewed_items: int = 0
    is_present: bool = True


class ResumeLearningGuideResponse(BaseModel):
    candidate_name: Optional[str] = None
    detected_domain: str
    headline: Optional[str] = None
    summary_section: Optional[Dict[str, Any]] = None
    skills: List[ResumeLearningSkillItem] = []
    projects: List[ResumeLearningProjectItem] = []
    experience: List[ResumeLearningExperienceItem] = []
    internships: List[ResumeLearningExperienceItem] = []
    education: List[ResumeLearningEducationItem] = []
    certifications: List[ResumeLearningCertificationItem] = []
    claims: List[ResumeLearningClaimItem] = []
    sections: List[ResumeLearningSectionSummary] = []
    overall_progress_pct: float = 0.0


class CreateResumeScratchRequest(BaseModel):
    title: Optional[str] = "My_Custom_Resume.pdf"
    structured_resume: StructuredResumeData
    target_job_description: Optional[str] = None


class SyncResumeRequest(BaseModel):
    structured_resume: StructuredResumeData
    target_job_description: Optional[str] = None
    target_job_title: Optional[str] = None

