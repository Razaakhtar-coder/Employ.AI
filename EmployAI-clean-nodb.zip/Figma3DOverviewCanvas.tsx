import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useHologramTheme } from '../context/HologramThemeContext';
import { 
  Scan, Orbit, FileText, Target, Compass, 
  Briefcase, BookMarked, Play,
  ExternalLink, Volume2,
  ZoomIn, ZoomOut, Zap, ChevronDown, ChevronUp, Sparkles
} from 'lucide-react';

interface Figma3DOverviewCanvasProps {
  onNavigate: (tab: string) => void;
  onNavigateToRoadmap?: (roleTitleOrId?: string, domain?: string) => void;
}

interface SectionFrame {
  id: string;
  tabId: string;
  frameNumber: string;
  dimensions: string;
  title: string;
  category: 'core_ai' | 'visual_3d' | 'career';
  categoryLabel: string;
  badge: string;
  badgeColor: string;
  description: string;
  stats: { label: string; value: string }[];
  accentColor: string;
  lightAccentColor: string;
  gradient: string;
  lightGradient: string;
  journeyStep: string;
}

const SECTION_FRAMES: SectionFrame[] = [
  {
    id: 'interview',
    tabId: 'interview',
    frameNumber: '#Frame 01',
    dimensions: '1920 × 1080',
    title: 'AI Mock Interview & STAR Voice Studio',
    category: 'core_ai',
    categoryLabel: 'Core Voice AI',
    badge: 'Real-time Defense',
    badgeColor: '#38bdf8',
    description: 'Ground-truth interview defense simulator testing project claims, technical depth, and STAR behavioral rubrics with real-time voice latency scoring and feedback.',
    stats: [
      { label: 'STAR Rubric', value: '4 Pillars' },
      { label: 'Voice Latency', value: '<250ms' },
      { label: 'ATS Grounding', value: '100%' }
    ],
    accentColor: '#38bdf8',
    lightAccentColor: '#0284c7',
    gradient: 'linear-gradient(135deg, rgba(56, 189, 248, 0.16) 0%, rgba(168, 85, 247, 0.1) 100%)',
    lightGradient: 'linear-gradient(135deg, #ffffff 0%, #f0f9ff 60%, #faf5ff 100%)',
    journeyStep: 'Stage 5 • Final Placement Readiness'
  },
  {
    id: 'scanner3d',
    tabId: 'scanner3d',
    frameNumber: '#Frame 02',
    dimensions: '1920 × 1080',
    title: '3D Hologram Resume Scanner & Laser Stage',
    category: 'visual_3d',
    categoryLabel: '3D Volumetric',
    badge: 'Volumetric Laser',
    badgeColor: '#00f2fe',
    description: 'Volumetric cybernetic scanner passing dual holographic laser beams across candidate resumes with real-time AST node mesh generation and atmospheric lighting themes.',
    stats: [
      { label: 'Visual Depth', value: '3D Laser' },
      { label: 'Themes', value: '5 Palettes' },
      { label: 'Sweep Rate', value: '60 FPS' }
    ],
    accentColor: '#00f2fe',
    lightAccentColor: '#0284c7',
    gradient: 'linear-gradient(135deg, rgba(0, 242, 254, 0.16) 0%, rgba(59, 130, 246, 0.12) 100%)',
    lightGradient: 'linear-gradient(135deg, #ffffff 0%, #ecfeff 60%, #eff6ff 100%)',
    journeyStep: 'Stage 1 • Deep Profile Ingestion'
  },
  {
    id: 'galaxy',
    tabId: 'galaxy',
    frameNumber: '#Frame 03',
    dimensions: '2560 × 1440',
    title: '3D Interactive Skill Galaxy',
    category: 'visual_3d',
    categoryLabel: 'Cosmic WebGL',
    badge: 'Orbital Constellation',
    badgeColor: '#a855f7',
    description: 'Explore your engineering skills in a dynamic 3D celestial particle universe with gravitational role clusters, branch links, and role requirement alignments.',
    stats: [
      { label: 'Particles', value: '2500+ Nodes' },
      { label: 'Skill Clusters', value: '12 Domains' },
      { label: '3D Physics', value: 'Dynamic' }
    ],
    accentColor: '#a855f7',
    lightAccentColor: '#7c3aed',
    gradient: 'linear-gradient(135deg, rgba(168, 85, 247, 0.18) 0%, rgba(236, 72, 153, 0.1) 100%)',
    lightGradient: 'linear-gradient(135deg, #ffffff 0%, #faf5ff 60%, #fdf2f8 100%)',
    journeyStep: 'Stage 2 • 3D Skill Graph Exploration'
  },
  {
    id: 'resume',
    tabId: 'resume',
    frameNumber: '#Frame 04',
    dimensions: '1440 × 900',
    title: 'AI Resume Studio & 10-Template ATS Engine',
    category: 'core_ai',
    categoryLabel: 'Core ATS Engine',
    badge: '10 Styled Templates',
    badgeColor: '#10b981',
    description: 'Live AST resume parser with 10 industry templates (Emerald, Tokyo, Lavender), keyword density optimization, multi-domain AST re-scoring, and bullet auto-enhancer.',
    stats: [
      { label: 'ATS Score', value: 'Live 0-100' },
      { label: 'Templates', value: '10 Modern' },
      { label: 'Export Formats', value: 'PDF & TXT' }
    ],
    accentColor: '#10b981',
    lightAccentColor: '#059669',
    gradient: 'linear-gradient(135deg, rgba(16, 185, 129, 0.16) 0%, rgba(56, 189, 248, 0.1) 100%)',
    lightGradient: 'linear-gradient(135deg, #ffffff 0%, #f0fdf4 60%, #f0f9ff 100%)',
    journeyStep: 'Stage 1 • Resume Optimization'
  },
  {
    id: 'matching',
    tabId: 'matching',
    frameNumber: '#Frame 05',
    dimensions: '1920 × 1080',
    title: 'Explainable AI Role Matcher',
    category: 'career',
    categoryLabel: 'Explainable AI',
    badge: 'Transparent Gaps',
    badgeColor: '#f59e0b',
    description: 'Deep NLP matching algorithm that explains why you match a role, highlights missing critical dependencies, and computes placement fit with honest justification.',
    stats: [
      { label: 'Match Precision', value: 'Cosine + AST' },
      { label: 'Role Taxonomy', value: '50+ Careers' },
      { label: 'Explainability', value: 'Line-by-line' }
    ],
    accentColor: '#f59e0b',
    lightAccentColor: '#d97706',
    gradient: 'linear-gradient(135deg, rgba(245, 158, 11, 0.16) 0%, rgba(239, 68, 68, 0.1) 100%)',
    lightGradient: 'linear-gradient(135deg, #ffffff 0%, #fffbeb 60%, #fef2f2 100%)',
    journeyStep: 'Stage 3 • Target Role Alignment'
  },
  {
    id: 'roadmap',
    tabId: 'roadmap',
    frameNumber: '#Frame 06',
    dimensions: '1920 × 1080',
    title: 'Placement Level Roadmap (5 Sprints)',
    category: 'career',
    categoryLabel: 'Adaptive Curriculum',
    badge: '5-Phase Sprints',
    badgeColor: '#34d399',
    description: 'Tailored milestone roadmap bridging candidate skill gaps over 5 progressive sprints from academic theory directly to placement offer.',
    stats: [
      { label: 'Milestones', value: '5 Sprints' },
      { label: 'Tasks', value: 'Self-Paced' },
      { label: 'Readiness', value: 'Placement Ready' }
    ],
    accentColor: '#34d399',
    lightAccentColor: '#059669',
    gradient: 'linear-gradient(135deg, rgba(52, 211, 153, 0.16) 0%, rgba(56, 189, 248, 0.1) 100%)',
    lightGradient: 'linear-gradient(135deg, #ffffff 0%, #ecfdf5 60%, #f0f9ff 100%)',
    journeyStep: 'Stage 4 • Gap Bridging'
  },
  {
    id: 'opportunities',
    tabId: 'opportunities',
    frameNumber: '#Frame 07',
    dimensions: '1440 × 900',
    title: 'Opportunities & Live Placement Radar',
    category: 'career',
    categoryLabel: 'Live Aggregate Feed',
    badge: 'Live Job Radar',
    badgeColor: '#ec4899',
    description: 'Live job radar scraping vetted technical roles, campus internships, and matching them in real time with your resume qualifications.',
    stats: [
      { label: 'Aggregated Jobs', value: 'Active Feed' },
      { label: 'Fit Filter', value: 'Instant Match' },
      { label: 'Direct Apply', value: '1-Click' }
    ],
    accentColor: '#ec4899',
    lightAccentColor: '#db2777',
    gradient: 'linear-gradient(135deg, rgba(236, 72, 153, 0.16) 0%, rgba(168, 85, 247, 0.1) 100%)',
    lightGradient: 'linear-gradient(135deg, #ffffff 0%, #fdf2f8 60%, #faf5ff 100%)',
    journeyStep: 'Stage 5 • Direct Placement'
  },
  {
    id: 'resume_learning',
    tabId: 'resume_learning',
    frameNumber: '#Frame 08',
    dimensions: '1920 × 1080',
    title: 'Read & Learn Ground-Truth Resume Studio',
    category: 'core_ai',
    categoryLabel: 'Ground-Truth Prep',
    badge: 'Architecture Study',
    badgeColor: '#6366f1',
    description: 'Comprehensive study module explaining every project claim, database choice, algorithm, and metrics on your resume for interview scrutiny.',
    stats: [
      { label: 'Project Deep-Dive', value: 'Full Stack' },
      { label: 'Claim Audit', value: 'Zero Fluff' },
      { label: 'Talking Points', value: 'Generated' }
    ],
    accentColor: '#6366f1',
    lightAccentColor: '#4f46e5',
    gradient: 'linear-gradient(135deg, rgba(99, 102, 241, 0.18) 0%, rgba(56, 189, 248, 0.1) 100%)',
    lightGradient: 'linear-gradient(135deg, #ffffff 0%, #eef2ff 60%, #f0f9ff 100%)',
    journeyStep: 'Stage 4 • Technical Defense Prep'
  }
];

const Figma3DOverviewCanvasComponent: React.FC<Figma3DOverviewCanvasProps> = ({
  onNavigate,
  onNavigateToRoadmap
}) => {
  const { mode } = useHologramTheme();
  const isLight = mode === 'light';

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [activeFrameIndex, setActiveFrameIndex] = useState<number>(0);

  // Filtered frames with useMemo
  const filteredFrames = useMemo(() => {
    if (activeCategory === 'all') return SECTION_FRAMES;
    return SECTION_FRAMES.filter(frame => frame.category === activeCategory);
  }, [activeCategory]);

  // High-performance single IntersectionObserver for active section detection & direct DOM class toggle
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        let bestIdx: number | null = null;
        let maxRatio = 0;

        entries.forEach((entry) => {
          const target = entry.target as HTMLElement;
          if (entry.isIntersecting) {
            target.classList.add('is-in-view');
            if (entry.intersectionRatio > maxRatio) {
              maxRatio = entry.intersectionRatio;
              const idxStr = target.getAttribute('data-frame-index');
              if (idxStr !== null) {
                const parsed = parseInt(idxStr, 10);
                if (!isNaN(parsed)) bestIdx = parsed;
              }
            }
          } else {
            target.classList.remove('is-in-view');
          }
        });

        if (bestIdx !== null) {
          const targetIdx = bestIdx;
          setActiveFrameIndex(prev => (prev === targetIdx ? prev : targetIdx));
        }
      },
      {
        threshold: [0.2, 0.5],
        rootMargin: '-5% 0px -15% 0px'
      }
    );

    const cards = document.querySelectorAll('.figma-rectangular-frame');
    cards.forEach(card => observer.observe(card));

    return () => observer.disconnect();
  }, [filteredFrames]);

  // Stable single callback passed to all cards (zero re-render churn on activeFrameIndex change)
  const handleLaunchTab = useCallback((tabId: string) => {
    if (tabId === 'roadmap' && onNavigateToRoadmap) {
      onNavigateToRoadmap();
    } else {
      onNavigate(tabId);
    }
  }, [onNavigate, onNavigateToRoadmap]);

  // Scroll to specific section frame
  const scrollToFrame = useCallback((index: number) => {
    setActiveFrameIndex(index);
    const target = document.getElementById(`figma-frame-${filteredFrames[index]?.id}`);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [filteredFrames]);

  const handleNextSection = useCallback(() => {
    if (activeFrameIndex < filteredFrames.length - 1) {
      scrollToFrame(activeFrameIndex + 1);
    }
  }, [activeFrameIndex, filteredFrames.length, scrollToFrame]);

  const handlePrevSection = useCallback(() => {
    if (activeFrameIndex > 0) {
      scrollToFrame(activeFrameIndex - 1);
    }
  }, [activeFrameIndex, scrollToFrame]);

  return (
    <div className="figma-3d-workspace-container" style={{
      position: 'relative',
      borderRadius: '20px',
      border: isLight ? '1.5px solid rgba(2, 132, 199, 0.25)' : '1.5px solid rgba(56, 189, 248, 0.25)',
      background: isLight 
        ? 'radial-gradient(ellipse at top, #f8fafc 0%, #f1f5f9 60%, #e2e8f0 100%)' 
        : 'radial-gradient(ellipse at top, #0f172a 0%, #030712 100%)',
      boxShadow: isLight 
        ? '0 12px 40px rgba(15, 23, 42, 0.06), inset 0 0 40px rgba(2, 132, 199, 0.04)' 
        : '0 20px 50px rgba(0, 0, 0, 0.6), inset 0 0 40px rgba(56, 189, 248, 0.05)',
      overflow: 'hidden',
      marginBottom: '2rem',
      padding: '1.5rem',
      width: '100%',
      boxSizing: 'border-box'
    }}>
      {/* Figma Canvas Background Dot-Grid */}
      <div 
        className="figma-canvas-dotgrid" 
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundImage: isLight 
            ? 'radial-gradient(circle, rgba(2, 132, 199, 0.16) 1px, transparent 1px)' 
            : 'radial-gradient(circle, rgba(56, 189, 248, 0.14) 1px, transparent 1px)',
          backgroundSize: '24px 24px',
          opacity: isLight ? 0.9 : 0.8,
          pointerEvents: 'none',
          zIndex: 1
        }} 
      />

      {/* TOP FIGMA CANVAS TOOLBAR */}
      <div 
        className="figma-canvas-toolbar"
        style={{
          position: 'sticky',
          top: '72px',
          zIndex: 30,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '0.85rem',
          padding: '0.85rem 1.35rem',
          borderRadius: '14px',
          background: isLight ? 'rgba(255, 255, 255, 0.97)' : 'rgba(11, 19, 43, 0.95)',
          backdropFilter: 'blur(8px)',
          WebkitBackdropFilter: 'blur(8px)',
          border: isLight ? '1px solid rgba(2, 132, 199, 0.25)' : '1px solid rgba(56, 189, 248, 0.3)',
          boxShadow: isLight ? '0 10px 30px rgba(15, 23, 42, 0.08)' : '0 10px 32px rgba(0, 0, 0, 0.6)',
          marginBottom: '1.5rem'
        }}
      >
        {/* Left: Employ.AI Value Proposition & Ecosystem Vision */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '42px',
            height: '42px',
            borderRadius: '12px',
            background: isLight
              ? 'linear-gradient(135deg, #0284c7 0%, #2563eb 50%, #7c3aed 100%)'
              : 'linear-gradient(135deg, #00f2fe 0%, #38bdf8 50%, #a855f7 100%)',
            boxShadow: isLight ? '0 4px 14px rgba(2, 132, 199, 0.35)' : '0 0 20px rgba(56, 189, 248, 0.6)',
            color: '#ffffff',
            fontWeight: 900,
            flexShrink: 0
          }}>
            <Sparkles size={22} />
          </div>

          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
              <span style={{ fontSize: '1.025rem', fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.01em' }}>
                Employ.AI — Your Intelligent Bridge from Campus to Dream Career
              </span>
              <span className="badge badge-emerald" style={{ fontSize: '0.65rem', padding: '0.15rem 0.55rem', fontWeight: 800 }}>
                🚀 10x Placement Readiness
              </span>
            </div>
            <p style={{ fontSize: '0.78rem', color: isLight ? '#334155' : 'var(--text-secondary)', margin: '0.2rem 0 0 0', lineHeight: 1.4 }}>
              Empowering candidates to ace technical interviews, master ATS resumes with 10 modern templates, and bridge every skill gap with 3D career intelligence.
            </p>
          </div>
        </div>

        {/* Center: Live Frame Stepper & Quick Jump Controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.4rem',
            padding: '0.3rem 0.75rem',
            borderRadius: '20px',
            background: isLight ? 'rgba(2, 132, 199, 0.08)' : 'rgba(56, 189, 248, 0.12)',
            border: isLight ? '1px solid rgba(2, 132, 199, 0.25)' : '1px solid rgba(56, 189, 248, 0.3)'
          }}>
            <span style={{ width: '7px', height: '7px', borderRadius: '50%', background: isLight ? '#0284c7' : '#38bdf8', boxShadow: isLight ? '0 0 6px #0284c7' : '0 0 6px #38bdf8' }} />
            <span style={{ fontSize: '0.75rem', fontWeight: 800, color: isLight ? '#0284c7' : '#38bdf8' }}>
              Section {activeFrameIndex + 1} of {filteredFrames.length}
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
            <button
              onClick={handlePrevSection}
              disabled={activeFrameIndex === 0}
              className="btn btn-secondary btn-sm"
              style={{
                padding: '0.3rem 0.55rem',
                opacity: activeFrameIndex === 0 ? 0.4 : 1,
                cursor: activeFrameIndex === 0 ? 'not-allowed' : 'pointer'
              }}
              title="Previous 3D Section"
            >
              <ChevronUp size={14} />
            </button>
            <button
              onClick={handleNextSection}
              disabled={activeFrameIndex === filteredFrames.length - 1}
              className="btn btn-secondary btn-sm"
              style={{
                padding: '0.3rem 0.55rem',
                opacity: activeFrameIndex === filteredFrames.length - 1 ? 0.4 : 1,
                cursor: activeFrameIndex === filteredFrames.length - 1 ? 'not-allowed' : 'pointer'
              }}
              title="Next 3D Section (Scroll Down)"
            >
              <ChevronDown size={14} />
            </button>
          </div>
        </div>

        {/* Right: Zoom controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }} className="header-hide-mobile">
          <button
            onClick={() => setZoomLevel(prev => Math.max(75, prev - 10))}
            className="btn btn-secondary btn-sm"
            style={{ padding: '0.3rem 0.5rem' }}
            title="Zoom Out"
          >
            <ZoomOut size={13} />
          </button>
          <span style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--text-muted)', minWidth: '40px', textAlign: 'center' }}>
            {zoomLevel}%
          </span>
          <button
            onClick={() => setZoomLevel(prev => Math.min(125, prev + 10))}
            className="btn btn-secondary btn-sm"
            style={{ padding: '0.3rem 0.5rem' }}
            title="Zoom In"
          >
            <ZoomIn size={13} />
          </button>
        </div>
      </div>

      {/* CATEGORY FILTER TABS (FIGMA PILL STYLE) */}
      <div style={{
        position: 'relative',
        zIndex: 10,
        display: 'flex',
        alignItems: 'center',
        gap: '0.5rem',
        overflowX: 'auto',
        paddingBottom: '0.5rem',
        marginBottom: '1.5rem',
        scrollbarWidth: 'none'
      }}>
        {[
          { id: 'all', label: 'All 8 Overview Sections' },
          { id: 'core_ai', label: 'Core AI Engines' },
          { id: 'visual_3d', label: '3D Hologram & Galaxy' },
          { id: 'career', label: 'Career, Match & Roadmap' }
        ].map(cat => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            style={{
              padding: '0.45rem 0.95rem',
              borderRadius: '20px',
              fontSize: '0.775rem',
              fontWeight: activeCategory === cat.id ? 700 : 500,
              background: activeCategory === cat.id 
                ? (isLight ? 'rgba(2, 132, 199, 0.12)' : 'rgba(56, 189, 248, 0.18)') 
                : (isLight ? '#ffffff' : 'rgba(255, 255, 255, 0.04)'),
              border: activeCategory === cat.id 
                ? '1.5px solid var(--accent-cyan)' 
                : (isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.08)'),
              color: activeCategory === cat.id 
                ? 'var(--accent-cyan)' 
                : (isLight ? '#334155' : 'var(--text-secondary)'),
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              transition: 'all 0.2s',
              flexShrink: 0,
              boxShadow: isLight && activeCategory === cat.id ? '0 2px 8px rgba(2, 132, 199, 0.12)' : (isLight ? '0 1px 3px rgba(15, 23, 42, 0.04)' : 'none')
            }}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* FULL-WIDTH RECTANGULAR 3D SCROLL STAGE */}
      <div 
        className="figma-fullwidth-scroll-stage"
        style={{
          position: 'relative',
          zIndex: 5,
          display: 'flex',
          flexDirection: 'column',
          gap: '2.5rem',
          width: '100%',
          transform: `scale(${zoomLevel / 100})`,
          transformOrigin: 'top center',
          transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
        }}
      >
        {filteredFrames.map((frame, index) => (
          <FullWidthFigmaFrameCard
            key={frame.id}
            frame={frame}
            index={index}
            totalFrames={filteredFrames.length}
            isLight={isLight}
            onLaunch={handleLaunchTab}
          />
        ))}
      </div>

      {/* Figma Flow Connector Status Bar at Bottom */}
      <div style={{
        position: 'relative',
        zIndex: 10,
        marginTop: '2rem',
        padding: '1rem 1.5rem',
        borderRadius: '14px',
        background: isLight ? 'rgba(255, 255, 255, 0.95)' : 'rgba(15, 23, 42, 0.85)',
        border: isLight ? '1px solid rgba(2, 132, 199, 0.25)' : '1px solid rgba(56, 189, 248, 0.25)',
        boxShadow: isLight ? '0 8px 24px rgba(15, 23, 42, 0.06)' : 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '1rem'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <Zap size={18} color="var(--accent-cyan)" />
          <span style={{ fontSize: '0.825rem', fontWeight: 700, color: 'var(--text-primary)' }}>
            Complete 3D Architecture Workflow:
          </span>
          <span style={{ fontSize: '0.775rem', color: isLight ? '#475569' : 'var(--text-muted)' }}>
            1. Ingestion ➔ 2. 3D Laser Scan ➔ 3. Galaxy Mapping ➔ 4. Explainable Match ➔ 5. 5-Sprint Roadmap ➔ 6. Voice Mock Defense
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <button
            onClick={() => onNavigate('interview')}
            className="btn btn-primary btn-sm"
            style={{ fontSize: '0.78rem', padding: '0.45rem 1rem', fontWeight: 700 }}
          >
            <Play size={13} /> Launch Full System Journey
          </button>
        </div>
      </div>
    </div>
  );
};

export const Figma3DOverviewCanvas = React.memo(Figma3DOverviewCanvasComponent);

/* ==========================================================================
   Full-Width Rectangular 3D Figma Frame Card (Covers Whole Rectangular Length)
   ========================================================================== */
interface FullWidthFigmaFrameCardProps {
  frame: SectionFrame;
  index: number;
  totalFrames: number;
  isLight: boolean;
  onLaunch: (tabId: string) => void;
}

const FullWidthFigmaFrameCardComponent: React.FC<FullWidthFigmaFrameCardProps> = ({
  frame,
  index,
  totalFrames,
  isLight,
  onLaunch
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const shineRef = useRef<HTMLDivElement>(null);
  const rectRef = useRef<DOMRect | null>(null);
  const rafRef = useRef<number | null>(null);

  // Micro-simulation states local to this card only
  const [audioWaveTesting, setAudioWaveTesting] = useState<boolean>(false);
  const [laserScanActive, setLaserScanActive] = useState<boolean>(true);
  const [activeSprintIndex, setActiveSprintIndex] = useState<number>(2);

  // Derive genuine live ATS gauge score from active resume
  const [atsGaugeValue, setAtsGaugeValue] = useState<number | null>(() => {
    try {
      const userStr = localStorage.getItem('employai_auth_user');
      const userId = userStr ? JSON.parse(userStr)?.id : null;
      const key = userId ? `employai_active_resume_analysis_${userId}` : 'employai_active_resume_analysis';
      const raw = localStorage.getItem(key) || localStorage.getItem('employai_active_resume_analysis');
      if (raw) {
        const parsed = JSON.parse(raw);
        const score = parsed.resume_quality_score || parsed.overall_score || 0;
        return score > 0 ? Math.round(score) : null;
      }
    } catch {}
    return null;
  });

  useEffect(() => {
    const handleSync = (e: any) => {
      if (e?.detail) {
        const score = e.detail.resume_quality_score || e.detail.overall_score || 0;
        setAtsGaugeValue(score > 0 ? Math.round(score) : null);
      } else if (e?.detail === null) {
        setAtsGaugeValue(null);
      }
    };
    window.addEventListener('employai:resume-updated', handleSync);
    return () => window.removeEventListener('employai:resume-updated', handleSync);
  }, []);

  // Cached mouseenter measurement + RAF tilt for buttery 60+ FPS interaction without React re-renders
  const handleMouseEnter = () => {
    if (cardRef.current) {
      rectRef.current = cardRef.current.getBoundingClientRect();
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!rectRef.current || !cardRef.current) return;
    const rect = rectRef.current;
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rX = ((y - centerY) / centerY) * -4.5;
    const rY = ((x - centerX) / centerX) * 4.5;
    const sX = (x / rect.width) * 100;
    const sY = (y / rect.height) * 100;

    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(() => {
      if (cardRef.current) {
        cardRef.current.style.transform = `perspective(1000px) rotateX(${rX.toFixed(2)}deg) rotateY(${rY.toFixed(2)}deg)`;
      }
      if (shineRef.current) {
        shineRef.current.style.background = isLight
          ? `radial-gradient(circle at ${sX.toFixed(1)}% ${sY.toFixed(1)}%, rgba(2, 132, 199, 0.08) 0%, transparent 60%)`
          : `radial-gradient(circle at ${sX.toFixed(1)}% ${sY.toFixed(1)}%, rgba(255, 255, 255, 0.12) 0%, transparent 60%)`;
      }
    });
  };

  const handleMouseLeave = () => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rectRef.current = null;
    if (cardRef.current) {
      cardRef.current.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg)';
    }
    if (shineRef.current) {
      shineRef.current.style.background = 'none';
    }
  };

  return (
    <div
      id={`figma-frame-${frame.id}`}
      data-frame-index={index}
      data-frame-id={frame.id}
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className="figma-rectangular-frame"
      style={{
        position: 'relative',
        width: '100%',
        borderRadius: '18px',
        background: isLight ? frame.lightGradient : frame.gradient,
        border: isLight ? '1.5px solid rgba(2, 132, 199, 0.25)' : '1.5px solid rgba(56, 189, 248, 0.25)',
        padding: '1.75rem',
        boxSizing: 'border-box',
        transform: 'perspective(1000px) rotateX(0deg) rotateY(0deg)',
        transition: 'transform 0.2s ease-out, box-shadow 0.25s ease, border-color 0.25s ease',
        boxShadow: isLight 
          ? '0 8px 24px rgba(15, 23, 42, 0.05)' 
          : '0 12px 36px rgba(0, 0, 0, 0.5)',
        display: 'flex',
        flexDirection: 'column',
        gap: '1.25rem'
      }}
    >
      {/* 3D Specular Shine overlay */}
      <div 
        ref={shineRef}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          borderRadius: '18px',
          background: 'none',
          pointerEvents: 'none',
          zIndex: 20
        }}
      />

      {/* Figma Selection Handles */}
      <div className="figma-handle" style={{ position: 'absolute', top: '-5px', left: '-5px', width: '10px', height: '10px', background: isLight ? '#0284c7' : '#38bdf8', border: isLight ? '1.5px solid #ffffff' : '1.5px solid #030712', borderRadius: '2px', zIndex: 30 }} />
      <div className="figma-handle" style={{ position: 'absolute', top: '-5px', right: '-5px', width: '10px', height: '10px', background: isLight ? '#0284c7' : '#38bdf8', border: isLight ? '1.5px solid #ffffff' : '1.5px solid #030712', borderRadius: '2px', zIndex: 30 }} />
      <div className="figma-handle" style={{ position: 'absolute', bottom: '-5px', left: '-5px', width: '10px', height: '10px', background: isLight ? '#0284c7' : '#38bdf8', border: isLight ? '1.5px solid #ffffff' : '1.5px solid #030712', borderRadius: '2px', zIndex: 30 }} />
      <div className="figma-handle" style={{ position: 'absolute', bottom: '-5px', right: '-5px', width: '10px', height: '10px', background: isLight ? '#0284c7' : '#38bdf8', border: isLight ? '1.5px solid #ffffff' : '1.5px solid #030712', borderRadius: '2px', zIndex: 30 }} />

      {/* TOP FIGMA FRAME BAR (Spans whole rectangular length) */}
      <div style={{
        transform: 'translateZ(20px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '0.75rem',
        paddingBottom: '0.85rem',
        borderBottom: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.1)'
      }}>
        {/* Left: Frame Tag + Dimensions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <span style={{ 
            fontSize: '0.75rem', 
            fontWeight: 900, 
            color: isLight ? frame.lightAccentColor : frame.accentColor,
            background: isLight ? '#ffffff' : 'rgba(0, 0, 0, 0.5)',
            padding: '0.2rem 0.6rem',
            borderRadius: '6px',
            border: `1px solid ${(isLight ? frame.lightAccentColor : frame.accentColor)}55`,
            boxShadow: isLight ? '0 1px 4px rgba(15, 23, 42, 0.06)' : 'none',
            letterSpacing: '0.04em'
          }}>
            {frame.frameNumber}
          </span>

          <span style={{ fontSize: '0.72rem', color: isLight ? '#334155' : 'var(--text-secondary)', fontWeight: 600 }}>
            {frame.categoryLabel}
          </span>
        </div>

        {/* Center: Frame Sequence Progress Indicator */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <span style={{ fontSize: '0.72rem', color: isLight ? '#475569' : 'var(--text-muted)' }}>
            Section {index + 1} of {totalFrames}
          </span>
          <span className="badge" style={{
            fontSize: '0.65rem',
            padding: '0.2rem 0.6rem',
            background: `${(isLight ? frame.lightAccentColor : frame.accentColor)}18`,
            color: isLight ? frame.lightAccentColor : frame.accentColor,
            border: `1px solid ${(isLight ? frame.lightAccentColor : frame.accentColor)}55`,
            fontWeight: 800
          }}>
            {frame.badge}
          </span>
        </div>
      </div>

      {/* WIDESCREEN 2-COLUMN BODY (Left: Details & Actions | Right: Rich 3D Live Simulation) */}
      <div 
        className="figma-widescreen-body"
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1.25fr',
          gap: '2rem',
          alignItems: 'center',
          transform: 'translateZ(25px)'
        }}
      >
        {/* LEFT COLUMN: Section Information, Architecture Purpose & Launch */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.4rem' }}>
              <span className="badge badge-cyan" style={{ fontSize: '0.65rem', textTransform: 'uppercase' }}>
                {frame.journeyStep}
              </span>
            </div>
            <h3 style={{ 
              fontSize: '1.35rem', 
              fontWeight: 800, 
              color: 'var(--text-primary)', 
              margin: '0 0 0.5rem 0',
              lineHeight: 1.3
            }}>
              {frame.title}
            </h3>
            <p style={{ 
              fontSize: '0.85rem', 
              color: isLight ? '#334155' : 'var(--text-secondary)', 
              margin: 0,
              lineHeight: 1.6
            }}>
              {frame.description}
            </p>
          </div>

          {/* Key Metrics Chips */}
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(3, 1fr)', 
            gap: '0.65rem'
          }}>
            {frame.stats.map((s, i) => (
              <div 
                key={i} 
                style={{ 
                  padding: '0.55rem 0.65rem', 
                  borderRadius: '8px', 
                  background: isLight ? '#ffffff' : 'rgba(255, 255, 255, 0.04)', 
                  border: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.08)',
                  boxShadow: isLight ? '0 2px 6px rgba(15, 23, 42, 0.04)' : 'none',
                  textAlign: 'center'
                }}
              >
                <div style={{ fontSize: '0.675rem', color: isLight ? '#64748b' : 'var(--text-muted)' }}>{s.label}</div>
                <div style={{ fontSize: '0.875rem', fontWeight: 800, color: 'var(--text-primary)', marginTop: '2px' }}>{s.value}</div>
              </div>
            ))}
          </div>

          {/* Action Button: Launch Full Section */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem', marginTop: '0.25rem' }}>
            <button
              onClick={() => onLaunch(frame.tabId)}
              className="btn"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.55rem',
                padding: '0.65rem 1.35rem',
                borderRadius: '10px',
                background: isLight ? frame.lightAccentColor : frame.accentColor,
                color: '#ffffff',
                border: 'none',
                fontWeight: 800,
                fontSize: '0.85rem',
                cursor: 'pointer',
                boxShadow: isLight 
                  ? `0 4px 14px ${(frame.lightAccentColor || frame.accentColor)}44` 
                  : `0 0 20px ${frame.accentColor}66`,
                transition: 'all 0.2s ease'
              }}
            >
              <span>Launch {frame.title.split('&')[0].trim()}</span>
              <ExternalLink size={15} />
            </button>
            <span style={{ fontSize: '0.725rem', color: isLight ? '#64748b' : 'var(--text-muted)' }}>
              Opens dedicated full-screen module
            </span>
          </div>
        </div>

        {/* RIGHT COLUMN: RICH 3D LIVE WORKING SIMULATION WIDGET */}
        <div 
          style={{ 
            borderRadius: '14px',
            background: isLight ? '#ffffff' : 'rgba(3, 7, 18, 0.85)',
            border: `1.5px solid ${(isLight ? frame.lightAccentColor : frame.accentColor)}33`,
            padding: '1.35rem',
            boxShadow: isLight 
              ? '0 8px 30px rgba(15, 23, 42, 0.06), inset 0 0 20px rgba(0, 0, 0, 0.02)' 
              : 'inset 0 0 30px rgba(0, 0, 0, 0.8), 0 10px 30px rgba(0, 0, 0, 0.5)',
            transform: 'translateZ(30px)'
          }}
        >
          {/* Section 1: AI Mock Interview Live Studio */}
          {frame.id === 'interview' && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Volume2 size={16} color="var(--accent-cyan)" />
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                    Live Audio Waveform & STAR Defense Coach
                  </span>
                </div>
                <button 
                  onClick={() => setAudioWaveTesting(prev => !prev)}
                  style={{
                    fontSize: '0.7rem',
                    padding: '0.3rem 0.75rem',
                    borderRadius: '6px',
                    background: audioWaveTesting ? (isLight ? '#0284c7' : 'var(--accent-cyan)') : (isLight ? '#f1f5f9' : 'rgba(255,255,255,0.08)'),
                    color: audioWaveTesting ? '#ffffff' : (isLight ? '#334155' : 'var(--text-secondary)'),
                    border: isLight ? '1px solid #cbd5e1' : '1px solid rgba(56, 189, 248, 0.4)',
                    cursor: 'pointer',
                    fontWeight: 800,
                    transition: 'all 0.2s'
                  }}
                >
                  {audioWaveTesting ? '● Voice Wave Active' : '▶ Test Voice Defense Pulse'}
                </button>
              </div>

              {/* Pulsing Audio Waveform Bars */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                height: '52px',
                gap: '4px',
                padding: '0.5rem 0.85rem',
                borderRadius: '8px',
                background: isLight ? '#f8fafc' : 'rgba(0, 0, 0, 0.4)',
                border: isLight ? '1px solid #e2e8f0' : '1px solid rgba(255, 255, 255, 0.05)',
                marginBottom: '1rem'
              }}>
                {[20, 36, 24, 44, 30, 22, 42, 28, 48, 32, 40, 26, 46, 34, 25, 42, 30, 48, 26, 38].map((h, i) => (
                  <div
                    key={i}
                    style={{
                      flex: 1,
                      height: audioWaveTesting ? `${Math.max(10, (h * (1 + (i % 4) * 0.25)) % 50)}px` : `${h * 0.7}px`,
                      borderRadius: '3px',
                      background: audioWaveTesting 
                        ? (isLight ? 'linear-gradient(to top, #0284c7, #7c3aed)' : 'linear-gradient(to top, #38bdf8, #a855f7)') 
                        : (isLight ? 'rgba(2, 132, 199, 0.35)' : 'rgba(56, 189, 248, 0.4)'),
                      transition: 'height 0.15s ease',
                      boxShadow: audioWaveTesting ? (isLight ? '0 0 8px rgba(2, 132, 199, 0.5)' : '0 0 8px #38bdf8') : 'none'
                    }}
                  />
                ))}
              </div>

              {/* STAR Rubric Breakdown Bars */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0.65rem' }}>
                {[
                  { label: 'Situation', score: 94, color: isLight ? '#0284c7' : '#38bdf8' },
                  { label: 'Task', score: 90, color: isLight ? '#059669' : '#34d399' },
                  { label: 'Action', score: 96, color: isLight ? '#7c3aed' : '#a855f7' },
                  { label: 'Result', score: 92, color: isLight ? '#d97706' : '#f59e0b' }
                ].map(p => (
                  <div key={p.label} style={{ padding: '0.5rem', borderRadius: '6px', background: isLight ? '#f8fafc' : 'rgba(255,255,255,0.03)', border: isLight ? '1px solid #e2e8f0' : 'none' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.675rem', marginBottom: '0.3rem' }}>
                      <span style={{ color: isLight ? '#334155' : 'var(--text-secondary)' }}>{p.label}</span>
                      <span style={{ color: p.color, fontWeight: 800 }}>{p.score}%</span>
                    </div>
                    <div style={{ height: '4px', background: isLight ? '#e2e8f0' : 'rgba(255,255,255,0.08)', borderRadius: '2px', overflow: 'hidden' }}>
                      <div style={{ width: `${p.score}%`, height: '100%', background: p.color }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section 2: 3D Hologram Resume Scanner */}
          {frame.id === 'scanner3d' && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Scan size={16} color={isLight ? '#0284c7' : '#00f2fe'} />
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                    Volumetric Holographic Dual-Beam Laser
                  </span>
                </div>
                <button 
                  onClick={() => setLaserScanActive(prev => !prev)}
                  style={{
                    fontSize: '0.7rem',
                    padding: '0.3rem 0.75rem',
                    borderRadius: '6px',
                    background: laserScanActive 
                      ? (isLight ? 'rgba(2, 132, 199, 0.12)' : 'rgba(0, 242, 254, 0.2)') 
                      : (isLight ? '#f1f5f9' : 'rgba(255, 255, 255, 0.08)'),
                    color: isLight ? '#0284c7' : '#00f2fe',
                    border: isLight ? '1px solid rgba(2, 132, 199, 0.3)' : '1px solid rgba(0, 242, 254, 0.4)',
                    cursor: 'pointer',
                    fontWeight: 800
                  }}
                >
                  {laserScanActive ? '● Laser Beam Active' : '○ Sweep Beam Idle'}
                </button>
              </div>

              <div style={{
                position: 'relative',
                height: '70px',
                borderRadius: '8px',
                background: isLight 
                  ? 'linear-gradient(180deg, rgba(2, 132, 199, 0.08) 0%, #f8fafc 100%)' 
                  : 'linear-gradient(180deg, rgba(0, 242, 254, 0.08) 0%, rgba(3, 7, 18, 0.9) 100%)',
                border: isLight ? '1px dashed rgba(2, 132, 199, 0.4)' : '1px dashed rgba(0, 242, 254, 0.4)',
                overflow: 'hidden',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: '0 1rem'
              }}>
                {laserScanActive && (
                  <div style={{
                    position: 'absolute',
                    top: 0,
                    bottom: 0,
                    left: 0,
                    width: '4px',
                    background: isLight ? '#0284c7' : '#00f2fe',
                    boxShadow: isLight ? '0 0 16px #0284c7, 0 0 32px #0284c7' : '0 0 16px #00f2fe, 0 0 32px #00f2fe',
                    animation: 'laserSweep 2.4s infinite ease-in-out'
                  }} />
                )}
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '2px', zIndex: 2 }}>
                  <span style={{ fontSize: '0.75rem', color: isLight ? '#0284c7' : '#00f2fe', fontFamily: 'monospace', fontWeight: 700 }}>
                    VOLUMETRIC CYBERNETIC AST MESH
                  </span>
                  <span style={{ fontSize: '0.675rem', color: isLight ? '#475569' : 'rgba(255, 255, 255, 0.65)', fontFamily: 'monospace' }}>
                    1,420 tokens parsed • 4 Core Project Clusters Verified
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Section 3: 3D Skill Galaxy */}
          {frame.id === 'galaxy' && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Orbit size={16} color={isLight ? '#7c3aed' : '#a855f7'} />
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                    Cosmic WebGL Particle Constellation
                  </span>
                </div>
                <span style={{ fontSize: '0.72rem', color: isLight ? '#7c3aed' : '#a855f7', fontWeight: 800 }}>
                  Orbital Constellation: Live 3D
                </span>
              </div>

              <div style={{
                position: 'relative',
                height: '74px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '1.5rem',
                borderRadius: '8px',
                background: isLight 
                  ? 'radial-gradient(circle, rgba(124, 58, 237, 0.08) 0%, #f8fafc 100%)' 
                  : 'radial-gradient(circle, rgba(168, 85, 247, 0.1) 0%, rgba(3, 7, 18, 0.8) 100%)',
                border: isLight ? '1px solid rgba(124, 58, 237, 0.25)' : '1px solid rgba(168, 85, 247, 0.3)'
              }}>
                <div style={{
                  width: '54px',
                  height: '54px',
                  borderRadius: '50%',
                  border: isLight ? '1.5px dashed rgba(124, 58, 237, 0.5)' : '1.5px dashed rgba(168, 85, 247, 0.7)',
                  animation: 'galaxyOrbitSpin 10s linear infinite',
                  position: 'relative',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  <div style={{ width: '14px', height: '14px', borderRadius: '50%', background: isLight ? '#7c3aed' : '#a855f7', boxShadow: isLight ? '0 0 10px rgba(124, 58, 237, 0.5)' : '0 0 12px #a855f7' }} />
                  <div style={{ position: 'absolute', top: '-6px', width: '9px', height: '9px', borderRadius: '50%', background: isLight ? '#0284c7' : '#38bdf8', boxShadow: isLight ? '0 0 6px #0284c7' : '0 0 8px #38bdf8' }} />
                  <div style={{ position: 'absolute', bottom: '-6px', width: '9px', height: '9px', borderRadius: '50%', background: isLight ? '#059669' : '#10b981', boxShadow: isLight ? '0 0 6px #059669' : '0 0 8px #10b981' }} />
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <span style={{ fontSize: '0.775rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                    Active Skill Planetary Nodes
                  </span>
                  <span style={{ fontSize: '0.7rem', color: isLight ? '#64748b' : 'var(--text-muted)' }}>
                    React.js • Python • PyTorch • Cloud AWS • PostgreSQL • Docker
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Section 4: AI Resume Studio & ATS Engine */}
          {frame.id === 'resume' && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <FileText size={16} color={isLight ? '#059669' : '#10b981'} />
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                    Live ATS Scoring & 10-Template Optimization
                  </span>
                </div>
                <span style={{ fontSize: '0.75rem', fontWeight: 800, color: atsGaugeValue != null ? (isLight ? '#059669' : '#10b981') : 'var(--text-muted)' }}>
                  ATS Score: {atsGaugeValue != null ? `${atsGaugeValue}/100` : '--/100 (No Resume)'}
                </span>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
                <div style={{
                  width: '60px',
                  height: '60px',
                  borderRadius: '50%',
                  background: atsGaugeValue != null 
                    ? `conic-gradient(${isLight ? '#059669' : '#10b981'} 0% ${atsGaugeValue}%, ${isLight ? '#e2e8f0' : 'rgba(255,255,255,0.08)'} ${atsGaugeValue}% 100%)`
                    : 'rgba(255,255,255,0.03)',
                  border: atsGaugeValue != null ? 'none' : '1.5px dashed rgba(255,255,255,0.2)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: atsGaugeValue != null ? (isLight ? '0 2px 10px rgba(5, 150, 105, 0.25)' : '0 0 16px rgba(16, 185, 129, 0.4)') : 'none',
                  flexShrink: 0
                }}>
                  <div style={{ 
                    width: '46px', 
                    height: '46px', 
                    borderRadius: '50%', 
                    background: isLight ? '#ffffff' : '#030712', 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'center', 
                    fontSize: atsGaugeValue != null ? '1.1rem' : '0.85rem', 
                    fontWeight: 900, 
                    color: atsGaugeValue != null ? (isLight ? '#059669' : '#10b981') : 'var(--text-muted)',
                    boxShadow: isLight ? '0 1px 4px rgba(15, 23, 42, 0.06)' : 'none'
                  }}>
                    {atsGaugeValue != null ? atsGaugeValue : '--'}
                  </div>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <span style={{ fontSize: '0.775rem', color: isLight ? '#047857' : '#34d399', fontWeight: 700 }}>
                    ✔ Emerald Forest, Tokyo Minimal & Lavender Compliant
                  </span>
                  <span style={{ fontSize: '0.72rem', color: isLight ? '#64748b' : 'var(--text-muted)' }}>
                    ✔ Multi-domain keyword density parsed with zero layout parsing errors
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Section 5: Explainable AI Role Matcher */}
          {frame.id === 'matching' && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Target size={16} color={isLight ? '#d97706' : '#f59e0b'} />
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                    Explainable Match Narrative & Gap Matrix
                  </span>
                </div>
                <span style={{ fontSize: '0.75rem', fontWeight: 800, color: isLight ? '#d97706' : '#f59e0b' }}>
                  88% Role Fit
                </span>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', color: isLight ? '#334155' : 'var(--text-secondary)', marginBottom: '2px' }}>
                    <span>Core Engineering & Backend</span>
                    <span style={{ color: isLight ? '#d97706' : '#f59e0b', fontWeight: 700 }}>92% Alignment</span>
                  </div>
                  <div style={{ height: '6px', background: isLight ? '#e2e8f0' : 'rgba(255,255,255,0.08)', borderRadius: '3px', overflow: 'hidden' }}>
                    <div style={{ width: '92%', height: '100%', background: 'linear-gradient(90deg, #f59e0b, #ef4444)' }} />
                  </div>
                </div>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', color: isLight ? '#334155' : 'var(--text-secondary)', marginBottom: '2px' }}>
                    <span>Distributed Systems Architecture</span>
                    <span style={{ color: isLight ? '#059669' : '#34d399', fontWeight: 700 }}>84% Alignment</span>
                  </div>
                  <div style={{ height: '6px', background: isLight ? '#e2e8f0' : 'rgba(255,255,255,0.08)', borderRadius: '3px', overflow: 'hidden' }}>
                    <div style={{ width: '84%', height: '100%', background: isLight ? '#059669' : '#34d399' }} />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Section 6: Placement Level Roadmap (5 Sprints) */}
          {frame.id === 'roadmap' && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Compass size={16} color={isLight ? '#059669' : '#34d399'} />
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                    5-Phase Sprint Stepper to Placement
                  </span>
                </div>
                <button 
                  onClick={() => setActiveSprintIndex(prev => (prev + 1) % 5)}
                  style={{
                    fontSize: '0.7rem',
                    padding: '0.25rem 0.65rem',
                    borderRadius: '6px',
                    background: isLight ? 'rgba(5, 150, 105, 0.12)' : 'rgba(52, 211, 153, 0.2)',
                    color: isLight ? '#059669' : '#34d399',
                    border: isLight ? '1px solid rgba(5, 150, 105, 0.3)' : '1px solid rgba(52, 211, 153, 0.4)',
                    cursor: 'pointer',
                    fontWeight: 800
                  }}
                >
                  Step Sprint ➔ {activeSprintIndex + 1}/5
                </button>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '6px' }}>
                {['Phase 1: Foundation', 'Phase 2: Core AI', 'Phase 3: STAR Prep', 'Phase 4: Defense', 'Phase 5: Offer'].map((s, idx) => (
                  <div 
                    key={s}
                    style={{
                      padding: '6px 4px',
                      borderRadius: '6px',
                      background: idx <= activeSprintIndex 
                        ? (isLight ? 'rgba(5, 150, 105, 0.15)' : 'rgba(52, 211, 153, 0.25)') 
                        : (isLight ? '#f1f5f9' : 'rgba(255, 255, 255, 0.04)'),
                      border: idx === activeSprintIndex 
                        ? (isLight ? '1.5px solid #059669' : '1.5px solid #34d399') 
                        : (isLight ? '1px solid #e2e8f0' : '1px solid transparent'),
                      textAlign: 'center',
                      fontSize: '0.675rem',
                      color: idx <= activeSprintIndex 
                        ? (isLight ? '#047857' : '#34d399') 
                        : (isLight ? '#64748b' : 'var(--text-muted)'),
                      fontWeight: idx === activeSprintIndex ? 800 : 500
                    }}
                  >
                    {s}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section 7: Opportunities & Live Placement Radar */}
          {frame.id === 'opportunities' && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Briefcase size={16} color={isLight ? '#e11d48' : '#ec4899'} />
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                    Live Radar Stream & Auto Compatibility Matching
                  </span>
                </div>
                <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>
                  Live Radar Sweep
                </span>
              </div>
              <p style={{ fontSize: '0.775rem', color: isLight ? '#64748b' : 'var(--text-muted)', margin: '0 0 0.5rem 0' }}>
                142 Active Technical Roles • 38 Vetted Campus Internships Synchronized
              </p>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <span style={{ fontSize: '0.675rem', padding: '0.2rem 0.6rem', borderRadius: '4px', background: isLight ? 'rgba(225, 29, 72, 0.1)' : 'rgba(236, 72, 153, 0.15)', color: isLight ? '#e11d48' : '#ec4899', fontWeight: 600 }}>
                  SWE Backend: 95% Fit
                </span>
                <span style={{ fontSize: '0.675rem', padding: '0.2rem 0.6rem', borderRadius: '4px', background: isLight ? 'rgba(2, 132, 199, 0.1)' : 'rgba(56, 189, 248, 0.15)', color: isLight ? '#0284c7' : '#38bdf8', fontWeight: 600 }}>
                  ML Specialist: 91% Fit
                </span>
              </div>
            </div>
          )}

          {/* Section 8: Read & Learn Ground-Truth Resume Studio */}
          {frame.id === 'resume_learning' && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <BookMarked size={16} color={isLight ? '#4f46e5' : '#6366f1'} />
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                    Architecture Blueprint & Project Truth Defensibility
                  </span>
                </div>
                <span style={{ fontSize: '0.72rem', color: isLight ? '#4f46e5' : '#6366f1', fontWeight: 800 }}>
                  Zero-Fluff Audit
                </span>
              </div>
              <p style={{ fontSize: '0.775rem', color: isLight ? '#475569' : 'var(--text-muted)', margin: 0 }}>
                Study architectural blueprints of your claimed projects, database schema choices, and technical trade-offs to defend every bullet point during technical rounds.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const FullWidthFigmaFrameCard = React.memo(FullWidthFigmaFrameCardComponent);
