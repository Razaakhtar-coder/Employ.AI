import os
import re
import html
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting
from app.core.config import settings


class JoobleProvider(JobProviderAdapter):
    """
    Jooble Global Job Search API Adapter.
    Aggregates job postings globally when JOOBLE_API_KEY is configured.
    """

    def __init__(self):
        self.api_key = settings.JOOBLE_API_KEY or os.getenv("JOOBLE_API_KEY", "")

    @property
    def name(self) -> str:
        return "Jooble"

    @property
    def is_enabled(self) -> bool:
        return bool(self.api_key)

    def _strip_html(self, raw_html: str) -> str:
        if not raw_html:
            return ""
        clean = re.sub(r"<[^>]+>", " ", raw_html)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        if not self.is_enabled:
            return []

        postings: List[RawJobPosting] = []
        url = f"https://jooble.org/api/{self.api_key}"
        payload_data = {
            "keywords": query or "Engineering Graduate Trainee",
            "location": location or "India",
            "page": page
        }

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(url, json=payload_data)
                if response.status_code == 200:
                    data = response.json()
                    jobs = data.get("jobs", [])
                    for item in jobs:
                        raw_title = item.get("title", "")
                        raw_snippet = self._strip_html(item.get("snippet", ""))
                        company = item.get("company", "Global Enterprise")
                        loc = item.get("location", "India")
                        apply_link = item.get("link", "https://jooble.org")

                        postings.append(RawJobPosting(
                            source_id=f"jooble-{item.get('id', raw_title)}",
                            source="Jooble",
                            title=raw_title,
                            company=company,
                            location=loc,
                            remote="remote" in (raw_title + " " + raw_snippet).lower(),
                            job_type="internship" if "intern" in raw_title.lower() else "full-time",
                            experience_level="intern" if "intern" in raw_title.lower() else "entry",
                            description=raw_snippet,
                            required_skills=[],
                            apply_url=apply_link,
                            salary_range=item.get("salary") or None,
                            posted_date=item.get("updated", "Recently")[:10]
                        ))
        except Exception as e:
            print(f"[WARN] Error fetching from Jooble provider: {e}")

        return postings
