import re

with open('c:/Users/RAZA AKHTAR/Desktop/Employ.AI/frontend/src/components/ResumeDocument.tsx', encoding='utf-8') as f:
    lines = f.readlines()

print("Scanning ResumeDocument.tsx for fallbacks and fake placeholders...")
for idx, line in enumerate(lines, 1):
    # Check for hardcoded companies, degrees, locations, dummy data
    if any(keyword in line.lower() for keyword in ['lorem', 'john doe', 'google inc', 'san francisco', 'harvard', 'california', 'fake', 'dummy', 'sample']):
        print(f"Line {idx}: {line.strip()}")
    # Check for || 'default text'
    m = re.findall(r'\|\|\s*[\'\"]([^\'\"]+)[\'\"]', line)
    for match in m:
        if len(match) > 3 and match not in ['none', 'auto', 'solid', 'pointer', 'transparent', 'flex-start', 'center', 'left', 'right', 'Profile']:
            print(f"Line {idx} Fallback: || '{match}' -> {line.strip()[:80]}")
