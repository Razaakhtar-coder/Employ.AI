import React, { useRef, useEffect, useState, useMemo, useCallback } from 'react';
import * as THREE from 'three';
import { useAuth } from '../context/AuthContext';
import { useHologramTheme, THEME_CONFIGS } from '../context/HologramThemeContext';
import type { ScannerTheme, ThemeColors } from '../context/HologramThemeContext';
import type { StructuredResume, ResumeAnalysisResult } from '../types';
import type { HologramSectionData } from '../utils/hologramSectionExtractor';
import { hologramAudio } from '../utils/hologramAudio';

export type { ScannerTheme } from '../context/HologramThemeContext';
export type HologramVisualMode = 'standard' | 'heatmap';

export interface BackgroundResumeScanner3DProps {
  interactive?: boolean;
  standalone?: boolean;
  theme?: ScannerTheme;
  visualMode?: HologramVisualMode;
  customSkills?: string[];
  candidateName?: string;
  domainName?: string;
  structuredResume?: StructuredResume | null;
  analysis?: ResumeAnalysisResult | null;
  selectedSectionId?: string | null;
  onSelectSection?: (sectionId: string | null) => void;
  detectedSections?: HologramSectionData[];
  laserBurstTrigger?: number;
  currentPage?: number;
  totalPages?: number;
  onPageChange?: (page: number) => void;
}

interface CachedTextureEntry {
  texture: THREE.CanvasTexture;
  worldYMap: Record<string, { y: number; height: number; top: number; bottom: number }>;
}

const EMPTY_SKILLS_FALLBACK: string[] = Object.freeze([]) as unknown as string[];

export const BackgroundResumeScanner3D: React.FC<BackgroundResumeScanner3DProps> = React.memo(({
  interactive = true,
  standalone: _standalone = false,
  theme: propTheme,
  visualMode = 'standard',
  customSkills,
  candidateName: propName,
  domainName: propDomain,
  structuredResume,
  analysis,
  selectedSectionId = null,
  onSelectSection,
  detectedSections = [],
  laserBurstTrigger = 0,
  currentPage = 1,
  totalPages = 2,
  onPageChange
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const { user } = useAuth();
  const { mode, colors: globalColors } = useHologramTheme();
  const isLight = mode === 'light';

  // Active theme and colors
  const activeColors = useMemo<ThemeColors>(() => {
    return propTheme ? (THEME_CONFIGS[propTheme] || globalColors) : globalColors;
  }, [propTheme, globalColors]);

  const [isBurstActive, setIsBurstActive] = useState<boolean>(false);
  const [clickRipple, setClickRipple] = useState<{ x: number; y: number; label?: string } | null>(null);

  // References for live 3D material & object updates
  const materialsRef = useRef<{
    resumeMat?: THREE.MeshBasicMaterial;
    borderMat?: THREE.LineBasicMaterial;
    laserGlowMat?: THREE.MeshBasicMaterial;
    laserLineMat?: THREE.LineBasicMaterial;
    highlightMat?: THREE.MeshBasicMaterial;
    backplateMat?: THREE.MeshBasicMaterial;
    floorGrid?: THREE.GridHelper;
    ceilingGrid?: THREE.GridHelper;
    sparkMat?: THREE.PointsMaterial;
    pointLight?: THREE.PointLight;
    raycastMesh?: THREE.Mesh;
    backplateMesh?: THREE.Mesh;
    pulseRingMesh?: THREE.Mesh;
    pulseRingMat?: THREE.MeshBasicMaterial;
    highlightMesh?: THREE.Mesh;
  }>({});

  // Fast Callback Refs so Three.js event listeners never cause scene re-creation
  const onSelectSectionRef = useRef(onSelectSection);
  useEffect(() => {
    onSelectSectionRef.current = onSelectSection;
  }, [onSelectSection]);

  const onPageChangeRef = useRef(onPageChange);
  useEffect(() => {
    onPageChangeRef.current = onPageChange;
  }, [onPageChange]);

  const interactiveRef = useRef(interactive);
  useEffect(() => {
    interactiveRef.current = interactive;
  }, [interactive]);

  const totalPagesRef = useRef(totalPages);
  useEffect(() => {
    totalPagesRef.current = totalPages;
  }, [totalPages]);

  const selectedSectionIdRef = useRef<string | null>(selectedSectionId);
  useEffect(() => {
    selectedSectionIdRef.current = selectedSectionId;
  }, [selectedSectionId]);

  const visualModeRef = useRef<HologramVisualMode>(visualMode);
  useEffect(() => {
    visualModeRef.current = visualMode;
  }, [visualMode]);

  const isBurstActiveRef = useRef(isBurstActive);
  useEffect(() => {
    isBurstActiveRef.current = isBurstActive;
  }, [isBurstActive]);

  const currentPageRef = useRef(currentPage);
  useEffect(() => {
    currentPageRef.current = currentPage;
  }, [currentPage]);

  const activeColorsRef = useRef<ThemeColors>(activeColors);
  useEffect(() => {
    activeColorsRef.current = activeColors;
  }, [activeColors]);

  // Laser trigger from props
  useEffect(() => {
    if (laserBurstTrigger > 0) {
      setIsBurstActive(true);
      hologramAudio.playScanBurst();
      const t = setTimeout(() => setIsBurstActive(false), 2400);
      return () => clearTimeout(t);
    }
  }, [laserBurstTrigger]);

  // Store section Y-coordinate mappings in 3D world space (centered on section midpoints)
  const sectionWorldPositionsRef = useRef<Record<string, { y: number; height: number; top: number; bottom: number }>>({});

  // High-performance In-Memory Texture Cache
  const textureCacheRef = useRef<Map<string, CachedTextureEntry>>(new Map());

  // Derived real resume details
  const activeCandidateName = useMemo(() => {
    return (
      structuredResume?.personal_info?.full_name ||
      propName ||
      user?.full_name ||
      analysis?.filename?.replace(/\.[^/.]+$/, '') ||
      'VERIFIED CANDIDATE'
    ).toUpperCase();
  }, [structuredResume, propName, user, analysis]);

  const activeDomain = useMemo(() => {
    return (
      structuredResume?.personal_info?.title ||
      structuredResume?.headline ||
      propDomain ||
      analysis?.detected_domain ||
      'PROFESSIONAL CANDIDATE'
    ).toUpperCase();
  }, [structuredResume, propDomain, analysis]);

  const activeSkillsList = useMemo(() => {
    if (customSkills && customSkills.length > 0) return customSkills;
    if (structuredResume?.skills && structuredResume.skills.length > 0) return structuredResume.skills;
    if (analysis?.extracted_skills && analysis.extracted_skills.length > 0) return analysis.extracted_skills;
    return EMPTY_SKILLS_FALLBACK;
  }, [customSkills, structuredResume, analysis]);

  const atsScore = useMemo(() => {
    return Math.round(analysis?.resume_quality_score || 94);
  }, [analysis]);

  // Helper to draw clean styled section headers in texture canvas
  const drawSectionHeader = (ctx: CanvasRenderingContext2D, x: number, y: number, text: string, primaryColor: string, secondaryColor: string, isHeatmap = false) => {
    if (isHeatmap) {
      ctx.fillStyle = 'rgba(56, 189, 248, 0.15)';
      ctx.fillRect(x - 8, y - 28, 1020, 38);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(x - 8, y - 28, 1020, 38);
    }

    const grad = ctx.createLinearGradient(x, y - 22, x + 380, y);
    grad.addColorStop(0, primaryColor);
    grad.addColorStop(1, secondaryColor);

    ctx.fillStyle = grad;
    ctx.fillRect(x, y - 22, 10, 30);

    ctx.fillStyle = isLight ? '#090d16' : '#ffffff';
    ctx.font = '900 26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.fillText(text, x + 20, y);

    if (isHeatmap) {
      ctx.fillStyle = '#10b981';
      ctx.font = 'bold 18px "JetBrains Mono", monospace';
      ctx.fillText('[ATS RECOGNIZED: HIGH IMPACT]', x + 620, y);
    }
  };

  const wrapText = (ctx: CanvasRenderingContext2D, text: string, x: number, y: number, maxWidth: number, lineHeight: number): number => {
    if (!text) return y;
    const words = text.split(' ');
    let line = '';
    let curY = y;
    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = ctx.measureText(testLine);
      const testWidth = metrics.width;
      if (testWidth > maxWidth && n > 0) {
        ctx.fillText(line, x, curY);
        line = words[n] + ' ';
        curY += lineHeight;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line, x, curY);
    return curY + lineHeight;
  };

  // High-performance, optimized 1200x1788 canvas rendering
  const renderCanvasAndCoordinates = useCallback((themeCfg: ThemeColors, modeType: HologramVisualMode, activePage: number = 1): CachedTextureEntry => {
    const canvas = document.createElement('canvas');
    canvas.width = 1200;
    canvas.height = 1788; // Exactly 0.6711 aspect ratio matching PlaneGeometry(2.35, 3.5)
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) {
      const fallbackTex = new THREE.CanvasTexture(canvas);
      return { texture: fallbackTex, worldYMap: {} };
    }

    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';

    const isHeatmap = modeType === 'heatmap';
    const textColorPrimary = isLight ? '#090d16' : '#ffffff';
    const textColorSecondary = isLight ? '#1e293b' : '#f8fafc';
    const textColorMuted = isLight ? '#334155' : '#cbd5e1';

    // 1. Background Fill
    const bgGrad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    if (isHeatmap) {
      bgGrad.addColorStop(0, '#040d1a');
      bgGrad.addColorStop(0.5, '#07162c');
      bgGrad.addColorStop(1, '#030814');
    } else if (isLight) {
      bgGrad.addColorStop(0, '#ffffff');
      bgGrad.addColorStop(0.5, '#f8fafc');
      bgGrad.addColorStop(1, '#f1f5f9');
    } else {
      bgGrad.addColorStop(0, '#080e22');
      bgGrad.addColorStop(0.5, '#0d1636');
      bgGrad.addColorStop(1, '#050918');
    }
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Subtle High-Tech Grid lines
    ctx.strokeStyle = isHeatmap ? 'rgba(56, 189, 248, 0.12)' : (isLight ? 'rgba(0, 0, 0, 0.04)' : 'rgba(255, 255, 255, 0.035)');
    ctx.lineWidth = 1.2;
    for (let x = 0; x < canvas.width; x += 100) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 100) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Heatmap Diagnostic Overlay Glow
    if (isHeatmap) {
      const heatGrad1 = ctx.createRadialGradient(320, 360, 30, 320, 360, 240);
      heatGrad1.addColorStop(0, 'rgba(16, 185, 129, 0.28)');
      heatGrad1.addColorStop(1, 'rgba(16, 185, 129, 0)');
      ctx.fillStyle = heatGrad1;
      ctx.fillRect(0, 160, 900, 480);

      const heatGrad2 = ctx.createRadialGradient(900, 1100, 40, 900, 1100, 320);
      heatGrad2.addColorStop(0, 'rgba(56, 189, 248, 0.28)');
      heatGrad2.addColorStop(1, 'rgba(56, 189, 248, 0)');
      ctx.fillStyle = heatGrad2;
      ctx.fillRect(450, 800, 750, 600);
    }

    const sectionCanvasYMap: Record<string, { startY: number; endY: number }> = {};
    let curY = 100;
    const marginX = 90;
    const contentW = canvas.width - marginX * 2;

    // IF NO SECTIONS DETECTED YET (Awaiting Upload):
    if (detectedSections.length === 0) {
      ctx.fillStyle = themeCfg.cssColor;
      ctx.font = 'bold 24px "JetBrains Mono", monospace';
      ctx.fillText('• 3D VOLUMETRIC OPTICAL SCANNER • STANDBY', marginX, curY);
      curY += 56;

      ctx.fillStyle = isHeatmap ? '#38bdf8' : textColorPrimary;
      ctx.font = '900 48px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText('AWAITING RESUME SCAN', marginX, curY);
      curY += 40;

      ctx.fillStyle = themeCfg.cssColor;
      ctx.font = 'bold 24px "JetBrains Mono", monospace';
      ctx.fillText('HIGH-DPI OCR INGESTION READY', marginX, curY);
      curY += 56;

      ctx.strokeStyle = themeCfg.cssGlow;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(marginX, curY, contentW, 560);

      ctx.fillStyle = textColorSecondary;
      ctx.font = '500 24px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText('Upload any PDF / DOCX resume to extract full multi-page sections.', marginX + 30, curY + 90);
      ctx.fillText('• Zero domain hallucinations across Civil, Mechanical, Medical, Law & Tech.', marginX + 30, curY + 150);
      ctx.fillText('• Automatic STAR bullet parsing, skill verification & neural ATS grading.', marginX + 30, curY + 210);
      ctx.fillText('• Multi-page 3D volumetric resume inspection with interactive section zoom.', marginX + 30, curY + 270);

      ctx.fillStyle = themeCfg.cssColor;
      ctx.font = 'bold 20px "JetBrains Mono", monospace';
      ctx.fillText('► STATUS: READY FOR DOCUMENT UPLOAD', marginX + 30, curY + 365);
      ctx.fillText('► SENSOR: OPTICAL GRID ALIGNED [X: 0.00 / Y: 0.00 / Z: 4.40]', marginX + 30, curY + 415);
      ctx.fillText('► ENGINE: NEURAL RESUME PARSER V2.4', marginX + 30, curY + 465);

      const texture = new THREE.CanvasTexture(canvas);
      texture.generateMipmaps = false;
      texture.minFilter = THREE.LinearFilter;
      texture.magFilter = THREE.LinearFilter;
      texture.colorSpace = THREE.SRGBColorSpace;
      texture.needsUpdate = true;
      return { texture, worldYMap: {} };
    }

    // =========================================================================
    // PAGE 1: Profile Header, Summary, Verified Skills, Work Experience & Internships
    // =========================================================================
    if (activePage === 1) {
      // Top HUD Ribbon
      ctx.fillStyle = themeCfg.cssColor;
      ctx.font = 'bold 20px "JetBrains Mono", monospace';
      ctx.fillText(`• HOLOGRAM ATS ID: EMP-${atsScore} • NEURAL QUALITY: ${atsScore}% • PAGE 1 OF ${totalPages}`, marginX, curY);
      curY += 42;

      ctx.fillStyle = isHeatmap ? '#38bdf8' : textColorPrimary;
      ctx.font = '900 46px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText(activeCandidateName, marginX, curY);
      curY += 38;

      ctx.fillStyle = themeCfg.cssColor;
      ctx.font = 'bold 24px "JetBrains Mono", monospace';
      ctx.fillText(activeDomain, marginX, curY);
      curY += 30;

      // Contact ribbon
      const email = structuredResume?.personal_info?.email || user?.email || 'verified.candidate@employai.dev';
      const phone = structuredResume?.personal_info?.phone || '+91 ••••• •••••';
      const loc = structuredResume?.personal_info?.location || 'Verified Profile';
      ctx.fillStyle = textColorMuted;
      ctx.font = '500 19px "JetBrains Mono", monospace';
      ctx.fillText(`${email}  |  ${phone}  |  ${loc}`, marginX, curY);
      curY += 36;

      // Divider line
      ctx.strokeStyle = isLight ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.12)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(marginX, curY);
      ctx.lineTo(canvas.width - marginX, curY);
      ctx.stroke();
      curY += 32;

      // Render Page 1 Sections: summary, skills, experience, internship
      const page1Sections = detectedSections.filter(s => ['summary', 'skills', 'experience', 'internship'].includes(s.id));

      page1Sections.forEach((sec, sIdx) => {
        const secNum = String(sIdx + 1).padStart(2, '0');
        const startY = curY;

        if (sec.id === 'summary') {
          const sumText = sec.rawItems?.summary || structuredResume?.summary || (analysis?.strengths ? analysis.strengths.join(' ') : '');
          if (sumText) {
            drawSectionHeader(ctx, marginX, curY, `${secNum}. ${sec.originalTitle.toUpperCase()}`, themeCfg.cssColor, themeCfg.cssSecondary, isHeatmap);
            curY += 38;

            ctx.fillStyle = isHeatmap ? '#a7f3d0' : textColorSecondary;
            ctx.font = '500 22px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
            curY = wrapText(ctx, sumText, marginX, curY, contentW, 30);
            curY += 24;
          }
        } else if (sec.id === 'skills') {
          const skillsToDraw: string[] = (sec.rawItems?.skills || activeSkillsList || []);
          if (skillsToDraw.length > 0) {
            drawSectionHeader(ctx, marginX, curY, `${secNum}. ${sec.originalTitle.toUpperCase()} (${skillsToDraw.length})`, themeCfg.cssColor, themeCfg.cssSecondary, isHeatmap);
            curY += 38;

            const colWidth = (contentW - 30) / 2;
            const displaySkills = skillsToDraw.slice(0, 8);
            displaySkills.forEach((sk, i) => {
              const col = i % 2;
              const row = Math.floor(i / 2);
              const x = marginX + col * (colWidth + 30);
              const y = curY + row * 58;

              ctx.fillStyle = isHeatmap ? 'rgba(6, 78, 59, 0.4)' : (isLight ? '#ffffff' : '#0b1328');
              ctx.fillRect(x, y, colWidth, 48);
              ctx.strokeStyle = isHeatmap ? '#10b981' : themeCfg.cssGlow.replace('0.45', '0.35');
              ctx.lineWidth = isHeatmap ? 1.5 : 1.2;
              ctx.strokeRect(x, y, colWidth, 48);

              ctx.fillStyle = isHeatmap ? '#34d399' : themeCfg.cssColor;
              ctx.beginPath();
              ctx.arc(x + 16, y + 16, 4.5, 0, Math.PI * 2);
              ctx.fill();

              ctx.fillStyle = textColorPrimary;
              ctx.font = 'bold 19px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
              const cleanSk = sk.length > 22 ? sk.slice(0, 20) + '...' : sk;
              ctx.fillText(cleanSk, x + 28, y + 23);

              ctx.fillStyle = isLight ? 'rgba(0, 0, 0, 0.1)' : 'rgba(255, 255, 255, 0.15)';
              ctx.fillRect(x + 16, y + 33, colWidth - 85, 6);

              const pct = 0.88 + (i * 0.02) % 0.11;
              ctx.fillStyle = isHeatmap ? '#10b981' : themeCfg.cssColor;
              ctx.fillRect(x + 16, y + 33, (colWidth - 85) * pct, 6);

              ctx.fillStyle = isHeatmap ? '#34d399' : themeCfg.cssColor;
              ctx.font = 'bold 16px "JetBrains Mono", monospace';
              ctx.fillText(`${Math.round(pct * 100)}%`, x + colWidth - 56, y + 39);
            });

            curY += Math.ceil(displaySkills.length / 2) * 58 + 20;
          }
        } else if (sec.id === 'experience' || sec.id === 'internship') {
          const expItems: any[] = Array.isArray(sec.rawItems) ? sec.rawItems : [];
          if (expItems.length > 0) {
            drawSectionHeader(ctx, marginX, curY, `${secNum}. ${sec.originalTitle.toUpperCase()} (${expItems.length})`, themeCfg.cssColor, themeCfg.cssSecondary, isHeatmap);
            curY += 38;

            expItems.forEach((exp) => {
              const role = exp.role || 'Role';
              const org = exp.company || exp.company_or_org || '';
              const dur = exp.duration ? ` • ${exp.duration}` : '';
              const subline = org ? `${org}${dur}` : (exp.duration || '');

              ctx.fillStyle = textColorPrimary;
              ctx.font = 'bold 23px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
              ctx.fillText(role, marginX, curY);

              if (subline) {
                ctx.fillStyle = themeCfg.cssColor;
                ctx.font = 'bold 19px "JetBrains Mono", monospace';
                ctx.fillText(subline, marginX, curY + 24);
                curY += 50;
              } else {
                curY += 32;
              }

              const bullets: string[] = exp.bullets || exp.highlights || [];
              const maxBullets = expItems.length > 1 ? 2 : 3;
              bullets.slice(0, maxBullets).forEach((b) => {
                ctx.fillStyle = themeCfg.cssSecondary;
                ctx.font = 'bold 18px "JetBrains Mono", monospace';
                ctx.fillText('▶', marginX, curY);
                ctx.fillStyle = textColorSecondary;
                ctx.font = '500 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                curY = wrapText(ctx, b, marginX + 30, curY, contentW - 40, 27);
                curY += 6;
              });
              curY += 10;
            });
            curY += 14;
          }
        }

        sectionCanvasYMap[sec.id] = { startY, endY: curY };
      });

      // Bottom Page Navigation Ribbon on Canvas
      ctx.fillStyle = themeCfg.cssGlow.replace('0.45', '0.15');
      ctx.fillRect(marginX, canvas.height - 85, contentW, 46);
      ctx.strokeStyle = themeCfg.cssColor;
      ctx.lineWidth = 1.2;
      ctx.strokeRect(marginX, canvas.height - 85, contentW, 46);

      ctx.fillStyle = themeCfg.cssColor;
      ctx.font = 'bold 18px "JetBrains Mono", monospace';
      ctx.fillText(`PAGE 1 OF ${totalPages} [EXPERIENCE & SKILLS]  •  CLICK PAGE 2 TO VIEW PROJECTS & EDUCATION`, marginX + 20, canvas.height - 55);
    } 
    // =========================================================================
    // PAGE 2: Projects, Education, Certifications, Publications & Achievements
    // =========================================================================
    else {
      // Top HUD Ribbon on Page 2
      ctx.fillStyle = themeCfg.cssSecondary;
      ctx.font = 'bold 20px "JetBrains Mono", monospace';
      ctx.fillText(`• HOLOGRAM CREDENTIALS • PAGE 2 OF ${totalPages} [PROJECTS & ACADEMICS]`, marginX, curY);
      curY += 42;

      ctx.fillStyle = isHeatmap ? '#38bdf8' : textColorPrimary;
      ctx.font = '900 46px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText(activeCandidateName, marginX, curY);
      curY += 38;

      ctx.fillStyle = themeCfg.cssColor;
      ctx.font = 'bold 24px "JetBrains Mono", monospace';
      ctx.fillText(`${activeDomain} • EXTENDED DOSSIER`, marginX, curY);
      curY += 30;

      // Divider line
      ctx.strokeStyle = isLight ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.12)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(marginX, curY);
      ctx.lineTo(canvas.width - marginX, curY);
      ctx.stroke();
      curY += 32;

      // Render Page 2 Sections: projects, education, certifications, achievements, publications, languages, volunteer
      const page2Sections = detectedSections.filter(s => !['summary', 'skills', 'experience', 'internship'].includes(s.id));

      page2Sections.forEach((sec, sIdx) => {
        const secNum = String(sIdx + 1).padStart(2, '0');
        const startY = curY;

        if (sec.id === 'projects') {
          const prjItems: any[] = Array.isArray(sec.rawItems) ? sec.rawItems : [];
          if (prjItems.length > 0) {
            drawSectionHeader(ctx, marginX, curY, `${secNum}. ${sec.originalTitle.toUpperCase()} (${prjItems.length})`, themeCfg.cssColor, themeCfg.cssSecondary, isHeatmap);
            curY += 40;

            prjItems.forEach((prj) => {
              const title = prj.title || 'Project';
              const tech = (prj.technologies || prj.key_technologies || []).slice(0, 4).join(', ');

              ctx.fillStyle = textColorPrimary;
              ctx.font = 'bold 23px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
              ctx.fillText(title, marginX, curY);

              if (tech) {
                ctx.fillStyle = themeCfg.cssColor;
                ctx.font = 'bold 17px "JetBrains Mono", monospace';
                ctx.fillText(`[Tags: ${tech}]`, marginX, curY + 24);
              }

              curY += 48;
              const desc = prj.description || (prj.bullets && prj.bullets[0]) || '';
              if (desc) {
                ctx.fillStyle = themeCfg.cssSecondary;
                ctx.font = 'bold 18px "JetBrains Mono", monospace';
                ctx.fillText('▶', marginX, curY);
                ctx.fillStyle = textColorSecondary;
                ctx.font = '500 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                curY = wrapText(ctx, desc, marginX + 30, curY, contentW - 40, 28);
                curY += 8;
              }
              curY += 6;
            });
            curY += 14;
          }
        } else if (sec.id === 'education') {
          const eduItems: any[] = Array.isArray(sec.rawItems) ? sec.rawItems : [];
          if (eduItems.length > 0) {
            drawSectionHeader(ctx, marginX, curY, `${secNum}. ${sec.originalTitle.toUpperCase()} (${eduItems.length})`, themeCfg.cssSecondary, themeCfg.cssColor, isHeatmap);
            curY += 40;

            eduItems.forEach((edu) => {
              ctx.fillStyle = textColorPrimary;
              ctx.font = 'bold 23px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
              const deg = edu.degree ? `${edu.degree}${edu.field_of_study ? ` in ${edu.field_of_study}` : ''}` : (edu.institution || 'Academic Qualification');
              ctx.fillText(deg, marginX, curY);

              const inst = edu.institution && edu.institution !== deg ? edu.institution : '';
              const yr = edu.end_year || edu.start_year || edu.year ? ` • ${edu.end_year || edu.start_year || edu.year}` : '';
              const grade = edu.grade_or_cgpa ? ` • Grade: ${edu.grade_or_cgpa}` : '';
              const eduSub = `${inst}${yr}${grade}`.replace(/^ • /, '');

              if (eduSub) {
                ctx.fillStyle = themeCfg.cssSecondary;
                ctx.font = 'bold 19px "JetBrains Mono", monospace';
                ctx.fillText(eduSub, marginX, curY + 25);
                curY += 54;
              } else {
                curY += 34;
              }
            });
            curY += 14;
          }
        } else if (sec.id === 'certifications') {
          const certItems: any[] = Array.isArray(sec.rawItems) ? sec.rawItems : [];
          if (certItems.length > 0) {
            drawSectionHeader(ctx, marginX, curY, `${secNum}. ${sec.originalTitle.toUpperCase()} (${certItems.length})`, themeCfg.cssColor, themeCfg.cssSecondary, isHeatmap);
            curY += 40;

            certItems.forEach((c) => {
              ctx.fillStyle = isLight ? '#ffffff' : '#0b1328';
              ctx.fillRect(marginX, curY, contentW, 54);
              ctx.strokeStyle = themeCfg.cssGlow.replace('0.45', '0.35');
              ctx.lineWidth = 1.2;
              ctx.strokeRect(marginX, curY, contentW, 54);

              ctx.fillStyle = themeCfg.cssColor;
              ctx.font = 'bold 19px "JetBrains Mono", monospace';
              ctx.fillText('★', marginX + 18, curY + 33);

              ctx.fillStyle = textColorPrimary;
              ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
              ctx.fillText(c.name || 'Verified Certificate', marginX + 46, curY + 34);

              if (c.issuer) {
                ctx.fillStyle = themeCfg.cssSecondary;
                ctx.font = 'bold 17px "JetBrains Mono", monospace';
                ctx.textAlign = 'right';
                ctx.fillText(c.issuer, canvas.width - marginX - 20, curY + 34);
                ctx.textAlign = 'left';
              }

              curY += 66;
            });
            curY += 14;
          }
        } else {
          const items: string[] = sec.previewItems || [];
          if (items.length > 0) {
            drawSectionHeader(ctx, marginX, curY, `${secNum}. ${sec.originalTitle.toUpperCase()}`, themeCfg.cssSecondary, themeCfg.cssColor, isHeatmap);
            curY += 38;

            items.forEach((it) => {
              ctx.fillStyle = textColorSecondary;
              ctx.font = '500 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
              ctx.fillText(`• ${it}`, marginX + 15, curY);
              curY += 30;
            });
            curY += 14;
          }
        }

        sectionCanvasYMap[sec.id] = { startY, endY: curY };
      });

      // Bottom Page Navigation Ribbon on Canvas Page 2
      ctx.fillStyle = themeCfg.cssGlow.replace('0.45', '0.15');
      ctx.fillRect(marginX, canvas.height - 85, contentW, 46);
      ctx.strokeStyle = themeCfg.cssColor;
      ctx.lineWidth = 1.2;
      ctx.strokeRect(marginX, canvas.height - 85, contentW, 46);

      ctx.fillStyle = themeCfg.cssColor;
      ctx.font = 'bold 18px "JetBrains Mono", monospace';
      ctx.fillText(`PAGE 2 OF ${totalPages} [PROJECTS & ACADEMICS]  •  VERIFIED HOLOGRAM SCAN COMPLETE`, marginX + 20, canvas.height - 55);
    }

    // Compute exact 3D World Y-coordinates for Raycast and Zoom
    const canvasH = canvas.height;
    const worldYMap: Record<string, { y: number; height: number; top: number; bottom: number }> = {};
    for (const [secId, bound] of Object.entries(sectionCanvasYMap)) {
      const midY = (bound.startY + bound.endY) / 2;
      const top3D = 1.75 - (bound.startY / canvasH) * 3.5;
      const bottom3D = 1.75 - (bound.endY / canvasH) * 3.5;
      const mid3D = 1.75 - (midY / canvasH) * 3.5;
      worldYMap[secId] = {
        y: mid3D,
        height: Math.abs(top3D - bottom3D),
        top: top3D,
        bottom: bottom3D
      };
    }

    // Create 1:1 Razor-Sharp Canvas Texture without expensive Mipmap generation
    const texture = new THREE.CanvasTexture(canvas);
    texture.generateMipmaps = false;
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.needsUpdate = true;
    return { texture, worldYMap };
  }, [activeCandidateName, activeDomain, activeSkillsList, atsScore, structuredResume, analysis, detectedSections, isLight, totalPages]);

  // Texture Getter & Pre-Renderer with 0ms Cache Hits
  const getOrRenderTexture = useCallback((page: number, themeCfg: ThemeColors, modeType: HologramVisualMode): CachedTextureEntry => {
    const key = `${themeCfg.name}_${modeType}_p${page}_${isLight ? 'light' : 'dark'}`;
    const cached = textureCacheRef.current.get(key);
    if (cached) return cached;

    const fresh = renderCanvasAndCoordinates(themeCfg, modeType, page);
    textureCacheRef.current.set(key, fresh);
    return fresh;
  }, [isLight, renderCanvasAndCoordinates]);

  // Purge cache and pre-render when core resume data changes
  useEffect(() => {
    // Clean up old textures in cache
    textureCacheRef.current.forEach(item => item.texture.dispose());
    textureCacheRef.current.clear();

    // Pre-render Page 1 and Page 2 in memory for instant switching
    const p1 = getOrRenderTexture(1, activeColors, visualMode);
    if (totalPages > 1) {
      getOrRenderTexture(2, activeColors, visualMode);
    }

    const activeEntry = currentPage === 2 ? getOrRenderTexture(2, activeColors, visualMode) : p1;
    sectionWorldPositionsRef.current = activeEntry.worldYMap;

    const mats = materialsRef.current;
    if (mats.resumeMat) {
      mats.resumeMat.map = activeEntry.texture;
      mats.resumeMat.needsUpdate = true;
    }
  }, [activeCandidateName, activeDomain, activeSkillsList, atsScore, structuredResume, analysis, detectedSections, isLight, totalPages]);

  // Instantaneous 0ms Page/Theme/Mode Switch without rebuilding WebGL Scene
  useEffect(() => {
    const mats = materialsRef.current;
    if (!mats.borderMat) return;

    // Fast Color Updates (0ms)
    mats.borderMat.color.setHex(activeColors.primaryHex);
    if (mats.laserGlowMat) mats.laserGlowMat.color.setHex(activeColors.laserHex);
    if (mats.highlightMat) mats.highlightMat.color.setHex(activeColors.secondaryHex);
    if (mats.pulseRingMat) mats.pulseRingMat.color.setHex(activeColors.secondaryHex);
    if (mats.sparkMat) mats.sparkMat.color.setHex(activeColors.glowHex);
    if (mats.pointLight) mats.pointLight.color.setHex(activeColors.primaryHex);
    if (mats.floorGrid) mats.floorGrid.material.color.setHex(activeColors.primaryHex);
    if (mats.ceilingGrid) mats.ceilingGrid.material.color.setHex(activeColors.secondaryHex);

    // Instant Map Swap from Pre-rendered Cache (0ms)
    const activeEntry = getOrRenderTexture(currentPage, activeColors, visualMode);
    sectionWorldPositionsRef.current = activeEntry.worldYMap;

    if (mats.resumeMat && mats.resumeMat.map !== activeEntry.texture) {
      mats.resumeMat.map = activeEntry.texture;
      mats.resumeMat.needsUpdate = true;
    }
  }, [activeColors, visualMode, currentPage, getOrRenderTexture]);

  // Persistent 60 FPS Three.js Scene Setup (Runs ONLY Once on Mount!)
  useEffect(() => {
    if (!containerRef.current) return;

    const container = containerRef.current;
    let width = container.clientWidth || window.innerWidth;
    let height = container.clientHeight || 580;

    // 1. Scene & Perspective Camera
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 4.4);

    // 2. High-Performance WebGL Renderer
    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
      precision: 'highp'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.35));
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 3. Ambient & Point Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 2.0);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(activeColorsRef.current.primaryHex, 2.2, 10);
    pointLight.position.set(0, 0, 3.5);
    scene.add(pointLight);

    // 4. Main Holographic 3D Document Group
    const resumeGroup = new THREE.Group();
    scene.add(resumeGroup);

    const initialEntry = getOrRenderTexture(currentPageRef.current, activeColorsRef.current, visualModeRef.current);
    sectionWorldPositionsRef.current = initialEntry.worldYMap;

    const resumeGeo = new THREE.PlaneGeometry(2.35, 3.5, 1, 1);
    const resumeMat = new THREE.MeshBasicMaterial({
      map: initialEntry.texture,
      transparent: true,
      opacity: 0.98,
      side: THREE.DoubleSide
    });

    const resumeMesh = new THREE.Mesh(resumeGeo, resumeMat);
    resumeGroup.add(resumeMesh);

    // Glowing Neon Border Line
    const borderEdges = new THREE.EdgesGeometry(new THREE.PlaneGeometry(2.35, 3.5));
    const borderMat = new THREE.LineBasicMaterial({
      color: activeColorsRef.current.primaryHex,
      transparent: true,
      opacity: 0.95
    });
    const borderLine = new THREE.LineSegments(borderEdges, borderMat);
    borderLine.position.z = 0.008;
    resumeGroup.add(borderLine);

    // Glass Backplate
    const backplateGeo = new THREE.PlaneGeometry(2.4, 3.55);
    const backplateMat = new THREE.MeshBasicMaterial({
      color: isLight ? 0xffffff : 0x060b24,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide
    });
    const backplateMesh = new THREE.Mesh(backplateGeo, backplateMat);
    backplateMesh.position.z = -0.03;
    resumeGroup.add(backplateMesh);

    // Section Focus Glowing Highlight Bracket Box
    const highlightGeo = new THREE.PlaneGeometry(2.35, 0.75);
    const highlightMat = new THREE.MeshBasicMaterial({
      color: activeColorsRef.current.secondaryHex,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide
    });
    const highlightMesh = new THREE.Mesh(highlightGeo, highlightMat);
    highlightMesh.position.z = 0.018;
    resumeGroup.add(highlightMesh);

    // 3D Pulse Ring on Click Coordinate
    const pulseRingGeo = new THREE.RingGeometry(0.04, 0.08, 32);
    const pulseRingMat = new THREE.MeshBasicMaterial({
      color: activeColorsRef.current.secondaryHex,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending
    });
    const pulseRingMesh = new THREE.Mesh(pulseRingGeo, pulseRingMat);
    pulseRingMesh.position.z = 0.03;
    resumeGroup.add(pulseRingMesh);

    // 5. 3D Laser Scanning Beam
    const laserGroup = new THREE.Group();
    resumeGroup.add(laserGroup);

    const laserLineGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-1.25, 0, 0.02),
      new THREE.Vector3(1.25, 0, 0.02)
    ]);
    const laserLineMat = new THREE.LineBasicMaterial({
      color: 0xffffff,
      linewidth: 3,
      transparent: true,
      opacity: 0.98
    });
    const laserLine = new THREE.Line(laserLineGeo, laserLineMat);
    laserGroup.add(laserLine);

    const laserGlowGeo = new THREE.PlaneGeometry(2.5, 0.22);
    const laserGlowMat = new THREE.MeshBasicMaterial({
      color: activeColorsRef.current.laserHex,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide
    });
    const laserGlowMesh = new THREE.Mesh(laserGlowGeo, laserGlowMat);
    laserGlowMesh.position.z = 0.02;
    laserGroup.add(laserGlowMesh);

    // Perspective Cyber Grid Floor & Ceiling
    const gridHelper = new THREE.GridHelper(16, 20, activeColorsRef.current.primaryHex, activeColorsRef.current.bgGrid);
    gridHelper.position.set(0, -2.4, 0);
    scene.add(gridHelper);

    const ceilingGrid = new THREE.GridHelper(16, 20, activeColorsRef.current.secondaryHex, activeColorsRef.current.bgGrid);
    ceilingGrid.position.set(0, 2.6, 0);
    scene.add(ceilingGrid);

    // Ambient Digital Sparks
    const sparkCount = 45;
    const sparkGeo = new THREE.BufferGeometry();
    const sparkPos = new Float32Array(sparkCount * 3);
    for (let i = 0; i < sparkCount; i++) {
      sparkPos[i * 3] = (Math.random() - 0.5) * 10;
      sparkPos[i * 3 + 1] = (Math.random() - 0.5) * 6;
      sparkPos[i * 3 + 2] = (Math.random() - 0.5) * 4;
    }
    sparkGeo.setAttribute('position', new THREE.BufferAttribute(sparkPos, 3));
    const sparkMat = new THREE.PointsMaterial({
      color: activeColorsRef.current.glowHex,
      size: 0.04,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending
    });
    const bgParticles = new THREE.Points(sparkGeo, sparkMat);
    scene.add(bgParticles);

    // Store references
    materialsRef.current = {
      resumeMat,
      borderMat,
      laserGlowMat,
      laserLineMat,
      highlightMat,
      backplateMat,
      floorGrid: gridHelper,
      ceilingGrid,
      sparkMat,
      pointLight,
      raycastMesh: resumeMesh,
      backplateMesh,
      pulseRingMesh,
      pulseRingMat,
      highlightMesh
    };

    // ==========================================
    // Raycasting: Direct Click & Touch on 3D Mesh
    // ==========================================
    const raycaster = new THREE.Raycaster();
    const mouseNorm = new THREE.Vector2();

    const handleCanvasClick = (e: MouseEvent | TouchEvent) => {
      if (!interactiveRef.current || !container) return;

      const rect = container.getBoundingClientRect();
      const clientX = 'clientX' in e ? e.clientX : e.touches[0].clientX;
      const clientY = 'clientY' in e ? e.clientY : e.touches[0].clientY;

      mouseNorm.x = ((clientX - rect.left) / rect.width) * 2 - 1;
      mouseNorm.y = -((clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouseNorm, camera);
      const intersects = raycaster.intersectObject(resumeMesh);

      if (intersects.length > 0) {
        const hit = intersects[0];
        const hitWorldY = hit.point.y;

        // Bottom Ribbon Page Switch Click Detection
        if (hitWorldY <= -1.45 && totalPagesRef.current > 1) {
          const newPage = currentPageRef.current === 1 ? 2 : 1;
          hologramAudio.playSectionSelect();
          if (onPageChangeRef.current) {
            onPageChangeRef.current(newPage);
          }
          setClickRipple({
            x: clientX - rect.left,
            y: clientY - rect.top,
            label: `PAGE ${newPage} / ${totalPagesRef.current}`
          });
          setTimeout(() => setClickRipple(null), 1200);
          return;
        }

        // Find intersecting section from sectionWorldPositionsRef
        let foundSectionId: string | null = null;
        let minDistance = 999;

        for (const [secId, bounds] of Object.entries(sectionWorldPositionsRef.current)) {
          if (hitWorldY <= bounds.top + 0.15 && hitWorldY >= bounds.bottom - 0.15) {
            foundSectionId = secId;
            break;
          }
          const dist = Math.abs(bounds.y - hitWorldY);
          if (dist < minDistance) {
            minDistance = dist;
            foundSectionId = secId;
          }
        }

        if (foundSectionId) {
          pulseRingMesh.position.set(hit.point.x, hit.point.y, 0.035);
          pulseRingMesh.scale.set(1, 1, 1);
          pulseRingMat.opacity = 0.9;
          
          if (onSelectSectionRef.current) {
            onSelectSectionRef.current(foundSectionId);
          }

          setClickRipple({
            x: clientX - rect.left,
            y: clientY - rect.top,
            label: foundSectionId.toUpperCase()
          });

          setTimeout(() => setClickRipple(null), 1200);
        }
      }
    };

    container.addEventListener('click', handleCanvasClick);
    container.addEventListener('touchstart', handleCanvasClick);

    // Mouse Tracking for Parallax / Holographic Tilt
    let mouseX = 0;
    let mouseY = 0;
    let targetRotX = 0;
    let targetRotY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      if (!interactiveRef.current) return;
      mouseX = (e.clientX / window.innerWidth) * 2 - 1;
      mouseY = -(e.clientY / window.innerHeight) * 2 + 1;
      targetRotY = mouseX * 0.22;
      targetRotX = -mouseY * 0.18;
    };

    window.addEventListener('mousemove', handleMouseMove);

    // Responsive Window & Container Resize
    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth || window.innerWidth;
      const newHeight = container.clientHeight || 580;
      if (newWidth > 0 && newHeight > 0) {
        width = newWidth;
        height = newHeight;
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
        renderer.setSize(width, height);
      }
    };

    window.addEventListener('resize', handleResize);

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        if (w > 0 && h > 0) {
          width = w;
          height = h;
          camera.aspect = width / height;
          camera.updateProjectionMatrix();
          renderer.setSize(width, height);
        }
      }
    });
    resizeObserver.observe(container);

    // ==========================================
    // 60 FPS Animation Loop
    // ==========================================
    let animationFrameId: number;
    let clock = new THREE.Clock();
    let laserDir = 1;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      if (document.hidden) return;
      const delta = Math.min(clock.getDelta(), 0.1);
      const time = clock.getElapsedTime();

      // Smooth camera easing towards target section or overview
      const activeSecId = selectedSectionIdRef.current;
      const targetSecBounds = activeSecId ? sectionWorldPositionsRef.current[activeSecId] : null;

      let targetCamX = 0;
      let targetCamY = 0;
      let targetCamZ = 4.4;

      if (activeSecId && targetSecBounds) {
        // Zoom into active section
        targetCamY = targetSecBounds.y;
        targetCamZ = 2.45; // Enhanced zoom depth
        targetRotX = 0;
        targetRotY = 0;
        
        // Highlight bracket
        highlightMat.opacity = THREE.MathUtils.lerp(highlightMat.opacity, 0.35, 0.1);
        highlightMesh.position.y = targetSecBounds.y;
        highlightMesh.scale.set(1, Math.max(0.6, targetSecBounds.height / 0.75), 1);
      } else {
        // Overview mode
        highlightMat.opacity = THREE.MathUtils.lerp(highlightMat.opacity, 0.0, 0.15);
      }

      camera.position.x = THREE.MathUtils.lerp(camera.position.x, targetCamX, 0.08);
      camera.position.y = THREE.MathUtils.lerp(camera.position.y, targetCamY, 0.08);
      camera.position.z = THREE.MathUtils.lerp(camera.position.z, targetCamZ, 0.08);

      // Smooth Document Tilt
      resumeGroup.rotation.y = THREE.MathUtils.lerp(resumeGroup.rotation.y, targetRotY, 0.06);
      resumeGroup.rotation.x = THREE.MathUtils.lerp(resumeGroup.rotation.x, targetRotX, 0.06);

      // Organic gentle floating drift in overview mode
      if (!activeSecId) {
        resumeGroup.position.y = Math.sin(time * 1.5) * 0.04;
      } else {
        resumeGroup.position.y = THREE.MathUtils.lerp(resumeGroup.position.y, 0, 0.08);
      }

      // Laser Scanner Animation
      const isBurst = isBurstActiveRef.current;
      const laserSpeed = isBurst ? 5.5 : 1.35;
      laserGroup.position.y += laserDir * delta * laserSpeed;

      if (laserGroup.position.y > 1.7) {
        laserGroup.position.y = 1.7;
        laserDir = -1;
      } else if (laserGroup.position.y < -1.7) {
        laserGroup.position.y = -1.7;
        laserDir = 1;
      }

      laserGlowMat.opacity = isBurst ? 0.95 : 0.65 + Math.sin(time * 6) * 0.2;

      // Pulse Ring Fade Out
      if (pulseRingMat.opacity > 0.01) {
        pulseRingMat.opacity = THREE.MathUtils.lerp(pulseRingMat.opacity, 0.0, 0.04);
        pulseRingMesh.scale.addScalar(delta * 1.5);
      }

      // Digital Spark Rotation
      bgParticles.rotation.y = time * 0.04;
      bgParticles.rotation.x = time * 0.02;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('click', handleCanvasClick);
      container.removeEventListener('touchstart', handleCanvasClick);

      // Clean disposal
      resumeGeo.dispose();
      borderEdges.dispose();
      backplateGeo.dispose();
      highlightGeo.dispose();
      pulseRingGeo.dispose();
      laserLineGeo.dispose();
      laserGlowGeo.dispose();
      sparkGeo.dispose();

      resumeMat.dispose();
      borderMat.dispose();
      backplateMat.dispose();
      highlightMat.dispose();
      pulseRingMat.dispose();
      laserLineMat.dispose();
      laserGlowMat.dispose();
      sparkMat.dispose();

      textureCacheRef.current.forEach(item => item.texture.dispose());
      textureCacheRef.current.clear();

      try {
        renderer.forceContextLoss();
      } catch {}
      if (renderer.domElement && renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', overflow: 'hidden' }}>
      <div 
        ref={containerRef} 
        style={{ 
          width: '100%', 
          height: '100%', 
          cursor: interactive ? (selectedSectionId ? 'zoom-out' : 'crosshair') : 'default' 
        }} 
      />

      {/* Futuristic Click Coordinate Ripple */}
      {clickRipple && (
        <div style={{
          position: 'absolute',
          left: clickRipple.x,
          top: clickRipple.y,
          transform: 'translate(-50%, -50%)',
          pointerEvents: 'none',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          animation: 'pulse 0.8s ease-out forwards',
          zIndex: 40
        }}>
          <div style={{
            width: '36px',
            height: '36px',
            borderRadius: '50%',
            border: `2px solid ${activeColors.cssColor}`,
            boxShadow: `0 0 16px ${activeColors.cssGlow}`,
            animation: 'ping 1s cubic-bezier(0, 0, 0.2, 1) infinite'
          }} />
          {clickRipple.label && (
            <span style={{
              marginTop: '4px',
              fontSize: '0.68rem',
              fontWeight: 800,
              fontFamily: 'monospace',
              color: '#ffffff',
              background: activeColors.swatch,
              padding: '0.15rem 0.45rem',
              borderRadius: '4px',
              boxShadow: `0 0 10px ${activeColors.cssGlow}`
            }}>
              {clickRipple.label}
            </span>
          )}
        </div>
      )}
    </div>
  );
});
