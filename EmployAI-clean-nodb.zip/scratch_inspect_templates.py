with open('c:/Users/RAZA AKHTAR/Desktop/Employ.AI/frontend/src/components/ResumeDocument.tsx', encoding='utf-8') as f:
    text = f.read()

import re
matches = re.findall(r"templateId\s*===?\s*['\"][^'\"]+['\"]", text)
print("Unique templateId comparisons in ResumeDocument.tsx:")
for m in sorted(set(matches)):
    print("  ", m)
