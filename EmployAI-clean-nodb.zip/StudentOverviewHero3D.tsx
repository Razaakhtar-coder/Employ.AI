import React, { useRef, useEffect, useState, useMemo, useCallback } from 'react';
import * as THREE from 'three';
import confetti from 'canvas-confetti';
import { 
  Mic, Scan, Orbit, FileText, Target, 
  Compass, Rocket
} from 'lucide-react';

export type OverviewThemeId = 'cyber-cyan' | 'royal-purple' | 'emerald-mint' | 'sunset-coral' | 'obsidian-gold';

export interface OverviewThemeConfig {
  id: OverviewThemeId;
  name: string;
  badge: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  glowColor: string;
  bgGradientDark: string;
  hoodieHex: number;
  headphoneHex: number;
  accentHex: number;
  lightHex: number;
  screenLightHex: number;
  confettiColors: string[];
}

export const OVERVIEW_THEMES: Record<OverviewThemeId, OverviewThemeConfig> = {
  'cyber-cyan': {
    id: 'cyber-cyan',
    name: 'Cyber Cyan',
    badge: '⚡ Electric AI',
    primaryColor: '#00f2fe',
    secondaryColor: '#38bdf8',
    accentColor: '#0284c7',
    glowColor: 'rgba(0, 242, 254, 0.45)',
    bgGradientDark: 'radial-gradient(ellipse at 50% 30%, rgba(0, 242, 254, 0.16) 0%, rgba(15, 23, 42, 0.95) 60%, #030712 100%)',
    hoodieHex: 0x0284c7,
    headphoneHex: 0x00f2fe,
    accentHex: 0x38bdf8,
    lightHex: 0x00f2fe,
    screenLightHex: 0x38bdf8,
    confettiColors: ['#00f2fe', '#38bdf8', '#0284c7', '#ffffff']
  },
  'royal-purple': {
    id: 'royal-purple',
    name: 'Royal Purple',
    badge: '🔮 Quantum',
    primaryColor: '#a855f7',
    secondaryColor: '#c084fc',
    accentColor: '#6366f1',
    glowColor: 'rgba(168, 85, 247, 0.45)',
    bgGradientDark: 'radial-gradient(ellipse at 50% 30%, rgba(168, 85, 247, 0.18) 0%, rgba(24, 18, 43, 0.95) 60%, #030712 100%)',
    hoodieHex: 0x6366f1,
    headphoneHex: 0xa855f7,
    accentHex: 0xc084fc,
    lightHex: 0xa855f7,
    screenLightHex: 0xc084fc,
    confettiColors: ['#a855f7', '#c084fc', '#6366f1', '#ffffff']
  },
  'emerald-mint': {
    id: 'emerald-mint',
    name: 'Emerald Mint',
    badge: '🌿 Placement Offer',
    primaryColor: '#10b981',
    secondaryColor: '#34d399',
    accentColor: '#059669',
    glowColor: 'rgba(168, 85, 129, 0.45)',
    bgGradientDark: 'radial-gradient(ellipse at 50% 30%, rgba(16, 185, 129, 0.16) 0%, rgba(6, 30, 23, 0.95) 60%, #030712 100%)',
    hoodieHex: 0x059669,
    headphoneHex: 0x10b981,
    accentHex: 0x34d399,
    lightHex: 0x10b981,
    screenLightHex: 0x34d399,
    confettiColors: ['#10b981', '#34d399', '#059669', '#ffffff']
  },
  'sunset-coral': {
    id: 'sunset-coral',
    name: 'Sunset Coral',
    badge: '🌅 High Momentum',
    primaryColor: '#f59e0b',
    secondaryColor: '#f43f5e',
    accentColor: '#ea580c',
    glowColor: 'rgba(245, 158, 11, 0.45)',
    bgGradientDark: 'radial-gradient(ellipse at 50% 30%, rgba(245, 158, 11, 0.18) 0%, rgba(36, 15, 20, 0.95) 60%, #030712 100%)',
    hoodieHex: 0xea580c,
    headphoneHex: 0xf43f5e,
    accentHex: 0xf59e0b,
    lightHex: 0xf59e0b,
    screenLightHex: 0xfbbf24,
    confettiColors: ['#f59e0b', '#f43f5e', '#ea580c', '#ffffff']
  },
  'obsidian-gold': {
    id: 'obsidian-gold',
    name: 'Obsidian Gold',
    badge: '👑 Executive Tier',
    primaryColor: '#fbbf24',
    secondaryColor: '#f59e0b',
    accentColor: '#d97706',
    glowColor: 'rgba(251, 191, 36, 0.45)',
    bgGradientDark: 'radial-gradient(ellipse at 50% 30%, rgba(251, 191, 36, 0.16) 0%, rgba(24, 24, 27, 0.95) 60%, #030712 100%)',
    hoodieHex: 0x27272a,
    headphoneHex: 0xfbbf24,
    accentHex: 0xf59e0b,
    lightHex: 0xfbbf24,
    screenLightHex: 0xfef08a,
    confettiColors: ['#fbbf24', '#f59e0b', '#d97706', '#ffffff']
  }
};

export interface StudentOverviewHero3DProps {
  studentName: string;
  department: string;
  institution: string;
  targetRoleTitle?: string | null;
  exactAtsScore?: number | null;
  hasResume?: boolean;
  roadmapProgress?: number;
  onNavigate: (tab: string) => void;
  onNavigateToRoadmap?: (roleTitleOrId?: string, domain?: string) => void;
}

// Helper to create live code screen canvas texture
function createCodeScreenTexture(themeColor: string): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 320;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    // Dark IDE background
    ctx.fillStyle = '#0a0f1d';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Window header bar
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 0, canvas.width, 32);

    // Window dots
    ctx.fillStyle = '#ef4444';
    ctx.beginPath(); ctx.arc(20, 16, 6, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath(); ctx.arc(38, 16, 6, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#10b981';
    ctx.beginPath(); ctx.arc(56, 16, 6, 0, Math.PI * 2); ctx.fill();

    // Title
    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 12px monospace';
    ctx.fillText('EmployAI_Career_Engine.ts', 80, 20);

    // Code lines
    ctx.font = '14px monospace';
    const lines = [
      { text: '// Real-Time ATS Optimization', color: '#64748b' },
      { text: 'import { analyzeCandidate } from "@employai/core";', color: '#c084fc' },
      { text: '', color: '' },
      { text: 'const candidate = await analyzeCandidate({', color: '#38bdf8' },
      { text: '  targetDomain: "Cloud & Distributed Systems",', color: '#34d399' },
      { text: '  atsScore: 94, // Placement Ready', color: themeColor },
      { text: '  interviewDefense: "STAR Verified"', color: '#fbbf24' },
      { text: '});', color: '#38bdf8' },
      { text: '', color: '' },
      { text: 'await candidate.deployToOfferPipeline(); 🚀', color: '#10b981' }
    ];

    let y = 62;
    lines.forEach(line => {
      if (line.text) {
        ctx.fillStyle = line.color;
        ctx.fillText(line.text, 24, y);
      }
      y += 24;
    });

    // ATS Progress Bar at bottom
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(24, 280, 464, 14);
    ctx.fillStyle = themeColor;
    ctx.fillRect(24, 280, 464 * 0.94, 14);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

export const StudentOverviewHero3D: React.FC<StudentOverviewHero3DProps> = React.memo(({
  studentName,
  department,
  institution,
  targetRoleTitle = null,
  exactAtsScore = null,
  hasResume = false,
  roadmapProgress = 0,
  onNavigate,
  onNavigateToRoadmap
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasMountRef = useRef<HTMLDivElement | null>(null);

  const [currentThemeId, setCurrentThemeId] = useState<OverviewThemeId>('cyber-cyan');
  const activeTheme = useMemo(() => OVERVIEW_THEMES[currentThemeId], [currentThemeId]);
  const isResumeActive = Boolean(hasResume && (exactAtsScore != null || Boolean(targetRoleTitle)));

  // Zero-rerender mouse tracking mutable refs for 60fps WebGL animation
  const mouseRef = useRef({
    currentX: 0,
    currentY: 0,
    targetX: 0,
    targetY: 0,
  });

  const themeHexRef = useRef({
    hoodie: activeTheme.hoodieHex,
    headphone: activeTheme.headphoneHex,
    accent: activeTheme.accentHex,
    light: activeTheme.lightHex,
    screenLight: activeTheme.screenLightHex,
  });

  useEffect(() => {
    themeHexRef.current = {
      hoodie: activeTheme.hoodieHex,
      headphone: activeTheme.headphoneHex,
      accent: activeTheme.accentHex,
      light: activeTheme.lightHex,
      screenLight: activeTheme.screenLightHex,
    };
  }, [activeTheme]);

  // Interactive Confetti
  const triggerCelebration = useCallback((e?: React.MouseEvent) => {
    const rect = containerRef.current?.getBoundingClientRect();
    const x = rect && e ? (e.clientX - rect.left) / rect.width : 0.5;
    const y = rect && e ? (e.clientY - rect.top) / rect.height : 0.45;

    confetti({
      particleCount: 50,
      spread: 70,
      origin: { x, y },
      colors: activeTheme.confettiColors,
      disableForReducedMotion: true
    });
  }, [activeTheme]);

  // -------------------------------------------------------------
  // THREE.JS REALISTIC 3D STUDENT & WORKSTATION ANIMATED SCENE
  // -------------------------------------------------------------
  useEffect(() => {
    const container = canvasMountRef.current;
    if (!container) return;

    let width = container.clientWidth || 800;
    let height = container.clientHeight || 480;

    // 1. Scene & Camera
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 0.6, 6.2);

    // 2. High-Performance Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
      stencil: false,
      depth: true
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 3. Cinematic Studio Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.7);
    keyLight.position.set(3.5, 5, 4);
    scene.add(keyLight);

    const warmFillLight = new THREE.DirectionalLight(0xffd5b8, 0.85);
    warmFillLight.position.set(-4, 2, 3);
    scene.add(warmFillLight);

    // Dynamic Rim / Accent Light
    const themeRimLight = new THREE.PointLight(activeTheme.lightHex, 3.8, 10);
    themeRimLight.position.set(0, 1.8, 2.5);
    scene.add(themeRimLight);

    // Laptop Screen Light (Casting real-time soft glow onto the student's face & hands)
    const laptopGlowLight = new THREE.PointLight(activeTheme.screenLightHex, 2.5, 3.5);
    laptopGlowLight.position.set(0, 0.35, 0.85);
    scene.add(laptopGlowLight);

    // 4. Master Stage Group
    const stage = new THREE.Group();
    scene.add(stage);

    // -------------------------------------------------------------
    // REALISTIC MATERIALS (PBR Smooth Skin, Fabric, Metal, Glass)
    // -------------------------------------------------------------
    const realisticSkinMaterial = new THREE.MeshStandardMaterial({
      color: 0xdfa685,
      roughness: 0.55,
      metalness: 0.05
    });

    const realisticHairMaterial = new THREE.MeshStandardMaterial({
      color: 0x241a15,
      roughness: 0.75,
      metalness: 0.1
    });

    const eyeScleraMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const irisMaterial = new THREE.MeshBasicMaterial({ color: 0x3d271d });
    const pupilMaterial = new THREE.MeshBasicMaterial({ color: 0x05070c });

    const hoodieMaterial = new THREE.MeshStandardMaterial({
      color: activeTheme.hoodieHex,
      roughness: 0.7,
      metalness: 0.1
    });

    const headphoneChassisMaterial = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.35,
      metalness: 0.6
    });

    const headphoneGlowRingMaterial = new THREE.MeshBasicMaterial({
      color: activeTheme.headphoneHex
    });

    const woodDeskMaterial = new THREE.MeshStandardMaterial({
      color: 0x8b5a2b,
      roughness: 0.45,
      metalness: 0.15
    });

    const laptopAluminumMaterial = new THREE.MeshStandardMaterial({
      color: 0xd4d4d8,
      roughness: 0.25,
      metalness: 0.85
    });

    const codeTexture = createCodeScreenTexture(activeTheme.primaryColor);
    const laptopScreenMaterial = new THREE.MeshBasicMaterial({
      map: codeTexture
    });

    const goldMaterial = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      roughness: 0.2,
      metalness: 0.85
    });

    // -------------------------------------------------------------
    // REALISTIC 3D FIGURE 1: THE TECH STUDENT
    // -------------------------------------------------------------
    const studentGroup = new THREE.Group();
    studentGroup.position.set(0, -0.25, 0.3);
    stage.add(studentGroup);

    // Ergonomic Mesh Chair (Backrest & Headrest Behind Student)
    const chairGroup = new THREE.Group();
    chairGroup.position.set(0, 0.45, -0.42);
    studentGroup.add(chairGroup);

    const chairMeshMaterial = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      roughness: 0.8,
      metalness: 0.2
    });

    const chairBack = new THREE.Mesh(
      new THREE.BoxGeometry(1.05, 1.25, 0.08),
      chairMeshMaterial
    );
    chairBack.position.set(0, 0.4, 0);
    chairGroup.add(chairBack);

    const headRest = new THREE.Mesh(
      new THREE.BoxGeometry(0.55, 0.24, 0.08),
      chairMeshMaterial
    );
    headRest.position.set(0, 1.12, 0.03);
    chairGroup.add(headRest);

    // Student Head Group (Blinks, tilts, eyes follow cursor)
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 0.95, 0);
    studentGroup.add(headGroup);

    // Anatomical Head Shape (Natural human head contours)
    const headGeom = new THREE.SphereGeometry(0.44, 32, 28);
    headGeom.scale(0.92, 1.15, 0.96);
    const headMesh = new THREE.Mesh(headGeom, realisticSkinMaterial);
    headGroup.add(headMesh);

    // Realistic Styled Hair (Layered hair cap + front fringe quiff)
    const hairCap = new THREE.Mesh(
      new THREE.SphereGeometry(0.46, 28, 24, 0, Math.PI * 2, 0, Math.PI * 0.52),
      realisticHairMaterial
    );
    hairCap.position.set(0, 0.16, -0.02);
    headGroup.add(hairCap);

    // Hair Top Volume Tufts
    for (let i = -2; i <= 2; i++) {
      const strand = new THREE.Mesh(
        new THREE.BoxGeometry(0.16, 0.14, 0.28),
        realisticHairMaterial
      );
      strand.position.set(i * 0.09, 0.52, 0.22 - Math.abs(i) * 0.04);
      strand.rotation.set(-0.35, i * 0.12, 0);
      headGroup.add(strand);
    }

    // Nose
    const nose = new THREE.Mesh(
      new THREE.ConeGeometry(0.045, 0.14, 8),
      realisticSkinMaterial
    );
    nose.position.set(0, -0.02, 0.43);
    nose.rotation.x = -0.15;
    headGroup.add(nose);

    // Left & Right Ears
    const earGeom = new THREE.SphereGeometry(0.11, 14, 14);
    earGeom.scale(0.4, 0.9, 0.6);

    const leftEar = new THREE.Mesh(earGeom, realisticSkinMaterial);
    leftEar.position.set(-0.41, 0, 0);
    headGroup.add(leftEar);

    const rightEar = new THREE.Mesh(earGeom, realisticSkinMaterial);
    rightEar.position.set(0.41, 0, 0);
    headGroup.add(rightEar);

    // Expressive Eyes (Sclera + Iris + Pupil that track mouse)
    const eyeGroup = new THREE.Group();
    eyeGroup.position.set(0, 0.06, 0.38);
    headGroup.add(eyeGroup);

    const scleraGeom = new THREE.SphereGeometry(0.08, 16, 16);
    const irisGeom = new THREE.SphereGeometry(0.045, 14, 14);
    const pupilGeom = new THREE.SphereGeometry(0.025, 12, 12);

    // Left Eye
    const leftSclera = new THREE.Mesh(scleraGeom, eyeScleraMaterial);
    leftSclera.position.set(-0.16, 0, 0);
    eyeGroup.add(leftSclera);

    const leftIris = new THREE.Mesh(irisGeom, irisMaterial);
    leftIris.position.set(0, 0, 0.055);
    leftSclera.add(leftIris);

    const leftPupil = new THREE.Mesh(pupilGeom, pupilMaterial);
    leftPupil.position.set(0, 0, 0.022);
    leftIris.add(leftPupil);

    // Right Eye
    const rightSclera = new THREE.Mesh(scleraGeom, eyeScleraMaterial);
    rightSclera.position.set(0.16, 0, 0);
    eyeGroup.add(rightSclera);

    const rightIris = new THREE.Mesh(irisGeom, irisMaterial);
    rightIris.position.set(0, 0, 0.055);
    rightSclera.add(rightIris);

    const rightPupil = new THREE.Mesh(pupilGeom, pupilMaterial);
    rightPupil.position.set(0, 0, 0.022);
    rightIris.add(rightPupil);

    // Smile Line
    const smile = new THREE.Mesh(
      new THREE.TorusGeometry(0.075, 0.015, 8, 16, Math.PI),
      realisticHairMaterial
    );
    smile.position.set(0, -0.16, 0.4);
    smile.rotation.x = Math.PI;
    headGroup.add(smile);

    // Modern Wireless Over-Ear Headphones (Around the neck / ears)
    const headphoneBand = new THREE.Mesh(
      new THREE.TorusGeometry(0.48, 0.038, 12, 24, Math.PI),
      headphoneChassisMaterial
    );
    headphoneBand.position.set(0, 0.05, 0);
    headphoneBand.rotation.z = Math.PI;
    headGroup.add(headphoneBand);

    const earcupGeom = new THREE.CylinderGeometry(0.15, 0.15, 0.1, 20);
    const ringGeom = new THREE.TorusGeometry(0.13, 0.018, 8, 20);

    const leftCup = new THREE.Mesh(earcupGeom, headphoneChassisMaterial);
    leftCup.position.set(-0.46, 0.02, 0);
    leftCup.rotation.z = Math.PI / 2;
    headGroup.add(leftCup);

    const leftGlowRing = new THREE.Mesh(ringGeom, headphoneGlowRingMaterial);
    leftGlowRing.position.set(-0.52, 0.02, 0);
    leftGlowRing.rotation.y = Math.PI / 2;
    headGroup.add(leftGlowRing);

    const rightCup = new THREE.Mesh(earcupGeom, headphoneChassisMaterial);
    rightCup.position.set(0.46, 0.02, 0);
    rightCup.rotation.z = Math.PI / 2;
    headGroup.add(rightCup);

    const rightGlowRing = new THREE.Mesh(ringGeom, headphoneGlowRingMaterial);
    rightGlowRing.position.set(0.52, 0.02, 0);
    rightGlowRing.rotation.y = Math.PI / 2;
    headGroup.add(rightGlowRing);

    // Neck
    const neck = new THREE.Mesh(
      new THREE.CylinderGeometry(0.14, 0.16, 0.22, 16),
      realisticSkinMaterial
    );
    neck.position.set(0, 0.44, 0);
    studentGroup.add(neck);

    // Torso / Stylish Hoodie (Theme Reactive)
    const torso = new THREE.Mesh(
      new THREE.CylinderGeometry(0.38, 0.48, 0.95, 24),
      hoodieMaterial
    );
    torso.position.set(0, 0.05, 0);
    studentGroup.add(torso);

    // Hoodie Collar & Drawstrings
    const hoodieCollar = new THREE.Mesh(
      new THREE.TorusGeometry(0.28, 0.065, 12, 24),
      hoodieMaterial
    );
    hoodieCollar.position.set(0, 0.48, 0.02);
    hoodieCollar.rotation.x = Math.PI / 2;
    studentGroup.add(hoodieCollar);

    // Arms Angled Forward to the Desk
    const armGeom = new THREE.CylinderGeometry(0.1, 0.085, 0.72, 16);
    const handGeom = new THREE.SphereGeometry(0.08, 14, 14);
    handGeom.scale(1, 0.65, 1.4);

    const leftArm = new THREE.Mesh(armGeom, hoodieMaterial);
    leftArm.position.set(-0.46, 0.12, 0.26);
    leftArm.rotation.set(0.72, 0.18, -0.38);
    studentGroup.add(leftArm);

    const leftHand = new THREE.Mesh(handGeom, realisticSkinMaterial);
    leftHand.position.set(-0.24, -0.16, 0.62);
    studentGroup.add(leftHand);

    const rightArm = new THREE.Mesh(armGeom, hoodieMaterial);
    rightArm.position.set(0.46, 0.12, 0.26);
    rightArm.rotation.set(0.72, -0.18, 0.38);
    studentGroup.add(rightArm);

    const rightHand = new THREE.Mesh(handGeom, realisticSkinMaterial);
    rightHand.position.set(0.24, -0.16, 0.62);
    studentGroup.add(rightHand);

    // -------------------------------------------------------------
    // REALISTIC 3D FIGURE 2: THE REAL LAPTOP & WORKSTATION
    // -------------------------------------------------------------
    const workstation = new THREE.Group();
    workstation.position.set(0, -0.45, 0.82);
    stage.add(workstation);

    // Wooden Desk Top with Beveled Finish
    const desk = new THREE.Mesh(
      new THREE.BoxGeometry(2.8, 0.09, 1.4),
      woodDeskMaterial
    );
    workstation.add(desk);

    // Realistic Slim Laptop (MacBook Style Clamshell)
    const laptop = new THREE.Group();
    laptop.position.set(0, 0.06, 0.08);
    workstation.add(laptop);

    // Base Chassis & Trackpad
    const laptopBase = new THREE.Mesh(
      new THREE.BoxGeometry(0.88, 0.024, 0.62),
      laptopAluminumMaterial
    );
    laptop.add(laptopBase);

    // Black Keyboard Tray
    const keyboardTray = new THREE.Mesh(
      new THREE.BoxGeometry(0.78, 0.008, 0.34),
      headphoneChassisMaterial
    );
    keyboardTray.position.set(0, 0.016, -0.04);
    laptop.add(keyboardTray);

    // Glass Trackpad
    const trackpad = new THREE.Mesh(
      new THREE.BoxGeometry(0.32, 0.006, 0.18),
      laptopAluminumMaterial
    );
    trackpad.position.set(0, 0.016, 0.18);
    laptop.add(trackpad);

    // Open Screen Clamshell (Angled 108 deg towards student)
    const screenHinge = new THREE.Group();
    screenHinge.position.set(0, 0.018, -0.3);
    screenHinge.rotation.x = -1.22;
    laptop.add(screenHinge);

    const screenLid = new THREE.Mesh(
      new THREE.BoxGeometry(0.88, 0.62, 0.022),
      laptopAluminumMaterial
    );
    screenLid.position.set(0, 0.31, 0);
    screenHinge.add(screenLid);

    // Illuminated Code Display Texture
    const screenDisplay = new THREE.Mesh(
      new THREE.PlaneGeometry(0.82, 0.56),
      laptopScreenMaterial
    );
    screenDisplay.position.set(0, 0.31, 0.014);
    screenHinge.add(screenDisplay);

    // -------------------------------------------------------------
    // REALISTIC DESK ACCESSORIES (Coffee, Succulent, Smartphone)
    // -------------------------------------------------------------
    // 1. Ceramic Coffee Mug
    const coffeeGroup = new THREE.Group();
    coffeeGroup.position.set(-0.75, 0.14, 0.1);
    workstation.add(coffeeGroup);

    const mug = new THREE.Mesh(
      new THREE.CylinderGeometry(0.1, 0.09, 0.22, 16),
      new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.2 })
    );
    coffeeGroup.add(mug);

    const coffeeLiquid = new THREE.Mesh(
      new THREE.CylinderGeometry(0.092, 0.092, 0.02, 16),
      new THREE.MeshStandardMaterial({ color: 0x3f2212, roughness: 0.3 })
    );
    coffeeLiquid.position.set(0, 0.095, 0);
    coffeeGroup.add(coffeeLiquid);

    const mugHandle = new THREE.Mesh(
      new THREE.TorusGeometry(0.065, 0.018, 8, 16, Math.PI * 1.2),
      new THREE.MeshStandardMaterial({ color: 0xf8fafc })
    );
    mugHandle.position.set(-0.1, 0, 0);
    mugHandle.rotation.y = Math.PI / 2;
    coffeeGroup.add(mugHandle);

    // Animated Rising Steam Particles
    const steamParticles: THREE.Mesh[] = [];
    const steamGeom = new THREE.SphereGeometry(0.024, 8, 8);
    const steamMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.35
    });
    for (let i = 0; i < 6; i++) {
      const p = new THREE.Mesh(steamGeom, steamMat);
      p.position.set(
        (Math.random() - 0.5) * 0.08,
        0.12 + i * 0.06,
        (Math.random() - 0.5) * 0.08
      );
      coffeeGroup.add(p);
      steamParticles.push(p);
    }

    // 2. Potted Desk Succulent Plant
    const plantGroup = new THREE.Group();
    plantGroup.position.set(-1.05, 0.14, -0.15);
    workstation.add(plantGroup);

    const pot = new THREE.Mesh(
      new THREE.CylinderGeometry(0.12, 0.08, 0.18, 12),
      new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.4 })
    );
    plantGroup.add(pot);

    const succulentMat = new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.5 });
    for (let i = 0; i < 5; i++) {
      const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.16, 6), succulentMat);
      leaf.position.set(
        Math.sin((i * Math.PI * 2) / 5) * 0.06,
        0.14,
        Math.cos((i * Math.PI * 2) / 5) * 0.06
      );
      leaf.rotation.set(0.35, (i * Math.PI * 2) / 5, 0);
      plantGroup.add(leaf);
    }

    // 3. Slim Smartphone on Desk
    const phone = new THREE.Mesh(
      new THREE.BoxGeometry(0.16, 0.012, 0.32),
      headphoneChassisMaterial
    );
    phone.position.set(0.72, 0.05, 0.22);
    phone.rotation.y = -0.25;
    workstation.add(phone);

    // -------------------------------------------------------------
    // FLOATING REAL 3D CAREER FIGURES (Rocket, Cap, Trophy)
    // -------------------------------------------------------------
    // 1. 3D Career Launch Rocket (Upper Right)
    const rocket = new THREE.Group();
    rocket.position.set(2.4, 1.15, -0.4);
    rocket.rotation.z = -0.45;
    stage.add(rocket);

    const rocketFuselage = new THREE.Mesh(
      new THREE.CylinderGeometry(0.18, 0.25, 0.95, 18),
      new THREE.MeshStandardMaterial({ color: 0xf8fafc, metalness: 0.4, roughness: 0.25 })
    );
    rocket.add(rocketFuselage);

    const rocketNose = new THREE.Mesh(
      new THREE.ConeGeometry(0.18, 0.46, 18),
      hoodieMaterial
    );
    rocketNose.position.set(0, 0.7, 0);
    rocket.add(rocketNose);

    const rocketWindow = new THREE.Mesh(
      new THREE.SphereGeometry(0.08, 14, 14),
      headphoneGlowRingMaterial
    );
    rocketWindow.position.set(0, 0.2, 0.18);
    rocket.add(rocketWindow);

    // Rocket Fins
    const finGeom = new THREE.BoxGeometry(0.04, 0.32, 0.24);
    for (let i = 0; i < 3; i++) {
      const fin = new THREE.Mesh(finGeom, hoodieMaterial);
      fin.position.set(
        Math.sin((i * Math.PI * 2) / 3) * 0.24,
        -0.36,
        Math.cos((i * Math.PI * 2) / 3) * 0.24
      );
      fin.rotation.y = (i * Math.PI * 2) / 3;
      rocket.add(fin);
    }

    // Rocket Thrust Flame
    const rocketFlame = new THREE.Mesh(
      new THREE.ConeGeometry(0.16, 0.5, 12),
      new THREE.MeshBasicMaterial({ color: 0xf59e0b })
    );
    rocketFlame.position.set(0, -0.7, 0);
    rocketFlame.rotation.x = Math.PI;
    rocket.add(rocketFlame);

    // 2. 3D Graduation Scholar Cap (Upper Left)
    const cap = new THREE.Group();
    cap.position.set(-2.3, 1.25, -0.3);
    cap.rotation.set(0.2, 0.4, 0.2);
    stage.add(cap);

    const capTop = new THREE.Mesh(
      new THREE.BoxGeometry(0.92, 0.035, 0.92),
      new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.5 })
    );
    capTop.rotation.y = Math.PI / 4;
    cap.add(capTop);

    const capSkull = new THREE.Mesh(
      new THREE.CylinderGeometry(0.26, 0.3, 0.24, 18),
      new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.5 })
    );
    capSkull.position.set(0, -0.13, 0);
    cap.add(capSkull);

    const capTassel = new THREE.Mesh(
      new THREE.CylinderGeometry(0.014, 0.014, 0.38, 8),
      goldMaterial
    );
    capTassel.position.set(0.24, -0.12, 0.24);
    capTassel.rotation.z = -0.32;
    cap.add(capTassel);

    // 3. 3D Gold Championship Trophy (Lower Right)
    const trophy = new THREE.Group();
    trophy.position.set(2.4, -0.55, 0.3);
    trophy.rotation.y = -0.35;
    stage.add(trophy);

    const trophyBase = new THREE.Mesh(
      new THREE.CylinderGeometry(0.28, 0.34, 0.22, 16),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.3, metalness: 0.6 })
    );
    trophy.add(trophyBase);

    const trophyStem = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.1, 0.26, 14),
      goldMaterial
    );
    trophyStem.position.set(0, 0.22, 0);
    trophy.add(trophyStem);

    const trophyCup = new THREE.Mesh(
      new THREE.CylinderGeometry(0.3, 0.14, 0.48, 18),
      goldMaterial
    );
    trophyCup.position.set(0, 0.56, 0);
    trophy.add(trophyCup);

    const trophyHandleGeom = new THREE.TorusGeometry(0.16, 0.025, 8, 16, Math.PI);
    const leftTrophyHandle = new THREE.Mesh(trophyHandleGeom, goldMaterial);
    leftTrophyHandle.position.set(-0.3, 0.58, 0);
    leftTrophyHandle.rotation.z = Math.PI / 2;
    trophy.add(leftTrophyHandle);

    const rightTrophyHandle = new THREE.Mesh(trophyHandleGeom, goldMaterial);
    rightTrophyHandle.position.set(0.3, 0.58, 0);
    rightTrophyHandle.rotation.z = -Math.PI / 2;
    trophy.add(rightTrophyHandle);

    // 4. Ambient Twinkling Career Particles
    const pCount = 220;
    const pPositions = new Float32Array(pCount * 3);
    for (let i = 0; i < pCount * 3; i += 3) {
      pPositions[i] = (Math.random() - 0.5) * 11;
      pPositions[i + 1] = (Math.random() - 0.5) * 7;
      pPositions[i + 2] = (Math.random() - 0.5) * 5 - 0.8;
    }
    const pGeom = new THREE.BufferGeometry();
    pGeom.setAttribute('position', new THREE.BufferAttribute(pPositions, 3));
    const pMat = new THREE.PointsMaterial({
      color: activeTheme.accentHex,
      size: 0.045,
      transparent: true,
      opacity: 0.7
    });
    const particles = new THREE.Points(pGeom, pMat);
    stage.add(particles);

    // -------------------------------------------------------------
    // BUTTERY-SMOOTH 60 FPS ANIMATION LOOP (Zero React Re-renders)
    // -------------------------------------------------------------
    let rafId: number;
    let clock = new THREE.Clock();
    let blinkTimer = 0;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      mouseRef.current.targetX = Math.max(-1, Math.min(1, x));
      mouseRef.current.targetY = Math.max(-1, Math.min(1, y));
    };

    container.addEventListener('mousemove', handleMouseMove, { passive: true });

    let isVisible = true;
    const observer = new IntersectionObserver((entries) => {
      isVisible = entries[0].isIntersecting;
    }, { threshold: 0.1 });
    observer.observe(container);

    const animate = () => {
      rafId = requestAnimationFrame(animate);
      if (!isVisible || document.hidden) return;

      const elapsed = clock.getElapsedTime();

      // Damped Mouse Smoothing (Lerp factor 0.07)
      const m = mouseRef.current;
      m.currentX += (m.targetX - m.currentX) * 0.07;
      m.currentY += (m.targetY - m.currentY) * 0.07;

      // 1. Live Color Transitions
      const colors = themeHexRef.current;
      hoodieMaterial.color.setHex(colors.hoodie);
      rocketNose.material.color.setHex(colors.hoodie);
      headphoneGlowRingMaterial.color.setHex(colors.headphone);
      themeRimLight.color.setHex(colors.light);
      laptopGlowLight.color.setHex(colors.screenLight);
      pMat.color.setHex(colors.accent);

      // 2. Student Head & Eye Tracking
      headGroup.rotation.y = m.currentX * 0.45;
      headGroup.rotation.x = -m.currentY * 0.28;

      leftIris.position.x = m.currentX * 0.018;
      leftIris.position.y = m.currentY * 0.018;
      rightIris.position.x = m.currentX * 0.018;
      rightIris.position.y = m.currentY * 0.018;

      // Natural Human Blinking (~every 3.8s)
      blinkTimer += 0.016;
      if (blinkTimer > 3.8) {
        eyeGroup.scale.y = 0.06;
        if (blinkTimer > 3.96) {
          eyeGroup.scale.y = 1;
          blinkTimer = 0;
        }
      }

      // Idle Breathing & Natural Typing Rhythm
      const breathing = Math.sin(elapsed * 2.2) * 0.016;
      torso.position.y = 0.05 + breathing;
      headGroup.position.y = 0.95 + breathing;

      leftHand.position.y = -0.16 + Math.sin(elapsed * 9) * 0.01;
      rightHand.position.y = -0.16 + Math.cos(elapsed * 8.5) * 0.01;

      // 3. Coffee Steam rising
      steamParticles.forEach((p, idx) => {
        p.position.y += 0.003;
        p.position.x += Math.sin(elapsed * 2 + idx) * 0.001;
        if (p.position.y > 0.48) p.position.y = 0.12;
      });

      // 4. Floating 3D Career Figures Bobbing
      // Rocket
      rocket.position.y = 1.15 + Math.sin(elapsed * 2.2) * 0.12;
      rocket.rotation.y = Math.sin(elapsed * 1.4) * 0.22;
      rocketFlame.scale.y = 0.85 + Math.sin(elapsed * 16) * 0.35; // Thruster fire pulse

      // Cap
      cap.position.y = 1.25 + Math.sin(elapsed * 1.8 + 1) * 0.09;
      capTassel.rotation.z = -0.32 + Math.sin(elapsed * 2.8) * 0.16; // Swinging tassel

      // Trophy
      trophy.position.y = -0.55 + Math.sin(elapsed * 2.0 + 2) * 0.08;
      trophy.rotation.y = -0.35 + Math.sin(elapsed * 1.2) * 0.3;

      // Particle Drift
      particles.rotation.y = elapsed * 0.035;

      // 5. 3D Camera Perspective Tilt
      stage.rotation.y = m.currentX * 0.14;
      stage.rotation.x = -m.currentY * 0.09;

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      width = container.clientWidth;
      height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(rafId);
      observer.disconnect();
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('mousemove', handleMouseMove);

      scene.traverse((obj: any) => {
        if (obj.geometry) obj.geometry.dispose();
        if (obj.material) {
          if (Array.isArray(obj.material)) obj.material.forEach((m: any) => m.dispose());
          else obj.material.dispose();
        }
      });
      codeTexture.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div 
      ref={containerRef}
      className="overview-3d-hero-container"
      style={{
        position: 'relative',
        borderRadius: '24px',
        background: activeTheme.bgGradientDark,
        border: `1.5px solid ${activeTheme.primaryColor}38`,
        boxShadow: `0 25px 65px -15px rgba(0, 0, 0, 0.8), 0 0 50px ${activeTheme.glowColor}`,
        overflow: 'hidden',
        minHeight: '520px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        transition: 'background 0.5s ease, border-color 0.4s ease, box-shadow 0.4s ease'
      }}
    >
      {/* 1. THREE.JS REALISTIC 3D ANIMATED STAGE */}
      <div 
        ref={canvasMountRef}
        onClick={triggerCelebration}
        title="Interactive 3D Student Workstation: Click to celebrate! Move your mouse to track eyes and 3D depth."
        style={{
          position: 'absolute',
          inset: 0,
          zIndex: 1,
          cursor: 'pointer'
        }}
      />

      {/* 2. TOP HUD: GREETING & THEME SELECTOR */}
      <div style={{
        position: 'relative',
        zIndex: 10,
        padding: '1.5rem 1.75rem 0.5rem 1.75rem',
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '1rem',
        pointerEvents: 'none'
      }}>
        {/* Left Title & Status */}
        <div style={{ pointerEvents: 'auto' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '0.35rem', flexWrap: 'wrap' }}>
            <span 
              className="badge" 
              style={{ 
                background: `${activeTheme.primaryColor}22`,
                color: activeTheme.primaryColor,
                border: `1px solid ${activeTheme.primaryColor}55`,
                fontSize: '0.72rem',
                fontWeight: 800,
                padding: '0.2rem 0.65rem'
              }}
            >
              {activeTheme.badge}
            </span>
            <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              • {institution}
            </span>
          </div>

          <h1 style={{ 
            fontSize: '1.75rem', 
            fontWeight: 800, 
            color: '#ffffff', 
            margin: 0,
            letterSpacing: '-0.02em',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem'
          }}>
            Welcome back, <span style={{ color: activeTheme.primaryColor }}>{studentName}</span>! 👋
          </h1>
          {Boolean(hasResume && isResumeActive && targetRoleTitle) && (
            <p style={{ fontSize: '0.825rem', color: 'var(--text-secondary)', margin: '0.35rem 0 0 0' }}>
              Active Target: <strong style={{ color: '#ffffff' }}>{targetRoleTitle}</strong>{department ? ` • ${department}` : ''}
            </p>
          )}
        </div>

        {/* Right Theme Selector */}
        <div style={{ 
          pointerEvents: 'auto',
          background: 'rgba(3, 7, 18, 0.78)',
          backdropFilter: 'blur(12px)',
          border: '1px solid rgba(255, 255, 255, 0.1)',
          borderRadius: '30px',
          padding: '0.35rem 0.65rem',
          display: 'flex',
          alignItems: 'center',
          gap: '0.45rem',
          boxShadow: '0 8px 24px rgba(0, 0, 0, 0.5)'
        }}>
          <span style={{ fontSize: '0.68rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', marginRight: '0.2rem' }}>
            Theme:
          </span>
          {(Object.keys(OVERVIEW_THEMES) as OverviewThemeId[]).map((themeKey) => {
            const t = OVERVIEW_THEMES[themeKey];
            const isSelected = currentThemeId === themeKey;
            return (
              <button
                key={themeKey}
                onClick={() => setCurrentThemeId(themeKey)}
                title={`Switch to ${t.name}`}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  padding: '0.3rem 0.6rem',
                  borderRadius: '20px',
                  border: isSelected ? `1.5px solid ${t.primaryColor}` : '1px solid transparent',
                  background: isSelected ? `${t.primaryColor}26` : 'transparent',
                  color: isSelected ? '#ffffff' : 'var(--text-muted)',
                  fontSize: '0.72rem',
                  fontWeight: isSelected ? 700 : 500,
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
              >
                <span style={{
                  width: '9px',
                  height: '9px',
                  borderRadius: '50%',
                  background: t.primaryColor,
                  boxShadow: isSelected ? `0 0 8px ${t.primaryColor}` : 'none'
                }} />
                <span className="header-hide-mobile">{t.name.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. FLOATING 3D TELEMETRY CARDS */}
      <div style={{
        position: 'relative',
        zIndex: 10,
        padding: '0 1.75rem',
        display: 'flex',
        justifyContent: (isResumeActive && exactAtsScore != null && exactAtsScore > 0) ? 'space-between' : 'flex-end',
        alignItems: 'center',
        pointerEvents: 'none'
      }}>
        {/* Left Stat: Live ATS Score (Only shown when an active resume is uploaded and parsed) */}
        {Boolean(hasResume && isResumeActive) && exactAtsScore != null && exactAtsScore > 0 && (
          <div style={{
            pointerEvents: 'auto',
            background: 'rgba(11, 19, 43, 0.72)',
            backdropFilter: 'blur(10px)',
            border: `1px solid ${activeTheme.primaryColor}33`,
            borderRadius: '16px',
            padding: '0.85rem 1.15rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.85rem',
            boxShadow: '0 10px 30px rgba(0, 0, 0, 0.45)',
            maxWidth: '220px'
          }}>
            <div style={{
              width: '44px',
              height: '44px',
              borderRadius: '50%',
              background: `conic-gradient(${activeTheme.primaryColor} 0% ${exactAtsScore}%, rgba(255,255,255,0.08) ${exactAtsScore}% 100%)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: `0 0 14px ${activeTheme.glowColor}`
            }}>
              <div style={{
                width: '34px',
                height: '34px',
                borderRadius: '50%',
                background: '#030712',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '0.78rem',
                fontWeight: 800,
                color: activeTheme.primaryColor
              }}>
                {exactAtsScore}%
              </div>
            </div>
            <div>
              <span style={{ fontSize: '0.675rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>
                Live ATS Score
              </span>
              <div style={{ fontSize: '0.875rem', fontWeight: 800, color: '#ffffff' }}>
                {exactAtsScore >= 80 ? 'Optimized Pass' : exactAtsScore >= 60 ? 'Competitive' : 'Needs Review'}
              </div>
            </div>
          </div>
        )}

        {/* Right Stat: Placement Sprint */}
        <div style={{
          pointerEvents: 'auto',
          background: 'rgba(11, 19, 43, 0.72)',
          backdropFilter: 'blur(10px)',
          border: `1px solid ${activeTheme.secondaryColor}33`,
          borderRadius: '16px',
          padding: '0.85rem 1.15rem',
          display: 'flex',
          alignItems: 'center',
          gap: '0.85rem',
          boxShadow: '0 10px 30px rgba(0, 0, 0, 0.45)',
          maxWidth: '220px'
        }}>
          <div style={{
            width: '42px',
            height: '42px',
            borderRadius: '12px',
            background: `${activeTheme.secondaryColor}22`,
            border: `1px solid ${activeTheme.secondaryColor}55`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: activeTheme.secondaryColor
          }}>
            <Rocket size={20} />
          </div>
          <div>
            <span style={{ fontSize: '0.675rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700 }}>
              Placement Sprint
            </span>
            <div style={{ fontSize: '0.875rem', fontWeight: 800, color: '#ffffff' }}>
              Phase {roadmapProgress ? Math.min(5, Math.ceil((roadmapProgress / 20) + 1)) : 1} of 5
            </div>
          </div>
        </div>
      </div>

      {/* 4. BOTTOM WORKFLOW LAUNCHER BAR (Interactive 3D Navigation) */}
      <div style={{
        position: 'relative',
        zIndex: 10,
        padding: '0.9rem 1.5rem',
        background: 'rgba(3, 7, 18, 0.85)',
        backdropFilter: 'blur(16px)',
        borderTop: '1px solid rgba(255, 255, 255, 0.08)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '0.75rem'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <span style={{
            fontSize: '0.72rem',
            fontWeight: 800,
            color: activeTheme.primaryColor,
            textTransform: 'uppercase',
            letterSpacing: '0.05em'
          }}>
            Launch 3D Workflows:
          </span>
        </div>

        <div style={{ display: 'flex', gap: '0.65rem', flexWrap: 'wrap' }}>
          <button 
            onClick={() => onNavigate('interview')} 
            className="btn btn-secondary btn-sm"
            style={{ 
              display: 'inline-flex', 
              alignItems: 'center', 
              gap: '0.4rem',
              borderColor: `${activeTheme.primaryColor}55`,
              transition: 'all 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = activeTheme.primaryColor;
              e.currentTarget.style.boxShadow = `0 0 12px ${activeTheme.glowColor}`;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = `${activeTheme.primaryColor}55`;
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            <Mic size={14} color={activeTheme.primaryColor} /> AI Mock Interview
          </button>

          <button 
            onClick={() => onNavigate('scanner3d')} 
            className="btn btn-secondary btn-sm"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}
          >
            <Scan size={14} /> 3D Scanner
          </button>

          <button 
            onClick={() => onNavigate('galaxy')} 
            className="btn btn-secondary btn-sm"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}
          >
            <Orbit size={14} /> 3D Skill Galaxy
          </button>

          <button 
            onClick={() => onNavigate('resume')} 
            className="btn btn-secondary btn-sm"
          >
            <FileText size={14} /> Resume Studio
          </button>

          <button 
            onClick={() => onNavigateToRoadmap ? onNavigateToRoadmap() : onNavigate('roadmap')} 
            className="btn btn-secondary btn-sm"
          >
            <Compass size={14} /> Roadmap
          </button>

          <button 
            onClick={() => onNavigate('matching')} 
            className="btn btn-primary btn-sm"
            style={{
              background: `linear-gradient(135deg, ${activeTheme.primaryColor} 0%, ${activeTheme.secondaryColor} 100%)`,
              border: 'none',
              color: '#030712',
              fontWeight: 800,
              boxShadow: `0 4px 14px ${activeTheme.glowColor}`
            }}
          >
            <Target size={14} /> Match Analysis →
          </button>
        </div>
      </div>
    </div>
  );
});

StudentOverviewHero3D.displayName = 'StudentOverviewHero3D';
export default StudentOverviewHero3D;
