import React from 'react';

interface BrandLogoProps {
  size?: number;
  showText?: boolean;
  showBadge?: boolean;
  badgeText?: string;
  onClick?: () => void;
  className?: string;
  animated?: boolean;
}

const BrandLogoComponent: React.FC<BrandLogoProps> = ({
  size = 40,
  showText = true,
  showBadge = true,
  badgeText = 'AI Powered',
  onClick,
  className = '',
  animated = true,
}) => {
  return (
    <div 
      onClick={onClick}
      className={`brand-logo-container ${className}`}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '0.75rem',
        cursor: onClick ? 'pointer' : 'default',
        userSelect: 'none',
      }}
    >
      {/* Sleek, Non-Confusing Modern Tech Emblem */}
      <div 
        style={{
          width: `${size}px`,
          height: `${size}px`,
          position: 'relative',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}
      >
        <svg 
          width={size} 
          height={size} 
          viewBox="0 0 100 100" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          style={{
            filter: 'drop-shadow(0 0 10px rgba(56, 189, 248, 0.35)) drop-shadow(0 0 18px rgba(168, 85, 247, 0.25))',
            transition: 'transform 0.25s ease-out',
          }}
          onMouseEnter={(e) => {
            if (animated) e.currentTarget.style.transform = 'scale(1.06)';
          }}
          onMouseLeave={(e) => {
            if (animated) e.currentTarget.style.transform = 'scale(1)';
          }}
        >
          <defs>
            {/* Gradients */}
            <linearGradient id="employLogoBg" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0f172a" />
              <stop offset="100%" stopColor="#020617" />
            </linearGradient>

            <linearGradient id="employLogoStroke" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="50%" stopColor="#818cf8" />
              <stop offset="100%" stopColor="#c084fc" />
            </linearGradient>

            <linearGradient id="employEGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00f2fe" />
              <stop offset="40%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#a855f7" />
            </linearGradient>

            <linearGradient id="employSparkGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="40%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#c084fc" />
            </linearGradient>

            <filter id="employSparkGlow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="2.5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Premium Rounded Squircle Backdrop */}
          <rect 
            x="4" 
            y="4" 
            width="92" 
            height="92" 
            rx="24" 
            fill="url(#employLogoBg)" 
            stroke="url(#employLogoStroke)" 
            strokeWidth="2" 
          />

          {/* Clean Stylized "E" Logo Mark */}
          {/* Vertical Spine */}
          <rect 
            x="24" 
            y="24" 
            width="10" 
            height="52" 
            rx="5" 
            fill="url(#employEGrad)" 
          />

          {/* Top Arm of E with upward dynamic curve */}
          <path 
            d="M 24 29 C 24 26.24 26.24 24 29 24 L 62 24 C 64.76 24 67 26.24 67 29 C 67 31.76 64.76 34 62 34 L 29 34 C 26.24 34 24 31.76 24 29 Z" 
            fill="url(#employEGrad)" 
          />

          {/* Middle Arm of E */}
          <rect 
            x="24" 
            y="45" 
            width="32" 
            height="10" 
            rx="5" 
            fill="url(#employEGrad)" 
          />

          {/* Bottom Arm of E */}
          <rect 
            x="24" 
            y="66" 
            width="42" 
            height="10" 
            rx="5" 
            fill="url(#employEGrad)" 
          />

          {/* Glowing AI Spark / Star at the Top-Right Apex */}
          <g transform="translate(68, 26)">
            {/* 4-point AI Star */}
            <path 
              d="M 0 -13 C 0 -4 4 0 13 0 C 4 0 0 4 0 13 C 0 4 -4 0 -13 0 C -4 0 0 -4 0 -13 Z" 
              fill="url(#employSparkGrad)" 
              filter="url(#employSparkGlow)" 
            />
            {/* Bright Center Node */}
            <circle cx="0" cy="0" r="3" fill="#ffffff" />
          </g>
        </svg>
      </div>

      {/* Brand Wordmark & Typography */}
      {showText && (
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
            <div style={{ display: 'flex', alignItems: 'baseline', letterSpacing: '-0.03em', lineHeight: 1 }}>
              <span 
                style={{ 
                  fontSize: `${size * 0.48}px`, 
                  fontWeight: 800, 
                  color: 'var(--text-primary)',
                  fontFamily: 'var(--font-sans)'
                }}
              >
                Employ
              </span>
              <span 
                style={{ 
                  fontSize: `${size * 0.48}px`, 
                  fontWeight: 900, 
                  background: 'linear-gradient(135deg, #00f2fe 0%, #38bdf8 45%, #a855f7 100%)', 
                  WebkitBackgroundClip: 'text', 
                  WebkitTextFillColor: 'transparent',
                  fontFamily: 'var(--font-sans)',
                  marginLeft: '1px'
                }}
              >
                .AI
              </span>
            </div>

            {showBadge && (
              <span 
                className="badge badge-cyan brand-logo-badge" 
                style={{ 
                  fontSize: '0.625rem', 
                  padding: '0.12rem 0.45rem', 
                  display: 'inline-flex', 
                  alignItems: 'center', 
                  gap: '0.35rem',
                  borderRadius: '9999px',
                  background: 'rgba(56, 189, 248, 0.12)',
                  border: '1px solid rgba(56, 189, 248, 0.35)',
                  fontWeight: 700
                }}
              >
                <span 
                  style={{ 
                    width: '6px', 
                    height: '6px', 
                    borderRadius: '50%', 
                    backgroundColor: '#00f2fe', 
                    boxShadow: '0 0 8px #00f2fe', 
                    animation: 'pulse 1.5s infinite' 
                  }} 
                />
                {badgeText}
              </span>
            )}
          </div>

          <p 
            className="brand-logo-subtitle"
            style={{ 
              fontSize: `${Math.max(10, size * 0.24)}px`, 
              color: 'var(--text-muted)', 
              lineHeight: 1.1,
              marginTop: '0.2rem',
              fontWeight: 600,
              letterSpacing: '0.01em'
            }}
          >
            Placement & Career Intelligence
          </p>
        </div>
      )}
    </div>
  );
};

export const BrandLogo = React.memo(BrandLogoComponent);
export default BrandLogo;
