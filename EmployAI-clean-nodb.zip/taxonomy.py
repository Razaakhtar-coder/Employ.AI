from typing import Optional, List
from pydantic import BaseModel


class SkillAliasItem(BaseModel):
    id: str
    alias: str
    domain_hint: Optional[str] = None

    class Config:
        from_attributes = True


class SkillResponse(BaseModel):
    id: str
    canonical_name: str
    slug: str
    domain: str
    category_id: Optional[str] = None
    description: Optional[str] = None
    is_emerging: bool
    aliases: List[SkillAliasItem] = []

    class Config:
        from_attributes = True


class SkillCreate(BaseModel):
    canonical_name: str
    domain: str
    category_id: Optional[str] = None
    description: Optional[str] = None
    aliases: List[str] = []
    is_emerging: bool = False


class SkillCategoryResponse(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    icon: Optional[str] = "Layers"
    skills_count: Optional[int] = 0

    class Config:
        from_attributes = True


class SyllabusIngestRequest(BaseModel):
    department: str
    course_code: str
    course_name: str
    academic_year: str = "2024-2025"
    raw_text: str


class SyllabusIngestResponse(BaseModel):
    id: str
    department: str
    course_code: str
    course_name: str
    extracted_skills: List[str]
    mapped_canonical_skills: List[dict]
    newly_discovered_skills: List[str]
