import React from 'react';

interface Hamburger3LinesButtonProps {
  isOpen: boolean;
  onClick: () => void;
  title?: string;
  className?: string;
}

const Hamburger3LinesButtonComponent: React.FC<Hamburger3LinesButtonProps> = ({
  isOpen,
  onClick,
  title = "Toggle Navigation Menu",
  className = ""
}) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`hamburger-3lines-btn ${isOpen ? 'is-active' : ''} ${className}`}
      aria-label={isOpen ? "Close sidebar menu" : "Open sidebar menu (3 lines)"}
      title={title}
      style={{
        display: 'inline-flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        width: '40px',
        height: '40px',
        minWidth: '40px',
        minHeight: '40px',
        padding: '8px',
        borderRadius: '10px',
        background: isOpen ? 'rgba(56, 189, 248, 0.16)' : 'rgba(255, 255, 255, 0.04)',
        border: isOpen ? '1px solid rgba(56, 189, 248, 0.45)' : '1px solid var(--border-subtle)',
        cursor: 'pointer',
        gap: '5px',
        transition: 'background-color 0.16s ease, border-color 0.16s ease, box-shadow 0.16s ease',
        boxShadow: isOpen ? '0 0 14px rgba(56, 189, 248, 0.3)' : 'none',
        outline: 'none',
        position: 'relative'
      }}
    >
      {/* Line 1 - Top */}
      <span
        style={{
          display: 'block',
          width: '20px',
          height: '2.5px',
          borderRadius: '3px',
          background: isOpen ? 'var(--accent-cyan)' : 'var(--text-primary)',
          transformOrigin: 'center',
          transform: isOpen ? 'translate3d(0, 7.5px, 0) rotate(45deg)' : 'none',
          transition: 'transform 0.16s ease, background-color 0.14s ease',
          willChange: 'transform'
        }}
      />
      {/* Line 2 - Middle */}
      <span
        style={{
          display: 'block',
          width: isOpen ? '0px' : '16px',
          height: '2.5px',
          borderRadius: '3px',
          background: 'var(--accent-cyan)',
          transformOrigin: 'center',
          opacity: isOpen ? 0 : 1,
          transition: 'opacity 0.14s ease, width 0.14s ease',
          alignSelf: 'flex-start',
          marginLeft: '2px',
          willChange: 'opacity, width'
        }}
      />
      {/* Line 3 - Bottom */}
      <span
        style={{
          display: 'block',
          width: '20px',
          height: '2.5px',
          borderRadius: '3px',
          background: isOpen ? 'var(--accent-cyan)' : 'var(--text-primary)',
          transformOrigin: 'center',
          transform: isOpen ? 'translate3d(0, -7.5px, 0) rotate(-45deg)' : 'none',
          transition: 'transform 0.16s ease, background-color 0.14s ease',
          willChange: 'transform'
        }}
      />
    </button>
  );
};

export const Hamburger3LinesButton = React.memo(Hamburger3LinesButtonComponent);
