from typing import Optional, List
from pydantic import BaseModel, Field
from app.schemas.auth import UserResponse


class StudentSkillItem(BaseModel):
    skill_id: str
    skill_name: str
    domain: str
    proficiency: str
    source: str
    evidence_snippet: Optional[str] = None

    class Config:
        from_attributes = True


class StudentProfileUpdate(BaseModel):
    enrollment_no: Optional[str] = None
    institution_name: Optional[str] = None
    degree: Optional[str] = None
    department: Optional[str] = None
    graduation_year: Optional[int] = None
    cgpa: Optional[float] = Field(None, ge=0.0, le=10.0)
    bio: Optional[str] = None
    location: Optional[str] = None
    target_domain: Optional[str] = None


class StudentProfileResponse(BaseModel):
    id: str
    user_id: str
    enrollment_no: Optional[str] = None
    institution_name: Optional[str] = None
    degree: Optional[str] = None
    department: Optional[str] = None
    graduation_year: Optional[int] = None
    cgpa: Optional[float] = None
    bio: Optional[str] = None
    location: Optional[str] = None
    target_domain: Optional[str] = None
    profile_completion_pct: int
    user: Optional[UserResponse] = None
    skills: List[StudentSkillItem] = []

    class Config:
        from_attributes = True


class AcademicProfileUpdate(BaseModel):
    institution_name: Optional[str] = None
    department: Optional[str] = None
    designation: Optional[str] = None
    employee_id: Optional[str] = None
    contact_number: Optional[str] = None


class AcademicProfileResponse(BaseModel):
    id: str
    user_id: str
    institution_name: str
    department: str
    designation: str
    employee_id: Optional[str] = None
    contact_number: Optional[str] = None
    user: Optional[UserResponse] = None

    class Config:
        from_attributes = True


class IndustryProfileUpdate(BaseModel):
    company_name: Optional[str] = None
    website: Optional[str] = None
    domain: Optional[str] = None
    company_size: Optional[str] = None
    location: Optional[str] = None


class IndustryProfileResponse(BaseModel):
    id: str
    user_id: str
    company_name: str
    website: Optional[str] = None
    domain: Optional[str] = None
    company_size: Optional[str] = None
    location: Optional[str] = None
    is_verified: bool
    user: Optional[UserResponse] = None

    class Config:
        from_attributes = True
