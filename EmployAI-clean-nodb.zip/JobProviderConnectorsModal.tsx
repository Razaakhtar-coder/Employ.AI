import React, { useState, useEffect } from 'react';
import { jobsApi } from '../services/api';
import type { ProviderMetadataItem } from '../types';
import { 
  X, Key, ShieldCheck, Check, Sparkles, 
  ExternalLink, AlertCircle, Eye, EyeOff, Zap
} from 'lucide-react';
import { FuturisticLoader } from './FuturisticLoader';

interface JobProviderConnectorsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRefreshCompleted?: () => void;
}

const PROVIDER_BRAND_INFO: Record<string, { color: string; bg: string; icon: string; directUrl: string }> = {
  'remote_com': { color: '#a855f7', bg: 'rgba(168, 85, 247, 0.12)', icon: '🌍', directUrl: 'https://remote.com/jobs' },
  'instahyre': { color: '#0ea5e9', bg: 'rgba(14, 165, 233, 0.12)', icon: '⚡', directUrl: 'https://www.instahyre.com' },
  'careerhound_io': { color: '#f59e0b', bg: 'rgba(245, 158, 11, 0.12)', icon: '🐕', directUrl: 'https://careerhound.io' },
  'wellfound': { color: '#ec4899', bg: 'rgba(236, 72, 153, 0.12)', icon: '✌️', directUrl: 'https://wellfound.com' },
  'yc_startups': { color: '#f97316', bg: 'rgba(249, 115, 22, 0.12)', icon: '🚀', directUrl: 'https://www.workatastartup.com' },
  'cutshort': { color: '#10b981', bg: 'rgba(16, 185, 129, 0.12)', icon: '✂️', directUrl: 'https://cutshort.io' },
  'otta': { color: '#6366f1', bg: 'rgba(99, 102, 241, 0.12)', icon: '🌿', directUrl: 'https://otta.com' },
  'remotive': { color: '#3b82f6', bg: 'rgba(59, 130, 246, 0.12)', icon: '💼', directUrl: 'https://remotive.com' },
  'himalayas': { color: '#c084fc', bg: 'rgba(192, 132, 252, 0.12)', icon: '🏔️', directUrl: 'https://himalayas.app' },
  'jobicy': { color: '#34d399', bg: 'rgba(52, 211, 153, 0.12)', icon: '🌐', directUrl: 'https://jobicy.com' },
  'arbeitnow': { color: '#fbbf24', bg: 'rgba(251, 191, 36, 0.12)', icon: '🇩🇪', directUrl: 'https://www.arbeitnow.com' },
  'remoteok': { color: '#fb7185', bg: 'rgba(251, 113, 133, 0.12)', icon: '🏝️', directUrl: 'https://remoteok.com' },
  'weworkremotely': { color: '#38bdf8', bg: 'rgba(56, 189, 248, 0.12)', icon: '💻', directUrl: 'https://weworkremotely.com' },
  'linkedin': { color: '#60a5fa', bg: 'rgba(96, 165, 250, 0.12)', icon: '🔗', directUrl: 'https://www.linkedin.com/jobs' },
  'naukri_com': { color: '#fb923c', bg: 'rgba(251, 146, 60, 0.12)', icon: '🇮🇳', directUrl: 'https://www.naukri.com' },
  'the_muse': { color: '#f472b6', bg: 'rgba(244, 114, 182, 0.12)', icon: '🏛️', directUrl: 'https://www.themuse.com' },
  'findwork': { color: '#2dd4bf', bg: 'rgba(45, 212, 191, 0.12)', icon: '🔍', directUrl: 'https://findwork.dev' },
  'jooble': { color: '#a78bfa', bg: 'rgba(167, 139, 250, 0.12)', icon: '🎯', directUrl: 'https://jooble.org' },
  'usajobs': { color: '#ef4444', bg: 'rgba(239, 68, 68, 0.12)', icon: '🇺🇸', directUrl: 'https://www.usajobs.gov' },
  'jsearch_(linkedin/indeed_aggregator)': { color: '#0284c7', bg: 'rgba(2, 132, 199, 0.12)', icon: '📊', directUrl: 'https://rapidapi.com/letscrape-6bRBa3qguO5/api/jsearch' },
  'adzuna': { color: '#14b8a6', bg: 'rgba(20, 184, 166, 0.12)', icon: '🏷️', directUrl: 'https://developer.adzuna.com' }
};

export const JobProviderConnectorsModal: React.FC<JobProviderConnectorsModalProps> = ({
  isOpen,
  onClose,
  onRefreshCompleted
}) => {
  const [providers, setProviders] = useState<ProviderMetadataItem[]>([]);
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [savingKeyFor, setSavingKeyFor] = useState<string | null>(null);
  const [keyValues, setKeyValues] = useState<Record<string, string>>({});
  const [visibleKeys, setVisibleKeys] = useState<Record<string, boolean>>({});
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const fetchProviders = async () => {
    setIsLoading(true);
    try {
      const res = await jobsApi.getProviders();
      setProviders(res.providers || []);
    } catch (err: any) {
      console.error('Failed to load job providers:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchProviders();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleKeyChange = (key: string, val: string) => {
    setKeyValues(prev => ({ ...prev, [key]: val }));
  };

  const toggleVisibility = (key: string) => {
    setVisibleKeys(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSaveKey = async (provider: ProviderMetadataItem) => {
    const val = keyValues[provider.key] || '';
    if (!val.trim()) return;

    setSavingKeyFor(provider.key);
    setStatusMessage(null);
    try {
      const res = await jobsApi.updateProviderKey(provider.key, val);
      setStatusMessage(res.message);
      setProviders(res.providers || []);
      setKeyValues(prev => ({ ...prev, [provider.key]: '' }));
      if (onRefreshCompleted) {
        onRefreshCompleted();
      }
      setTimeout(() => setStatusMessage(null), 4000);
    } catch (err: any) {
      setStatusMessage(`Failed to update key: ${err?.message || 'Unknown error'}`);
    } finally {
      setSavingKeyFor(null);
    }
  };

  const filteredProviders = providers.filter(p => {
    if (categoryFilter === 'low_crowd') return p.crowd_level === 'low';
    if (categoryFilter === 'remote') return p.category === 'Global Remote';
    if (categoryFilter === 'enterprise') return p.category === 'Enterprise Portals';
    return true;
  });

  const lowCrowdCount = providers.filter(p => p.crowd_level === 'low').length;
  const remoteCount = providers.filter(p => p.category === 'Global Remote').length;
  const enterpriseCount = providers.filter(p => p.category === 'Enterprise Portals').length;

  return (
    <div 
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(5, 8, 18, 0.85)',
        backdropFilter: 'blur(10px)',
        zIndex: 1050,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1.25rem'
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="glass-card animate-fadeIn"
        style={{
          width: '100%',
          maxWidth: '920px',
          maxHeight: '90vh',
          display: 'flex',
          flexDirection: 'column',
          borderRadius: '16px',
          border: '1px solid rgba(56, 189, 248, 0.25)',
          boxShadow: '0 25px 60px -15px rgba(0, 0, 0, 0.7), 0 0 40px rgba(56, 189, 248, 0.1)',
          background: 'linear-gradient(180deg, rgba(17, 24, 39, 0.96) 0%, rgba(10, 15, 30, 0.98) 100%)',
          overflow: 'hidden'
        }}
      >
        {/* Modal Header */}
        <div style={{
          padding: '1.4rem 1.75rem',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '1rem',
          flexWrap: 'wrap'
        }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
              <h2 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0, letterSpacing: '-0.02em' }}>
                Job Providers & API Key Connectors
              </h2>
              <span className="badge badge-emerald" style={{ fontSize: '0.725rem', display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}>
                <ShieldCheck size={13} /> {providers.filter(p => p.is_enabled).length} Active Feeds
              </span>
              <span className="badge badge-cyan" style={{ fontSize: '0.725rem', display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}>
                <Zap size={13} /> Real-Time Sync
              </span>
            </div>
            <p style={{ fontSize: '0.825rem', color: 'var(--text-muted)', margin: '0.35rem 0 0 0', lineHeight: 1.45 }}>
              Configure private partner API keys or stream directly from curated low-competition platforms (<strong>Remote.com, Instahyre, Careerhound.io, Wellfound, YC Startups, Cutshort & Otta</strong>) with zero client-side caching.
            </p>
          </div>

          <button
            onClick={onClose}
            className="btn btn-secondary btn-sm"
            style={{ padding: '0.45rem', borderRadius: '50%', minWidth: '34px', minHeight: '34px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
            aria-label="Close modal"
          >
            <X size={18} />
          </button>
        </div>

        {/* Status Notification */}
        {statusMessage && (
          <div style={{
            padding: '0.75rem 1.75rem',
            backgroundColor: 'rgba(16, 185, 129, 0.12)',
            borderBottom: '1px solid rgba(16, 185, 129, 0.25)',
            color: '#34d399',
            fontSize: '0.825rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem'
          }}>
            <Check size={16} /> {statusMessage}
          </div>
        )}

        {/* Category Tabs */}
        <div style={{
          padding: '0.85rem 1.75rem',
          borderBottom: '1px solid rgba(255, 255, 255, 0.05)',
          display: 'flex',
          gap: '0.5rem',
          overflowX: 'auto'
        }}>
          <button
            onClick={() => setCategoryFilter('all')}
            style={{
              padding: '0.4rem 0.85rem',
              borderRadius: '20px',
              fontSize: '0.775rem',
              fontWeight: categoryFilter === 'all' ? 700 : 500,
              cursor: 'pointer',
              border: categoryFilter === 'all' ? '1px solid var(--accent-cyan)' : '1px solid var(--border-subtle)',
              backgroundColor: categoryFilter === 'all' ? 'rgba(6, 182, 212, 0.15)' : 'transparent',
              color: categoryFilter === 'all' ? 'var(--accent-cyan)' : 'var(--text-secondary)'
            }}
          >
            🌐 All Platforms ({providers.length})
          </button>
          <button
            onClick={() => setCategoryFilter('low_crowd')}
            style={{
              padding: '0.4rem 0.85rem',
              borderRadius: '20px',
              fontSize: '0.775rem',
              fontWeight: categoryFilter === 'low_crowd' ? 700 : 500,
              cursor: 'pointer',
              border: categoryFilter === 'low_crowd' ? '1px solid #10b981' : '1px solid var(--border-subtle)',
              backgroundColor: categoryFilter === 'low_crowd' ? 'rgba(16, 185, 129, 0.18)' : 'transparent',
              color: categoryFilter === 'low_crowd' ? '#34d399' : 'var(--text-secondary)',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.35rem'
            }}
          >
            <Sparkles size={13} color="#34d399" /> Curated & Low Crowd ({lowCrowdCount})
          </button>
          <button
            onClick={() => setCategoryFilter('remote')}
            style={{
              padding: '0.4rem 0.85rem',
              borderRadius: '20px',
              fontSize: '0.775rem',
              fontWeight: categoryFilter === 'remote' ? 700 : 500,
              cursor: 'pointer',
              border: categoryFilter === 'remote' ? '1px solid #38bdf8' : '1px solid var(--border-subtle)',
              backgroundColor: categoryFilter === 'remote' ? 'rgba(56, 189, 248, 0.15)' : 'transparent',
              color: categoryFilter === 'remote' ? '#38bdf8' : 'var(--text-secondary)'
            }}
          >
            🌍 Global Remote ({remoteCount})
          </button>
          <button
            onClick={() => setCategoryFilter('enterprise')}
            style={{
              padding: '0.4rem 0.85rem',
              borderRadius: '20px',
              fontSize: '0.775rem',
              fontWeight: categoryFilter === 'enterprise' ? 700 : 500,
              cursor: 'pointer',
              border: categoryFilter === 'enterprise' ? '1px solid #a855f7' : '1px solid var(--border-subtle)',
              backgroundColor: categoryFilter === 'enterprise' ? 'rgba(168, 85, 247, 0.15)' : 'transparent',
              color: categoryFilter === 'enterprise' ? '#c084fc' : 'var(--text-secondary)'
            }}
          >
            🏢 Enterprise Portals ({enterpriseCount})
          </button>
        </div>

        {/* Providers Grid Container */}
        <div style={{
          padding: '1.5rem 1.75rem',
          overflowY: 'auto',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(380px, 1fr))',
          gap: '1.25rem',
          flex: 1
        }}>
          {isLoading ? (
            <div style={{ gridColumn: '1 / -1', textAlign: 'center', padding: '3rem 1rem' }}>
              <FuturisticLoader
                size="md"
                icon="globe"
                title="Inspecting Active Career Feeds..."
                subtitle="Verifying connector status, rate limits, and live provider sync"
              />
            </div>
          ) : filteredProviders.length === 0 ? (
            <div style={{ gridColumn: '1 / -1', textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
              No providers found in this category.
            </div>
          ) : (
            filteredProviders.map((provider) => {
              const brand = PROVIDER_BRAND_INFO[provider.key] || {
                color: '#38bdf8',
                bg: 'rgba(56, 189, 248, 0.1)',
                icon: '💼',
                directUrl: '#'
              };
              const isLowCrowd = provider.crowd_level === 'low';
              const isSaving = savingKeyFor === provider.key;
              const inputVal = keyValues[provider.key] ?? '';
              const isVisible = visibleKeys[provider.key] || false;

              return (
                <div
                  key={provider.key}
                  style={{
                    backgroundColor: 'rgba(255, 255, 255, 0.02)',
                    border: isLowCrowd ? '1px solid rgba(16, 185, 129, 0.35)' : '1px solid var(--border-subtle)',
                    borderRadius: '12px',
                    padding: '1.25rem',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    gap: '1rem',
                    transition: 'all 0.2s ease',
                    position: 'relative',
                    background: isLowCrowd ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.05) 0%, rgba(255, 255, 255, 0.02) 100%)' : 'rgba(255, 255, 255, 0.02)'
                  }}
                >
                  <div>
                    {/* Top Row: Brand, Category, Crowd Badge */}
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem', marginBottom: '0.65rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                        <span style={{
                          fontSize: '1.25rem',
                          width: '36px',
                          height: '36px',
                          borderRadius: '8px',
                          backgroundColor: brand.bg,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          border: `1px solid ${brand.color}40`
                        }}>
                          {brand.icon}
                        </span>
                        <div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                            <h4 style={{ fontSize: '1rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                              {provider.name}
                            </h4>
                            {brand.directUrl !== '#' && (
                              <a
                                href={brand.directUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                style={{ color: 'var(--text-muted)', display: 'inline-flex' }}
                                title={`Visit ${provider.name} portal`}
                              >
                                <ExternalLink size={12} />
                              </a>
                            )}
                          </div>
                          <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                            {provider.category}
                          </span>
                        </div>
                      </div>

                      {/* Competition Badge */}
                      {isLowCrowd ? (
                        <span className="badge" style={{
                          backgroundColor: 'rgba(16, 185, 129, 0.18)',
                          color: '#34d399',
                          borderColor: 'rgba(16, 185, 129, 0.4)',
                          fontSize: '0.68rem',
                          fontWeight: 700,
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '0.25rem'
                        }}>
                          <Sparkles size={11} /> Low Crowd (5x Response)
                        </span>
                      ) : (
                        <span className="badge badge-secondary" style={{ fontSize: '0.68rem' }}>
                          {provider.crowd_level === 'moderate' ? 'Moderate Crowd' : 'Standard Feed'}
                        </span>
                      )}
                    </div>

                    {/* Description */}
                    <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', lineHeight: 1.45, margin: '0 0 0.85rem 0' }}>
                      {provider.description}
                    </p>

                    {/* Status & Active Counts Chips */}
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', fontSize: '0.725rem', marginBottom: '0.75rem' }}>
                      {provider.is_enabled ? (
                        <span style={{ color: '#34d399', display: 'flex', alignItems: 'center', gap: '0.3rem', fontWeight: 600 }}>
                          <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#10b981', display: 'inline-block' }} />
                          Live Stream Active
                        </span>
                      ) : (
                        <span style={{ color: '#fb7185', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                          <AlertCircle size={12} /> API Key Required
                        </span>
                      )}

                      {provider.is_configured && (
                        <span style={{ color: '#60a5fa', display: 'flex', alignItems: 'center', gap: '0.3rem', fontWeight: 600 }}>
                          <Key size={11} /> Custom Key Saved
                        </span>
                      )}

                      {typeof provider.active_jobs_count === 'number' && (
                        <span style={{ color: 'var(--text-muted)' }}>
                          • <strong>{provider.active_jobs_count}</strong> live postings indexed
                        </span>
                      )}
                    </div>
                  </div>

                  {/* API Key Configuration Form */}
                  <div style={{
                    paddingTop: '0.75rem',
                    borderTop: '1px solid rgba(255, 255, 255, 0.05)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '0.45rem'
                  }}>
                    <label style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'flex', justifyContent: 'space-between' }}>
                      <span>{provider.api_key_name || `${provider.name.toUpperCase().replace(/[^A-Z]/g, '_')}_API_KEY`}</span>
                      {provider.is_configured && <span style={{ color: '#34d399' }}>✓ Active in Environment</span>}
                    </label>

                    <div style={{ display: 'flex', gap: '0.4rem' }}>
                      <div style={{ position: 'relative', flex: 1 }}>
                        <input
                          type={isVisible ? 'text' : 'password'}
                          placeholder={provider.is_configured ? '••••••••••••••••••••' : 'Enter API key or partner token...'}
                          value={inputVal}
                          onChange={(e) => handleKeyChange(provider.key, e.target.value)}
                          style={{
                            width: '100%',
                            padding: '0.45rem 2rem 0.45rem 0.65rem',
                            fontSize: '0.775rem',
                            borderRadius: '6px',
                            border: '1px solid var(--border-subtle)',
                            backgroundColor: 'rgba(0, 0, 0, 0.3)',
                            color: 'var(--text-primary)',
                            outline: 'none'
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => toggleVisibility(provider.key)}
                          style={{
                            position: 'absolute',
                            right: '0.5rem',
                            top: '50%',
                            transform: 'translateY(-50%)',
                            background: 'none',
                            border: 'none',
                            color: 'var(--text-muted)',
                            cursor: 'pointer',
                            padding: 0
                          }}
                        >
                          {isVisible ? <EyeOff size={13} /> : <Eye size={13} />}
                        </button>
                      </div>

                      <button
                        onClick={() => handleSaveKey(provider)}
                        disabled={isSaving || !inputVal.trim()}
                        className="btn btn-primary btn-sm"
                        style={{
                          fontSize: '0.75rem',
                          padding: '0.45rem 0.75rem',
                          whiteSpace: 'nowrap',
                          opacity: !inputVal.trim() ? 0.5 : 1
                        }}
                      >
                        {isSaving ? 'Saving...' : 'Save Key'}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer */}
        <div style={{
          padding: '1rem 1.75rem',
          borderTop: '1px solid var(--border-subtle)',
          backgroundColor: 'rgba(0, 0, 0, 0.2)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '1rem'
        }}>
          <div style={{ fontSize: '0.775rem', color: 'var(--text-muted)' }}>
            <span style={{ color: 'var(--accent-emerald)', fontWeight: 600 }}>● Instant Sync Safeguards:</span> Strict 3.5s async timeout per provider ensures zero UI delay.
          </div>
          <button
            onClick={onClose}
            className="btn btn-secondary btn-sm"
            style={{ padding: '0.45rem 1.25rem' }}
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
