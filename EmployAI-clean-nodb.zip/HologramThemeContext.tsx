import React, { createContext, useContext, useState, useEffect } from 'react';

export type ScannerTheme = 'emerald-growth' | 'celestial-cyan' | 'royal-indigo' | 'solar-horizon' | 'aurora-sapphire' | 'neon-matrix';
export type ThemeMode = 'light' | 'dark';

export interface ThemeColors {
  name: string;
  subtitle: string;
  primaryHex: number;
  secondaryHex: number;
  glowHex: number;
  laserHex: number;
  laserCorona: number;
  bgGrid: number;
  cssColor: string;
  cssGlow: string;
  cssSecondary: string;
  accentBg: string;
  bgRadialLight: string;
  bgRadialDark: string;
  gradHeader: string[];
  swatch: string;
}

export const THEME_CONFIGS: Record<ScannerTheme, ThemeColors> = {
  'emerald-growth': {
    name: 'Emerald Growth',
    subtitle: 'Career Mastery & Placement Success',
    primaryHex: 0x10b981,
    secondaryHex: 0x059669,
    glowHex: 0x34d399,
    laserHex: 0x10b981,
    laserCorona: 0x059669,
    bgGrid: 0x10b981,
    cssColor: '#10b981',
    cssSecondary: '#059669',
    cssGlow: 'rgba(16, 185, 129, 0.45)',
    accentBg: 'rgba(16, 185, 129, 0.15)',
    swatch: 'linear-gradient(135deg, #10b981, #059669)',
    bgRadialLight: 'radial-gradient(circle at 18% 15%, rgba(16, 185, 129, 0.18) 0%, transparent 50%), radial-gradient(circle at 82% 82%, rgba(5, 150, 105, 0.14) 0%, transparent 50%)',
    bgRadialDark: 'radial-gradient(circle at 18% 15%, rgba(16, 185, 129, 0.3) 0%, transparent 45%), radial-gradient(circle at 82% 82%, rgba(5, 150, 105, 0.22) 0%, transparent 45%)',
    gradHeader: ['#10b981', '#059669', '#34d399']
  },
  'celestial-cyan': {
    name: 'Celestial Cyan',
    subtitle: 'Expansive Horizons & Crystal Precision',
    primaryHex: 0x00f2fe,
    secondaryHex: 0x0284c7,
    glowHex: 0x38bdf8,
    laserHex: 0x00f2fe,
    laserCorona: 0x0284c7,
    bgGrid: 0x0284c7,
    cssColor: '#00f2fe',
    cssSecondary: '#0284c7',
    cssGlow: 'rgba(0, 242, 254, 0.45)',
    accentBg: 'rgba(0, 242, 254, 0.15)',
    swatch: 'linear-gradient(135deg, #00f2fe, #0284c7)',
    bgRadialLight: 'radial-gradient(circle at 15% 15%, rgba(0, 242, 254, 0.18) 0%, transparent 50%), radial-gradient(circle at 85% 85%, rgba(2, 132, 199, 0.14) 0%, transparent 50%)',
    bgRadialDark: 'radial-gradient(circle at 15% 15%, rgba(0, 242, 254, 0.3) 0%, transparent 45%), radial-gradient(circle at 85% 85%, rgba(2, 132, 199, 0.22) 0%, transparent 45%)',
    gradHeader: ['#00f2fe', '#38bdf8', '#0284c7']
  },
  'royal-indigo': {
    name: 'Royal Indigo',
    subtitle: 'Institutional Prestige & Tech Leadership',
    primaryHex: 0xa855f7,
    secondaryHex: 0x6366f1,
    glowHex: 0xc084fc,
    laserHex: 0xa855f7,
    laserCorona: 0x6366f1,
    bgGrid: 0x8b5cf6,
    cssColor: '#a855f7',
    cssSecondary: '#6366f1',
    cssGlow: 'rgba(168, 85, 247, 0.45)',
    accentBg: 'rgba(168, 85, 247, 0.15)',
    swatch: 'linear-gradient(135deg, #a855f7, #6366f1)',
    bgRadialLight: 'radial-gradient(circle at 15% 15%, rgba(168, 85, 247, 0.18) 0%, transparent 50%), radial-gradient(circle at 85% 85%, rgba(99, 102, 241, 0.14) 0%, transparent 50%)',
    bgRadialDark: 'radial-gradient(circle at 15% 15%, rgba(168, 85, 247, 0.3) 0%, transparent 45%), radial-gradient(circle at 85% 85%, rgba(99, 102, 241, 0.22) 0%, transparent 45%)',
    gradHeader: ['#a855f7', '#8b5cf6', '#6366f1']
  },
  'solar-horizon': {
    name: 'Solar Horizon',
    subtitle: 'Warm Energy & Forward Momentum',
    primaryHex: 0xf59e0b,
    secondaryHex: 0xf43f5e,
    glowHex: 0xfbbf24,
    laserHex: 0xf59e0b,
    laserCorona: 0xf43f5e,
    bgGrid: 0xf59e0b,
    cssColor: '#f59e0b',
    cssSecondary: '#f43f5e',
    cssGlow: 'rgba(245, 158, 11, 0.45)',
    accentBg: 'rgba(245, 158, 11, 0.15)',
    swatch: 'linear-gradient(135deg, #f59e0b, #f43f5e)',
    bgRadialLight: 'radial-gradient(circle at 15% 15%, rgba(245, 158, 11, 0.18) 0%, transparent 50%), radial-gradient(circle at 85% 85%, rgba(244, 63, 94, 0.14) 0%, transparent 50%)',
    bgRadialDark: 'radial-gradient(circle at 15% 15%, rgba(245, 158, 11, 0.3) 0%, transparent 45%), radial-gradient(circle at 85% 85%, rgba(244, 63, 94, 0.22) 0%, transparent 45%)',
    gradHeader: ['#f59e0b', '#f43f5e', '#ea580c']
  },
  'aurora-sapphire': {
    name: 'Aurora Sapphire',
    subtitle: 'Optimistic & Trustworthy Career Intelligence',
    primaryHex: 0x0284c7,
    secondaryHex: 0x2563eb,
    glowHex: 0x38bdf8,
    laserHex: 0x0284c7,
    laserCorona: 0x2563eb,
    bgGrid: 0x0284c7,
    cssColor: '#0284c7',
    cssSecondary: '#2563eb',
    cssGlow: 'rgba(2, 132, 199, 0.45)',
    accentBg: 'rgba(2, 132, 199, 0.15)',
    swatch: 'linear-gradient(135deg, #0284c7, #2563eb)',
    bgRadialLight: 'radial-gradient(circle at 15% 15%, rgba(2, 132, 199, 0.18) 0%, transparent 50%), radial-gradient(circle at 85% 85%, rgba(37, 99, 235, 0.14) 0%, transparent 50%)',
    bgRadialDark: 'radial-gradient(circle at 15% 15%, rgba(2, 132, 199, 0.3) 0%, transparent 45%), radial-gradient(circle at 85% 85%, rgba(37, 99, 235, 0.22) 0%, transparent 45%)',
    gradHeader: ['#0284c7', '#2563eb', '#6366f1']
  },
  'neon-matrix': {
    name: 'Neon Matrix',
    subtitle: 'Cyber Green & High-Tech Neural Grid',
    primaryHex: 0x22c55e,
    secondaryHex: 0x84cc16,
    glowHex: 0x4ade80,
    laserHex: 0x22c55e,
    laserCorona: 0x16a34a,
    bgGrid: 0x22c55e,
    cssColor: '#22c55e',
    cssSecondary: '#84cc16',
    cssGlow: 'rgba(34, 197, 94, 0.45)',
    accentBg: 'rgba(34, 197, 94, 0.15)',
    swatch: 'linear-gradient(135deg, #22c55e, #84cc16)',
    bgRadialLight: 'radial-gradient(circle at 15% 15%, rgba(34, 197, 94, 0.18) 0%, transparent 50%), radial-gradient(circle at 85% 85%, rgba(132, 204, 22, 0.14) 0%, transparent 50%)',
    bgRadialDark: 'radial-gradient(circle at 15% 15%, rgba(34, 197, 94, 0.3) 0%, transparent 45%), radial-gradient(circle at 85% 85%, rgba(132, 204, 22, 0.22) 0%, transparent 45%)',
    gradHeader: ['#22c55e', '#84cc16', '#16a34a']
  }
};

interface HologramThemeContextType {
  mode: ThemeMode;
  toggleMode: () => void;
  setMode: (mode: ThemeMode) => void;
  theme: ScannerTheme;
  setTheme: (theme: ScannerTheme) => void;
  colors: ThemeColors;
}

const HologramThemeContext = createContext<HologramThemeContextType | undefined>(undefined);

export const HologramThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [mode, setModeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('employai_theme_mode') as ThemeMode | null;
    return saved === 'dark' || saved === 'light' ? saved : 'dark';
  });

  const [theme, setThemeState] = useState<ScannerTheme>(() => {
    const saved = localStorage.getItem('employai_hologram_theme') as ScannerTheme | null;
    return saved && THEME_CONFIGS[saved] ? saved : 'celestial-cyan';
  });

  const colors = THEME_CONFIGS[theme] || THEME_CONFIGS['celestial-cyan'];

  const setMode = (newMode: ThemeMode) => {
    setModeState(newMode);
    localStorage.setItem('employai_theme_mode', newMode);
  };

  const toggleMode = () => {
    setMode(mode === 'light' ? 'dark' : 'light');
  };

  const setTheme = (newTheme: ScannerTheme) => {
    setThemeState(newTheme);
    localStorage.setItem('employai_hologram_theme', newTheme);
  };

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-theme', mode);
    root.style.setProperty('--hologram-primary', colors.cssColor);
    root.style.setProperty('--hologram-secondary', colors.cssSecondary);
    root.style.setProperty('--hologram-glow', colors.cssGlow);
    
    const bgRadial = mode === 'light' ? colors.bgRadialLight : colors.bgRadialDark;
    root.style.setProperty('--theme-bg-radial', bgRadial);
  }, [mode, colors]);

  return (
    <HologramThemeContext.Provider value={{ mode, toggleMode, setMode, theme, setTheme, colors }}>
      {children}
    </HologramThemeContext.Provider>
  );
};

export const useHologramTheme = () => {
  const context = useContext(HologramThemeContext);
  if (!context) {
    throw new Error('useHologramTheme must be used within a HologramThemeProvider');
  }
  return context;
};
