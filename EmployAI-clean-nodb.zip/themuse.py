import os
import re
import html
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting
from app.core.config import settings


class TheMuseProvider(JobProviderAdapter):
    """
    The Muse Open Job Search API Adapter.
    Public, license-compliant multi-domain job and internship aggregator.
    Pulls real-world verified listings across Engineering, Business, Healthcare,
    Finance, Management, Design, Legal, and Marketing.
    """

    API_URL = "https://www.themuse.com/api/public/jobs"

    def __init__(self):
        self.api_key = settings.THEMUSE_API_KEY or os.getenv("THEMUSE_API_KEY", "")

    @property
    def name(self) -> str:
        return "The Muse"

    @property
    def is_enabled(self) -> bool:
        return True

    def _strip_html(self, raw_html: str) -> str:
        if not raw_html:
            return ""
        clean = re.sub(r"<[^>]+>", " ", raw_html)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        postings: List[RawJobPosting] = []

        try:
            params = {
                "page": max(1, page),
            }
            if self.api_key:
                params["api_key"] = self.api_key

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) EmployAI/1.0",
                "Accept": "application/json"
            }

            async with httpx.AsyncClient(timeout=12.0, follow_redirects=True) as client:
                response = await client.get(self.API_URL, params=params, headers=headers)
                if response.status_code != 200:
                    print(f"[WARN] The Muse API returned status {response.status_code}")
                    return []

                payload = response.json()
                results = payload.get("results", [])

                for item in results:
                    raw_title = item.get("name", "")
                    raw_desc = self._strip_html(item.get("contents", ""))
                    comp_dict = item.get("company") or {}
                    company_name = comp_dict.get("name", "Industry Enterprise")

                    # Extract locations
                    locs = item.get("locations") or []
                    loc_str = ", ".join([loc.get("name", "") for loc in locs if loc.get("name")]) or "Global / Remote"
                    is_remote = "remote" in loc_str.lower() or "flexible" in loc_str.lower() or (remote is True)

                    # Extract categories/tags
                    categories = item.get("categories") or []
                    tags = [c.get("name", "") for c in categories if c.get("name")]

                    # Levels
                    levels = item.get("levels") or []
                    level_names = " ".join([l.get("name", "").lower() for l in levels])

                    mapped_type = "full-time"
                    exp_level = "entry"

                    title_level_text = (raw_title + " " + level_names + " " + raw_desc[:300]).lower()

                    if "intern" in title_level_text or "trainee" in title_level_text:
                        mapped_type = "internship"
                        exp_level = "intern"
                    elif "part-time" in title_level_text or "part time" in title_level_text:
                        mapped_type = "part-time"
                    elif "contract" in title_level_text or "freelance" in title_level_text:
                        mapped_type = "contract"

                    if exp_level != "intern":
                        if "senior" in title_level_text or "lead" in title_level_text or "principal" in title_level_text or "director" in title_level_text:
                            exp_level = "senior"
                        elif "mid" in title_level_text or "intermediate" in title_level_text:
                            exp_level = "mid"
                        else:
                            exp_level = "entry"

                    # Filters
                    if remote is True and not is_remote:
                        continue
                    if job_type and job_type.lower() != "all" and job_type.lower() not in mapped_type:
                        continue
                    if query:
                        q_low = query.lower()
                        in_match = (
                            q_low in raw_title.lower() or
                            q_low in raw_desc.lower() or
                            q_low in company_name.lower() or
                            any(q_low in t.lower() for t in tags)
                        )
                        if not in_match:
                            continue

                    refs = item.get("refs") or {}
                    landing_url = refs.get("landing_page")
                    if not landing_url or "themuse.com/jobs?" in landing_url or landing_url.endswith("themuse.com/jobs"):
                        import urllib.parse
                        safe_q = urllib.parse.quote(f"{company_name} {raw_title}".strip())
                        landing_url = f"https://www.themuse.com/search/jobs?q={safe_q}"

                    postings.append(RawJobPosting(
                        source_id=f"themuse-{item.get('id', raw_title)}",
                        source="The Muse",
                        title=raw_title,
                        company=company_name,
                        location=loc_str,
                        remote=is_remote,
                        job_type=mapped_type,
                        experience_level=exp_level,
                        description=raw_desc[:3000],
                        required_skills=tags,
                        apply_url=landing_url,
                        posted_date=item.get("publication_date", "Recently")[:10] if item.get("publication_date") else "Recently"
                    ))

        except Exception as e:
            print(f"[ERROR] The Muse fetch_jobs failed: {e}")

        return postings
