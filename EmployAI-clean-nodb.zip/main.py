import asyncio
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.core.database import Base, engine, SessionLocal
import app.models
from app.api.v1.router import api_router
from seeds.taxonomy_seed import seed_universal_taxonomy


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan context for startup initialization, seeding, and perpetual live sync."""
    print("[INFO] Initializing EmployAI Database & Models...")
    Base.metadata.create_all(bind=engine)
    
    # Auto-seed canonical multi-domain taxonomy, career roles, and initial job opportunities
    db = SessionLocal()
    try:
        seed_universal_taxonomy(db)
        from app.services.job_aggregator_service import JobAggregatorService
        JobAggregatorService.ensure_initial_seed(db)
    except Exception as e:
        print(f"[WARN] Seeding notice: {e}")
    finally:
        db.close()
        
    # Start perpetual background real-time sync across Cutshort, Wellfound, LinkedIn, Naukri, Remote.com, etc.
    sync_task = None
    if not os.getenv("VERCEL"):
        from app.services.job_aggregator_service import JobAggregatorService
        sync_task = asyncio.create_task(JobAggregatorService.start_periodic_background_sync(interval_seconds=120))

    yield
    print("[INFO] EmployAI Server shutting down...")
    if sync_task:
        sync_task.cancel()


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="AI-powered Academia–Industry Skill Mapping, Internships and Placement Platform for Smart India Hackathon.",
    lifespan=lifespan
)

# Configure CORS with strict allowed origins
origins = settings.ALLOWED_ORIGINS if isinstance(settings.ALLOWED_ORIGINS, list) else [settings.ALLOWED_ORIGINS]
if "https://employai-hub.vercel.app" not in origins:
    origins.append("https://employai-hub.vercel.app")

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_origin_regex=r"^https:\/\/([a-zA-Z0-9_-]+\.)?vercel\.app$",
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["X-EmployAI-Realtime", "X-EmployAI-Providers-Count", "X-EmployAI-Last-Sync", "X-Request-ID"],
)

# Security & Correlation Headers Middleware
import uuid

@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    request_id = request.headers.get("x-request-id") or str(uuid.uuid4())
    request.state.request_id = request_id

    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    # Enable HSTS for HTTPS requests
    if request.url.scheme == "https" or os.getenv("VERCEL"):
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains; preload"
    return response

# Global Exception Handlers
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail},
        headers=getattr(exc, "headers", None)
    )

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"detail": exc.errors()}
    )

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    import traceback
    if isinstance(exc, StarletteHTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail},
            headers=getattr(exc, "headers", None)
        )
    print(f"[ERROR] Unhandled Server Exception: {exc}")
    traceback.print_exc()
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "An internal server error occurred. Please try again or contact support."}
    )

# Mount API Routers
app.include_router(api_router, prefix=settings.API_V1_STR)


@app.get("/", tags=["System"])
def root():
    """Root endpoint welcoming users and directing to API documentation."""
    return {
        "message": f"Welcome to {settings.PROJECT_NAME} Backend API",
        "status": "online",
        "version": settings.VERSION,
        "docs": "/docs",
        "redoc": "/redoc",
        "health": "/health"
    }


@app.get("/health", tags=["System"])
@app.get("/api/health", tags=["System"])
@app.get("/api/v1/health", tags=["System"])
def health_check():
    """System health check endpoint."""
    return {
        "status": "online",
        "platform": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "environment": "development" if settings.DEBUG else "production"
    }


