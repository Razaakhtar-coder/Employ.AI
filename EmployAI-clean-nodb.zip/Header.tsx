import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useHologramTheme } from '../context/HologramThemeContext';
import { BrandLogo } from './BrandLogo';
import { BackendStatusPill } from './BackendStatusBanner';
import { Hamburger3LinesButton } from './Hamburger3LinesButton';
import { 
  Bell, ChevronDown, Sun, Moon,
  GraduationCap, Building2,
  LogOut, Shield, Info, Zap, LogIn
} from 'lucide-react';

export interface HeaderProps {
  onToggleSidebar?: () => void;
  isSidebarOpen?: boolean;
  onNavigate?: (tab: string) => void;
  currentTab?: string;
}

const HeaderComponent: React.FC<HeaderProps> = ({ onToggleSidebar, isSidebarOpen = false, onNavigate, currentTab }) => {
  const { 
    user, isAuthenticated, logout, openAuthModal, 
    studentProfile, academicProfile, 
    isPremium, isAdmin, openSubscriptionModal, openAdminPaymentsModal 
  } = useAuth();
  const { mode, toggleMode } = useHologramTheme();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const getRoleBadge = (role?: string) => {
    switch (role) {
      case 'academia':
        return { label: 'Academia & TPO', icon: Building2, color: 'badge-amber' };
      case 'admin':
        return { label: 'Administrator', icon: Shield, color: 'badge-violet' };
      default:
        return { label: 'Student Portal', icon: GraduationCap, color: 'badge-cyan' };
    }
  };

  const roleInfo = getRoleBadge(user?.role);
  const RoleIcon = roleInfo.icon;

  const getSubtitle = () => {
    if (!user) return 'Explore EmployAI Ecosystem';
    if (user.role === 'academia') return academicProfile?.institution_name || academicProfile?.department || 'Institutional Command Center';
    return studentProfile?.institution_name || studentProfile?.department || 'Student Workspace';
  };

  return (
    <header className="no-print" style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0.75rem 1.5rem',
      backgroundColor: 'var(--bg-secondary)',
      borderBottom: '1px solid var(--border-subtle)',
      position: 'sticky',
      top: 0,
      zIndex: 100,
      backdropFilter: 'blur(12px)',
      boxShadow: 'var(--shadow-sm)'
    }}>
      {/* Left: 3-Lines Menu Trigger + Brand Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
        <Hamburger3LinesButton 
          isOpen={isSidebarOpen} 
          onClick={onToggleSidebar || (() => {})} 
          title="Toggle Navigation Sidebar (3 Lines)" 
        />
        <BrandLogo size={36} badgeText="3D Engine" />
      </div>

      {/* Right Actions: Theme Toggle + Backend Status + PRO / Admin + Role Switcher / Auth */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        
        {/* Live Backend Connection Indicator */}
        <div className="header-hide-mobile">
          <BackendStatusPill />
        </div>
        
        {/* Light/Dark Mode Switcher */}
        <button
          onClick={toggleMode}
          className="btn btn-secondary"
          style={{
            padding: '0.45rem 0.65rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.35rem',
            borderRadius: 'var(--radius-sm)',
            fontSize: '0.8rem',
            fontWeight: 700,
            cursor: 'pointer'
          }}
          title={`Switch to ${mode === 'light' ? 'Dark' : 'Light'} Mode`}
        >
          {mode === 'light' ? (
            <>
              <Sun size={15} color="#d97706" />
              <span className="header-hide-mobile">Light</span>
            </>
          ) : (
            <>
              <Moon size={15} color="#38bdf8" />
              <span className="header-hide-mobile">Dark</span>
            </>
          )}
        </button>

        {/* About Employ.AI Quick Link */}
        {onNavigate && (
          <button
            onClick={() => onNavigate('about')}
            className="btn btn-secondary"
            style={{
              padding: '0.45rem 0.65rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
              borderRadius: 'var(--radius-sm)',
              fontSize: '0.8rem',
              fontWeight: 700,
              cursor: 'pointer',
              backgroundColor: currentTab === 'about' ? 'rgba(56, 189, 248, 0.15)' : undefined,
              borderColor: currentTab === 'about' ? 'var(--accent-cyan)' : undefined,
              color: currentTab === 'about' ? 'var(--accent-cyan)' : undefined,
              boxShadow: currentTab === 'about' ? '0 0 10px rgba(56, 189, 248, 0.25)' : undefined
            }}
            title="About Employ.AI Platform"
          >
            <Info size={15} color="var(--accent-cyan)" />
            <span className="header-hide-mobile">About</span>
          </button>
        )}

        {/* Super Admin Payment Approval Button (Strictly for akhtarrakeeb52@gmail.com) */}
        {isAuthenticated && isAdmin && (
          <button
            onClick={openAdminPaymentsModal}
            className="btn btn-outline-cyan"
            style={{
              padding: '0.45rem 0.85rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.45rem',
              borderRadius: 'var(--radius-sm)',
              fontSize: '0.8rem',
              fontWeight: 800,
              cursor: 'pointer',
              borderColor: 'var(--accent-purple)',
              color: 'var(--accent-purple)',
              background: 'rgba(168, 85, 247, 0.12)',
              boxShadow: '0 0 12px rgba(168, 85, 247, 0.25)'
            }}
            title="Manage User UPI Payment Verifications"
          >
            <Shield size={14} color="var(--accent-purple)" />
            <span>Admin Approvals</span>
          </button>
        )}

        {/* PRO Subscription Trigger Button for Regular Users */}
        {isAuthenticated && !isAdmin && (
          isPremium ? (
            <div 
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.4rem',
                padding: '0.4rem 0.75rem',
                borderRadius: '8px',
                background: 'rgba(16, 185, 129, 0.12)',
                border: '1px solid rgba(16, 185, 129, 0.35)',
                color: 'var(--accent-emerald)',
                fontSize: '0.75rem',
                fontWeight: 800,
                letterSpacing: '0.04em',
                cursor: 'pointer'
              }}
              onClick={openSubscriptionModal}
              title={
                user?.days_remaining
                  ? `Employ.AI PRO Active (${user.days_remaining} days remaining · ${user.subscription_plan === 'annual' ? 'Annual Plan' : 'Monthly Plan'})`
                  : "Employ.AI PRO Active"
              }
            >
              <span>💎 PRO ACTIVE</span>
              {typeof user?.days_remaining === 'number' && user.days_remaining > 0 && user.days_remaining < 999 && (
                <span style={{ fontSize: '0.68rem', opacity: 0.9, fontWeight: 700 }}>
                  ({user.days_remaining}d)
                </span>
              )}
            </div>
          ) : (
            <button
              onClick={openSubscriptionModal}
              className="btn btn-primary"
              style={{
                padding: '0.45rem 0.85rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.4rem',
                borderRadius: 'var(--radius-sm)',
                fontSize: '0.8rem',
                fontWeight: 800,
                cursor: 'pointer',
                boxShadow: user?.is_expired ? '0 0 16px rgba(245, 158, 11, 0.45)' : 'var(--glow-cyan)',
                border: user?.is_expired ? '1px solid rgba(245, 158, 11, 0.6)' : undefined,
                background: user?.is_expired ? 'linear-gradient(135deg, #f59e0b, #d97706)' : undefined
              }}
              title={user?.is_expired ? "Your subscription has expired. Click to renew." : "Upgrade to Employ.AI PRO (₹49/mo or ₹499/yr)"}
            >
              <Zap size={14} />
              <span>{user?.is_expired ? 'Renew PRO' : 'Upgrade to PRO'}</span>
            </button>
          )
        )}

        {isAuthenticated && user ? (
          <>
            {/* Account & Role Switcher Dropdown */}
            <div style={{ position: 'relative' }}>
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="btn btn-secondary"
                style={{
                  padding: '0.45rem 0.75rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.45rem',
                  borderRadius: 'var(--radius-sm)',
                  fontSize: '0.8rem'
                }}
              >
                <RoleIcon size={15} style={{ color: 'var(--accent-cyan)' }} />
                <span style={{ maxWidth: '140px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontWeight: 700 }}>{user.full_name}</span>
                <ChevronDown size={13} style={{ transform: dropdownOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
              </button>

              {dropdownOpen && (
                <div
                  className="glass-card"
                  style={{
                    position: 'absolute',
                    top: 'calc(100% + 8px)',
                    right: 0,
                    width: '280px',
                    padding: '0.75rem',
                    zIndex: 200,
                    boxShadow: 'var(--shadow-lg)',
                    border: '1px solid var(--border-glass)'
                  }}
                >
                  <div style={{ padding: '0.4rem 0.5rem', borderBottom: '1px solid var(--border-subtle)', marginBottom: '0.5rem' }}>
                    <p style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                      {user.full_name}
                    </p>
                    <p style={{ fontSize: '0.725rem', color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {user.email}
                    </p>
                    <span className={`badge ${roleInfo.color}`} style={{ fontSize: '0.65rem', marginTop: '0.3rem' }}>
                      {roleInfo.label}
                    </span>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                    <button
                      onClick={() => {
                        setDropdownOpen(false);
                        openAuthModal();
                      }}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.5rem',
                        padding: '0.55rem',
                        borderRadius: '6px',
                        background: 'transparent',
                        border: 'none',
                        color: 'var(--text-secondary)',
                        fontSize: '0.8rem',
                        cursor: 'pointer',
                        textAlign: 'left'
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(255, 255, 255, 0.05)'}
                      onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                      </svg>
                      <span>Switch Google Account</span>
                    </button>


                    <button
                      onClick={() => {
                        setDropdownOpen(false);
                        logout();
                      }}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.5rem',
                        padding: '0.55rem',
                        borderRadius: '6px',
                        background: 'rgba(244, 63, 94, 0.08)',
                        border: '1px solid rgba(244, 63, 94, 0.2)',
                        color: '#fb7185',
                        fontSize: '0.8rem',
                        cursor: 'pointer',
                        textAlign: 'left',
                        marginTop: '0.25rem'
                      }}
                    >
                      <LogOut size={14} />
                      <span>Log Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Notifications */}
            <button
              className="btn btn-secondary header-hide-mobile"
              style={{ padding: '0.5rem', borderRadius: '50%', width: '36px', height: '36px' }}
              title="Notifications"
            >
              <Bell size={16} color="var(--text-secondary)" />
            </button>

            {/* Active Profile Info */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.55rem', paddingLeft: '0.4rem', borderLeft: '1px solid var(--border-subtle)' }}>
              <div style={{
                width: '34px',
                height: '34px',
                borderRadius: '50%',
                background: 'var(--grad-primary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: 700,
                color: '#030712',
                fontSize: '0.85rem',
                border: '2px solid var(--accent-cyan)'
              }}>
                {user.full_name?.charAt(0) || 'U'}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column' }} className="header-user-details">
                <span style={{ fontSize: '0.825rem', fontWeight: 700, color: 'var(--text-primary)' }}>
                  {user.full_name}
                </span>
                <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)' }}>
                  {getSubtitle()}
                </span>
              </div>
            </div>
          </>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <button 
              onClick={() => openAuthModal()} 
              className="btn btn-primary btn-sm"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                fontWeight: 700
              }}
            >
              <LogIn size={15} />
              <span>Sign In / Register</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
};

export const Header = React.memo(HeaderComponent);
