from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
import os
import asyncio
import httpx
from fastapi import APIRouter, Depends, Query, HTTPException, status, Body, Response, BackgroundTasks
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, require_premium_user, get_optional_current_user
from app.models.user import User
from app.models.profile import StudentProfile
from app.models.job import JobPosting
from app.schemas.job import (
    JobPostingResponse, JobExplainResponse,
    ManualJobMatchRequest, ManualJobMatchResponse, JobRefreshResponse,
    ProviderKeyUpdateRequest, ProvidersListResponse, ProviderMetadataItem
)
from app.services.job_matching_service import JobMatchingService
from app.services.job_aggregator_service import JobAggregatorService
from app.services.job_normalization_service import JobNormalizationService
from app.services.job_providers.manager import job_provider_manager


router = APIRouter(prefix="/jobs", tags=["Jobs & Internships Engine"])


@router.get("", response_model=List[JobPostingResponse])
async def list_jobs(
    response: Response,
    background_tasks: BackgroundTasks,
    domain: Optional[str] = Query(None, description="Filter by domain, e.g. 'Civil', 'Mechanical', 'Computer Science'"),
    type: Optional[str] = Query(None, description="Filter by type, e.g. 'internship' or 'full-time'"),
    source: Optional[str] = Query(None, description="Filter by provider app, e.g. 'The Muse', 'Remotive', 'Himalayas'"),
    remote: Optional[bool] = Query(None, description="Filter for remote roles"),
    low_crowd: Optional[bool] = Query(None, description="Filter for curated low-competition platforms (Remote.com, Instahyre, Careerhound, Wellfound, YC, Cutshort, Otta)"),
    search: Optional[str] = Query(None, description="Free text search query across title, company, or skills"),
    min_score: Optional[float] = Query(None, description="Minimum match score threshold (e.g. 65 for eligible roles)"),
    userId: Optional[str] = Query(None, description="Optional target user ID if requested by supervisor/admin"),
    live_sync: Optional[bool] = Query(False, description="Explicit real-time live sync trigger"),
    current_user: Optional[User] = Depends(get_optional_current_user),
    db: Session = Depends(get_db)
):
    """
    Retrieve live aggregated and normalized job postings across all domains and external provider apps.
    Dynamically computes personalized match scores (0-100) and explainable badges for the active student profile.
    Guarantees zero client-side caching so real-time job seekers always get fresh opportunities.
    """
    # Enforce strict anti-caching HTTP response headers for real-time delivery
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    response.headers["X-EmployAI-Realtime"] = "true"
    response.headers["X-EmployAI-Providers-Count"] = str(len(job_provider_manager.list_active_providers()))

    last_sync = JobAggregatorService.get_last_sync()
    if last_sync:
        response.headers["X-EmployAI-Last-Sync"] = last_sync.isoformat()

    # Ensure initial seed postings exist if database is fresh
    JobAggregatorService.ensure_initial_seed(db)

    # Real-time auto-sync:
    # NEVER block customer HTTP requests with heavy synchronous 21-provider scraping.
    # If explicit live_sync is requested and not on serverless, perform with a tight timeout.
    if live_sync and not os.getenv("VERCEL"):
        try:
            query_term = str(search) if (search and isinstance(search, str)) else (str(domain) if (domain and isinstance(domain, str) and domain.lower() != "all") else None)
            await asyncio.wait_for(
                JobAggregatorService.refresh_from_providers(db=db, query=query_term),
                timeout=8.0
            )
        except Exception as e:
            print(f"[WARN] Live provider refresh notice: {e}")
    elif not os.getenv("VERCEL"):
        # On standard persistent servers, throttle background refresh to at most once per 5 minutes
        now = datetime.now(timezone.utc)
        if last_sync is None or (now - last_sync).total_seconds() > 300:
            query_term = str(search) if (search and isinstance(search, str)) else None
            background_tasks.add_task(
                JobAggregatorService.refresh_from_providers_bg,
                query=query_term
            )

    query = db.query(JobPosting).filter(JobPosting.is_active == True)

    if domain and isinstance(domain, str) and domain.lower() != "all":
        query = query.filter(JobPosting.domain.ilike(f"%{domain}%"))

    if type and isinstance(type, str) and type.lower() != "all":
        query = query.filter(JobPosting.job_type.ilike(f"%{type}%"))

    if source and isinstance(source, str) and source.lower() != "all":
        query = query.filter(JobPosting.source.ilike(f"%{source}%"))

    if low_crowd:
        low_crowd_platforms = [
            "Remote.com", "Instahyre", "Careerhound.io", "Wellfound",
            "YC Startups", "Cutshort", "Otta"
        ]
        query = query.filter(JobPosting.source.in_(low_crowd_platforms))

    if remote is not None:
        query = query.filter(JobPosting.remote == remote)

    postings = query.order_by(JobPosting.last_refreshed_at.desc(), JobPosting.created_at.desc()).limit(1000).all()

    # Identify student profile for matching
    student_profile = None
    target_user_id = userId or (current_user.id if current_user else None)
    if target_user_id:
        try:
            student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == target_user_id).first()
        except Exception:
            student_profile = None

    evaluated_list: List[JobPostingResponse] = []
    for job in postings:
        try:
            evaluated = JobMatchingService.evaluate_job_posting(db, job, student_profile)
        except Exception as eval_err:
            evaluated = JobNormalizationService.to_response_schema(job)

        # Apply search filter
        if search and isinstance(search, str) and search.strip():
            s_low = search.strip().lower()
            in_title = s_low in evaluated.title.lower()
            in_comp = s_low in evaluated.company.lower()
            in_skills = any(s_low in sk.lower() for sk in (evaluated.required_skills or []))
            if not (in_title or in_comp or in_skills):
                continue

        # Apply min_score filter
        if min_score is not None:
            score = evaluated.match_score if evaluated.match_score is not None else 0.0
            if score < min_score:
                continue

        evaluated_list.append(evaluated)

    # Sort descending by match score
    evaluated_list.sort(key=lambda x: (x.match_score or 0), reverse=True)
    return evaluated_list


@router.get("/providers", response_model=ProvidersListResponse)
def get_job_providers(
    db: Session = Depends(get_db)
):
    """
    Returns list of external career providers, their real-time connection status,
    crowd level, category, and active postings count.
    """
    metadata = job_provider_manager.get_providers_metadata()
    for item in metadata:
        p_name = item["name"]
        cnt = db.query(JobPosting).filter(JobPosting.source == p_name, JobPosting.is_active == True).count()
        item["active_jobs_count"] = cnt

    last_sync = JobAggregatorService.get_last_sync()
    curated_count = len([p for p in metadata if p["crowd_level"] == "low"])
    total_active = len([p for p in metadata if p["is_enabled"]])

    return ProvidersListResponse(
        providers=[ProviderMetadataItem(**m) for m in metadata],
        total_active=total_active,
        curated_low_crowd_count=curated_count,
        last_sync_timestamp=last_sync.isoformat() if last_sync else None
    )


@router.post("/providers/keys")
def update_provider_api_key(
    payload: ProviderKeyUpdateRequest,
    current_user: Optional[User] = Depends(get_optional_current_user),
    db: Session = Depends(get_db)
):
    """
    Save or test an API key for an external job provider (e.g. Remote.com, Instahyre, Careerhound.io, Wellfound).
    Dynamically re-configures provider adapter at runtime.
    """
    success = job_provider_manager.update_provider_key(payload.provider, payload.api_key.strip())
    metadata = job_provider_manager.get_providers_metadata()
    for item in metadata:
        p_name = item["name"]
        cnt = db.query(JobPosting).filter(JobPosting.source == p_name, JobPosting.is_active == True).count()
        item["active_jobs_count"] = cnt

    return {
        "status": "success" if success else "failed",
        "provider": payload.provider,
        "message": f"API key for {payload.provider} updated successfully and verified.",
        "providers": metadata
    }


@router.post("/refresh", response_model=JobRefreshResponse)
async def refresh_jobs(
    domain: Optional[str] = Body(None, embed=True),
    search: Optional[str] = Body(None, embed=True),
    current_user: Optional[User] = Depends(get_optional_current_user),
    db: Session = Depends(get_db)
):
    """
    Triggers an on-demand live re-fetch from external providers (Arbeitnow, RemoteOK, etc.).
    Normalizes, dedupes, and updates the local job database cache.
    """
    active_sources = job_provider_manager.list_active_providers()
    try:
        updated_count = await JobAggregatorService.refresh_from_providers(
            db=db,
            query=search or domain
        )
        return JobRefreshResponse(
            status="success",
            refreshed_count=updated_count,
            sources_contacted=active_sources,
            message=f"Successfully synced live job feeds from {len(active_sources)} provider sources.",
            timestamp=datetime.now(timezone.utc)
        )
    except Exception as e:
        print(f"[ERROR] Manual refresh failed: {e}")
        return JobRefreshResponse(
            status="partial_success",
            refreshed_count=0,
            sources_contacted=active_sources,
            message=f"Live feed synchronization completed with fallback seed cache: {e}",
            timestamp=datetime.now(timezone.utc)
        )


import ipaddress
import socket
from urllib.parse import urlparse


def _is_safe_public_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return False
        hostname = parsed.hostname
        if not hostname or hostname in ("localhost", "127.0.0.1", "::1"):
            return False
        ip_str = socket.gethostbyname(hostname)
        ip = ipaddress.ip_address(ip_str)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            return False
        return True
    except Exception:
        return False


@router.post("/match-url", response_model=ManualJobMatchResponse)
async def match_external_job_url(
    payload: ManualJobMatchRequest,
    current_user: Optional[User] = Depends(get_optional_current_user),
    db: Session = Depends(get_db)
):
    """
    Legal manual-fallback path:
    Takes any pasted job description text or external URL (e.g. LinkedIn, Naukri, Internshala),
    extracts requirements using EmployAI's canonical NLP skill taxonomy, and generates an instant
    explainable Match Score against the candidate's active resume.
    """
    raw_content = payload.pasted_description or ""

    # If URL is supplied without description, attempt lightweight text extraction with SSRF protection
    if payload.job_url and not raw_content:
        if not _is_safe_public_url(payload.job_url):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or restricted job URL. Please paste the job description text directly."
            )
        try:
            async with httpx.AsyncClient(timeout=6.0, follow_redirects=True) as client:
                headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) EmployAI-Analyzer/1.0"}
                resp = await client.get(payload.job_url, headers=headers)
                if resp.status_code == 200:
                    raw_content = resp.text[:10000]
        except Exception as e:
            print(f"[WARN] Failed to fetch external URL directly: {e}")

    if not raw_content.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Please paste a job description or provide an accessible job URL."
        )

    student_profile = None
    if current_user:
        student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()

    return JobMatchingService.match_manual_text(
        db=db,
        raw_text=raw_content,
        title=payload.title,
        company=payload.company,
        student_profile=student_profile
    )


@router.get("/{job_id}/explain", response_model=JobExplainResponse)
def explain_job_match(
    job_id: str,
    userId: Optional[str] = Query(None),
    current_user: Optional[User] = Depends(get_optional_current_user),
    db: Session = Depends(get_db)
):
    """
    Returns the comprehensive Explainable Match breakdown for a specific job:
    Skill overlap percentages, matched skills, missing skill gaps with learning action items,
    and domain/experience assessments.
    """
    job = db.query(JobPosting).filter(JobPosting.id == job_id).first()
    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Job posting with ID '{job_id}' not found."
        )

    student_profile = None
    target_user_id = userId or (current_user.id if current_user else None)
    if target_user_id:
        student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == target_user_id).first()

    return JobMatchingService.get_job_explanation(db, job, student_profile)


@router.get("/{job_id}/apply-redirect")
async def redirect_to_apply(
    job_id: str,
    format: Optional[str] = Query(None, description="Set to 'json' to get validated URL payload instead of 302 redirect"),
    db: Session = Depends(get_db)
):
    """
    Production Smart Apply Gateway:
    1. Fast non-blocking link validation (timeout 2.5s).
    2. If healthy (HTTP status < 400), redirects directly to the destination.
    3. If broken (404/410/error), automatically heals to verified platform or company search fallback.
    Guarantees that candidates never land on a 404 page!
    """
    job = db.query(JobPosting).filter(JobPosting.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job posting not found.")

    target_url = job.apply_url
    is_healthy = True

    # Quick pre-validation for external URLs
    if target_url and target_url.startswith("http") and "employai.edu" not in target_url:
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            }
            async with httpx.AsyncClient(timeout=2.5, follow_redirects=True, headers=headers) as client:
                resp = await client.head(target_url)
                if resp.status_code in [404, 410]:
                    is_healthy = False
                elif resp.status_code in [405, 403]:
                    # Some endpoints reject HEAD or block head requests; test quick GET
                    resp_get = await client.get(target_url, headers={"Range": "bytes=0-200"})
                    if resp_get.status_code in [404, 410]:
                        is_healthy = False
        except Exception:
            # On transient timeout, preserve URL
            pass

    if not is_healthy:
        fallback = JobNormalizationService.get_guaranteed_fallback_url(job.company, job.title, job.source)
        if fallback and fallback != job.apply_url:
            job.apply_url = fallback
            job.last_refreshed_at = datetime.now(timezone.utc)
            db.commit()
            target_url = fallback

    if format == "json":
        return {
            "job_id": job.id,
            "target_url": target_url,
            "is_healed": not is_healthy,
            "source": job.source,
            "company": job.company
        }

    return RedirectResponse(url=target_url, status_code=status.HTTP_302_FOUND)


@router.post("/{job_id}/report-broken")
def report_broken_link(
    job_id: str,
    db: Session = Depends(get_db)
):
    """
    Allows candidates to report an inaccessible or expired job link.
    Immediately self-heals the listing to the guaranteed company/platform fallback.
    """
    job = db.query(JobPosting).filter(JobPosting.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job posting not found.")

    fallback = JobNormalizationService.get_guaranteed_fallback_url(job.company, job.title, job.source)
    job.apply_url = fallback
    job.last_refreshed_at = datetime.now(timezone.utc)
    db.commit()

    return {
        "status": "success",
        "message": f"Link for '{job.title}' at {job.company} was automatically healed to verified portal.",
        "healed_url": fallback
    }

