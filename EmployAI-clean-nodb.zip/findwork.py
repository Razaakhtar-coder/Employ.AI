import os
import re
import html
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting
from app.core.config import settings


class FindworkProvider(JobProviderAdapter):
    """
    Findwork Job Board API Adapter.
    Pulls live engineering, software, product, and devops positions.
    Supports optional FINDWORK_API_KEY token or open fallback.
    """

    API_URL = "https://findwork.dev/api/jobs/"

    def __init__(self):
        self.api_key = settings.FINDWORK_API_KEY or os.getenv("FINDWORK_API_KEY", "")

    @property
    def name(self) -> str:
        return "Findwork"

    @property
    def is_enabled(self) -> bool:
        return True

    def _strip_html(self, raw_html: str) -> str:
        if not raw_html:
            return ""
        clean = re.sub(r"<[^>]+>", " ", raw_html)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        postings: List[RawJobPosting] = []

        try:
            params = {}
            if query:
                params["search"] = query
            if location:
                params["location"] = location
            if remote is not None:
                params["remote"] = "true" if remote else "false"

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) EmployAI/1.0",
                "Accept": "application/json"
            }
            if self.api_key:
                headers["Authorization"] = f"Token {self.api_key}"

            async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as client:
                response = await client.get(self.API_URL, params=params, headers=headers)
                if response.status_code != 200:
                    return []

                payload = response.json()
                results = payload.get("results", []) if isinstance(payload, dict) else (payload if isinstance(payload, list) else [])

                for item in results:
                    raw_title = item.get("role", "") or item.get("title", "")
                    raw_desc = self._strip_html(item.get("text", "") or item.get("description", ""))
                    company_name = item.get("company_name", "Innovative Tech Co.")
                    loc = item.get("location", "Global / Remote")
                    is_remote = bool(item.get("remote", False)) or "remote" in loc.lower()
                    tags = item.get("keywords") or []

                    emp_type = (item.get("employment_type") or "full-time").lower()
                    mapped_type = "full-time"
                    if "intern" in emp_type or "intern" in raw_title.lower() or "trainee" in raw_title.lower():
                        mapped_type = "internship"
                    elif "part" in emp_type:
                        mapped_type = "part-time"
                    elif "contract" in emp_type:
                        mapped_type = "contract"

                    exp_level = "entry"
                    if mapped_type == "internship":
                        exp_level = "intern"
                    elif re.search(r"\b(senior|lead|principal|staff|architect)\b", raw_title.lower()):
                        exp_level = "senior"
                    elif re.search(r"\b(mid|intermediate)\b", raw_title.lower()):
                        exp_level = "mid"

                    postings.append(RawJobPosting(
                        source_id=f"findwork-{item.get('id', raw_title)}",
                        source="Findwork",
                        title=raw_title,
                        company=company_name,
                        location=loc,
                        remote=is_remote,
                        job_type=mapped_type,
                        experience_level=exp_level,
                        description=raw_desc[:2500],
                        required_skills=tags,
                        apply_url=item.get("url") or "https://findwork.dev",
                        posted_date=str(item.get("date_posted") or "Recently")[:10]
                    ))

        except Exception as e:
            print(f"[WARN] Findwork fetch_jobs notice: {e}")

        return postings
