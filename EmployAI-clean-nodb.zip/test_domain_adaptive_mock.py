import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import json
from app.services.interview_service import InterviewService

print("================================================================================")
print("TEST 1: Verify Domain Purity for 'Management & Business Specialist' Resume")
print("================================================================================")

mgmt_facts = {
    "has_resume": True,
    "skills": ["Strategic Planning", "Market Research", "CRM", "Budgeting", "KPI Dashboards", "Operations Management"],
    "projects": [
        {
            "title": "Supply Chain Process Optimization",
            "role_or_tech": "Operations & Agile",
            "description": "Streamlined warehouse fulfillment cycle by 28% and reduced inventory holding costs by $150K."
        },
        {
            "title": "Enterprise CRM & Retention Overhaul",
            "role_or_tech": "Salesforce & Analytics",
            "description": "Implemented automated customer lifecycle workflows, increasing customer retention by 18%."
        }
    ],
    "experience": [
        {
            "company_or_org": "Apex Strategy Consulting",
            "role": "Management & Business Specialist",
            "highlights": ["Delivered executive strategic advisory across 4 business units."]
        }
    ],
    "domain": "Management & Business"
}

# Forbidden software development words for a pure business/management profile
forbidden_tech_terms = ["api key", "apis", "redis", "async/await", "b-tree", "database indexing", "fastapi", "react", "docker", "xss", "csrf", "concurrency", "thread safety", "memory leak", "app development"]

# 1. Project Deep-Dive Mode for Business Resume
proj_qs = InterviewService.generate_interview_questions(
    facts=mgmt_facts,
    target_role="Management & Business Specialist",
    interview_type="project_deepdive",
    difficulty="intermediate",
    num_questions=4
)
print(f"\n[Management: Project Deep-Dive] Generated {len(proj_qs)} questions:")
for q in proj_qs:
    q_text = q['question'].lower()
    print(f"  • Category: {q['category']} | Ref: {q['resume_reference']}")
    print(f"    Q: {q['question']}")
    for bad_w in forbidden_tech_terms:
        assert bad_w not in q_text, f"Domain Violation! Forbidden term '{bad_w}' found in business question: {q['question']}"
    assert "Supply Chain Process Optimization" in q['question'] or "Enterprise CRM & Retention Overhaul" in q['question']

# 2. Technical / Domain Mastery Mode for Business Resume
tech_qs = InterviewService.generate_interview_questions(
    facts=mgmt_facts,
    target_role="Management & Business Specialist",
    interview_type="technical",
    difficulty="intermediate",
    num_questions=4
)
print(f"\n[Management: Domain Mastery] Generated {len(tech_qs)} questions:")
for q in tech_qs:
    q_text = q['question'].lower()
    print(f"  • Category: {q['category']} | Ref: {q['resume_reference']}")
    print(f"    Q: {q['question']}")
    for bad_w in forbidden_tech_terms:
        assert bad_w not in q_text, f"Domain Violation! Forbidden term '{bad_w}' found in business question: {q['question']}"

# 3. Behavioral STAR Mode for Business Resume
star_qs = InterviewService.generate_interview_questions(
    facts=mgmt_facts,
    target_role="Management & Business Specialist",
    interview_type="behavioral_star",
    difficulty="intermediate",
    num_questions=4
)
print(f"\n[Management: Behavioral STAR] Generated {len(star_qs)} questions:")
for q in star_qs:
    q_text = q['question'].lower()
    print(f"  • Category: {q['category']} | Ref: {q['resume_reference']}")
    print(f"    Q: {q['question']}")
    for bad_w in forbidden_tech_terms:
        assert bad_w not in q_text, f"Domain Violation! Forbidden term '{bad_w}' found in business question: {q['question']}"

# 4. Comprehensive Mode for Business Resume
comp_qs = InterviewService.generate_interview_questions(
    facts=mgmt_facts,
    target_role="Management & Business Specialist",
    interview_type="comprehensive",
    difficulty="intermediate",
    num_questions=5
)
print(f"\n[Management: Comprehensive Mode] Generated {len(comp_qs)} questions:")
for q in comp_qs:
    q_text = q['question'].lower()
    print(f"  • Category: {q['category']} | Ref: {q['resume_reference']}")
    print(f"    Q: {q['question']}")
    for bad_w in forbidden_tech_terms:
        assert bad_w not in q_text, f"Domain Violation! Forbidden term '{bad_w}' found in business question: {q['question']}"

print("\n================================================================================")
print("TEST 2: Verify Accuracy-Based Evaluation for Business Questions")
print("================================================================================")

business_q = [q for q in tech_qs if "swot" in q['question'].lower() or "strategic" in q['question'].lower()][0] if any("swot" in q['question'].lower() or "strategic" in q['question'].lower() for q in tech_qs) else tech_qs[0]
print(f"Question under test: {business_q['question']}")

# A. Concise, highly accurate business answer (~30 words)
concise_mgmt_answer = "I utilize SWOT and Porter's Five Forces to evaluate competitive positioning and industry dynamics, stress-testing our strategy by modeling scenario risks, establishing clear OKRs, and tracking ROI metrics."
eval_mgmt = InterviewService.evaluate_answer(business_q, concise_mgmt_answer, target_role="Management & Business Specialist")
print("\nA. Accurate Business Answer Evaluation:")
print(f"   Score: {eval_mgmt['score']}/100 | Verdict: {eval_mgmt['verdict']} | Is Correct: {eval_mgmt['is_correct']}")
assert eval_mgmt['score'] >= 75.0, f"Expected accurate business answer to score >= 75, got {eval_mgmt['score']}"
assert eval_mgmt['is_correct'] is True

# B. Verbose fluff answer
fluff_mgmt_answer = "In my view business is all about synergy and working dynamically as a team to make sure everyone is happy and striving for the best possible quality and perfection every single day in the office."
eval_fluff = InterviewService.evaluate_answer(business_q, fluff_mgmt_answer, target_role="Management & Business Specialist")
print("\nB. Verbose Fluff Evaluation:")
print(f"   Score: {eval_fluff['score']}/100 | Verdict: {eval_fluff['verdict']} | Is Correct: {eval_fluff['is_correct']}")
assert eval_fluff['score'] <= 35.0, f"Expected fluff answer to score <= 35, got {eval_fluff['score']}"

# C. Trivial non-answer
eval_trivial = InterviewService.evaluate_answer(business_q, "business done", target_role="Management & Business Specialist")
print("\nC. Trivial Non-Answer Evaluation:")
print(f"   Score: {eval_trivial['score']}/100 | Verdict: {eval_trivial['verdict']} | Is Correct: {eval_trivial['is_correct']}")
assert eval_trivial['score'] == 0.0
assert eval_trivial['is_correct'] is False

print("\n================================================================================")
print("TEST 3: Verify Cross-Domain Purity (Finance, Civil Engineering, Law)")
print("================================================================================")

# 1. Finance Resume
fin_facts = {
    "has_resume": True,
    "skills": ["Financial Accounting", "GST Compliance", "Auditing", "Financial Modeling"],
    "projects": [{"title": "Corporate Tax & Audit Restructuring", "role_or_tech": "Taxation & GAAP"}],
    "experience": [],
    "domain": "Finance & Commerce"
}
fin_qs = InterviewService.generate_interview_questions(facts=fin_facts, target_role="Financial Analyst", interview_type="technical", difficulty="intermediate", num_questions=3)
print(f"\n[Finance Questions] Generated {len(fin_qs)}:")
for q in fin_qs:
    print(f"  • {q['question']}")
    for bad_w in forbidden_tech_terms:
        assert bad_w not in q['question'].lower(), f"Domain violation in finance: {q['question']}"

# 2. Civil Engineering Resume
civil_facts = {
    "has_resume": True,
    "skills": ["Structural Analysis", "Revit & BIM", "STAAD.Pro", "Concrete Design"],
    "projects": [{"title": "Multi-Storey Commercial Complex", "role_or_tech": "STAAD.Pro & IS Codes"}],
    "experience": [],
    "domain": "Civil Engineering"
}
civil_qs = InterviewService.generate_interview_questions(facts=civil_facts, target_role="Structural Engineer", interview_type="technical", difficulty="intermediate", num_questions=3)
print(f"\n[Civil Engineering Questions] Generated {len(civil_qs)}:")
for q in civil_qs:
    print(f"  • {q['question']}")
    for bad_w in forbidden_tech_terms:
        assert bad_w not in q['question'].lower(), f"Domain violation in civil: {q['question']}"

# 3. Law & Legal Resume
law_facts = {
    "has_resume": True,
    "skills": ["Corporate Law", "Contract Drafting", "Intellectual Property", "Litigation"],
    "projects": [{"title": "Cross-Border Commercial M&A Advisory", "role_or_tech": "Corporate Law & Due Diligence"}],
    "experience": [],
    "domain": "Law & Legal"
}
law_qs = InterviewService.generate_interview_questions(facts=law_facts, target_role="Corporate Legal Counsel", interview_type="technical", difficulty="intermediate", num_questions=3)
print(f"\n[Law & Legal Questions] Generated {len(law_qs)}:")
for q in law_qs:
    print(f"  • {q['question']}")
    for bad_w in forbidden_tech_terms:
        assert bad_w not in q['question'].lower(), f"Domain violation in law: {q['question']}"

print("\n================================================================================")
print(">>> ALL DOMAIN-ADAPTIVE ACCURACY & PURITY TESTS PASSED (100%) <<<")
print("================================================================================")
