import type { DomainPhaseVideoMap } from './domainYouTubeData';

// ============================================================================
// Process & Transport Engineering 5-Phase YouTube Registry
// Covers Chemical Engineering, Biotechnology, Marine Engineering, and Aeronautical
// Phase 0: Foundations & Governing Physical Laws
// Phase 1: Applied Modeling, Flowsheets & Simulation
// Phase 2: Unit Operations, Control & Scale-Up Optimization
// Phase 3: Flagship Capstone, Pilot Plant & Regulatory Systems
// Phase 4: Professional Screening, Industrial Viva & Placement Prep
// ============================================================================

export const PROCESS_TRANSPORT_YOUTUBE_REGISTRY: Record<string, DomainPhaseVideoMap> = {
  // --------------------------------------------------------------------------
  // CHEMICAL: Aspen Plus / HYSYS Simulation
  // --------------------------------------------------------------------------
  'chem-aspen': {
    0: [{
      id: "chem-asp-p0-basics",
      title: "Aspen Plus for Beginners: Components, Property Methods & Flash Drums",
      youtube_video_id: "xC4SGlVn4HI",
      youtube_url: "https://www.youtube.com/watch?v=xC4SGlVn4HI",
      fallback_video_id: "kjXRGFju6hY",
      search_query: "Aspen Plus Tutorial for Beginners Components Property Methods Flash2 Flowsheet",
      channel_name: "LafayetteChBE",
      duration: "24:15",
      difficulty: "Beginner",
      topic_focus: "Component Databanks, NRTL vs Peng-Robinson Equation of State & Flash Calculations",
      key_takeaways: [
        "Setting up simulation specifications: Selecting pure components and pseudo-components from Aspen databanks",
        "Selecting thermodynamic property models: Activity coefficient models (NRTL, UNIQUAC) vs EOS (Peng-Robinson, SRK)",
        "Configuring Flash2 and Flash3 equilibrium separator blocks with specified temperature and pressure",
        "Interpreting stream summary tables: Vapor fractions, enthalpy balances, and phase split compositions"
      ]
    }],
    1: [{
      id: "chem-asp-p1-distillation-radfrac",
      title: "Rigorous Distillation Modeling with RadFrac in Aspen Plus",
      youtube_video_id: "2eLexwkZOHA",
      youtube_url: "https://www.youtube.com/watch?v=2eLexwkZOHA",
      fallback_video_id: "Cv4KjY2BJTA",
      search_query: "Aspen Plus RadFrac Distillation Column Stages Reflux Ratio Condenser Reboiler",
      channel_name: "Chemical Engg by Shumas",
      duration: "28:40",
      difficulty: "Intermediate",
      topic_focus: "Equilibrium Stages, Feed Stage Location, Reflux Ratio & Design Specs (Vary/Spec)",
      key_takeaways: [
        "Configuring RadFrac block: Number of theoretical stages, total condenser, partial reboiler",
        "Optimizing feed tray entry point to minimize reboiler duty and separation entropy loss",
        "Implementing Design Specifications: Specifying distillate purity (e.g. 99.5% ethanol) and varying reflux ratio",
        "Troubleshooting column convergence errors: Damping factors, initial stage estimates, and tear streams"
      ]
    }],
    2: [{
      id: "chem-asp-p2-reactors-cstr",
      title: "Chemical Reactor Modeling: CSTR (RCSTR), PFR (RPlug) & Kinetic Rate Laws",
      youtube_video_id: "_DPxkmmeAJc",
      youtube_url: "https://www.youtube.com/watch?v=_DPxkmmeAJc",
      fallback_video_id: "C5nesXjtAEg",
      search_query: "Aspen Plus RCSTR RPlug Reactor Kinetic Reactions Arrhenius Equation Equilibrium",
      channel_name: "Chem Engg & Aspen Channel",
      duration: "26:50",
      difficulty: "Intermediate",
      topic_focus: "Power Law Kinetics, Arrhenius Activation Energy, Exothermic Heat Duty & Tube Pressure Drop",
      key_takeaways: [
        "Differentiating stoichiometric (RStoic), yield (RYield), and kinetic (RCSTR / RPlug) reactor models",
        "Inputting Arrhenius kinetic parameters: Pre-exponential factor (k0) and activation energy (Ea)",
        "Managing reaction exothermicity: Sizing jacket cooling utility requirements to prevent thermal runaway",
        "Modeling plug flow axial pressure drop using the Ergun equation for packed catalyst beds"
      ]
    }],
    3: [{
      id: "chem-asp-p3-flowsheet-capstone",
      title: "Full Plant Flowsheet Simulation: Recycle Loops, Sensitivity Analysis & Heat Integration",
      youtube_video_id: "Embv8WDnTmg",
      youtube_url: "https://www.youtube.com/watch?v=Embv8WDnTmg",
      fallback_video_id: "9F1dUpllEHo",
      search_query: "Aspen Plus Flowsheet Recycle Convergence Sensitivity Analysis Pinch Energy Integration",
      channel_name: "Process Simulation Examples in ASPEN",
      duration: "32:20",
      difficulty: "Advanced",
      topic_focus: "Wegstein Convergence Acceleration, Tear Streams, Sensitivity Blocks & Pinch Analysis",
      key_takeaways: [
        "Managing closed mass recycle loops: Defining tear streams and tuning Wegstein accelerator parameters",
        "Running Sensitivity Analysis to identify optimal operating windows and trade-offs across parameters",
        "Pinch Technology heat exchanger network integration: Composite curves and minimum utility targets",
        "Exporting converged equipment sizes and utility heat duties to Aspen Process Economic Analyzer (APEA)"
      ]
    }],
    4: [{
      id: "chem-asp-p4-process-interview",
      title: "Process Simulation Engineer Placement Interview & Aspen Case Study Viva",
      youtube_video_id: "FleUxl1oLgs",
      youtube_url: "https://www.youtube.com/watch?v=FleUxl1oLgs",
      fallback_video_id: "dSAPgA9-hQs",
      search_query: "Process Engineer Technical Interview Questions Aspen Plus Simulation Flowsheet Viva",
      channel_name: "CareerGuide",
      duration: "28:40",
      difficulty: "Placement",
      topic_focus: "Thermodynamic Method Selection Heuristics, Distillation Column Control & Placement Viva",
      key_takeaways: [
        "Mastering Carlson's decision trees for selecting thermodynamic property packages",
        "Dynamic simulation in Aspen Plus Dynamics: Level controllers, pressure relief systems, and column control loops",
        "Troubleshooting practical plant debottlenecking scenarios during technical interview problem sets",
        "Clearing process design engineering screening at Dow, ExxonMobil, Shell, Reliance, and Fluor"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // CHEMICAL: Mass & Energy Balances across Unit Operations
  // --------------------------------------------------------------------------
  'chem-massenergy': {
    0: [{
      id: "chem-me-p0-conservation",
      title: "Principles of Chemical Engineering: Conservation of Mass & Degrees of Freedom Analysis",
      youtube_video_id: "6Rx2ry1P6ME",
      youtube_url: "https://www.youtube.com/watch?v=6Rx2ry1P6ME",
      fallback_video_id: "10qbOTikL1k",
      search_query: "Degree of Freedom Analysis on a Single Unit LearnChemE Material Balances",
      channel_name: "LearnChemE",
      duration: "23:45",
      difficulty: "Beginner",
      topic_focus: "Input - Output + Generation - Consumption = Accumulation, Degrees of Freedom (NDOF = 0)",
      key_takeaways: [
        "General material balance equation: Input + Generation - Output - Consumption = Accumulation",
        "Steady-state non-reactive processes: Total mass input strictly equals total mass output",
        "Degrees of freedom analysis (NDOF): Unknown variables minus independent material balance equations",
        "Selecting an optimal calculation basis (e.g. 100 mol/hr or 1000 kg/hr) to streamline algebra"
      ]
    }],
    1: [{
      id: "chem-me-p1-recycle-purge",
      title: "Material Balances with Recycle, Bypass & Purge Streams",
      youtube_video_id: "dOHnvvEKcfM",
      youtube_url: "https://www.youtube.com/watch?v=dOHnvvEKcfM",
      fallback_video_id: "my1ZTIDSMbs",
      search_query: "Material Balances on System with Purge LearnChemE Recycle Purge Stream",
      channel_name: "LearnChemE",
      duration: "25:30",
      difficulty: "Intermediate",
      topic_focus: "Overall vs Single-Pass Conversion, Purge Ratios & Inert Buildup Prevention",
      key_takeaways: [
        "Differentiating single-pass reactor conversion from overall flowsheet conversion",
        "The critical necessity of purge streams: Preventing buildup of non-reactive inert components in recycle loops",
        "Setting up overall system boundaries vs unit operation sub-boundaries for simultaneous equations",
        "Bypass streams for precise temperature or concentration control without processing full feed"
      ]
    }],
    2: [{
      id: "chem-me-p2-reactive-balances",
      title: "Reactive Material Balances: Extent of Reaction & Limiting Reactants",
      youtube_video_id: "YusSU0jlOUk",
      youtube_url: "https://www.youtube.com/watch?v=YusSU0jlOUk",
      fallback_video_id: "ALBnLnApipA",
      search_query: "Extent of Reaction for Material Balances LearnChemE Limiting Reactant",
      channel_name: "LearnChemE",
      duration: "27:20",
      difficulty: "Intermediate",
      topic_focus: "Stoichiometry, Extent of Reaction (xi), Theoretical Oxygen & Percent Excess Air",
      key_takeaways: [
        "Extent of Reaction (xi) method: ni = ni_0 + nu_i * xi across multi-reaction systems",
        "Identifying limiting reactants and calculating percentage excess of secondary reactants",
        "Combustion balances: Theoretical oxygen, complete vs incomplete combustion, Orsat flue gas analysis",
        "Atomic balance method vs molecular balance method for complex hydrocarbon reforming reactions"
      ]
    }],
    3: [{
      id: "chem-me-p3-energy-balances",
      title: "Energy Balances: Heat of Reaction, Sensible Heat, Latent Heat & Hess's Law",
      youtube_video_id: "z438ssCWhdw",
      youtube_url: "https://www.youtube.com/watch?v=z438ssCWhdw",
      fallback_video_id: "npYpdio35e0",
      search_query: "Calculating Enthalpy Changes Using Heat of Reaction Method LearnChemE Energy Balances",
      channel_name: "LearnChemE",
      duration: "29:30",
      difficulty: "Advanced",
      topic_focus: "Reference States, Integral Cp(T)dT, Heat of Formation (Delta Hf) & Adiabatic Flame Temp",
      key_takeaways: [
        "First Law energy balance for open continuous systems: Delta H_dot + Delta E_k + Delta E_p = Q_dot - W_dot",
        "Calculating sensible enthalpy changes using temperature-dependent polynomial heat capacities (Cp)",
        "Standard Heat of Reaction (Delta Hr) calculation from Heats of Formation (Delta Hf) and Heats of Combustion",
        "Calculating maximum theoretical Adiabatic Flame Temperature in industrial combustion furnaces"
      ]
    }],
    4: [{
      id: "chem-me-p4-balances-interview",
      title: "Chemical Engineering Core Technical Placement Interview & Balance Calculations Viva",
      youtube_video_id: "dSAPgA9-hQs",
      youtube_url: "https://www.youtube.com/watch?v=dSAPgA9-hQs",
      fallback_video_id: "RPmCk7yHN74",
      search_query: "Chemical Engineer Interview Questions and Answers Core Technical Mass Energy Balances",
      channel_name: "CareerGuide",
      duration: "28:15",
      difficulty: "Placement",
      topic_focus: "Transient Material Balances, Tank Drainage (Torricelli) & Core Technical Viva",
      key_takeaways: [
        "Formulating unsteady-state transient differential equations for tank filling and batch reactor purging",
        "Quick mental estimations of mass fractions, molar conversions, and energy fluxes on interview whiteboards",
        "Explaining thermodynamic steam tables and humidification chart balances in plant utilities",
        "Passing technical screening at SABIC, BASF, Indian Oil (IOCL), BPCL, and Schlumberger"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // CHEMICAL: Distillation Column & Mass Transfer Design
  // --------------------------------------------------------------------------
  'chem-distillation': {
    0: [{
      id: "chem-dis-p0-vle",
      title: "Vapor-Liquid Equilibrium (VLE) & Raoult's Law First Principles",
      youtube_video_id: "NX1e1WHAK7o",
      youtube_url: "https://www.youtube.com/watch?v=NX1e1WHAK7o",
      fallback_video_id: "JJBlvH5VGI8",
      search_query: "Binary VLE Vapor Liquid Equilibrium LearnChemE Raoult's Law T-x-y Diagrams",
      channel_name: "LearnChemE",
      duration: "22:30",
      difficulty: "Beginner",
      topic_focus: "Raoult's Law (P_i = x_i * P_sat), Antoine Equation, Relative Volatility (alpha) & Azeotropes",
      key_takeaways: [
        "Vapor-liquid equilibrium principles: Raoult's law for ideal mixtures and activity coefficients for non-ideal mixtures",
        "Antoine equation for pure component saturated vapor pressure as a function of temperature",
        "Constructing and interpreting T-x-y boiling point diagrams and x-y equilibrium distribution curves",
        "Relative volatility (alpha = K_A / K_B) and why separation difficulty escalates as alpha approaches 1.0"
      ]
    }],
    1: [{
      id: "chem-dis-p1-mccabe-thiele",
      title: "McCabe-Thiele Method: Operating Lines, Feed Condition (q-line) & Minimum Reflux",
      youtube_video_id: "Cv4KjY2BJTA",
      youtube_url: "https://www.youtube.com/watch?v=Cv4KjY2BJTA",
      fallback_video_id: "eIJk5uXmBRc",
      search_query: "McCabe-Thiele Graphical Method Example LearnChemE Distillation Stages Reflux Ratio",
      channel_name: "LearnChemE",
      duration: "26:40",
      difficulty: "Intermediate",
      topic_focus: "Top Operating Line (TOL), Bottom Operating Line (BOL), Feed Quality (q) & Stepping Stages",
      key_takeaways: [
        "Deriving Top Operating Line: y = [R / (R + 1)] * x + [x_D / (R + 1)] using reflux ratio R",
        "Feed thermal condition parameter (q) and plotting the q-line slope: Subcooled liquid, saturated liquid, vapor",
        "Stepping off theoretical stages between operating lines and equilibrium curve from distillate to bottoms",
        "Determining minimum reflux ratio (Rmin) from the pinch point and total reflux minimum stages (Fenske)"
      ]
    }],
    2: [{
      id: "chem-dis-p2-tray-hydraulics",
      title: "Tray Hydraulics & Column Internals: Sieve, Valve & Bubble-Cap Trays",
      youtube_video_id: "UlOR-Oo7U-U",
      youtube_url: "https://www.youtube.com/watch?v=UlOR-Oo7U-U",
      fallback_video_id: "jW1w19kLZz0",
      search_query: "What is a Distillation Column? Column Internals & Components Piping Mantra",
      channel_name: "Piping Mantra",
      duration: "24:50",
      difficulty: "Intermediate",
      topic_focus: "Flooding, Weeping, Entrainment, Downcomer Backup & Operating Windows",
      key_takeaways: [
        "Comparing tray geometries: Low-cost sieve trays, high-turndown valve trays, and low-leakage bubble-cap trays",
        "Hydraulic operational limits: Weeping at low vapor velocities, jet flooding and spray entrainment at high vapor rates",
        "Downcomer sizing criteria: Clear liquid height, downcomer backup limits, and froth choke velocity",
        "Pressure drop per theoretical stage and its impact on column bottom reboiler temperature"
      ]
    }],
    3: [{
      id: "chem-dis-p3-packed-columns",
      title: "Packed Column Design: HETP, Random vs Structured Packing & Pressure Drop",
      youtube_video_id: "2WI2sMIa5r0",
      youtube_url: "https://www.youtube.com/watch?v=2WI2sMIa5r0",
      fallback_video_id: "AbArRgpP2B0",
      search_query: "Packed Bed Column Height LearnChemE Mass Transfer HETP Random Structured Packing",
      channel_name: "LearnChemE",
      duration: "28:20",
      difficulty: "Advanced",
      topic_focus: "Height Equivalent to a Theoretical Plate (HETP), Generalized Pressure Drop Correlation & Distributors",
      key_takeaways: [
        "Random packing (Raschig rings, Pall rings, IMTP) vs corrugated sheet structured packing (Mellapak)",
        "Calculating packed bed height: Z = N_stages * HETP or transfer unit integration (Z = HTU * NTU)",
        "Generalized Pressure Drop Correlation (GPDC) charts for liquid loading and gas flooding velocities",
        "Liquid distributor design: Preventing channel wall maldistribution and ensuring uniform bed irrigation"
      ]
    }],
    4: [{
      id: "chem-dis-p4-distillation-interview",
      title: "Distillation Design Technical Interview & Plant Column Troubleshooting",
      youtube_video_id: "-H5O0o6t_W8",
      youtube_url: "https://www.youtube.com/watch?v=-H5O0o6t_W8",
      fallback_video_id: "FleUxl1oLgs",
      search_query: "Interview Questions & Answers in Chemical Engineering Distillation SPEC e-Learn",
      channel_name: "SPEC e-Learn",
      duration: "29:10",
      difficulty: "Placement",
      topic_focus: "Column Foaming, Azeotropic Distillation, Column Temperature Control & Placement Viva",
      key_takeaways: [
        "Troubleshooting plant operational failures: Premature flooding caused by heavy hydrocarbon foaming",
        "Overcoming azeotropes: Pressure-swing distillation vs extractive distillation using entrainers",
        "Column dual-temperature control architectures: Manipulating reflux for top purity and steam for bottoms",
        "Passing distillation design viva rounds at Shell, ExxonMobil, Reliance, Technip, and L&T Hydrocarbon"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // CHEMICAL: Process Safety Management & HAZOP Analysis
  // --------------------------------------------------------------------------
  'chem-hazop': {
    0: [{
      id: "chem-hzp-p0-basics",
      title: "Process Safety Management (PSM) & OSHA 14 Elements First Principles",
      youtube_video_id: "ta5NntcnHsY",
      youtube_url: "https://www.youtube.com/watch?v=ta5NntcnHsY",
      fallback_video_id: "9lmV8GLFGzE",
      search_query: "Process Safety Management PSM The 14 Elements Explained OSHA 1910.119",
      channel_name: "Six Sigma Development Solutions",
      duration: "25:40",
      difficulty: "Beginner",
      topic_focus: "Process Safety vs Occupational Safety, The 14 PSM Elements & Process Hazard Analysis (PHA)",
      key_takeaways: [
        "Differentiating occupational personal safety (slips, trips, PPE) from process safety (containment loss, fires, explosions)",
        "The 14 elements of OSHA PSM 1910.119: Process Safety Information (PSI), PHA, Management of Change (MOC)",
        "Historical chemical catastrophe lessons: Bhopal gas tragedy (MIC release), Texas City refinery explosion, Piper Alpha",
        "Inherent safety design principles: Substitute, Minimize, Moderate, and Simplify (Kletz principles)"
      ]
    }],
    1: [{
      id: "chem-hzp-p1-methodology",
      title: "HAZOP Study Methodology: Guide Words, Deviations, Causes & Consequences",
      youtube_video_id: "iDo5DMmgjzE",
      youtube_url: "https://www.youtube.com/watch?v=iDo5DMmgjzE",
      fallback_video_id: "3gyJu5SuYEo",
      search_query: "What is HAZOP Hazard and Operability Study Explained Chemical adda Guide Words",
      channel_name: "Chemical adda",
      duration: "27:30",
      difficulty: "Intermediate",
      topic_focus: "HAZOP Nodes, Guide Words (NO, MORE, LESS, AS WELL AS, REVERSE), Safeguards & Recommendations",
      key_takeaways: [
        "Partitioning P&ID drawings into distinct HAZOP Nodes with specific design intentions",
        "Applying standard guide words combined with process parameters: MORE FLOW, LESS TEMPERATURE, HIGH PRESSURE, REVERSE FLOW",
        "Identifying root causes: Control valve failure, pipe rupture, heat exchanger tube leak, operator error",
        "Evaluating existing engineered safeguards and proposing mandatory actionable recommendations"
      ]
    }],
    2: [{
      id: "chem-hzp-p2-lopa-sil",
      title: "Layer of Protection Analysis (LOPA) & Safety Integrity Levels (SIL / SIS)",
      youtube_video_id: "7g-wl8kkHF8",
      youtube_url: "https://www.youtube.com/watch?v=7g-wl8kkHF8",
      fallback_video_id: "wLmaPhze_Yc",
      search_query: "SIL Determination LOPA SIL Verification Explained IEC 61511 Safety Lifecycle",
      channel_name: "Risk Alive Analytics",
      duration: "28:45",
      difficulty: "Intermediate",
      topic_focus: "Independent Protection Layers (IPL), Probability of Failure on Demand (PFDavg) & SIL 1-4",
      key_takeaways: [
        "Principles of Independent Protection Layers (IPL): Specificity, independence, dependability, and auditability",
        "Quantifying initiating event frequencies and mitigating risk using Probability of Failure on Demand (PFD)",
        "IEC 61508 / 61511 Safety Instrumented Systems (SIS): Sensor, Logic Solver, and Final Control Element",
        "Classifying Safety Integrity Levels: SIL 1 (PFD 10^-1 to 10^-2) up to SIL 4 (PFD 10^-4 to 10^-5)"
      ]
    }],
    3: [{
      id: "chem-hzp-p3-relief-sizing",
      title: "Pressure Relief Valve (PRV) Sizing & Rupture Disc Sizing to API 520 / 521",
      youtube_video_id: "62SgIUeOn-s",
      youtube_url: "https://www.youtube.com/watch?v=62SgIUeOn-s",
      fallback_video_id: "7Mxc2gap2hw",
      search_query: "PSV Orifice Sizing Fire Case API 521 API 520 Step by Step Relief Valve",
      channel_name: "DesiGn HuB",
      duration: "31:15",
      difficulty: "Advanced",
      topic_focus: "Relief Scenarios (Blocked Discharge, External Fire Pool), Orifice Letter Sizing & Flare Headers",
      key_takeaways: [
        "Identifying governing relief overpressure scenarios: Blocked liquid outlet, cooling water failure, external pool fire",
        "API 520 sizing equations for vapor and liquid relief orifice area calculations (standard orifice letters D to T)",
        "Set pressure allowances and allowable overpressure limits (10% standard, 21% for fire cases)",
        "Backpressure considerations: Conventional spring-loaded PRVs vs balanced bellows PRVs in pressurized flare headers"
      ]
    }],
    4: [{
      id: "chem-hzp-p4-safety-interview",
      title: "Process Safety Engineer Placement Interview & Plant Hazard Scenario Viva",
      youtube_video_id: "1ehMkgs90cw",
      youtube_url: "https://www.youtube.com/watch?v=1ehMkgs90cw",
      fallback_video_id: "-6ynKRtsnKc",
      search_query: "IEC 61511 Functional Safety Life Cycle Guide to SIS Process Safety Technical Interview",
      channel_name: "InstruNexus",
      duration: "29:10",
      difficulty: "Placement",
      topic_focus: "Risk Assessment Matrix (RAM), Quantitative Risk Assessment (QRA), F-N Curves & Viva",
      key_takeaways: [
        "Applying corporate Risk Assessment Matrices (RAM) to rank severity and likelihood of hazardous events",
        "Quantitative Risk Assessment (QRA): Individual risk of fatality contours and societal risk F-N curves",
        "Management of Change (MOC) procedures: Pre-startup safety reviews (PSSR) before plant commissioning",
        "Passing process safety engineering technical rounds at DNV, ERM, Baker Hughes, BP, and TotalEnergies"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // CHEMICAL: Piping & Instrumentation Diagrams (P&ID)
  // --------------------------------------------------------------------------
  'chem-pid': {
    0: [{
      id: "chem-pid-p0-isa-symbols",
      title: "How to Read P&ID: ISA-5.1 Instrumentation Symbols & Line Identification",
      youtube_video_id: "j4EOTerfyTY",
      youtube_url: "https://www.youtube.com/watch?v=j4EOTerfyTY",
      fallback_video_id: "lBJnU1MJAts",
      search_query: "How to Read PID Piping and Instrumentation Diagram ISA 5.1 Tag Numbers Symbols RealPars",
      channel_name: "RealPars",
      duration: "23:50",
      difficulty: "Beginner",
      topic_focus: "First Letter Variables (T, P, F, L), Succeeding Letters (T, I, C, V) & Line Types",
      key_takeaways: [
        "Decoding instrument tag bubbles: Field mounted (no line) vs control room DCS accessible (solid horizontal line)",
        "ISA-5.1 lettering syntax: Variable (T=Temp, P=Press, F=Flow, L=Level) + Modifier (D=Diff) + Function (T=Transmitter, C=Controller, V=Valve)",
        "Piping line classification syntax: Line size (inches), fluid service code, piping spec class, insulation code",
        "Signal lines: Pneumatic signal (double cross hatch), electrical signal (dashed line), software internal link"
      ]
    }],
    1: [{
      id: "chem-pid-p1-valves-failsafe",
      title: "Control Valves, Fail-Safe Modes (FC, FO, FL) & Actuator Types in P&IDs",
      youtube_video_id: "KtsiM1st0KA",
      youtube_url: "https://www.youtube.com/watch?v=KtsiM1st0KA",
      fallback_video_id: "uHQ7OySwnLc",
      search_query: "What is a Control Valve Working Principles RealPars Fail Safe Actuators",
      channel_name: "RealPars",
      duration: "25:30",
      difficulty: "Intermediate",
      topic_focus: "Pneumatic Diaphragm Actuators, Fail-Close (Air-to-Open), Fail-Open (Air-to-Close) & Valve Characteristics",
      key_takeaways: [
        "Determining fail-safe valve modes: Fail-Closed (FC) for feed reactants vs Fail-Open (FO) for jacket cooling water",
        "Diaphragm actuator spring action: Air-to-Open vs Air-to-Close valve mechanisms",
        "Equal percentage vs linear vs quick-opening valve trim flow characteristics for process stability",
        "Control valve station piping layout: Isolation block valves, upstream strainer, and manual bypass needle valve"
      ]
    }],
    2: [{
      id: "chem-pid-p2-control-loops",
      title: "Process Control Loops in P&ID: Feedback, Cascade, Ratio & Feedforward",
      youtube_video_id: "7bkgUxi1u4U",
      youtube_url: "https://www.youtube.com/watch?v=7bkgUxi1u4U",
      fallback_video_id: "J0sRRVGxJ2g",
      search_query: "Cascade Control Explained Simple Practical Guide Product Process People PID Loops",
      channel_name: "Product Process People",
      duration: "27:15",
      difficulty: "Intermediate",
      topic_focus: "Cascade Architecture (Master Level / Slave Flow), Ratio Controllers (FFC) & 3-Element Boiler Drum",
      key_takeaways: [
        "Feedback loop fundamentals: Process Variable (PV), Setpoint (SP), and Manipulated Variable (MV)",
        "Cascade control implementation: Outer primary master controller feeding setpoints to fast inner secondary slave controller",
        "Ratio control (FFC) for stoichiometric combustion: Air-to-fuel ratio control with lead-lag cross-limiting",
        "Feedforward control: Anticipating measurable process disturbances (e.g. ambient feed temperature drops) before PV deviates"
      ]
    }],
    3: [{
      id: "chem-pid-p3-interlocks-safety",
      title: "Safety Interlocks, Cause & Effect Matrix & Emergency Shutdown (ESD) Systems",
      youtube_video_id: "seza6tKNMtI",
      youtube_url: "https://www.youtube.com/watch?v=seza6tKNMtI",
      fallback_video_id: "cWjMVY4mVzM",
      search_query: "Cause and Effect Matrix Process Control Safety Interlocks Jeferson Costa ESD",
      channel_name: "Jeferson Costa Chemical Process Engineering",
      duration: "28:30",
      difficulty: "Advanced",
      topic_focus: "Shutdown Valves (SDV), Blowdown Valves (BDV), Cause & Effect (C&E) Matrix & 2oo3 Voting Logic",
      key_takeaways: [
        "P&ID safety interlock symbology: High-High trip switches (PSHH, LSHH, TSHH) connected to Emergency Shutdown (ESD) logic",
        "Interpreting Cause and Effect (C&E) matrices: Correlating initiating trip alarms with automated shutdown valve closures",
        "Emergency isolation: Sizing fail-closed Shutdown Valves (SDV / XV) and fail-open emergency depressuring Blowdown Valves (BDV)",
        "Sensor redundancy voting logic: 2-out-of-3 (2oo3) triple modular redundant transmitter configurations to prevent spurious trips"
      ]
    }],
    4: [{
      id: "chem-pid-p4-pid-interview",
      title: "P&ID Walkthrough Technical Placement Interview & Field Instrumentation Viva",
      youtube_video_id: "nz_XVSrgmlA",
      youtube_url: "https://www.youtube.com/watch?v=nz_XVSrgmlA",
      fallback_video_id: "yYT55oSVD9o",
      search_query: "Top 30 PID Symbology Loop Diagram Interview Questions Answers Instrumentation",
      channel_name: "IIQA",
      duration: "30:15",
      difficulty: "Placement",
      topic_focus: "Drawing Walkthrough, Pump NPSH Protection, Pressure Rating Transitions & EPC Viva",
      key_takeaways: [
        "Conducting live P&ID drawing walkthroughs during engineering contractor technical interviews",
        "Pump protection piping detailing: Minimum flow spillback bypass lines, suction strainers, and vortex breakers",
        "Piping class spec breaks across pressure boundaries (e.g. Class 300 to Class 150 flanged transitions)",
        "Acing process piping engineering interviews at Technip, McDermott, Worley, Petrofac, and Wood Group"
      ]
    }]
  },

  // ==========================================================================
  // BIOTECHNOLOGY CO-DOMAINS
  // ==========================================================================

  // --------------------------------------------------------------------------
  // BIOTECH: Genetic Engineering & CRISPR-Cas9 Protocols
  // --------------------------------------------------------------------------
  'bio-crispr': {
    0: [{
      id: "bio-crp-p0-molecular-cloning",
      title: "Recombinant DNA Technology: Restriction Enzymes, Plasmids & Ligation",
      youtube_video_id: "-2K3tFYUKaw",
      youtube_url: "https://www.youtube.com/watch?v=-2K3tFYUKaw",
      fallback_video_id: "NoyeCMmP5tw",
      search_query: "Recombinant DNA Technology Plasmids Restriction Enzymes Ligase Bacterial Transformation",
      channel_name: "Derek McLachlin",
      duration: "23:30",
      difficulty: "Beginner",
      topic_focus: "Type II Restriction Endonucleases (EcoRI), Sticky vs Blunt Ends, T4 DNA Ligase & Transformation",
      key_takeaways: [
        "Plasmid cloning vectors: Origin of replication (ori), multiple cloning site (MCS), and antibiotic selection markers",
        "Restriction digestion mechanisms: Palindromic recognition sequences generating 5' or 3' sticky overhangs",
        "Phosphodiester bond catalysis using T4 DNA ligase and optimizing insert-to-vector molar ratios (3:1 to 5:1)",
        "Bacterial transformation: Heat shock of chemically competent E. coli cells and blue-white colony screening (lacZ)"
      ]
    }],
    1: [{
      id: "bio-crp-p1-crispr-mechanism",
      title: "CRISPR-Cas9 Mechanism: sgRNA Design, PAM Sequences & Double-Strand Breaks",
      youtube_video_id: "IiPL5HgPehs",
      youtube_url: "https://www.youtube.com/watch?v=IiPL5HgPehs",
      fallback_video_id: "iSEEw4Vs_B4",
      search_query: "CRISPR Cas9 Mechanism sgRNA PAM Sequence SpCas9 Double Strand Break Cleavage",
      channel_name: "Professor Dave Explains",
      duration: "27:15",
      difficulty: "Intermediate",
      topic_focus: "Single Guide RNA (sgRNA), 5'-NGG-3' PAM Recognition, RuvC & HNH Endonuclease Domains",
      key_takeaways: [
        "Molecular architecture of Streptococcus pyogenes Cas9: Recognition (REC) and nuclease (NUC) lobes",
        "Designing the 20-nucleotide single-guide RNA (sgRNA) spacer complementary to target genomic DNA",
        "Mandatory Protospacer Adjacent Motif (PAM) sequence requirement (5'-NGG-3') for target DNA unwinding",
        "Targeted double-strand breaks (DSB) induced 3 base pairs upstream of the PAM site by RuvC and HNH domains"
      ]
    }],
    2: [{
      id: "bio-crp-p2-repair-pathways",
      title: "DNA Repair Pathways: Non-Homologous End Joining (NHEJ) vs Homology-Directed Repair (HDR)",
      youtube_video_id: "-weaa_ja_LA",
      youtube_url: "https://www.youtube.com/watch?v=-weaa_ja_LA",
      fallback_video_id: "Rv6-RB20f0s",
      search_query: "NHEJ vs HDR DNA Repair Pathways CRISPR Gene Knockout Knockin Donor Template",
      channel_name: "Animated biology With arpan",
      duration: "28:40",
      difficulty: "Intermediate",
      topic_focus: "Error-Prone NHEJ for Gene Knockouts (Indels), Frameshift Mutations & Precise HDR Knock-in",
      key_takeaways: [
        "Non-Homologous End Joining (NHEJ): Error-prone ligation causing insertion/deletion (indel) mutations for gene knockouts",
        "Frameshift nonsense mutations leading to premature stop codons and target protein loss of function",
        "Homology-Directed Repair (HDR): Providing exogenous single-stranded oligo donor templates (ssODN) for precise gene editing",
        "Cell cycle dependence of HDR (active primarily in S/G2 phase) and strategies to boost knock-in efficiency"
      ]
    }],
    3: [{
      id: "bio-crp-p3-prime-base-editing",
      title: "Advanced Gene Editing: Base Editors (CBE/ABE), Prime Editing & Off-Target Profiling",
      youtube_video_id: "huDgW0wCi9c",
      youtube_url: "https://www.youtube.com/watch?v=huDgW0wCi9c",
      fallback_video_id: "GvTcdIA--q8",
      search_query: "Base Editing Prime Editing David Liu GUIDE-seq Off Target Cleavage NGS",
      channel_name: "theCrux",
      duration: "33:10",
      difficulty: "Advanced",
      topic_focus: "Cytosine / Adenine Base Editors, Catalytically Dead dCas9, pegRNA Reverse Transcription & Off-Targets",
      key_takeaways: [
        "Base Editing: Fusing dead dCas9 or nickase with cytidine or adenosine deaminases (C->T and A->G without double-strand breaks)",
        "Prime Editing: Reverse transcriptase fused to Cas9 nickase guided by pegRNA for search-and-replace genomic editing",
        "Detecting unintended off-target genome cleavage: Unbiased genome-wide sequencing assays (GUIDE-seq, CIRCLE-seq)",
        "Engineered high-fidelity Cas9 variants (eSpCas9, SpCas9-HF1) that eliminate non-specific chromatin binding"
      ]
    }],
    4: [{
      id: "bio-crp-p4-crispr-interview",
      title: "Biotechnology & Cell/Gene Therapy Scientist Placement Interview Viva",
      youtube_video_id: "lx3EhUVHI-Q",
      youtube_url: "https://www.youtube.com/watch?v=lx3EhUVHI-Q",
      fallback_video_id: "wbBBigw1CL4",
      search_query: "Biotech Scientist Technical Interview Questions CRISPR CAR-T Cell Therapy Viva",
      channel_name: "Thermo Fisher Scientific",
      duration: "31:20",
      difficulty: "Placement",
      topic_focus: "Viral (AAV/Lentivirus) vs Non-Viral (LNP) Delivery, CAR-T Engineering & Regulatory Viva",
      key_takeaways: [
        "In vivo delivery vehicles: Adeno-associated virus (AAV) vectors vs lipid nanoparticles (LNP) mRNA delivery",
        "Ex vivo autologous cell therapy: Manufacturing allogeneic and autologous CAR-T cells for immuno-oncology",
        "Navigating FDA / CDSCO clinical trial guidelines for human somatic cell genome editing therapeutics",
        "Acing biotech scientist technical interviews at Vertex, Editas Medicine, CRISPR Therapeutics, and Biocon"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // BIOTECH: Bioreactor Fermentation & Process Parameters
  // --------------------------------------------------------------------------
  'bio-fermentation': {
    0: [{
      id: "bio-fer-p0-kinetics",
      title: "Microbial Growth Kinetics: Monod Model, Doubling Time & Fermentation Modes",
      youtube_video_id: "O1UC5DwufDQ",
      youtube_url: "https://www.youtube.com/watch?v=O1UC5DwufDQ",
      fallback_video_id: "8AhDxAQaDOA",
      search_query: "Microbial Growth Kinetics Monod Equation Specific Growth Rate Batch Fed Batch Chemostat",
      channel_name: "The Biotech Engineer 👩‍🔬",
      duration: "25:20",
      difficulty: "Beginner",
      topic_focus: "Lag, Exponential, Stationary & Death Phases, Specific Growth Rate (mu), Ks & Yield (Yx/s)",
      key_takeaways: [
        "The 4 microbial growth phases: Lag phase acclimation, exponential log phase, nutrient exhaustion stationary phase",
        "Monod growth kinetics equation: mu = mu_max * S / (Ks + S); calculating substrate affinity constant (Ks)",
        "Biomass yield coefficient (Y_X/S = Delta X / Delta S) and product yield calculations",
        "Comparison of operational modes: Batch culture, Fed-batch glucose feeding, Continuous Chemostat operation"
      ]
    }],
    1: [{
      id: "bio-fer-p1-bioreactor-hardware",
      title: "Bioreactor Design & Anatomy: Stirred Tank (STR), Impellers, Spargers & Baffles",
      youtube_video_id: "azdVSr7DBlg",
      youtube_url: "https://www.youtube.com/watch?v=azdVSr7DBlg",
      fallback_video_id: "NFsDw-nabRk",
      search_query: "Stirred Tank Bioreactor Design Rushton Turbine Impeller Sparger Baffles Dissolved Oxygen",
      channel_name: "InformationBoxTicket Lifestyles",
      duration: "27:40",
      difficulty: "Intermediate",
      topic_focus: "Rushton Flat-Blade Turbines vs Marine Impellers, Microspargers, 4 Baffles & Antifoam Systems",
      key_takeaways: [
        "Impeller selection: High shear radial flow (Rushton turbines) for bacteria vs low shear axial flow (marine hydrofoils) for mammalian cells",
        "Role of vertical wall baffles (typically 4, width 1/10th tank diameter) in preventing vortex formation and enhancing mixing",
        "Air sparging systems: Ring spargers and sintered microspargers for maximizing interfacial bubble contact surface area",
        "Mechanical and chemical antifoam mechanisms to prevent foam out through exhaust sterile gas filters"
      ]
    }],
    2: [{
      id: "bio-fer-p2-kla-oxygen",
      title: "Oxygen Mass Transfer (kLa) Determination & Scale-Up Criteria in Bioreactors",
      youtube_video_id: "12zIQZH5RrE",
      youtube_url: "https://www.youtube.com/watch?v=12zIQZH5RrE",
      fallback_video_id: "LrTiB4O-Z6s",
      search_query: "Oxygen Transfer Rate OTR kLa Dynamic Gassing Out Method Scale Up Constant P/V",
      channel_name: "Learn With SciTech",
      duration: "30:15",
      difficulty: "Intermediate",
      topic_focus: "Oxygen Transfer Rate (OTR), OUR, Dynamic Gassing-Out, Constant Power per Volume (P/V)",
      key_takeaways: [
        "Volumetric mass transfer equation: OTR = kLa * (C* - CL); matching Oxygen Uptake Rate (OUR) of cells",
        "Experimental measurement of kLa: Dynamic gassing-out method with nitrogen purging and re-aeration",
        "Bioreactor scale-up rules: Constant volumetric power input (P/V), constant tip speed, or constant kLa",
        "Managing dissolved oxygen (DO) cascade control: Adjusting agitation RPM, airflow rate, and pure oxygen supplementation"
      ]
    }],
    3: [{
      id: "bio-fer-p3-sip-cip",
      title: "Sterilization in Place (SIP), Cleaning in Place (CIP) & Sterile Inoculation",
      youtube_video_id: "7eQPUcfRPNU",
      youtube_url: "https://www.youtube.com/watch?v=7eQPUcfRPNU",
      fallback_video_id: "nlwSZXecRzI",
      search_query: "Sterilization in Place SIP Cleaning in Place CIP Bioreactor Sterility Del Factor Fo",
      channel_name: "Learn gmp Inc.",
      duration: "32:50",
      difficulty: "Advanced",
      topic_focus: "Thermal Death Kinetics (Del Factor / Fo Value), 121C Saturated Steam & CIP Multi-Stage Cycles",
      key_takeaways: [
        "Thermal sterilization kinetics: Del factor (Nabla = ln(N0/Nt)) targeting probability of non-sterility < 10^-3",
        "Executing automated SIP cycles: 121°C saturated steam holding for 30 minutes with continuous condensate draining",
        "Cleaning in Place (CIP) validated sequences: Pre-rinse, hot caustic wash (1-2% NaOH), acid wash, final WFI rinse",
        "Aseptic inoculation techniques using sterile transfer bottles, peristaltic pumps, and flame/containment ports"
      ]
    }],
    4: [{
      id: "bio-fer-p4-fermentation-interview",
      title: "Upstream Bioprocess / Fermentation Scientist Placement Interview Screening & Viva",
      youtube_video_id: "L_uryPX4PTE",
      youtube_url: "https://www.youtube.com/watch?v=L_uryPX4PTE",
      fallback_video_id: "iuiHp87Xmzs",
      search_query: "Upstream Bioprocess Engineer Interview Questions Fermentation Troubleshooting Viva",
      channel_name: "Microbial Concepts (Microbiology channel)",
      duration: "29:40",
      difficulty: "Placement",
      topic_focus: "Contamination Troubleshooting, Crabtree Effect (Ethanol Overflow), Scale-Down Models & Viva",
      key_takeaways: [
        "Troubleshooting contamination events: Identifying bacterial vs phage infections via microscopic stains and culture plates",
        "Mitigating overflow metabolism: Avoiding Crabtree effect in yeast and acetate accumulation in E. coli via exponential fed-batch feeding",
        "Developing qualified scale-down benchtop bioreactor models to predict 10,000-liter commercial production performance",
        "Passing upstream bioprocess engineering interviews at Genentech, Amgen, Biocon, Serum Institute, and Lonza"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // BIOTECH: Protein Purification & Chromatography (HPLC/FPLC)
  // --------------------------------------------------------------------------
  'bio-chromatography': {
    0: [{
      id: "bio-chr-p0-principles",
      title: "Protein Chromatography Principles: Retention Time, Resolution & Column Efficiency",
      youtube_video_id: "FOjEH4VoTxE",
      youtube_url: "https://www.youtube.com/watch?v=FOjEH4VoTxE",
      fallback_video_id: "We8jYuInf94",
      search_query: "Protein Chromatography Principles Van Deemter Equation Retention Factor Resolution",
      channel_name: "Pallavi's Pharma Tuition",
      duration: "24:45",
      difficulty: "Beginner",
      topic_focus: "Van Deemter Equation (A, B, C terms), Theoretical Plate Count (N), Peak Symmetry & Capacity Factor",
      key_takeaways: [
        "Fundamental chromatography physics: Differential partition between stationary phase resin and liquid mobile phase",
        "Van Deemter equation: H = A + B/u + C*u; finding optimal mobile phase linear flow velocity (u)",
        "Quantifying chromatographic resolution (Rs >= 1.5 for baseline separation of neighboring protein peaks)",
        "Calculating number of theoretical plates (N = 16 * (tR / W)^2) to evaluate packed column efficiency"
      ]
    }],
    1: [{
      id: "bio-chr-p1-affinity-fplc",
      title: "Affinity Chromatography: Protein A, Nickel-NTA (His-Tag) & ÄKTA FPLC Systems",
      youtube_video_id: "rbcDxuc8TOw",
      youtube_url: "https://www.youtube.com/watch?v=rbcDxuc8TOw",
      fallback_video_id: "KOTNXKo2O7o",
      search_query: "Protein A Affinity Chromatography Monoclonal Antibodies Akta FPLC His Tag Ni NTA",
      channel_name: "Animated biology With arpan",
      duration: "28:30",
      difficulty: "Intermediate",
      topic_focus: "Protein A Binding to IgG Fc Region, Low pH Glycine Elution, ÄKTA Flow Path & UV Monitors",
      key_takeaways: [
        "Monoclonal antibody (mAb) platform capture: Protein A ligand binding selectively to the Fc constant region",
        "Stepwise elution: Washing host cell impurities at neutral pH; eluting antibody using low pH citrate/glycine buffer (pH 3.0-3.5)",
        "Immobilized Metal Affinity Chromatography (IMAC): Ni-NTA resins capturing 6xHis-tagged recombinant proteins with Imidazole elution",
        "Operating ÄKTA FPLC systems: Pumps, pressure sensors, air sensors, UV absorbance (280nm), and conductivity monitors"
      ]
    }],
    2: [{
      id: "bio-chr-p2-iex-sec",
      title: "Ion Exchange (IEX) & Size Exclusion Chromatography (SEC): Resins & Elution",
      youtube_video_id: "vMzs4NyVvuc",
      youtube_url: "https://www.youtube.com/watch?v=vMzs4NyVvuc",
      fallback_video_id: "bu0wm5swcJ0",
      search_query: "Ion Exchange Chromatography Cation Anion Exchange Isoelectric Point SEC Gel Filtration",
      channel_name: "Baayo",
      duration: "29:50",
      difficulty: "Intermediate",
      topic_focus: "Isoelectric Point (pI), Cation (SP/CM) vs Anion (Q/DEAE) Exchangers & Linear Salt Gradients",
      key_takeaways: [
        "Exploiting protein isoelectric points (pI): Buffer pH > pI gives net negative charge (Anion Exchanger bind); pH < pI gives net positive charge",
        "Strong vs weak ion exchange functional groups (Quaternary ammonium Q vs Sulfopropyl SP)",
        "Executing linear sodium chloride (NaCl) salt gradients to elute proteins based on surface charge density",
        "Size Exclusion Chromatography (SEC / Gel Filtration): Porous bead dextran matrices separating aggregates from monomers"
      ]
    }],
    3: [{
      id: "bio-chr-p3-hplc-analytics",
      title: "Analytical HPLC: Reverse Phase (RP-HPLC), Mass Spectrometry & Purity Validation",
      youtube_video_id: "lONazGlhOdQ",
      youtube_url: "https://www.youtube.com/watch?v=lONazGlhOdQ",
      fallback_video_id: "HJ2z366lEhI",
      search_query: "Analytical Reverse Phase HPLC C18 Column Acetonitrile Gradient Protein Purity SDS-PAGE",
      channel_name: "Pharma Growth Hub",
      duration: "32:15",
      difficulty: "Advanced",
      topic_focus: "C18/C4 Silica Columns, Hydrophobic Interactions, Acetonitrile/TFA Gradients & Peak Integration",
      key_takeaways: [
        "Reverse Phase HPLC principles: Non-polar stationary phase (C4 for intact proteins, C18 for peptides) with polar aqueous mobile phase",
        "Organic modifier gradient elution: Water/Acetonitrile with 0.1% Trifluoroacetic acid (TFA) ion-pairing reagent",
        "Quantifying therapeutic protein purity and identifying post-translational modifications (deamidation, oxidation)",
        "Orthogonal purity confirmation: SDS-PAGE silver staining, Western blot, and capillary isoelectric focusing (cIEF)"
      ]
    }],
    4: [{
      id: "bio-chr-p4-downstream-interview",
      title: "Downstream Bioprocess / Purification Scientist Placement Interview & Viva",
      youtube_video_id: "qAJLl__hxMI",
      youtube_url: "https://www.youtube.com/watch?v=qAJLl__hxMI",
      fallback_video_id: "kH7xlbOu3Q4",
      search_query: "Downstream Processing Scientist Technical Interview Chromatography Viral Clearance Viva",
      channel_name: "Manas Tutorial ",
      duration: "30:45",
      difficulty: "Placement",
      topic_focus: "Viral Clearance Steps (Low pH Inactivation, Nanofiltration), TFF Ultrafiltration & Placement Viva",
      key_takeaways: [
        "Mandatory downstream viral safety: Low pH viral inactivation, solvent-detergent treatment, and 20nm viral nanofiltration",
        "Tangential Flow Filtration (TFF): Ultrafiltration / Diafiltration (UF/DF) for final drug substance concentration and buffer exchange",
        "Troubleshooting chromatographic column fouling, peak tailing, and resin lifetime re-use validation",
        "Passing downstream purification technical interviews at Novartis, Roche, Pfizer, and Dr. Reddy's Biologics"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // BIOTECH: Bio-Informatics Python & Sequence Alignment
  // --------------------------------------------------------------------------
  'bio-bioinfo': {
    0: [{
      id: "bio-inf-p0-biopython",
      title: "Bioinformatics with Python: BioPython, FASTA Parsing & Seq Objects",
      youtube_video_id: "zidLpWef5_4",
      youtube_url: "https://www.youtube.com/watch?v=zidLpWef5_4",
      fallback_video_id: "yj3qld0J5EY",
      search_query: "Biopython Tutorial for Beginners SeqIO FASTA Transcription Translation Python",
      channel_name: "Python for Bioinformatics",
      duration: "23:10",
      difficulty: "Beginner",
      topic_focus: "SeqRecord Objects, SeqIO.parse, Complement, Reverse Complement & Transcription/Translation",
      key_takeaways: [
        "Structure of biological sequence file formats: FASTA headers and FASTQ quality score encoding (Phred scores)",
        "Manipulating nucleotide sequences with Bio.Seq: DNA to mRNA transcription and translation into 20 amino acid peptides",
        "Parsing multi-megabyte FASTA genomic files efficiently using generator pipelines (Bio.SeqIO.parse)",
        "Calculating GC content percentage and detecting CpG islands in gene promoter regions"
      ]
    }],
    1: [{
      id: "bio-inf-p1-alignment-algorithms",
      title: "Pairwise Sequence Alignment: Needleman-Wunsch (Global) & Smith-Waterman (Local)",
      youtube_video_id: "Lsa-VfSQgt4",
      youtube_url: "https://www.youtube.com/watch?v=Lsa-VfSQgt4",
      fallback_video_id: "bFDRny7T3_s",
      search_query: "Needleman Wunsch Global Alignment Smith Waterman Local Alignment Dynamic Programming Matrix",
      channel_name: "Bio Scholar",
      duration: "28:20",
      difficulty: "Intermediate",
      topic_focus: "Dynamic Programming Grid, Match/Mismatch Scores, Affine Gap Penalties & Traceback Matrix",
      key_takeaways: [
        "Dynamic programming formulation for sequence comparison: Filling the 2D scoring matrix from top-left",
        "Needleman-Wunsch algorithm: Global end-to-end alignment maximizing overall sequence similarity",
        "Smith-Waterman algorithm: Local alignment resetting negative cell scores to zero to find conserved functional motifs",
        "Affine gap penalties: Distinguishing high gap opening cost from lower gap extension penalty"
      ]
    }],
    2: [{
      id: "bio-inf-p2-blast-matrices",
      title: "BLAST Algorithm & Scoring Matrices: PAM vs BLOSUM62 and E-Values",
      youtube_video_id: "R05PaiyE2RQ",
      youtube_url: "https://www.youtube.com/watch?v=R05PaiyE2RQ",
      fallback_video_id: "DncDNhP0p0E",
      search_query: "BLAST Algorithm Tutorial BLOSUM62 PAM Matrix Expect Value E-Value NCBI BLAST",
      channel_name: "Biosolutions by Gunjan",
      duration: "27:40",
      difficulty: "Intermediate",
      topic_focus: "Seed Word Matching (k-mers), Ungapped Extension, BLOSUM62 Derivation & E-Value Interpretation",
      key_takeaways: [
        "Heuristic database search: Why BLAST is 100x faster than Smith-Waterman using short exact seed matches (k-mers)",
        "Derivation of log-odds substitution matrices: PAM (divergent evolutionary distance) vs BLOSUM62 (conserved blocks)",
        "Interpreting the Expect Value (E-value): Number of expected chance hits; thresholding statistically significant homologs (E < 10^-5)",
        "Automating remote and local BLAST queries using NCBI REST APIs and Python's Bio.Blast.NCBIWWW module"
      ]
    }],
    3: [{
      id: "bio-inf-p3-ngs-pipeline",
      title: "Next-Generation Sequencing (NGS) Data Analysis: FastQC, BWA Alignment & GATK Variant Calling",
      youtube_video_id: "iHkiQvxyr5c",
      youtube_url: "https://www.youtube.com/watch?v=iHkiQvxyr5c",
      fallback_video_id: "gkSdzMApWF4",
      search_query: "Next Generation Sequencing NGS Data Analysis FastQC BWA MEM SAMtools GATK Variant Calling",
      channel_name: "Bioinformagician",
      duration: "34:15",
      difficulty: "Advanced",
      topic_focus: "FASTQ Quality Trimming (Trimmomatic), Burrows-Wheeler Aligner (BWA), BAM Sorting & VCF Files",
      key_takeaways: [
        "Quality assessment of raw Illumina sequencing reads: FastQC reports (per-base quality, adapter contamination)",
        "Burrows-Wheeler Transform (BWA-MEM) indexing and reference genome read mapping",
        "Processing SAM/BAM alignments using SAMtools: Coordinate sorting, indexing, and PCR duplicate marking",
        "Broad Institute GATK Best Practices pipeline: HaplotypeCaller generating Variant Call Format (VCF) files for SNPs and indels"
      ]
    }],
    4: [{
      id: "bio-inf-p4-bioinfo-interview",
      title: "Bioinformatics / Computational Biology Placement Interview & Technical Screening Viva",
      youtube_video_id: "2Rf2HrMdM68",
      youtube_url: "https://www.youtube.com/watch?v=2Rf2HrMdM68",
      fallback_video_id: "u4r1Fp2Auf8",
      search_query: "Bioinformatics Scientist Technical Interview Questions Python Algorithm Coding Viva",
      channel_name: "CodeLucky",
      duration: "30:30",
      difficulty: "Placement",
      topic_focus: "Hidden Markov Models (HMM), RNA-Seq Differential Expression (DESeq2) & Placement Viva",
      key_takeaways: [
        "Profile Hidden Markov Models (HMMER) for detecting remote protein family homologous domains",
        "RNA-Seq differential gene expression workflows: Read counting (featureCounts) and negative binomial models in DESeq2",
        "High-performance computing (HPC) for genomics: Writing reproducible Nextflow and Snakemake pipeline workflows",
        "Clearing computational biology technical interviews at Illumina, Broad Institute, 23andMe, and AstraZeneca"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // BIOTECH: Biomedical Device Design & Biosensors
  // --------------------------------------------------------------------------
  'bio-meddevice': {
    0: [{
      id: "bio-med-p0-sensors-basics",
      title: "Biosensors Working Principles: Bioreceptors, Transducers & Immobilization Methods",
      youtube_video_id: "Fpsu7RXbBYM",
      youtube_url: "https://www.youtube.com/watch?v=Fpsu7RXbBYM",
      fallback_video_id: "nxySi4rJkQE",
      search_query: "Biosensors Working Principle Bioreceptor Transducer Enzyme Antibody DNA Sensor",
      channel_name: "Carewell pharma",
      duration: "23:50",
      difficulty: "Beginner",
      topic_focus: "Enzymatic vs Immunosensors, Electrochemical Transducers, Covalent Coupling & Crosslinking",
      key_takeaways: [
        "The three structural components of a biosensor: Biological recognition element, physical transducer, signal amplifier",
        "Bioreceptor types: Enzymes (glucose oxidase), antibodies (antigen affinity), nucleic acids (DNA hybridization), aptamers",
        "Transduction mechanisms: Electrochemical (amperometric, potentiometric), optical (surface plasmon resonance), piezoelectric",
        "Surface immobilization chemistry: Self-Assembled Monolayers (SAM), EDC-NHS covalent amine coupling, entrapment"
      ]
    }],
    1: [{
      id: "bio-med-p1-glucose-sensor",
      title: "Electrochemical Biosensors: Glucose Meter Demonstration & Cyclic Voltammetry",
      youtube_video_id: "OUu5bhGGjj8",
      youtube_url: "https://www.youtube.com/watch?v=OUu5bhGGjj8",
      fallback_video_id: "dSgyOkEqRb8",
      search_query: "Electrochemical Biosensor Glucose Meter Cyclic Voltammetry Working Counter Reference",
      channel_name: "dheerajdh",
      duration: "27:10",
      difficulty: "Intermediate",
      topic_focus: "3-Electrode Cell (Working, Counter, Reference), Glucose Oxidase Reaction & Ferrocene Mediators",
      key_takeaways: [
        "Three-electrode electrochemical cell: Working electrode (sensing), Reference electrode (Ag/AgCl), Counter auxiliary electrode",
        "1st, 2nd, and 3rd generation glucose biosensors: Oxygen dependence vs synthetic electron mediators (Ferrocene/Osmium)",
        "Interpreting Cyclic Voltammetry (CV) duck-shaped voltammograms: Anodic and cathodic peak currents and redox reversibility",
        "Chronoamperometry for commercial point-of-care test strips: Cottrell equation relating current to analyte concentration"
      ]
    }],
    2: [{
      id: "bio-med-p2-microfluidics",
      title: "Microfluidic Lab-on-a-Chip: PDMS Soft Lithography & Capillary Flow Devices",
      youtube_video_id: "lH-FCSxRvrU",
      youtube_url: "https://www.youtube.com/watch?v=lH-FCSxRvrU",
      fallback_video_id: "sBLRe6IlwyY",
      search_query: "Microfluidics Lab on a Chip PDMS Soft Lithography Cleanroom Photolithography Channels",
      channel_name: "Queen Mary Microfluidics",
      duration: "29:30",
      difficulty: "Intermediate",
      topic_focus: "Laminar Flow at Low Reynolds Number (Re << 1), Diffusion Mixing, SU-8 Photoresist & PDMS Plasma Bonding",
      key_takeaways: [
        "Fluid mechanics at microscale: Laminar flow without turbulence (Re << 1) and purely diffusion-dominated molecular mixing",
        "Soft lithography fabrication: Spin-coating SU-8 photoresist on silicon wafers, UV mask photolithography, master molding",
        "Curing and casting Polydimethylsiloxane (PDMS) silicone elastomer micro-channels",
        "Oxygen plasma surface activation to achieve irreversible covalent bonding of PDMS to glass slides"
      ]
    }],
    3: [{
      id: "bio-med-p3-iso13485",
      title: "Medical Device Regulatory Engineering: ISO 13485, Risk Analysis (ISO 14971) & FDA 510(k)",
      youtube_video_id: "y_mD3i8EWnE",
      youtube_url: "https://www.youtube.com/watch?v=y_mD3i8EWnE",
      fallback_video_id: "TsWwBMD4XGs",
      search_query: "Medical Device Design Controls ISO 13485 ISO 14971 Risk Management FDA 510k Clearance",
      channel_name: "Medical Device HQ",
      duration: "32:40",
      difficulty: "Advanced",
      topic_focus: "Device Classification (Class I, II, III), Design Controls (Waterfall), FMEA & 510(k) Equivalence",
      key_takeaways: [
        "Medical device risk classification: Class I (low risk), Class II (moderate risk point-of-care), Class III (life-supporting implants)",
        "FDA 21 CFR 820 Design Controls waterfall: User Needs -> Design Inputs -> Design Outputs -> Verification & Validation",
        "Risk management to ISO 14971: Performing Design FMEA (Failure Mode and Effects Analysis) and mitigations",
        "Preparing FDA 510(k) premarket notification demonstrating Substantial Equivalence (SE) to a legally marketed predicate device"
      ]
    }],
    4: [{
      id: "bio-med-p4-device-interview",
      title: "Biomedical Systems Engineer Placement Interview & Hardware Screening Viva",
      youtube_video_id: "DuZ8ljGNtqY",
      youtube_url: "https://www.youtube.com/watch?v=DuZ8ljGNtqY",
      fallback_video_id: "OCk6a8-m83I",
      search_query: "Biomedical Engineer Technical Interview Questions Biosensors Medical Device Hardware Viva",
      channel_name: "Top Career Interviews",
      duration: "30:15",
      difficulty: "Placement",
      topic_focus: "Biocompatibility Standards (ISO 10993), Wearable Sensors, Electrical Safety (IEC 60601) & Viva",
      key_takeaways: [
        "Biocompatibility evaluation under ISO 10993: Cytotoxicity, sensitization, irritation, and hemocompatibility assays",
        "Medical electrical safety standards: IEC 60601-1 patient leakage current limits (Type B, BF, CF applied parts)",
        "Continuous Glucose Monitoring (CGM) sensor design challenges: In vivo biofouling and foreign body capsule encapsulation",
        "Clearing biomedical engineering technical interviews at Medtronic, Abbott, Dexcom, Philips Healthcare, and Roche Diagnostics"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // BIOTECH: cGMP Cleanroom & Biopharma Regulatory Standards
  // --------------------------------------------------------------------------
  'bio-cgmp': {
    0: [{
      id: "bio-gmp-p0-basics",
      title: "cGMP Principles for Biopharma: Good Manufacturing Practices & Documentation (ALCOA+)",
      youtube_video_id: "u8Wz8xkHzC0",
      youtube_url: "https://www.youtube.com/watch?v=u8Wz8xkHzC0",
      fallback_video_id: "AeCGy7PeYo0",
      search_query: "cGMP Principles Good Manufacturing Practices ALCOA Plus Data Integrity FDA",
      channel_name: "Technical Vimal Pharma ",
      duration: "23:45",
      difficulty: "Beginner",
      topic_focus: "Current Good Manufacturing Practices (21 CFR Part 211), ALCOA+ Principles & Batch Production Records",
      key_takeaways: [
        "The core purpose of cGMP: Ensuring drugs meet safety, identity, strength, purity, and quality (SISPQ) standards",
        "Data Integrity ALCOA+ criteria: Attributable, Legible, Contemporaneous, Original, Accurate, Complete, Consistent",
        "Good Documentation Practices (GDP): Real-time recording, no white-out correction fluids, single-line strike-through with signature",
        "Batch Production Records (BPR): Traceable step-by-step master manufacturing instructions and dual operator sign-offs"
      ]
    }],
    1: [{
      id: "bio-gmp-p1-cleanroom-iso",
      title: "Cleanroom Classification (ISO 14644 / EU GMP Grades A-D) & Air Handling (HVAC)",
      youtube_video_id: "_wvnaogmp4k",
      youtube_url: "https://www.youtube.com/watch?v=_wvnaogmp4k",
      fallback_video_id: "3TOzsle8KbE",
      search_query: "Cleanroom Classification ISO 14644 EU GMP Grade A B C D HEPA Filtration HVAC Pressure Cascade",
      channel_name: "Pharmaguideline",
      duration: "27:30",
      difficulty: "Intermediate",
      topic_focus: "Particle Counts (0.5 and 5.0 micron), Laminar Flow (0.45 m/s), Pressure Differentials (10-15 Pa) & Airlocks",
      key_takeaways: [
        "EU GMP cleanroom grading: Grade A (laminar flow critical filling zone, ISO 5), Grade B (aseptic prep), Grades C & D",
        "Airborne particulate limits: At-rest vs in-operation maximum permitted particle counts per cubic meter",
        "HVAC design principles: Terminal HEPA filters (99.97% efficiency at 0.3 micron) and minimum 20-30 air changes per hour",
        "Pressure cascade hierarchies: Positive pressure differentials (10-15 Pascals) outward from cleanest to less clean areas"
      ]
    }],
    2: [{
      id: "bio-gmp-p2-gowning-environmental",
      title: "Aseptic Gowning Procedures & Environmental Monitoring (EM) Programs",
      youtube_video_id: "DHG0S2ZvHKo",
      youtube_url: "https://www.youtube.com/watch?v=DHG0S2ZvHKo",
      fallback_video_id: "KdndbLKHxmw",
      search_query: "Aseptic Gowning Procedure Grade A B Cleanroom Environmental Monitoring Settle Plates Air Sampler",
      channel_name: "Hardy Diagnostics",
      duration: "28:50",
      difficulty: "Intermediate",
      topic_focus: "Step-by-Step Gowning Qualification, Active Air Samplers, Settle Plates, Contact Plates & Action Limits",
      key_takeaways: [
        "Zero skin exposure rule: Sterile jumpsuits, hood, face mask, eye goggles, boots, and double sterile nitrile gloves",
        "Personnel gowning qualification: Consecutive 3-run post-gowning contact plate fingertip and gown monitoring (<1 CFU)",
        "Environmental Monitoring (EM) tools: Volumetric air samplers, 4-hour settle plates, surface contact (RODAC) plates",
        "Establishing Alert Limits and Action Limits; immediate investigation and sanitization upon microbial excursions"
      ]
    }],
    3: [{
      id: "bio-gmp-p3-validation-capa",
      title: "Quality Management: Out of Specification (OOS), Deviations & CAPA Workflows",
      youtube_video_id: "wRJk-M2eCy0",
      youtube_url: "https://www.youtube.com/watch?v=wRJk-M2eCy0",
      fallback_video_id: "jSinZH0wlck",
      search_query: "Out of Specification OOS Investigation Root Cause Analysis 5 Whys Fishbone CAPA Workflow",
      channel_name: "Pharma Growth Hub",
      duration: "31:40",
      difficulty: "Advanced",
      topic_focus: "Phase 1 Lab Investigation vs Phase 2 Manufacturing Investigation, Ishikawa Diagram & CAPA Effectiveness",
      key_takeaways: [
        "Handling Out of Specification (OOS) lab test results according to FDA OOS guidance: Phase 1 immediate lab error check",
        "Root cause analysis methodologies: The 5 Whys, Ishikawa Fishbone diagrams, and failure mode mapping",
        "Corrective and Preventive Actions (CAPA) lifecycle: Root cause identification, action plan execution, and effectiveness checks",
        "Change Control management: Evaluating the impact of raw material supplier changes or equipment modifications on validated state"
      ]
    }],
    4: [{
      id: "bio-gmp-p4-gmp-interview",
      title: "Quality Assurance (QA) / Quality Control (QC) Placement Interview & FDA Audit Viva",
      youtube_video_id: "uLd_aBiUCYc",
      youtube_url: "https://www.youtube.com/watch?v=uLd_aBiUCYc",
      fallback_video_id: "k0rJYPkmAjg",
      search_query: "Pharma QA QC Placement Interview FDA Form 483 Process Validation Biocon Pfizer",
      channel_name: "PharmEx Solutions",
      duration: "34:20",
      difficulty: "Placement",
      topic_focus: "FDA Form 483 Observations, Warning Letters, Process Validation (Stage 1, 2, 3) & Placement Screening",
      key_takeaways: [
        "The three stages of Process Validation: Stage 1 Process Design, Stage 2 Process Qualification (PPQ 3 batches), Stage 3 Continued Verification",
        "Understanding regulatory inspections: Responding to FDA Form 483 observations within 15 business days to avert Warning Letters",
        "Conducting mock regulatory audit interviews with composure, adherence to facts, and zero unverified speculation",
        "Acing Quality Assurance and Quality Control technical interviews at Pfizer, Novartis, Biocon, Sun Pharma, and Cipla"
      ]
    }]
  },

  // ==========================================================================
  // MARINE ENGINEERING CO-DOMAINS
  // ==========================================================================

  // --------------------------------------------------------------------------
  // MARINE: Marine Diesel Engines & Propulsion Systems
  // --------------------------------------------------------------------------
  'mar-diesel': {
    0: [{
      id: "mar-dsl-p0-crosshead-basics",
      title: "Marine 2-Stroke Crosshead Diesel Engines: Working Cycle & Component Anatomy",
      youtube_video_id: "3zRIndR9j40",
      youtube_url: "https://www.youtube.com/watch?v=3zRIndR9j40",
      fallback_video_id: "-Bo6XYkyLHo",
      search_query: "Marine 2 Stroke Diesel Engine Crosshead Piston Stuffing Box MAN B&W",
      channel_name: "3D Living Studio",
      duration: "26:40",
      difficulty: "Beginner",
      topic_focus: "Bedplate, A-Frame, Cylinder Liner, Stuffing Box, Crosshead Guide & Uniflow Scavenging",
      key_takeaways: [
        "Anatomy of large marine 2-stroke low-speed crosshead engines (MAN B&W, WinGD)",
        "Role of the crosshead: Translating connecting rod angular side thrust to the engine frame rather than piston skirts",
        "Piston rod stuffing box: Preventing contaminated crankcase oil from mixing with combustion cylinder drainings",
        "Uniflow scavenging mechanism: Scavenge air ports at bottom of liner and hydraulically operated central exhaust valve"
      ]
    }],
    1: [{
      id: "mar-dsl-p1-fuel-injection",
      title: "Common Rail Fuel Injection & Exhaust Gas Turbocharger Systems",
      youtube_video_id: "bL8zTXmLQKk",
      youtube_url: "https://www.youtube.com/watch?v=bL8zTXmLQKk",
      fallback_video_id: "3vO0FbfW5u8",
      search_query: "Marine Diesel Electronic Fuel Injection Common Rail Turbocharger Surging Scavenge Air",
      channel_name: "Supreme_Engineer",
      duration: "29:15",
      difficulty: "Intermediate",
      topic_focus: "High-Pressure Common Rail (1000+ bar), Electronic Control (ME Engines), Turbocharger Surging & Air Cooler",
      key_takeaways: [
        "Electronically controlled marine diesel engines (MAN ME-C / WinGD X-DF): Hydraulic-electric actuation replacing camshafts",
        "Variable Injection Timing (VIT) and multiple pilot fuel injection pulses for optimized low-load fuel efficiency",
        "Exhaust gas turbochargers: Turbine wheel, compressor impeller, nozzle ring, and air cooler condensation water mist catchers",
        "Root cause of turbocharger surging: Mismatch between scavenge manifold backpressure and turbine mass flow"
      ]
    }],
    2: [{
      id: "mar-dsl-p2-indicator-diagrams",
      title: "Indicator Diagrams & Power Balancing: Peak Pressure & Mean Indicated Pressure (MIP)",
      youtube_video_id: "AM-c_M5woJQ",
      youtube_url: "https://www.youtube.com/watch?v=AM-c_M5woJQ",
      fallback_video_id: "Y0ll5HaJTVs",
      search_query: "Marine Engine Indicator Diagram Power Cards Draw Cards Peak Pressure Pmax Compression Pcomp",
      channel_name: "Marine Pathshala",
      duration: "28:20",
      difficulty: "Intermediate",
      topic_focus: "Normal Indicator Cards, Draw Cards (Out-of-Phase), Compression Pressure (Pcomp) & Peak Firing (Pmax)",
      key_takeaways: [
        "Taking electronic cylinder indicator measurements: Normal power cards (area = indicated work) and 90-degree draw cards",
        "Analyzing cylinder compression pressure (Pcomp) vs maximum peak firing pressure (Pmax)",
        "Diagnosing faulty combustion: Leaking exhaust valves, early/retarded fuel injection timing, worn fuel injectors",
        "Balancing power distribution evenly across all cylinders to prevent crankshaft torsional stress fatigue"
      ]
    }],
    3: [{
      id: "mar-dsl-p3-crankcase-explosion",
      title: "Crankcase Explosion Hazards, Mist Detectors & Scavenge Fire Extinguishing",
      youtube_video_id: "7AjjxutFoBU",
      youtube_url: "https://www.youtube.com/watch?v=7AjjxutFoBU",
      fallback_video_id: "eROHJaUz6p8",
      search_query: "Marine Engine Crankcase Explosion Oil Mist Detector Relief Valves Scavenge Fire CO2",
      channel_name: "Marine Eng Videos",
      duration: "31:50",
      difficulty: "Advanced",
      topic_focus: "Hot Spots (Overheated Bearings), Oil Mist Explosive Limits, Relief Doors & High-Pressure CO2 Smothering",
      key_takeaways: [
        "Mechanism of crankcase explosions: Bearing overheating vaporizing lube oil into explosive sub-micron mist droplets",
        "Graviner optical oil mist detectors: Triggering automatic engine slowdown upon detecting high mist opacity",
        "Crankcase explosion relief valves: Spring-loaded flame arrestor discs releasing internal overpressure safely",
        "Scavenge space fires: Detecting high scavenge box temperature, reducing RPM, and activating fixed CO2 / steam drenching"
      ]
    }],
    4: [{
      id: "mar-dsl-p4-propulsion-interview",
      title: "Marine Chief Engineer / 4th Engineer Placement Interview & MMD Class IV Viva",
      youtube_video_id: "eEQkk03bYbU",
      youtube_url: "https://www.youtube.com/watch?v=eEQkk03bYbU",
      fallback_video_id: "jie9E0IOBAQ",
      search_query: "Marine Engineering Class 4 Oral Exam Questions Main Engine Emergency Maneuvering Viva",
      channel_name: "The Marine Whales",
      duration: "33:10",
      difficulty: "Placement",
      topic_focus: "Emergency Maneuvering Console, Reversing Air Starting Sequence, Crankshaft Deflection & Viva",
      key_takeaways: [
        "Executing emergency bridge-to-engine room changeover and manual local maneuvering on the starting console",
        "Engine starting air system: Air compressors (30 bar), master starting air valve, air distributor, cylinder starting valves",
        "Measuring and logging crankshaft bridge gauge clearances and cold/hot web deflections (hogging vs sagging)",
        "Acing Class IV / Class II Marine Engineer Officer government MMD oral examinations and shipping company interviews"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // MARINE: Ship Hydrostatics, Metacentric Height & Stability
  // --------------------------------------------------------------------------
  'mar-stability': {
    0: [{
      id: "mar-stb-p0-hydrostatics",
      title: "Ship Hydrostatics: Archimedes Principle, Center of Buoyancy (B) & Center of Gravity (G)",
      youtube_video_id: "190HXFtz2zU",
      youtube_url: "https://www.youtube.com/watch?v=190HXFtz2zU",
      fallback_video_id: "X5R7NLues5M",
      search_query: "Ship Stability Basics Center of Gravity G Center of Buoyancy B Metacenter M",
      channel_name: "sail skills",
      duration: "24:15",
      difficulty: "Beginner",
      topic_focus: "Displacement Tonnage, Draft, Keel (K), Center of Buoyancy (KB), Center of Gravity (KG) & Metacenter (KM)",
      key_takeaways: [
        "Archimedes principle applied to marine vessels: Ship displacement strictly equals mass of displaced water",
        "Vertical reference planes: Keel baseline (K), Center of Buoyancy (B centroid of underwater hull), Center of Gravity (G)",
        "Transverse Metacenter (M): The intersection of vertical buoyant force lines as the ship heels through small angles",
        "Fundamental stability equation: KM = KB + BM (where BM is Metacentric Radius = transverse moment of inertia / volume)"
      ]
    }],
    1: [{
      id: "mar-stb-p1-metacentric-height",
      title: "Metacentric Height (GM): Stable, Neutral & Unstable Equilibrium States",
      youtube_video_id: "ZV4x1cj5cEQ",
      youtube_url: "https://www.youtube.com/watch?v=ZV4x1cj5cEQ",
      fallback_video_id: "6mZbP61KLCk",
      search_query: "Ship Metacentric Height GM Stable Unstable Neutral Equilibrium Stiff Tender Ship",
      channel_name: "Capt.S.S. Chaudhari",
      duration: "27:40",
      difficulty: "Intermediate",
      topic_focus: "Righting Moment (GZ = GM * sin(theta)), Stiff vs Tender Ships, Positive GM & Angle of Loll",
      key_takeaways: [
        "Evaluating initial stability: Positive GM (G below M = righting couple), Neutral GM (G coincident with M), Negative GM",
        "Righting lever arm: GZ = GM * sin(theta) for small angles of heel (<10-15 degrees)",
        "Stiff ships (excessively large GM): Violent, snappy roll periods causing cargo lashings failure and crew discomfort",
        "Tender ships (very small GM): Sluggish rolling, and dangers of negative GM producing an Angle of Loll"
      ]
    }],
    2: [{
      id: "mar-stb-p2-gz-curves",
      title: "GZ Curves (Curves of Statical Stability) & IMO Intact Stability Criteria",
      youtube_video_id: "eUi4yktaU5Y",
      youtube_url: "https://www.youtube.com/watch?v=eUi4yktaU5Y",
      fallback_video_id: "g5DdSSMYa-Q",
      search_query: "GZ Curve Curve of Statical Stability IMO Intact Stability Code Area Under Curve",
      channel_name: "Pro Sailor",
      duration: "29:50",
      difficulty: "Intermediate",
      topic_focus: "Maximum GZ Value, Angle of Vanishing Stability, Range of Stability & Dynamic Stability (Area Under GZ)",
      key_takeaways: [
        "Constructing the GZ curve: Plotting righting arm GZ across heel angles up to 90 degrees",
        "Key GZ features: Initial GM slope at origin, maximum GZ amplitude, and Angle of Vanishing Stability (range)",
        "IMO Intact Stability Code criteria: Minimum GM >= 0.15m, Area under GZ up to 30 deg >= 0.055 m-rad",
        "Severe wind heel and rolling criterion: Assessing dynamic wind heeling moments against righting energy"
      ]
    }],
    3: [{
      id: "mar-stb-p3-free-surface-damage",
      title: "Free Surface Effect (FSE) & Compartment Flooding / Damage Stability",
      youtube_video_id: "1MwE-ArZTWE",
      youtube_url: "https://www.youtube.com/watch?v=1MwE-ArZTWE",
      fallback_video_id: "ZpuPhc7oL2s",
      search_query: "Free Surface Effect FSE Tank Baffles Virtual Loss of GM Damage Stability SOLAS",
      channel_name: "SAILORSTUBE",
      duration: "32:30",
      difficulty: "Advanced",
      topic_focus: "Slack Tanks, Virtual Rise of G (GG1 = i / V), Longitudinal Bulkheads & SOLAS Probabilistic Stability",
      key_takeaways: [
        "Free surface effect in slack ballast and cargo fuel tanks: Liquid shift creating a virtual loss of GM (GG1 = rho*i / displacement)",
        "Mitigating FSE: Keeping tanks either 100% pressed full or completely empty; installing longitudinal wash bulkheads",
        "Damage stability methods: Added weight method vs lost buoyancy method during hull breach flooding",
        "SOLAS Chapter II-1 probabilistic damage stability: Required subdivision index (R) and attained index (A)"
      ]
    }],
    4: [{
      id: "mar-stb-p4-stability-interview",
      title: "Deck Officer / Naval Architect Placement Interview & Loading Computer Viva",
      youtube_video_id: "J94Uf-jrHYA",
      youtube_url: "https://www.youtube.com/watch?v=J94Uf-jrHYA",
      fallback_video_id: "Z04hKKprLqw",
      search_query: "Ship Stability Technical Interview Questions Inclining Experiment Loading Computer Viva",
      channel_name: "Nav Insider",
      duration: "30:45",
      difficulty: "Placement",
      topic_focus: "The Inclining Experiment Procedure, Trim & Bending Moments (Shear Force / Bending Moment) & Viva",
      key_takeaways: [
        "Conducting the shipyard Inclining Experiment: Shifting known weights transversely to determine accurate as-built lightship KG",
        "Monitoring longitudinal hull girder stresses: Still water shear force (SFS) and bending moments (BM) in loading software",
        "Handling dangerous cargo loading conditions: Liquefaction of mineral ore bulk cargoes and parametric rolling in container ships",
        "Passing technical screening at Lloyd's Register, DNV, ABS, Maersk, and Indian Register of Shipping (IRS)"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // MARINE: Marine Auxiliary Boilers, Purifiers & FWG
  // --------------------------------------------------------------------------
  'mar-auxiliary': {
    0: [{
      id: "mar-aux-p0-purifiers",
      title: "Marine Centrifugal Fuel Oil Purifiers & Clarifiers: Operating Principles",
      youtube_video_id: "QWDB4UlOAJs",
      youtube_url: "https://www.youtube.com/watch?v=QWDB4UlOAJs",
      fallback_video_id: "WB9ly14RIAo",
      search_query: "Marine Purifier Clarifier Centrifugal Separator Gravity Disc Alfa Laval",
      channel_name: "Marine Eng Videos",
      duration: "25:30",
      difficulty: "Beginner",
      topic_focus: "Stokes' Law, High-Speed Bowl (8000+ RPM), Gravity Disc Selection & Operating Water Seal",
      key_takeaways: [
        "Centrifugal separation physics: Replacing gravitational settling with 5000-8000 G centrifugal acceleration",
        "Purifier setup: Separating water and solid sludge from fuel oil; establishing unbroken water seal before fuel feed",
        "Selecting optimal gravity disc diameter based on fuel oil density and separation temperature (98°C for HFO)",
        "Clarifier mode setup (blind disc): Removing fine catalytic cat fines and sub-micron particulate sediments"
      ]
    }],
    1: [{
      id: "mar-aux-p1-boilers",
      title: "Marine Auxiliary Oil-Fired & Exhaust Gas Economizer Boilers",
      youtube_video_id: "BDvR_pDebiI",
      youtube_url: "https://www.youtube.com/watch?v=BDvR_pDebiI",
      fallback_video_id: "C79NSuYiPDk",
      search_query: "Marine Auxiliary Boiler Exhaust Gas Economizer Composite Boiler Water Level Glass",
      channel_name: "HIMT",
      duration: "28:10",
      difficulty: "Intermediate",
      topic_focus: "Smoke Tube vs Water Tube Boilers, Feedwater Treatment, Gauge Glass Blowing & Economizers",
      key_takeaways: [
        "Auxiliary steam duties: Fuel oil tank heating coils, purifier preheaters, cabin air conditioning, and soot blowing",
        "Exhaust Gas Economizer (EGE): Utilizing main engine waste exhaust heat at sea to generate saturated steam",
        "Testing and blowing down boiler gauge glasses to verify clear true water level and avoid catastrophic dry firing",
        "Boiler water chemical conditioning: Alkalinity, phosphate buffering, and dissolved oxygen scavengers (Hydrazine/DEHA)"
      ]
    }],
    2: [{
      id: "mar-aux-p2-freshwater",
      title: "Fresh Water Generators: Vacuum Distillation & Reverse Osmosis Plants",
      youtube_video_id: "5K21I-pnEQE",
      youtube_url: "https://www.youtube.com/watch?v=5K21I-pnEQE",
      fallback_video_id: "NSbF7ltmUd0",
      search_query: "Fresh Water Generator Vacuum Distillation Marine Jacket Water Ejector Salinometer",
      channel_name: "HIMT",
      duration: "26:50",
      difficulty: "Intermediate",
      topic_focus: "Vacuum Boiling (40-45°C), Water Ejector / Air Ejector, Salinometer Demister & Distillate Pump",
      key_takeaways: [
        "Vacuum distillation physics: Lowering chamber boiling point to 40-45°C using seawater/air combined ejectors (90% vacuum)",
        "Utilizing waste engine jacket cooling water (80-85°C) as the heat source in plate-type heat exchangers",
        "Demister mesh pads: Preventing seawater droplets and carryover foam from contaminating distilled vapor",
        "Salinometer monitoring: Automatically dumping distillate to bilge if salinity exceeds 10 ppm"
      ]
    }],
    3: [{
      id: "mar-aux-p3-ows-marpol",
      title: "Oily Water Separator (OWS) & 15 PPM Bilge Alarm Monitor (MEPC.107(49))",
      youtube_video_id: "5lpLUJ___ls",
      youtube_url: "https://www.youtube.com/watch?v=5lpLUJ___ls",
      fallback_video_id: "ERRCdyigQEU",
      search_query: "Oily Water Separator OWS 15 PPM Bilge Alarm Marpol Annex 1 Oil Record Book",
      channel_name: "HIMT",
      duration: "30:40",
      difficulty: "Advanced",
      topic_focus: "Coalescer Cartridges, 15 PPM Optical Turbidity Cell, 3-Way Recirculation Valve & Oil Record Book",
      key_takeaways: [
        "Multi-stage oily water separation: Gravity separation chamber followed by fine coalescer filtration cartridges",
        "Operating the 15 PPM Bilge Alarm: Optical turbidity sensor with continuous fresh water flushing cycles",
        "Fail-safe 3-way automatic divert valve: Diverting effluent back to the bilge holding tank if oil content reaches 15 ppm",
        "Maintaining accurate, tamper-proof entries in the Oil Record Book Part 1 (Machinery Space Operations)"
      ]
    }],
    4: [{
      id: "mar-aux-p4-auxiliary-interview",
      title: "Marine Auxiliary Machinery Technical Placement Interview & Troubleshooting Viva",
      youtube_video_id: "UFleFh0ZR7c",
      youtube_url: "https://www.youtube.com/watch?v=UFleFh0ZR7c",
      fallback_video_id: "vsVAT3xpNGQ",
      search_query: "Marine Engineer Auxiliary Machinery Interview Questions Steering Gear OWS Purifier Viva",
      channel_name: "MEO EXAMS",
      duration: "29:30",
      difficulty: "Placement",
      topic_focus: "Electro-Hydraulic Steering Gear (Ram vs Rotary Vane), Telemotor Controls & Technical Viva",
      key_takeaways: [
        "Operating electro-hydraulic 4-ram and rotary vane steering gear: 100% duplicate power units and hunting gear feedback",
        "SOLAS steering gear requirements: Moving rudder from 35 deg port to 30 deg starboard within 28 seconds at full speed",
        "Emergency steering changeover drills and hydraulic air bleeding procedures",
        "Clearing technical recruitment rounds at Anglo-Eastern, Bernhard Schulte, Synergy Marine, and Fleet Management"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // MARINE: IMO MARPOL Regulations & Environmental Safety
  // --------------------------------------------------------------------------
  'mar-marpol': {
    0: [{
      id: "mar-mar-p0-annexes",
      title: "Overview of IMO MARPOL 73/78: Annexes I through VI Structure",
      youtube_video_id: "5FXozArTGe8",
      youtube_url: "https://www.youtube.com/watch?v=5FXozArTGe8",
      fallback_video_id: "nypejEQrp2o",
      search_query: "MARPOL 73/78 Overview Annex 1 to 6 Oil Sewage Garbage Air Pollution IMO",
      channel_name: "Still Onboard - Seamans Vlog ",
      duration: "24:50",
      difficulty: "Beginner",
      topic_focus: "Annex I (Oil), Annex II (NLS), Annex III (Packaged Goods), Annex IV (Sewage), Annex V (Garbage), Annex VI (Air)",
      key_takeaways: [
        "International Convention for the Prevention of Pollution from Ships (MARPOL) core mission and jurisdiction",
        "The 6 technical annexes: Annex I (Oil), II (Noxious Liquids), III (Harmful Substances in Packaged Form), IV (Sewage), V (Garbage), VI (Air Pollution)",
        "Special Areas defined under MARPOL: Mediterranean, Baltic Sea, Black Sea, Red Sea, Persian Gulf with stricter rules",
        "Port State Control (PSC) inspections and documentation of statutory environmental certificates (IOPP, IAPP, ISPP)"
      ]
    }],
    1: [{
      id: "mar-mar-p1-annex1-oil",
      title: "MARPOL Annex I: Discharge Criteria, Double Hull Tankers & Clean Ballast",
      youtube_video_id: "kW9oPUOocXk",
      youtube_url: "https://www.youtube.com/watch?v=kW9oPUOocXk",
      fallback_video_id: "rBDaoT6SdQk",
      search_query: "MARPOL Annex 1 Oil Discharge Criteria ODME Clean Ballast Double Hull Tanker",
      channel_name: "HIMT",
      duration: "27:15",
      difficulty: "Intermediate",
      topic_focus: "Machinery Space (15 ppm, Ship En Route) vs Cargo Space (30 L/NM, 1/30,000 of cargo), ODME Systems",
      key_takeaways: [
        "Strict discharge limits for machinery space bilges: En route, using approved 15 ppm equipment, no visible sheen",
        "Tanker cargo discharge criteria using Oil Discharge Monitoring Equipment (ODME): Speed >= 7 knots, > 50 NM from land, max 30 L/NM",
        "Segregated Ballast Tanks (SBT) and dedicated clean ballast systems preventing cargo-water cross contact",
        "Mandatory double-hull and double-bottom construction requirements for all crude oil tankers"
      ]
    }],
    2: [{
      id: "mar-mar-p2-annex5-garbage",
      title: "MARPOL Annex V: Garbage Management Plans & Food Waste Commuter Standards",
      youtube_video_id: "1L5CbP4D8Go",
      youtube_url: "https://www.youtube.com/watch?v=1L5CbP4D8Go",
      fallback_video_id: "_g6_eSHVN7M",
      search_query: "MARPOL Annex 5 Garbage Management Plan Plastics Prohibition Food Waste Discharges",
      channel_name: "Captain's Corner",
      duration: "26:30",
      difficulty: "Intermediate",
      topic_focus: "Total Plastic Discharge Prohibition, Food Waste (>12 NM or >3 NM comminuted <25mm), Garbage Record Book",
      key_takeaways: [
        "Absolute, zero-tolerance prohibition on discharging any plastics, synthetic ropes, and incinerator ashes into the sea",
        "Food waste discharge rules outside special areas: > 12 nautical miles (uncomminuted) or > 3 NM (comminuted passing 25mm screen)",
        "Operating marine incinerators: Permitted waste streams vs banned plastics, heavy metals, and polychlorinated biphenyls (PCBs)",
        "Maintaining entries in the Garbage Record Book: Category codes, estimated volumes (m3), position, and shore facility receipts"
      ]
    }],
    3: [{
      id: "mar-mar-p3-annex6-emissions",
      title: "MARPOL Annex VI: Global 0.50% Sulfur Cap, Tier III NOx & EGCS Exhaust Scrubbers",
      youtube_video_id: "uHZ7gN2PUic",
      youtube_url: "https://www.youtube.com/watch?v=uHZ7gN2PUic",
      fallback_video_id: "N_ojdf_g6og",
      search_query: "MARPOL Annex 6 Sulfur Cap 0.50% ECA 0.10% Tier 3 NOx SCR Exhaust Gas Scrubber",
      channel_name: "Sailor's Compass 🧭",
      duration: "32:10",
      difficulty: "Advanced",
      topic_focus: "Global Sulfur Limit (0.50%), Emission Control Areas (0.10% SECA), Open/Closed Loop Scrubbers & SCR",
      key_takeaways: [
        "Global IMO 2020 sulfur cap: Maximum 0.50% sulfur in marine fuel oils worldwide",
        "Emission Control Areas (ECAs - Baltic, North Sea, North America): Ultra-low 0.10% sulfur limit or alternative compliance",
        "Exhaust Gas Cleaning Systems (EGCS / Scrubbers): Open-loop seawater wash vs closed-loop caustic soda (NaOH) recirculation",
        "NOx Tier III regulations: Selective Catalytic Reduction (SCR with urea injection) and Exhaust Gas Recirculation (EGR)"
      ]
    }],
    4: [{
      id: "mar-mar-p4-marpol-interview",
      title: "Maritime Environmental Compliance / Port State Control (PSC) Inspection Viva",
      youtube_video_id: "no5kTcf8L70",
      youtube_url: "https://www.youtube.com/watch?v=no5kTcf8L70",
      fallback_video_id: "zTWxI3DuSkY",
      search_query: "Port State Control PSC Inspection Questions MARPOL Compliance Magic Pipe Defense Viva",
      channel_name: "Oral exam Mmd prep",
      duration: "31:40",
      difficulty: "Placement",
      topic_focus: "PSC Concentrated Inspection Campaigns (CIC), Magic Pipe Violations, USCG Bunkering Audits & Viva",
      key_takeaways: [
        "Facing Port State Control (PSC) Paris MoU / Tokyo MoU audits: Documentation checks, physical walkthrough, and operational drills",
        "Severe legal penalties and criminal prosecution for illegal bypass piping (Magic Pipe) and falsified Oil Record Books",
        "Bunker Delivery Note (BDN) verification and MARPOL fuel oil representative sample retention protocols (minimum 12 months)",
        "Passing superintendent and environmental compliance officer technical interviews at top shipping lines"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // MARINE: Naval Architecture & Maxsurf 3D Hull Modeling
  // --------------------------------------------------------------------------
  'mar-maxsurf': {
    0: [{
      id: "mar-mxs-p0-curves",
      title: "Maxsurf Modeler: NURBS Surface Hull Modeling & Control Point Grids",
      youtube_video_id: "j2k0Z2x1nrs",
      youtube_url: "https://www.youtube.com/watch?v=j2k0Z2x1nrs",
      fallback_video_id: "yPAnqCyolVU",
      search_query: "Maxsurf Modeler Tutorial NURBS Surfaces Control Points Hull Lines Plan",
      channel_name: "Bentley Offshore Analysis",
      duration: "25:15",
      difficulty: "Beginner",
      topic_focus: "NURBS (Non-Uniform Rational B-Splines), Control Net Manipulation, Fairing Lines & Waterlines",
      key_takeaways: [
        "Generating 3D parametric hull forms using Non-Uniform Rational B-Splines (NURBS) surface patches",
        "Manipulating the control net grid: Longitudinal rows and vertical columns to shape bow bulb, midbody, and transom stern",
        "Evaluating hull surface fairness: Longitudinal curvature Gaussian curves and inflection point checks",
        "Displaying traditional 2D lines plans: Stations (transverse sections), Waterlines (horizontal cuts), Buttocks (longitudinal cuts)"
      ]
    }],
    1: [{
      id: "mar-mxs-p1-hydrostatics",
      title: "Maxsurf Stability: Hydrostatic Analysis, Sectional Area Curves & Coefficients",
      youtube_video_id: "qCESTDFga-c",
      youtube_url: "https://www.youtube.com/watch?v=qCESTDFga-c",
      fallback_video_id: "cLQeqYdinCc",
      search_query: "Maxsurf Stability Hydrostatics Calculation Block Coefficient Cb Sectional Area Curve",
      channel_name: "Parametric Ship Lab",
      duration: "28:40",
      difficulty: "Intermediate",
      topic_focus: "Block Coefficient (Cb), Midship Coefficient (Cm), Prismatic Coefficient (Cp), LCB & LCF Trends",
      key_takeaways: [
        "Computing key hull form coefficients: Block coefficient (Cb), Waterplane area coefficient (Cw), Prismatic coefficient (Cp)",
        "Generating Sectional Area Curves (SAC) to evaluate longitudinal distribution of volume and minimize wave-making resistance",
        "Calculating Longitudinal Center of Buoyancy (LCB) and Longitudinal Center of Flotation (LCF) across varying draft waterlines",
        "Exporting hydrostatic tables (KM, KB, BM, TPC tons per centimeter immersion) to Excel calculation workbooks"
      ]
    }],
    2: [{
      id: "mar-mxs-p2-intact-damage",
      title: "Maxsurf Stability: Loading Conditions, Tank Modeling & Intact/Damage Stability",
      youtube_video_id: "yMJEAmnnEbU",
      youtube_url: "https://www.youtube.com/watch?v=yMJEAmnnEbU",
      fallback_video_id: "-UbdfwOnR08",
      search_query: "Maxsurf Stability Tank Modeling Permeability Intact Stability Criteria Damage Case",
      channel_name: "Bentley Offshore Analysis",
      duration: "30:20",
      difficulty: "Intermediate",
      topic_focus: "Internal Tank Volumes, Permeabilities (Cargo 95%, Machinery 85%), Equilibrium Heel & GZ Curves",
      key_takeaways: [
        "Modeling complex internal tanks: Ballast double bottom tanks, wing tanks, and fuel bunkers with specific permeabilities",
        "Defining realistic operational load conditions: Lightship, Ballast departure/arrival, Fully loaded departure/arrival",
        "Running automated IMO Intact Stability checks and generating pass/fail compliance reports",
        "Simulating compartment damage flooding scenarios and checking residual GZ curve equilibrium and downflooding angles"
      ]
    }],
    3: [{
      id: "mar-mxs-p3-resistance-powering",
      title: "Maxsurf Resistance: Holtrop-Mennen Resistance Prediction & Propeller Sizing",
      youtube_video_id: "nXJQZNqIKys",
      youtube_url: "https://www.youtube.com/watch?v=nXJQZNqIKys",
      fallback_video_id: "qMaaxd3VHmw",
      search_query: "Maxsurf Resistance Holtrop Mennen Method Effective Power Wageningen B Series Propeller",
      channel_name: "Naval Architecture & Marine Engineering Dept.",
      duration: "32:45",
      difficulty: "Advanced",
      topic_focus: "Frictional Resistance (ITTC 1957), Wave-Making Resistance, Holtrop Empirical Method & Delivered Power (Pd)",
      key_takeaways: [
        "Breaking down total hydrodynamic resistance: ITTC-1957 frictional resistance, form factor (1+k), wave-making resistance",
        "Applying the Holtrop-Mennen empirical regression method for slender cargo vessels and displacement hulls",
        "Calculating Effective Power (PE = R_total * V) and Brake Power (PB) accounting for hull-propeller interaction efficiencies",
        "Matching propellers using Wageningen B-Series charts: Sizing diameter, pitch ratio (P/D), and expanded area ratio (EAR)"
      ]
    }],
    4: [{
      id: "mar-mxs-p4-naval-interview",
      title: "Naval Architect / Ship Design Engineer Placement Interview Screening Viva",
      youtube_video_id: "J0E-WXNnJV4",
      youtube_url: "https://www.youtube.com/watch?v=J0E-WXNnJV4",
      fallback_video_id: "Gbknv_rhFjI",
      search_query: "Naval Architect Technical Interview Questions Ship Design Bulbous Bow Cavitation Viva",
      channel_name: "Future Tech with  Ali",
      duration: "30:10",
      difficulty: "Placement",
      topic_focus: "Bulbous Bow Hydrodynamics, Propeller Cavitation (Burrill Criteria), Seakeeping & Placement Viva",
      key_takeaways: [
        "Hydrodynamics of bulbous bows: Creating an opposing wave system to cancel out bow wave crests at design Froude numbers",
        "Propeller cavitation types: Tip vortex cavitation, sheet cavitation, and assessing erosion risk using Burrill cavitation charts",
        "Ship motions in seaway: Pitch, roll, heave, yaw, sway, surge and Response Amplitude Operators (RAO)",
        "Cracking naval architecture technical interviews at Damen Shipyards, Fincantieri, Cochin Shipyard, and BMT"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // MARINE: Engine Room Watchkeeping & Alarm Protocols
  // --------------------------------------------------------------------------
  'mar-watchkeeping': {
    0: [{
      id: "mar-wtc-p0-stcw-duties",
      title: "STCW Engine Room Watchkeeping Duties & Handover Procedures",
      youtube_video_id: "50ia02aZzRU",
      youtube_url: "https://www.youtube.com/watch?v=50ia02aZzRU",
      fallback_video_id: "DgFNC9ulEZE",
      search_query: "STCW Engine Room Watchkeeping Handover Checklist Duties Logbook Entries",
      channel_name: "MEOclass4&2MMDexams",
      duration: "24:30",
      difficulty: "Beginner",
      topic_focus: "STCW Section A-VIII/2, Taking Over the Watch, Physical Rounds & Machinery Status Checks",
      key_takeaways: [
        "International standards of watchkeeping under STCW: Fitness for duty, rest hours compliance, zero alcohol tolerance",
        "Physical pre-handover engine room inspection rounds: Checking bilges, tank levels, leaks, vibrations, and unusual noises",
        "Reviewing standing orders from the Chief Engineer and special instructions from the bridge",
        "Crucial information exchanged during watch handover: Running machinery status, ongoing maintenance, and alarm history"
      ]
    }],
    1: [{
      id: "mar-wtc-p1-logbook-parameters",
      title: "Engine Room Logbook Entries: Critical Pressures, Temperatures & Soundings",
      youtube_video_id: "DrRiwOuYY5w",
      youtube_url: "https://www.youtube.com/watch?v=DrRiwOuYY5w",
      fallback_video_id: "BhxPnhlB8cQ",
      search_query: "Engine Room Logbook Documentation Parameters Temperatures Pressures Tank Soundings",
      channel_name: "Sailor DECODED",
      duration: "26:45",
      difficulty: "Intermediate",
      topic_focus: "Main Engine Exhaust Temps, Lube Oil Pressures (4-5 bar), Cooling Water In/Out & Sounding Tape Method",
      key_takeaways: [
        "Accurately recording hourly engine operating logs: Fuel oil inlet pressure/temp, scavenge air manifold, lube oil bearing pressure",
        "Monitoring individual cylinder exhaust gas temperatures and investigating deviations > 30°C",
        "Performing daily manual tank soundings using sounding tapes and water finding paste",
        "Computing daily fuel oil, lube oil, and fresh water consumption rates and calculating sea voyage remaining endurance"
      ]
    }],
    2: [{
      id: "mar-wtc-p2-alarms-ums",
      title: "Unattended Machinery Space (UMS) & Engine Room Alarm Handling Protocols",
      youtube_video_id: "zFPqVVwxVyk",
      youtube_url: "https://www.youtube.com/watch?v=zFPqVVwxVyk",
      fallback_video_id: "rYLooupDNhQ",
      search_query: "UMS Mode Unattended Machinery Space Dead Man Alarm Engine Room Automation",
      channel_name: "ismail Mr",
      duration: "28:15",
      difficulty: "Intermediate",
      topic_focus: "UMS Checklist, Dead-Man Safety Timer, Fire Detection Loops & Duty Engineer Cabin Alarms",
      key_takeaways: [
        "Prerequisites for placing the engine room into Unattended Machinery Space (UMS) mode at sea",
        "Operating the Dead-Man patrol alarm system: Resetting countdown timers during solo rounds to prevent incapacitated rescuer events",
        "Engine control room alarm hierarchy: Critical shutdown alarms, slowdown alarms, non-critical warning alarms",
        "Automatic alarm forwarding to the Duty Engineer's cabin and the navigating bridge upon unacknowledged alerts (>2 minutes)"
      ]
    }],
    3: [{
      id: "mar-wtc-p3-blackout-recovery",
      title: "Ship Blackout Recovery: Emergency Generator Starting & Power Restoration",
      youtube_video_id: "-72raBPMIeY",
      youtube_url: "https://www.youtube.com/watch?v=-72raBPMIeY",
      fallback_video_id: "N3IhZZE4Eqk",
      search_query: "Ship Blackout Recovery Emergency Generator Auto Start Dead Ship Recovery Procedure",
      channel_name: "TechTide Digital Lifestyle",
      duration: "32:20",
      difficulty: "Advanced",
      topic_focus: "Emergency Generator Independent Starting (<45 seconds), Dead Bus Closing & Sequential Restart",
      key_takeaways: [
        "SOLAS emergency electrical power: Independent starting of emergency generator within 45 seconds of main bus power loss",
        "Dead-ship recovery procedure: Emergency generator energizing emergency switchboard and auxiliary start air compressor",
        "Manual and automatic synchronizing of main diesel generators: Synchroscope 11 o'clock breaker closing",
        "Sequential restart of essential auxiliary machinery: Boiler feedwater pumps, lube oil pumps, and sea water cooling pumps"
      ]
    }],
    4: [{
      id: "mar-wtc-p4-watchkeeping-interview",
      title: "Marine Junior Engineer Placement Interview & Practical Watch Scenario Viva",
      youtube_video_id: "aJRjdOgYBWU",
      youtube_url: "https://www.youtube.com/watch?v=aJRjdOgYBWU",
      fallback_video_id: "ggBcxit4Fiw",
      search_query: "Junior Marine Engineer Technical Interview Questions Watchkeeping Scenarios Viva",
      channel_name: "AliAzizQualityEducation ",
      duration: "30:40",
      difficulty: "Placement",
      topic_focus: "Emergency Steering Changeover Drills, Fuel Changeover for SECA (MGO/HFO) & Technical Viva",
      key_takeaways: [
        "Executing fuel changeover procedures when entering emission control zones: Heating rate limit (2°C/min) to prevent fuel pump thermal shock",
        "Action in the event of high engine jacket water temperature alarms: Investigating expansion tank levels, pump belts, and thermostatic valves",
        "Safety during enclosed space entry: Atmosphere testing (Oxygen > 20.9%, Flammable gases < 1% LFL, Toxic gases < TLV)",
        "Acing shipping company technical interview panels and obtaining employment as an operational marine engineering officer"
      ]
    }]
  },

  // ==========================================================================
  // AERONAUTICAL CO-DOMAINS
  // ==========================================================================

  // --------------------------------------------------------------------------
  // AERO: Aerodynamics & Airfoil Lift-Drag Polars
  // --------------------------------------------------------------------------
  'aero-aerodynamics': {
    0: [{
      id: "aero-aero-p0-airfoils",
      title: "Airfoil Aerodynamics: NACA 4-Digit Series, Pressure Distribution & Bernoulli vs Circulation",
      youtube_video_id: "XNfMVhcw8C4",
      youtube_url: "https://www.youtube.com/watch?v=XNfMVhcw8C4",
      fallback_video_id: "JeLmiQq8bPc",
      search_query: "Airfoil Aerodynamics NACA 4 Digit Camber Thickness Lift Drag Coefficient",
      channel_name: "The Efficient Engineer",
      duration: "24:35",
      difficulty: "Beginner",
      topic_focus: "NACA 4-Digit Naming (Camber, Position, Thickness), Chord Line, Angle of Attack & Pressure Coefficient (Cp)",
      key_takeaways: [
        "Decoding NACA 4-digit airfoil nomenclature (e.g. NACA 2412: 2% max camber, at 40% chord, 12% thickness)",
        "Lift generation physics: Circulation theory of lift (Kutta-Joukowski theorem) and Bernoulli suction over upper surface",
        "Plotting surface pressure coefficient (Cp) distributions along upper and lower airfoil surfaces",
        "Defining standard aerodynamic dimensionless coefficients: Lift coefficient (Cl), Drag coefficient (Cd), Pitching moment (Cm)"
      ]
    }],
    1: [{
      id: "aero-aero-p1-drag-polar",
      title: "Lift-to-Drag Ratio (L/D), Induced Drag & Finite Wing Tip Vortices",
      youtube_video_id: "IfIvJIXdKlQ",
      youtube_url: "https://www.youtube.com/watch?v=IfIvJIXdKlQ",
      fallback_video_id: "KoJ-vuzu19A",
      search_query: "Induced Drag Wingtip Vortices Aspect Ratio Oswald Efficiency Drag Polar",
      channel_name: "Real Engineering",
      duration: "27:50",
      difficulty: "Intermediate",
      topic_focus: "Parasite Drag vs Induced Drag (Cdi = Cl^2 / (pi * AR * e)), Aspect Ratio (AR) & Winglets",
      key_takeaways: [
        "Components of total aircraft drag: Parasite drag (skin friction, form drag) and lift-induced drag",
        "Finite wing tip vortices: High pressure air beneath the wing rolling over the wingtips into low pressure upper regions",
        "Calculating induced drag coefficient: Cdi = Cl^2 / (pi * AR * e); why high Aspect Ratio (gliders) minimizes drag",
        "Role of winglets: Diffusing tip vortex strength and increasing effective wing span without structural weight penalty"
      ]
    }],
    2: [{
      id: "aero-aero-p2-boundary-layer",
      title: "Boundary Layer Separation, Adverse Pressure Gradients & Aerodynamic Stall",
      youtube_video_id: "M9-M9eLfU6U",
      youtube_url: "https://www.youtube.com/watch?v=M9-M9eLfU6U",
      fallback_video_id: "HfICmKv9SzE",
      search_query: "Boundary Layer Separation Adverse Pressure Gradient Airfoil Stall Vortex Generators",
      channel_name: "Aerospace Engineering Hub",
      duration: "29:15",
      difficulty: "Intermediate",
      topic_focus: "Laminar vs Turbulent Boundary Layers, Critical Angle of Attack, Flow Separation & Stall Warning",
      key_takeaways: [
        "Boundary layer physics: Laminar boundary layer (low friction, easily separates) vs turbulent boundary layer (higher friction, resists separation)",
        "Mechanism of flow separation: Adverse pressure gradient (dp/dx > 0) decelerating fluid until wall shear stress vanishes (du/dy = 0)",
        "Aerodynamic stall: Exceeding critical angle of attack (alpha_crit), catastrophic loss of lift, and surge in form pressure drag",
        "Boundary layer control devices: Vortex generators (re-energizing boundary layer with freestream momentum) and leading edge slats"
      ]
    }],
    3: [{
      id: "aero-aero-p3-compressible-flow",
      title: "Compressible Aerodynamics: Mach Number, Oblique Shock Waves & Critical Mach (Mcrit)",
      youtube_video_id: "4b_WgXbz90c",
      youtube_url: "https://www.youtube.com/watch?v=4b_WgXbz90c",
      fallback_video_id: "VtuJnjOV4U8",
      search_query: "Compressible Flow Critical Mach Number Shock Wave Wave Drag Swept Wing Area Rule",
      channel_name: "Aerodynamics Academy",
      duration: "33:40",
      difficulty: "Advanced",
      topic_focus: "Subsonic, Transonic, Supersonic Regimes, Critical Mach (Mcrit), Wave Drag & Whitcomb Area Rule",
      key_takeaways: [
        "Mach number regimes: Flow compressibility becomes significant above Mach 0.3; transonic shock waves at Mach 0.8-1.2",
        "Critical Mach number (Mcrit): Freestream velocity where localized sonic flow (Mach 1.0) first appears on upper wing surface",
        "Shock wave formation: Normal and oblique shock waves causing sudden total pressure loss and shock-induced boundary layer separation",
        "Transonic drag reduction: Swept wings (reducing effective chordwise Mach number) and the Whitcomb Area Rule (wasp-waist fuselage)"
      ]
    }],
    4: [{
      id: "aero-aero-p4-aerodynamics-interview",
      title: "Aerodynamics Engineer Placement Interview & Wind Tunnel Testing Viva",
      youtube_video_id: "ZEnv38GWiGQ",
      youtube_url: "https://www.youtube.com/watch?v=ZEnv38GWiGQ",
      fallback_video_id: "aPDHCTVqpP4",
      search_query: "Aerodynamics Engineer Technical Interview Questions Wind Tunnel Reynolds Mach Scaling Viva",
      channel_name: "Aerospace Career Academy",
      duration: "31:25",
      difficulty: "Placement",
      topic_focus: "Wind Tunnel Wall Interference, Reynolds Number Scaling, Pitot-Static Calibration & Technical Viva",
      key_takeaways: [
        "Subsonic and supersonic wind tunnel testing: Balancing Reynolds number and Mach number dynamic similitude",
        "Surface flow visualization techniques: Oil flow patterns, tufts, and pressure-sensitive paint (PSP)",
        "Solving practical aircraft performance questions: Maximum rate of climb (Vy), maximum angle of climb (Vx), and gliding range",
        "Clearing aerodynamics technical interviews at Boeing, Airbus, Lockheed Martin, NASA, and ISRO"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // AERO: CFD Airflow Simulation (ANSYS Fluent)
  // --------------------------------------------------------------------------
  'aero-cfd': {
    0: [{
      id: "aero-cfd-p0-navier-stokes",
      title: "Computational Fluid Dynamics First Principles: Navier-Stokes Equations & Discretization",
      youtube_video_id: "sfLkKJthQ2g",
      youtube_url: "https://www.youtube.com/watch?v=sfLkKJthQ2g",
      fallback_video_id: "E9_kyXjtRHc",
      search_query: "CFD First Principles Navier Stokes Equations Finite Volume Method Discretization",
      channel_name: "CFD Ninja",
      duration: "25:10",
      difficulty: "Beginner",
      topic_focus: "Continuity, Momentum, Energy Equations, Finite Volume Method (FVM) & Cell Centers",
      key_takeaways: [
        "The governing partial differential equations of fluid dynamics: Conservation of mass, momentum (Navier-Stokes), and energy",
        "The Finite Volume Method (FVM): Integrating differential equations over discrete control volumes with surface flux balances",
        "Spatial discretization schemes: First-order upwind vs second-order upwind and QUICK schemes for advective terms",
        "Pressure-velocity coupling algorithms in Fluent: SIMPLE, SIMPLEC, and PISO schemes for incompressible flows"
      ]
    }],
    1: [{
      id: "aero-cfd-p1-meshing-yplus",
      title: "ANSYS Meshing & Boundary Layer Inflation: The y+ Wall Treatment Rule",
      youtube_video_id: "EcJEDjIdRAI",
      youtube_url: "https://www.youtube.com/watch?v=EcJEDjIdRAI",
      fallback_video_id: "aNLk3zn2R9U",
      search_query: "ANSYS Meshing y+ Wall Distance Inflation Layers Prism Layers First Cell Height",
      channel_name: "CFD Flow Engineering",
      duration: "28:30",
      difficulty: "Intermediate",
      topic_focus: "Dimensionless Wall Distance (y+), First Cell Height Calculation, Inflation Layers & Orthogonal Quality",
      key_takeaways: [
        "The law of the wall: Viscous sublayer (y+ < 5), buffer layer (5 < y+ < 30), and fully turbulent log-law region (y+ > 30)",
        "Calculating first cell height (delta y) using flat plate skin friction correlations for specified target y+ values",
        "Generating prism inflation layers on airfoil surfaces with smooth transition ratios (< 1.2) into unstructured tetrahedral core",
        "Evaluating mesh quality metrics: Orthogonal quality (> 0.2) and skewness (< 0.8) to guarantee solver convergence"
      ]
    }],
    2: [{
      id: "aero-cfd-p2-turbulence-models",
      title: "Turbulence Modeling in Fluent: k-epsilon vs k-omega SST vs Spallart-Almaras",
      youtube_video_id: "nw3dzZKcuKM",
      youtube_url: "https://www.youtube.com/watch?v=nw3dzZKcuKM",
      fallback_video_id: "J8EnaSWOju8",
      search_query: "Turbulence Models ANSYS Fluent k epsilon k omega SST Spalart Allmaras Separation",
      channel_name: "CFD Academy",
      duration: "30:45",
      difficulty: "Intermediate",
      topic_focus: "Reynolds-Averaged Navier-Stokes (RANS), Eddy Viscosity, k-omega SST Blending Function & Stall Capture",
      key_takeaways: [
        "Reynolds-Averaged Navier-Stokes (RANS) framework: Reynolds decomposition and Boussinesq eddy viscosity hypothesis",
        "Spalart-Allmaras (1-equation model): Industry workhorse for clean external aerospace flows without massive separation",
        "Menter's k-omega SST (Shear Stress Transport): k-omega formulation near the wall blending smoothly into k-epsilon in freestream",
        "Why k-omega SST is the premier model for capturing adverse pressure gradients and aerodynamic stall onset"
      ]
    }],
    3: [{
      id: "aero-cfd-p3-airfoil-simulation",
      title: "Transonic Airfoil Simulation in ANSYS Fluent: Shock Waves & Convergence Monitoring",
      youtube_video_id: "Ad7Ig-7O4Ho",
      youtube_url: "https://www.youtube.com/watch?v=Ad7Ig-7O4Ho",
      fallback_video_id: "B2seSotQe4I",
      search_query: "ANSYS Fluent Airfoil Simulation Drag Polar Convergence Residuals Force Monitors",
      channel_name: "CFD Flow Engineering",
      duration: "34:10",
      difficulty: "Advanced",
      topic_focus: "Far-Field Boundary Conditions, Pressure Far-Field, Residual Criteria (10^-6) & Lift/Drag Monitors",
      key_takeaways: [
        "Domain sizing: Placing C-mesh or O-mesh far-field boundaries 20-50 chord lengths away to eliminate reflection artifacts",
        "Setting up compressible flow: Ideal gas density model, Sutherland's three-coefficient law for dynamic viscosity",
        "Monitoring convergence: Scaling residuals below 10^-6 while verifying steady-state force coefficient (Cl, Cd) plateau lines",
        "Post-processing: Plotting Mach contours, static pressure contours, and comparing computed Cp against wind tunnel validation data"
      ]
    }],
    4: [{
      id: "aero-cfd-p4-cfd-interview",
      title: "Aerodynamics CFD Engineer Placement Interview & Mesh Independence Viva",
      youtube_video_id: "VXEPhiFcUac",
      youtube_url: "https://www.youtube.com/watch?v=VXEPhiFcUac",
      fallback_video_id: "UGtWUM4yxU0",
      search_query: "CFD Engineer Technical Interview Questions Grid Independence Study Verification Validation Viva",
      channel_name: "Aerospace Career Academy",
      duration: "29:50",
      difficulty: "Placement",
      topic_focus: "Grid Convergence Index (GCI), Richardson Extrapolation, LES/DES Hybrid Models & Placement Viva",
      key_takeaways: [
        "Demonstrating Grid Independence: Applying Richardson extrapolation to compute the Grid Convergence Index (GCI)",
        "Understanding advanced turbulence formulations: Large Eddy Simulation (LES) and Detached Eddy Simulation (DES) for detached bluff bodies",
        "Troubleshooting floating-point exceptions and non-physical temperature/turbulent viscosity limiter errors in Fluent",
        "Passing CFD aerodynamics engineering interviews at Rolls-Royce, Pratt & Whitney, Boom Supersonic, and ISRO"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // AERO: Aircraft Structural Mechanics & FEA
  // --------------------------------------------------------------------------
  'aero-structures': {
    0: [{
      id: "aero-str-p0-semimonocoque",
      title: "Aircraft Structural Design: Semi-Monocoque Construction, Spars, Ribs & Skin",
      youtube_video_id: "vCDv8wK4KPY",
      youtube_url: "https://www.youtube.com/watch?v=vCDv8wK4KPY",
      fallback_video_id: "zHQP3HHwj9s",
      search_query: "Aircraft Structural Design Semi Monocoque Wing Spar Rib Stringer Skin Bending",
      channel_name: "The Efficient Engineer",
      duration: "24:50",
      difficulty: "Beginner",
      topic_focus: "Wing Structural Box, Front/Rear Spars, Ribs, Stringers, Thin Skin & Load Paths",
      key_takeaways: [
        "The semi-monocoque principle: Thin stressed skins carrying shear while longitudinal stringers and spars resist bending moments",
        "Wing structural box layout: Front and rear spars forming a closed torque box with aerodynamically contoured ribs",
        "Load transfer mechanism: Aerodynamic pressure on skin -> transferred to ribs -> carried as bending and shear by main spars",
        "Fuselage construction: Circumferential frames maintaining cross-section circularity and longerons carrying cabin bending"
      ]
    }],
    1: [{
      id: "aero-str-p1-shear-flow",
      title: "Shear Flow in Thin-Walled Open & Closed Sections: Bredt-Batho Torsion Formula",
      youtube_video_id: "xeoV_e_0Rjk",
      youtube_url: "https://www.youtube.com/watch?v=xeoV_e_0Rjk",
      fallback_video_id: "AT7-a3l20SI",
      search_query: "Shear Flow Thin Walled Beams Bredt Batho Theory Aircraft Structures Torsion",
      channel_name: "Aerospace Structures Hub",
      duration: "28:15",
      difficulty: "Intermediate",
      topic_focus: "Shear Flow (q = V*Q / I), Shear Center Location & Bredt-Batho Torsion (q = T / 2*A)",
      key_takeaways: [
        "Shear flow concept: Internal shear force per unit length (q = tau * t) in thin aircraft sheet metal webs",
        "Locating the Shear Center (flexural center): Point through which transverse loads produce zero twisting rotation",
        "Bredt-Batho theory for closed single-cell thin-walled tubes: Uniform shear flow q = Torque / (2 * Enclosed Area)",
        "Multi-cell closed wing box torsion analysis: Equal angle of twist compatibility equations across cells"
      ]
    }],
    2: [{
      id: "aero-str-p2-composites",
      title: "Carbon Fiber Composites (CFRP): Classical Lamination Theory & Failure Criteria",
      youtube_video_id: "04K0bLwCDdM",
      youtube_url: "https://www.youtube.com/watch?v=04K0bLwCDdM",
      fallback_video_id: "g4i39M9DSeI",
      search_query: "Composite Materials Classical Lamination Theory ABD Matrix Tsai Hill Failure",
      channel_name: "Composite Materials Academy",
      duration: "30:20",
      difficulty: "Intermediate",
      topic_focus: "Orthotropic Ply Properties, ABD Stiffness Matrix, Quasi-Isotropic Layups & Tsai-Wu Failure",
      key_takeaways: [
        "Orthotropic lamina elasticity: Longitudinal modulus (E1), transverse modulus (E2), shear modulus (G12), Poisson ratio (nu12)",
        "Classical Lamination Theory (CLT): Constructing the ABD stiffness matrix relating midplane strains and curvatures to loads",
        "Standard aerospace laminate tailoring: Quasi-isotropic layups [0°/±45°/90°] balancing directional tensile and shear loads",
        "Composite failure criteria: Maximum stress criterion, interactive Tsai-Hill and Tsai-Wu quadratic stress tensor criteria"
      ]
    }],
    3: [{
      id: "aero-str-p3-ansys-fea",
      title: "Aircraft Structural FEA in ANSYS: Wing Spar Bending, Buckling & Limit Loads",
      youtube_video_id: "0wDi6fnaNws",
      youtube_url: "https://www.youtube.com/watch?v=0wDi6fnaNws",
      fallback_video_id: "Y9iScPNPpj0",
      search_query: "ANSYS Structural FEA Aircraft Wing Spar Shell Elements Buckling Limit Load Factor",
      channel_name: "Finite Element Hub",
      duration: "33:15",
      difficulty: "Advanced",
      topic_focus: "2D Shell Elements, V-n Maneuver Flight Envelope (+2.5g / -1.0g), Eigenvalue Skin Buckling & Margins",
      key_takeaways: [
        "Meshing thin aircraft structures using 2D quadrilateral shell elements (SHELL181 / SHELL281) with assigned thicknesses",
        "Applying the V-n Flight Maneuver Envelope limit load factor (+2.5g positive maneuver limit, 1.5 safety factor = +3.75g ultimate)",
        "Eigenvalue buckling analysis of thin aluminum skin panels under compressive in-plane shear forces",
        "Calculating Margin of Safety: MS = (Allowable Stress / (Applied Stress * Safety Factor)) - 1; ensuring MS >= 0"
      ]
    }],
    4: [{
      id: "aero-str-p4-structures-interview",
      title: "Aircraft Structural Stress Engineer Placement Interview & FAR 25 Certification Viva",
      youtube_video_id: "m8DJlkpIM20",
      youtube_url: "https://www.youtube.com/watch?v=m8DJlkpIM20",
      fallback_video_id: "uy2h20OzlTU",
      search_query: "Aerospace Stress Engineer Interview Questions Fatigue Fracture Mechanics FAR 25 Viva",
      channel_name: "Aerospace Career Academy",
      duration: "30:45",
      difficulty: "Placement",
      topic_focus: "Fatigue Life (S-N Curves), Miner's Rule, Damage Tolerance & FAR Part 25 Airworthiness Certification",
      key_takeaways: [
        "Damage tolerance vs safe-life design philosophy: Assuming initial manufacturing flaws and inspecting before critical crack length",
        "Linear elastic fracture mechanics: Stress intensity factor (K_I), fracture toughness (K_IC), and Paris Law crack growth rate (da/dN)",
        "Cumulative fatigue damage calculation using Palmgren-Miner linear damage summation rule: Sum(ni / Ni) <= 1.0",
        "Passing stress engineering interviews at Boeing, Airbus, Bombardier, Embraer, and Northrop Grumman"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // AERO: Gas Turbine Propulsion & Jet Engines
  // --------------------------------------------------------------------------
  'aero-propulsion': {
    0: [{
      id: "aero-prp-p0-turbofan-basics",
      title: "How Jet Engines Work: Turbofan, Turbojet, Turboprop & The Brayton Cycle",
      youtube_video_id: "L24Wf0VlTE0",
      youtube_url: "https://www.youtube.com/watch?v=L24Wf0VlTE0",
      fallback_video_id: "B9sDz_fQ26w",
      search_query: "How Jet Engine Works Turbofan Brayton Cycle Bypass Ratio Rolls Royce Trent",
      channel_name: "Animagraffs",
      duration: "23:40",
      difficulty: "Beginner",
      topic_focus: "Intake Fan, Low/High Pressure Compressor, Combustor, Turbine & Bypass Ratio",
      key_takeaways: [
        "The ideal Brayton thermodynamic cycle for open gas turbines: Isentropic compression, constant-pressure combustion, expansion",
        "Anatomy of modern high-bypass commercial turbofans (Rolls-Royce Trent, CFM LEAP, GE90)",
        "The bypass ratio (BPR = m_bypass / m_core): Why high bypass (BPR > 10) yields massive propulsive efficiency gains",
        "Spool architectures: Twin-spool (LP/HP) and triple-spool configurations allowing independent optimal rotational speeds"
      ]
    }],
    1: [{
      id: "aero-prp-p1-compressors",
      title: "Axial Compressors & Compressor Stall / Surge Aerodynamics",
      youtube_video_id: "OMd0FRfgx2Y",
      youtube_url: "https://www.youtube.com/watch?v=OMd0FRfgx2Y",
      fallback_video_id: "3VXnB1SH_2s",
      search_query: "Axial Flow Compressor Rotor Stator Compressor Surge Stall Bleed Valves",
      channel_name: "Learn Engineering",
      duration: "27:10",
      difficulty: "Intermediate",
      topic_focus: "Rotor-Stator Pairs, Pressure Rise per Stage, Rotating Stall vs Complete Compressor Surge",
      key_takeaways: [
        "Operating mechanism of axial compressor stages: Moving rotor blades add kinetic energy; stationary stator vanes convert to static pressure",
        "Degree of reaction in axial compressors (typically 50% shared enthalpy rise between rotor and stator)",
        "Rotating stall: Localized stall cells rotating around the compressor annulus at 50% of rotor speed",
        "Violent compressor surge: Complete breakdown of flow with explosive reverse flow out the intake; mitigation via variable bleed valves (VBV)"
      ]
    }],
    2: [{
      id: "aero-prp-p2-combustion-turbines",
      title: "Combustion Chambers & High-Pressure Turbine Blade Film Cooling",
      youtube_video_id: "V_G7hj9Sp00",
      youtube_url: "https://www.youtube.com/watch?v=V_G7hj9Sp00",
      fallback_video_id: "7upnkrhqRWQ",
      search_query: "Gas Turbine Combustor Annular Turbine Blade Cooling Film Cooling Thermal Barrier Coating",
      channel_name: "Aerospace Propulsion Hub",
      duration: "29:30",
      difficulty: "Intermediate",
      topic_focus: "Annular Combustors, Swirlers, Primary/Dilution Zones, Blade Cooling Holes & TBC",
      key_takeaways: [
        "Combustion chamber architecture: Swirl nozzles stabilizing recirculating flames in high-velocity airflow",
        "Zoned airflow: Primary stoichiometric zone (equivalence ratio ~ 1) and secondary dilution air cooling gases before turbine entry",
        "Turbine inlet temperature (TIT > 1600°C) exceeding the melting point of nickel superalloy blade metals",
        "Internal serpentine convective passages, pin fins, and external surface laser-drilled film cooling holes creating an insulating air boundary"
      ]
    }],
    3: [{
      id: "aero-prp-p3-nozzles-thrust",
      title: "Exhaust Nozzles: Convergent vs CD Nozzles, Thrust Equations & Afterburners",
      youtube_video_id: "INBqhHEqyas",
      youtube_url: "https://www.youtube.com/watch?v=INBqhHEqyas",
      fallback_video_id: "hljZdY8SaLE",
      search_query: "Jet Engine Exhaust Nozzle Convergent Divergent De Laval Nozzle Thrust Equation Afterburner",
      channel_name: "Propulsion Academy",
      duration: "32:15",
      difficulty: "Advanced",
      topic_focus: "Net Thrust Equation (F = m_dot * (v_e - v_0) + (p_e - p_0)*A_e), Choked Nozzles & Supersonic CD Expansion",
      key_takeaways: [
        "The complete net thrust equation: Momentum thrust from acceleration of mass plus pressure thrust from nozzle pressure mismatch",
        "Convergent nozzles for commercial subsonic aircraft: Choking at nozzle throat (Mach 1.0) when pressure ratio exceeds critical ratio (1.89)",
        "Convergent-Divergent (CD / de Laval) variable geometry nozzles for military supersonic afterburning fighters",
        "Specific Fuel Consumption (TSFC): Thrust produced per unit mass flow of fuel consumed per hour"
      ]
    }],
    4: [{
      id: "aero-prp-p4-propulsion-interview",
      title: "Gas Turbine / Propulsion Engineer Placement Interview & Performance Matching Viva",
      youtube_video_id: "9z54PGaxD7c",
      youtube_url: "https://www.youtube.com/watch?v=9z54PGaxD7c",
      fallback_video_id: "zJEc68NOi8Y",
      search_query: "Gas Turbine Propulsion Engineer Technical Interview Questions Component Matching Viva",
      channel_name: "Aerospace Career Academy",
      duration: "30:40",
      difficulty: "Placement",
      topic_focus: "Turbine-Compressor Work Matching, Corrected Mass Flow, Performance Curves & Technical Viva",
      key_takeaways: [
        "Component matching rules: HP turbine power output strictly equaling HP compressor power absorption on the shared shaft",
        "Using non-dimensional corrected engine parameters: Corrected mass flow, corrected speed (N / sqrt(theta)) across altitudes",
        "Troubleshooting engine degradation: Hot gas path erosion, turbine blade creep, and compressor fouling wash schedules",
        "Acing propulsion engineering technical rounds at GE Aerospace, Pratt & Whitney, Rolls-Royce, and Safran"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // AERO: Flight Dynamics & Aircraft Stability Derivatives
  // --------------------------------------------------------------------------
  'aero-stability': {
    0: [{
      id: "aero-dyn-p0-axes-moments",
      title: "Aircraft Axes, Angles & Aerodynamic Control Surfaces First Principles",
      youtube_video_id: "gb-7kACwrnM",
      youtube_url: "https://www.youtube.com/watch?v=gb-7kACwrnM",
      fallback_video_id: "XxrdhJanotw",
      search_query: "Aircraft Axes Pitch Roll Yaw Control Surfaces Ailerons Elevator Rudder Stability",
      channel_name: "The Efficient Engineer",
      duration: "23:15",
      difficulty: "Beginner",
      topic_focus: "Body-Fixed Coordinate System (X-Roll, Y-Pitch, Z-Yaw), Moments (L, M, N) & Primary Controls",
      key_takeaways: [
        "Aircraft body axes definition: Longitudinal X-axis (Roll), Lateral Y-axis (Pitch), Normal Z-axis (Yaw) right-hand rule",
        "Primary aerodynamic control surfaces: Elevators controlling pitch moment (M), Ailerons controlling roll (L), Rudder controlling yaw (N)",
        "Aerodynamic angles: Angle of attack (alpha) in the longitudinal plane and sideslip angle (beta) in the lateral plane",
        "Trimming principles: Adjusting horizontal stabilizer or elevator trim tabs to achieve zero net pitching moment (Cm = 0)"
      ]
    }],
    1: [{
      id: "aero-dyn-p1-longitudinal-static",
      title: "Longitudinal Static Stability: Neutral Point & Static Margin (Kn)",
      youtube_video_id: "-bN7wZTeMUE",
      youtube_url: "https://www.youtube.com/watch?v=-bN7wZTeMUE",
      fallback_video_id: "VhxxE3SOUf0",
      search_query: "Longitudinal Static Stability Neutral Point Static Margin Pitch Moment Curve Cm Alpha",
      channel_name: "Flight Mechanics Hub",
      duration: "27:40",
      difficulty: "Intermediate",
      topic_focus: "Negative Pitch Stiffness (dCm/dalpha < 0), Neutral Point (X_np), Static Margin & Tail Volume Ratio",
      key_takeaways: [
        "The golden condition for longitudinal static stability: Negative slope of pitching moment curve (dCm / dalpha < 0)",
        "Neutral Point (X_np): The specific Center of Gravity location where aircraft static stability is neutral (dCm/dalpha = 0)",
        "Static Margin definition: Distance between Center of Gravity and Neutral Point expressed as percentage of Mean Aerodynamic Chord",
        "Horizontal tail volume ratio (Vh): Sizing tail surface area and moment arm to maintain safe positive static margin (typically 5-15%)"
      ]
    }],
    2: [{
      id: "aero-dyn-p2-lateral-directional",
      title: "Lateral-Directional Static Stability: Dihedral Effect & Weathercock Stability",
      youtube_video_id: "B3YSFpWFxrM",
      youtube_url: "https://www.youtube.com/watch?v=B3YSFpWFxrM",
      fallback_video_id: "uldtTHIO4AY",
      search_query: "Lateral Directional Stability Dihedral Effect Wing Sweep Weathercock Stability Rudder",
      channel_name: "Flight Mechanics Hub",
      duration: "28:50",
      difficulty: "Intermediate",
      topic_focus: "Roll Stability Derivative (Cl_beta < 0), Dihedral Angle, Wing Sweep & Yaw Stability (Cn_beta > 0)",
      key_takeaways: [
        "Directional (weathercock) stability: Restoring yawing moment into the relative wind when sideslipping (Cn_beta > 0)",
        "Sizing the vertical tail fin and rudder to guarantee robust weathercock directional stiffness",
        "Lateral dihedral effect: Wing geometric dihedral and aft wing sweep producing a restoring roll moment away from sideslip (Cl_beta < 0)",
        "Adverse yaw: Deflected downward aileron creating higher induced drag, causing aircraft to yaw opposite to the intended roll"
      ]
    }],
    3: [{
      id: "aero-dyn-p3-dynamic-modes",
      title: "Dynamic Stability Modes: Phugoid, Short Period, Dutch Roll & Spiral Divergence",
      youtube_video_id: "qszrrd_y5ak",
      youtube_url: "https://www.youtube.com/watch?v=qszrrd_y5ak",
      fallback_video_id: "elDbjhCpmM8",
      search_query: "Aircraft Dynamic Stability Modes Phugoid Short Period Dutch Roll Spiral Divergence",
      channel_name: "Flight Dynamics Academy",
      duration: "33:20",
      difficulty: "Advanced",
      topic_focus: "Longitudinal Modes (Short-Period Pitch vs Slow Phugoid Energy Trade), Dutch Roll & Yaw Dampers",
      key_takeaways: [
        "Short-Period mode: Rapid, heavily damped pitch angle oscillation at nearly constant airspeed",
        "Phugoid mode: Long-period (30-60s) gentle oscillation exchanging kinetic energy (airspeed) and potential energy (altitude)",
        "Dutch Roll mode: Coupled out-of-phase yawing and rolling motion; suppression using automated avionics Yaw Dampers",
        "Spiral Divergence mode: Non-oscillatory divergence into a steepening descending spiral bank; acceptable if slow (time to double > 20s)"
      ]
    }],
    4: [{
      id: "aero-dyn-p4-stability-interview",
      title: "Flight Controls / Handling Qualities Placement Interview & Cooper-Harper Viva",
      youtube_video_id: "s_XdMPouhqU",
      youtube_url: "https://www.youtube.com/watch?v=s_XdMPouhqU",
      fallback_video_id: "JZlqctmQ7is",
      search_query: "Flight Dynamics Stability Derivatives Cooper Harper Rating Handling Qualities Interview Viva",
      channel_name: "Aerospace Career Academy",
      duration: "30:30",
      difficulty: "Placement",
      topic_focus: "Stability Derivatives Matrix, State-Space Linearization, Cooper-Harper Scale & Technical Viva",
      key_takeaways: [
        "Linearizing non-linear 6-DOF aircraft equations of motion using stability and control derivative matrices",
        "Cooper-Harper Rating scale (CHR 1 to 10) for pilot evaluation of aircraft handling qualities and workload",
        "Pilot-Induced Oscillations (PIO): Causes, phase lag in flight control actuators, and aerodynamic design remedies",
        "Acing flight dynamics technical interviews at Lockheed Martin Skunk Works, Northrop, Textron Aviation, and DLR"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // AERO: Avionics & Digital Flight Control Systems
  // --------------------------------------------------------------------------
  'aero-avionics': {
    0: [{
      id: "aero-av-p0-pitot-static",
      title: "Pitot-Static Flight Instruments: Airspeed Indicator, Altimeter & VSI",
      youtube_video_id: "mqLyitBTfjY",
      youtube_url: "https://www.youtube.com/watch?v=mqLyitBTfjY",
      fallback_video_id: "KfOuacajp_I",
      search_query: "Pitot Static Flight Instruments Indicated Airspeed Altimeter VSI Barometric Setting",
      channel_name: "Mentour Pilot",
      duration: "24:10",
      difficulty: "Beginner",
      topic_focus: "Pitot Tube Total Pressure, Static Ports, Indicated (IAS) vs True Airspeed (TAS) & Altimeter Subscale",
      key_takeaways: [
        "Pitot-static instrument architecture: Ram air dynamic pressure vs ambient atmospheric static pressure ports",
        "Airspeed Indicator (ASI) operation: Diaphragm expanding with dynamic pressure (q = 1/2 * rho * V^2)",
        "Airspeed conversions: Indicated Airspeed (IAS) -> Calibrated (CAS) -> Equivalent (EAS compressibility) -> True Airspeed (TAS)",
        "Barometric Altimeter operation: Aneroid wafer capsules expanding with altitude and barometric Kollsman subscale setting (QNH/STD)"
      ]
    }],
    1: [{
      id: "aero-av-p1-arinc429",
      title: "Avionics Data Buses: ARINC 429 Protocol, Words, Labels & MIL-STD-1553",
      youtube_video_id: "9L0lI_D961s",
      youtube_url: "https://www.youtube.com/watch?v=9L0lI_D961s",
      fallback_video_id: "tiim2adsLtA",
      search_query: "ARINC 429 Tutorial Avionics Data Bus 32 Bit Word BNR BCD Label Parity",
      channel_name: "Avionics Hub",
      duration: "27:45",
      difficulty: "Intermediate",
      topic_focus: "Differential Twisted Pair, 32-Bit Word Structure, Octal Labels, BNR/BCD Encoding & Parity",
      key_takeaways: [
        "ARINC 429 digital transmission standard: Point-to-point simplex broadcast on shielded twisted wire pairs",
        "Signaling: Bipolar Return-to-Zero (BPRZ) modulation at Low Speed (12.5 kbps) or High Speed (100 kbps)",
        "Anatomy of the standard 32-bit ARINC word: Label (bits 1-8 octal), SDI (bits 9-10), Data payload, SSM (30-31), Parity (32)",
        "Comparing commercial ARINC 429 with military dual-redundant command-response MIL-STD-1553B multiplex buses"
      ]
    }],
    2: [{
      id: "aero-av-p2-fly-by-wire",
      title: "Fly-By-Wire (FBW) Architectures: Flight Control Computers & Flight Envelope Protection",
      youtube_video_id: "YIZl5mT2P28",
      youtube_url: "https://www.youtube.com/watch?v=YIZl5mT2P28",
      fallback_video_id: "MtDbeteM8B0",
      search_query: "Fly By Wire System Architecture Airbus Boeing Flight Control Laws Normal Direct Law",
      channel_name: "Mentour Pilot",
      duration: "29:30",
      difficulty: "Intermediate",
      topic_focus: "Triple-Redundant Flight Control Computers (FCC), Side-Stick Transducers & Normal vs Direct Laws",
      key_takeaways: [
        "Evolution from mechanical cables/pulleys to digital Fly-by-Wire: Weight reduction and digital control augmentation",
        "Airbus flight control laws: Normal Law (g-load demand in pitch, roll-rate demand in roll) with hard envelope protection",
        "Hard envelope protections: High angle of attack (alpha-prot), high speed protection, pitch attitude and bank angle limits",
        "Reversionary modes: Degradation to Alternate Law and Direct Law following multiple sensor/computer failure states"
      ]
    }],
    3: [{
      id: "aero-av-p3-autopilot-laws",
      title: "Autopilot Control Laws: Inner-Loop Attitude Hold & Outer-Loop Nav Tracking",
      youtube_video_id: "SiQzTdRpqsg",
      youtube_url: "https://www.youtube.com/watch?v=SiQzTdRpqsg",
      fallback_video_id: "HYBQ4KHRgVs",
      search_query: "Autopilot Flight Director Control Laws Inner Loop Stability Augmentation ILS Glide Slope",
      channel_name: "Avionics Academy",
      duration: "33:15",
      difficulty: "Advanced",
      topic_focus: "Inner Loop SAS (Attitude Hold), Outer Loop Autopilot (Altitude Preselect, VNAV, ILS Localizer/Glideslope)",
      key_takeaways: [
        "Hierarchical autopilot control loops: Fast inner-loop stability augmentation (SAS) and slower outer-loop path guidance",
        "Altitude hold and capture algorithms: Proportional rate of climb control with smooth exponential capture curves",
        "Instrument Landing System (ILS) autopilot coupling: Intercepting and tracking localizer beam and glideslope vertical profile",
        "Autothrottle / Autothrust systems: Mode transitions between Speed mode and Thrust/Climb mode (FMA annunciation)"
      ]
    }],
    4: [{
      id: "aero-av-p4-avionics-interview",
      title: "Avionics Systems / Embedded Flight Software Placement Interview & DO-178C Viva",
      youtube_video_id: "L2HzkyTQk54",
      youtube_url: "https://www.youtube.com/watch?v=L2HzkyTQk54",
      fallback_video_id: "jSxXMfeNIu0",
      search_query: "Avionics Software Engineer Technical Interview Questions DO-178C DAL A Safety Critical Viva",
      channel_name: "Aerospace Career Academy",
      duration: "31:40",
      difficulty: "Placement",
      topic_focus: "RTCA DO-178C Software Considerations, Design Assurance Levels (DAL A to E), MC/DC Coverage & Viva",
      key_takeaways: [
        "DO-178C airborne software certification: Design Assurance Levels from DAL A (Catastrophic) down to DAL E (No effect)",
        "Structural coverage requirements for DAL A safety-critical avionics: Modified Condition / Decision Coverage (MC/DC)",
        "Hardware-in-the-Loop (HIL) Iron Bird system integration test benches validating real-time actuators against avionics",
        "Passing avionics systems engineering interviews at Collins Aerospace, Honeywell Aerospace, Thales, and Garmin"
      ]
    }]
  }
};

