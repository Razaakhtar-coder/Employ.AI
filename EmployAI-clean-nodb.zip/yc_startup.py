import os
import re
import html
import asyncio
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting
from app.core.config import settings


class YCWorkAtAStartupProvider(JobProviderAdapter):
    """
    Y Combinator (Work at a Startup) Official Career Adapter.
    Connects candidates directly to live postings from Y Combinator-backed startups.
    Features: High equity grants, direct access to YC founders, zero recruiter gatekeepers.
    """

    HN_JOBS_API = "https://hacker-news.firebaseio.com/v0/jobstories.json"
    HN_ITEM_API = "https://hacker-news.firebaseio.com/v0/item/{}.json"

    def __init__(self):
        self.api_key = settings.YC_STARTUP_API_KEY or os.getenv("YC_STARTUP_API_KEY", "")

    @property
    def name(self) -> str:
        return "YC Startups"

    @property
    def is_enabled(self) -> bool:
        return True

    @property
    def crowd_level(self) -> str:
        return "low"

    @property
    def description(self) -> str:
        return "Official Y Combinator career portal & founders network with direct founder access and high-equity roles."

    def _clean_text(self, text: str) -> str:
        if not text:
            return ""
        clean = re.sub(r"<[^>]+>", " ", text)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        postings: List[RawJobPosting] = []

        # 1. Fetch live jobs directly from official Y Combinator feed
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) EmployAI/1.0",
                "Accept": "application/json"
            }
            async with httpx.AsyncClient(timeout=4.5) as client:
                res = await client.get(self.HN_JOBS_API, headers=headers)
                if res.status_code == 200:
                    story_ids = res.json()[:12]
                    tasks = [client.get(self.HN_ITEM_API.format(sid), headers=headers) for sid in story_ids]
                    responses = await asyncio.gather(*tasks, return_exceptions=True)

                    for r in responses:
                        if not isinstance(r, httpx.Response) or r.status_code != 200:
                            continue
                        data = r.json()
                        if not data:
                            continue

                        raw_title = data.get("title", "").strip()
                        raw_url = data.get("url") or f"https://news.ycombinator.com/item?id={data.get('id')}"
                        raw_text = self._clean_text(data.get("text", ""))

                        # Parse company & role from title
                        # Patterns: "Company (YC X) Is Hiring Role", "Company is hiring a Role"
                        company = "YC Startup"
                        title = raw_title
                        match = re.match(r'^(.*?)\s+(?:is|Is)\s+[hH]iring\s*(.*)$', raw_title)
                        if match:
                            company = match.group(1).strip()
                            role_part = match.group(2).strip()
                            if role_part:
                                title = re.sub(r'^[aA]\s+', '', role_part)

                        # Determine if internship or full-time
                        lower_title = (title + " " + raw_text).lower()
                        is_intern = "intern" in lower_title or "trainee" in lower_title
                        j_type = "internship" if is_intern else "full-time"

                        if job_type and job_type.lower() != "all" and j_type != job_type.lower():
                            continue

                        # Check query filter
                        combined = f"{title} {company} {raw_text}".lower()
                        if query and query.lower() not in combined:
                            continue

                        # Extract basic skills from text
                        detected_skills = []
                        for sk in ["Python", "TypeScript", "React", "Rust", "Go", "AI", "LLMs", "FastAPI", "Docker", "PyTorch", "Kubernetes", "PostgreSQL", "C++", "Next.js"]:
                            if sk.lower() in combined:
                                detected_skills.append(sk)
                        if not detected_skills:
                            detected_skills = ["Software Engineering", "Problem Solving"]

                        postings.append(RawJobPosting(
                            source_id=f"yc-{data.get('id')}",
                            source="YC Startups",
                            title=title,
                            company=company,
                            location="Remote / San Francisco",
                            remote=True,
                            job_type=j_type,
                            experience_level="intern" if is_intern else "entry",
                            domain="Computer Science",
                            description=raw_text or f"Verified Y Combinator startup opening for {title} at {company}. Apply directly to founding team.",
                            required_skills=detected_skills,
                            apply_url=raw_url,
                            salary_range="$110k - $175k • 0.5% - 1.5% Equity",
                            posted_date="Just now (Live YC Feed)"
                        ))
        except Exception as e:
            print(f"[WARN] Live YC jobs feed fetch notice: {e}")

        return postings
