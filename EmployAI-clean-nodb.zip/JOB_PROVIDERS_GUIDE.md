# Employ.AI - Job Provider Adapter Architecture & Extension Guide

The Employ.AI Job & Internship Matching Engine uses an adapter design pattern to pull and aggregate live career postings from legal, authorized external providers without scraping.

---

## 1. Architecture Overview

```
[External Job Source] (Arbeitnow / RemoteOK / Adzuna / JSearch / Custom Partner API)
        │
        ▼ (HTTP Request / Response)
[JobProviderAdapter] ──> Returns standardized List[RawJobPosting]
        │
        ▼
[JobProviderManager] ──> Executes concurrent aggregation across all active adapters
        │
        ▼
[JobNormalizationService] ──> Deduplication + Canonical NLP Skill Extraction
        │
        ▼
[JobMatchingService] ──> Deterministic 0-100 Match Scoring & Explainability
        │
        ▼
[Database / REST API] ──> /api/v1/jobs
```

---

## 2. The `JobProviderAdapter` Interface

Every provider adapter must inherit from `JobProviderAdapter` defined in [`app/services/job_providers/base.py`](file:///c:/Users/RAZA%20AKHTAR/Desktop/Employ.AI/backend/app/services/job_providers/base.py):

```python
from abc import ABC, abstractmethod
from typing import List, Optional
from app.schemas.job import RawJobPosting

class JobProviderAdapter(ABC):
    @property
    @abstractmethod
    def name(self) -> str:
        """Unique provider identifier name."""
        pass

    @property
    def is_enabled(self) -> bool:
        """Returns True if required API keys / configurations are set."""
        return True

    @abstractmethod
    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        """Fetches and maps external postings into standardized RawJobPosting DTOs."""
        pass
```

---

## 3. Step-by-Step: Adding a New Provider Adapter

### Step 1: Create the Adapter File
Create a new file in `app/services/job_providers/` (e.g. `wellfound.py`):

```python
import os
import httpx
from typing import List, Optional
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting

class WellfoundProvider(JobProviderAdapter):
    """
    Wellfound (AngelList Talent) Partner API Adapter.
    """
    API_URL = "https://api.wellfound.com/v1/jobs"

    def __init__(self):
        self.partner_key = os.getenv("WELLFOUND_PARTNER_KEY", "")

    @property
    def name(self) -> str:
        return "Wellfound"

    @property
    def is_enabled(self) -> bool:
        return bool(self.partner_key)

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        if not self.is_enabled:
            return []

        headers = {"Authorization": f"Bearer {self.partner_key}"}
        params = {"query": query or "Engineering", "page": page}

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(self.API_URL, headers=headers, params=params)
            if response.status_code != 200:
                return []

            data = response.json().get("jobs", [])
            postings = []
            for item in data:
                postings.append(RawJobPosting(
                    source_id=f"wellfound-{item['id']}",
                    source="Wellfound",
                    title=item["title"],
                    company=item["company"]["name"],
                    location=item.get("location", "Remote"),
                    remote=bool(item.get("is_remote", False)),
                    job_type="internship" if item.get("type") == "internship" else "full-time",
                    experience_level=item.get("experience_level", "entry"),
                    description=item["description"],
                    required_skills=item.get("skills", []),
                    apply_url=item["apply_url"],
                    salary_range=item.get("compensation")
                ))
            return postings
```

### Step 2: Register in `JobProviderManager`
In [`app/services/job_providers/manager.py`](file:///c:/Users/RAZA%20AKHTAR/Desktop/Employ.AI/backend/app/services/job_providers/manager.py):

```python
from app.services.job_providers.wellfound import WellfoundProvider

class JobProviderManager:
    def __init__(self):
        # Register new provider
        self.register_provider(WellfoundProvider())
```

### Step 3: Add API Keys to `.env`
Add any required environment variables:
```env
WELLFOUND_PARTNER_KEY="your-api-key-here"
```

The system automatically calls the new provider concurrently during regular background cron jobs and on-demand manual refresh events.
