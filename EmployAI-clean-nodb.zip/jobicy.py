import re
import html
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting


class JobicyProvider(JobProviderAdapter):
    """
    Jobicy Public Remote Jobs API Adapter.
    Pulls high-quality remote engineering, product analytics, design, marketing,
    finance, and operations opportunities.
    """

    API_URL = "https://jobicy.com/api/v2/remote-jobs"

    @property
    def name(self) -> str:
        return "Jobicy"

    def _strip_html(self, raw_html: str) -> str:
        if not raw_html:
            return ""
        clean = re.sub(r"<[^>]+>", " ", raw_html)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        postings: List[RawJobPosting] = []
        try:
            params = {"count": 50}
            if query:
                params["tag"] = query

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) EmployAI/1.0",
                "Accept": "application/json"
            }

            async with httpx.AsyncClient(timeout=12.0, follow_redirects=True) as client:
                response = await client.get(self.API_URL, params=params, headers=headers)
                if response.status_code != 200:
                    print(f"[WARN] Jobicy API returned status {response.status_code}")
                    return []

                payload = response.json()
                jobs = payload.get("jobs", [])

                for item in jobs:
                    raw_title = item.get("jobTitle", "")
                    raw_desc = self._strip_html(item.get("jobDescription") or item.get("jobExcerpt", ""))
                    company_name = item.get("companyName", "Innovative Tech Co.")
                    industry = item.get("jobIndustry") or []
                    if isinstance(industry, str):
                        industry = [industry]
                    tags = list(industry)

                    raw_types = item.get("jobType") or []
                    if isinstance(raw_types, str):
                        raw_types = [raw_types]
                    types_str = " ".join(raw_types).lower()

                    mapped_type = "full-time"
                    if "intern" in types_str or "intern" in raw_title.lower():
                        mapped_type = "internship"
                    elif "part" in types_str:
                        mapped_type = "part-time"
                    elif "contract" in types_str or "freelance" in types_str:
                        mapped_type = "contract"

                    job_level = (item.get("jobLevel") or "").lower()
                    exp_level = "entry"
                    if "senior" in job_level or "senior" in raw_title.lower() or "lead" in raw_title.lower():
                        exp_level = "senior"
                    elif "mid" in job_level:
                        exp_level = "mid"
                    elif "entry" in job_level or "intern" in mapped_type:
                        exp_level = "intern" if mapped_type == "internship" else "entry"

                    geo = item.get("jobGeo") or "Remote"

                    postings.append(RawJobPosting(
                        source_id=f"jobicy-{item.get('id', item.get('jobSlug', 'job'))}",
                        source="Jobicy",
                        title=raw_title,
                        company=company_name,
                        location=geo,
                        remote=True,
                        job_type=mapped_type,
                        experience_level=exp_level,
                        description=raw_desc,
                        required_skills=tags,
                        apply_url=item.get("url") or "https://jobicy.com",
                        posted_date=str(item.get("pubDate") or "Recently")
                    ))
        except Exception as e:
            print(f"[ERROR] Jobicy fetch_jobs failed: {e}")

        return postings
