from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status, Body
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user
from app.models.user import User
from app.models.profile import StudentProfile, IndustryProfile
from app.models.opportunity import Opportunity, Application, OpportunitySkill
from app.models.document import Document
from app.models.job import JobPosting
from app.schemas.opportunity import ApplicationCreate, ApplicationResponse

router = APIRouter(prefix="/applications", tags=["Applications"])


@router.post("/apply", response_model=ApplicationResponse, status_code=status.HTTP_201_CREATED)
def apply_to_opportunity(
    data: ApplicationCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Submit a verified application to an internship or job opportunity."""
    student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not student_profile:
        student_profile = StudentProfile(
            user_id=current_user.id,
            full_name=current_user.full_name or "Applicant",
            institution="EmployAI Campus Network",
            department="Computer Science & Engineering",
            cgpa=8.0
        )
        db.add(student_profile)
        db.flush()

    opp = db.query(Opportunity).filter(Opportunity.id == data.opportunity_id).first()
    if not opp:
        # Check if opportunity_id is a JobPosting from the aggregated portal
        job = db.query(JobPosting).filter(JobPosting.id == data.opportunity_id).first()
        if job:
            ind_profile = db.query(IndustryProfile).filter(IndustryProfile.company_name == job.company).first()
            if not ind_profile:
                ind_profile = IndustryProfile(
                    company_name=job.company or "Verified Employer",
                    industry=job.domain or "Technology",
                    location=job.location or "Global",
                    is_verified=True
                )
                db.add(ind_profile)
                db.flush()

            opp = Opportunity(
                id=job.id,
                company_id=ind_profile.id,
                title=job.title,
                type="internship" if job.job_type == "internship" else "job",
                domain=job.domain or "Computer Science",
                location=job.location or "Remote",
                work_mode="remote" if job.remote else "onsite",
                description=job.description or f"Role for {job.title} at {job.company}",
                stipend_salary=job.salary_range or "Competitive",
                eligibility_min_cgpa=6.0,
                is_active=True
            )
            db.add(opp)
            db.commit()
            db.refresh(opp)

    if not opp:
        raise HTTPException(status_code=404, detail="Opportunity not found.")

    # Check if already applied
    existing = db.query(Application).filter(
        Application.opportunity_id == opp.id,
        Application.user_id == current_user.id
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="You have already applied for this opportunity.")

    # Get latest resume doc
    doc_id = data.document_id
    if not doc_id:
        latest_doc = db.query(Document).filter(Document.user_id == current_user.id).order_by(Document.created_at.desc()).first()
        doc_id = latest_doc.id if latest_doc else None

    # Calculate dynamic match snapshot
    from app.models.taxonomy import StudentSkill
    st_skills = db.query(StudentSkill.skill_id).filter(StudentSkill.student_profile_id == student_profile.id).all()
    st_skill_ids = {s[0] for s in st_skills}

    opp_skills = db.query(OpportunitySkill).filter(OpportunitySkill.opportunity_id == opp.id).all()
    req_skills = [os for os in opp_skills if os.is_required]
    req_matched = len([os for os in req_skills if os.skill_id in st_skill_ids])
    req_total = len(req_skills) or 1

    base_score = (req_matched / req_total) * 85.0
    cgpa_score = 15.0 if (student_profile.cgpa or 0.0) >= opp.eligibility_min_cgpa else 0.0
    match_score = round(min(100.0, base_score + cgpa_score), 1)

    app_rec = Application(
        opportunity_id=opp.id,
        user_id=current_user.id,
        document_id=doc_id,
        status="applied",
        match_score_snapshot=match_score,
        cover_note=data.cover_note or "Applied via EmployAI Career Platform.",
        applied_at=datetime.now(timezone.utc)
    )
    db.add(app_rec)
    db.commit()
    db.refresh(app_rec)

    comp = db.query(IndustryProfile).filter(IndustryProfile.id == opp.company_id).first()
    comp_name = comp.company_name if comp else "EmployAI Partner"

    return ApplicationResponse(
        id=app_rec.id,
        opportunity_id=opp.id,
        opportunity_title=opp.title,
        company_name=comp_name,
        opportunity_type=opp.type,
        status=app_rec.status,
        match_score_snapshot=app_rec.match_score_snapshot,
        cover_note=app_rec.cover_note,
        applied_at=app_rec.applied_at,
        updated_at=app_rec.updated_at
    )


@router.get("/my-applications", response_model=List[ApplicationResponse])
def get_my_applications(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all submitted applications by current student."""
    apps = db.query(Application).filter(Application.user_id == current_user.id).order_by(Application.applied_at.desc()).all()
    results = []
    for a in apps:
        opp = db.query(Opportunity).filter(Opportunity.id == a.opportunity_id).first()
        comp = db.query(IndustryProfile).filter(IndustryProfile.id == opp.company_id).first() if opp else None
        results.append(ApplicationResponse(
            id=a.id,
            opportunity_id=a.opportunity_id,
            opportunity_title=opp.title if opp else "Opportunity",
            company_name=comp.company_name if comp else "Enterprise Partner",
            opportunity_type=opp.type if opp else "internship",
            status=a.status,
            match_score_snapshot=a.match_score_snapshot,
            cover_note=a.cover_note,
            applied_at=a.applied_at,
            updated_at=a.updated_at
        ))
    return results


@router.patch("/{application_id}/status")
def update_application_status(
    application_id: str,
    new_status: str = Body(..., embed=True),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Recruiter or Administrator updates candidate application status.
    Strictly verifies ownership to prevent Broken Object-Level Authorization (BOLA).
    """
    app_rec = db.query(Application).filter(Application.id == application_id).first()
    if not app_rec:
        raise HTTPException(status_code=404, detail="Application not found.")

    from app.core.dependencies import ADMIN_EMAIL
    is_admin = current_user.email.strip().lower() == ADMIN_EMAIL.lower()

    if not is_admin:
        opp = db.query(Opportunity).filter(Opportunity.id == app_rec.opportunity_id).first()
        ind_profile = db.query(IndustryProfile).filter(IndustryProfile.user_id == current_user.id).first()
        is_owner = False
        if opp and ind_profile and opp.company_id == ind_profile.id:
            is_owner = True
        elif opp and getattr(opp, "posted_by_user_id", None) == current_user.id:
            is_owner = True

        if not is_owner:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Forbidden: Only the opportunity employer or administrator can update application status."
            )

    app_rec.status = new_status
    app_rec.updated_at = datetime.now(timezone.utc)
    db.commit()
    return {"status": "success", "application_id": application_id, "new_status": new_status}
