export type UserRole = 'student' | 'academia' | 'industry' | 'admin';

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  avatar_url?: string;
  auth_provider?: string;
  is_active?: boolean;
  is_premium?: boolean;
  subscription_plan?: 'monthly' | 'annual' | string;
  subscription_valid_until?: string | number | null;
  days_remaining?: number;
  is_expired?: boolean;
}

export interface PaymentItem {
  id: string;
  user_id: string;
  user_email?: string;
  user_name?: string;
  amount: number;
  currency: string;
  upi_id: string;
  utr_number: string;
  payer_name?: string;
  payer_upi?: string;
  payment_app?: string;
  screenshot_url?: string;
  status: 'pending' | 'verified' | 'rejected';
  verified_at?: string;
  verified_by?: string;
  notes?: string;
  plan_type?: 'monthly' | 'annual' | string;
  valid_until?: string | null;
  created_at: string;
}

export interface PaymentStatusData {
  is_premium: boolean;
  is_admin: boolean;
  email: string;
  role: string;
  has_pending: boolean;
  active_payment: PaymentItem | null;
  history: PaymentItem[];
  plan_type?: 'monthly' | 'annual' | string | null;
  subscription_valid_until?: string | null;
  days_remaining?: number | null;
  is_expired?: boolean;
}

export interface StudentSkillItem {
  skill_id: string;
  skill_name: string;
  domain?: string;
  proficiency?: string;
  source?: string;
  evidence_snippet?: string;
}

export interface StudentProfile {
  id: string;
  user_id: string;
  enrollment_no?: string;
  institution_name?: string;
  degree?: string;
  department?: string;
  graduation_year?: number;
  cgpa?: number;
  target_domain?: string;
  profile_completion_pct?: number;
  bio?: string;
  location?: string;
  skills?: StudentSkillItem[];
}

export interface AcademicProfile {
  id: string;
  user_id: string;
  institution_name?: string;
  department?: string;
  designation?: string;
  employee_id?: string;
  contact_number?: string;
}

export interface IndustryProfile {
  id: string;
  user_id: string;
  company_name: string;
  website?: string;
  domain?: string;
  company_size?: string;
  location?: string;
  is_verified?: boolean;
}

export interface SkillCategory {
  id: string;
  name: string;
  description?: string;
  icon?: string;
  skills_count?: number;
}

export interface SkillItem {
  id: string;
  canonical_name: string;
  slug: string;
  domain: string;
  category_id?: string;
  description?: string;
  is_emerging: boolean;
}

export interface RoleSkillItem {
  skill_id: string;
  skill_name: string;
  domain?: string;
  is_required: boolean;
  weight: number;
  importance?: 'critical' | 'important' | 'preferred' | string;
  importance_level?: string;
}

export interface CareerRole {
  id: string;
  title: string;
  slug: string;
  domain: string;
  department_affinity?: string;
  description: string;
  market_demand?: 'very_high' | 'high' | 'medium';
  average_salary_lpa?: number;
  min_exp_months?: number;
  skills: RoleSkillItem[];
}

export interface SkillMatchItem {
  skill_id: string;
  skill_name: string;
  is_required: boolean;
  proficiency: string;
  source: string;
  weight?: number;
}

export interface MissingSkillItem {
  skill_id: string;
  skill_name: string;
  domain?: string;
  is_required: boolean;
  weight?: number;
  importance?: 'critical' | 'high' | 'medium' | string;
  importance_level?: string;
  recommended_learning_weeks?: number;
  recommendation?: string;
}

export interface MatchBreakdown {
  overall_match?: number;
  overall_match_pct?: number;
  required_skills_score?: number;
  required_skills_coverage_pct?: number;
  preferred_skills_score?: number;
  preferred_skills_bonus_pct?: number;
  projects_relevance_score?: number;
  education_eligibility_score?: number;
  matched_required_count?: number;
  total_required_count?: number;
  matched_preferred_count?: number;
  total_preferred_count?: number;
}

export interface ExplainabilityNarrative {
  summary?: string;
  match_summary?: string;
  why_matches?: string[];
  missing_critical_gaps?: string[];
  recommended_action_plan?: string[];
  key_strengths_summary?: string;
  primary_gap_summary?: string;
  competitive_positioning?: string;
}

export interface SkillGapEvaluation {
  id?: string;
  role_id: string;
  role_title: string;
  domain?: string;
  role_domain?: string;
  match_percentage?: number;
  match_breakdown?: MatchBreakdown;
  breakdown?: MatchBreakdown;
  matched_skills: SkillMatchItem[];
  missing_skills: MissingSkillItem[];
  explainability: ExplainabilityNarrative;
}

export interface RoadmapTask {
  id: string;
  title: string;
  description: string;
  resource_type?: string;
  resource_url?: string;
  estimated_hours: number;
  is_completed: boolean;
}

export interface PracticalExercise {
  id: string;
  title: string;
  domain_category?: string;
  prompt: string;
  starter_code?: string;
  solution_code?: string;
  language?: 'javascript' | 'python' | 'cpp' | 'sql' | 'formula' | 'medical_checklist' | 'structural_calc' | 'text' | string;
  expected_output?: string;
  hint?: string;
  test_cases?: Array<{ input?: string; expected: string; description: string }>;
}

export interface RoadmapYouTubeResource {
  id: string;
  title: string;
  youtube_video_id: string;
  youtube_url: string;
  fallback_video_id?: string;
  search_query?: string;
  channel_name: string;
  duration: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Placement';
  topic_focus?: string;
  key_takeaways: string[];
}

export interface LearningPlatformResource {
  platform_name: string;
  platform_url: string;
  topic_focus: string;
  resource_type: 'official_docs' | 'interactive_lab' | 'video_course' | 'clinical_case' | 'statutory_portal' | 'practice_arena' | string;
  access_badge: string;
  description: string;
}

export interface RoadmapMilestone {
  week_range: string;
  week_number?: number;
  stage_level?: 'beginner' | 'intermediate' | 'advanced' | 'projects' | 'placement' | string;
  phase_title?: string;
  focus_skill: string;
  goal: string;
  how_to_achieve?: string;
  key_action_steps?: string[];
  recommended_tools?: string[];
  pro_tips?: string[];
  checkpoint_criteria?: string[];
  interview_questions?: { question: string; answer_guide?: string }[];
  learning_platforms?: LearningPlatformResource[];
  youtube_resources?: RoadmapYouTubeResource[];
  topics: string[];
  practical_project?: string;
  suggested_project?: string;
  deliverable?: string;
  tasks: RoadmapTask[];
  is_completed?: boolean;
}

export interface PlacementIntelligence {
  target_entry_roles: string[];
  ats_keywords: string[];
  star_bullet_examples: string[];
  top_hiring_companies: string[];
  expected_salary_range: string;
  interview_screening_checklist: string[];
}

export interface LearningRoadmap {
  id: string;
  student_profile_id?: string;
  target_role_id?: string;
  target_role_title: string;
  target_domain?: string;
  domain?: string;
  title?: string;
  roadmap_type?: 'role' | 'co_domain' | 'custom';
  co_domain_name?: string;
  duration_weeks?: number;
  estimated_weeks?: number;
  completion_pct?: number;
  placement_destination?: PlacementIntelligence;
  milestones: RoadmapMilestone[];
  created_at?: string;
}

export interface ResumeScoreBreakdown {
  structure: number;
  content_impact: number;
  skill_density: number;
  formatting_clarity: number;
  overall_quality: number;
  keyword_match?: number;
  experience_relevance?: number;
}

export interface STARImprovement {
  section: string;
  original_bullet: string;
  suggested_bullet?: string;
  improved_bullet?: string;
  rationale: string;
  framework_used?: string;
  is_applied: boolean;
  is_safe_change?: boolean;
}

export interface KeywordRecommendation {
  keyword: string;
  category: string;
  reason: string;
  status: 'present' | 'missing' | 'underused' | string;
}

export interface JobSkillMatch {
  skill: string;
  status: 'matched' | 'partial' | 'missing' | string;
  resume_evidence?: string;
  recommendation?: string;
}

export interface JobMatchAnalysis {
  target_job_title?: string;
  target_industry?: string;
  matched_skills: JobSkillMatch[];
  missing_skills: JobSkillMatch[];
  job_alignment_score?: number;
  key_recommendations: string[];
}

export interface ResumeLinkItem {
  label: string;
  url: string;
  type?: 'linkedin' | 'github' | 'leetcode' | 'codeforces' | 'codechef' | 'hackerrank' | 'kaggle' | 'portfolio' | 'code' | 'demo' | 'email' | 'other' | string;
}

export interface ResumePersonalInfo {
  full_name?: string;
  headline?: string;
  title?: string;
  email?: string;
  phone?: string;
  location?: string;
  linkedin?: string;
  github?: string;
  leetcode?: string;
  codeforces?: string;
  codechef?: string;
  hackerrank?: string;
  kaggle?: string;
  portfolio?: string;
  other_links?: string[];
  links?: ResumeLinkItem[];
  summary?: string;
}

export interface ResumeEducationItem {
  institution: string;
  degree: string;
  field_of_study?: string;
  start_year?: string;
  end_year?: string;
  grade_or_cgpa?: string;
  location?: string;
  coursework?: string[];
  academic_achievements?: string[];
}

export interface ResumeExperienceItem {
  id?: string;
  company: string;
  role: string;
  location?: string;
  duration?: string;
  bullets: string[];
  technologies?: string[];
}

export interface ResumeProjectItem {
  id?: string;
  title: string;
  role_or_tech?: string;
  duration?: string;
  description?: string;
  technologies?: string[];
  bullets: string[];
  url?: string;
  code_url?: string;
  links?: ResumeLinkItem[];
}

export interface ResumeCertificationItem {
  name: string;
  issuer?: string;
  year?: string;
}

export interface StructuredResume {
  personal_info: ResumePersonalInfo;
  headline?: string;
  title?: string;
  summary?: string;
  skills: string[];
  technical_skills?: Record<string, string[]>;
  experience: ResumeExperienceItem[];
  projects: ResumeProjectItem[];
  portfolio?: ResumeProjectItem[];
  education: ResumeEducationItem[];
  certifications?: ResumeCertificationItem[];
  achievements?: string[];
  publications?: string[];
  awards?: string[];
  volunteering?: string[];
  languages?: string[];
}

export interface ResumeAnalysisResult {
  id: string;
  document_id?: string;
  filename?: string;
  file_url?: string;
  detected_links?: ResumeLinkItem[];
  detected_domain: string;
  resume_quality_score: number;
  score_breakdown: ResumeScoreBreakdown;
  strengths: string[];
  weaknesses: string[];
  extracted_skills: string[];
  extracted_projects: {
    title: string;
    role_or_tech?: string;
    description: string;
    key_technologies?: string[];
    quantifiable_metrics?: string;
    quantified_impact?: string;
  }[];
  extracted_experience?: {
    company_or_org: string;
    role: string;
    duration?: string;
    highlights: string[];
  }[];
  improvements: STARImprovement[];
  improvement_suggestions?: STARImprovement[];
  keyword_recommendations?: KeywordRecommendation[];
  job_analysis?: JobMatchAnalysis;
  structured_resume?: StructuredResume;
  section_audits?: ResumeSectionAudits;
  skill_gaps?: SkillGapAuditItem[];
  raw_text?: string;
  is_scratch?: boolean;
  created_at?: string;
}

export interface SkillGapAuditItem {
  skill: string;
  category?: string;
  importance: 'critical' | 'high' | 'recommended' | string;
  reason: string;
  suggested_action: string;
}

export interface SectionAuditItem {
  status: 'needs_modification' | 'good' | 'strong' | string;
  section_name: string;
  issues_detected: string[];
  modifications_needed: string[];
  ai_recommendation: string;
}

export interface ResumeSectionAudits {
  skill_gaps?: SkillGapAuditItem[];
  experience_audit?: SectionAuditItem;
  projects_audit?: SectionAuditItem;
  skills_audit?: SectionAuditItem;
  summary_audit?: SectionAuditItem;
}

export interface SectionEnhanceRequest {
  section: string;
  item_id?: string;
  current_content?: any;
  target_domain?: string;
  target_role?: string;
  instruction?: string;
}

export interface SectionEnhanceResponse {
  section: string;
  item_id?: string;
  original_content?: any;
  enhanced_content?: string;
  suggested_bullets: string[];
  action_verbs_used: string[];
  keywords_infused: string[];
  impact_explanation: string;
  ats_score_lift_estimate: number;
}

export interface OpportunitySkillItem {
  skill_id: string;
  skill_name: string;
  is_required: boolean;
  weight: number;
}

export interface Opportunity {
  id: string;
  company_id: string;
  company_name: string;
  company_logo?: string;
  company_location?: string;
  title: string;
  type: string;
  opportunity_type?: 'internship' | 'job' | 'research_fellowship' | string;
  domain: string;
  location: string;
  work_mode: string;
  description: string;
  stipend_salary?: string;
  stipend_or_salary?: string;
  eligibility_min_cgpa: number;
  eligible_departments: string[];
  deadline?: string;
  is_active: boolean;
  created_at: string;
  skills: OpportunitySkillItem[] | string[];
  user_match_percentage?: number;
  match_score?: number;
  matched_skills?: string[];
  missing_skills?: string[];
  eligibility_status?: string;
  is_applied?: boolean;
}

export interface CandidateCard {
  id?: string;
  application_id?: string;
  student_id: string;
  student_name: string;
  name?: string;
  email: string;
  degree: string;
  department: string;
  cgpa: number;
  match_pct?: number;
  match_percentage?: number;
  avatar_url?: string;
  verified_skills: string[];
  missing_skills: string[];
  ats_score?: number;
  is_ats_verified?: boolean;
  is_eligible?: boolean;
  verified_evidence?: {
    project_title: string;
    summary: string;
    link?: string;
  }[];
  application_status?: string;
  applied_at?: string;
}

export interface AcademiaStats {
  institution_name: string;
  total_registered_students: number;
  registered_students?: number;
  active_departments_count: number;
  active_departments?: number;
  overall_readiness_index: number;
  readiness_index?: number;
  placement_conversion_pct?: number;
  active_recruiters_count?: number;
  top_demanded_skills: {
    skill: string;
    domain: string;
    demand_index: number;
  }[];
  critical_department_skill_gaps: {
    skill_name: string;
    domain: string;
    students_lacking_count: number;
    percentage_lacking: number;
    importance: string;
  }[];
  department_metrics: {
    department: string;
    total_students: number;
    average_cgpa?: number;
    avg_cgpa?: number;
    average_readiness_score?: number;
    readiness_score?: number;
    top_skill_gaps?: string[];
    top_gaps?: string[];
    placed_or_shortlisted_count?: number;
  }[];
  curriculum_matrix?: {
    program: string;
    skills: { name: string; gap_level: 'low' | 'medium' | 'high'; score: number }[];
  }[];
}

export interface RecruiterDashboardStats {
  company_name: string;
  active_job_postings: number;
  total_applicants: number;
  average_applicant_match_pct: number;
  shortlisted_candidates_count: number;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  role: UserRole;
  user_id: string;
  email: string;
  full_name: string;
  avatar_url?: string;
  is_premium?: boolean;
  subscription_plan?: 'monthly' | 'annual' | string | null;
  subscription_valid_until?: string | null;
  days_remaining?: number | null;
  is_expired?: boolean;
}

// -------------------------------------------------------------
// ENHANCV-INSPIRED RESUME PLATFORM FEATURE TYPES
// -------------------------------------------------------------

export type ResumeTemplateId = 
  | 'ats_classic'
  | 'emerald_sidebar'
  | 'lavender_lilac'
  | 'midnight_gold'
  | 'executive_yellow'
  | 'professional'
  | 'modern'
  | 'minimal'
  | 'executive'
  | 'student_fresher';

export interface ResumeTemplateMeta {
  id: ResumeTemplateId;
  name: string;
  tagline: string;
  description: string;
  isATSFriendly: boolean;
  accentColor: string;
  previewClass: string;
}

export const RESUME_TEMPLATES: Array<{ id: ResumeTemplateId; label: string; tag: string }> = [
  { id: 'emerald_sidebar', label: 'Emerald Forest Sidebar', tag: 'Sales/Mgmt' },
  { id: 'lavender_lilac', label: 'Lavender Pastel Minimal', tag: 'Security/Law' },
  { id: 'midnight_gold', label: 'Midnight Navy & Gold', tag: 'Creative Tech' },
  { id: 'executive_yellow', label: 'Golden Modern Executive', tag: 'Finance/Exec' },
  { id: 'ats_classic', label: 'ATS Classic (Harvard)', tag: 'Ivy League' },
  { id: 'modern', label: 'Modern Tech (Silicon Valley)', tag: 'AI/Tech' },
  { id: 'professional', label: 'Corporate Professional', tag: 'Corporate' },
  { id: 'minimal', label: 'Minimalist Swiss', tag: 'Minimal' },
  { id: 'executive', label: 'Executive Leadership', tag: 'Leadership' },
  { id: 'student_fresher', label: 'Student / Fresher', tag: 'Academic' },
];

export interface ResumeVersionItem {
  version_id: string;
  version_num: number;
  version_name: string;
  target_job?: string;
  created_at: string;
  updated_at?: string;
  structured_resume?: StructuredResume;
  resume_quality_score?: number;
}

export interface SavedResumeItem {
  id: string;
  title: string;
  original_filename: string;
  detected_domain: string;
  ats_score: number;
  created_at: string;
  updated_at: string;
  version_count: number;
  active_version_id?: string;
  target_job?: string;
  versions: ResumeVersionItem[];
}

export interface BulletImprovementOption {
  option_id: string;
  text: string;
  style_label: string;
  why_better: string[];
  action_verb_used: string;
  keywords_used: string[];
}

export interface BulletImprovementOptionsResponse {
  original_bullet: string;
  options: BulletImprovementOption[];
  missing_metrics_advice?: string;
}

export interface SummaryImprovementOption {
  style: string;
  summary_text: string;
  why_better: string[];
}

export interface SummaryImprovementOptionsResponse {
  options: SummaryImprovementOption[];
}

export interface HeadlineGenerateResponse {
  headlines: string[];
  detected_domain: string;
  primary_recommendation: string;
}

export interface QualityIssueItem {
  id: string;
  category: 'weak_verbs' | 'repetition' | 'overly_long' | 'missing_metrics' | 'formatting' | 'vague_words' | string;
  severity: 'high' | 'medium' | 'low' | 'info';
  issue_title: string;
  location: string;
  snippet: string;
  recommendation: string;
  suggested_fix?: string;
}

export interface QualityCheckResult {
  overall_score: number;
  total_issues_count: number;
  weak_verbs_count: number;
  repetition_count: number;
  metrics_density_pct: number;
  issues: QualityIssueItem[];
}

export interface AppliedChangeItem {
  id: string;
  timestamp: string;
  description: string;
  section: 'experience' | 'projects' | 'summary' | 'skills' | 'headline' | 'education' | 'general';
  itemId?: string | null;
  originalText: string;
  newText: string;
}

// -------------------------------------------------------------
// JOB-SPECIFIC RESUME TAILORING TYPES
// -------------------------------------------------------------

export interface JobDescriptionParsedData {
  job_title: string;
  company_name?: string | null;
  domain: string;
  seniority?: string;
  required_skills: string[];
  preferred_skills: string[];
  technical_skills: string[];
  soft_skills: string[];
  tools_and_technologies: string[];
  responsibilities: string[];
  qualifications: string[];
  education_requirements: string[];
  experience_requirements?: string | null;
  certifications: string[];
  domain_terminology: string[];
  high_priority_keywords: string[];
  medium_priority_keywords: string[];
  low_priority_keywords: string[];
  action_verbs: string[];
  repeated_phrases: string[];
}

export interface JobRequirementMatchItem {
  id: string;
  requirement: string;
  category: 'skill' | 'responsibility' | 'qualification' | 'tool' | 'education' | string;
  status: 'matched' | 'partially_matched' | 'missing' | 'hidden_match' | string;
  importance: 'high' | 'medium' | 'low' | string;
  resume_evidence?: string | null;
  recommendation?: string | null;
  action_note?: string | null;
}

export interface TailoredBulletSuggestion {
  id: string;
  section: 'experience' | 'projects' | 'portfolio' | string;
  item_id?: string | null;
  item_title?: string | null;
  bullet_index: number;
  original_bullet: string;
  tailored_bullet: string;
  why_better: string;
  is_safe: boolean;
  change_type: 'safe_wording' | 'keyword_alignment' | 'structure' | 'requires_confirmation' | string;
}

export interface TailoredSummarySuggestion {
  original_summary?: string | null;
  tailored_summary: string;
  why_better: string;
  is_safe: boolean;
}

export interface TailoredProjectSuggestion {
  id: string;
  project_id?: string | null;
  original_title: string;
  tailored_title?: string | null;
  original_bullets: string[];
  tailored_bullets: string[];
  why_better: string;
  is_safe: boolean;
}

export interface JobTailoringAnalysisResponse {
  job_parsed: JobDescriptionParsedData;
  target_job_title: string;
  company_name?: string | null;
  overall_match_score: number;
  original_ats_score: number;
  tailored_ats_score: number;
  score_breakdown_before: Record<string, number>;
  score_breakdown_after: Record<string, number>;
  matched_count: number;
  partially_matched_count: number;
  missing_count: number;
  requirement_matches: JobRequirementMatchItem[];
  hidden_matches: JobRequirementMatchItem[];
  missing_skills: JobRequirementMatchItem[];
  prioritized_keywords: {
    high: string[];
    medium: string[];
    missing: string[];
  };
  added_skills?: string[];
  added_keywords?: string[];
  recommended_actions: string[];
  tailored_headline?: string | null;
  tailored_summary?: TailoredSummarySuggestion | null;
  tailored_skills_order: string[];
  tailored_experience_bullets: TailoredBulletSuggestion[];
  tailored_projects: TailoredProjectSuggestion[];
  tailored_structured_resume: StructuredResume;
  created_at: string;
}


export interface JobTailoringRequest {
  document_id?: string | null;
  job_description: string;
  structured_resume?: StructuredResume | null;
}

export interface JobAnalysisHistoryItem {
  id: string;
  document_id: string;
  job_title: string;
  company_name?: string | null;
  match_score: number;
  created_at: string;
  job_description_snippet: string;
  tailored_version_id?: string | null;
}

export interface SaveTailoredVersionRequest {
  version_name: string;
  target_job: string;
  company_name?: string | null;
  structured_resume: StructuredResume;
  job_description?: string | null;
  ats_score?: number;
}

// -------------------------------------------------------------
// Live Job Aggregation & Matching Engine Types
// -------------------------------------------------------------
export interface JobSkillDetail {
  skill_name: string;
  is_matched: boolean;
  is_required: boolean;
  importance: string;
  recommendation?: string;
}

export interface JobScoreBreakdown {
  skill_overlap_score: number;
  experience_fit_score: number;
  domain_fit_score: number;
  ats_readiness_score: number;
  overall_match: number;
}

export interface JobPosting {
  id: string;
  source_id: string;
  source: string;
  title: string;
  company: string;
  location: string;
  remote: boolean;
  job_type: string;
  experience_level: string;
  domain: string;
  description: string;
  required_skills: string[];
  apply_url: string;
  salary_range?: string | null;
  posted_date?: string | null;
  last_refreshed_at?: string | null;
  created_at?: string | null;
  match_score?: number;
  match_badge?: 'High Fit' | 'Good Fit' | 'Skill Gap' | string;
  matched_skills?: string[];
  missing_skills?: string[];
  is_eligible?: boolean;
  responsibilities?: string[];
  qualifications?: string[];
  benefits?: string[];
  about_company?: string;
}

export interface JobExplainResult {
  job_id: string;
  title: string;
  company: string;
  source: string;
  match_score: number;
  breakdown: JobScoreBreakdown;
  matched_skills: JobSkillDetail[];
  missing_skills: JobSkillDetail[];
  summary: string;
  why_matches: string[];
  missing_critical_gaps: string[];
  recommended_action_plan: string[];
  experience_assessment: string;
  domain_assessment: string;
}

export interface ManualJobMatchRequest {
  job_url?: string;
  pasted_description?: string;
  title?: string;
  company?: string;
}

export interface ManualJobMatchResult {
  title: string;
  company: string;
  domain: string;
  extracted_skills: string[];
  experience_level: string;
  match_score: number;
  breakdown: JobScoreBreakdown;
  matched_skills: JobSkillDetail[];
  missing_skills: JobSkillDetail[];
  summary: string;
  why_matches: string[];
  missing_critical_gaps: string[];
  recommended_action_plan: string[];
}

export interface JobRefreshResponse {
  status: string;
  refreshed_count: number;
  sources_contacted: string[];
  message: string;
  timestamp: string;
}

export interface ProviderMetadataItem {
  name: string;
  key: string;
  category: string;
  crowd_level: 'low' | 'moderate' | 'standard' | string;
  is_enabled: boolean;
  is_configured: boolean;
  has_live_feed: boolean;
  description: string;
  api_key_name: string;
  active_jobs_count?: number;
}

export interface ProvidersListResponse {
  providers: ProviderMetadataItem[];
  total_active: number;
  curated_low_crowd_count: number;
  last_sync_timestamp: string | null;
}

// =========================================================================
// READ & LEARN MY RESUME TYPES
// =========================================================================

export interface DeepDiveTopicDetail {
  title: string;
  summary: string;
  architecture_mechanism?: string;
  why_it_matters?: string;
  interview_defense?: string;
  common_pitfalls?: string;
}

export interface ResumeLearningLineBreakdown {
  raw_line: string;
  line_label?: string;
  brief_explanation: string;
  what_it_demonstrates: string;
  interview_angle: string;
  key_talking_point: string;
}

export interface ResumeLearningSkillItem {
  skill_name: string;
  what_it_is: string;
  what_it_is_used_for: string;
  what_it_means_on_resume: string;
  what_you_should_know: string[];
  how_to_explain_it: string;
  beginner_explanation: string;
  deeper_explanation: string;
  architecture_breakdown?: string;
  deeper_topics?: DeepDiveTopicDetail[];
  trade_offs_and_pitfalls?: string[];
  line_by_line_breakdown?: ResumeLearningLineBreakdown[];
  is_reviewed?: boolean;
}

export interface ResumeLearningProjectItem {
  project_name: string;
  what_you_wrote: string;
  project_explanation: string;
  technologies_mentioned: string[];
  concepts_to_understand: string[];
  your_contribution: string;
  what_you_should_know: string[];
  beginner_explanation: string;
  deeper_explanation: string;
  system_architecture?: string;
  deeper_concepts?: DeepDiveTopicDetail[];
  deeper_defense_points?: DeepDiveTopicDetail[];
  trade_offs_and_pitfalls?: string[];
  line_by_line_breakdown?: ResumeLearningLineBreakdown[];
  is_reviewed?: boolean;
}

export interface ResumeLearningExperienceItem {
  role: string;
  company: string;
  dates?: string | null;
  description: string;
  is_internship: boolean;
  what_you_claimed: string;
  skills_demonstrated: string[];
  important_terminology: { term: string; definition: string }[];
  what_you_should_understand: string[];
  beginner_explanation: string;
  deeper_explanation: string;
  operational_context?: string;
  deeper_learnings?: DeepDiveTopicDetail[];
  line_by_line_breakdown?: ResumeLearningLineBreakdown[];
  is_reviewed?: boolean;
}

export interface ResumeLearningEducationItem {
  degree: string;
  institution: string;
  dates_or_grade?: string | null;
  relevant_coursework: string[];
  academic_achievements: string[];
  what_it_demonstrates: string;
  key_concepts: string[];
  key_concepts_title?: string;
  deeper_foundations?: DeepDiveTopicDetail[];
  line_by_line_breakdown?: ResumeLearningLineBreakdown[];
  is_reviewed?: boolean;
}

export interface ResumeLearningCertificationItem {
  name: string;
  issuer?: string | null;
  what_it_represents: string;
  knowledge_covered: string[];
  important_concepts: string[];
  what_you_should_understand: string;
  deeper_standards?: DeepDiveTopicDetail[];
  line_by_line_breakdown?: ResumeLearningLineBreakdown[];
  is_reviewed?: boolean;
}

export interface ResumeLearningClaimItem {
  id: string;
  claim_text: string;
  source_section: string;
  what_you_should_understand: string[];
  deeper_claim_breakdown?: DeepDiveTopicDetail[];
  is_reviewed?: boolean;
}

export interface ResumeLearningAchievementItem {
  id: string;
  title: string;
  what_you_wrote: string;
  understand_it: string;
  key_things_to_know: string[];
  why_it_matters: string;
  what_you_should_explain: string[];
  beginner_explanation: string;
  deeper_explanation: string;
  deeper_context?: DeepDiveTopicDetail[];
  line_by_line_breakdown?: ResumeLearningLineBreakdown[];
  is_reviewed?: boolean;
}

export interface ResumeLearningSectionSummary {
  id: string;
  title: string;
  total_items: number;
  reviewed_items: number;
  is_present: boolean;
}

export interface ResumeLearningSummarySection {
  what_you_wrote: string;
  understand_it: string;
  key_things_to_know: string[];
  why_it_matters: string;
  what_you_should_explain: string;
  beginner_explanation: string;
  deeper_explanation: string;
  deeper_positioning_topics?: DeepDiveTopicDetail[];
  line_by_line_breakdown?: ResumeLearningLineBreakdown[];
  is_reviewed?: boolean;
}

export interface ResumeLearningGuideResponse {
  candidate_name?: string | null;
  detected_domain: string;
  headline?: string | null;
  summary_section?: ResumeLearningSummarySection | null;
  skills: ResumeLearningSkillItem[];
  projects: ResumeLearningProjectItem[];
  experience: ResumeLearningExperienceItem[];
  internships: ResumeLearningExperienceItem[];
  education: ResumeLearningEducationItem[];
  certifications: ResumeLearningCertificationItem[];
  achievements?: ResumeLearningAchievementItem[];
  claims: ResumeLearningClaimItem[];
  sections: ResumeLearningSectionSummary[];
  overall_progress_pct: number;
}

export interface InterviewQuestion {
  id: string;
  index: number;
  question: string;
  category: 'technical' | 'project_deepdive' | 'behavioral_star' | 'system_design' | 'core_fundamentals' | string;
  resume_reference?: string | null;
  context_hint?: string | null;
  ideal_answer_points?: string[];
  user_answer?: string | null;
  score?: number | null;
  is_correct?: boolean | null;
  verdict?: string | null;
  feedback?: string | null;
  strengths?: string[];
  improvements?: string[];
  star_breakdown?: {
    situation?: string;
    task?: string;
    action?: string;
    result?: string;
  } | null;
  model_answer_snippet?: string | null;
}

export interface InterviewSession {
  id: string;
  user_id?: string | null;
  student_profile_id?: string | null;
  target_role: string;
  interview_type: string;
  difficulty: string;
  total_questions: number;
  status: 'in_progress' | 'completed' | 'abandoned' | string;
  overall_score?: number | null;
  technical_score?: number | null;
  communication_score?: number | null;
  star_method_score?: number | null;
  problem_solving_score?: number | null;
  resume_authenticity_score?: number | null;
  readiness_level?: string | null;
  summary_verdict?: string | null;
  strengths: string[];
  improvements: string[];
  key_takeaways?: string[];
  questions: InterviewQuestion[];
  resume_snapshot?: any;
  duration_seconds: number;
  created_at: string;
  completed_at?: string | null;
}

export interface InterviewStartRequest {
  target_role?: string;
  interview_type?: string;
  difficulty?: string;
  num_questions?: number;
  resume_text?: string;
  document_id?: string;
  previous_questions?: string[];
}

export interface SubmitAnswerRequest {
  question_id: string;
  user_answer: string;
  audio_duration_seconds?: number;
}

export interface QuestionEvaluationResponse {
  question_id: string;
  score: number;
  is_correct?: boolean;
  verdict?: string;
  feedback: string;
  strengths: string[];
  improvements: string[];
  star_breakdown?: {
    situation?: string;
    task?: string;
    action?: string;
    result?: string;
  } | null;
  model_answer_snippet?: string | null;
}

export interface InterviewScoreHistoryItem {
  id: string;
  target_role: string;
  interview_type: string;
  difficulty: string;
  overall_score: number;
  technical_score?: number | null;
  communication_score?: number | null;
  star_method_score?: number | null;
  readiness_level?: string;
  total_questions: number;
  duration_seconds: number;
  created_at: string;
  completed_at?: string | null;
  strengths_count: number;
  improvements_count: number;
}

export interface InterviewHistoryData {
  history: InterviewScoreHistoryItem[];
  total_interviews: number;
  average_score: number;
  highest_score: number;
  score_trend: {
    date: string;
    score: number;
    role: string;
    type: string;
  }[];
  category_averages: {
    technical?: number;
    communication?: number;
    star_method?: number;
    problem_solving?: number;
  };
}



