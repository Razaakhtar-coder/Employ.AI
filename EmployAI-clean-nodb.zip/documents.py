from datetime import datetime, timezone
import os
from typing import List, Optional
from pydantic import BaseModel
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, status
from sqlalchemy.orm import Session
from app.core.config import settings
from app.core.dependencies import get_db, get_current_user, require_premium_user
from app.core.rate_limit import enforce_rate_limit
from app.models.user import User
from app.models.profile import StudentProfile
from app.models.document import Document, DocumentVersion, AnalysisResult
from app.models.taxonomy import StudentSkill, Skill
from app.models.opportunity import Application
from app.models.interview import InterviewSession
from app.schemas.document import (
    DocumentResponse, AnalysisResultResponse, ScoreBreakdown,
    ExtractedProject, ExtractedExperience, ResumeImprovementItem, ApplyImprovementRequest,
    StructuredResumeData, ResumePersonalInfo, ResumeExperienceItem, ResumeProjectItem,
    ResumeEducationItem, ResumeCertificationItem, KeywordRecommendationItem,
    JobDescriptionAnalysis, JobAnalysisRequest, SectionEnhanceRequest, SectionEnhanceResponse,
    SkillGapAuditItem, ResumeSectionAudits, SectionAuditItem,
    SavedResumeSummary, ResumeVersionItemSchema, ResumeVersionCreateRequest, ResumeRenameRequest,
    HeadlineGenerateRequest, HeadlineGenerateResponse,
    BulletImprovementOptionsRequest, BulletImprovementOptionsResponse, BulletImprovementOption,
    SummaryImprovementOptionsRequest, SummaryImprovementOptionsResponse, SummaryImprovementOption,
    QualityCheckRequest, QualityCheckResponse,
    JobTailoringRequest, JobTailoringAnalysisResponse, JobAnalysisHistoryItem, SaveTailoredVersionRequest,
    JobDescriptionParsedData, JobRequirementMatchItem, TailoredBulletSuggestion,
    TailoredSummarySuggestion, TailoredProjectSuggestion,
    ResumeLearningGuideResponse, CreateResumeScratchRequest, ResumeLinkItem,
    SyncResumeRequest
)
from app.services.document_service import DocumentService
from app.services.ai_service import AIService
from app.services.resume_parser_service import ResumeParserService
from app.services.taxonomy_service import TaxonomyService
from app.services.resume_learning_service import ResumeLearningService

router = APIRouter(prefix="/documents", tags=["Documents"])


def _ensure_scheme(u: Optional[str]) -> Optional[str]:
    """Ensures a URL has an absolute scheme (https:// or http:// or mailto: or tel:)."""
    if not u:
        return None
    s = u.strip()
    if not s:
        return None
    if s.startswith("http://") or s.startswith("https://") or s.startswith("mailto:") or s.startswith("tel:"):
        return s
    return f"https://{s}"


def _resolve_document_file_path(stored_filename: str) -> str:
    """Finds the document on disk checking both configured STORAGE_DIR and /tmp/storage with path sanitization."""
    safe_name = os.path.basename(stored_filename.strip())
    candidates = [
        os.path.join(settings.STORAGE_DIR, safe_name),
        os.path.join("/tmp/storage", safe_name),
        os.path.join("/tmp", safe_name)
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    return candidates[0]


def _build_structured_resume(analysis_data: dict, raw_text: str) -> StructuredResumeData:
    """
    Constructs a StructuredResumeData object strictly from extracted resume analysis
    or parses raw_text directly. Never injects fake/demo candidate profiles.
    Ensures 100% fidelity with original uploaded document.
    """
    structured_deterministic, _ = ResumeParserService.parse_resume(raw_text)
    struct_dict = analysis_data.get("structured_resume")
    if struct_dict and isinstance(struct_dict, dict):
        try:
            struct_obj = StructuredResumeData(**struct_dict)
            # Enforce ground-truth phone, headline, and portfolio
            if structured_deterministic.personal_info.phone and (not struct_obj.personal_info.phone or struct_obj.personal_info.phone not in raw_text):
                struct_obj.personal_info.phone = structured_deterministic.personal_info.phone
            if structured_deterministic.personal_info.headline and not struct_obj.personal_info.headline:
                struct_obj.personal_info.headline = structured_deterministic.personal_info.headline
                struct_obj.headline = structured_deterministic.headline
            if structured_deterministic.personal_info.title and not struct_obj.personal_info.title:
                struct_obj.personal_info.title = structured_deterministic.personal_info.title
                struct_obj.title = structured_deterministic.title
            if structured_deterministic.portfolio and not struct_obj.portfolio:
                struct_obj.portfolio = structured_deterministic.portfolio
            if structured_deterministic.personal_info.portfolio and not struct_obj.personal_info.portfolio:
                struct_obj.personal_info.portfolio = structured_deterministic.personal_info.portfolio
            return struct_obj
        except Exception as e:
            print(f"[WARN] Failed to instantiate StructuredResumeData from dictionary: {e}")

    return structured_deterministic


@router.post(
    "/upload",
    response_model=AnalysisResultResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(enforce_rate_limit("doc_upload", max_requests=10, window_seconds=120))]
)
async def upload_and_analyze_document(
    file: UploadFile = File(...),
    target_job_description: Optional[str] = Form(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Upload a resume document (PDF, DOCX, TXT), extract real text,
    and execute AI skill intelligence & ATS optimization.
    Strictly isolated: Clears stale resume skill states on fresh upload.
    """
    try:
        student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
        if not student_profile:
            student_profile = StudentProfile(user_id=current_user.id)
            db.add(student_profile)
            db.commit()
            db.refresh(student_profile)

        file_type = DocumentService.validate_file(file)
        content_bytes = await file.read()

        stored_filename, sha256_hash, file_size = DocumentService.save_file_securely(
            content_bytes, file.filename, file_type
        )

        extracted_text = DocumentService.extract_text(content_bytes, file_type)
        detected_links = DocumentService.extract_hyperlinks(content_bytes, file_type, extracted_text)

        # Execute AI Document & Skill Analysis with strict anti-hallucination
        analysis_data = AIService.analyze_resume(extracted_text, target_job_desc=target_job_description)
        structured_resume = _build_structured_resume(analysis_data, extracted_text)

        # Save Document record
        doc = Document(
            user_id=current_user.id,
            original_filename=file.filename,
            stored_filename=stored_filename,
            file_type=file_type,
            file_size_bytes=file_size,
            sha256_hash=sha256_hash,
            upload_status="analyzed"
        )
        db.add(doc)
        db.flush()

        doc_version = DocumentVersion(
            document_id=doc.id,
            version_num=1,
            raw_text=extracted_text,
            char_count=len(extracted_text),
            word_count=len(extracted_text.split()),
            parsed_metadata_json={
                "filename": file.filename,
                "size": file_size,
                "version_name": "Original Resume",
                "target_job": target_job_description or "General",
                "structured_resume": structured_resume.model_dump(),
                "ats_score": analysis_data.get("resume_quality_score", 80.0),
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
        )
        db.add(doc_version)

        score_dict = analysis_data.get("score_breakdown", {})
        if isinstance(score_dict, dict):
            score_model = ScoreBreakdown(**score_dict)
        else:
            score_model = score_dict

        analysis_rec = AnalysisResult(
            document_id=doc.id,
            student_profile_id=student_profile.id,
            resume_quality_score=analysis_data.get("resume_quality_score", 80.0),
            score_breakdown_json=score_model.model_dump() if hasattr(score_model, "model_dump") else score_model,
            detected_domain=analysis_data.get("detected_domain", "General Professional"),
            strengths_json=analysis_data.get("strengths", []),
            weaknesses_json=analysis_data.get("weaknesses", []),
            extracted_skills_json=analysis_data.get("extracted_skills", []),
            extracted_projects_json=analysis_data.get("extracted_projects", []),
            extracted_experience_json=analysis_data.get("extracted_experience", []),
            improvement_suggestions_json=analysis_data.get("improvement_suggestions", [])
        )
        db.add(analysis_rec)

        # Reset old resume-derived skills to prevent stale cross-document pollution
        db.query(StudentSkill).filter(
            StudentSkill.student_profile_id == student_profile.id,
            StudentSkill.source == "resume"
        ).delete(synchronize_session=False)

        # Sync genuinely extracted skills to StudentProfile
        extracted_skill_names = analysis_data.get("extracted_skills", [])
        for skill_item in extracted_skill_names:
            norm_skill = TaxonomyService.normalize_skill_name(db, skill_item, domain_hint=analysis_data.get("detected_domain"))
            if norm_skill:
                existing_st_skill = db.query(StudentSkill).filter(
                    StudentSkill.student_profile_id == student_profile.id,
                    StudentSkill.skill_id == norm_skill.id
                ).first()
                if not existing_st_skill:
                    db.add(StudentSkill(
                        student_profile_id=student_profile.id,
                        skill_id=norm_skill.id,
                        proficiency="intermediate",
                        source="resume",
                        evidence_snippet=f"Extracted from {file.filename}"
                    ))

        # Update detected domain on student profile
        det_domain = analysis_data.get("detected_domain")
        if det_domain and det_domain != "General Professional":
            student_profile.target_domain = det_domain
            student_profile.department = det_domain
        else:
            student_profile.target_domain = det_domain
        current_pct = student_profile.profile_completion_pct if student_profile.profile_completion_pct is not None else 30
        student_profile.profile_completion_pct = max(current_pct, 85)

        db.commit()
        db.refresh(analysis_rec)

        keyword_recs = [
            KeywordRecommendationItem(**k) if isinstance(k, dict) else k
            for k in analysis_data.get("keyword_recommendations", [])
        ]
        job_analysis = (
            JobDescriptionAnalysis(**analysis_data["job_analysis"])
            if isinstance(analysis_data.get("job_analysis"), dict)
            else analysis_data.get("job_analysis")
        )

        section_audits = (
            ResumeSectionAudits(**analysis_data["section_audits"])
            if isinstance(analysis_data.get("section_audits"), dict)
            else analysis_data.get("section_audits")
        )
        skill_gaps = [
            SkillGapAuditItem(**s) if isinstance(s, dict) else s
            for s in analysis_data.get("skill_gaps", [])
        ]

        return AnalysisResultResponse(
            id=analysis_rec.id,
            document_id=doc.id,
            student_profile_id=student_profile.id,
            resume_quality_score=analysis_rec.resume_quality_score,
            score_breakdown=score_model,
            detected_domain=analysis_rec.detected_domain or "General Professional",
            strengths=analysis_rec.strengths_json or [],
            weaknesses=analysis_rec.weaknesses_json or [],
            extracted_skills=analysis_rec.extracted_skills_json or [],
            extracted_projects=[ExtractedProject(**p) if isinstance(p, dict) else p for p in (analysis_rec.extracted_projects_json or [])],
            extracted_experience=[ExtractedExperience(**e) if isinstance(e, dict) else e for e in (analysis_rec.extracted_experience_json or [])],
            improvement_suggestions=[ResumeImprovementItem(**i) if isinstance(i, dict) else i for i in (analysis_rec.improvement_suggestions_json or [])],
            structured_resume=structured_resume,
            keyword_recommendations=keyword_recs,
            job_analysis=job_analysis,
            section_audits=section_audits,
            skill_gaps=skill_gaps,
            raw_text=extracted_text,
            filename=file.filename,
            file_url=f"/api/v1/documents/{doc.id}/file",
            detected_links=detected_links,
            is_scratch=False,
            created_at=analysis_rec.created_at
        )
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        import traceback
        print(f"[ERROR] Failed to upload and analyze document: {e}")
        traceback.print_exc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Document parsing error: {str(e)}"
        )


@router.get("/active/file")
def get_active_resume_file(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Streams the active uploaded resume binary file (PDF/DOCX/TXT) for high-fidelity canvas rendering."""
    from fastapi.responses import FileResponse
    doc = db.query(Document).filter(
        Document.user_id == current_user.id
    ).order_by(Document.created_at.desc()).first()

    if not doc or not doc.stored_filename:
        raise HTTPException(status_code=404, detail="No active resume file found.")

    if doc.file_type == "scratch":
        raise HTTPException(status_code=404, detail="Active resume was created from scratch; no original uploaded document exists.")

    doc_ver = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).order_by(DocumentVersion.version_num.desc()).first()
    if doc_ver and isinstance(doc_ver.parsed_metadata_json, dict):
        meta = doc_ver.parsed_metadata_json
        if meta.get("is_scratch") or meta.get("source") == "scratch" or meta.get("version_name") == "Created from Scratch":
            raise HTTPException(status_code=404, detail="Active resume was created from scratch; no original uploaded document exists.")

    file_path = _resolve_document_file_path(doc.stored_filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Stored resume file not found on disk.")

    media_type = "application/pdf" if doc.file_type == "pdf" else (
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document" if doc.file_type == "docx" else "application/octet-stream"
    )
    return FileResponse(
        path=file_path,
        media_type=media_type,
        filename=doc.original_filename
    )


@router.get("/{document_id}/file")
def get_document_file(
    document_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Streams a specific document binary file by ID."""
    from fastapi.responses import FileResponse
    doc = db.query(Document).filter(
        Document.id == document_id,
        Document.user_id == current_user.id
    ).first()

    if not doc or not doc.stored_filename:
        raise HTTPException(status_code=404, detail="Document file not found.")

    if doc.file_type == "scratch":
        raise HTTPException(status_code=404, detail="Document was created from scratch; no original uploaded document exists.")

    doc_ver = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).order_by(DocumentVersion.version_num.desc()).first()
    if doc_ver and isinstance(doc_ver.parsed_metadata_json, dict):
        meta = doc_ver.parsed_metadata_json
        if meta.get("is_scratch") or meta.get("source") == "scratch" or meta.get("version_name") == "Created from Scratch":
            raise HTTPException(status_code=404, detail="Document was created from scratch; no original uploaded document exists.")

    file_path = _resolve_document_file_path(doc.stored_filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Stored document file not found on disk.")

    media_type = "application/pdf" if doc.file_type == "pdf" else (
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document" if doc.file_type == "docx" else "application/octet-stream"
    )
    return FileResponse(
        path=file_path,
        media_type=media_type,
        filename=doc.original_filename
    )


@router.get("/latest-analysis", response_model=AnalysisResultResponse)
def get_latest_analysis(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieve the most recent resume analysis result for the current user."""
    student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not student_profile:
        raise HTTPException(status_code=404, detail="Student profile not found.")

    analysis_rec = db.query(AnalysisResult).filter(
        AnalysisResult.student_profile_id == student_profile.id
    ).order_by(AnalysisResult.created_at.desc()).first()

    if not analysis_rec:
        raise HTTPException(status_code=404, detail="No resume analysis found. Please upload a resume first.")

    doc = db.query(Document).filter(Document.id == analysis_rec.document_id).first()
    doc_ver = db.query(DocumentVersion).filter(DocumentVersion.document_id == analysis_rec.document_id).order_by(DocumentVersion.version_num.desc()).first()

    score_dict = analysis_rec.score_breakdown_json or {
        "structure": 85.0, "content_impact": 80.0, "skill_density": 82.0, "formatting_clarity": 85.0, "overall_quality": 83.0
    }

    raw_text = doc_ver.raw_text if doc_ver else ""
    metadata = doc_ver.parsed_metadata_json if doc_ver else {}
    struct_dict = metadata.get("structured_resume") if isinstance(metadata, dict) else None

    if struct_dict:
        try:
            structured_resume = StructuredResumeData(**struct_dict)
        except Exception:
            structured_resume = _build_structured_resume({}, raw_text)
    else:
        structured_resume = _build_structured_resume({}, raw_text)

    # Generate fresh keyword recommendations based on actual resume text
    _, eval_data = ResumeParserService.parse_resume(raw_text)
    keyword_recs = [
        KeywordRecommendationItem(**k) if isinstance(k, dict) else k
        for k in eval_data.get("keyword_recommendations", [])
    ]

    section_audits = eval_data.get("section_audits")
    skill_gaps = [
        SkillGapAuditItem(**s) if isinstance(s, dict) else s
        for s in eval_data.get("skill_gaps", [])
    ]

    # Extract detected links from document file on disk or text
    detected_links = []
    if doc and doc.stored_filename:
        file_path = _resolve_document_file_path(doc.stored_filename)
        if os.path.exists(file_path):
            try:
                with open(file_path, "rb") as f:
                    file_bytes = f.read()
                detected_links = DocumentService.extract_hyperlinks(file_bytes, doc.file_type, raw_text)
            except Exception as e:
                print(f"[DEBUG] Error extracting links from disk file: {e}")
    if not detected_links and raw_text:
        detected_links = DocumentService.extract_hyperlinks(b"", "txt", raw_text)

    # Supplement detected_links with structured resume social/portfolio/project links
    if structured_resume:
        existing_urls = {l.url for l in detected_links if hasattr(l, "url")}
        p = getattr(structured_resume, "personal_info", None)
        if p:
            if p.linkedin:
                u = _ensure_scheme(p.linkedin)
                if u and u not in existing_urls:
                    detected_links.append(ResumeLinkItem(label="LinkedIn", url=u, type="linkedin"))
                    existing_urls.add(u)
            if p.github:
                u = _ensure_scheme(p.github)
                if u and u not in existing_urls:
                    detected_links.append(ResumeLinkItem(label="GitHub", url=u, type="github"))
                    existing_urls.add(u)
            if p.portfolio:
                u = _ensure_scheme(p.portfolio)
                if u and u not in existing_urls:
                    detected_links.append(ResumeLinkItem(label="Portfolio", url=u, type="portfolio"))
                    existing_urls.add(u)
            if getattr(p, "leetcode", None):
                u = _ensure_scheme(p.leetcode)
                if u and u not in existing_urls:
                    detected_links.append(ResumeLinkItem(label="LeetCode", url=u, type="leetcode"))
                    existing_urls.add(u)
            if getattr(p, "codeforces", None):
                u = _ensure_scheme(p.codeforces)
                if u and u not in existing_urls:
                    detected_links.append(ResumeLinkItem(label="Codeforces", url=u, type="codeforces"))
                    existing_urls.add(u)
        if getattr(structured_resume, "projects", None):
            for proj in structured_resume.projects:
                if proj.url:
                    u = _ensure_scheme(proj.url)
                    if u and u not in existing_urls:
                        detected_links.append(ResumeLinkItem(label=f"{proj.title} Demo", url=u, type="demo"))
                        existing_urls.add(u)
                if proj.code_url:
                    u = _ensure_scheme(proj.code_url)
                    if u and u not in existing_urls:
                        detected_links.append(ResumeLinkItem(label=f"{proj.title} Repo", url=u, type="repo"))
                        existing_urls.add(u)

    is_scratch = False
    if doc and doc.file_type == "scratch":
        is_scratch = True
    elif metadata and isinstance(metadata, dict):
        if metadata.get("is_scratch") or metadata.get("source") == "scratch" or metadata.get("version_name") == "Created from Scratch":
            is_scratch = True

    return AnalysisResultResponse(
        id=analysis_rec.id,
        document_id=analysis_rec.document_id,
        student_profile_id=student_profile.id,
        resume_quality_score=analysis_rec.resume_quality_score,
        score_breakdown=ScoreBreakdown(**score_dict),
        detected_domain=analysis_rec.detected_domain or "General Professional",
        strengths=analysis_rec.strengths_json or [],
        weaknesses=analysis_rec.weaknesses_json or [],
        extracted_skills=analysis_rec.extracted_skills_json or [],
        extracted_projects=[ExtractedProject(**p) if isinstance(p, dict) else p for p in (analysis_rec.extracted_projects_json or [])],
        extracted_experience=[ExtractedExperience(**e) if isinstance(e, dict) else e for e in (analysis_rec.extracted_experience_json or [])],
        improvement_suggestions=[ResumeImprovementItem(**i) if isinstance(i, dict) else i for i in (analysis_rec.improvement_suggestions_json or [])],
        structured_resume=structured_resume,
        keyword_recommendations=keyword_recs,
        job_analysis=None,
        section_audits=section_audits,
        skill_gaps=skill_gaps,
        raw_text=raw_text,
        filename=doc.original_filename if doc else "Analyzed Resume",
        file_url=None if is_scratch else (f"/api/v1/documents/{doc.id}/file" if doc else None),
        detected_links=[] if is_scratch else detected_links,
        is_scratch=is_scratch,
        created_at=analysis_rec.created_at
    )


@router.post("/analyze-job", response_model=AnalysisResultResponse)
def analyze_with_target_job(
    request: JobAnalysisRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Re-analyze current active resume against a target job description."""
    student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not student_profile:
        raise HTTPException(status_code=404, detail="Student profile not found.")

    analysis_rec = db.query(AnalysisResult).filter(
        AnalysisResult.student_profile_id == student_profile.id
    ).order_by(AnalysisResult.created_at.desc()).first()

    if not analysis_rec:
        raise HTTPException(status_code=404, detail="No resume uploaded yet. Please upload your resume first.")

    doc = db.query(Document).filter(Document.id == analysis_rec.document_id).first()
    doc_ver = db.query(DocumentVersion).filter(DocumentVersion.document_id == analysis_rec.document_id).order_by(DocumentVersion.version_num.desc()).first()
    raw_text = doc_ver.raw_text if doc_ver else ""

    structured_data, analysis_metrics = ResumeParserService.parse_resume(raw_text, target_job_desc=request.target_job_description)

    score_dict = analysis_metrics["score_breakdown"].model_dump() if hasattr(analysis_metrics["score_breakdown"], "model_dump") else analysis_metrics["score_breakdown"]
    keyword_recs = [
        KeywordRecommendationItem(**k) if isinstance(k, dict) else k
        for k in analysis_metrics.get("keyword_recommendations", [])
    ]
    job_analysis = (
        JobDescriptionAnalysis(**analysis_metrics["job_analysis"])
        if isinstance(analysis_metrics.get("job_analysis"), dict)
        else analysis_metrics.get("job_analysis")
    )

    section_audits = analysis_metrics.get("section_audits")
    skill_gaps = [
        SkillGapAuditItem(**s) if isinstance(s, dict) else s
        for s in analysis_metrics.get("skill_gaps", [])
    ]

    # Extract detected links
    detected_links = []
    if doc and doc.stored_filename:
        file_path = _resolve_document_file_path(doc.stored_filename)
        if os.path.exists(file_path):
            try:
                with open(file_path, "rb") as f:
                    file_bytes = f.read()
                detected_links = DocumentService.extract_hyperlinks(file_bytes, doc.file_type, raw_text)
            except Exception:
                pass
    if not detected_links and raw_text:
        detected_links = DocumentService.extract_hyperlinks(b"", "txt", raw_text)

    is_scratch = False
    if doc and doc.file_type == "scratch":
        is_scratch = True
    elif doc_ver and isinstance(doc_ver.parsed_metadata_json, dict):
        meta = doc_ver.parsed_metadata_json
        if meta.get("is_scratch") or meta.get("source") == "scratch" or meta.get("version_name") == "Created from Scratch":
            is_scratch = True

    return AnalysisResultResponse(
        id=analysis_rec.id,
        document_id=analysis_rec.document_id,
        student_profile_id=student_profile.id,
        resume_quality_score=analysis_metrics["resume_quality_score"],
        score_breakdown=ScoreBreakdown(**score_dict),
        detected_domain=analysis_metrics["detected_domain"],
        strengths=analysis_metrics["strengths"],
        weaknesses=analysis_metrics["weaknesses"],
        extracted_skills=analysis_metrics["extracted_skills"],
        extracted_projects=[ExtractedProject(**p.model_dump()) if hasattr(p, "model_dump") else (ExtractedProject(**p) if isinstance(p, dict) else p) for p in analysis_metrics["extracted_projects"]],
        extracted_experience=[ExtractedExperience(**e.model_dump()) if hasattr(e, "model_dump") else (ExtractedExperience(**e) if isinstance(e, dict) else e) for e in analysis_metrics["extracted_experience"]],
        improvement_suggestions=[ResumeImprovementItem(**i.model_dump()) if hasattr(i, "model_dump") else (ResumeImprovementItem(**i) if isinstance(i, dict) else i) for i in analysis_metrics["improvement_suggestions"]],
        structured_resume=structured_data,
        keyword_recommendations=keyword_recs,
        job_analysis=job_analysis,
        section_audits=section_audits,
        skill_gaps=skill_gaps,
        raw_text=raw_text,
        filename=doc.original_filename if doc else "Analyzed Resume",
        file_url=None if is_scratch else (f"/api/v1/documents/{doc.id}/file" if doc else None),
        detected_links=[] if is_scratch else detected_links,
        is_scratch=is_scratch,
        created_at=analysis_rec.created_at
    )


@router.post("/enhance-section", response_model=SectionEnhanceResponse)
def enhance_resume_section(
    request: SectionEnhanceRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Enhances a specific resume section/bullet statement using LLM to generate
    excellent professional wording, strong action verbs, and quantifiable STAR deliverables.
    """
    student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    domain = request.target_domain or (student_profile.target_domain if student_profile else "General Professional")

    enhanced_result = AIService.enhance_section(
        section=request.section,
        item_id=request.item_id,
        current_content=request.current_content,
        target_domain=domain,
        target_role=request.target_role,
        instruction=request.instruction
    )
    return SectionEnhanceResponse(**enhanced_result)


@router.delete("/active", status_code=status.HTTP_200_OK)
def delete_active_resume(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Deletes the current active resume, analysis results, and associated resume skills for the user.
    """
    try:
        student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
        if student_profile:
            # Clear resume-derived skills
            db.query(StudentSkill).filter(
                StudentSkill.student_profile_id == student_profile.id,
                StudentSkill.source == "resume"
            ).delete(synchronize_session=False)
            # Clear analysis results for this student profile
            db.query(AnalysisResult).filter(
                AnalysisResult.student_profile_id == student_profile.id
            ).delete(synchronize_session=False)
            student_profile.target_domain = None

        # Delete documents for this user
        user_docs = db.query(Document).filter(Document.user_id == current_user.id).all()
        for doc in user_docs:
            # Unlink applications referencing this document to maintain foreign key integrity
            db.query(Application).filter(Application.document_id == doc.id).update(
                {"document_id": None}, synchronize_session=False
            )
            # Unlink interview sessions referencing this document
            db.query(InterviewSession).filter(InterviewSession.document_id == doc.id).update(
                {"document_id": None}, synchronize_session=False
            )

            # Remove physical file on disk if present
            if doc.stored_filename:
                try:
                    file_path = os.path.join(settings.STORAGE_DIR, doc.stored_filename)
                    if os.path.exists(file_path):
                        os.remove(file_path)
                except Exception as e:
                    print(f"[WARN] Failed to delete stored resume file {doc.stored_filename}: {e}")

            # Deleting the doc entity will cascade-delete versions and analysis_results cleanly in SQLAlchemy ORM
            db.delete(doc)

        db.commit()
        return {"message": "Active resume and associated analysis deleted successfully."}
    except Exception as e:
        db.rollback()
        import traceback
        print(f"[ERROR] Failed to delete active resume: {e}")
        traceback.print_exc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete active resume: {str(e)}"
        )


def _doc_to_summary(doc: Document, db: Session) -> SavedResumeSummary:
    analysis = db.query(AnalysisResult).filter(AnalysisResult.document_id == doc.id).order_by(AnalysisResult.created_at.desc()).first()
    versions = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).order_by(DocumentVersion.version_num.asc()).all()

    version_items: List[ResumeVersionItemSchema] = []
    active_version_id: Optional[str] = None
    latest_updated = doc.created_at
    latest_target_job: Optional[str] = None

    for v in versions:
        meta = v.parsed_metadata_json or {}
        v_name = meta.get("version_name", f"Version {v.version_num}")
        t_job = meta.get("target_job")
        if t_job:
            latest_target_job = t_job
        u_at_str = meta.get("updated_at")
        try:
            u_at = datetime.fromisoformat(u_at_str) if u_at_str else v.created_at
        except Exception:
            u_at = v.created_at

        if u_at > latest_updated:
            latest_updated = u_at

        struct_dict = meta.get("structured_resume")
        struct_model = None
        if struct_dict and isinstance(struct_dict, dict):
            try:
                struct_model = StructuredResumeData(**struct_dict)
            except Exception:
                pass

        ats_score = float(meta.get("ats_score", analysis.resume_quality_score if analysis else 80.0))

        v_item = ResumeVersionItemSchema(
            version_id=v.id,
            version_num=v.version_num,
            version_name=v_name,
            target_job=t_job,
            created_at=v.created_at,
            updated_at=u_at,
            structured_resume=struct_model,
            resume_quality_score=ats_score
        )
        version_items.append(v_item)
        active_version_id = v.id

    ats = analysis.resume_quality_score if analysis else 80.0
    domain = analysis.detected_domain if analysis and analysis.detected_domain else "General Professional"

    title = doc.original_filename
    if versions:
        last_meta = versions[-1].parsed_metadata_json or {}
        if last_meta.get("custom_title"):
            title = last_meta["custom_title"]

    return SavedResumeSummary(
        id=doc.id,
        title=title,
        original_filename=doc.original_filename,
        detected_domain=domain,
        ats_score=ats,
        created_at=doc.created_at,
        updated_at=latest_updated,
        version_count=len(versions),
        active_version_id=active_version_id,
        target_job=latest_target_job,
        versions=version_items
    )


# -----------------------------------------------------------------------------
# 1. MY RESUMES / RESUME STORAGE ENDPOINTS
# -----------------------------------------------------------------------------

@router.get("/my-resumes", response_model=List[SavedResumeSummary])
def list_my_resumes(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieves all saved resumes for the authenticated user with version counts and ATS scores."""
    docs = db.query(Document).filter(Document.user_id == current_user.id).order_by(Document.created_at.desc()).all()
    return [_doc_to_summary(doc, db) for doc in docs]


@router.post("/{document_id}/open", response_model=AnalysisResultResponse)
def open_saved_resume(
    document_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Loads a specific saved resume into the active workspace."""
    doc = db.query(Document).filter(Document.id == document_id, Document.user_id == current_user.id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Resume document not found.")

    student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if not student_profile:
        student_profile = StudentProfile(user_id=current_user.id)
        db.add(student_profile)
        db.commit()
        db.refresh(student_profile)

    analysis_rec = db.query(AnalysisResult).filter(AnalysisResult.document_id == doc.id).order_by(AnalysisResult.created_at.desc()).first()
    doc_ver = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).order_by(DocumentVersion.version_num.desc()).first()

    raw_text = doc_ver.raw_text if doc_ver else ""
    metadata = doc_ver.parsed_metadata_json if doc_ver else {}
    struct_dict = metadata.get("structured_resume") if isinstance(metadata, dict) else None

    if struct_dict:
        try:
            structured_resume = StructuredResumeData(**struct_dict)
        except Exception:
            structured_resume = _build_structured_resume({}, raw_text)
    else:
        structured_resume = _build_structured_resume({}, raw_text)

    # Touch analysis_rec created_at so it becomes the latest active
    if analysis_rec:
        analysis_rec.created_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(analysis_rec)

    # Generate fresh keyword recommendations and audits
    _, eval_data = ResumeParserService.parse_resume(raw_text)
    keyword_recs = [
        KeywordRecommendationItem(**k) if isinstance(k, dict) else k
        for k in eval_data.get("keyword_recommendations", [])
    ]
    section_audits = eval_data.get("section_audits")
    skill_gaps = [
        SkillGapAuditItem(**s) if isinstance(s, dict) else s
        for s in eval_data.get("skill_gaps", [])
    ]

    detected_links = []
    if doc.stored_filename:
        file_path = os.path.join(settings.STORAGE_DIR, doc.stored_filename)
        if os.path.exists(file_path):
            try:
                with open(file_path, "rb") as f:
                    file_bytes = f.read()
                detected_links = DocumentService.extract_hyperlinks(file_bytes, doc.file_type, raw_text)
            except Exception:
                pass
    if not detected_links and raw_text:
        detected_links = DocumentService.extract_hyperlinks(b"", "txt", raw_text)

    score_dict = analysis_rec.score_breakdown_json if analysis_rec and analysis_rec.score_breakdown_json else {
        "structure": 85.0, "content_impact": 80.0, "skill_density": 82.0, "formatting_clarity": 85.0, "overall_quality": 83.0
    }

    is_scratch = False
    if doc.file_type == "scratch":
        is_scratch = True
    elif metadata and isinstance(metadata, dict):
        if metadata.get("is_scratch") or metadata.get("source") == "scratch" or metadata.get("version_name") == "Created from Scratch":
            is_scratch = True

    return AnalysisResultResponse(
        id=analysis_rec.id if analysis_rec else doc.id,
        document_id=doc.id,
        student_profile_id=student_profile.id,
        resume_quality_score=analysis_rec.resume_quality_score if analysis_rec else 80.0,
        score_breakdown=ScoreBreakdown(**score_dict),
        detected_domain=analysis_rec.detected_domain if analysis_rec and analysis_rec.detected_domain else "General Professional",
        strengths=analysis_rec.strengths_json if analysis_rec and analysis_rec.strengths_json else [],
        weaknesses=analysis_rec.weaknesses_json if analysis_rec and analysis_rec.weaknesses_json else [],
        extracted_skills=analysis_rec.extracted_skills_json if analysis_rec and analysis_rec.extracted_skills_json else [],
        extracted_projects=[ExtractedProject(**p) if isinstance(p, dict) else p for p in (analysis_rec.extracted_projects_json or [])] if analysis_rec else [],
        extracted_experience=[ExtractedExperience(**e) if isinstance(e, dict) else e for e in (analysis_rec.extracted_experience_json or [])] if analysis_rec else [],
        improvement_suggestions=[ResumeImprovementItem(**i) if isinstance(i, dict) else i for i in (analysis_rec.improvement_suggestions_json or [])] if analysis_rec else [],
        structured_resume=structured_resume,
        keyword_recommendations=keyword_recs,
        job_analysis=None,
        section_audits=section_audits,
        skill_gaps=skill_gaps,
        raw_text=raw_text,
        filename=doc.original_filename,
        file_url=None if is_scratch else f"/api/v1/documents/{doc.id}/file",
        detected_links=[] if is_scratch else detected_links,
        is_scratch=is_scratch,
        created_at=analysis_rec.created_at if analysis_rec else doc.created_at
    )


@router.post("/{document_id}/duplicate", response_model=SavedResumeSummary)
def duplicate_resume(
    document_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Duplicates a saved resume document, all its versions, and analysis results."""
    doc = db.query(Document).filter(Document.id == document_id, Document.user_id == current_user.id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Resume document not found.")

    new_stored_filename = f"copy_{doc.stored_filename}"
    if doc.stored_filename:
        src = os.path.join(settings.STORAGE_DIR, doc.stored_filename)
        dst = os.path.join(settings.STORAGE_DIR, new_stored_filename)
        if os.path.exists(src):
            try:
                import shutil
                shutil.copyfile(src, dst)
            except Exception as e:
                print(f"[WARN] Failed to duplicate disk file: {e}")

    new_doc = Document(
        user_id=current_user.id,
        original_filename=f"Copy of {doc.original_filename}",
        stored_filename=new_stored_filename,
        file_type=doc.file_type,
        file_size_bytes=doc.file_size_bytes,
        sha256_hash=doc.sha256_hash,
        upload_status=doc.upload_status
    )
    db.add(new_doc)
    db.flush()

    # Duplicate versions
    versions = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).all()
    for v in versions:
        new_v = DocumentVersion(
            document_id=new_doc.id,
            version_num=v.version_num,
            raw_text=v.raw_text,
            char_count=v.char_count,
            word_count=v.word_count,
            parsed_metadata_json=v.parsed_metadata_json
        )
        db.add(new_v)

    # Duplicate analysis results
    analyses = db.query(AnalysisResult).filter(AnalysisResult.document_id == doc.id).all()
    for a in analyses:
        new_a = AnalysisResult(
            document_id=new_doc.id,
            student_profile_id=a.student_profile_id,
            resume_quality_score=a.resume_quality_score,
            score_breakdown_json=a.score_breakdown_json,
            detected_domain=a.detected_domain,
            strengths_json=a.strengths_json,
            weaknesses_json=a.weaknesses_json,
            extracted_skills_json=a.extracted_skills_json,
            extracted_projects_json=a.extracted_projects_json,
            extracted_experience_json=a.extracted_experience_json,
            improvement_suggestions_json=a.improvement_suggestions_json
        )
        db.add(new_a)

    db.commit()
    return _doc_to_summary(new_doc, db)


@router.patch("/{document_id}/rename", response_model=SavedResumeSummary)
def rename_resume(
    document_id: str,
    request: ResumeRenameRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Renames a saved resume title."""
    doc = db.query(Document).filter(Document.id == document_id, Document.user_id == current_user.id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Resume document not found.")

    doc.original_filename = request.title.strip() or doc.original_filename

    latest_ver = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).order_by(DocumentVersion.version_num.desc()).first()
    if latest_ver and latest_ver.parsed_metadata_json:
        meta = dict(latest_ver.parsed_metadata_json)
        meta["custom_title"] = request.title.strip()
        latest_ver.parsed_metadata_json = meta

    db.commit()
    return _doc_to_summary(doc, db)


@router.delete("/{document_id}", status_code=status.HTTP_200_OK)
def delete_resume_by_id(
    document_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Deletes a specific resume document by ID."""
    doc = db.query(Document).filter(Document.id == document_id, Document.user_id == current_user.id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Resume document not found.")

    db.query(Application).filter(Application.document_id == doc.id).update(
        {"document_id": None}, synchronize_session=False
    )
    db.query(InterviewSession).filter(InterviewSession.document_id == doc.id).update(
        {"document_id": None}, synchronize_session=False
    )

    if doc.stored_filename:
        try:
            file_path = os.path.join(settings.STORAGE_DIR, doc.stored_filename)
            if os.path.exists(file_path):
                os.remove(file_path)
        except Exception as e:
            print(f"[WARN] Failed to delete stored resume file {doc.stored_filename}: {e}")

    db.delete(doc)

    remaining_docs = db.query(Document).filter(Document.user_id == current_user.id).count()
    if remaining_docs == 0:
        student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
        if student_profile:
            db.query(StudentSkill).filter(
                StudentSkill.student_profile_id == student_profile.id,
                StudentSkill.source == "resume"
            ).delete(synchronize_session=False)
            db.query(AnalysisResult).filter(
                AnalysisResult.student_profile_id == student_profile.id
            ).delete(synchronize_session=False)
            student_profile.target_domain = None

    db.commit()
    return {"message": "Resume deleted successfully."}


# -----------------------------------------------------------------------------
# 2. RESUME VERSIONS ENDPOINTS
# -----------------------------------------------------------------------------

@router.get("/{document_id}/versions", response_model=List[ResumeVersionItemSchema])
def list_resume_versions(
    document_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Lists all saved versions for a resume document."""
    doc = db.query(Document).filter(Document.id == document_id, Document.user_id == current_user.id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Resume document not found.")

    versions = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).order_by(DocumentVersion.version_num.asc()).all()
    analysis = db.query(AnalysisResult).filter(AnalysisResult.document_id == doc.id).first()

    result = []
    for v in versions:
        meta = v.parsed_metadata_json or {}
        struct_dict = meta.get("structured_resume")
        struct_model = None
        if struct_dict and isinstance(struct_dict, dict):
            try:
                struct_model = StructuredResumeData(**struct_dict)
            except Exception:
                pass

        u_at_str = meta.get("updated_at")
        try:
            u_at = datetime.fromisoformat(u_at_str) if u_at_str else v.created_at
        except Exception:
            u_at = v.created_at

        ats_score = float(meta.get("ats_score", analysis.resume_quality_score if analysis else 80.0))

        result.append(ResumeVersionItemSchema(
            version_id=v.id,
            version_num=v.version_num,
            version_name=meta.get("version_name", f"Version {v.version_num}"),
            target_job=meta.get("target_job"),
            created_at=v.created_at,
            updated_at=u_at,
            structured_resume=struct_model,
            resume_quality_score=ats_score
        ))
    return result


@router.post("/{document_id}/versions", response_model=ResumeVersionItemSchema)
def create_resume_version(
    document_id: str,
    request: ResumeVersionCreateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Creates a new version of a resume document without overwriting previous versions."""
    doc = db.query(Document).filter(Document.id == document_id, Document.user_id == current_user.id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Resume document not found.")

    latest_ver = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).order_by(DocumentVersion.version_num.desc()).first()
    next_ver_num = (latest_ver.version_num + 1) if latest_ver else 1
    base_raw_text = latest_ver.raw_text if latest_ver else ""

    now_iso = datetime.now(timezone.utc).isoformat()
    meta = {
        "version_name": request.version_name.strip() or f"Version {next_ver_num}",
        "target_job": request.target_job,
        "structured_resume": request.structured_resume.model_dump(),
        "ats_score": 85.0,
        "updated_at": now_iso
    }

    new_v = DocumentVersion(
        document_id=doc.id,
        version_num=next_ver_num,
        raw_text=base_raw_text,
        char_count=len(base_raw_text),
        word_count=len(base_raw_text.split()),
        parsed_metadata_json=meta
    )
    db.add(new_v)
    db.commit()
    db.refresh(new_v)

    return ResumeVersionItemSchema(
        version_id=new_v.id,
        version_num=new_v.version_num,
        version_name=meta["version_name"],
        target_job=meta["target_job"],
        created_at=new_v.created_at,
        updated_at=datetime.fromisoformat(now_iso),
        structured_resume=request.structured_resume,
        resume_quality_score=meta["ats_score"]
    )


@router.put("/{document_id}/versions/{version_id}", response_model=ResumeVersionItemSchema)
def update_resume_version(
    document_id: str,
    version_id: str,
    request: ResumeVersionCreateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Updates an existing resume version with new structured data or target job."""
    doc = db.query(Document).filter(Document.id == document_id, Document.user_id == current_user.id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Resume document not found.")

    v = db.query(DocumentVersion).filter(DocumentVersion.id == version_id, DocumentVersion.document_id == doc.id).first()
    if not v:
        raise HTTPException(status_code=404, detail="Version not found.")

    now_iso = datetime.now(timezone.utc).isoformat()
    meta = dict(v.parsed_metadata_json or {})
    meta["version_name"] = request.version_name.strip() or meta.get("version_name", f"Version {v.version_num}")
    meta["target_job"] = request.target_job
    meta["structured_resume"] = request.structured_resume.model_dump()
    meta["updated_at"] = now_iso

    v.parsed_metadata_json = meta
    db.commit()
    db.refresh(v)

    return ResumeVersionItemSchema(
        version_id=v.id,
        version_num=v.version_num,
        version_name=meta["version_name"],
        target_job=meta["target_job"],
        created_at=v.created_at,
        updated_at=datetime.fromisoformat(now_iso),
        structured_resume=request.structured_resume,
        resume_quality_score=meta.get("ats_score", 85.0)
    )


# -----------------------------------------------------------------------------
# 3. TARGETED AI IMPROVEMENT ENDPOINTS
# -----------------------------------------------------------------------------

@router.post("/generate-bullet-options", response_model=BulletImprovementOptionsResponse)
def generate_bullet_options_endpoint(
    request: BulletImprovementOptionsRequest,
    current_user: User = Depends(get_current_user)
):
    """Generates 3 distinct bullet improvement options with 'Why this is better' and metric advice."""
    result = AIService.generate_bullet_options(
        bullet=request.bullet,
        role_or_project=request.role_or_project,
        target_domain=request.target_domain,
        target_job=request.target_job
    )
    return BulletImprovementOptionsResponse(
        original_bullet=result.get("original_bullet", request.bullet),
        options=[BulletImprovementOption(**opt) for opt in result.get("options", [])],
        missing_metrics_advice=result.get("missing_metrics_advice")
    )


@router.post("/generate-summary-options", response_model=SummaryImprovementOptionsResponse)
def generate_summary_options_endpoint(
    request: SummaryImprovementOptionsRequest,
    current_user: User = Depends(get_current_user)
):
    """Generates ATS-focused, Professional Executive, and Concise summary options."""
    result = AIService.generate_summary_options(
        current_summary=request.current_summary,
        target_domain=request.target_domain,
        skills=request.skills,
        experience_summary=request.experience_summary
    )
    return SummaryImprovementOptionsResponse(
        options=[SummaryImprovementOption(**opt) for opt in result.get("options", [])]
    )


@router.post("/generate-headlines", response_model=HeadlineGenerateResponse)
def generate_headlines_endpoint(
    request: HeadlineGenerateRequest,
    current_user: User = Depends(get_current_user)
):
    """Generates 3 professional headlines derived strictly from candidate domain and skills."""
    result = AIService.generate_headlines(
        name=request.name,
        domain=request.domain,
        skills=request.skills,
        experience_roles=request.experience_roles,
        target_job=request.target_job
    )
    return HeadlineGenerateResponse(**result)


@router.post("/quality-check", response_model=QualityCheckResponse)
def quality_check_endpoint(
    request: QualityCheckRequest,
    current_user: User = Depends(get_current_user)
):
    """Executes actionable resume quality checks (weak verbs, repetition, length, metrics density)."""
    result = AIService.quality_check(
        structured_resume_dict=request.structured_resume.model_dump(),
        target_job=request.target_job_description
    )
    return QualityCheckResponse(**result)


# -------------------------------------------------------------
# 4. JOB-SPECIFIC RESUME TAILORING ENDPOINTS
# -------------------------------------------------------------

@router.post("/tailor-to-job", response_model=JobTailoringAnalysisResponse)
def tailor_resume_to_job_endpoint(
    request: JobTailoringRequest,
    current_user: User = Depends(require_premium_user),
    db: Session = Depends(get_db)
):
    """
    Analyzes target job description against candidate's current authoritative resume.
    Identifies matched requirements with quotes, missing skills (never fabricated),
    semantic hidden matches, and generates a tailored resume version with STAR impact.
    """
    doc = None
    if request.document_id:
        doc = db.query(Document).filter(
            Document.id == request.document_id,
            Document.user_id == current_user.id
        ).first()
    if not doc:
        doc = db.query(Document).filter(
            Document.user_id == current_user.id
        ).order_by(Document.created_at.desc()).first()
    if not doc and not request.structured_resume:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No resume found. Please upload a resume first before tailoring."
        )

    latest_ver = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).order_by(DocumentVersion.version_num.desc()).first() if doc else None
    raw_text = latest_ver.raw_text if latest_ver else ""

    # Determine base structured resume
    if request.structured_resume:
        base_struct_dict = request.structured_resume.model_dump()
    else:
        meta = latest_ver.parsed_metadata_json if latest_ver else {}
        struct_data = meta.get("structured_resume") if isinstance(meta, dict) else None
        if struct_data and isinstance(struct_data, dict):
            base_struct_dict = struct_data
        else:
            base_struct = _build_structured_resume({}, raw_text)
            base_struct_dict = base_struct.model_dump()

    # Execute Job Tailoring AI Engine
    tailoring_result = AIService.tailor_resume_to_job(
        raw_text=raw_text,
        structured_resume_dict=base_struct_dict,
        job_description=request.job_description
    )

    # Persist job analysis history in metadata
    if latest_ver and latest_ver.parsed_metadata_json:
        meta = dict(latest_ver.parsed_metadata_json)
        history = meta.get("job_tailoring_history", [])
        history_item = {
            "id": f"jh-{int(datetime.now(timezone.utc).timestamp())}",
            "document_id": doc.id if doc else "doc-active",
            "job_title": tailoring_result.get("target_job_title", "Target Role"),
            "company_name": tailoring_result.get("company_name"),
            "match_score": tailoring_result.get("overall_match_score", 80.0),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "job_description_snippet": request.job_description[:180] + ("..." if len(request.job_description) > 180 else ""),
            "tailored_version_id": None
        }
        # Keep latest 10 job history items
        meta["job_tailoring_history"] = [history_item] + [h for h in history if h.get("job_title") != history_item["job_title"]][:9]
        latest_ver.parsed_metadata_json = meta
        db.commit()

    return JobTailoringAnalysisResponse(**tailoring_result)


@router.get("/{document_id}/job-history", response_model=List[JobAnalysisHistoryItem])
def get_job_history_endpoint(
    document_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieves previous job description tailoring analyses for a resume document."""
    doc = db.query(Document).filter(
        Document.id == document_id,
        Document.user_id == current_user.id
    ).first()
    if not doc:
        doc = db.query(Document).filter(Document.user_id == current_user.id).order_by(Document.created_at.desc()).first()
    if not doc:
        return []

    latest_ver = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).order_by(DocumentVersion.version_num.desc()).first()
    if not latest_ver or not latest_ver.parsed_metadata_json:
        return []

    history = latest_ver.parsed_metadata_json.get("job_tailoring_history", [])
    results = []
    for h in history:
        try:
            results.append(JobAnalysisHistoryItem(
                id=h.get("id", f"jh-{doc.id}"),
                document_id=doc.id,
                job_title=h.get("job_title", "Target Role"),
                company_name=h.get("company_name"),
                match_score=float(h.get("match_score", 80.0)),
                created_at=datetime.fromisoformat(h.get("created_at", datetime.now(timezone.utc).isoformat())),
                job_description_snippet=h.get("job_description_snippet", ""),
                tailored_version_id=h.get("tailored_version_id")
            ))
        except Exception:
            pass
    return results


@router.post("/{document_id}/save-tailored-version", response_model=ResumeVersionItemSchema)
def save_tailored_version_endpoint(
    document_id: str,
    request: SaveTailoredVersionRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Saves an approved tailored resume as a distinct named version under the base resume document.
    Ensures the original baseline resume remains completely intact.
    """
    doc = db.query(Document).filter(
        Document.id == document_id,
        Document.user_id == current_user.id
    ).first()
    if not doc:
        doc = db.query(Document).filter(Document.user_id == current_user.id).order_by(Document.created_at.desc()).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Resume document not found.")

    latest_ver = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).order_by(DocumentVersion.version_num.desc()).first()
    next_ver_num = (latest_ver.version_num + 1) if latest_ver else 1
    base_raw_text = latest_ver.raw_text if latest_ver else ""

    now_iso = datetime.now(timezone.utc).isoformat()
    clean_v_name = request.version_name.strip() or f"{request.target_job} Tailored"

    meta = {
        "version_name": clean_v_name,
        "target_job": request.target_job,
        "company_name": request.company_name,
        "is_job_tailored": True,
        "job_description_snippet": request.job_description[:200] if request.job_description else None,
        "structured_resume": request.structured_resume.model_dump(),
        "ats_score": request.ats_score or 88.0,
        "updated_at": now_iso
    }

    new_v = DocumentVersion(
        document_id=doc.id,
        version_num=next_ver_num,
        raw_text=base_raw_text,
        char_count=len(base_raw_text),
        word_count=len(base_raw_text.split()),
        parsed_metadata_json=meta
    )
    db.add(new_v)
    db.commit()
    db.refresh(new_v)

    return ResumeVersionItemSchema(
        version_id=new_v.id,
        version_num=new_v.version_num,
        version_name=clean_v_name,
        target_job=request.target_job,
        created_at=new_v.created_at,
        updated_at=datetime.fromisoformat(now_iso),
        structured_resume=request.structured_resume,
        resume_quality_score=meta["ats_score"]
    )


@router.get("/read-and-learn", response_model=ResumeLearningGuideResponse)
async def get_read_and_learn_guide(
    document_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Generates a personalized, truthful, zero-hallucination 'Read & Learn My Resume' guide
    derived directly from the user's currently uploaded / selected resume document.
    """
    # 1. Fetch document and analysis
    if document_id:
        doc = db.query(Document).filter(Document.id == document_id, Document.user_id == current_user.id).first()
    else:
        doc = db.query(Document).filter(Document.user_id == current_user.id).order_by(Document.created_at.desc()).first()

    if not doc:
        raise HTTPException(status_code=404, detail="No resume document found. Please upload a resume first.")

    analysis = db.query(AnalysisResult).filter(AnalysisResult.document_id == doc.id).order_by(AnalysisResult.created_at.desc()).first()
    latest_ver = db.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).order_by(DocumentVersion.version_num.desc()).first()
    raw_text = latest_ver.raw_text if latest_ver else ""

    analysis_data = analysis.parsed_analysis_json if (analysis and analysis.parsed_analysis_json) else {}
    structured_resume = _build_structured_resume(analysis_data, raw_text)
    detected_domain = (analysis and analysis.detected_domain) or analysis_data.get("detected_domain") or "Engineering & Technology"

    # 2. Generate learning guide
    guide = ResumeLearningService.generate_learning_guide(
        structured_resume=structured_resume,
        detected_domain=detected_domain,
        raw_text=raw_text
    )

    return guide


def _structured_resume_to_plaintext(struct: StructuredResumeData) -> str:
    lines = []
    p = struct.personal_info
    if p.full_name:
        lines.append(p.full_name)
    contact = []
    if p.email:
        contact.append(p.email)
    if p.phone:
        contact.append(p.phone)
    if p.location:
        contact.append(p.location)
    if p.linkedin:
        contact.append(f"LinkedIn: {p.linkedin}")
    if p.github:
        contact.append(f"GitHub: {p.github}")
    if p.portfolio:
        contact.append(f"Portfolio: {p.portfolio}")
    if contact:
        lines.append(" | ".join(contact))
    
    headline = p.headline or p.title or struct.headline or struct.title
    if headline:
        lines.append(f"\nProfessional Headline: {headline}")
    
    summary = struct.summary or p.summary
    if summary:
        lines.append(f"\nPROFESSIONAL SUMMARY\n{summary}")
    
    if struct.skills:
        lines.append(f"\nTECHNICAL SKILLS\n{', '.join(struct.skills)}")
    
    if struct.experience:
        lines.append("\nPROFESSIONAL EXPERIENCE & INTERNSHIPS")
        for exp in struct.experience:
            header = f"{exp.role} - {exp.company}"
            if exp.duration:
                header += f" ({exp.duration})"
            if exp.location:
                header += f", {exp.location}"
            lines.append(header)
            for b in exp.bullets:
                lines.append(f"• {b}")
    
    if struct.projects:
        lines.append("\nTECHNICAL PROJECTS")
        for proj in struct.projects:
            header = proj.title
            if proj.role_or_tech:
                header += f" | {proj.role_or_tech}"
            lines.append(header)
            if proj.description:
                lines.append(proj.description)
            for b in proj.bullets:
                lines.append(f"• {b}")
    
    if struct.education:
        lines.append("\nEDUCATION")
        for edu in struct.education:
            header = f"{edu.degree} - {edu.institution}"
            if edu.field_of_study:
                header += f" ({edu.field_of_study})"
            if edu.start_year or edu.end_year:
                header += f" | {edu.start_year or ''} - {edu.end_year or ''}"
            if edu.grade_or_cgpa:
                header += f" | GPA: {edu.grade_or_cgpa}"
            lines.append(header)
            
    if struct.certifications:
        lines.append("\nCERTIFICATIONS")
        for cert in struct.certifications:
            c_str = cert.name
            if cert.issuer:
                c_str += f" - {cert.issuer}"
            if cert.year:
                c_str += f" ({cert.year})"
            lines.append(f"• {c_str}")
            
    return "\n".join(lines)


@router.post("/create-scratch", response_model=AnalysisResultResponse, status_code=status.HTTP_201_CREATED)
async def create_resume_from_scratch(
    request_data: CreateResumeScratchRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Creates a new resume directly from scratch using structured data (summary, skills, projects, etc.),
    generates full AI analysis, and saves as the student's active resume.
    """
    try:
        student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
        if not student_profile:
            student_profile = StudentProfile(user_id=current_user.id)
            db.add(student_profile)
            db.commit()
            db.refresh(student_profile)

        raw_text = _structured_resume_to_plaintext(request_data.structured_resume)
        if not raw_text.strip():
            raw_text = "Student Resume Profile\nTechnical Skills: Python, JavaScript, Web Development\nEducation: Bachelor of Technology"

        filename = request_data.title or f"{request_data.structured_resume.personal_info.full_name or 'My'}_Resume.pdf"
        content_bytes = raw_text.encode("utf-8")
        
        stored_filename, sha256_hash, file_size = DocumentService.save_file_securely(
            content_bytes, filename, "txt"
        )

        detected_links = []
        p = request_data.structured_resume.personal_info
        if p.linkedin:
            detected_links.append(ResumeLinkItem(label="LinkedIn", url=_ensure_scheme(p.linkedin) or p.linkedin, type="linkedin"))
        if p.github:
            detected_links.append(ResumeLinkItem(label="GitHub", url=_ensure_scheme(p.github) or p.github, type="github"))
        if p.portfolio:
            detected_links.append(ResumeLinkItem(label="Portfolio", url=_ensure_scheme(p.portfolio) or p.portfolio, type="portfolio"))
        if getattr(p, "leetcode", None):
            detected_links.append(ResumeLinkItem(label="LeetCode", url=_ensure_scheme(p.leetcode) or p.leetcode, type="leetcode"))
        if getattr(p, "codeforces", None):
            detected_links.append(ResumeLinkItem(label="Codeforces", url=_ensure_scheme(p.codeforces) or p.codeforces, type="codeforces"))

        for proj in request_data.structured_resume.projects:
            if proj.url:
                detected_links.append(ResumeLinkItem(label=f"{proj.title} Demo", url=_ensure_scheme(proj.url) or proj.url, type="demo"))
            if proj.code_url:
                detected_links.append(ResumeLinkItem(label=f"{proj.title} Repo", url=_ensure_scheme(proj.code_url) or proj.code_url, type="repo"))

        analysis_data = AIService.analyze_resume(raw_text, target_job_desc=request_data.target_job_description)
        analysis_data["structured_resume"] = request_data.structured_resume.model_dump()
        structured_resume = request_data.structured_resume

        # Save Document record
        doc = Document(
            user_id=current_user.id,
            original_filename=filename,
            stored_filename=stored_filename,
            file_type="scratch",
            file_size_bytes=file_size,
            sha256_hash=sha256_hash,
            upload_status="analyzed"
        )
        db.add(doc)
        db.flush()

        doc_version = DocumentVersion(
            document_id=doc.id,
            version_num=1,
            raw_text=raw_text,
            char_count=len(raw_text),
            word_count=len(raw_text.split()),
            parsed_metadata_json={
                "filename": filename,
                "size": file_size,
                "version_name": "Created from Scratch",
                "source": "scratch",
                "is_scratch": True,
                "target_job": request_data.target_job_description or "General",
                "structured_resume": structured_resume.model_dump(),
                "ats_score": analysis_data.get("resume_quality_score", 85.0),
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
        )
        db.add(doc_version)

        score_dict = analysis_data.get("score_breakdown", {})
        if isinstance(score_dict, dict):
            score_model = ScoreBreakdown(**score_dict)
        else:
            score_model = score_dict

        # Determine authentic domain from analysis, education field of study, or resume headline
        scratch_detected_domain = analysis_data.get("detected_domain")
        if not scratch_detected_domain or scratch_detected_domain in ("General Professional", "Computer Science & Engineering"):
            for edu in request_data.structured_resume.education:
                if edu.field_of_study and edu.field_of_study.strip():
                    scratch_detected_domain = edu.field_of_study.strip()
                    break
                elif edu.degree and edu.degree.strip():
                    scratch_detected_domain = edu.degree.strip()
                    break
        if not scratch_detected_domain or scratch_detected_domain in ("General Professional", "Computer Science & Engineering"):
            hl = (request_data.structured_resume.personal_info.headline or 
                  request_data.structured_resume.headline or 
                  getattr(request_data.structured_resume.personal_info, "title", None))
            if hl and hl.strip():
                scratch_detected_domain = hl.strip()
        if not scratch_detected_domain:
            scratch_detected_domain = "General Professional"

        analysis_rec = AnalysisResult(
            document_id=doc.id,
            student_profile_id=student_profile.id,
            resume_quality_score=analysis_data.get("resume_quality_score", 85.0),
            score_breakdown_json=score_model.model_dump() if hasattr(score_model, "model_dump") else score_model,
            detected_domain=scratch_detected_domain,
            strengths_json=analysis_data.get("strengths", ["Strong structured sections", "Verifiable project descriptions"]),
            weaknesses_json=analysis_data.get("weaknesses", []),
            extracted_skills_json=request_data.structured_resume.skills or analysis_data.get("extracted_skills", []),
            extracted_projects_json=[
                {
                    "title": p.title,
                    "role_or_tech": p.role_or_tech,
                    "description": p.description or "",
                    "key_technologies": p.technologies,
                    "url": _ensure_scheme(p.url),
                    "code_url": _ensure_scheme(p.code_url)
                }
                for p in request_data.structured_resume.projects
            ],
            extracted_experience_json=[
                {"company_or_org": e.company, "role": e.role, "duration": e.duration, "highlights": e.bullets}
                for e in request_data.structured_resume.experience
            ],
            improvement_suggestions_json=analysis_data.get("improvement_suggestions", [])
        )
        db.add(analysis_rec)

        # Reset old resume-derived skills
        db.query(StudentSkill).filter(
            StudentSkill.student_profile_id == student_profile.id,
            StudentSkill.source == "resume"
        ).delete(synchronize_session=False)

        # Sync skills to StudentProfile
        for skill_item in (request_data.structured_resume.skills or []):
            norm_skill = TaxonomyService.normalize_skill_name(db, skill_item, domain_hint=scratch_detected_domain)
            if norm_skill:
                existing_st_skill = db.query(StudentSkill).filter(
                    StudentSkill.student_profile_id == student_profile.id,
                    StudentSkill.skill_id == norm_skill.id
                ).first()
                if not existing_st_skill:
                    db.add(StudentSkill(
                        student_profile_id=student_profile.id,
                        skill_id=norm_skill.id,
                        proficiency="intermediate",
                        source="resume",
                        evidence_snippet=f"Added from scratch builder"
                    ))

        # Update detected domain and department on student profile
        student_profile.target_domain = scratch_detected_domain
        if scratch_detected_domain and scratch_detected_domain != "General Professional":
            student_profile.department = scratch_detected_domain
        current_pct = student_profile.profile_completion_pct if student_profile.profile_completion_pct is not None else 30
        student_profile.profile_completion_pct = max(current_pct, 90)

        db.commit()
        db.refresh(analysis_rec)

        keyword_recs = [
            KeywordRecommendationItem(**k) if isinstance(k, dict) else k
            for k in analysis_data.get("keyword_recommendations", [])
        ]
        job_analysis = (
            JobDescriptionAnalysis(**analysis_data["job_analysis"])
            if isinstance(analysis_data.get("job_analysis"), dict)
            else analysis_data.get("job_analysis")
        )
        section_audits = (
            ResumeSectionAudits(**analysis_data["section_audits"])
            if isinstance(analysis_data.get("section_audits"), dict)
            else analysis_data.get("section_audits")
        )

        return AnalysisResultResponse(
            id=analysis_rec.id,
            document_id=doc.id,
            student_profile_id=student_profile.id,
            resume_quality_score=analysis_rec.resume_quality_score,
            score_breakdown=score_model if hasattr(score_model, "structure") else ScoreBreakdown(**score_model),
            detected_domain=analysis_rec.detected_domain,
            strengths=analysis_rec.strengths_json or [],
            weaknesses=analysis_rec.weaknesses_json or [],
            extracted_skills=analysis_rec.extracted_skills_json or [],
            extracted_projects=[ExtractedProject(**p) for p in analysis_rec.extracted_projects_json or []],
            extracted_experience=[ExtractedExperience(**e) for e in analysis_rec.extracted_experience_json or []],
            improvement_suggestions=[ResumeImprovementItem(**i) for i in analysis_rec.improvement_suggestions_json or []],
            structured_resume=structured_resume,
            keyword_recommendations=keyword_recs,
            job_analysis=job_analysis,
            section_audits=section_audits,
            skill_gaps=[SkillGapAuditItem(**sg) if isinstance(sg, dict) else sg for sg in (analysis_data.get("skill_gaps") or [])],
            raw_text=raw_text,
            filename=filename,
            file_url=None,
            detected_links=[],
            is_scratch=True,
            created_at=analysis_rec.created_at
        )
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        print(f"[ERROR] Failed to create resume from scratch: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create resume from scratch: {str(e)}"
        )


@router.put("/active/sync-resume", response_model=AnalysisResultResponse)
async def sync_active_resume(
    request_data: SyncResumeRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Synchronizes the candidate's active structured resume changes (skills addition/removal,
    experience updates, project edits) to the database in real time.
    Guarantees that AnalysisResult, DocumentVersion, and StudentSkill records are 100% synchronized
    so that Job & Internship matching engines reflect genuine additions and removals immediately.
    """
    try:
        student_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
        if not student_profile:
            student_profile = StudentProfile(user_id=current_user.id)
            db.add(student_profile)
            db.commit()
            db.refresh(student_profile)

        analysis_rec = db.query(AnalysisResult).filter(
            AnalysisResult.student_profile_id == student_profile.id
        ).order_by(AnalysisResult.created_at.desc()).first()

        clean_skills = [
            s.strip() for s in (request_data.structured_resume.skills or [])
            if isinstance(s, str) and s.strip()
        ]

        # If no analysis_rec exists yet, fallback to create_resume_from_scratch logic
        if not analysis_rec:
            candidate_name = (request_data.structured_resume.personal_info.full_name or 'My').strip().replace(' ', '_')
            scratch_req = CreateResumeScratchRequest(
                title=f"{candidate_name}_Resume.pdf",
                structured_resume=request_data.structured_resume,
                target_job_description=request_data.target_job_description
            )
            return await create_resume_from_scratch(scratch_req, current_user=current_user, db=db)

        # 1. Update AnalysisResult fields
        analysis_rec.extracted_skills_json = clean_skills
        analysis_rec.extracted_projects_json = [
            {
                "title": p.title,
                "role_or_tech": p.role_or_tech,
                "description": p.description or "",
                "key_technologies": p.technologies,
                "url": _ensure_scheme(p.url),
                "code_url": _ensure_scheme(p.code_url)
            }
            for p in request_data.structured_resume.projects
        ]
        analysis_rec.extracted_experience_json = [
            {
                "company_or_org": e.company,
                "role": e.role,
                "duration": e.duration,
                "highlights": e.bullets
            }
            for e in request_data.structured_resume.experience
        ]

        # 2. Update DocumentVersion parsed metadata
        doc = db.query(Document).filter(Document.id == analysis_rec.document_id).first()
        doc_ver = None
        if doc:
            doc_ver = db.query(DocumentVersion).filter(
                DocumentVersion.document_id == doc.id
            ).order_by(DocumentVersion.version_num.desc()).first()

        now_iso = datetime.now(timezone.utc).isoformat()
        if doc_ver:
            meta = dict(doc_ver.parsed_metadata_json or {})
            meta["structured_resume"] = request_data.structured_resume.model_dump()
            meta["updated_at"] = now_iso
            doc_ver.parsed_metadata_json = meta
            try:
                raw_text = _structured_resume_to_plaintext(request_data.structured_resume)
                if raw_text.strip():
                    doc_ver.raw_text = raw_text
                    doc_ver.word_count = len(raw_text.split())
                    doc_ver.char_count = len(raw_text)
            except Exception as e:
                print(f"[WARN] Error converting structured resume to plaintext: {e}")

        # 3. Synchronize StudentSkill table:
        # First, purge resume-derived skills to remove any deleted skills (e.g. "Content Creation")
        db.query(StudentSkill).filter(
            StudentSkill.student_profile_id == student_profile.id,
            StudentSkill.source == "resume"
        ).delete(synchronize_session=False)

        # Add active resume skills into StudentSkill
        for skill_item in clean_skills:
            norm_skill = TaxonomyService.normalize_skill_name(
                db, skill_item, domain_hint=analysis_rec.detected_domain or student_profile.target_domain
            )
            if norm_skill:
                existing = db.query(StudentSkill).filter(
                    StudentSkill.student_profile_id == student_profile.id,
                    StudentSkill.skill_id == norm_skill.id
                ).first()
                if not existing:
                    db.add(StudentSkill(
                        student_profile_id=student_profile.id,
                        skill_id=norm_skill.id,
                        proficiency="intermediate",
                        source="resume",
                        evidence_snippet="Synchronized from active resume"
                    ))
            else:
                try:
                    from app.schemas.taxonomy import SkillCreate
                    new_skill = TaxonomyService.create_skill(
                        db,
                        SkillCreate(
                            canonical_name=skill_item,
                            domain=analysis_rec.detected_domain or student_profile.target_domain or "General",
                            description=f"Skill extracted from candidate resume: {skill_item}"
                        )
                    )
                    db.add(StudentSkill(
                        student_profile_id=student_profile.id,
                        skill_id=new_skill.id,
                        proficiency="intermediate",
                        source="resume",
                        evidence_snippet="Synchronized from active resume"
                    ))
                except Exception as e:
                    print(f"[WARN] Could not create skill taxonomy for {skill_item}: {e}")

        # Synchronize student profile domain and department
        if analysis_rec.detected_domain and analysis_rec.detected_domain != "General Professional":
            student_profile.target_domain = analysis_rec.detected_domain
            student_profile.department = analysis_rec.detected_domain

        db.commit()
        db.refresh(analysis_rec)

        return get_latest_analysis(current_user=current_user, db=db)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        print(f"[ERROR] Failed to sync active resume: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to sync active resume: {str(e)}"
        )


class ExportPdfRequest(BaseModel):
    html_content: str
    filename: Optional[str] = "Resume_Document.pdf"


@router.post("/export-pdf")
def export_resume_pdf(request_data: ExportPdfRequest):
    """
    Renders high-fidelity HTML resume into a crisp, vector A4 PDF using Chromium/Edge headless.
    Guarantees 100% genuine vector /Link annotations for LinkedIn, Gmail/Email, GitHub, LeetCode,
    and phone numbers with zero Windows printer driver degradation.
    """
    import subprocess
    import tempfile
    import shutil
    from fastapi.responses import Response

    if not request_data.html_content or not request_data.html_content.strip():
        raise HTTPException(status_code=400, detail="html_content is required.")

    possible_paths = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable",
        "/usr/bin/chromium",
        "/usr/bin/chromium-browser",
        shutil.which("msedge"),
        shutil.which("chrome"),
        shutil.which("google-chrome"),
        shutil.which("chromium"),
        shutil.which("chromium-browser"),
    ]
    browser_path = None
    for p in possible_paths:
        if p and os.path.exists(p):
            browser_path = p
            break

    if not browser_path:
        raise HTTPException(status_code=500, detail="Chromium browser not found on host server for PDF rendering.")

    temp_dir = tempfile.mkdtemp(prefix="employai_pdf_")
    html_file = os.path.join(temp_dir, "resume.html")
    pdf_file = os.path.join(temp_dir, "resume.pdf")
    user_data_dir = os.path.join(temp_dir, "edge_profile")

    try:
        with open(html_file, "w", encoding="utf-8") as f:
            f.write(request_data.html_content)

        cmd = [
            browser_path,
            "--headless=new",
            "--disable-gpu",
            "--no-sandbox",
            "--disable-extensions",
            "--run-all-compositor-stages-before-draw",
            f"--user-data-dir={user_data_dir}",
            "--no-pdf-header-footer",
            f"--print-to-pdf={pdf_file}",
            html_file
        ]

        proc = subprocess.run(cmd, capture_output=True, timeout=20)
        if proc.returncode != 0 or not os.path.exists(pdf_file):
            err_msg = proc.stderr.decode("utf-8", errors="ignore")
            raise HTTPException(status_code=500, detail=f"Headless browser PDF export failed: {err_msg}")

        with open(pdf_file, "rb") as f:
            pdf_bytes = f.read()

        out_filename = request_data.filename or "Resume_Document.pdf"
        if not out_filename.lower().endswith(".pdf"):
            out_filename += ".pdf"

        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f'attachment; filename="{out_filename}"',
                "Content-Type": "application/pdf"
            }
        )
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


