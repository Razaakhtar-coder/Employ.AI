import os
import re
import html
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting
from app.core.config import settings


class WellfoundProvider(JobProviderAdapter):
    """
    Wellfound (formerly AngelList Talent) Startup Ecosystem Adapter.
    Connects candidates directly with vetted tech startups and scaleups.
    Features: Direct pitch to founders/CTOs, equity transparency, verified openings.
    """

    JOBS_PAGE_URL = "https://wellfound.com/jobs"

    def __init__(self):
        self.api_key = settings.WELLFOUND_API_KEY or os.getenv("WELLFOUND_API_KEY", "")

    @property
    def name(self) -> str:
        return "Wellfound"

    @property
    def is_enabled(self) -> bool:
        return True

    @property
    def crowd_level(self) -> str:
        return "low"

    @property
    def description(self) -> str:
        return "The #1 startup job platform (formerly AngelList Talent) with direct founder messaging and equity transparency."

    def _clean_text(self, text: str) -> str:
        if not text:
            return ""
        clean = re.sub(r"<[^>]+>", " ", text)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        postings: List[RawJobPosting] = []
        seen_urls = set()

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        try:
            async with httpx.AsyncClient(timeout=8.0, follow_redirects=True) as client:
                resp = await client.get(self.JOBS_PAGE_URL, headers=headers)
                if resp.status_code == 200:
                    matches = list(re.finditer(r'<a[^>]+href="(/jobs/(\d+-[^"]+))"[^>]*>([^<]+)</a>', resp.text))
                    for m in matches:
                        full_path = m.group(1)
                        slug = m.group(2)
                        raw_title = html.unescape(m.group(3).strip())
                        job_url = f"https://wellfound.com{full_path}"

                        if job_url in seen_urls:
                            continue
                        seen_urls.add(job_url)

                        pos = m.start()
                        end_pos = m.end()
                        sub_before = resp.text[max(0, pos - 500): pos]
                        sub_after = resp.text[end_pos: min(len(resp.text), end_pos + 600)]

                        # 1. Company extraction with multi-stage verification
                        company = None
                        comp_logo = re.search(r'alt="([^"]+?)\s+company logo"', sub_before, re.IGNORECASE)
                        if comp_logo:
                            company = comp_logo.group(1).strip()
                        
                        if not company:
                            span_comp = re.search(r'<span>([^<]+?)(?:<!-- -->)?\s*[•·]', sub_after)
                            if span_comp:
                                company = span_comp.group(1).strip()

                        if not company:
                            comp_link = re.search(r'/company/([a-zA-Z0-9_-]+)', sub_before)
                            if comp_link:
                                company = comp_link.group(1).replace("-", " ").title()
                                company = re.sub(r'\s+\d+$', '', company).strip()

                        if not company or company.lower() in ["wellfound venture startup", "none", "startup"]:
                            company = "Wellfound Tech Startup"

                        # 2. Location & Salary extraction
                        loc = "Remote"
                        loc_match = re.search(r'<span class="text-gray-700">([^<]+)</span>', sub_after)
                        if loc_match:
                            loc_text = re.sub(r'<!-- -->', '', loc_match.group(1)).strip()
                            parts = [p.strip() for p in loc_text.split('•') if p.strip()]
                            if parts:
                                loc = parts[0]

                        salary = "$110k - $175k • Equity"
                        sal_match = re.search(r'\$\d+k(?:\s*-\s*\$\d+k)?', sub_after)
                        if sal_match:
                            salary = f"{sal_match.group(0)} • Equity Included"

                        # Title & type
                        title = self._clean_text(raw_title)
                        lower_title = (title + " " + company).lower()
                        is_intern = "intern" in lower_title or "trainee" in lower_title
                        j_type = "internship" if is_intern else "full-time"

                        if job_type and job_type.lower() != "all" and j_type != job_type.lower():
                            continue

                        combined = f"{title} {company} {loc}".lower()
                        if query and query.lower() not in combined:
                            continue

                        # Extract skills
                        detected_skills = []
                        for sk in ["Python", "TypeScript", "React", "Rust", "Go", "Docker", "Kubernetes", "AWS", "Machine Learning", "FastAPI", "DevOps", "Node.js", "PostgreSQL", "C++"]:
                            if sk.lower() in combined or sk.lower() in title.lower():
                                detected_skills.append(sk)
                        if not detected_skills:
                            detected_skills = ["Software Engineering", "Product Mindset"]

                        postings.append(RawJobPosting(
                            source_id=f"wellfound-{slug}",
                            source="Wellfound",
                            title=title,
                            company=company,
                            location=loc,
                            remote="remote" in loc.lower() or "remote" in title.lower(),
                            job_type=j_type,
                            experience_level="intern" if is_intern else "entry",
                            domain="Computer Science",
                            description=f"Verified opening for {title} at {company} on Wellfound (AngelList Talent). Direct founder connection & equity potential.",
                            required_skills=detected_skills,
                            apply_url=job_url,
                            salary_range=salary,
                            posted_date="Just now (Live Wellfound Feed)"
                        ))
        except Exception as e:
            print(f"[WARN] Live Wellfound jobs feed fetch notice: {e}")

        return postings
