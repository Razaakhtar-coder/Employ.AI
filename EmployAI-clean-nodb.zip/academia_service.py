from typing import List, Dict, Any
from collections import Counter
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models.profile import StudentProfile, AcademicProfile
from app.models.matching import SkillGap, Role, RoleSkill
from app.models.opportunity import Application, Opportunity, OpportunitySkill
from app.models.taxonomy import Skill, StudentSkill
from app.schemas.analytics import AcademiaDashboardStats, DepartmentReadinessMetric, SkillGapAggregate


class AcademiaService:
    @staticmethod
    def get_dashboard_stats(db: Session, academic_profile: AcademicProfile) -> AcademiaDashboardStats:
        """Compute aggregated analytics dynamically from stored database records for TPO/Academia."""
        students = db.query(StudentProfile).all()
        total_students = len(students)

        # 1. Group students by department
        departments: Dict[str, List[StudentProfile]] = {}
        for s in students:
            dept = s.department or "General Engineering"
            departments.setdefault(dept, []).append(s)

        department_metrics: List[DepartmentReadinessMetric] = []
        all_readiness_scores = []

        for dept_name, s_list in departments.items():
            avg_cgpa = (sum(s.cgpa for s in s_list if s.cgpa is not None) / len(s_list)) if s_list else 0.0
            
            s_ids = [s.id for s in s_list]
            gaps = db.query(SkillGap).filter(SkillGap.student_profile_id.in_(s_ids)).all() if s_ids else []
            avg_readiness = (sum(g.match_percentage for g in gaps) / len(gaps)) if gaps else (80.0 if s_list else 0.0)
            all_readiness_scores.append(avg_readiness)

            # Count shortlisted / placed applications
            u_ids = [s.user_id for s in s_list]
            placed_count = db.query(Application).filter(
                Application.user_id.in_(u_ids),
                Application.status.in_(["shortlisted", "interview", "offered", "accepted"])
            ).count() if u_ids else 0

            # Dynamic missing skill gaps for students in this department
            dept_missing_counter = Counter()
            for g in gaps:
                if g.missing_skills_json:
                    for item in g.missing_skills_json:
                        s_name = item.get("skill_name")
                        if s_name:
                            dept_missing_counter[s_name] += 1

            if not dept_missing_counter and s_ids:
                # Calculate from RoleSkills matching department affinity
                matching_roles = db.query(Role).filter(Role.department_affinity.ilike(f"%{dept_name}%")).all()
                if not matching_roles:
                    matching_roles = db.query(Role).all()
                st_skills = db.query(StudentSkill.skill_id).filter(StudentSkill.student_profile_id.in_(s_ids)).all()
                known_skill_ids = {row[0] for row in st_skills}
                for r in matching_roles:
                    for rs in r.role_skills:
                        if rs.is_required and rs.skill_id not in known_skill_ids:
                            sk = db.query(Skill).filter(Skill.id == rs.skill_id).first()
                            if sk:
                                dept_missing_counter[sk.canonical_name] += len(s_list)

            top_gaps = [name for name, _ in dept_missing_counter.most_common(3)]
            if not top_gaps:
                top_gaps = ["Domain Standards", "Advanced Tooling"]

            department_metrics.append(DepartmentReadinessMetric(
                department=dept_name,
                total_students=len(s_list),
                average_cgpa=round(avg_cgpa, 2),
                average_readiness_score=round(avg_readiness, 1),
                top_skill_gaps=top_gaps,
                placed_or_shortlisted_count=placed_count
            ))

        overall_readiness = (sum(all_readiness_scores) / len(all_readiness_scores)) if all_readiness_scores else 0.0

        # 2. Dynamic critical department skill gaps
        critical_gaps_counter = Counter()
        skill_domain_map = {}
        for g in db.query(SkillGap).all():
            if g.missing_skills_json:
                for item in g.missing_skills_json:
                    name = item.get("skill_name")
                    dom = item.get("domain", "Engineering")
                    if name:
                        critical_gaps_counter[name] += 1
                        skill_domain_map[name] = dom

        critical_gaps: List[SkillGapAggregate] = []
        if critical_gaps_counter:
            for s_name, count in critical_gaps_counter.most_common(4):
                pct = round((count / max(1, total_students)) * 100.0, 1)
                critical_gaps.append(SkillGapAggregate(
                    skill_name=s_name,
                    domain=skill_domain_map.get(s_name, "General"),
                    students_lacking_count=count,
                    percentage_lacking=pct,
                    importance="Critical" if pct >= 50 else "High"
                ))
        else:
            # Fallback based on universal taxonomy required role skills
            top_role_skills = db.query(Skill.canonical_name, Skill.domain, func.count(RoleSkill.id)).join(
                RoleSkill, RoleSkill.skill_id == Skill.id
            ).filter(RoleSkill.is_required == True).group_by(Skill.canonical_name, Skill.domain).order_by(
                func.count(RoleSkill.id).desc()
            ).limit(4).all()
            for sk_name, dom, _ in top_role_skills:
                critical_gaps.append(SkillGapAggregate(
                    skill_name=sk_name,
                    domain=dom,
                    students_lacking_count=0,
                    percentage_lacking=0.0,
                    importance="High"
                ))

        # 3. Dynamic top demanded skills from live OpportunitySkills & RoleSkills
        demand_counts = Counter()
        demand_domains = {}
        for os in db.query(OpportunitySkill).all():
            sk = db.query(Skill).filter(Skill.id == os.skill_id).first()
            if sk:
                demand_counts[sk.canonical_name] += 2 if os.is_required else 1
                demand_domains[sk.canonical_name] = sk.domain

        for rs in db.query(RoleSkill).all():
            sk = db.query(Skill).filter(Skill.id == rs.skill_id).first()
            if sk:
                demand_counts[sk.canonical_name] += 2 if rs.is_required else 1
                demand_domains[sk.canonical_name] = sk.domain

        top_demanded = []
        max_demand = max(demand_counts.values()) if demand_counts else 1
        for s_name, count in demand_counts.most_common(4):
            demand_index = int((count / max_demand) * 100)
            top_demanded.append({
                "skill": s_name,
                "domain": demand_domains.get(s_name, "Engineering"),
                "demand_index": max(60, demand_index)
            })

        if not top_demanded:
            top_skills = db.query(Skill).limit(4).all()
            for s in top_skills:
                top_demanded.append({
                    "skill": s.canonical_name,
                    "domain": s.domain,
                    "demand_index": 85
                })

        return AcademiaDashboardStats(
            institution_name=academic_profile.institution_name or "Academic Institution",
            total_registered_students=total_students,
            active_departments_count=len(departments),
            overall_readiness_index=round(overall_readiness, 1),
            top_demanded_skills=top_demanded,
            critical_department_skill_gaps=critical_gaps,
            department_metrics=department_metrics
        )
