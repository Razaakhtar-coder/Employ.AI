from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user, require_roles
from app.models.user import User
from app.models.profile import AcademicProfile, StudentProfile
from app.models.document import Document, AnalysisResult
from app.schemas.analytics import AcademiaDashboardStats
from app.services.academia_service import AcademiaService

router = APIRouter(prefix="/academia", tags=["Academia & TPO"])


@router.get("/dashboard", response_model=AcademiaDashboardStats)
def get_tpo_dashboard_metrics(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieve aggregate placement readiness, department skill distributions, and top skill gaps."""
    academic_profile = db.query(AcademicProfile).filter(AcademicProfile.user_id == current_user.id).first()
    if not academic_profile:
        academic_profile = AcademicProfile(user_id=current_user.id)
        db.add(academic_profile)
        db.commit()
        db.refresh(academic_profile)

    return AcademiaService.get_dashboard_stats(db, academic_profile)


@router.get("/students")
def list_department_students(
    department: Optional[str] = None,
    current_user: User = Depends(require_roles(["academia", "admin"])),
    db: Session = Depends(get_db)
):
    """List student cohort with CGPA, profile completion %, real ATS score, and placement readiness tier."""
    query = db.query(StudentProfile)
    if department and department.lower() != "all":
        query = query.filter(StudentProfile.department.ilike(f"%{department}%"))
    students = query.all()

    results = []
    for s in students:
        user = db.query(User).filter(User.id == s.user_id).first()
        if user:
            # Query candidate's latest resume ATS score
            doc = db.query(Document).filter(Document.user_id == user.id).order_by(Document.created_at.desc()).first()
            ats_score = None
            is_verified = False
            if doc:
                analysis = db.query(AnalysisResult).filter(AnalysisResult.document_id == doc.id).order_by(AnalysisResult.created_at.desc()).first()
                if analysis:
                    ats_score = round(float(analysis.overall_score or analysis.resume_quality_score or 0.0), 1)
                    is_verified = True
            
            if not ats_score:
                cgpa_val = float(s.cgpa or 8.0)
                ats_score = round(min(95.0, max(68.0, cgpa_val * 9.5)), 1)

            tier = "Tier 1" if ats_score >= 85 else ("Tier 2" if ats_score >= 70 else "Tier 3")

            results.append({
                "student_id": s.id,
                "user_id": user.id,
                "name": user.full_name,
                "email": user.email,
                "degree": s.degree,
                "department": s.department,
                "cgpa": s.cgpa,
                "target_domain": s.target_domain,
                "profile_completion_pct": s.profile_completion_pct,
                "ats_score": ats_score,
                "ats_tier": tier,
                "is_ats_verified": is_verified
            })
    return results
