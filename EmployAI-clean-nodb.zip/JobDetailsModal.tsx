import React, { useEffect, useState } from 'react';
import type { JobPosting } from '../types';
import { 
  X, Briefcase, MapPin, Calendar, 
  Target, CheckCircle2, ExternalLink, 
  Send, Sparkles, BookOpen, MessageSquare, Check, 
  ShieldCheck, Share2, Award, Zap
} from 'lucide-react';

interface JobDetailsModalProps {
  job: JobPosting | null;
  isOpen: boolean;
  onClose: () => void;
  onApplyDirect: (job: JobPosting) => void;
  resolveValidApplyUrl: (job: JobPosting) => string;
  hasApplied: boolean;
  isApplying: boolean;
  matchScore: number | null;
  matchedSkillsSet: Set<string>;
  onNavigate?: (tab: string) => void;
  getSourceBadgeColor: (source: string) => { bg: string; text: string; border: string };
}

export const JobDetailsModal: React.FC<JobDetailsModalProps> = ({
  job,
  isOpen,
  onClose,
  onApplyDirect,
  resolveValidApplyUrl,
  hasApplied,
  isApplying,
  matchScore,
  matchedSkillsSet,
  onNavigate,
  getSourceBadgeColor
}) => {
  const [copiedLink, setCopiedLink] = useState(false);

  // Close on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Lock body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen || !job) return null;

  const targetUrl = resolveValidApplyUrl(job);
  const srcStyle = getSourceBadgeColor(job.source);

  const hasMatch = matchScore !== null;
  const isHighFit = hasMatch && matchScore >= 85;
  const isGoodFit = hasMatch && matchScore >= 65 && matchScore < 85;

  const matchColor = isHighFit 
    ? 'var(--accent-emerald, #10b981)' 
    : isGoodFit 
      ? 'var(--accent-cyan, #06b6d4)' 
      : hasMatch 
        ? 'var(--accent-amber, #f59e0b)' 
        : 'var(--text-muted)';

  const matchBg = isHighFit 
    ? 'rgba(16, 185, 129, 0.12)' 
    : isGoodFit 
      ? 'rgba(6, 182, 212, 0.12)' 
      : hasMatch 
        ? 'rgba(245, 158, 11, 0.12)' 
        : 'rgba(255, 255, 255, 0.05)';

  // Fallback lists if the job object doesn't have detailed arrays
  const responsibilities = (job.responsibilities && job.responsibilities.length > 0)
    ? job.responsibilities
    : [
        `Lead core deliverables and problem-solving initiatives across ${job.domain} projects.`,
        `Collaborate effectively with cross-functional mentors, product leaders, and engineering teams.`,
        `Ensure industry-standard quality, maintain documentation, and adhere to reliable best practices.`,
        `Continuously analyze project metrics, optimize performance, and participate in peer reviews.`
      ];

  const qualifications = (job.qualifications && job.qualifications.length > 0)
    ? job.qualifications
    : [
        `Academic degree or practical background in ${job.domain} or related fields.`,
        `Demonstrated working familiarity with ${job.required_skills?.slice(0, 3).join(', ') || 'core principles'}.`,
        `Strong analytical thinking, proactive communication, and ability to work in team environments.`,
        `Self-motivated approach to learning modern tools and industry workflows.`
      ];

  const benefits = (job.benefits && job.benefits.length > 0)
    ? job.benefits
    : [
        job.remote ? '100% Remote flexibility & flexible working hours' : 'State-of-the-art office & hybrid flexibility',
        'Direct mentorship from principal leads and senior executives',
        'Comprehensive health benefits and wellness support',
        'Performance incentives and fast-track career advancement path'
      ];

  const handleCopyLink = () => {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'https://employai-hub.vercel.app';
    const inAppLink = `${origin}/?tab=opportunities&job=${job.id}`;
    navigator.clipboard.writeText(inAppLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleTailorResume = () => {
    try {
      localStorage.setItem('employai_tailor_target_job', JSON.stringify({
        title: job.title,
        company: job.company,
        description: job.description,
        skills: job.required_skills
      }));
    } catch {}
    onClose();
    if (onNavigate) {
      onNavigate('resume-enhancer');
    }
  };

  const handleMockInterview = () => {
    try {
      localStorage.setItem('employai_interview_target_role', JSON.stringify({
        role: job.title,
        domain: job.domain,
        company: job.company,
        skills: job.required_skills
      }));
    } catch {}
    onClose();
    if (onNavigate) {
      onNavigate('interviews');
    }
  };

  return (
    <div 
      className="job-details-modal-overlay"
      onClick={onClose}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 1000,
        backgroundColor: 'var(--modal-backdrop, rgba(5, 8, 16, 0.78))',
        backdropFilter: 'blur(8px)',
        WebkitBackdropFilter: 'blur(8px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1rem',
        animation: 'fadeIn 0.2s ease-out'
      }}
    >
      <div 
        className="job-details-modal-container glass-card"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: '820px',
          maxHeight: '90vh',
          backgroundColor: 'var(--bg-modal, #121826)',
          borderRadius: '18px',
          border: '1px solid var(--border-subtle, rgba(255, 255, 255, 0.12))',
          boxShadow: 'var(--shadow-modal, 0 25px 60px -15px rgba(0, 0, 0, 0.7))',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
          animation: 'modalSlideUp 0.25s cubic-bezier(0.16, 1, 0.3, 1)'
        }}
      >
        {/* Sticky Header */}
        <div 
          style={{
            padding: '1.4rem 1.75rem',
            borderBottom: '1px solid var(--border-subtle, rgba(255, 255, 255, 0.08))',
            display: 'flex',
            alignItems: 'flex-start',
            justifyContent: 'space-between',
            gap: '1rem',
            position: 'relative',
            backgroundColor: 'var(--bg-secondary, rgba(18, 24, 38, 0.95))'
          }}
        >
          <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start', flex: 1 }}>
            {/* Company Avatar Icon */}
            <div 
              style={{
                width: '54px',
                height: '54px',
                borderRadius: '14px',
                backgroundColor: 'rgba(6, 182, 212, 0.12)',
                border: '1px solid rgba(6, 182, 212, 0.25)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1.4rem',
                fontWeight: 800,
                color: 'var(--accent-cyan, #06b6d4)',
                flexShrink: 0
              }}
            >
              {job.company.charAt(0).toUpperCase()}
            </div>

            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '0.35rem' }}>
                <span 
                  className="badge"
                  style={{
                    fontSize: '0.7rem',
                    backgroundColor: srcStyle.bg,
                    color: srcStyle.text,
                    borderColor: srcStyle.border,
                    fontWeight: 700
                  }}
                >
                  {job.source}
                </span>
                <span 
                  className="badge badge-secondary"
                  style={{ fontSize: '0.7rem', fontWeight: 600 }}
                >
                  {job.job_type === 'internship' ? '🎓 Internship' : '💼 ' + (job.job_type || 'Full-Time')}
                </span>
                {job.domain && (
                  <span 
                    className="badge"
                    style={{
                      fontSize: '0.7rem',
                      backgroundColor: 'rgba(255, 255, 255, 0.05)',
                      color: 'var(--text-secondary)'
                    }}
                  >
                    {job.domain}
                  </span>
                )}
                {job.remote && (
                  <span 
                    className="badge"
                    style={{
                      fontSize: '0.7rem',
                      backgroundColor: 'rgba(16, 185, 129, 0.15)',
                      color: '#34d399',
                      borderColor: 'rgba(16, 185, 129, 0.3)'
                    }}
                  >
                    🌐 Remote Available
                  </span>
                )}
              </div>

              <h2 
                style={{
                  fontSize: '1.35rem',
                  fontWeight: 800,
                  color: 'var(--text-primary)',
                  letterSpacing: '-0.01em',
                  margin: '0 0 0.35rem 0',
                  lineHeight: 1.3
                }}
              >
                {job.title}
              </h2>

              <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem', flexWrap: 'wrap', fontSize: '0.825rem', color: 'var(--text-secondary)' }}>
                <span style={{ fontWeight: 700, color: 'var(--accent-cyan)' }}>
                  {job.company}
                </span>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}>
                  <MapPin size={13} style={{ color: 'var(--text-muted)' }} /> {job.location}
                </span>
                {job.salary_range && (
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', color: 'var(--accent-emerald)', fontWeight: 600 }}>
                    💰 {job.salary_range}
                  </span>
                )}
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', color: 'var(--text-muted)' }}>
                  <Calendar size={13} /> {job.posted_date || 'Active opening'}
                </span>
              </div>
            </div>
          </div>

          {/* Action buttons (Direct Link, Share & Close) */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
            <a
              href={targetUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-secondary btn-sm"
              style={{
                fontSize: '0.78rem',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.35rem',
                textDecoration: 'none',
                padding: '0.42rem 0.75rem',
                color: 'var(--accent-cyan)'
              }}
              title={`Apply directly on verified live platform feed (${job.source})`}
            >
              <ExternalLink size={13} /> View on {job.source.replace(/\([^)]*\)/g, '').trim()}
            </a>
            <button
              onClick={handleCopyLink}
              className="btn btn-secondary btn-sm"
              style={{ padding: '0.45rem', borderRadius: '8px' }}
              title="Copy link to opportunity"
            >
              {copiedLink ? <Check size={16} style={{ color: '#34d399' }} /> : <Share2 size={16} />}
            </button>
            <button
              onClick={onClose}
              className="btn btn-secondary btn-sm"
              style={{ padding: '0.45rem', borderRadius: '8px' }}
              title="Close modal"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Scrollable Body Content */}
        <div 
          style={{
            padding: '1.75rem',
            overflowY: 'auto',
            display: 'flex',
            flexDirection: 'column',
            gap: '1.6rem',
            flex: 1
          }}
        >
          {/* Personalized ATS Fit Analysis */}
          <div 
            style={{
              padding: '1.25rem 1.4rem',
              borderRadius: '14px',
              backgroundColor: matchBg,
              border: `1px solid ${matchColor}`,
              display: 'flex',
              flexDirection: 'column',
              gap: '0.85rem'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Target size={18} style={{ color: matchColor }} />
                <span style={{ fontSize: '0.95rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                  Personalized Match Analysis
                </span>
              </div>
              <span 
                className="badge" 
                style={{
                  fontSize: '0.825rem',
                  fontWeight: 800,
                  backgroundColor: matchBg,
                  color: matchColor,
                  borderColor: matchColor
                }}
              >
                {hasMatch ? `${matchScore}% Compatibility` : 'Sign In to Calculate Fit'}
              </span>
            </div>

            <p style={{ fontSize: '0.825rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
              {isHighFit 
                ? '🌟 Exceptional candidate fit! Your profile demonstrates strong coverage for the core responsibilities and technical skills required by this role.'
                : isGoodFit
                  ? '👍 Solid competitive match. You possess key domain competencies; review the target skills below to enhance your candidate positioning.'
                  : hasMatch
                    ? '⚡ Moderate fit. Target the missing skills using our personalized Learning Roadmaps to boost your ATS match score.'
                    : 'Sign in and upload your resume to evaluate exact ATS match score, skill coverage, and tailored gap recommendations.'}
            </p>

            {/* Skill Tags Matched & Missing */}
            <div>
              <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '0.45rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                Required Competencies ({job.required_skills?.length || 0})
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                {(job.required_skills || []).map((skill, idx) => {
                  const isMatched = matchedSkillsSet.has(skill.toLowerCase().trim());
                  return (
                    <span
                      key={idx}
                      className="badge"
                      style={{
                        fontSize: '0.72rem',
                        padding: '0.25rem 0.55rem',
                        backgroundColor: isMatched ? 'rgba(16, 185, 129, 0.18)' : 'rgba(245, 158, 11, 0.12)',
                        color: isMatched ? '#34d399' : 'var(--accent-amber, #fbbf24)',
                        borderColor: isMatched ? 'rgba(16, 185, 129, 0.4)' : 'rgba(245, 158, 11, 0.35)',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.25rem'
                      }}
                    >
                      {isMatched ? <CheckCircle2 size={12} /> : <Target size={12} />}
                      {skill}
                    </span>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Section: Role Overview */}
          <div>
            <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.6rem', display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
              <Briefcase size={17} style={{ color: 'var(--accent-cyan)' }} />
              About the Role
            </h3>
            <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.65, margin: 0 }}>
              {job.description}
            </p>
          </div>

          {/* Section: Key Responsibilities */}
          <div>
            <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.65rem', display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
              <Zap size={17} style={{ color: 'var(--accent-emerald)' }} />
              Key Responsibilities
            </h3>
            <ul style={{ margin: 0, paddingLeft: '1.25rem', display: 'flex', flexDirection: 'column', gap: '0.45rem' }}>
              {responsibilities.map((resp, i) => (
                <li key={i} style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.55 }}>
                  {resp}
                </li>
              ))}
            </ul>
          </div>

          {/* Section: Requirements & Qualifications */}
          <div>
            <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.65rem', display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
              <Award size={17} style={{ color: 'var(--accent-amber)' }} />
              Qualifications & Requirements
            </h3>
            <ul style={{ margin: 0, paddingLeft: '1.25rem', display: 'flex', flexDirection: 'column', gap: '0.45rem' }}>
              {qualifications.map((qual, i) => (
                <li key={i} style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.55 }}>
                  {qual}
                </li>
              ))}
            </ul>
          </div>

          {/* Section: Benefits & Perks */}
          <div>
            <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.65rem', display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
              <Sparkles size={17} style={{ color: '#c084fc' }} />
              Benefits & Offerings
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '0.65rem' }}>
              {benefits.map((b, i) => (
                <div 
                  key={i}
                  style={{
                    padding: '0.65rem 0.85rem',
                    borderRadius: '10px',
                    backgroundColor: 'var(--bg-tertiary, rgba(255, 255, 255, 0.04))',
                    border: '1px solid var(--border-subtle, rgba(255, 255, 255, 0.07))',
                    fontSize: '0.8rem',
                    color: 'var(--text-secondary)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.45rem'
                  }}
                >
                  <span style={{ color: 'var(--accent-emerald)' }}>✓</span> {b}
                </div>
              ))}
            </div>
          </div>

          {/* Career Acceleration Pathway Banner */}
          <div 
            style={{
              padding: '1.1rem 1.25rem',
              borderRadius: '12px',
              backgroundColor: 'rgba(6, 182, 212, 0.08)',
              border: '1px solid rgba(6, 182, 212, 0.25)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: '1rem',
              flexWrap: 'wrap'
            }}
          >
            <div style={{ flex: 1, minWidth: '240px' }}>
              <div style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--accent-cyan)', marginBottom: '0.2rem' }}>
                Targeting this opportunity? Boost your interview odds
              </div>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: 0, lineHeight: 1.45 }}>
                EmployAI can instantly tailor your resume bullet points for this specific JD, or launch an AI Mock Interview session tailored to {job.company}.
              </p>
            </div>
            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
              <button
                onClick={handleTailorResume}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.78rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}
              >
                <BookOpen size={13} /> Tailor Resume
              </button>
              <button
                onClick={handleMockInterview}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.78rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}
              >
                <MessageSquare size={13} /> Mock Interview
              </button>
            </div>
          </div>
        </div>

        {/* Sticky Action Footer */}
        <div 
          style={{
            padding: '1.1rem 1.75rem',
            borderTop: '1px solid var(--border-subtle, rgba(255, 255, 255, 0.08))',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '1rem',
            backgroundColor: 'var(--bg-secondary, rgba(18, 24, 38, 0.95))',
            flexWrap: 'wrap'
          }}
        >
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <ShieldCheck size={16} style={{ color: 'var(--accent-emerald)' }} />
            <span>Verified job posting sourced via <strong>{job.source}</strong></span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
            {/* Quick Apply via EmployAI */}
            {hasApplied ? (
              <button
                disabled
                className="btn btn-secondary"
                style={{ fontSize: '0.875rem', color: '#34d399', borderColor: 'rgba(16, 185, 129, 0.4)' }}
              >
                <Check size={15} /> Application Submitted
              </button>
            ) : (
              <button
                onClick={() => onApplyDirect(job)}
                disabled={isApplying}
                className="btn btn-secondary"
                style={{ fontSize: '0.875rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}
              >
                {isApplying ? 'Submitting...' : <><Send size={14} /> Quick Apply</>}
              </button>
            )}

            {/* Direct Official Apply Link */}
            <a
              href={targetUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary"
              style={{
                fontSize: '0.875rem',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.45rem',
                textDecoration: 'none',
                fontWeight: 700
              }}
              title={`Apply directly on verified live platform feed (${job.source})`}
            >
              Apply on {job.source.replace(/\([^)]*\)/g, '').trim()} <ExternalLink size={15} />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
