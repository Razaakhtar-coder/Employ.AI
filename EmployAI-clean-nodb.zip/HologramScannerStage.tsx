import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { BackgroundResumeScanner3D, type HologramVisualMode } from './BackgroundResumeScanner3D';
import type { ScannerTheme } from '../context/HologramThemeContext';
import { useHologramTheme, THEME_CONFIGS } from '../context/HologramThemeContext';
import { useAuth } from '../context/AuthContext';
import { documentApi } from '../services/api';
import type { StructuredResume, ResumeAnalysisResult } from '../types';
import { extractHologramSections, getDomainSpecificRecommendation, type HologramSectionData } from '../utils/hologramSectionExtractor';
import { hologramAudio } from '../utils/hologramAudio';
import { calculateATSScore, normalizeResumeForATS, getATSTier } from '../services/atsScoring';
import { 
  Scan, CheckCircle2, Activity, FileText, 
  Layers, Briefcase, Code, GraduationCap, 
  Award, BookOpen, Globe,
  ChevronLeft, ChevronRight, Upload, Sparkles,
  RefreshCw, X, Zap, ZoomOut, Volume2, VolumeX,
  Copy, Check, ArrowRight, HeartHandshake
} from 'lucide-react';

interface HologramScannerStageProps {
  onNavigateToResume?: () => void;
  onNavigateToRoadmap?: () => void;
}

const EMPTY_SKILLS: string[] = Object.freeze([]) as unknown as string[];

const HologramScannerStageComponent: React.FC<HologramScannerStageProps> = ({
  onNavigateToResume,
  onNavigateToRoadmap,
}) => {
  const { user, isAuthenticated, openAuthModal } = useAuth();
  const { mode, theme, setTheme, colors } = useHologramTheme();
  const isLight = mode === 'light';

  // Data states from canonical resume pipeline
  const [structuredResume, setStructuredResume] = useState<StructuredResume | null>(null);
  const [analysis, setAnalysis] = useState<ResumeAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  
  // Interactive Section Focus / Zoom State
  const [selectedSectionId, setSelectedSectionId] = useState<string | null>(null);
  const [hoveredSectionId, setHoveredSectionId] = useState<string | null>(null);

  // Multi-Page Hologram Navigation State
  const [currentPage, setCurrentPage] = useState<number>(1);
  
  // Visual Mode State: standard | heatmap
  const [visualMode, setVisualMode] = useState<HologramVisualMode>('standard');
  const [laserTrigger, setLaserTrigger] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(hologramAudio.getMuted());
  const [copiedText, setCopiedText] = useState<boolean>(false);

  // Responsive Drawer Toggles for Mobile/Tablet
  const [activeSideDrawer, setActiveSideDrawer] = useState<'none' | 'tokens' | 'ats'>('none');
  
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Load canonical latest analysis from backend
  const loadLatestResumeData = async () => {
    setIsLoading(true);
    try {
      const res = await documentApi.getLatestAnalysis();
      if (res) {
        setAnalysis(res);
        if (res.structured_resume) {
          setStructuredResume(res.structured_resume);
        } else {
          setStructuredResume({
            personal_info: {
              full_name: user?.full_name || res.filename?.replace(/\.[^/.]+$/, '') || 'Candidate',
              title: res.detected_domain || 'Verified Candidate',
              summary: res.strengths && res.strengths.length > 0 ? res.strengths.join(' ') : ''
            },
            headline: res.detected_domain,
            summary: res.strengths && res.strengths.length > 0 ? res.strengths.join(' ') : '',
            skills: res.extracted_skills || [],
            experience: (res.extracted_experience || []).map((e: any, idx: number) => ({
              id: `exp-${idx}`,
              role: e.role,
              company: e.company_or_org,
              duration: e.duration || '',
              bullets: e.highlights || []
            })),
            projects: (res.extracted_projects || []).map((p: any, idx: number) => ({
              id: `prj-${idx}`,
              title: p.title,
              role_or_tech: p.role_or_tech,
              technologies: p.key_technologies || [],
              description: p.description,
              bullets: [p.description, p.quantifiable_metrics || p.quantified_impact].filter(Boolean) as string[]
            })),
            education: [],
            certifications: []
          });
        }
      }
    } catch {
      setAnalysis(null);
      setStructuredResume(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadLatestResumeData();
  }, [isAuthenticated]);

  // Handle direct file upload right on the Hologram stage
  const handleFileUpload = async (file: File) => {
    if (!isAuthenticated) {
      openAuthModal('login', 'student');
      return;
    }

    setIsUploading(true);
    setUploadError(null);
    setSelectedSectionId(null);
    setCurrentPage(1);

    try {
      const result = await documentApi.uploadResume(file);
      setAnalysis(result);
      if (result.structured_resume) {
        setStructuredResume(result.structured_resume);
      } else {
        setStructuredResume({
          personal_info: {
            full_name: user?.full_name || file.name.replace(/\.[^/.]+$/, ''),
            title: result.detected_domain || 'Verified Candidate',
            summary: result.strengths && result.strengths.length > 0 ? result.strengths.join(' ') : ''
          },
          headline: result.detected_domain,
          skills: result.extracted_skills || [],
          experience: (result.extracted_experience || []).map((e: any, idx: number) => ({
            id: `exp-${idx}`,
            role: e.role,
            company: e.company_or_org,
            duration: e.duration || '',
            bullets: e.highlights || []
          })),
          projects: (result.extracted_projects || []).map((p: any, idx: number) => ({
            id: `prj-${idx}`,
            title: p.title,
            role_or_tech: p.role_or_tech,
            technologies: p.key_technologies || [],
            description: p.description,
            bullets: [p.description, p.quantifiable_metrics || p.quantified_impact].filter(Boolean) as string[]
          })),
          education: [],
          certifications: []
        });
      }

      hologramAudio.playScanBurst();
    } catch (err: any) {
      setUploadError(err?.message || 'Failed to upload and parse resume. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  // Extract sections dynamically from parsed resume
  const detectedSections = useMemo<HologramSectionData[]>(() => {
    return extractHologramSections(structuredResume, analysis);
  }, [structuredResume, analysis]);

  // Total available pages based on whether multi-page content exists
  const totalPages = useMemo(() => {
    return detectedSections.length > 0 ? 2 : 1;
  }, [detectedSections]);

  // Switch resume page
  const handlePageChange = useCallback((page: number) => {
    if (page < 1 || page > totalPages || page === currentPage) return;
    hologramAudio.playSectionSelect();
    setCurrentPage(page);
    setLaserTrigger(Date.now());
  }, [totalPages, currentPage]);

  // Split sections into Left Rail (Page 1) and Right Rail (Page 2)
  const { leftRailSections, rightRailSections } = useMemo(() => {
    const left: HologramSectionData[] = [];
    const right: HologramSectionData[] = [];

    detectedSections.forEach((sec) => {
      if (['summary', 'skills', 'experience', 'internship'].includes(sec.id)) {
        left.push(sec);
      } else {
        right.push(sec);
      }
    });

    if (left.length === 0 && right.length > 0) {
      const half = Math.ceil(right.length / 2);
      return { leftRailSections: right.slice(0, half), rightRailSections: right.slice(half) };
    }
    if (right.length === 0 && left.length > 0) {
      const half = Math.ceil(left.length / 2);
      return { leftRailSections: left.slice(0, half), rightRailSections: left.slice(half) };
    }

    return { leftRailSections: left, rightRailSections: right };
  }, [detectedSections]);

  // Selected active section object
  const activeSection = useMemo<HologramSectionData | undefined>(() => {
    if (!selectedSectionId) return undefined;
    return detectedSections.find(s => s.id === selectedSectionId);
  }, [selectedSectionId, detectedSections]);

  // Handle selecting section from anywhere with auto-page flip
  const handleSelectSection = useCallback((secId: string | null) => {
    if (!secId) {
      setSelectedSectionId(null);
      return;
    }
    const isPage2 = ['projects', 'education', 'certifications', 'achievements', 'publications', 'languages', 'volunteer'].includes(secId);
    const targetPage = isPage2 ? 2 : 1;
    if (targetPage !== currentPage && totalPages > 1) {
      setCurrentPage(targetPage);
    }
    hologramAudio.playSectionLock();
    setSelectedSectionId(secId);
  }, [currentPage, totalPages]);

  // Navigate to prev/next section while zoomed
  const handleNavigateSection = useCallback((direction: 'prev' | 'next') => {
    if (!selectedSectionId || detectedSections.length === 0) return;
    const curIdx = detectedSections.findIndex(s => s.id === selectedSectionId);
    if (curIdx === -1) return;

    let newIdx = direction === 'next' ? curIdx + 1 : curIdx - 1;
    if (newIdx < 0) newIdx = detectedSections.length - 1;
    if (newIdx >= detectedSections.length) newIdx = 0;

    const targetSec = detectedSections[newIdx];
    if (targetSec) {
      const isPage2 = ['projects', 'education', 'certifications', 'achievements', 'publications', 'languages', 'volunteer'].includes(targetSec.id);
      const targetPage = isPage2 ? 2 : 1;
      if (targetPage !== currentPage && totalPages > 1) {
        setCurrentPage(targetPage);
      }
      hologramAudio.playSectionLock();
      setSelectedSectionId(targetSec.id);
    }
  }, [selectedSectionId, detectedSections, currentPage, totalPages]);

  // Keyboard navigation: Esc zooms out, arrows navigate sections, PgUp/PgDn or 1/2 flips pages
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;

      if (e.key === 'Escape') {
        if (selectedSectionId) {
          hologramAudio.playZoomOut();
          setSelectedSectionId(null);
        }
      } else if (e.key === 'ArrowRight' && selectedSectionId) {
        handleNavigateSection('next');
      } else if (e.key === 'ArrowLeft' && selectedSectionId) {
        handleNavigateSection('prev');
      } else if (e.key === 'PageDown' || e.key === '2' || e.key === ']') {
        if (totalPages > 1 && currentPage !== 2) {
          handlePageChange(2);
        }
      } else if (e.key === 'PageUp' || e.key === '1' || e.key === '[') {
        if (currentPage !== 1) {
          handlePageChange(1);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedSectionId, detectedSections, currentPage, totalPages]);

  const candidateName = useMemo(() => {
    return structuredResume?.personal_info?.full_name || 
      user?.full_name || 
      analysis?.filename?.replace(/\.[^/.]+$/, '') || 
      'Verified Candidate';
  }, [structuredResume, user, analysis]);

  const domainTitle = useMemo(() => {
    return structuredResume?.personal_info?.title || 
      structuredResume?.headline || 
      analysis?.detected_domain || 
      'Professional Candidate';
  }, [structuredResume, analysis]);

  const extractedSkills = useMemo<string[]>(() => {
    if (structuredResume?.skills && structuredResume.skills.length > 0) {
      return structuredResume.skills;
    }
    if (analysis?.extracted_skills && analysis.extracted_skills.length > 0) {
      return analysis.extracted_skills;
    }
    return EMPTY_SKILLS;
  }, [structuredResume, analysis]);

  const dynamicATS = useMemo(() => {
    const norm = normalizeResumeForATS(structuredResume || analysis);
    return calculateATSScore(norm, analysis?.resume_quality_score || 75);
  }, [structuredResume, analysis]);

  const qualityScore = dynamicATS.overall_score;
  const atsTierInfo = useMemo(() => getATSTier(qualityScore), [qualityScore]);

  const toggleSound = () => {
    const newMuted = hologramAudio.toggleMute();
    setIsMuted(newMuted);
  };

  const handleSelectVisualMode = (modeType: HologramVisualMode) => {
    setVisualMode(modeType);
    hologramAudio.playModeSwitch();
  };

  const handleTriggerLaserBurst = () => {
    setLaserTrigger(Date.now());
  };

  const copySectionContent = (text: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedText(true);
      setTimeout(() => setCopiedText(false), 2000);
    }
  };

  // Helper for section icons
  const getSectionIcon = (iconName: string, size = 14) => {
    switch (iconName) {
      case 'summary': return <FileText size={size} />;
      case 'skills': return <Zap size={size} />;
      case 'experience': return <Briefcase size={size} />;
      case 'internship': return <Layers size={size} />;
      case 'projects': return <Code size={size} />;
      case 'education': return <GraduationCap size={size} />;
      case 'certifications': return <Award size={size} />;
      case 'achievements': return <Sparkles size={size} />;
      case 'publications': return <BookOpen size={size} />;
      case 'languages': return <Globe size={size} />;
      case 'volunteer': return <HeartHandshake size={size} />;
      default: return <FileText size={size} />;
    }
  };

  // Actionable domain-aware AI recommendation based on active section and candidate domain
  const getSectionRecommendation = (sectionId: string): string => {
    return getDomainSpecificRecommendation(sectionId, domainTitle);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      
      {/* Top Holographic Console Header */}
      <div 
        className="glass-card" 
        style={{ 
          padding: '1.25rem 1.75rem', 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between', 
          flexWrap: 'wrap', 
          gap: '1rem',
          background: isLight 
            ? 'linear-gradient(135deg, rgba(255, 255, 255, 0.96) 0%, rgba(240, 249, 255, 0.92) 100%)'
            : 'linear-gradient(135deg, rgba(11, 17, 44, 0.96) 0%, rgba(17, 24, 58, 0.88) 100%)',
          border: `1.5px solid ${colors.cssColor}`,
          boxShadow: isLight ? `0 4px 20px ${colors.cssGlow}` : `0 0 25px ${colors.cssGlow}`
        }}
      >
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '0.25rem', flexWrap: 'wrap' }}>
            <div style={{
              width: '36px',
              height: '36px',
              borderRadius: '8px',
              background: colors.swatch,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: `0 0 15px ${colors.cssGlow}`
            }}>
              <Scan size={20} color="#ffffff" />
            </div>
            <h1 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.02em', margin: 0 }}>
              3D Holographic Resume Scanner
            </h1>
            <span 
              className="badge" 
              style={{ 
                fontSize: '0.65rem',
                background: colors.accentBg,
                color: colors.cssColor,
                border: `1px solid ${colors.cssColor}`,
                fontWeight: 700
              }}
            >
              <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: colors.cssColor, boxShadow: `0 0 6px ${colors.cssColor}`, animation: 'pulse 1.5s infinite', display: 'inline-block', marginRight: '4px' }} />
              {isLoading ? 'SYNCING...' : colors.name.toUpperCase()}
            </span>
          </div>
          <p style={{ fontSize: '0.825rem', color: 'var(--text-secondary)', margin: 0 }}>
            {detectedSections.length > 0 ? (
              <>Mapped <strong>{detectedSections.length} sections</strong> and <strong>{extractedSkills.length} skills</strong> for <strong>{candidateName}</strong> across <strong>{totalPages} Holographic Pages</strong>. Click any section or use page tabs to inspect full candidate credentials.</>
            ) : (
              <>Real-time WebGL 3D volumetric laser sweep, multi-page mesh inspection, and optical token extraction.</>
            )}
          </p>
        </div>

        {/* Upload, Sound & Theme Controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleFileUpload(e.target.files[0]);
              }
            }} 
            accept=".pdf,.docx,.doc" 
            style={{ display: 'none' }} 
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            className="btn btn-primary btn-sm"
            style={{
              fontSize: '0.75rem',
              fontWeight: 800,
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.4rem',
              background: colors.swatch,
              color: '#ffffff',
              border: 'none',
              boxShadow: `0 0 14px ${colors.cssGlow}`
            }}
          >
            {isUploading ? (
              <>
                <RefreshCw size={13} className="animate-spin-slow" />
                <span>Scanning...</span>
              </>
            ) : (
              <>
                <Upload size={13} />
                <span>Upload Resume</span>
              </>
            )}
          </button>

          {/* Sound Toggle */}
          <button
            type="button"
            onClick={toggleSound}
            className="btn btn-secondary btn-sm"
            style={{
              padding: '0.35rem 0.6rem',
              fontSize: '0.75rem',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.3rem',
              border: isMuted ? '1px solid var(--border-subtle)' : `1px solid ${colors.cssColor}`,
              color: isMuted ? 'var(--text-muted)' : colors.cssColor
            }}
            title={isMuted ? 'Enable Synthesized Audio FX' : 'Mute Audio FX'}
          >
            {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            <span style={{ fontSize: '0.7rem' }}>{isMuted ? 'Muted' : 'Audio ON'}</span>
          </button>

          {/* Atmosphere Color Selector Pills */}
          <div style={{ display: 'flex', background: isLight ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)', padding: '0.2rem', borderRadius: '8px', border: `1px solid ${colors.cssGlow}`, gap: '0.2rem' }}>
            {(Object.keys(THEME_CONFIGS) as ScannerTheme[]).map((t) => {
              const cfg = THEME_CONFIGS[t];
              const isCur = theme === t;
              return (
                <button
                  key={t}
                  onClick={() => setTheme(t)}
                  style={{
                    padding: '0.3rem 0.55rem',
                    borderRadius: '6px',
                    border: isCur ? `1.5px solid ${cfg.cssColor}` : '1px solid transparent',
                    background: isCur ? cfg.swatch : 'transparent',
                    color: isCur ? '#ffffff' : (isLight ? '#475569' : 'var(--text-muted)'),
                    fontSize: '0.7rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.3rem',
                    boxShadow: isCur ? `0 0 10px ${cfg.cssGlow}` : 'none',
                    transition: 'all 0.15s'
                  }}
                  title={cfg.subtitle}
                >
                  <span style={{ width: '7px', height: '7px', borderRadius: '50%', backgroundColor: cfg.cssColor, display: 'inline-block' }} />
                  <span>{cfg.name.split(' ')[0]}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {uploadError && (
        <div style={{ padding: '0.75rem 1rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.12)', border: '1px solid rgba(244, 63, 94, 0.3)', color: '#fb7185', fontSize: '0.8rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span>{uploadError}</span>
          <button onClick={() => setUploadError(null)} style={{ background: 'transparent', border: 'none', color: '#fb7185', cursor: 'pointer' }}><X size={15} /></button>
        </div>
      )}

      {/* 3D Visual Mode Toolbar */}
      <div 
        className="glass-card" 
        style={{ 
          padding: '0.5rem 0.85rem', 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between', 
          flexWrap: 'wrap', 
          gap: '0.6rem',
          background: isLight ? 'rgba(255, 255, 255, 0.85)' : 'rgba(15, 23, 42, 0.75)',
          border: `1px solid ${colors.cssGlow}`
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap' }}>
          <span style={{ fontSize: '0.72rem', fontWeight: 800, color: 'var(--text-muted)', textTransform: 'uppercase', marginRight: '0.1rem' }}>
            Visual Mode:
          </span>

          <button
            type="button"
            onClick={() => handleSelectVisualMode('standard')}
            className={`btn btn-sm ${visualMode === 'standard' ? 'btn-primary' : 'btn-secondary'}`}
            style={{
              fontSize: '0.72rem',
              padding: '0.3rem 0.75rem',
              background: visualMode === 'standard' ? colors.swatch : undefined,
              border: visualMode === 'standard' ? 'none' : undefined,
              color: visualMode === 'standard' ? '#ffffff' : undefined,
              fontWeight: 700
            }}
          >
            <Scan size={13} />
            <span>Standard 3D</span>
          </button>

          <button
            type="button"
            onClick={() => handleSelectVisualMode('heatmap')}
            className={`btn btn-sm ${visualMode === 'heatmap' ? 'btn-primary' : 'btn-secondary'}`}
            style={{
              fontSize: '0.72rem',
              padding: '0.3rem 0.75rem',
              background: visualMode === 'heatmap' ? 'linear-gradient(135deg, #10b981 0%, #059669 100%)' : undefined,
              border: visualMode === 'heatmap' ? 'none' : undefined,
              color: visualMode === 'heatmap' ? '#ffffff' : undefined,
              fontWeight: 700
            }}
          >
            <Activity size={13} />
            <span>Neural ATS Heatmap</span>
          </button>

          {/* Holographic Resume Page Switcher */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.25rem',
            background: isLight ? 'rgba(0, 0, 0, 0.04)' : 'rgba(255, 255, 255, 0.04)',
            padding: '0.2rem 0.35rem',
            borderRadius: '8px',
            border: `1px solid ${colors.cssGlow}`,
            marginLeft: '0.25rem'
          }}>
            <span style={{ fontSize: '0.7rem', fontWeight: 800, color: 'var(--text-muted)', textTransform: 'uppercase', marginRight: '0.2rem' }}>
              Hologram Page:
            </span>

            <button
              type="button"
              onClick={() => handlePageChange(1)}
              className={`btn btn-sm ${currentPage === 1 ? 'btn-primary' : 'btn-secondary'}`}
              style={{
                fontSize: '0.72rem',
                padding: '0.25rem 0.65rem',
                background: currentPage === 1 ? colors.swatch : 'transparent',
                border: currentPage === 1 ? 'none' : '1px solid transparent',
                color: currentPage === 1 ? '#ffffff' : (isLight ? '#334155' : 'var(--text-secondary)'),
                fontWeight: 700,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.3rem'
              }}
              title="Page 1: Profile Summary, Verified Skills, Work Experience & Internships"
            >
              <FileText size={12} />
              <span>Page 1: Experience</span>
            </button>

            <button
              type="button"
              onClick={() => handlePageChange(2)}
              className={`btn btn-sm ${currentPage === 2 ? 'btn-primary' : 'btn-secondary'}`}
              style={{
                fontSize: '0.72rem',
                padding: '0.25rem 0.65rem',
                background: currentPage === 2 ? colors.swatch : 'transparent',
                border: currentPage === 2 ? 'none' : '1px solid transparent',
                color: currentPage === 2 ? '#ffffff' : (isLight ? '#334155' : 'var(--text-secondary)'),
                fontWeight: 700,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.3rem'
              }}
              title="Page 2: Key Projects, Education, Certifications & Credentials"
            >
              <Code size={12} />
              <span>Page 2: Projects</span>
            </button>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <button
            type="button"
            onClick={handleTriggerLaserBurst}
            className="btn btn-outline-cyan btn-sm"
            style={{
              fontSize: '0.72rem',
              padding: '0.3rem 0.75rem',
              borderColor: colors.cssColor,
              color: colors.cssColor,
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.35rem',
              fontWeight: 700
            }}
          >
            <Zap size={13} />
            <span>Laser Pulse Sweep</span>
          </button>

          {/* Mobile/Tablet Side Panel Toggles */}
          <div className="hologram-mobile-toggles" style={{ display: 'none', gap: '0.3rem' }}>
            <button
              type="button"
              onClick={() => setActiveSideDrawer(activeSideDrawer === 'tokens' ? 'none' : 'tokens')}
              className="btn btn-secondary btn-sm"
              style={{ fontSize: '0.7rem', padding: '0.3rem 0.5rem' }}
            >
              OCR Tokens
            </button>
            <button
              type="button"
              onClick={() => setActiveSideDrawer(activeSideDrawer === 'ats' ? 'none' : 'ats')}
              className="btn btn-secondary btn-sm"
              style={{ fontSize: '0.7rem', padding: '0.3rem 0.5rem' }}
            >
              ATS Rating
            </button>
          </div>
        </div>
      </div>

      {/* Main Responsive 3D Stage Grid */}
      <div className="hologram-grid-responsive">
        
        {/* Left Column: Live OCR Token Stream & Extracted Signals */}
        <div className={`glass-card hologram-col-left ${activeSideDrawer === 'tokens' ? 'hologram-drawer-open' : ''}`} style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Activity size={16} color={colors.cssColor} />
              <h3 style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
                Live Token Pipeline
              </h3>
            </div>
            <span className="badge" style={{ fontSize: '0.65rem', background: colors.accentBg, color: colors.cssColor, border: `1px solid ${colors.cssColor}` }}>
              {detectedSections.length} Sections
            </span>
          </div>

          {/* Terminal / Live Token Stream */}
          <div style={{ 
            background: isLight ? 'rgba(15, 23, 42, 0.94)' : 'rgba(0, 0, 0, 0.45)', 
            padding: '0.85rem', 
            borderRadius: '8px', 
            border: `1px solid ${colors.cssGlow}`, 
            fontSize: '0.74rem', 
            fontFamily: 'monospace', 
            display: 'flex', 
            flexDirection: 'column', 
            gap: '0.4rem', 
            maxHeight: '170px', 
            overflowY: 'auto',
            boxShadow: isLight ? '0 4px 14px rgba(15, 23, 42, 0.12)' : 'none'
          }}>
            <div style={{ color: colors.cssColor, fontWeight: 600 }}>&gt; [0.012s] OCR Layer Initialized (2400x3574 High-DPI)</div>
            <div style={{ color: '#34d399', fontWeight: 600 }}>&gt; [0.048s] Candidate: {candidateName}</div>
            <div style={{ color: '#cbd5e1', fontWeight: 500 }}>&gt; [0.092s] Domain: {domainTitle.slice(0, 24)}</div>
            <div style={{ color: colors.cssSecondary, fontWeight: 600 }}>&gt; [0.144s] Mode: {visualMode === 'heatmap' ? 'ATS HEATMAP' : '3D HOLOGRAM'}</div>
            <div style={{ color: '#fbbf24', fontWeight: 600 }}>&gt; [0.210s] Neural ATS Quality: {qualityScore}%</div>
            <div style={{ color: colors.cssColor, fontWeight: 600 }}>&gt; [0.280s] 3D Raycast: TAP_ANY_SECTION</div>
          </div>

          {/* Real Extracted Competencies */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.45rem' }}>
              <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                Extracted Competencies ({extractedSkills.length})
              </span>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem', maxHeight: '180px', overflowY: 'auto' }}>
              {extractedSkills.length > 0 ? (
                extractedSkills.map((s: string, idx: number) => (
                  <span 
                    key={idx} 
                    className="badge badge-secondary" 
                    style={{ 
                      fontSize: '0.72rem',
                      fontWeight: 600,
                      border: `1px solid ${colors.cssGlow}`,
                      background: colors.accentBg,
                      color: isLight ? '#0f172a' : '#e2e8f0',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.3rem',
                      padding: '0.2rem 0.45rem',
                      borderRadius: '6px'
                    }}
                  >
                    <CheckCircle2 size={10} color={colors.cssColor} />
                    {s}
                  </span>
                ))
              ) : (
                <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: 0, fontStyle: 'italic' }}>
                  No skills detected yet. Upload a resume to extract.
                </p>
              )}
            </div>
          </div>

          <div style={{ marginTop: 'auto', paddingTop: '0.75rem', borderTop: isLight ? '1px solid rgba(0, 0, 0, 0.08)' : '1px solid rgba(255, 255, 255, 0.05)' }}>
            <button 
              onClick={() => React.startTransition(() => onNavigateToResume?.())}
              className="btn btn-outline-cyan btn-sm" 
              style={{ width: '100%', fontSize: '0.75rem', borderColor: colors.cssColor, color: colors.cssColor }}
            >
              <FileText size={14} /> Open Full AI Resume Studio →
            </button>
          </div>
        </div>

        {/* Center Column: 3D Holographic Stage */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
          
          <div 
            className="glass-card hologram-col-center" 
            style={{ 
              padding: '0', 
              position: 'relative', 
              minHeight: '580px', 
              overflow: 'hidden',
              border: `1.5px solid ${colors.cssColor}`,
              boxShadow: isLight 
                ? `inset 0 0 30px ${colors.cssGlow}, 0 8px 25px rgba(0, 0, 0, 0.08)` 
                : `inset 0 0 40px rgba(0, 0, 0, 0.8), 0 10px 30px ${colors.cssGlow}`
            }}
          >
            {/* Top Control Overlay Banner */}
            <div style={{
              position: 'absolute',
              top: '0.75rem',
              left: '0.85rem',
              right: '0.85rem',
              zIndex: 30,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              pointerEvents: 'none',
              flexWrap: 'wrap',
              gap: '0.5rem'
            }}>
              <div style={{ 
                background: isLight ? 'rgba(255, 255, 255, 0.94)' : 'rgba(6, 11, 24, 0.88)', 
                padding: '0.35rem 0.75rem', 
                borderRadius: '8px', 
                border: `1px solid ${colors.cssGlow}`, 
                backdropFilter: 'blur(8px)',
                pointerEvents: 'auto',
                display: 'flex',
                alignItems: 'center',
                gap: '0.4rem'
              }}>
                <span style={{ fontSize: '0.68rem', color: isLight ? '#475569' : 'var(--text-muted)' }}>CANDIDATE: </span>
                <strong style={{ fontSize: '0.75rem', color: isLight ? '#0f172a' : '#f8fafc' }}>{candidateName}</strong>
              </div>

              {/* When Zoomed In: Clean Header & Section Switcher with ZERO Content Obstruction */}
              {selectedSectionId && activeSection ? (
                <div style={{ 
                  background: isLight ? 'rgba(255, 255, 255, 0.98)' : 'rgba(15, 23, 42, 0.96)', 
                  padding: '0.35rem 0.85rem', 
                  borderRadius: '10px', 
                  border: `1.5px solid ${colors.cssColor}`, 
                  boxShadow: `0 0 20px ${colors.cssGlow}`,
                  backdropFilter: 'blur(12px)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.6rem',
                  pointerEvents: 'auto',
                  animation: 'fadeIn 0.2s ease-out'
                }}>
                  <button
                    type="button"
                    onClick={() => handleNavigateSection('prev')}
                    className="btn btn-ghost btn-sm"
                    style={{ padding: '0.2rem 0.35rem', fontSize: '0.7rem' }}
                    title="Previous Section (Left Arrow)"
                  >
                    <ChevronLeft size={15} />
                  </button>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                    <span style={{ color: colors.cssColor }}>
                      {getSectionIcon(activeSection.iconName, 14)}
                    </span>
                    <span style={{ fontSize: '0.78rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                      {activeSection.label}
                    </span>
                    <span style={{ fontSize: '0.68rem', color: colors.cssColor, fontWeight: 700 }}>
                      ({activeSection.stat})
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleNavigateSection('next')}
                    className="btn btn-ghost btn-sm"
                    style={{ padding: '0.2rem 0.35rem', fontSize: '0.7rem' }}
                    title="Next Section (Right Arrow)"
                  >
                    <ChevronRight size={15} />
                  </button>

                  {/* Overview Action Button */}
                  <button
                    type="button"
                    onClick={() => {
                      hologramAudio.playZoomOut();
                      setSelectedSectionId(null);
                    }}
                    className="btn btn-primary btn-sm"
                    style={{
                      padding: '0.3rem 0.75rem',
                      fontSize: '0.74rem',
                      fontWeight: 800,
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.35rem',
                      marginLeft: '0.35rem',
                      background: colors.swatch,
                      color: '#ffffff',
                      border: 'none',
                      boxShadow: `0 0 12px ${colors.cssGlow}`,
                      cursor: 'pointer'
                    }}
                    title="Zoom out to overview (Esc)"
                  >
                    <ZoomOut size={13} />
                    <span>Overview (Esc)</span>
                  </button>
                </div>
              ) : (
                <div style={{ 
                  background: isLight ? 'rgba(255, 255, 255, 0.94)' : 'rgba(6, 11, 24, 0.88)', 
                  padding: '0.35rem 0.75rem', 
                  borderRadius: '8px', 
                  border: `1px solid ${colors.cssColor}`, 
                  backdropFilter: 'blur(8px)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.4rem',
                  pointerEvents: 'auto'
                }}>
                  <span style={{ fontSize: '0.68rem', color: colors.cssColor, fontWeight: 700 }}>
                    ⚡ CLICK ANY SECTION ON THE 3D RESUME TO INSPECT
                  </span>
                </div>
              )}
            </div>

            {/* LEFT & RIGHT FLOATING SECTION BUTTONS (Shown in overview) */}
            {!selectedSectionId && (
              <>
                {/* LEFT RAIL FLOATING BUTTONS (Page 1: Profile & Experience) */}
                <div className="hologram-rail-left" style={{
                  position: 'absolute',
                  left: '1rem',
                  top: '3.8rem',
                  bottom: '3.5rem',
                  zIndex: 25,
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.5rem',
                  justifyContent: 'center',
                  pointerEvents: 'auto',
                  animation: 'fadeIn 0.25s ease-out'
                }}>
                  <div style={{
                    fontSize: '0.62rem',
                    fontWeight: 800,
                    color: colors.cssColor,
                    letterSpacing: '0.05em',
                    textTransform: 'uppercase',
                    marginBottom: '0.1rem',
                    background: colors.accentBg,
                    padding: '0.2rem 0.5rem',
                    borderRadius: '6px',
                    textAlign: 'center',
                    border: `1px solid ${colors.cssGlow}`,
                    backdropFilter: 'blur(8px)'
                  }}>
                    📄 Page 1 • Exp
                  </div>

                  {leftRailSections.map((sec) => {
                    const isHovered = hoveredSectionId === sec.id;

                    return (
                      <div
                        key={sec.id}
                        tabIndex={0}
                        role="button"
                        aria-label={`Zoom into ${sec.label}`}
                        onClick={() => handleSelectSection(sec.id)}
                        onMouseEnter={() => setHoveredSectionId(sec.id)}
                        onMouseLeave={() => setHoveredSectionId(null)}
                        style={{
                          cursor: 'pointer',
                          padding: '0.45rem 0.75rem',
                          borderRadius: '10px',
                          background: isHovered 
                            ? (isLight ? 'rgba(255, 255, 255, 0.98)' : 'rgba(15, 23, 42, 0.95)')
                            : (isLight ? 'rgba(255, 255, 255, 0.88)' : 'rgba(8, 14, 34, 0.85)'),
                          border: isHovered 
                            ? `1.5px solid ${colors.cssColor}` 
                            : `1px solid ${colors.cssGlow}`,
                          boxShadow: isHovered 
                            ? `0 0 16px ${colors.cssGlow}, 0 8px 24px rgba(0,0,0,0.5)` 
                            : '0 4px 12px rgba(0,0,0,0.3)',
                          backdropFilter: 'blur(10px)',
                          transform: isHovered ? 'scale(1.05) translateX(3px)' : 'scale(1.0)',
                          transition: 'all 0.18s cubic-bezier(0.34, 1.56, 0.64, 1)',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '0.15rem',
                          minWidth: '125px',
                          maxWidth: '150px',
                          userSelect: 'none'
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                          <span style={{ color: colors.cssColor }}>
                            {getSectionIcon(sec.iconName, 13)}
                          </span>
                          <span style={{ fontSize: '0.74rem', fontWeight: 800, color: isLight ? '#0f172a' : '#f8fafc', letterSpacing: '0.03em' }}>
                            {sec.label}
                          </span>
                        </div>
                        <span style={{ fontSize: '0.66rem', color: colors.cssColor, fontWeight: 700, fontFamily: 'monospace' }}>
                          {sec.stat}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* RIGHT RAIL FLOATING BUTTONS (Page 2: Projects & Credentials) */}
                <div className="hologram-rail-right" style={{
                  position: 'absolute',
                  right: '1rem',
                  top: '3.8rem',
                  bottom: '3.5rem',
                  zIndex: 25,
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.5rem',
                  justifyContent: 'center',
                  alignItems: 'flex-end',
                  pointerEvents: 'auto',
                  animation: 'fadeIn 0.25s ease-out'
                }}>
                  <div style={{
                    fontSize: '0.62rem',
                    fontWeight: 800,
                    color: colors.cssSecondary,
                    letterSpacing: '0.05em',
                    textTransform: 'uppercase',
                    marginBottom: '0.1rem',
                    background: colors.accentBg,
                    padding: '0.2rem 0.5rem',
                    borderRadius: '6px',
                    textAlign: 'center',
                    border: `1px solid ${colors.cssGlow}`,
                    backdropFilter: 'blur(8px)'
                  }}>
                    📑 Page 2 • Projects
                  </div>

                  {rightRailSections.map((sec) => {
                    const isHovered = hoveredSectionId === sec.id;

                    return (
                      <div
                        key={sec.id}
                        tabIndex={0}
                        role="button"
                        aria-label={`Zoom into ${sec.label}`}
                        onClick={() => handleSelectSection(sec.id)}
                        onMouseEnter={() => setHoveredSectionId(sec.id)}
                        onMouseLeave={() => setHoveredSectionId(null)}
                        style={{
                          cursor: 'pointer',
                          padding: '0.45rem 0.75rem',
                          borderRadius: '10px',
                          background: isHovered 
                            ? (isLight ? 'rgba(255, 255, 255, 0.98)' : 'rgba(15, 23, 42, 0.95)')
                            : (isLight ? 'rgba(255, 255, 255, 0.88)' : 'rgba(8, 14, 34, 0.85)'),
                          border: isHovered 
                            ? `1.5px solid ${colors.cssColor}` 
                            : `1px solid ${colors.cssGlow}`,
                          boxShadow: isHovered 
                            ? `0 0 16px ${colors.cssGlow}, 0 8px 24px rgba(0,0,0,0.5)` 
                            : '0 4px 12px rgba(0,0,0,0.3)',
                          backdropFilter: 'blur(10px)',
                          transform: isHovered ? 'scale(1.05) translateX(-3px)' : 'scale(1.0)',
                          transition: 'all 0.18s cubic-bezier(0.34, 1.56, 0.64, 1)',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '0.15rem',
                          minWidth: '125px',
                          maxWidth: '150px',
                          userSelect: 'none'
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                          <span style={{ color: colors.cssColor }}>
                            {getSectionIcon(sec.iconName, 13)}
                          </span>
                          <span style={{ fontSize: '0.74rem', fontWeight: 800, color: isLight ? '#0f172a' : '#f8fafc', letterSpacing: '0.03em' }}>
                            {sec.label}
                          </span>
                        </div>
                        <span style={{ fontSize: '0.66rem', color: colors.cssColor, fontWeight: 700, fontFamily: 'monospace' }}>
                          {sec.stat}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </>
            )}

            {/* Floating Holographic Page Navigator Ribbon at bottom center of 3D Canvas */}
            <div style={{
              position: 'absolute',
              bottom: '0.85rem',
              left: '50%',
              transform: 'translateX(-50%)',
              zIndex: 30,
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              background: isLight ? 'rgba(255, 255, 255, 0.95)' : 'rgba(11, 17, 44, 0.92)',
              padding: '0.35rem 0.85rem',
              borderRadius: '30px',
              border: `1.5px solid ${colors.cssColor}`,
              boxShadow: `0 4px 20px rgba(0, 0, 0, 0.35), 0 0 16px ${colors.cssGlow}`,
              backdropFilter: 'blur(12px)',
              pointerEvents: 'auto'
            }}>
              <button
                type="button"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage <= 1}
                className="btn btn-ghost btn-sm"
                style={{
                  padding: '0.2rem 0.45rem',
                  fontSize: '0.72rem',
                  opacity: currentPage <= 1 ? 0.35 : 1,
                  cursor: currentPage <= 1 ? 'not-allowed' : 'pointer',
                  color: colors.cssColor
                }}
                title="Previous Resume Page (PageUp or 1)"
              >
                <ChevronLeft size={16} />
              </button>

              <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <button
                  type="button"
                  onClick={() => handlePageChange(1)}
                  style={{
                    padding: '0.25rem 0.75rem',
                    borderRadius: '20px',
                    border: 'none',
                    background: currentPage === 1 ? colors.swatch : 'transparent',
                    color: currentPage === 1 ? '#ffffff' : (isLight ? '#334155' : '#94a3b8'),
                    fontSize: '0.72rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    boxShadow: currentPage === 1 ? `0 0 10px ${colors.cssGlow}` : 'none',
                    transition: 'all 0.15s ease-out',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.3rem'
                  }}
                >
                  <FileText size={11} />
                  <span>Page 1: Experience</span>
                </button>

                <button
                  type="button"
                  onClick={() => handlePageChange(2)}
                  style={{
                    padding: '0.25rem 0.75rem',
                    borderRadius: '20px',
                    border: 'none',
                    background: currentPage === 2 ? colors.swatch : 'transparent',
                    color: currentPage === 2 ? '#ffffff' : (isLight ? '#334155' : '#94a3b8'),
                    fontSize: '0.72rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    boxShadow: currentPage === 2 ? `0 0 10px ${colors.cssGlow}` : 'none',
                    transition: 'all 0.15s ease-out',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.3rem'
                  }}
                >
                  <Code size={11} />
                  <span>Page 2: Projects</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage >= totalPages}
                className="btn btn-ghost btn-sm"
                style={{
                  padding: '0.2rem 0.45rem',
                  fontSize: '0.72rem',
                  opacity: currentPage >= totalPages ? 0.35 : 1,
                  cursor: currentPage >= totalPages ? 'not-allowed' : 'pointer',
                  color: colors.cssColor
                }}
                title="Next Resume Page (PageDown or 2)"
              >
                <ChevronRight size={16} />
              </button>
            </div>

            {/* 3D WebGL Holographic Scanner Scene (100% Unobstructed) */}
            <div 
              style={{ width: '100%', height: '580px' }}
            >
              <BackgroundResumeScanner3D 
                standalone={true} 
                interactive={true} 
                theme={theme}
                visualMode={visualMode}
                candidateName={candidateName}
                domainName={domainTitle}
                customSkills={extractedSkills}
                structuredResume={structuredResume}
                analysis={analysis}
                selectedSectionId={selectedSectionId}
                onSelectSection={handleSelectSection}
                detectedSections={detectedSections}
                laserBurstTrigger={laserTrigger}
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={handlePageChange}
              />
            </div>
          </div>

          {/* DEDICATED SECTION DEEP-DIVE & AI OPTIMIZER CARD (Placed cleanly below canvas to avoid ANY overlap!) */}
          {selectedSectionId && activeSection && (
            <div 
              className="glass-card"
              style={{
                padding: '1.25rem 1.5rem',
                borderRadius: '14px',
                background: isLight 
                  ? 'linear-gradient(135deg, rgba(255, 255, 255, 0.98) 0%, rgba(240, 249, 255, 0.95) 100%)' 
                  : 'linear-gradient(135deg, rgba(15, 23, 42, 0.98) 0%, rgba(8, 14, 34, 0.95) 100%)',
                border: `1.5px solid ${colors.cssColor}`,
                boxShadow: `0 8px 30px rgba(0, 0, 0, 0.25), 0 0 20px ${colors.cssGlow}`,
                animation: 'slideUp 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.85rem'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.6rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                  <div style={{ 
                    width: '32px', 
                    height: '32px', 
                    borderRadius: '8px', 
                    background: colors.swatch, 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'center', 
                    color: '#ffffff',
                    boxShadow: `0 0 12px ${colors.cssGlow}`
                  }}>
                    {getSectionIcon(activeSection.iconName, 16)}
                  </div>
                  <div>
                    <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                      {activeSection.originalTitle}
                    </h3>
                    <span style={{ fontSize: '0.72rem', color: colors.cssColor, fontWeight: 700 }}>
                      {activeSection.stat} • Section Health Grade: A+
                    </span>
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <button
                    type="button"
                    onClick={() => copySectionContent((activeSection.previewItems || []).join('\n'))}
                    className="btn btn-secondary btn-sm"
                    style={{ fontSize: '0.74rem', padding: '0.35rem 0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}
                  >
                    {copiedText ? <Check size={13} color="#10b981" /> : <Copy size={13} />}
                    <span>{copiedText ? 'Copied to Clipboard!' : 'Copy Section Text'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => React.startTransition(() => onNavigateToResume?.())}
                    className="btn btn-primary btn-sm"
                    style={{ 
                      fontSize: '0.74rem', 
                      padding: '0.35rem 0.85rem', 
                      background: colors.swatch, 
                      border: 'none', 
                      color: '#ffffff', 
                      display: 'inline-flex', 
                      alignItems: 'center', 
                      gap: '0.35rem',
                      boxShadow: `0 0 12px ${colors.cssGlow}`
                    }}
                  >
                    <span>Edit in AI Resume Studio</span>
                    <ArrowRight size={13} />
                  </button>
                </div>
              </div>

              {/* Extracted rich structured content snippet */}
              <div style={{ 
                background: isLight ? 'rgba(241, 245, 249, 0.95)' : 'rgba(0, 0, 0, 0.45)', 
                padding: '0.95rem 1.15rem', 
                borderRadius: '10px', 
                fontSize: '0.82rem', 
                color: isLight ? '#1e293b' : '#e2e8f0',
                maxHeight: '160px',
                overflowY: 'auto',
                lineHeight: 1.55,
                border: `1px solid ${isLight ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.08)'}`
              }}>
                {activeSection.id === 'skills' ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                      {((activeSection.rawItems?.skills || activeSection.previewItems) as string[]).map((sk: string, idx: number) => (
                        <span 
                          key={idx} 
                          style={{
                            background: colors.accentBg,
                            border: `1px solid ${colors.cssColor}`,
                            color: isLight ? '#0f172a' : '#f8fafc',
                            padding: '0.2rem 0.5rem',
                            borderRadius: '6px',
                            fontSize: '0.74rem',
                            fontWeight: 700,
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '0.25rem'
                          }}
                        >
                          <CheckCircle2 size={11} color={colors.cssColor} />
                          {sk}
                        </span>
                      ))}
                    </div>
                  </div>
                ) : activeSection.id === 'experience' || activeSection.id === 'internship' ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
                    {(Array.isArray(activeSection.rawItems) ? activeSection.rawItems : []).map((exp: any, idx: number) => {
                      const companyName = exp.company || exp.company_or_org;
                      return (
                        <div key={idx} style={{ borderLeft: `2px solid ${colors.cssColor}`, paddingLeft: '0.65rem' }}>
                          <div style={{ fontWeight: 800, color: isLight ? '#0f172a' : '#f8fafc', fontSize: '0.85rem' }}>
                            {exp.role || 'Role'} 
                            {companyName ? <span style={{ color: colors.cssColor, fontWeight: 600 }}> @ {companyName}</span> : null}
                            {exp.duration ? <span style={{ color: 'var(--text-muted)', fontSize: '0.72rem', marginLeft: '0.4rem' }}>({exp.duration})</span> : null}
                          </div>
                          {(exp.bullets || exp.highlights || []).slice(0, 3).map((b: string, bIdx: number) => (
                            <div key={bIdx} style={{ fontSize: '0.78rem', color: isLight ? '#334155' : '#cbd5e1', marginTop: '0.2rem' }}>
                              • {b}
                            </div>
                          ))}
                        </div>
                      );
                    })}
                  </div>
                ) : activeSection.id === 'projects' ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
                    {(Array.isArray(activeSection.rawItems) ? activeSection.rawItems : []).map((prj: any, idx: number) => (
                      <div key={idx} style={{ borderLeft: `2px solid ${colors.cssColor}`, paddingLeft: '0.65rem' }}>
                        <div style={{ fontWeight: 800, color: isLight ? '#0f172a' : '#f8fafc', fontSize: '0.85rem' }}>
                          {prj.title || 'Project'}
                          {(prj.technologies || prj.key_technologies) && (prj.technologies || prj.key_technologies).length > 0 ? (
                            <span style={{ color: colors.cssColor, fontSize: '0.72rem', marginLeft: '0.4rem', fontWeight: 600 }}>
                              [{(prj.technologies || prj.key_technologies).slice(0, 4).join(', ')}]
                            </span>
                          ) : null}
                        </div>
                        {prj.description && (
                          <div style={{ fontSize: '0.78rem', color: isLight ? '#334155' : '#cbd5e1', marginTop: '0.2rem' }}>
                            {prj.description}
                          </div>
                        )}
                        {(prj.bullets || []).filter((b: string) => b !== prj.description).slice(0, 2).map((b: string, bIdx: number) => (
                          <div key={bIdx} style={{ fontSize: '0.76rem', color: isLight ? '#475569' : '#94a3b8', marginTop: '0.15rem' }}>
                            ▶ {b}
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                ) : activeSection.id === 'education' ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.55rem' }}>
                    {(Array.isArray(activeSection.rawItems) ? activeSection.rawItems : []).map((edu: any, idx: number) => (
                      <div key={idx} style={{ borderLeft: `2px solid ${colors.cssColor}`, paddingLeft: '0.65rem' }}>
                        <div style={{ fontWeight: 800, color: isLight ? '#0f172a' : '#f8fafc', fontSize: '0.85rem' }}>
                          {edu.degree || 'Degree Qualification'} {edu.field_of_study ? `in ${edu.field_of_study}` : ''}
                        </div>
                        <div style={{ color: colors.cssColor, fontSize: '0.75rem', fontWeight: 600 }}>
                          {edu.institution ? edu.institution : ''}
                          {edu.end_year || edu.start_year || edu.year ? ` • ${edu.end_year || edu.start_year || edu.year}` : ''}
                          {edu.grade_or_cgpa ? ` • Grade: ${edu.grade_or_cgpa}` : ''}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : activeSection.id === 'certifications' ? (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.45rem' }}>
                    {(Array.isArray(activeSection.rawItems) ? activeSection.rawItems : []).map((c: any, idx: number) => (
                      <div key={idx} style={{ background: colors.accentBg, border: `1px solid ${colors.cssColor}`, padding: '0.35rem 0.65rem', borderRadius: '8px', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                        <Award size={14} color={colors.cssColor} />
                        <div>
                          <div style={{ fontWeight: 700, fontSize: '0.78rem', color: isLight ? '#0f172a' : '#f8fafc' }}>{c.name || 'Certificate'}</div>
                          {c.issuer ? <div style={{ fontSize: '0.68rem', color: colors.cssColor, fontWeight: 600 }}>{c.issuer}{c.year ? ` • ${c.year}` : ''}</div> : null}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                    {(activeSection.previewItems && activeSection.previewItems.length > 0) ? (
                      activeSection.previewItems.map((item, idx) => (
                        <div key={idx} style={{ fontSize: '0.8rem', color: isLight ? '#1e293b' : '#e2e8f0' }}>
                          • {item}
                        </div>
                      ))
                    ) : (
                      <span style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Section details parsed from authoritative resume facts.</span>
                    )}
                  </div>
                )}
              </div>

              {/* Actionable AI Optimization Tip */}
              <div style={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: '0.5rem', 
                fontSize: '0.76rem', 
                color: colors.cssColor, 
                background: colors.accentBg, 
                padding: '0.5rem 0.85rem', 
                borderRadius: '8px', 
                border: `1px solid ${colors.cssGlow}` 
              }}>
                <Sparkles size={14} style={{ flexShrink: 0 }} />
                <span><strong>AI ATS Recommendation:</strong> {getSectionRecommendation(activeSection.id)}</span>
              </div>
            </div>
          )}

        </div>

        {/* Right Column: Neural ATS Rating & Telemetry */}
        <div className={`glass-card hologram-col-right ${activeSideDrawer === 'ats' ? 'hologram-drawer-open' : ''}`} style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
              Neural ATS Rating
            </h3>
            <span 
              className="badge" 
              style={{ 
                fontSize: '0.65rem', 
                background: atsTierInfo.bg, 
                color: atsTierInfo.color, 
                border: `1px solid ${atsTierInfo.borderColor}`,
                fontWeight: 700 
              }}
              title={atsTierInfo.description}
            >
              {atsTierInfo.tier}
            </span>
          </div>

          {/* Big Circular Score Dial with active theme color */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '0.5rem 0' }}>
            <div style={{
              width: '115px',
              height: '115px',
              borderRadius: '50%',
              background: `conic-gradient(${colors.cssColor} 0% ${qualityScore}%, rgba(255, 255, 255, 0.08) ${qualityScore}% 100%)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: `0 0 20px ${colors.cssGlow}`
            }}>
              <div style={{
                width: '92px',
                height: '92px',
                borderRadius: '50%',
                backgroundColor: isLight ? '#ffffff' : 'var(--bg-secondary)',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: isLight ? '0 2px 8px rgba(0,0,0,0.06)' : 'none'
              }}>
                <span style={{ fontSize: '1.75rem', fontWeight: 800, color: colors.cssColor, lineHeight: 1 }}>
                  {qualityScore}
                </span>
                <span style={{ fontSize: '0.65rem', color: isLight ? '#64748b' : 'var(--text-muted)', fontWeight: 600 }}>/ 100 ATS</span>
              </div>
            </div>
            <span style={{ fontSize: '0.72rem', color: atsTierInfo.color, fontWeight: 700, marginTop: '0.4rem' }}>
              {atsTierInfo.label}
            </span>
          </div>

          {/* Sub-Score Progress Bars from Analysis */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.725rem', marginBottom: '0.2rem' }}>
                <span style={{ color: 'var(--text-secondary)', fontWeight: 600 }}>Content Impact (STAR)</span>
                <span style={{ color: colors.cssColor, fontWeight: 700 }}>
                  {dynamicATS.score_breakdown.content_impact}%
                </span>
              </div>
              <div style={{ width: '100%', height: '5px', background: isLight ? 'rgba(0, 0, 0, 0.08)' : 'rgba(255, 255, 255, 0.06)', borderRadius: '3px', overflow: 'hidden' }}>
                <div style={{ width: `${dynamicATS.score_breakdown.content_impact}%`, height: '100%', background: colors.swatch }} />
              </div>
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.725rem', marginBottom: '0.2rem' }}>
                <span style={{ color: 'var(--text-secondary)', fontWeight: 600 }}>Skill Density</span>
                <span style={{ color: colors.cssSecondary, fontWeight: 700 }}>
                  {dynamicATS.score_breakdown.skill_density}%
                </span>
              </div>
              <div style={{ width: '100%', height: '5px', background: isLight ? 'rgba(0, 0, 0, 0.08)' : 'rgba(255, 255, 255, 0.06)', borderRadius: '3px', overflow: 'hidden' }}>
                <div style={{ width: `${dynamicATS.score_breakdown.skill_density}%`, height: '100%', background: colors.swatch }} />
              </div>
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.725rem', marginBottom: '0.2rem' }}>
                <span style={{ color: 'var(--text-secondary)', fontWeight: 600 }}>Formatting Clarity</span>
                <span style={{ color: colors.cssColor, fontWeight: 700 }}>
                  {dynamicATS.score_breakdown.formatting_clarity}%
                </span>
              </div>
              <div style={{ width: '100%', height: '5px', background: isLight ? 'rgba(0, 0, 0, 0.08)' : 'rgba(255, 255, 255, 0.06)', borderRadius: '3px', overflow: 'hidden' }}>
                <div style={{ width: `${dynamicATS.score_breakdown.formatting_clarity}%`, height: '100%', background: colors.swatch }} />
              </div>
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.725rem', marginBottom: '0.2rem' }}>
                <span style={{ color: 'var(--text-secondary)', fontWeight: 600 }}>Structure & Header</span>
                <span style={{ color: colors.cssSecondary, fontWeight: 700 }}>
                  {dynamicATS.score_breakdown.structure}%
                </span>
              </div>
              <div style={{ width: '100%', height: '5px', background: isLight ? 'rgba(0, 0, 0, 0.08)' : 'rgba(255, 255, 255, 0.06)', borderRadius: '3px', overflow: 'hidden' }}>
                <div style={{ width: `${dynamicATS.score_breakdown.structure}%`, height: '100%', background: colors.swatch }} />
              </div>
            </div>
          </div>

          <div style={{ marginTop: 'auto', display: 'flex', flexDirection: 'column', gap: '0.5rem', paddingTop: '0.75rem', borderTop: isLight ? '1px solid rgba(0, 0, 0, 0.08)' : '1px solid rgba(255, 255, 255, 0.05)' }}>
            <button 
              onClick={() => React.startTransition(() => onNavigateToRoadmap?.())}
              className="btn btn-emerald btn-sm" 
              style={{ width: '100%', fontSize: '0.75rem', background: colors.swatch, border: 'none', color: '#ffffff' }}
            >
              Bridge Skill Gaps in Roadmap →
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

export const HologramScannerStage = React.memo(HologramScannerStageComponent);
