import React, { useState } from 'react';
import { jobsApi } from '../services/api';
import type { ManualJobMatchResult } from '../types';
import { 
  X, CheckCircle2, AlertTriangle, 
  Sparkles, Zap, FileSearch
} from 'lucide-react';

interface ManualJobMatchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ManualJobMatchModal: React.FC<ManualJobMatchModalProps> = ({ isOpen, onClose }) => {
  const [title, setTitle] = useState('');
  const [company, setCompany] = useState('');
  const [jobUrl, setJobUrl] = useState('');
  const [pastedDescription, setPastedDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ManualJobMatchResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pastedDescription.trim() && !jobUrl.trim()) {
      setError('Please paste a job description or provide an accessible posting URL.');
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const res = await jobsApi.matchExternalJob({
        title: title.trim() || undefined,
        company: company.trim() || undefined,
        job_url: jobUrl.trim() || undefined,
        pasted_description: pastedDescription.trim() || undefined
      });
      setResult(res);
    } catch (err: any) {
      setError(err?.message || 'Failed to analyze job matching. Please verify input.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setError(null);
  };

  return (
    <div 
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.75)',
        backdropFilter: 'blur(8px)',
        zIndex: 9999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1.25rem'
      }}
      onClick={onClose}
    >
      <div 
        className="glass-card"
        style={{
          width: '100%',
          maxWidth: '740px',
          maxHeight: '90vh',
          overflowY: 'auto',
          padding: '1.75rem',
          position: 'relative',
          background: 'var(--bg-card, #111827)',
          border: '1px solid var(--border-subtle, rgba(255, 255, 255, 0.1))',
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.7)',
          borderRadius: '16px'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '1.25rem',
            right: '1.25rem',
            background: 'rgba(255, 255, 255, 0.06)',
            border: 'none',
            borderRadius: '50%',
            width: '32px',
            height: '32px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--text-secondary, #94a3b8)',
            cursor: 'pointer'
          }}
        >
          <X size={18} />
        </button>

        {/* Modal Header */}
        <div style={{ marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.3rem' }}>
            <FileSearch size={22} color="var(--accent-cyan)" />
            <h2 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary)' }}>
              Check Any External Job Posting
            </h2>
          </div>
          <p style={{ fontSize: '0.825rem', color: 'var(--text-muted)', lineHeight: 1.4 }}>
            Directly test postings from <strong>LinkedIn, Naukri, Internshala, or Instahyre</strong>.
            Our NLP engine parses requirements from raw text and matches against your active resume.
          </p>
        </div>

        {error && (
          <div style={{ padding: '0.75rem 1rem', borderRadius: '8px', background: 'rgba(244, 63, 94, 0.1)', border: '1px solid rgba(244, 63, 94, 0.3)', color: '#fb7185', fontSize: '0.825rem', marginBottom: '1rem' }}>
            {error}
          </div>
        )}

        {!result ? (
          /* Form State */
          <form onSubmit={handleAnalyze} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.85rem' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '0.3rem' }}>
                  Target Role Title (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Backend Engineer Intern"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '0.55rem 0.8rem',
                    borderRadius: '8px',
                    border: '1px solid var(--border-subtle)',
                    backgroundColor: 'rgba(255, 255, 255, 0.04)',
                    color: 'var(--text-primary)',
                    fontSize: '0.825rem'
                  }}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '0.3rem' }}>
                  Company Name (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Acme Corp"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '0.55rem 0.8rem',
                    borderRadius: '8px',
                    border: '1px solid var(--border-subtle)',
                    backgroundColor: 'rgba(255, 255, 255, 0.04)',
                    color: 'var(--text-primary)',
                    fontSize: '0.825rem'
                  }}
                />
              </div>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '0.3rem' }}>
                Job Posting URL (Optional)
              </label>
              <input
                type="url"
                placeholder="https://www.linkedin.com/jobs/view/... or job link"
                value={jobUrl}
                onChange={(e) => setJobUrl(e.target.value)}
                style={{
                  width: '100%',
                  padding: '0.55rem 0.8rem',
                  borderRadius: '8px',
                  border: '1px solid var(--border-subtle)',
                  backgroundColor: 'rgba(255, 255, 255, 0.04)',
                  color: 'var(--text-primary)',
                  fontSize: '0.825rem'
                }}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '0.3rem' }}>
                Paste Job Description / Qualifications Text <span style={{ color: 'var(--accent-cyan)' }}>*</span>
              </label>
              <textarea
                rows={7}
                placeholder="Paste the full job requirements, skills, and qualifications here..."
                value={pastedDescription}
                onChange={(e) => setPastedDescription(e.target.value)}
                style={{
                  width: '100%',
                  padding: '0.65rem 0.85rem',
                  borderRadius: '8px',
                  border: '1px solid var(--border-subtle)',
                  backgroundColor: 'rgba(255, 255, 255, 0.04)',
                  color: 'var(--text-primary)',
                  fontSize: '0.825rem',
                  resize: 'vertical',
                  lineHeight: 1.45
                }}
                required={!jobUrl}
              />
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem' }}>
              <button type="button" onClick={onClose} className="btn btn-secondary btn-sm">
                Cancel
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="btn btn-primary btn-sm"
                style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}
              >
                {isLoading ? (
                  <>
                    <Zap size={14} className="animate-spin-slow" /> Analyzing Match...
                  </>
                ) : (
                  <>
                    <Sparkles size={14} /> Calculate Compatibility Score
                  </>
                )}
              </button>
            </div>
          </form>
        ) : (
          /* Result State */
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            {/* Top Score Banner */}
            <div style={{ padding: '1.25rem', background: 'rgba(56, 189, 248, 0.06)', borderRadius: '12px', border: '1px solid rgba(56, 189, 248, 0.25)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
              <div>
                <span className="badge badge-cyan" style={{ fontSize: '0.7rem', marginBottom: '0.3rem' }}>
                  {result.domain} • {result.experience_level}
                </span>
                <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                  {result.title}
                </h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--accent-cyan)', fontWeight: 600 }}>
                  {result.company}
                </p>
              </div>

              <div style={{ textAlign: 'right' }}>
                <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Compatibility Score</span>
                <div style={{ fontSize: '1.8rem', fontWeight: 900, color: result.match_score >= 80 ? 'var(--accent-emerald)' : result.match_score >= 60 ? 'var(--accent-cyan)' : 'var(--accent-amber)' }}>
                  {result.match_score}%
                </div>
              </div>
            </div>

            {/* Extracted Required Skills */}
            <div style={{ padding: '1rem', background: 'rgba(255, 255, 255, 0.02)', borderRadius: '12px', border: '1px solid var(--border-subtle)' }}>
              <h4 style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.6rem' }}>
                NLP Extracted Core Skills ({result.extracted_skills.length})
              </h4>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                {result.extracted_skills.map((s, idx) => (
                  <span key={idx} className="badge badge-secondary" style={{ fontSize: '0.7rem' }}>
                    {s}
                  </span>
                ))}
              </div>
            </div>

            {/* Matched vs Missing Skills */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
              <div style={{ padding: '1rem', background: 'rgba(16, 185, 129, 0.05)', borderRadius: '12px', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.5rem' }}>
                  <CheckCircle2 size={15} color="var(--accent-emerald)" />
                  <h4 style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--accent-emerald)' }}>
                    Verified In Your Resume ({result.matched_skills.length})
                  </h4>
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                  {result.matched_skills.map((s, idx) => (
                    <span key={idx} className="badge" style={{ backgroundColor: 'rgba(16, 185, 129, 0.15)', color: '#34d399', fontSize: '0.72rem' }}>
                      ✓ {s.skill_name}
                    </span>
                  ))}
                </div>
              </div>

              <div style={{ padding: '1rem', background: 'rgba(245, 158, 11, 0.05)', borderRadius: '12px', border: '1px solid rgba(245, 158, 11, 0.2)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.5rem' }}>
                  <AlertTriangle size={15} color="var(--accent-amber)" />
                  <h4 style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--accent-amber)' }}>
                    Missing Skill Gaps ({result.missing_skills.length})
                  </h4>
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                  {result.missing_skills.map((s, idx) => (
                    <span key={idx} className="badge" style={{ backgroundColor: 'rgba(245, 158, 11, 0.12)', color: '#fbbf24', fontSize: '0.72rem' }}>
                      • {s.skill_name}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Narrative & Preparation */}
            <div style={{ padding: '1rem', background: 'rgba(255, 255, 255, 0.03)', borderRadius: '12px', border: '1px solid var(--border-subtle)' }}>
              <h4 style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--accent-cyan)', marginBottom: '0.4rem' }}>
                AI Compatibility Summary
              </h4>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', lineHeight: 1.45, marginBottom: '0.6rem' }}>
                {result.summary}
              </p>
              <ul style={{ margin: 0, paddingLeft: '1.2rem', fontSize: '0.76rem', color: 'var(--text-muted)', display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                {result.recommended_action_plan.map((act, idx) => (
                  <li key={idx}>{act}</li>
                ))}
              </ul>
            </div>

            {/* Modal Actions */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '0.5rem' }}>
              <button onClick={handleReset} className="btn btn-secondary btn-sm">
                ← Check Another Posting
              </button>
              <button onClick={onClose} className="btn btn-primary btn-sm">
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
