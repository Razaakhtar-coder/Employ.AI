import type { DomainPhaseVideoMap } from './domainYouTubeData';

// ============================================================================
// Core Engineering Co-Domain 5-Phase YouTube Registry
// Covers Civil, Mechanical, Electrical, Robotics, Chemical, Biotech, Marine & Aero
// Phase 0: Foundations, Physical Principles & CAD/Specs
// Phase 1: Core Tooling, Modeling, Circuitry & Simulation
// Phase 2: Advanced Design, Load Stress, Optimization & Compliance
// Phase 3: Flagship Capstone, Multi-Discipline Prototype & Build
// Phase 4: Technical Screening, Industrial Viva & Placement Prep
// ============================================================================

export const CORE_ENGINEERING_YOUTUBE_REGISTRY: Record<string, DomainPhaseVideoMap> = {
  // --------------------------------------------------------------------------
  // CIVIL: STAAD.Pro 3D Space Frame & Seismic Design
  // --------------------------------------------------------------------------
  'civ-staad': {
    0: [{
      id: "civ-staad-p0-basics",
      title: "STAAD.Pro Tutorial for Beginners: Space Frame Geometry & Node Modeling",
      youtube_video_id: "_oaUwpuvzDs",
      youtube_url: "https://www.youtube.com/watch?v=_oaUwpuvzDs",
      fallback_video_id: "Jas4CJuD-a8",
      search_query: "Bentley STAAD Pro Space Frame Modeling Tutorial for Beginners",
      channel_name: "ICON CAD",
      duration: "25:30",
      difficulty: "Beginner",
      topic_focus: "Node Generation, Beam Elements, Member Offsets & Material Constants",
      key_takeaways: [
        "Coordinate systems: Global vs Local axis orientation for structural elements",
        "Generating 3D multi-story space frame grids using Structure Wizard",
        "Assigning prismatic property sections (concrete columns, beams, steel trusses)",
        "Applying boundary support conditions: Fixed, pinned, and spring foundations"
      ]
    }],
    1: [{
      id: "civ-staad-p1-loads-seismic",
      title: "Load Combinations & IS 1893 / ASCE 7 Seismic Response Spectrum in STAAD",
      youtube_video_id: "6w0S3K8cpmA",
      youtube_url: "https://www.youtube.com/watch?v=6w0S3K8cpmA",
      fallback_video_id: "cBFwyK6qobo",
      search_query: "STAAD Pro Seismic Analysis IS 1893 Response Spectrum Wind Loads",
      channel_name: "Civil Engineering Hub",
      duration: "28:45",
      difficulty: "Intermediate",
      topic_focus: "Dead Loads, Live Loads, Wind Loads & Dynamic Seismic Calculations",
      key_takeaways: [
        "Generating automatic primary load cases: Dead load, live load, and roof live load",
        "Seismic zone factors, importance factors, and fundamental natural periods",
        "Modal analysis and Eigenvalue extraction for dynamic modal mass participation (>90%)",
        "Defining standard limit state load combinations for serviceability and strength"
      ]
    }],
    2: [{
      id: "civ-staad-p2-design-optimization",
      title: "Concrete Beam & Column Design Optimization to IS 456 / ACI 318 in STAAD",
      youtube_video_id: "JcB7QAFdMI0",
      youtube_url: "https://www.youtube.com/watch?v=JcB7QAFdMI0",
      fallback_video_id: "-K7NllM-y-c",
      search_query: "STAAD Pro Concrete Design IS 456 ACI 318 Reinforcement details",
      channel_name: "Structural Analysis Pro",
      duration: "24:15",
      difficulty: "Advanced",
      topic_focus: "Bending Moment Envelopes, Shear Force Diagrams & Rebar Optimization",
      key_takeaways: [
        "Interpreting bending moment (BM) and shear force (SF) envelopes across spans",
        "Automated reinforcement percentage calculations and deflection limit checks",
        "Torsion and shear link detailing according to ductility codes (IS 13920)",
        "Checking Unity Check ratios and section adequacy to prevent over-reinforcement"
      ]
    }],
    3: [{
      id: "civ-staad-p3-highrise-capstone",
      title: "High-Rise G+15 Commercial Building Structural Design Capstone in STAAD",
      youtube_video_id: "IONq0phpb3Y",
      youtube_url: "https://www.youtube.com/watch?v=IONq0phpb3Y",
      fallback_video_id: "RsOtM0wD0nY",
      search_query: "STAAD Pro High Rise G+15 Building Structural Design Full Capstone",
      channel_name: "Civil Engineering Studio",
      duration: "35:20",
      difficulty: "Advanced",
      topic_focus: "Shear Wall Core Modeling, P-Delta Second Order Analysis & Foundation Export",
      key_takeaways: [
        "Modeling reinforced concrete lift core shear walls using surface plate elements",
        "Second-order P-Delta geometric nonlinearity under extreme wind lateral loads",
        "Exporting support column reaction loads to STAAD Foundation Advanced",
        "Compiling comprehensive engineering structural calculation reports and BOQs"
      ]
    }],
    4: [{
      id: "civ-staad-p4-structural-interview",
      title: "Structural Design Engineering Placement Interview Screening & IS Code Viva",
      youtube_video_id: "beri0tNTBNc",
      youtube_url: "https://www.youtube.com/watch?v=beri0tNTBNc",
      fallback_video_id: "UV88zFdA3J8",
      search_query: "Structural Engineer Technical Interview Questions STAAD Pro IS 456",
      channel_name: "The Institute of Construction Management",
      duration: "31:10",
      difficulty: "Placement",
      topic_focus: "First-Principle Deflections, Moment Distribution & Structural Viva",
      key_takeaways: [
        "Explaining moment distribution, slope deflection, and stiffness matrix equations",
        "Answering critical interview questions on soft-story failures and torsion irregularity",
        "Interpreting structural failure modes and detailing ductile detailing standards",
        "Acing technical interviews at Larsen & Toubro, Tata Projects, and AECOM"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // CIVIL: Autodesk Revit BIM Modeling
  // --------------------------------------------------------------------------
  'civ-revit': {
    0: [{
      id: "civ-revit-p0-bim-basics",
      title: "Autodesk Revit BIM Architecture & Structure Complete Beginner Tutorial",
      youtube_video_id: "8rHcFeCGyOU",
      youtube_url: "https://www.youtube.com/watch?v=8rHcFeCGyOU",
      fallback_video_id: "chom9hiewXI",
      search_query: "Autodesk Revit Complete Beginner Course BIM Architecture Structure",
      channel_name: "BIM Studio Pro",
      duration: "29:00",
      difficulty: "Beginner",
      topic_focus: "Levels, Grids, Parametric Walls, Floors, Structural Columns & Families",
      key_takeaways: [
        "BIM parametric modeling philosophy vs 2D CAD drafting",
        "Setting up datum levels, elevation views, and structural grid networks",
        "Placing architectural and structural walls with composite layer assemblies",
        "Understanding Revit Family categories, types, and instance parameters"
      ]
    }],
    1: [{
      id: "civ-revit-p1-structural-reinforcement",
      title: "Revit Structural Modeling: Rebar Detailing, Beams, Slabs & Schedules",
      youtube_video_id: "5XswcSPnmDg",
      youtube_url: "https://www.youtube.com/watch?v=5XswcSPnmDg",
      fallback_video_id: "KlK6ESZjvOM",
      search_query: "Revit Structure 3D Rebar Detailing Beams Columns Slabs Schedule",
      channel_name: "PTS CAD EXPERT",
      duration: "27:15",
      difficulty: "Intermediate",
      topic_focus: "3D Rebar Placement, Bar Bending Schedules (BBS) & Tagging",
      key_takeaways: [
        "Adding structural framing members, concrete slab edges, and foundation footings",
        "Placing 3D reinforcing rebar shape families in beams, columns, and slabs",
        "Generating automated Bar Bending Schedules (BBS) with cut lengths and tonnages",
        "Creating structural drafting sheets, multi-view viewports, and callouts"
      ]
    }],
    2: [{
      id: "civ-revit-p2-clash-detection",
      title: "BIM Coordination & Clash Detection: Navisworks Manage & Revit",
      youtube_video_id: "zDfn30BTt3o",
      youtube_url: "https://www.youtube.com/watch?v=zDfn30BTt3o",
      fallback_video_id: "l489GxRcB3E",
      search_query: "Navisworks Clash Detection Revit Coordination MEP Structure",
      channel_name: "BIM Coordination Hub",
      duration: "24:40",
      difficulty: "Advanced",
      topic_focus: "Federated BIM Models, Hard vs Soft Clashes & Clash Matrix",
      key_takeaways: [
        "Exporting NWC files from Revit and federating Architecture, Structure, and MEP models",
        "Setting up Clash Detective rules and tolerance thresholds in Navisworks Manage",
        "Categorizing and resolving structural beam penetrations vs HVAC duct routing",
        "Assigning clash reports to engineering disciplines with BCF issue tracking"
      ]
    }],
    3: [{
      id: "civ-revit-p3-4d-scheduling",
      title: "4D Construction Simulation & Phasing with Revit and Navisworks TimeLiner",
      youtube_video_id: "_WLscRCMd6A",
      youtube_url: "https://www.youtube.com/watch?v=_WLscRCMd6A",
      fallback_video_id: "MAzn5stjSzM",
      search_query: "Navisworks TimeLiner 4D Construction Simulation Revit Phasing",
      channel_name: "How To BIM",
      duration: "26:10",
      difficulty: "Advanced",
      topic_focus: "Linking MS Project/Primavera to 3D Geometry, Construction Phasing",
      key_takeaways: [
        "Assigning Construction Phases (Demolition, Phase 1, Phase 2) in Revit elements",
        "Importing construction schedules (CSV / Primavera XML) into Navisworks TimeLiner",
        "Automating element-to-task attachment using Selection Sets and search rules",
        "Exporting 4D construction milestone animation videos for stakeholder review"
      ]
    }],
    4: [{
      id: "civ-revit-p4-bim-interview",
      title: "BIM Engineer & Revit Coordinator Placement Interview Screening Viva",
      youtube_video_id: "bIzMvLwwRBM",
      youtube_url: "https://www.youtube.com/watch?v=bIzMvLwwRBM",
      fallback_video_id: "BAx9l25Ccqg",
      search_query: "BIM Coordinator Technical Interview Questions Revit Navisworks ISO 19650",
      channel_name: "BIM Academy Global",
      duration: "30:00",
      difficulty: "Placement",
      topic_focus: "ISO 19650 BIM Standards, Level of Development (LOD 100-500) & Viva",
      key_takeaways: [
        "Explaining ISO 19650 information management workflows and Common Data Environment (CDE)",
        "Differentiating Level of Development (LOD 100 conceptual through LOD 400 fabrication)",
        "Optimizing Revit model performance: Purging unused families and worksharing protocols",
        "Acing BIM Coordinator interviews at global infrastructure consultancies (AECOM, WSP, Atkins)"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // MECHANICAL: SolidWorks 3D Parametric CAD
  // --------------------------------------------------------------------------
  'mech-solidworks': {
    0: [{
      id: "mech-sw-p0-parametric-sketch",
      title: "SolidWorks Tutorial for Beginners: Parametric Sketching & Extrusions",
      youtube_video_id: "6spVzflSubI",
      youtube_url: "https://www.youtube.com/watch?v=6spVzflSubI",
      fallback_video_id: "Ulttc_2p4DY",
      search_query: "SolidWorks Tutorial for Beginners Parametric Sketching Extrude Cut",
      channel_name: "CAD Cam Tutorials",
      duration: "26:30",
      difficulty: "Beginner",
      topic_focus: "2D Constraint Relations, Fully Defined Sketches & Extrude Boss/Cut",
      key_takeaways: [
        "Applying geometric constraints: Coincident, tangent, concentric, horizontal, vertical",
        "Ensuring 100% fully defined sketches with smart dimensioning to prevent model drift",
        "Creating solid base features with Extruded Boss/Base and Revolved Boss/Base",
        "Material properties assignment and mass calculation inquiries"
      ]
    }],
    1: [{
      id: "mech-sw-p1-complex-assemblies",
      title: "SolidWorks Mechanical Assembly Design: Mates, Gears & Exploded Views",
      youtube_video_id: "fA-IYnzwjAE",
      youtube_url: "https://www.youtube.com/watch?v=fA-IYnzwjAE",
      fallback_video_id: "7szznDaQgSk",
      search_query: "SolidWorks Assembly Tutorial Standard Mechanical Mates Exploded View",
      channel_name: "SolidWorks Official",
      duration: "28:15",
      difficulty: "Intermediate",
      topic_focus: "Standard Mates, Mechanical Gear/Cam Mates & Exploded Animations",
      key_takeaways: [
        "Bottom-up vs top-down assembly modeling strategies in SolidWorks",
        "Applying standard mates: Coincident, parallel, distance, and angle limits",
        "Simulating mechanical kinematic linkages with gear, rack & pinion, and cam mates",
        "Creating exploded views, Bill of Materials (BOM), and balloon annotations"
      ]
    }],
    2: [{
      id: "mech-sw-p2-sheet-metal-surfaces",
      title: "SolidWorks Sheet Metal & Complex Curvature Surfacing Masterclass",
      youtube_video_id: "R114WrrSiLo",
      youtube_url: "https://www.youtube.com/watch?v=R114WrrSiLo",
      fallback_video_id: "dakMFFTixtw",
      search_query: "SolidWorks Sheet Metal K Factor Lofted Surface Masterclass",
      channel_name: "CAD CAM Solutions",
      duration: "25:40",
      difficulty: "Advanced",
      topic_focus: "K-Factor Bend Tables, Base Flanges, Lofted Surfaces & Boundary Cuts",
      key_takeaways: [
        "Sheet metal parameters: Bend radius, bend relief, and K-Factor calculation",
        "Generating flat patterns for CNC laser cutting and press brake bending",
        "Curvature-continuous surface modeling: G0, G1, and G2 tangent continuity",
        "Thickening surfaces into watertight solid manufacturing bodies"
      ]
    }],
    3: [{
      id: "mech-sw-p3-engine-capstone",
      title: "Single-Cylinder IC Engine 3D Modeling & Kinematic Motion Capstone",
      youtube_video_id: "ZRNbVd_lAns",
      youtube_url: "https://www.youtube.com/watch?v=ZRNbVd_lAns",
      fallback_video_id: "pBczBrM7uq0",
      search_query: "SolidWorks IC Engine Modeling Assembly Motion Analysis Capstone",
      channel_name: "Design Masterclass",
      duration: "38:00",
      difficulty: "Advanced",
      topic_focus: "Piston, Connecting Rod, Crankshaft, Interference Detection & Motion Study",
      key_takeaways: [
        "Parametric modeling of cylinder block, crankshaft, connecting rod, and piston wrist pin",
        "Running dynamic interference detection to verify zero component collision across 360 rotation",
        "Extracting piston displacement, velocity, and acceleration curves with SolidWorks Motion",
        "Generating 2D fabrication production drawings adhering to ASME Y14 standards"
      ]
    }],
    4: [{
      id: "mech-sw-p4-cswp-interview",
      title: "CSWP Certification Practice & Mechanical Design Engineer Screening Viva",
      youtube_video_id: "P3XP1ZFiiKA",
      youtube_url: "https://www.youtube.com/watch?v=P3XP1ZFiiKA",
      fallback_video_id: "8BzW9oitygE",
      search_query: "SolidWorks CSWP Certified Professional Exam Practice CAD Interview",
      channel_name: "SolidWorks Pro Academy",
      duration: "33:15",
      difficulty: "Placement",
      topic_focus: "CSWP Timed Speed Drills, Design Modification & Technical Interview Viva",
      key_takeaways: [
        "Solving CSWP Segment 1, 2, and 3 modeling challenges within strict timed limits",
        "Rapid mass property verification when dimension variables change dynamically",
        "Troubleshooting broken mate references and sketch rebuild errors under pressure",
        "Acing mechanical design engineer interviews at automotive and aerospace OEMs"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // MECHANICAL: ANSYS Structural FEA
  // --------------------------------------------------------------------------
  'mech-fea': {
    0: [{
      id: "mech-fea-p0-fundamentals",
      title: "ANSYS Workbench Static Structural FEA Tutorial for Beginners",
      youtube_video_id: "qbsx1c-R_qU",
      youtube_url: "https://www.youtube.com/watch?v=qbsx1c-R_qU",
      fallback_video_id: "vnpq5zzOS48",
      search_query: "ANSYS Workbench Static Structural FEA Tutorial for Beginners",
      channel_name: "ANSYS Learning Hub",
      duration: "24:30",
      difficulty: "Beginner",
      topic_focus: "Engineering Data, Geometry Import, Boundary Conditions & Solution",
      key_takeaways: [
        "Finite Element Analysis workflow: Pre-processing, solution, and post-processing",
        "Assigning isotropic/orthotropic material properties (Young's modulus, Poisson's ratio)",
        "Applying boundary constraints: Fixed support, frictionless, cylindrical, and remote displacement",
        "Evaluating equivalent von Mises stress, principal stresses, and total deformation"
      ]
    }],
    1: [{
      id: "mech-fea-p1-mesh-convergence",
      title: "ANSYS Meshing Mastery: Mesh Convergence, Element Quality & Sizing",
      youtube_video_id: "3Z_5doyBCg4",
      youtube_url: "https://www.youtube.com/watch?v=3Z_5doyBCg4",
      fallback_video_id: "5XwVYm-kwT4",
      search_query: "ANSYS Meshing Tutorial Mesh Convergence Element Quality Aspect Ratio",
      channel_name: "SimuTech Group",
      duration: "27:10",
      difficulty: "Intermediate",
      topic_focus: "Tetrahedral vs Hexahedral Elements, Mesh Sizing, Skewness & Orthogonal Quality",
      key_takeaways: [
        "Element types: 1D beam, 2D shell, 3D solid (tetrahedral vs structured hexahedral)",
        "Mesh metric quality indicators: Aspect ratio, skewness (<0.85), and orthogonal quality (>0.15)",
        "Executing mesh convergence studies: Refining element sizes until stress results stabilize within 3%",
        "Applying local mesh controls: Sphere of influence, inflation layers, and body sizing"
      ]
    }],
    2: [{
      id: "mech-fea-p2-modal-thermal",
      title: "ANSYS Modal Vibration & Steady-State Thermal Stress Analysis",
      youtube_video_id: "h9RzNhpYG6s",
      youtube_url: "https://www.youtube.com/watch?v=h9RzNhpYG6s",
      fallback_video_id: "yEP4XJu1K-Y",
      search_query: "ANSYS Modal Analysis Natural Frequency Resonance Thermal Stress",
      channel_name: "CAE Pro Tutorials",
      duration: "26:45",
      difficulty: "Advanced",
      topic_focus: "Natural Frequencies, Mode Shapes, Resonance & Thermal Expansion",
      key_takeaways: [
        "Extracting undamped natural frequencies and mode shapes to avoid mechanical resonance",
        "Steady-state thermal analysis: Conduction, convection film coefficients, and radiation",
        "Coupling thermal temperature fields into structural solvers to evaluate thermal stresses",
        "Assessing stress concentrations at fillets and holes with Peterson's stress concentration factors"
      ]
    }],
    3: [{
      id: "mech-fea-p3-fatigue-capstone",
      title: "Automotive Suspension Wishbone Fatigue Life & Durability FEA Capstone",
      youtube_video_id: "jxaAIkqwNbA",
      youtube_url: "https://www.youtube.com/watch?v=jxaAIkqwNbA",
      fallback_video_id: "LEHfQsu1I2Y",
      search_query: "ANSYS Fatigue Tool SN Curve Life Damage Safety Factor Capstone",
      channel_name: "Automotive Simulation Lab",
      duration: "34:00",
      difficulty: "Advanced",
      topic_focus: "S-N Wöhler Curves, Cyclic Fatigue Life, Damage Accumulation & Factor of Safety",
      key_takeaways: [
        "High-cycle fatigue analysis using the ANSYS Fatigue Tool and S-N endurance curves",
        "Goodman and Gerber mean stress correction theories for tension-compression cycles",
        "Calculating fatigue life cycles and cumulative damage factors under variable amplitude loads",
        "Iterative topology optimization: Reducing component mass by 22% while preserving stiffness"
      ]
    }],
    4: [{
      id: "mech-fea-p4-fea-interview",
      title: "FEA Simulation Engineer Technical Screening & Failure Criteria Viva",
      youtube_video_id: "7KD4s90sE9w",
      youtube_url: "https://www.youtube.com/watch?v=7KD4s90sE9w",
      fallback_video_id: "OxyQ_1i-rcM",
      search_query: "FEA Simulation Engineer Interview Questions von Mises Failure Theories",
      channel_name: "Engineering Interview Pro",
      duration: "29:30",
      difficulty: "Placement",
      topic_focus: "Tresca vs von Mises Failure Theories, Singularity vs Convergence & Viva",
      key_takeaways: [
        "First principles: Why von Mises distortion energy theory governs ductile metal yielding",
        "Distinguishing artificial stress singularities (sharp re-entrant corners) from true physical stresses",
        "Verifying FEA numerical outputs against hand calculations and beam theory equations",
        "Acing FEA simulation engineer interviews at Tesla, Bosch, Cummins, and General Electric"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // ELECTRICAL: Embedded C & ARM Cortex-M Firmware
  // --------------------------------------------------------------------------
  'ee-embedded': {
    0: [{
      id: "ee-emb-p0-cortex-basics",
      title: "Embedded C & ARM Cortex-M Architecture: Registers, Memory & GPIO",
      youtube_video_id: "qWqlkCLmZoE",
      youtube_url: "https://www.youtube.com/watch?v=qWqlkCLmZoE",
      fallback_video_id: "UbrxWbWUvdE",
      search_query: "FastBit Embedded Brain Academy ARM Cortex M Embedded C GPIO Bare Metal",
      channel_name: "FastBit Academy",
      duration: "28:10",
      difficulty: "Beginner",
      topic_focus: "Cortex-M Registers, Memory Map, Bitwise Manipulation & Bare-Metal GPIO",
      key_takeaways: [
        "ARM Cortex-M core architecture: Register bank (R0-R15), stack pointer (MSP/PSP), and PC",
        "Memory-mapped I/O: Navigating microcontroller memory maps using peripheral base addresses",
        "Bitwise manipulation operations (AND, OR, XOR, shift) in C for register configuration",
        "Writing bare-metal GPIO drivers: Clock gating (RCC), direction mode, and output data registers"
      ]
    }],
    1: [{
      id: "ee-emb-p1-interrupts-nvic",
      title: "NVIC Interrupt Handling, Timers & Hardware PWM in Embedded C",
      youtube_video_id: "chPLzpLMOV8",
      youtube_url: "https://www.youtube.com/watch?v=chPLzpLMOV8",
      fallback_video_id: "VfbW6nfG4kw",
      search_query: "ARM Cortex NVIC Interrupts Hardware Timers PWM STM32 FastBit",
      channel_name: "FastBit Academy",
      duration: "31:45",
      difficulty: "Intermediate",
      topic_focus: "Nested Vectored Interrupt Controller (NVIC), ISR Latency & Hardware Timers",
      key_takeaways: [
        "NVIC architecture: Priority grouping, preemption priority, and subpriority",
        "Writing clean Interrupt Service Routines (ISRs) and declaring shared variables as 'volatile'",
        "General-purpose hardware timers: Prescaler calculation, auto-reload register (ARR)",
        "Generating Pulse Width Modulation (PWM) signals for DC motor speed control"
      ]
    }],
    2: [{
      id: "ee-emb-p2-comm-protocols",
      title: "Serial Communication Protocols: UART, SPI & I2C Bus Driver Architecture",
      youtube_video_id: "7_RynrcHegk",
      youtube_url: "https://www.youtube.com/watch?v=7_RynrcHegk",
      fallback_video_id: "z1hVxZLoKEk",
      search_query: "UART SPI I2C Protocols Embedded C Driver Implementation FastBit",
      channel_name: "FastBit Academy",
      duration: "33:20",
      difficulty: "Advanced",
      topic_focus: "Baud Rates, Clock Polarity/Phase (CPOL/CPHA), I2C ACK/NACK & Bus Drivers",
      key_takeaways: [
        "UART: Asynchronous packet framing, start/stop bits, parity, and ring buffer DMA transfers",
        "SPI: Synchronous master-slave communication, clock polarity (CPOL), and phase (CPHA) modes",
        "I2C: Open-drain outputs, pull-up resistors, 7-bit addressing, start/stop conditions, and ACK/NACK",
        "Implementing non-blocking interrupt-driven and DMA-accelerated bus transactions"
      ]
    }],
    3: [{
      id: "ee-emb-p3-freertos-capstone",
      title: "FreeRTOS Real-Time Operating System: Tasks, Semaphores & Queue Pipelines",
      youtube_video_id: "F321087yYy4",
      youtube_url: "https://www.youtube.com/watch?v=F321087yYy4",
      fallback_video_id: "Hcf0nAXtn_0",
      search_query: "FreeRTOS Tutorial for Beginners Tasks Mutex Semaphores Message Queues",
      channel_name: "DigiKey",
      duration: "36:00",
      difficulty: "Advanced",
      topic_focus: "Preemptive Scheduling, Context Switching, Mutexes & Priority Inversion",
      key_takeaways: [
        "FreeRTOS preemptive priority-based scheduler and task control block (TCB) mechanics",
        "Inter-task communication and synchronization using FreeRTOS message queues",
        "Binary semaphores vs Mutexes: Priority inheritance to prevent priority inversion",
        "Building a multi-sensor IoT edge data logger with FreeRTOS and low-power sleep modes"
      ]
    }],
    4: [{
      id: "ee-emb-p4-embedded-interview",
      title: "Embedded Systems Firmware Engineer Placement Interview Screening Viva",
      youtube_video_id: "AMxNDfLJrg0",
      youtube_url: "https://www.youtube.com/watch?v=AMxNDfLJrg0",
      fallback_video_id: "4vgxRCcMJVA",
      search_query: "Embedded Systems Firmware Engineer Technical Interview Questions C Pointers",
      channel_name: "Embedded Pro",
      duration: "29:10",
      difficulty: "Placement",
      topic_focus: "Volatile Keyword, Function Pointers, Memory Alignment, Cache & Viva",
      key_takeaways: [
        "Explaining why 'volatile' is critical in memory-mapped I/O and multi-threaded systems",
        "Function pointers, callback mechanisms, and building state machine dispatch tables in C",
        "Memory alignment, structure padding, stack vs heap overflow debugging with JTAG/SWD",
        "Acing embedded firmware engineering interviews at Qualcomm, Texas Instruments, and Intel"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // ELECTRICAL: High-Speed Multi-Layer PCB Design (Altium)
  // --------------------------------------------------------------------------
  'ee-pcb': {
    0: [{
      id: "ee-pcb-p0-schematic-capture",
      title: "Altium Designer PCB Design for Beginners: Schematic Capture & Libraries",
      youtube_video_id: "4JJzcFkEojg",
      youtube_url: "https://www.youtube.com/watch?v=4JJzcFkEojg",
      fallback_video_id: "YTGzncKU5RY",
      search_query: "Altium Designer PCB Tutorial for Beginners Schematic Capture Library",
      channel_name: "Altium Academy",
      duration: "26:40",
      difficulty: "Beginner",
      topic_focus: "Schematic Symbols, Footprints, Component Parameters & Netlists",
      key_takeaways: [
        "Creating custom schematic component symbols and linking IPC-compliant footprints",
        "Wiring schematics, hierarchical multi-sheet design, and net label connectivity",
        "Running Electrical Rule Checks (ERC) to catch floating pins and duplicate designators",
        "Transferring schematic netlists to PCB layout with Engineering Change Orders (ECO)"
      ]
    }],
    1: [{
      id: "ee-pcb-p1-4layer-routing",
      title: "4-Layer PCB Stackup, Placement & Trace Routing in Altium Designer",
      youtube_video_id: "KNeBbkdYdRE",
      youtube_url: "https://www.youtube.com/watch?v=KNeBbkdYdRE",
      fallback_video_id: "CtxEjmoIRpI",
      search_query: "Altium 4 Layer PCB Stackup Component Placement Routing Ground Plane",
      channel_name: "Altium Academy",
      duration: "29:15",
      difficulty: "Intermediate",
      topic_focus: "Layer Stackup Manager (SIG-GND-PWR-SIG), Decoupling Caps & Routing Rules",
      key_takeaways: [
        "Standard 4-layer stackup: Signal (Top), Ground Plane (Layer 2), Power Plane, Signal (Bottom)",
        "Component floorplanning: Placing decoupling capacitors close to IC power pins",
        "Setting up Design Rule Checks (DRC): Clearance, trace width, and via sizes",
        "Routing high-current power traces vs sensitive low-noise analog sensor lines"
      ]
    }],
    2: [{
      id: "ee-pcb-p2-high-speed-impedance",
      title: "High-Speed PCB Design: Controlled Impedance, Differential Pairs & Return Paths",
      youtube_video_id: "xwrdvhm4vgw",
      youtube_url: "https://www.youtube.com/watch?v=xwrdvhm4vgw",
      fallback_video_id: "s2BomzmM5W8",
      search_query: "High Speed PCB Design Controlled Impedance Differential Pairs Return Path",
      channel_name: "Robert Feranec",
      duration: "32:00",
      difficulty: "Advanced",
      topic_focus: "50-Ohm Microstrip, 90-Ohm USB Differential Pairs & Length Tuning",
      key_takeaways: [
        "Controlled impedance calculations using dielectric constant (Er) and trace geometry",
        "Routing 90-ohm USB and 100-ohm Ethernet differential pairs with consistent intra-pair spacing",
        "Accordion serpentine length matching to prevent high-speed timing skew",
        "Preserving continuous ground reference planes to prevent EMI loop antennas"
      ]
    }],
    3: [{
      id: "ee-pcb-p3-iot-board-capstone",
      title: "STM32 Microcontroller IoT Edge Board 4-Layer PCB Design Capstone",
      youtube_video_id: "PMEpQZ90f34",
      youtube_url: "https://www.youtube.com/watch?v=PMEpQZ90f34",
      fallback_video_id: "0NcIRfdrbXQ",
      search_query: "Complete STM32 Hardware Design 4 Layer PCB Altium Capstone",
      channel_name: "Phil's Lab",
      duration: "37:30",
      difficulty: "Advanced",
      topic_focus: "Crystal Oscillator Routing, Power Management (Buck Converter) & Gerbers",
      key_takeaways: [
        "Routing sensitive high-frequency crystal oscillator lines with guard rings",
        "Switch-mode power supply (SMPS) layout: Minimizing high-di/dt current loops",
        "Thermal relief vias and copper pours for efficient heat dissipation",
        "Generating production-ready Gerber X2, drill files, and Pick-and-Place BOM files"
      ]
    }],
    4: [{
      id: "ee-pcb-p4-hardware-interview",
      title: "Hardware & PCB Design Engineer Placement Interview Screening Viva",
      youtube_video_id: "TderFrOupo4",
      youtube_url: "https://www.youtube.com/watch?v=TderFrOupo4",
      fallback_video_id: "Zfc_y1I5WcI",
      search_query: "Hardware Design Engineer Interview Questions PCB Altium EMI EMC",
      channel_name: "PCB Design Tutorials",
      duration: "28:40",
      difficulty: "Placement",
      topic_focus: "EMI/EMC Compliance, Crosstalk Reduction, Ground Bounce & Hardware Viva",
      key_takeaways: [
        "Explaining electromagnetic compatibility (EMC) and shielding techniques",
        "Root causes of crosstalk and applying the 3W rule between high-speed traces",
        "Mitigating ground bounce and power supply rail noise with ferrite beads",
        "Acing hardware design engineering interviews at Intel, NVIDIA, and Schneider Electric"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // ROBOTICS: ROS 2 Core Architecture
  // --------------------------------------------------------------------------
  'rob-ros2': {
    0: [{
      id: "rob-ros2-p0-nodes-topics",
      title: "ROS 2 (Robot Operating System) Tutorial: Nodes, Topics & Messages",
      youtube_video_id: "0AXM2_CDzDk",
      youtube_url: "https://www.youtube.com/watch?v=0AXM2_CDzDk",
      fallback_video_id: "VDotKYuKcVY",
      search_query: "ROS 2 Basics Tutorial for Beginners Nodes Topics Publishers Subscribers",
      channel_name: "StepPhase-01",
      duration: "27:15",
      difficulty: "Beginner",
      topic_focus: "ROS 2 Humble, Workspace Setup, Publisher/Subscriber Nodes & CLI",
      key_takeaways: [
        "ROS 2 architecture: DDS middleware, modular nodes, and distributed computing",
        "Creating a ROS 2 colcon workspace, packages, and CMakeLists.txt / setup.py",
        "Writing C++ and Python publisher and subscriber nodes over communication topics",
        "Using ROS 2 CLI tools: ros2 topic list, echo, hz, and node info"
      ]
    }],
    1: [{
      id: "rob-ros2-p1-services-actions",
      title: "ROS 2 Services, Custom Interfaces, Actions & Parameter Servers",
      youtube_video_id: "WzOopOkrowA",
      youtube_url: "https://www.youtube.com/watch?v=WzOopOkrowA",
      fallback_video_id: "NurWZbpJBes",
      search_query: "ROS 2 Services Actions Parameters Custom Interfaces Tutorial",
      channel_name: "Hummingbird",
      duration: "29:40",
      difficulty: "Intermediate",
      topic_focus: "Request-Response Services, Long-Running Actions with Feedback & YAML",
      key_takeaways: [
        "Implementing synchronous request-response communication with ROS 2 Services",
        "Designing long-running goal tasks with progress feedback using ROS 2 Actions",
        "Creating custom message, service, and action definition files (.msg, .srv, .action)",
        "Managing dynamic robot configuration parameters via YAML launch files"
      ]
    }],
    2: [{
      id: "rob-ros2-p2-urdf-tf2",
      title: "Robot Modeling with URDF, TF2 Coordinate Transforms & RViz 2",
      youtube_video_id: "QyvHhY4Y_Y8",
      youtube_url: "https://www.youtube.com/watch?v=QyvHhY4Y_Y8",
      fallback_video_id: "Nwr4VvJ17uM",
      search_query: "ROS 2 URDF Robot Modeling TF2 Transforms RViz Gazebo Simulation",
      channel_name: "Articulated Robotics",
      duration: "31:10",
      difficulty: "Advanced",
      topic_focus: "Links, Joints, Inertial Matrices, TF2 Tree & RViz 2 Visualizer",
      key_takeaways: [
        "Building multi-link robot models with Unified Robot Description Format (URDF / Xacro)",
        "Defining joint kinematics: Revolute, continuous, prismatic, and fixed joint limits",
        "Maintaining coordinate frame transformations using the TF2 transform library",
        "Visualizing robot state, sensor rays, and point clouds in RViz 2"
      ]
    }],
    3: [{
      id: "rob-ros2-p3-slam-nav2-capstone",
      title: "Autonomous Mobile Robot Navigation: SLAM & Nav2 Stack Capstone",
      youtube_video_id: "GSuqO0p2mIk",
      youtube_url: "https://www.youtube.com/watch?v=GSuqO0p2mIk",
      fallback_video_id: "idQb2pB-h2Q",
      search_query: "ROS 2 Nav2 Navigation Stack SLAM Autonomous Mobile Robot Capstone",
      channel_name: "Muhammad Luqman",
      duration: "38:20",
      difficulty: "Advanced",
      topic_focus: "2D LiDAR Mapping (Slam Toolbox), Costmaps, AMCL & Path Planners",
      key_takeaways: [
        "Simulating a differential-drive robot with 2D LiDAR in Gazebo Fortress",
        "Generating 2D occupancy grid maps using slam_toolbox in real-time",
        "Configuring the Nav2 navigation stack: Global planner (NavFn) and local controller (DWB)",
        "Setting up global and local costmap obstacle layers and recovery behaviors"
      ]
    }],
    4: [{
      id: "rob-ros2-p4-robotics-interview",
      title: "Robotics Software Engineer Placement Interview & Kinematics Viva",
      youtube_video_id: "uvyeTIinYiM",
      youtube_url: "https://www.youtube.com/watch?v=uvyeTIinYiM",
      fallback_video_id: "G5r5GP7d2T0",
      search_query: "Robotics Software Engineer Interview Preparation ROS 2 GreyOrange Boston Dynamics",
      channel_name: "Livedisqus",
      duration: "42:15",
      difficulty: "Placement",
      topic_focus: "DDS QoS Profiles, Inverse Kinematics, Kalman Filters & Technical Viva",
      key_takeaways: [
        "Explaining ROS 2 Quality of Service (QoS) policies: Reliability, durability, and history",
        "Solving forward and inverse kinematics using Denavit-Hartenberg (DH) parameters",
        "State estimation algorithms: Extended Kalman Filter (EKF) sensor fusion (IMU + Odom)",
        "Acing robotics software interviews at Boston Dynamics, GreyOrange, and Tesla Robotics"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // CIVIL: Reinforced Concrete Design (IS 456 / ACI 318)
  // --------------------------------------------------------------------------
  'civ-rcc': {
    0: [{
      id: "civ-rcc-p0-principles",
      title: "Reinforced Concrete Design Principles: Limit State Method & Stress-Strain Curves",
      youtube_video_id: "j7j2t88ZmXc",
      youtube_url: "https://www.youtube.com/watch?v=j7j2t88ZmXc",
      fallback_video_id: "lEn13f8i7Ho",
      search_query: "Reinforced Concrete Design Limit State IS 456 ACI 318 Stress Block",
      channel_name: "Civil TechMate",
      duration: "26:30",
      difficulty: "Beginner",
      topic_focus: "Limit State of Collapse vs Serviceability, Neutral Axis Depth & Under-Reinforced Sections",
      key_takeaways: [
        "Fundamental assumptions of limit state design for reinforced concrete",
        "Parabolic stress-strain relationship of concrete in compression (0.0035 ultimate strain)",
        "Deriving limiting depth of neutral axis (Xu,max) to ensure ductile, under-reinforced failure",
        "Partial safety factors for concrete (1.5) and reinforcing steel (1.15)"
      ]
    }],
    1: [{
      id: "civ-rcc-p1-beams-slabs",
      title: "Design of Singly & Doubly Reinforced Beams and One-Way / Two-Way Slabs",
      youtube_video_id: "Zop0L689DO8",
      youtube_url: "https://www.youtube.com/watch?v=Zop0L689DO8",
      fallback_video_id: "aQPrI7aWuVs",
      search_query: "Design of Singly Doubly Reinforced Beam Two Way Slab IS 456",
      channel_name: "Parash Joshi - Civil Construction and Tutor",
      duration: "29:15",
      difficulty: "Intermediate",
      topic_focus: "Moment of Resistance, Compression Steel, Shear Links & Torsion Detailing",
      key_takeaways: [
        "Calculating moment of resistance (Mu) for singly and doubly reinforced rectangular beams",
        "Design of vertical stirrups and bent-up bars for diagonal tension shear failure",
        "Rankine-Grashoff and IS 456 moment coefficients for two-way restrained slabs",
        "Deflection control criteria: Basic span-to-effective depth ratios and modification factors"
      ]
    }],
    2: [{
      id: "civ-rcc-p2-columns-footings",
      title: "Design of Axially & Uniaxially Loaded Columns and Isolated Footings",
      youtube_video_id: "pOIl0RVMj5c",
      youtube_url: "https://www.youtube.com/watch?v=pOIl0RVMj5c",
      fallback_video_id: "6-z5xBpNWBA",
      search_query: "Design of Reinforced Concrete Columns Isolated Footing One Way Two Way Shear",
      channel_name: "All About Structural Analysis and Design",
      duration: "31:45",
      difficulty: "Intermediate",
      topic_focus: "Short vs Slender Columns, Interaction Curves, Punching Shear & Bending in Footings",
      key_takeaways: [
        "Axial load capacity formula for short tied columns and spiral columns (5% strength boost)",
        "Constructing and reading uniaxial column interaction diagrams (P-M curves)",
        "Sizing isolated square/rectangular footings based on safe allowable soil bearing capacity",
        "Checking critical footing sections for one-way beam shear and two-way punching shear"
      ]
    }],
    3: [{
      id: "civ-rcc-p3-retaining-wall",
      title: "Cantilever Retaining Wall & Water Tank Design Capstone Project",
      youtube_video_id: "V5SmsQHJo8Q",
      youtube_url: "https://www.youtube.com/watch?v=V5SmsQHJo8Q",
      fallback_video_id: "EPSkXnzbObU",
      search_query: "Cantilever Retaining Wall Design RCC Stability Overturning Sliding",
      channel_name: "Civil Inside",
      duration: "34:20",
      difficulty: "Advanced",
      topic_focus: "Rankine Earth Pressure, Sliding/Overturning Stability, Stem Reinforcement & Shear Key",
      key_takeaways: [
        "Computing active and passive lateral earth pressures using Rankine theory",
        "Checking stability factors of safety: Overturning (>=1.5), sliding (>=1.5), soil pressure limits",
        "Curtailment of vertical flexural reinforcement along stem height to optimize rebar tonnage",
        "Designing heel and toe slab cantilever reinforcement and drainage weep holes"
      ]
    }],
    4: [{
      id: "civ-rcc-p4-rcc-interview",
      title: "RCC Structural Engineering Placement Interview & IS 456 Code Viva",
      youtube_video_id: "2Un0o4FqPbc",
      youtube_url: "https://www.youtube.com/watch?v=2Un0o4FqPbc",
      fallback_video_id: "nuDYONNdyk4",
      search_query: "RCC Design Engineer Interview Questions IS 456 Viva Civil Engineering",
      channel_name: "The Civil Engineer",
      duration: "28:50",
      difficulty: "Placement",
      topic_focus: "Development Length (Ld), Minimum Eccentricity, Ductile Detailing (IS 13920) & Viva",
      key_takeaways: [
        "Explaining bond stress, lap splices, and anchorage development length (Ld = phi*fs / 4*tau_bd)",
        "Ductile detailing rules under IS 13920: Column hoop confinement and beam-column joint rebar",
        "Defending structural drawings and calculation sheets during site engineering technical interviews",
        "Acing core RCC civil engineering recruitment tests at L&T, Tata Projects, and Shapoorji Pallonji"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // CIVIL: Geotechnical Soil Mechanics & Foundations
  // --------------------------------------------------------------------------
  'civ-geotech': {
    0: [{
      id: "civ-geo-p0-soil-properties",
      title: "Soil Mechanics First Principles: Phase Relationships & Atterberg Limits",
      youtube_video_id: "_chsHz8lrRw",
      youtube_url: "https://www.youtube.com/watch?v=_chsHz8lrRw",
      fallback_video_id: "KmzFZ4d1Zg8",
      search_query: "Soil Mechanics Phase Relationships Void Ratio Porosity Atterberg Limits USCS",
      channel_name: "Ganesh Shegar",
      duration: "23:40",
      difficulty: "Beginner",
      topic_focus: "Void Ratio, Moisture Content, Plasticity Index & Soil Classification (USCS)",
      key_takeaways: [
        "Three-phase soil diagram: Volume and weight relationships (void ratio, porosity, degree of saturation)",
        "Atterberg limits testing: Liquid limit (Casagrande cup), plastic limit, and plasticity index (PI)",
        "Classifying fine and coarse soils using Unified Soil Classification System (USCS) and A-line chart",
        "Standard compaction tests: Optimum Moisture Content (OMC) and Maximum Dry Density (MDD)"
      ]
    }],
    1: [{
      id: "civ-geo-p1-permeability-shear",
      title: "Soil Permeability, Effective Stress Principle & Mohr-Coulomb Shear Strength",
      youtube_video_id: "a33rmtNZXKg",
      youtube_url: "https://www.youtube.com/watch?v=a33rmtNZXKg",
      fallback_video_id: "rUV8KHNGP64",
      search_query: "Effective Stress Principle Mohr Coulomb Shear Strength Triaxial Test Direct Shear",
      channel_name: "Elementary Engineering",
      duration: "28:10",
      difficulty: "Intermediate",
      topic_focus: "Terzaghi's Total vs Effective Stress, Pore Water Pressure, Cohesion (c) & Friction Angle (phi)",
      key_takeaways: [
        "Terzaghi effective stress equation: sigma' = sigma - u (pore water pressure) in saturated soils",
        "Mohr-Coulomb failure envelope: Shear strength tau = c' + sigma' tan(phi')",
        "Direct shear box test vs triaxial compression test (UU, CU, and CD consolidated-drained tests)",
        "Critical hydraulic gradient and quicksand liquefaction phenomenon in cohesionless sands"
      ]
    }],
    2: [{
      id: "civ-geo-p2-consolidation-settlement",
      title: "One-Dimensional Soil Consolidation & Terzaghi Settlement Analysis",
      youtube_video_id: "l9b-VZwMY5k",
      youtube_url: "https://www.youtube.com/watch?v=l9b-VZwMY5k",
      fallback_video_id: "XKvXWL3Zt4Y",
      search_query: "Soil Consolidation Settlement Oedometer Test Compression Index Cc Overconsolidation OCR",
      channel_name: "Elementary Engineering",
      duration: "27:15",
      difficulty: "Intermediate",
      topic_focus: "Oedometer Test, Preconsolidation Pressure, OCR, Compression Index (Cc) & Time-Settlement",
      key_takeaways: [
        "Differentiating immediate elastic settlement from long-term primary consolidation settlement",
        "Interpreting e-log(p) consolidation curves: Normally consolidated vs overconsolidated clay (OCR)",
        "Calculating ultimate primary consolidation settlement using compression index (Cc) and swelling index (Cs)",
        "Terzaghi 1D consolidation theory: Time factor (Tv), coefficient of consolidation (Cv), and drainage path"
      ]
    }],
    3: [{
      id: "civ-geo-p3-bearing-capacity-piles",
      title: "Bearing Capacity Theories (Terzaghi / Meyerhof) & Deep Pile Foundation Design",
      youtube_video_id: "ve8Z3Gue9Xs",
      youtube_url: "https://www.youtube.com/watch?v=ve8Z3Gue9Xs",
      fallback_video_id: "7KvAlN6QP4w",
      search_query: "Terzaghi Bearing Capacity Deep Pile Foundation Design End Bearing Skin Friction",
      channel_name: "MADE EASY",
      duration: "33:20",
      difficulty: "Advanced",
      topic_focus: "General vs Local Shear Failure, Bearing Factors (Nc, Nq, Ngamma) & Pile Group Efficiency",
      key_takeaways: [
        "Terzaghi ultimate bearing capacity formula for strip, circular, and square shallow footings",
        "Correcting bearing capacity factors for water table elevation and embedment depth",
        "Axial capacity of driven and bored cast-in-situ piles: End bearing resistance and skin friction",
        "Pile group settlement, block failure checks, and negative skin friction in soft consolidating clays"
      ]
    }],
    4: [{
      id: "civ-geo-p4-geotech-interview",
      title: "Geotechnical Engineering Placement Interview & Soil Investigation Report Viva",
      youtube_video_id: "Ycq1Xqmr6XY",
      youtube_url: "https://www.youtube.com/watch?v=Ycq1Xqmr6XY",
      fallback_video_id: "zpM38Yplm0A",
      search_query: "Geotechnical Engineer Interview Questions Standard Penetration Test SPT N Value Viva",
      channel_name: "MADE EASY",
      duration: "30:40",
      difficulty: "Placement",
      topic_focus: "Standard Penetration Test (SPT N-Value), Dilatancy Corrections, Slope Stability & Viva",
      key_takeaways: [
        "Conducting Standard Penetration Test (SPT): Split-spoon sampler, 63.5 kg hammer, 750 mm drop",
        "Applying overburden pressure and dilatancy corrections to raw SPT N-values",
        "Interpreting geotechnical soil investigation bore-logs to recommend appropriate foundation types",
        "Passing geotechnical technical rounds at Keller, Fugro, L&T Geostructure, and Jacobs"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // CIVIL: Quantity Surveying, Estimation & BOQ
  // --------------------------------------------------------------------------
  'civ-boq': {
    0: [{
      id: "civ-boq-p0-methods",
      title: "Quantity Surveying Basics: Centerline Method vs Long Wall-Short Wall Method",
      youtube_video_id: "sTe7gMVDONU",
      youtube_url: "https://www.youtube.com/watch?v=sTe7gMVDONU",
      fallback_video_id: "yhMPodo0oU0",
      search_query: "Quantity Surveying Estimation Centerline Method Long Wall Short Wall Method Building Plan",
      channel_name: "CivilConstruction",
      duration: "24:50",
      difficulty: "Beginner",
      topic_focus: "Reading Architectural Plans, Centerline Length Deductions & Measurement Units (IS 1200)",
      key_takeaways: [
        "Standard units of measurement and tolerance limits according to IS 1200",
        "Applying the Centerline Method: Calculating total center line length and deducting T-junction half-breadths",
        "Long Wall-Short Wall method step-by-step for multi-room residential layouts",
        "Earthwork excavation quantity computation in foundation trenches with side slopes"
      ]
    }],
    1: [{
      id: "civ-boq-p1-material-quantities",
      title: "Material Quantity Take-Off: Cement, Sand, Aggregate, Brickwork & Plastering",
      youtube_video_id: "PWcM_38ILzI",
      youtube_url: "https://www.youtube.com/watch?v=PWcM_38ILzI",
      fallback_video_id: "W8PXxEUcM3I",
      search_query: "Material Calculation Cement Sand Aggregate Concrete M20 Brickwork Plastering",
      channel_name: "ENGINEERING TACTICS",
      duration: "27:30",
      difficulty: "Intermediate",
      topic_focus: "Dry Volume vs Wet Volume (1.54 Factor), Nominal Mix (M15, M20) & Brick Mortar Ratios",
      key_takeaways: [
        "Applying the dry volume multiplier (1.54) for concrete mix design quantities (cement, fine, coarse)",
        "Calculating number of standard modular bricks per cubic meter (500 bricks/m3 with mortar)",
        "Dry volume conversion for cement-sand mortar in 12mm internal plastering (1.30 multiplier)",
        "Factoring in standard wastage percentages during material procurement scheduling"
      ]
    }],
    2: [{
      id: "civ-boq-p2-bar-bending-schedule",
      title: "Bar Bending Schedule (BBS) for Beams, Slabs, Columns & Footings",
      youtube_video_id: "uPfhUaDI2jQ",
      youtube_url: "https://www.youtube.com/watch?v=uPfhUaDI2jQ",
      fallback_video_id: "bTp0xaKlM3k",
      search_query: "Bar Bending Schedule BBS Beam Slab Column Footing Cutting Length Rebar Weight",
      channel_name: "CIVIL JE EXAM",
      duration: "30:15",
      difficulty: "Intermediate",
      topic_focus: "Cutting Length Formulas, Bend Deductions (45, 90, 135 deg), Hook Allowances & Rebar Weight",
      key_takeaways: [
        "Computing unit weight of steel rebar formula: D^2 / 162.2 kg per meter length",
        "Standard bend deduction rules: 1d for 45 deg, 2d for 90 deg, 3d for 135 deg hook bends",
        "Generating cutting length tables and shape codes for stirrups, cranked bars, and column lap splices",
        "Optimizing rebar cutting patterns to minimize scrap offcuts on active construction jobsites"
      ]
    }],
    3: [{
      id: "civ-boq-p3-rate-analysis-tenders",
      title: "Rate Analysis (DSR / CPWD Specs) & Bill of Quantities (BOQ) Tender Preparation",
      youtube_video_id: "LjWRZSMsiwY",
      youtube_url: "https://www.youtube.com/watch?v=LjWRZSMsiwY",
      fallback_video_id: "eui_U2NIRuQ",
      search_query: "Rate Analysis CPWD DSR Bill of Quantities BOQ Tender Document Preparation",
      channel_name: "REINFORCE",
      duration: "32:40",
      difficulty: "Advanced",
      topic_focus: "Labor Output Constants, Equipment Machinery Rates, Contractor Profit (15%) & Tender BOQ",
      key_takeaways: [
        "Breaking down rate analysis: Material cost, labor constants (mason, helper), equipment hire, water/contingency",
        "Using CPWD Delhi Schedule of Rates (DSR) and state PWD schedules for accurate rate benchmarking",
        "Preparing item-rate, lump-sum, and EPC tender bidding documents and Schedule of Quantities",
        "Compiling comprehensive master BOQ spreadsheets with linked formulas in Microsoft Excel"
      ]
    }],
    4: [{
      id: "civ-boq-p4-surveying-interview",
      title: "Quantity Surveyor / Cost Estimator Placement Interview & Excel BOQ Screening",
      youtube_video_id: "serkUSGghb0",
      youtube_url: "https://www.youtube.com/watch?v=serkUSGghb0",
      fallback_video_id: "dAPuMmZYqUI",
      search_query: "Quantity Surveyor Interview Questions Cost Estimation BOQ Billing Engineer Viva",
      channel_name: "Civil Site05",
      duration: "29:10",
      difficulty: "Placement",
      topic_focus: "Interim Payment Certificates (IPC), Reconciliation Statements, Variation Claims & Viva",
      key_takeaways: [
        "Preparing contractor Interim Payment Certificates (IPC) and running account (RA) bills",
        "Performing monthly material reconciliation statements (actual consumed vs theoretical allowed)",
        "Drafting contractual variation orders, extra items, and delay claim substantiations under FIDIC contracts",
        "Clearing quantity surveying technical assessments at L&T, Atkins, Turner & Townsend, and Mott MacDonald"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // CIVIL: Construction Project Scheduling (Primavera / MS Project)
  // --------------------------------------------------------------------------
  'civ-projectmgmt': {
    0: [{
      id: "civ-pm-p0-cpm-pert",
      title: "Construction Project Management: Critical Path Method (CPM) & PERT Networks",
      youtube_video_id: "-TDh-5n90vk",
      youtube_url: "https://www.youtube.com/watch?v=-TDh-5n90vk",
      fallback_video_id: "Us5YtgvfomQ",
      search_query: "Critical Path Method CPM PERT Network Diagram Early Start Late Finish Float",
      channel_name: "Joshua Emmanuel",
      duration: "25:15",
      difficulty: "Beginner",
      topic_focus: "Activity on Node (AON), Forward/Backward Pass, Early Start/Finish & Total Float",
      key_takeaways: [
        "Drawing Activity on Node (AON) network logic diagrams with Finish-to-Start (FS) and Start-to-Start (SS) dependencies",
        "Executing forward pass for Early Start (ES) and Early Finish (EF) project duration calculation",
        "Executing backward pass for Late Start (LS) and Late Finish (LF) to identify zero float critical paths",
        "Total Float vs Free Float vs Interfering Float computation to prevent project delay penalties"
      ]
    }],
    1: [{
      id: "civ-pm-p1-primavera-wbs",
      title: "Primavera P6 Tutorial: Work Breakdown Structure (WBS) & Activity Sequencing",
      youtube_video_id: "4e6NNiuH4lw",
      youtube_url: "https://www.youtube.com/watch?v=4e6NNiuH4lw",
      fallback_video_id: "hlwMna3pepk",
      search_query: "Primavera P6 Tutorial Work Breakdown Structure WBS Activity Predecessor Successor",
      channel_name: "Learn with EngrWaqas",
      duration: "28:30",
      difficulty: "Intermediate",
      topic_focus: "Enterprise Project Structure (EPS), WBS Levels, Milestones & Calendar Definitions",
      key_takeaways: [
        "Structuring the Enterprise Project Structure (EPS) and Organizational Breakdown Structure (OBS)",
        "Decomposing construction deliverables into hierarchical multi-level Work Breakdown Structures (WBS)",
        "Defining project working calendars: Shifts, non-working holidays, and seasonal monsoon rain delays",
        "Assigning predecessors, successors, and relationship lags to establish baseline schedules"
      ]
    }],
    2: [{
      id: "civ-pm-p2-resource-leveling",
      title: "Resource Loading, Resource Leveling & Cash Flow S-Curve Tracking",
      youtube_video_id: "miN8vEpqo-0",
      youtube_url: "https://www.youtube.com/watch?v=miN8vEpqo-0",
      fallback_video_id: "yXqaXAUBpQo",
      search_query: "Primavera P6 Resource Leveling Manpower Equipment Loading S Curve Cash Flow",
      channel_name: "Extra Inchs",
      duration: "29:50",
      difficulty: "Intermediate",
      topic_focus: "Labor/Non-Labor Resource Assignment, Overallocation Smoothing & Baseline S-Curve",
      key_takeaways: [
        "Assigning labor, non-labor (plant/machinery), and material resources to scheduled activities",
        "Resolving peak overallocation bottlenecks through automated resource leveling without delaying milestones",
        "Generating planned vs actual cumulative expenditure S-curves for executive cash flow monitoring",
        "Tracking productivity rates (man-hours per cubic meter of concrete / square meter of shuttering)"
      ]
    }],
    3: [{
      id: "civ-pm-p3-evm-tracking",
      title: "Earned Value Management (EVM): Cost & Schedule Performance Indices (CPI / SPI)",
      youtube_video_id: "yIr5PbffuxM",
      youtube_url: "https://www.youtube.com/watch?v=yIr5PbffuxM",
      fallback_video_id: "tAqvmE9bp_g",
      search_query: "Earned Value Management EVM Planned Value PV Earned Value EV Actual Cost CPI SPI",
      channel_name: "iZenBridge Consultancy",
      duration: "31:20",
      difficulty: "Advanced",
      topic_focus: "PV, EV, AC, Schedule Variance (SV), Cost Variance (CV) & Estimate at Completion (EAC)",
      key_takeaways: [
        "Defining core EVM metrics: Planned Value (PV), Earned Value (EV), and Actual Cost (AC)",
        "Calculating Schedule Variance (SV = EV - PV) and Schedule Performance Index (SPI = EV / PV)",
        "Calculating Cost Variance (CV = EV - AC) and Cost Performance Index (CPI = EV / AC)",
        "Forecasting final project costs using Estimate at Completion: EAC = BAC / CPI"
      ]
    }],
    4: [{
      id: "civ-pm-p4-planning-interview",
      title: "Construction Planning Engineer Placement Interview & P6 Case Study Viva",
      youtube_video_id: "PHYzuQ97V6k",
      youtube_url: "https://www.youtube.com/watch?v=PHYzuQ97V6k",
      fallback_video_id: "c_H5HRLThJo",
      search_query: "Planning Engineer Interview Questions Primavera P6 Project Management Delay Analysis Viva",
      channel_name: "Learn with EngrWaqas",
      duration: "30:10",
      difficulty: "Placement",
      topic_focus: "Time Impact Analysis (TIA), Extension of Time (EOT) Claims & Technical Interview",
      key_takeaways: [
        "Performing Time Impact Analysis (TIA) to substantiate Extension of Time (EOT) delay claims",
        "Differentiating excusable vs non-excusable delays and concurrent employer/contractor delays",
        "Presenting monthly progress update dashboards to clients and project management consultants",
        "Acing construction planning interviews at Bechtel, L&T Construction, Mace, and AECOM"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // MECHANICAL: GD&T (ASME Y14.5 Geometric Dimensioning & Tolerancing)
  // --------------------------------------------------------------------------
  'mech-gdt': {
    0: [{
      id: "mech-gdt-p0-basics",
      title: "GD&T Fundamentals: ASME Y14.5 Feature Control Frames & Datums",
      youtube_video_id: "vcY2Z5SF6Vw",
      youtube_url: "https://www.youtube.com/watch?v=vcY2Z5SF6Vw",
      fallback_video_id: "kc7LirWrvsg",
      search_query: "GD&T Tutorial ASME Y14.5 Feature Control Frame Datums Primary Secondary Tertiary",
      channel_name: "Simplegyan Engineering",
      duration: "23:45",
      difficulty: "Beginner",
      topic_focus: "Datum Reference Frame (3-2-1 Rule), Basic Dimensions & Feature Control Frame Breakdown",
      key_takeaways: [
        "Limitations of traditional plus-minus coordinate tolerancing and why GD&T prevents scrap",
        "Anatomy of the Feature Control Frame: Geometric characteristic symbol, tolerance value, material condition, datums",
        "Establishing the Datum Reference Frame (DRF) using the 3-2-1 locating principle (6 degrees of freedom constrained)",
        "Definition of Basic Dimensions (boxed dimensions) without individual tolerances"
      ]
    }],
    1: [{
      id: "mech-gdt-p1-form-orientation",
      title: "Form & Orientation Tolerances: Flatness, Straightness, Perpendicularity & Parallelism",
      youtube_video_id: "b9sst1ADoIw",
      youtube_url: "https://www.youtube.com/watch?v=b9sst1ADoIw",
      fallback_video_id: "QLNYYWicWvA",
      search_query: "GD&T Form Orientation Tolerances Flatness Straightness Perpendicularity Parallelism",
      channel_name: "iGETIT by Tata Tech",
      duration: "26:30",
      difficulty: "Intermediate",
      topic_focus: "Rule #1 (Taylor Principle / Envelope Principle), Flatness vs Parallelism & Verification",
      key_takeaways: [
        "ASME Rule #1 (Envelope Principle): Perfect form at Maximum Material Condition (MMC)",
        "Form tolerances (Straightness, Flatness, Circularity, Cylindricity) that never reference datums",
        "Orientation tolerances (Perpendicularity, Parallelism, Angularity) that require datum references",
        "Physical CMM probe and dial indicator inspection setups to measure geometric runout on inspection plates"
      ]
    }],
    2: [{
      id: "mech-gdt-p2-position-mmc",
      title: "True Position Tolerance & Material Condition Modifiers (MMC, LMC, RFS)",
      youtube_video_id: "cQDR-KCuaPU",
      youtube_url: "https://www.youtube.com/watch?v=cQDR-KCuaPU",
      fallback_video_id: "CdW4LrYXGxM",
      search_query: "GD&T True Position Tolerance Bonus Tolerance Maximum Material Condition MMC LMC",
      channel_name: "Magician of CNC Machining",
      duration: "29:15",
      difficulty: "Intermediate",
      topic_focus: "True Position Cylindrical Tolerance Zone, Calculating Bonus Tolerance & Functional Gaging",
      key_takeaways: [
        "Why cylindrical true position tolerance zones provide 57% more usable tolerance area than square zones",
        "Maximum Material Condition (MMC) concept: Pin at maximum diameter, hole at minimum diameter",
        "Calculating bonus tolerance: Allowed position error increases as feature departs from MMC toward LMC",
        "Designing functional Go / No-Go plug gages for rapid assembly line quality inspection"
      ]
    }],
    3: [{
      id: "mech-gdt-p3-stackup-profile",
      title: "Profile of a Surface Tolerance & 1D / 2D Worst-Case Tolerance Stackup Analysis",
      youtube_video_id: "fnpVItS7KGs",
      youtube_url: "https://www.youtube.com/watch?v=fnpVItS7KGs",
      fallback_video_id: "7M0QQBo2awA",
      search_query: "Profile of a Surface GD&T Tolerance Stackup Analysis Worst Case RSS 1D Stackup",
      channel_name: "RedVectorOnline",
      duration: "31:40",
      difficulty: "Advanced",
      topic_focus: "Unilateral vs Bilateral Surface Profile, Worst-Case vs Root Sum Square (RSS) Stackup",
      key_takeaways: [
        "Profile of a Surface: Controlling size, form, orientation, and location of complex contoured parts",
        "Differentiating bilateral equal, unequal disposed, and unilateral surface profile tolerance zones",
        "Executing 1D tolerance stackup loop diagrams: Tracking positive and negative vector dimensions",
        "Worst-Case method vs statistical Root Sum of Squares (RSS) tolerance distribution models"
      ]
    }],
    4: [{
      id: "mech-gdt-p4-gdt-interview",
      title: "Mechanical Design Engineer GD&T Placement Interview & Drawing Print Reading",
      youtube_video_id: "Icoc46X0Gl8",
      youtube_url: "https://www.youtube.com/watch?v=Icoc46X0Gl8",
      fallback_video_id: "qFFWkwbZDv0",
      search_query: "Mechanical Engineer GD&T Interview Print Reading ASME Y14.5 Technical Viva",
      channel_name: "Drawing Guru India",
      duration: "28:20",
      difficulty: "Placement",
      topic_focus: "Engineering Drawing Interpretation, Complex CMM Reports & OEM Design Viva",
      key_takeaways: [
        "Interpreting complex automotive powertrain and aerospace structural 2D engineering drawings",
        "Troubleshooting non-conformance reports (NCR) and evaluating whether out-of-spec parts assemble",
        "Explaining composite position tolerancing vs dual single-segment position tolerances in interviews",
        "Acing mechanical design engineering screening at Boeing, Cummins, Tesla, and Caterpillar"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // MECHANICAL: CNC Machining, G-Code & CAM Toolpaths
  // --------------------------------------------------------------------------
  'mech-cnc': {
    0: [{
      id: "mech-cnc-p0-gcode-basics",
      title: "CNC Machining & Manual G-Code Programming: G00, G01, G02, G03 & Coordinate Planes",
      youtube_video_id: "qJ1OL1OzKHw",
      youtube_url: "https://www.youtube.com/watch?v=qJ1OL1OzKHw",
      fallback_video_id: "5XihF05K4yM",
      search_query: "CNC Programming for Beginners G-Code G00 G01 G02 G03 Milling Circular Interpolation",
      channel_name: "CNC TALKS",
      duration: "25:40",
      difficulty: "Beginner",
      topic_focus: "Machine Zero vs Work Coordinate System (G54-G59), Absolute (G90) vs Incremental (G91)",
      key_takeaways: [
        "Cartesian coordinate axes in 3-axis vertical machining centers (X, Y, Z right-hand rule)",
        "Rapid positioning (G00) vs linear cutting feed (G01 with F parameter)",
        "Circular interpolation: Clockwise (G02) and counter-clockwise (G03) with I, J, K or R arc centers",
        "Work Coordinate Systems (WCS): Setting G54 part datum offsets using edge finders and touch probes"
      ]
    }],
    1: [{
      id: "mech-cnc-p1-tools-speeds-feeds",
      title: "Speeds & Feeds Calculation, Tool Geometry & Canned Drilling Cycles (G81-G84)",
      youtube_video_id: "gTnkNHB7dss",
      youtube_url: "https://www.youtube.com/watch?v=gTnkNHB7dss",
      fallback_video_id: "Fx7MP1hP3pU",
      search_query: "CNC Speeds and Feeds Calculation Surface Footage RPM Feed Rate Canned Cycles",
      channel_name: "Haas Automation, Inc.",
      duration: "27:15",
      difficulty: "Intermediate",
      topic_focus: "Spindle RPM = (SFM * 3.82) / D, Chip Load per Tooth, G81 Spot Drill & G83 Peck Drilling",
      key_takeaways: [
        "Calculating spindle speed: RPM = (Surface Speed SFM x 3.82) / Tool Diameter (inches)",
        "Calculating table feed rate: IPM = RPM x Number of Flutes x Chip Load (inches per tooth)",
        "Standard canned cycles: G81 simple drilling, G83 deep-hole peck drilling with chip break, G84 tapping",
        "Tool length offset (G43 H-code) and cutter radius compensation (G41 left / G42 right)"
      ]
    }],
    2: [{
      id: "mech-cnc-p2-cam-toolpaths",
      title: "Mastercam / Fusion 360 CAM: 2D & 3D High-Speed Dynamic Milling Toolpaths",
      youtube_video_id: "xxxYXOz5QS8",
      youtube_url: "https://www.youtube.com/watch?v=xxxYXOz5QS8",
      fallback_video_id: "wJjRQh7Yqgw",
      search_query: "Fusion 360 CAM Tutorial 2D Adaptive Clearing 3D Contour Dynamic Milling Toolpath",
      channel_name: "NYC CNC",
      duration: "30:25",
      difficulty: "Intermediate",
      topic_focus: "Adaptive Clearing, Constant Tool Engagement Angle, Stepover, Stepdown & Stock Allowance",
      key_takeaways: [
        "Why Dynamic / Adaptive Milling toolpaths maintain constant radial engagement to prevent tool breakage",
        "Selecting optimal stepdown (axial depth of cut) and stepover (radial width of cut) in tough alloys",
        "Roughing vs semi-finishing vs parallel surface finishing passes for mirror surface roughness (Ra)",
        "Simulating toolpaths to eliminate gouging, tool holder collisions, and rapid plunge crashes"
      ]
    }],
    3: [{
      id: "mech-cnc-p3-lathe-multiaxis",
      title: "CNC Lathe Turning (G71 Roughing Cycles) & 4th/5th Axis Multiaxis Machining",
      youtube_video_id: "iYXfsrbJZuE",
      youtube_url: "https://www.youtube.com/watch?v=iYXfsrbJZuE",
      fallback_video_id: "OKFFRZevXlM",
      search_query: "CNC Lathe Programming G71 Turning Roughing Cycle 5 Axis CNC Machining",
      channel_name: "Tom Stikkelman",
      duration: "33:50",
      difficulty: "Advanced",
      topic_focus: "G71 OD Roughing, G70 Finishing, Thread Cutting (G76) & 5-Axis Positional Machining",
      key_takeaways: [
        "CNC turning canned cycles: G71 outer diameter profile roughing and G70 finish profile pass",
        "Single-point thread turning canned cycle (G76): Thread pitch, lead, compound infeed angles",
        "3+2 positional indexing vs simultaneous 5-axis continuous swarf and contour milling",
        "Post-processor configuration: Translating CAM toolpath CL-data into machine-specific Fanuc/Siemens G-code"
      ]
    }],
    4: [{
      id: "mech-cnc-p4-cnc-interview",
      title: "CNC Programmer / Manufacturing Engineer Placement Interview & Machining Viva",
      youtube_video_id: "jHSRfCwZipc",
      youtube_url: "https://www.youtube.com/watch?v=jHSRfCwZipc",
      fallback_video_id: "0C9G16tIbmg",
      search_query: "CNC Programmer Manufacturing Engineer Technical Interview Questions G Code Viva",
      channel_name: "RVM CAD",
      duration: "29:30",
      difficulty: "Placement",
      topic_focus: "Tool Wear Offsets, Chatter Troubleshooting, Workholding Jigs & Placement Viva",
      key_takeaways: [
        "Troubleshooting chatter and harmonic vibration: Adjusting spindle speed sweet spots and overhang",
        "Fixture design: Soft jaws, vacuum chucks, zero-point clamping systems, and modular vice workholding",
        "Interpreting insert wear patterns (flank wear, crater wear, built-up edge) to optimize tool life",
        "Passing manufacturing engineering interviews at Haas, Kennametal, Sandvik Coromant, and Tesla"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // MECHANICAL: Thermodynamics & Heat Exchanger Design
  // --------------------------------------------------------------------------
  'mech-thermo': {
    0: [{
      id: "mech-th-p0-laws",
      title: "Thermodynamics First Principles: First & Second Laws, Enthalpy & Entropy",
      youtube_video_id: "f1OokOgtcqg",
      youtube_url: "https://www.youtube.com/watch?v=f1OokOgtcqg",
      fallback_video_id: "ZnqmyAEl2UQ",
      search_query: "Engineering Thermodynamics First Law Second Law Enthalpy Entropy Steam Tables",
      channel_name: "Khan Academy",
      duration: "24:10",
      difficulty: "Beginner",
      topic_focus: "Closed vs Open Systems, First Law Energy Balance (Q - W = Delta U), Carnot Efficiency",
      key_takeaways: [
        "Closed system First Law energy equation: Delta U = Q - W; Open steady flow system (SFEE)",
        "Reading property diagrams: P-v, T-s, and Mollier (h-s) diagrams using steam tables",
        "Second Law of Thermodynamics: Clausius and Kelvin-Planck statements; entropy generation (Sgen >= 0)",
        "Carnot cycle efficiency limit: eta_max = 1 - (T_cold / T_hot) in absolute Kelvin"
      ]
    }],
    1: [{
      id: "mech-th-p1-cycles",
      title: "Power & Refrigeration Cycles: Rankine, Brayton, Otto, Diesel & Vapor Compression",
      youtube_video_id: "AwLpST3vlS4",
      youtube_url: "https://www.youtube.com/watch?v=AwLpST3vlS4",
      fallback_video_id: "8paWhATWxgU",
      search_query: "Rankine Cycle Steam Power Plant Brayton Cycle Gas Turbine Vapor Compression Refrigeration",
      channel_name: "Less Boring Lectures",
      duration: "27:40",
      difficulty: "Intermediate",
      topic_focus: "Superheating, Reheat Rankine Cycle, Compressor Work, COP of Heat Pumps & T-s Diagrams",
      key_takeaways: [
        "Ideal vs actual Rankine cycle: Boiler, turbine isentropic efficiency, condenser, and feedwater pump",
        "Increasing Rankine efficiency via reheat, regeneration (open and closed feedwater heaters), and superheat",
        "Brayton gas turbine cycle: Compressor pressure ratio, turbine inlet temperature, and regenerators",
        "Standard Vapor Compression Refrigeration Cycle (VCRC): Evaporator, compressor, condenser, expansion valve, COP"
      ]
    }],
    2: [{
      id: "mech-th-p2-heat-transfer",
      title: "Modes of Heat Transfer: Conduction (Fourier), Convection (Newton) & Radiation (Stefan-Boltzmann)",
      youtube_video_id: "lvyCe0UaqJY",
      youtube_url: "https://www.youtube.com/watch?v=lvyCe0UaqJY",
      fallback_video_id: "5t4L2dH26tE",
      search_query: "Heat Transfer Conduction Convection Radiation Nusselt Reynolds Prandtl Number",
      channel_name: "Wisc-Online",
      duration: "28:50",
      difficulty: "Intermediate",
      topic_focus: "Thermal Resistance Networks, Nusselt Number, Dittus-Boelter Correlation & Emissivity",
      key_takeaways: [
        "Fourier law of conduction through plane walls and composite hollow cylinders; critical insulation radius",
        "Newton law of cooling and convective heat transfer coefficient (h)",
        "Dimensionless numbers: Reynolds (Re), Prandtl (Pr), and Nusselt (Nu) for laminar vs turbulent forced pipe flow",
        "Stefan-Boltzmann radiation law: Blackbody emissive power and gray surface view factor radiation networks"
      ]
    }],
    3: [{
      id: "mech-th-p3-heat-exchangers",
      title: "Heat Exchanger Design: Log Mean Temperature Difference (LMTD) & NTU-Effectiveness",
      youtube_video_id: "lT7VReMCQDk",
      youtube_url: "https://www.youtube.com/watch?v=lT7VReMCQDk",
      fallback_video_id: "VyIL6KQO8Dg",
      search_query: "Heat Exchanger Design LMTD Method NTU Effectiveness Shell and Tube TEMA Standards",
      channel_name: "Mechanical by Vikas Bhadoria",
      duration: "32:15",
      difficulty: "Advanced",
      topic_focus: "Parallel vs Counter-Flow, Overall Heat Transfer Coefficient (U), Fouling Factors & Sizing",
      key_takeaways: [
        "Why counter-flow configuration achieves higher heat transfer rates than parallel flow",
        "Calculating Log Mean Temperature Difference (LMTD) with correction factors for multi-pass shell-and-tube units",
        "The Number of Transfer Units (NTU) and effectiveness (epsilon) method when fluid outlet temperatures are unknown",
        "Factoring in internal tube-side and external shell-side fouling resistances according to TEMA standards"
      ]
    }],
    4: [{
      id: "mech-th-p4-thermo-interview",
      title: "Thermal & HVAC Systems Design Placement Interview Screening & Viva",
      youtube_video_id: "50fOuRXOjQE",
      youtube_url: "https://www.youtube.com/watch?v=50fOuRXOjQE",
      fallback_video_id: "jXKA1kprp_c",
      search_query: "Thermal Engineer HVAC Design Technical Interview Questions Psychrometric Chart Viva",
      channel_name: "A Mechanical Engineer",
      duration: "29:45",
      difficulty: "Placement",
      topic_focus: "Psychrometric Processes (Sensible Cooling, Dehumidification), Chiller Plants & Technical Viva",
      key_takeaways: [
        "Reading the Psychrometric Chart: Dry bulb, wet bulb, dew point temperature, relative humidity, and enthalpy",
        "Cooling coil air-conditioning processes: Sensible cooling with moisture dehumidification",
        "Troubleshooting thermal runaway, cavitation in centrifugal boiler feedwater pumps, and boiling regimes",
        "Acing thermal engineering placement interviews at GE Power, Daikin, Carrier, Siemens Energy, and ISRO"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // MECHANICAL: Design for Manufacturing & Assembly (DFMA)
  // --------------------------------------------------------------------------
  'mech-dfma': {
    0: [{
      id: "mech-dfma-p0-principles",
      title: "DFMA First Principles: Boothroyd-Dewhurst Methodology & Part Count Reduction",
      youtube_video_id: "H6XtXCvhaec",
      youtube_url: "https://www.youtube.com/watch?v=H6XtXCvhaec",
      fallback_video_id: "7JQaa0AenaU",
      search_query: "Design for Manufacturing and Assembly DFMA Boothroyd Dewhurst Part Reduction",
      channel_name: "DFMA® by Boothroyd Dewhurst, Inc.",
      duration: "23:30",
      difficulty: "Beginner",
      topic_focus: "The 3 Theoretical Minimum Part Criteria, Design for Assembly (DFA) Index & Symmetry",
      key_takeaways: [
        "The three Boothroyd-Dewhurst criteria for theoretical minimum parts: Relative motion, different material, assembly access",
        "Eliminating threaded fasteners (screws, nuts, washers) via integrated snap fits and interlocking tabs",
        "Part symmetry rules: Designing parts that are either end-to-end symmetrical or blatantly asymmetrical to prevent insertion errors (Poka-Yoke)",
        "Chamfering mating parts and self-locating features to guide blind insertion in high-speed assembly"
      ]
    }],
    1: [{
      id: "mech-dfma-p1-sheet-metal",
      title: "Design for Sheet Metal: K-Factor, Bend Radii, Relief Notches & Hemming",
      youtube_video_id: "kUizKC1gkg0",
      youtube_url: "https://www.youtube.com/watch?v=kUizKC1gkg0",
      fallback_video_id: "nsuLlW-Aby8",
      search_query: "Design for Sheet Metal K Factor Bend Allowance Bend Deduction Flat Pattern",
      channel_name: "TriMech Group",
      duration: "26:10",
      difficulty: "Intermediate",
      topic_focus: "Neutral Axis Shift (K-Factor), Bend Allowance, Hole-to-Bend Minimum Clearance & Flanges",
      key_takeaways: [
        "Understanding neutral axis displacement during bending and selecting appropriate K-Factor (typically 0.33 to 0.50)",
        "Calculating Flat Pattern lengths using Bend Allowance (BA) and Bend Deduction (BD) formulas",
        "Minimum bend radius rules (equal to material thickness t) to avoid external tensile cracking",
        "Corner relief cutouts (rectangular, circular, tear relief) to prevent tearing at intersecting 90-degree bends"
      ]
    }],
    2: [{
      id: "mech-dfma-p2-injection-molding",
      title: "Design for Injection Molding: Uniform Wall Thickness, Draft Angles, Ribs & Bosses",
      youtube_video_id: "hMynMPhiMTU",
      youtube_url: "https://www.youtube.com/watch?v=hMynMPhiMTU",
      fallback_video_id: "c9Hp3O3RT7g",
      search_query: "Design for Injection Molding Plastic Parts Draft Angle Wall Thickness Ribs Bosses",
      channel_name: "RAPID DIRECT",
      duration: "28:40",
      difficulty: "Intermediate",
      topic_focus: "Preventing Sink Marks & Warpage, 1-2 Degree Draft Angles, Coring Out Thick Sections",
      key_takeaways: [
        "Maintaining nominal uniform wall thickness throughout plastic parts to ensure uniform cooling and prevent differential shrinkage warpage",
        "Applying proper draft angles (minimum 1 to 2 degrees per side) to ensure clean mold release without drag marks",
        "Structural stiffening ribs design: Rib thickness should be 50-60% of nominal wall to avoid visible surface sink marks",
        "Screw boss design: Core pin depths, gusset supports, and radius fillets to prevent localized stress concentration"
      ]
    }],
    3: [{
      id: "mech-dfma-p3-die-casting",
      title: "Design for High-Pressure Die Casting & Additive Manufacturing (DfAM)",
      youtube_video_id: "6qZiHqQl7sI",
      youtube_url: "https://www.youtube.com/watch?v=6qZiHqQl7sI",
      fallback_video_id: "1xqMMaordic",
      search_query: "Design for Die Casting Aluminum Magnesium DfAM Topology Optimization",
      channel_name: "Mechanical Engineering Explained",
      duration: "31:15",
      difficulty: "Advanced",
      topic_focus: "Parting Line Selection, Ejector Pin Locations, Topology Optimization & Overhang Angles",
      key_takeaways: [
        "Aluminum and magnesium high-pressure die casting rules: Radiused corners, parting line flash minimization, zero undercut tooling",
        "Placement of mold ejector pins and gating overflows to avoid cosmetic surfaces and high-stress regions",
        "Design for Additive Manufacturing (DfAM): 45-degree self-supporting overhang rule to eliminate support structures",
        "Topology optimization: Using generative design algorithms to distribute material strictly along principal stress trajectories"
      ]
    }],
    4: [{
      id: "mech-dfma-p4-dfma-interview",
      title: "Product Design Engineer (NPI) Placement Interview & DFMA Review Viva",
      youtube_video_id: "s5t6nRf1ez8",
      youtube_url: "https://www.youtube.com/watch?v=s5t6nRf1ez8",
      fallback_video_id: "Ucm_WKeD8g8",
      search_query: "Product Design Engineer Technical Interview Questions DFMA NPI Tooling Viva",
      channel_name: "Skill Industrial",
      duration: "29:10",
      difficulty: "Placement",
      topic_focus: "Tooling Cost Estimation, Cycle Time Optimization, Production Failure Modes & Placement Viva",
      key_takeaways: [
        "Evaluating tooling lead times and mold complexity (lifters, side-action sliders, unscrewing cores)",
        "Conducting structured New Product Introduction (NPI) DFMA design reviews with cross-functional manufacturing plants",
        "Root cause analysis of manufacturing defects: Weld lines, short shots, flash, air traps, and burn marks",
        "Acing product design and mechanical hardware engineering interviews at Apple, Dyson, Tesla, and Foxconn"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // ELECTRICAL: VLSI Digital Design & Verilog RTL
  // --------------------------------------------------------------------------
  'ee-vlsi': {
    0: [{
      id: "ee-vlsi-p0-verilog-basics",
      title: "Verilog HDL for Beginners: Combinational Logic, Continuous Assignment & Data Types",
      youtube_video_id: "ofPsICnGODg",
      youtube_url: "https://www.youtube.com/watch?v=ofPsICnGODg",
      fallback_video_id: "I8lHk36sTB4",
      search_query: "Verilog HDL Tutorial for Beginners Combinational Logic Assign Always Wire Reg",
      channel_name: "Neso Academy",
      duration: "24:45",
      difficulty: "Beginner",
      topic_focus: "Wires vs Regs, Continuous Assignment (assign), Module Ports & Gate-Level Modeling",
      key_takeaways: [
        "Hardware Description Language (HDL) vs sequential software programming paradigms",
        "Verilog data types: Nets (wire) driven continuously vs variables (reg) in procedural blocks",
        "Combinational logic modeling using continuous assignment (assign out = a & b;) and conditional operators",
        "Hierarchical module instantiation, port mapping by name (.port(net)), and multi-bit bus vectors"
      ]
    }],
    1: [{
      id: "ee-vlsi-p1-sequential-fsm",
      title: "Sequential Circuits & Finite State Machines (FSM): Mealy vs Moore Architectures",
      youtube_video_id: "xp_O1pflcZ4",
      youtube_url: "https://www.youtube.com/watch?v=xp_O1pflcZ4",
      fallback_video_id: "NmctR-u_N-8",
      search_query: "Verilog Sequential Logic Flip Flops Finite State Machine Mealy Moore FSM 3-Process",
      channel_name: "ALL ABOUT VLSI",
      duration: "28:10",
      difficulty: "Intermediate",
      topic_focus: "Blocking (=) vs Non-Blocking (<=) Assignments, D Flip-Flops & 3-Process State Machines",
      key_takeaways: [
        "Golden rule of Verilog: Use blocking (=) for combinational logic; use non-blocking (<=) for sequential clocked registers",
        "Clocked procedural blocks: always @(posedge clk or negedge rst_n) for asynchronous active-low reset D flip-flops",
        "Designing Mealy vs Moore Finite State Machines (FSM) using 3-always-block robust coding styles",
        "State encoding comparisons: Binary, Gray code (glitch-free), and One-Hot encoding for high-speed FPGAs"
      ]
    }],
    2: [{
      id: "ee-vlsi-p2-testbenches-simulation",
      title: "Verilog Testbenches & RTL Verification: Clocks, Resets, Self-Checking Tasks",
      youtube_video_id: "1RtdCVtyFLA",
      youtube_url: "https://www.youtube.com/watch?v=1RtdCVtyFLA",
      fallback_video_id: "2CjhQ41oboQ",
      search_query: "Verilog Testbench Tutorial Writing Self Checking Testbench Simulation Waveforms",
      channel_name: "VLSI Simplified",
      duration: "29:35",
      difficulty: "Intermediate",
      topic_focus: "Initial Blocks, Free-Running Clocks (#5 clk = ~clk;), Stimulus Vectors & ModelSim Waveforms",
      key_takeaways: [
        "Constructing standalone non-synthesizable testbench fixtures without module inputs/outputs",
        "Generating realistic periodic clock signals using initial and forever loops with timescale parameters",
        "Applying directed test vectors, reset sequences, and verifying outputs with $display and $fatal statements",
        "Viewing waveform dumps (VCD) in ModelSim / Vivado XSIM logic analyzers to locate timing race conditions"
      ]
    }],
    3: [{
      id: "ee-vlsi-p3-sta-synthesis",
      title: "Static Timing Analysis (STA): Setup & Hold Time Violations and FPGA Synthesis",
      youtube_video_id: "za2o93ldrVQ",
      youtube_url: "https://www.youtube.com/watch?v=za2o93ldrVQ",
      fallback_video_id: "xCA54Qu4WtQ",
      search_query: "Static Timing Analysis STA Setup Time Hold Time Violation Clock Jitter Skew FPGA",
      channel_name: "vlsideepdive",
      duration: "32:50",
      difficulty: "Advanced",
      topic_focus: "Setup Slack, Hold Slack, Clock Skew, Clock Jitter & Pipelining for Maximum Frequency (Fmax)",
      key_takeaways: [
        "Setup time equation: T_clk >= T_cq + T_comb_max + T_setup - T_skew; calculating Setup Slack",
        "Hold time equation: T_cq + T_comb_min >= T_hold + T_skew; why hold violations cannot be fixed by lowering clock speed",
        "Resolving setup violations through architectural pipelining, retiming, and logic level reduction",
        "FPGA implementation in Xilinx Vivado: Synthesis, Technology Mapping (LUTs, DSP48 slices), Place & Route"
      ]
    }],
    4: [{
      id: "ee-vlsi-p4-vlsi-interview",
      title: "VLSI Digital Design / ASIC Placement Interview & Digital Electronics Viva",
      youtube_video_id: "r2kDxytZEUY",
      youtube_url: "https://www.youtube.com/watch?v=r2kDxytZEUY",
      fallback_video_id: "aUTmKYwfpHA",
      search_query: "VLSI Design Engineer Interview Questions Verilog FIFO Setup Hold Metastability Viva",
      channel_name: "CareerGuide",
      duration: "31:15",
      difficulty: "Placement",
      topic_focus: "Asynchronous FIFO Design, Clock Domain Crossing (CDC), Metastability & ASIC Viva",
      key_takeaways: [
        "Solving Clock Domain Crossing (CDC) problems using 2-flip-flop synchronizers and Gray-coded pointers",
        "Designing parameterizable Asynchronous FIFOs with dual independent read/write clocks and full/empty flags",
        "Explaining CMOS inverter characteristics (VTC curve, noise margins, propagation delay tpHL/tpLH)",
        "Cracking core VLSI technical interviews at Intel, NVIDIA, Qualcomm, AMD, and Texas Instruments"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // ELECTRICAL: Power Electronics & Motor Inverters
  // --------------------------------------------------------------------------
  'ee-powerelec': {
    0: [{
      id: "ee-pe-p0-switches",
      title: "Power Semiconductor Switches: Power MOSFETs, IGBTs & Gate Driver Circuits",
      youtube_video_id: "fXvllju0Duw",
      youtube_url: "https://www.youtube.com/watch?v=fXvllju0Duw",
      fallback_video_id: "of_v2N5f788",
      search_query: "Power Electronics MOSFET vs IGBT Switching Losses Gate Driver Bootstrap Circuit",
      channel_name: "RhyniTech - PEMD",
      duration: "22:50",
      difficulty: "Beginner",
      topic_focus: "Conduction Losses (Rds_on), Switching Losses, Safe Operating Area (SOA) & Isolated Gate Drives",
      key_takeaways: [
        "Comparison of power switches: Power MOSFETs (high frequency, <600V) vs IGBTs (high voltage/current, lower frequency)",
        "Calculating total semiconductor power dissipation: Conduction losses (I^2 * Rds_on) plus switching energy losses",
        "Safe Operating Area (SOA) boundaries: Maximum drain current, breakdown voltage, thermal breakdown limit",
        "High-side gate drive design: Floating bootstrap capacitor circuits and optocoupler / galvanic isolation"
      ]
    }],
    1: [{
      id: "ee-pe-p1-dcdc-converters",
      title: "Switch-Mode DC-DC Converters: Buck, Boost & Buck-Boost Topologies",
      youtube_video_id: "m8rK9gU30v4",
      youtube_url: "https://www.youtube.com/watch?v=m8rK9gU30v4",
      fallback_video_id: "ZiD_X-uo_TQ",
      search_query: "Buck Converter Boost Converter Inductor Sizing Continuous Conduction Mode CCM",
      channel_name: "GreatScott!",
      duration: "27:15",
      difficulty: "Intermediate",
      topic_focus: "Volt-Second Balance, Capacitor Charge Balance, CCM vs DCM & Inductor Sizing",
      key_takeaways: [
        "Applying the Inductor Volt-Second Balance to derive Buck (Vout = D * Vin) and Boost (Vout = Vin / (1-D)) ratios",
        "Capacitor charge balance across switching cycles to calculate output voltage peak-to-peak ripple",
        "Determining critical inductance boundary between Continuous Conduction Mode (CCM) and Discontinuous Mode (DCM)",
        "Selecting low Equivalent Series Resistance (ESR) electrolytic and ceramic output filtering capacitors"
      ]
    }],
    2: [{
      id: "ee-pe-p2-inverters-spwm",
      title: "3-Phase Voltage Source Inverters (VSI) & Sinusoidal PWM (SPWM) Modulation",
      youtube_video_id: "RPWM8rQ_cno",
      youtube_url: "https://www.youtube.com/watch?v=RPWM8rQ_cno",
      fallback_video_id: "h37Ej6m5RM0",
      search_query: "Three Phase Inverter SPWM Modulation Dead Time Shoot Through Protection Bridge",
      channel_name: "SimuScope",
      duration: "29:40",
      difficulty: "Intermediate",
      topic_focus: "6-Switch H-Bridge Inverter, Carrier-Based SPWM, Modulation Index & Dead-Time Insertion",
      key_takeaways: [
        "Operating principles of 3-phase full-bridge inverters with complementary high/low-side switch pairs",
        "Sinusoidal Pulse Width Modulation (SPWM): Comparing 3 sinusoidal reference waves with high-frequency triangular carrier",
        "Amplitude modulation index (ma) and frequency modulation index (mf) impact on fundamental voltage output",
        "Dead-time generation (interlocking delay) in hardware/microcontroller to eliminate catastrophic bridge shoot-through"
      ]
    }],
    3: [{
      id: "ee-pe-p3-svpwm-foc",
      title: "Space Vector PWM (SVPWM) & Field Oriented Control (FOC) for AC Motors",
      youtube_video_id: "6yqRlYyY1bk",
      youtube_url: "https://www.youtube.com/watch?v=6yqRlYyY1bk",
      fallback_video_id: "oq868piQ9Q4",
      search_query: "Space Vector PWM SVPWM Field Oriented Control FOC Clarke Park Transform",
      channel_name: "Syed Abdul Rahman Kashif",
      duration: "33:20",
      difficulty: "Advanced",
      topic_focus: "Clarke & Park Transformations (abc to dq0), 8 Switching Vectors, Sector Calculation & Dwell Times",
      key_takeaways: [
        "Why Space Vector PWM yields 15.5% higher DC bus utilization and lower harmonic distortion compared to SPWM",
        "Clarke transformation (3-phase abc stationary frame to 2-phase alpha-beta orthogonal stationary frame)",
        "Park transformation (alpha-beta to dq rotating rotor reference frame) to decouple flux (Id) and torque (Iq)",
        "Calculating dwell switching times (T1, T2, T0) across the 6 hexagonal sectors of the space vector diagram"
      ]
    }],
    4: [{
      id: "ee-pe-p4-pe-interview",
      title: "Power Electronics & Motor Drives Placement Interview Screening & Viva",
      youtube_video_id: "3yEiqBu02X4",
      youtube_url: "https://www.youtube.com/watch?v=3yEiqBu02X4",
      fallback_video_id: "Gb5-8zvH_Qg",
      search_query: "Power Electronics Engineer Technical Interview Questions EV Inverter Motor Drives Viva",
      channel_name: "Power Electrix",
      duration: "30:30",
      difficulty: "Placement",
      topic_focus: "Silicon Carbide (SiC) / GaN Wide-Bandgap Devices, Thermal Sizing & Placement Viva",
      key_takeaways: [
        "Advantages of Silicon Carbide (SiC) and Gallium Nitride (GaN) wide-bandgap semiconductors in EV traction inverters",
        "Thermal heatsink sizing: Junction-to-case, case-to-sink, and sink-to-ambient thermal resistance calculations",
        "EMI/EMC mitigation: Common-mode chokes, snubber circuits, and minimizing high di/dt and dv/dt loop areas",
        "Acing power electronics interviews at Tesla, ABB, Schneider Electric, Infineon, and Eaton"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // ELECTRICAL: MATLAB Simulink Control Systems & Modeling
  // --------------------------------------------------------------------------
  'ee-matlab': {
    0: [{
      id: "ee-mat-p0-simulink-basics",
      title: "MATLAB & Simulink for Beginners: Continuous Blocks, Solvers & Transfer Functions",
      youtube_video_id: "vxzR3W2BcRk",
      youtube_url: "https://www.youtube.com/watch?v=vxzR3W2BcRk",
      fallback_video_id: "t0HPbdzZOpI",
      search_query: "Simulink Tutorial for Beginners Transfer Function Scope ODE Solvers Step Response",
      channel_name: "Udemy",
      duration: "23:15",
      difficulty: "Beginner",
      topic_focus: "Simulink Library Browser, Sources/Sinks, Continuous Integrators & ODE Fixed/Variable Solvers",
      key_takeaways: [
        "Navigating the Simulink Library Browser: Sources (Step, Ramp, Sine), Sinks (Scope, To Workspace), Math Operations",
        "Modeling dynamic physical systems using first-order and second-order differential equations and integrators",
        "Defining Laplace transfer function blocks: Numerator and denominator polynomial vector coefficients",
        "Selecting appropriate ODE numerical solvers: Variable-step (ode45 Dormand-Prince) vs fixed-step (ode4 Runge-Kutta)"
      ]
    }],
    1: [{
      id: "ee-mat-p1-bode-rootlocus",
      title: "Classical Control Systems in MATLAB: Root Locus, Bode Plots & Nyquist Stability",
      youtube_video_id: "_eh1conN6YM",
      youtube_url: "https://www.youtube.com/watch?v=_eh1conN6YM",
      fallback_video_id: "CRvVDoQJjYI",
      search_query: "MATLAB Control Systems Toolbox Root Locus rlocus Bode Plot margin Nyquist Stability",
      channel_name: "Brian Douglas",
      duration: "27:50",
      difficulty: "Intermediate",
      topic_focus: "rlocus, bode, margin Commands, Gain Margin (GM), Phase Margin (PM) & Routh Hurwitz",
      key_takeaways: [
        "Using MATLAB Control System Toolbox commands: tf(), step(), impulse(), and rlocus()",
        "Interpreting frequency response Bode plots: Gain crossover frequency, phase crossover frequency, GM, and PM",
        "Assessing closed-loop stability: Gain Margin >= 6 dB and Phase Margin between 45-60 degrees for robust damping",
        "Nyquist stability criterion: Encirclements of the critical (-1, j0) point and right-half plane open-loop poles"
      ]
    }],
    2: [{
      id: "ee-mat-p2-pid-tuning",
      title: "PID Controller Design & Automated Tuning in Simulink (Ziegler-Nichols & Control System Designer)",
      youtube_video_id: "wkfEZmsQqiA",
      youtube_url: "https://www.youtube.com/watch?v=wkfEZmsQqiA",
      fallback_video_id: "ARewp6SCwGs",
      search_query: "PID Controller Tuning Simulink Ziegler Nichols Automated PID Tuner Anti Windup",
      channel_name: "MATLAB",
      duration: "29:10",
      difficulty: "Intermediate",
      topic_focus: "Proportional, Integral, Derivative Actions, Automated PID Tuner & Integrator Anti-Windup",
      key_takeaways: [
        "Roles of PID parameters: Kp reduces rise time, Ki eliminates steady-state error, Kd improves damping overshoot",
        "Applying the automated PID Tuner app in Simulink to interactively balance response time and transient robustness",
        "Ziegler-Nichols closed-loop tuning: Finding ultimate gain (Ku) and ultimate period (Tu) via sustained oscillations",
        "Implementing integrator anti-windup clamping to prevent severe overshoot caused by physical actuator saturation limits"
      ]
    }],
    3: [{
      id: "ee-mat-p3-state-space",
      title: "Modern Control Theory: State-Space Modeling, Controllability, Observability & LQR",
      youtube_video_id: "hpeKrMG-WP0",
      youtube_url: "https://www.youtube.com/watch?v=hpeKrMG-WP0",
      fallback_video_id: "FXSpHy8LvmY",
      search_query: "State Space Modeling MATLAB Controllability Observability Pole Placement LQR Control",
      channel_name: "MATLAB",
      duration: "33:40",
      difficulty: "Advanced",
      topic_focus: "Continuous Matrices (A, B, C, D), ctrb(), obsv(), Pole Placement (place) & LQR Cost Matrices (Q, R)",
      key_takeaways: [
        "Formulating state-space matrix equations: x_dot = A*x + B*u; y = C*x + D*u",
        "Testing system controllability (ctrb rank = n) and observability (obsv rank = n)",
        "Full-state feedback controller design using Ackermann pole placement formula (place() command)",
        "Linear Quadratic Regulator (LQR): Minimizing quadratic cost function balancing state error (Q) and control effort (R)"
      ]
    }],
    4: [{
      id: "ee-mat-p4-control-interview",
      title: "Control Systems Engineer Placement Interview & Simulink Model-Based Design Viva",
      youtube_video_id: "HGzfkuT1Q1w",
      youtube_url: "https://www.youtube.com/watch?v=HGzfkuT1Q1w",
      fallback_video_id: "tE1oKXXwmtI",
      search_query: "Control Systems Engineer Interview Questions MATLAB Simulink Model Based Design Viva",
      channel_name: "Instrumentation Hub",
      duration: "30:15",
      difficulty: "Placement",
      topic_focus: "Embedded Coder (MBD), Hardware-in-the-Loop (HIL) Testing & Control Theory Viva",
      key_takeaways: [
        "Model-Based Design (MBD) workflow: MIL (Model-in-the-Loop), SIL (Software-in-the-Loop), and HIL testing",
        "Generating optimized, MISRA-C compliant C-code from Simulink models using Embedded Coder",
        "Handling practical system identification questions: Estimating transfer functions from experimental step response data",
        "Passing control systems technical interviews at MathWorks, Collins Aerospace, ISRO, and Tesla Autopilot"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // ELECTRICAL: EV Battery Management Systems (BMS)
  // --------------------------------------------------------------------------
  'ee-evbms': {
    0: [{
      id: "ee-bms-p0-cell-chemistry",
      title: "Lithium-Ion Battery Chemistry, Operating Window & BMS Architecture",
      youtube_video_id: "4tCffYRAkZA",
      youtube_url: "https://www.youtube.com/watch?v=4tCffYRAkZA",
      fallback_video_id: "GXYJ1xC10j4",
      search_query: "BMS Battery Management System Architecture Lithium Ion NMC LFP Safe Operating Window",
      channel_name: "Owl WiS",
      duration: "24:20",
      difficulty: "Beginner",
      topic_focus: "NMC vs LFP Chemistries, Safe Operating Area (Voltage, Current, Temp), Master-Slave BMS",
      key_takeaways: [
        "Comparing electric vehicle chemistries: Nickel-Manganese-Cobalt (NMC high energy) vs Lithium Iron Phosphate (LFP high safety)",
        "Strict voltage boundaries: Over-voltage (4.2V NMC, risk of lithium plating) and under-voltage (2.5V, copper shunts)",
        "Master-Slave distributed BMS architecture: Battery Module Controllers (slave AFEs) and Battery Management Unit (master)",
        "High-voltage safety disconnects: Contactors, pre-charge resistors, pyrofuses, and manual service disconnects (MSD)"
      ]
    }],
    1: [{
      id: "ee-bms-p1-soc-estimation",
      title: "State of Charge (SoC) & State of Health (SoH) Estimation Algorithms",
      youtube_video_id: "7DTzShuFN6M",
      youtube_url: "https://www.youtube.com/watch?v=7DTzShuFN6M",
      fallback_video_id: "ENiTo4yJWDQ",
      search_query: "BMS State of Charge SoC Estimation Coulomb Counting Extended Kalman Filter OCV",
      channel_name: "Owl WiS",
      duration: "28:35",
      difficulty: "Intermediate",
      topic_focus: "Coulomb Counting, Open Circuit Voltage (OCV-SoC Lookup), Extended Kalman Filter (EKF) & SoH",
      key_takeaways: [
        "Coulomb Counting method: Integrating shunt current sensor measurements over time (Ah tracking)",
        "Limitations of Coulomb Counting: Current sensor drift accumulation and initial SoC uncertainty",
        "Open Circuit Voltage (OCV) relaxation curves and why flat OCV plateau in LFP requires advanced estimators",
        "Extended Kalman Filter (EKF) implementation using equivalent circuit models (ECM 1-RC / 2-RC pairs)"
      ]
    }],
    2: [{
      id: "ee-bms-p2-cell-balancing",
      title: "Cell Balancing Techniques: Passive Dissipative vs Active Energy Shuttle Balancing",
      youtube_video_id: "ONmyxtp-p54",
      youtube_url: "https://www.youtube.com/watch?v=ONmyxtp-p54",
      fallback_video_id: "Q6WVEmS43L4",
      search_query: "BMS Cell Balancing Passive Balancing Shunt Resistor Active Balancing DC DC Converter",
      channel_name: "Owl WiS",
      duration: "26:40",
      difficulty: "Intermediate",
      topic_focus: "Cell Capacity Variations, Switched Resistor Passive Bleeding, Flyback Active Balancing",
      key_takeaways: [
        "Why cell manufacturing tolerances and temperature gradients cause irreversible cell-to-cell capacity divergence",
        "Passive balancing operation: Dissipating excess energy from high-voltage cells as heat through power resistors and MOSFETs",
        "Active balancing topologies: Transferring charge from highest cell to lowest cell via capacitive/inductive DC-DC converters",
        "Balancing thresholds and thermal management during fast charging and top-of-charge phases"
      ]
    }],
    3: [{
      id: "ee-bms-p3-thermal-runaway",
      title: "Thermal Management, CAN Bus Communication & Thermal Runaway Mitigation",
      youtube_video_id: "RaEvDrT9oFA",
      youtube_url: "https://www.youtube.com/watch?v=RaEvDrT9oFA",
      fallback_video_id: "ECES3VcEIao",
      search_query: "EV Battery Thermal Runaway Propagation Liquid Cooling Plate CAN Bus BMS DBC File",
      channel_name: "Owl WiS",
      duration: "31:50",
      difficulty: "Advanced",
      topic_focus: "SEI Layer Breakdown, Exothermic Propagation, Liquid Cold Plates & CAN 2.0B / CAN-FD Messages",
      key_takeaways: [
        "Cascade stages of thermal runaway: Solid Electrolyte Interphase (SEI) decomposition (>80C), separator melting, catastrophic fire",
        "Design of liquid cooling plates and glycol-water flow rate optimization to keep pack temperature delta < 3C",
        "BMS CAN bus communication: Structuring DBC databases, periodic broadcast messages (pack voltage, max/min cell, DTC alarms)",
        "Insulation monitoring and ground fault detection (isolation resistance > 500 ohms/volt to chassis)"
      ]
    }],
    4: [{
      id: "ee-bms-p4-bms-interview",
      title: "EV BMS Engineer Placement Interview & Functional Safety (ISO 26262 ASIL-D) Viva",
      youtube_video_id: "yDISHgbMpNc",
      youtube_url: "https://www.youtube.com/watch?v=yDISHgbMpNc",
      fallback_video_id: "yEjQ2ZvV-1o",
      search_query: "BMS Engineer Technical Interview Questions ISO 26262 ASIL D Hardware Software Viva",
      channel_name: "CS Electrical And Electronics",
      duration: "30:45",
      difficulty: "Placement",
      topic_focus: "ISO 26262 Safety Goals, Overcurrent Protection, Hardware Watchdogs & Technical Viva",
      key_takeaways: [
        "Functional safety requirements in battery management: ISO 26262 ASIL-D classification for preventing uncommanded contactor weld",
        "Redundant safety mechanisms: Dual voltage sensing channels, independent analog hardware trip comparators, and window watchdogs",
        "Simulating cell faults and pre-charge failure scenarios on real-time Hardware-in-the-Loop (HIL) test benches",
        "Clearing EV powertrain and BMS hardware/firmware engineer interviews at Tesla, Rivian, Lucid, Ather, and Tata Motors"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // ROBOTICS: Robot Kinematics & Inverse Kinematics
  // --------------------------------------------------------------------------
  'rob-kinematics': {
    0: [{
      id: "rob-kin-p0-dh-params",
      title: "Forward Kinematics & Denavit-Hartenberg (DH) Convention Step-by-Step",
      youtube_video_id: "JSEPoyIypHQ",
      youtube_url: "https://www.youtube.com/watch?v=JSEPoyIypHQ",
      fallback_video_id: "kCNK2OXQhio",
      search_query: "Robot Kinematics Forward Kinematics Denavit Hartenberg DH Parameters 4 Parameters",
      channel_name: "ROBOMECHTRIX",
      duration: "25:30",
      difficulty: "Beginner",
      topic_focus: "The 4 DH Parameters (theta, d, a, alpha), Coordinate Frame Assignment & Transformation Matrices",
      key_takeaways: [
        "Coordinate frame assignment rules according to standard Denavit-Hartenberg convention",
        "The 4 DH parameters: Link length (a), link twist (alpha), link offset (d), and joint angle (theta)",
        "Constructing the 4x4 homogenous transformation matrix (Rotational 3x3 + Translation 3x1)",
        "Computing end-effector Cartesian pose by compounding successive link transformation matrices"
      ]
    }],
    1: [{
      id: "rob-kin-p1-inverse-kinematics",
      title: "Inverse Kinematics: Analytical Closed-Form vs Numerical Jacobian Solvers",
      youtube_video_id: "2_cdDGwnl80",
      youtube_url: "https://www.youtube.com/watch?v=2_cdDGwnl80",
      fallback_video_id: "gI-ZSOZUCeM",
      search_query: "Inverse Kinematics Analytical Geometric Algebraic Jacobian Pseudoinverse Damped Least Squares",
      channel_name: "Geat",
      duration: "28:40",
      difficulty: "Intermediate",
      topic_focus: "Pieper's Criterion (Spherical Wrists), Geometric Decoupling, Multiple Solutions & Joint Limits",
      key_takeaways: [
        "Analytical vs numerical inverse kinematics: Closed-form algebraic solutions for 6-DOF arms with spherical wrists (Pieper criterion)",
        "Decoupling wrist center position from end-effector tool orientation",
        "Resolving multiple mathematical solutions (elbow up vs elbow down, shoulder right vs left) based on minimum joint travel",
        "Enforcing physical actuator joint angle and velocity limits during trajectory planning"
      ]
    }],
    2: [{
      id: "rob-kin-p2-jacobian-singularities",
      title: "Robot Jacobian Matrix: Velocity Kinematics, Singularities & Manipulability",
      youtube_video_id: "Wud3aCXiSm8",
      youtube_url: "https://www.youtube.com/watch?v=Wud3aCXiSm8",
      fallback_video_id: "h2YM0CDzDl4",
      search_query: "Robot Jacobian Matrix Geometric Jacobian Singularities Manipulability Ellipsoid",
      channel_name: "Engineering Simplified",
      duration: "30:15",
      difficulty: "Advanced",
      topic_focus: "Linear & Angular Velocity Jacobian, Singular Configurations (det(J) = 0) & Damped Least Squares",
      key_takeaways: [
        "Relating joint velocities to Cartesian end-effector velocities: v = J(q) * q_dot",
        "Constructing the Geometric Jacobian columns for revolute and prismatic joints",
        "Identifying kinematic singularities where determinant of square Jacobian vanishes (det(J) = 0)",
        "Preventing infinite joint speeds near singularities using Damped Least Squares (Levenberg-Marquardt) inversion"
      ]
    }],
    3: [{
      id: "rob-kin-p3-trajectory-dynamics",
      title: "Trajectory Generation (Polynomial / Trapezoidal) & Newton-Euler Robot Dynamics",
      youtube_video_id: "ZASVKAlegfQ",
      youtube_url: "https://www.youtube.com/watch?v=ZASVKAlegfQ",
      fallback_video_id: "-CuMfZcft7I",
      search_query: "Robot Trajectory Planning Cubic Quintic Polynomial Trapezoidal Velocity Newton Euler Dynamics",
      channel_name: "Northwestern Robotics",
      duration: "33:20",
      difficulty: "Advanced",
      topic_focus: "Cubic/Quintic Splines, Trapezoidal Velocity Profiles, Recursive Newton-Euler & Inertia Matrix",
      key_takeaways: [
        "Generating smooth trajectories in joint space: Quintic polynomials ensuring continuous position, velocity, and acceleration",
        "Trapezoidal velocity profiles (Linear Segment with Parabolic Blends - LSPB) for motor acceleration limits",
        "Equations of motion: M(q)*q_ddot + C(q, q_dot)*q_dot + g(q) = tau (torques)",
        "Recursive Newton-Euler forward kinematics and backward force/torque propagation for real-time computed torque control"
      ]
    }],
    4: [{
      id: "rob-kin-p4-kinematics-interview",
      title: "Robotics Kinematics & Controls Placement Interview & Mathematical Viva",
      youtube_video_id: "X4K_lDtOffE",
      youtube_url: "https://www.youtube.com/watch?v=X4K_lDtOffE",
      fallback_video_id: "UlqYPK8Rkis",
      search_query: "Robotics Controls Engineer Interview Questions Kinematics Quaternion Lie Algebra Viva",
      channel_name: "HandZ Maker Lab",
      duration: "31:40",
      difficulty: "Placement",
      topic_focus: "Quaternions vs Euler Angles (Gimbal Lock), Lie Groups (SO3, SE3) & Placement Screening",
      key_takeaways: [
        "Explaining orientation representations: Why unit quaternions avoid Euler angle gimbal lock singularity issues",
        "Introduction to Lie Group SO(3) and SE(3) matrix exponential coordinates for screw axis kinematics",
        "Tuning Cartesian impedance and admittance controllers for compliant robot contact with rigid environments",
        "Acing robotics controls interviews at KUKA, ABB Robotics, Universal Robots, Fanuc, and Boston Dynamics"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // ROBOTICS: Autonomous Navigation & LiDAR SLAM
  // --------------------------------------------------------------------------
  'rob-slam': {
    0: [{
      id: "rob-slm-p0-lidar-basics",
      title: "LiDAR Principles & 2D Point Cloud Processing for Mobile Robots",
      youtube_video_id: "eJZXRncGaGM",
      youtube_url: "https://www.youtube.com/watch?v=eJZXRncGaGM",
      fallback_video_id: "IFNikTHN1pk",
      search_query: "LiDAR Working Principle 2D Laser Scanner Point Cloud Processing LaserScan ROS",
      channel_name: "Articulated Robotics",
      duration: "24:10",
      difficulty: "Beginner",
      topic_focus: "Time of Flight (ToF), LaserScan Message Format, Range/Angle Filtering & Coordinate Frames",
      key_takeaways: [
        "Time-of-Flight (ToF) and triangulation operating physics in 2D planar LiDAR sensors",
        "Structure of sensor_msgs/LaserScan message: angle_min, angle_max, angle_increment, ranges array",
        "Filtering invalid LiDAR readings: Clearing NaN values, inf readings, and clipping out robot chassis occlusions",
        "Transforming raw laser range points into 2D Cartesian coordinates in the laser_frame and base_link"
      ]
    }],
    1: [{
      id: "rob-slm-p1-occupancy-grid",
      title: "Occupancy Grid Mapping & Log-Odds Bayesian Mapping Algorithms",
      youtube_video_id: "8ckhPViqneg",
      youtube_url: "https://www.youtube.com/watch?v=8ckhPViqneg",
      fallback_video_id: "Tvkut1Z7Muw",
      search_query: "Occupancy Grid Mapping Log Odds Inverse Sensor Model Bresenham Ray Tracing",
      channel_name: "Cyrill Stachniss",
      duration: "27:50",
      difficulty: "Intermediate",
      topic_focus: "Bresenham Ray Casting, Log-Odds Representation, Free Space vs Obstacle Cells",
      key_takeaways: [
        "Discretizing continuous 2D physical environments into 2D grid cells (e.g. 5cm x 5cm resolution)",
        "Updating cell probabilities using the Log-Odds recursive formulation to avoid numerical underflow",
        "Using Bresenham line-drawing algorithm for fast ray tracing: Decreasing obstacle probability along beam path",
        "Marking endpoint cells as occupied and publishing nav_msgs/OccupancyGrid map topics"
      ]
    }],
    2: [{
      id: "rob-slm-p2-graph-slam",
      title: "Graph-Based SLAM & Scan Matching: Iterative Closest Point (ICP) & Loop Closure",
      youtube_video_id: "uHbRKvD8TWg",
      youtube_url: "https://www.youtube.com/watch?v=uHbRKvD8TWg",
      fallback_video_id: "saVZtgPyyJQ",
      search_query: "Graph SLAM Tutorial Iterative Closest Point ICP Scan Matching Loop Closure Ceres",
      channel_name: "Cyrill Stachniss",
      duration: "32:15",
      difficulty: "Advanced",
      topic_focus: "Pose Graph Nodes & Spatial Edges, Point-to-Point / Point-to-Line ICP & Loop Closure Detection",
      key_takeaways: [
        "The graph-based SLAM paradigm: Robot poses as graph nodes; odometry and scan matching as constraint edges",
        "Iterative Closest Point (ICP) scan registration: Finding nearest neighbor correspondences and minimizing distance",
        "Detecting loop closures when returning to previously mapped environments via correlative scan matching",
        "Non-linear least squares pose graph optimization (g2o, Ceres Solver) to correct accumulated drift globally"
      ]
    }],
    3: [{
      id: "rob-slm-p3-amcl-nav2",
      title: "Adaptive Monte Carlo Localization (AMCL) & Nav2 Autonomous Navigation",
      youtube_video_id: "jkoGkAd0GYk",
      youtube_url: "https://www.youtube.com/watch?v=jkoGkAd0GYk",
      fallback_video_id: "NrzmH_yerBU",
      search_query: "Adaptive Monte Carlo Localization AMCL Particle Filter ROS 2 Nav2 Costmaps Path Planning",
      channel_name: "Articulated Robotics",
      duration: "34:30",
      difficulty: "Advanced",
      topic_focus: "Particle Filter Tracking, KLD Sampling, Global Costmaps & DWB Local Path Controllers",
      key_takeaways: [
        "Particle filter localization: Representing robot pose uncertainty with cloud particles",
        "Resampling particles based on observation likelihood (matching live laser scans against pre-built static map)",
        "KLD-sampling: Dynamically adjusting particle count based on pose certainty to save CPU compute",
        "Configuring Nav2 costmaps (inflation radius) and dynamic obstacle avoidance using DWB local planners"
      ]
    }],
    4: [{
      id: "rob-slm-p4-slam-interview",
      title: "SLAM / Navigation Engineer Placement Interview & Autonomous Driving Viva",
      youtube_video_id: "e3hnY3Tn1UA",
      youtube_url: "https://www.youtube.com/watch?v=e3hnY3Tn1UA",
      fallback_video_id: "atXF6zmvZT0",
      search_query: "SLAM Engineer Technical Interview Questions LiDAR SLAM EKF Particle Filter Viva",
      channel_name: "CodeLucky",
      duration: "30:20",
      difficulty: "Placement",
      topic_focus: "Wheel Odometry Slip, Visual-Inertial Odometry (VIO), Sensor Fusion & Placement Screening",
      key_takeaways: [
        "Handling wheel odometry slippage using Extended Kalman Filter (robot_localization) fusing IMU and wheel encoders",
        "Explaining the kidnap robot problem and recovery behaviors in production warehouse AGVs",
        "Comparing 2D LiDAR SLAM (Cartographer, Slam Toolbox) with 3D LiDAR SLAM (LIO-SAM, FAST-LIO)",
        "Passing autonomy software interviews at Waymo, Zoox, Skydio, GreyOrange, and Amazon Robotics"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // ROBOTICS: Industrial PLC Programming & Ladder Logic
  // --------------------------------------------------------------------------
  'rob-plc': {
    0: [{
      id: "rob-plc-p0-ladder-basics",
      title: "PLC Programming Basics: Ladder Logic (LAD), Contacts, Coils & Scan Cycle",
      youtube_video_id: "qaI48NCUvkA",
      youtube_url: "https://www.youtube.com/watch?v=qaI48NCUvkA",
      fallback_video_id: "0_b0S_UL0u4",
      search_query: "PLC Programming for Beginners Ladder Logic Normally Open Closed Rung Scan Cycle",
      channel_name: "RealPars",
      duration: "22:45",
      difficulty: "Beginner",
      topic_focus: "Normally Open (NO), Normally Closed (NC), Output Coils, Rung Execution & PLC Scan Cycle",
      key_takeaways: [
        "Understanding the PLC operating scan cycle: Read inputs, execute ladder program logic, update physical outputs, housekeep",
        "Fundamental ladder symbols: Normally Open contact (-[ ]-), Normally Closed contact (-[/]-), and Output Coil (-( )-)",
        "Implementing standard latching circuits (seal-in logic) for motor start/stop push buttons",
        "Interlocking safety circuits to prevent forward and reverse contactors from engaging simultaneously"
      ]
    }],
    1: [{
      id: "rob-plc-p1-timers-counters",
      title: "PLC Timers & Counters: TON, TOF, TP, CTU, CTD & Retentive Memory",
      youtube_video_id: "BHbOXDt5O3o",
      youtube_url: "https://www.youtube.com/watch?v=BHbOXDt5O3o",
      fallback_video_id: "euFbTdFvAiI",
      search_query: "PLC Timers Counters Tutorial TON On Delay TOF Off Delay CTU Count Up",
      channel_name: "RealPars",
      duration: "26:20",
      difficulty: "Intermediate",
      topic_focus: "On-Delay Timer (TON), Off-Delay Timer (TOF), Pulse Timer (TP), Preset Time (PT) & Elapsed Time (ET)",
      key_takeaways: [
        "Configuring On-Delay Timers (TON): Accumulating time when rung is true; energizing output bit after preset time",
        "Configuring Off-Delay Timers (TOF) for delayed cooling fan shutdowns after main machine stoppage",
        "Up-Counters (CTU) and Down-Counters (CTD): Tracking factory conveyor part counts and pallet batching",
        "Retentive timers (TONR) that preserve accumulated elapsed time across momentary power outages"
      ]
    }],
    2: [{
      id: "rob-plc-p2-tia-portal",
      title: "Siemens TIA Portal & Allen-Bradley Studio 5000: Function Blocks (FB) & Data Blocks (DB)",
      youtube_video_id: "rpOhFk6Ki2Y",
      youtube_url: "https://www.youtube.com/watch?v=rpOhFk6Ki2Y",
      fallback_video_id: "osuiU0Rn4OM",
      search_query: "Siemens TIA Portal Tutorial S7 1200 S7 1500 Function Block FB Data Block DB",
      channel_name: "PLC Tech World",
      duration: "29:50",
      difficulty: "Intermediate",
      topic_focus: "Organization Blocks (OB1), Functions (FC), Function Blocks with Instance DBs & Global DBs",
      key_takeaways: [
        "Modular architecture in Siemens S7-1200/1500: Main Organization Block (OB1) calling functions",
        "Functions (FC) for stateless logic vs Function Blocks (FB) requiring dedicated instance Data Blocks (DB)",
        "Creating User-Defined Types (UDT) for standardized factory valve and variable frequency drive (VFD) objects",
        "Structured Text (ST / SCL) programming for complex mathematical recipes and array data handling"
      ]
    }],
    3: [{
      id: "rob-plc-p3-hmi-scada",
      title: "HMI Screen Design, Alarm Management & Industrial Protocols (PROFINET, Modbus TCP)",
      youtube_video_id: "Nfwti91bxoM",
      youtube_url: "https://www.youtube.com/watch?v=Nfwti91bxoM",
      fallback_video_id: "_IlDmg5i6-c",
      search_query: "Siemens WinCC HMI Design PROFINET Modbus TCP Industrial SCADA Alarm Screen",
      channel_name: "PLC Programming Tutorials Tips and Tricks",
      duration: "32:10",
      difficulty: "Advanced",
      topic_focus: "WinCC Comfort Panels, Tag Logging, Discrete/Analog Alarms & PROFINET Network Topologies",
      key_takeaways: [
        "Designing human-machine interface (HMI) operational screens: Push buttons, graphic indicators, numeric IO fields",
        "Configuring discrete fault alarms (E-stop pressed) and analog threshold alarms (over-temperature)",
        "Industrial Ethernet communication: PROFINET IO device commissioning, IP addressing, and GSDML device files",
        "Modbus TCP/IP client-server register mapping (Holding Registers, Input Coils) to third-party sensors"
      ]
    }],
    4: [{
      id: "rob-plc-p4-plc-interview",
      title: "Industrial Automation / PLC Programmer Placement Interview & Troubleshooting Viva",
      youtube_video_id: "d0BhHyc2L3Y",
      youtube_url: "https://www.youtube.com/watch?v=d0BhHyc2L3Y",
      fallback_video_id: "tSXLd7IzWhw",
      search_query: "PLC Programmer Interview Questions Industrial Automation Troubleshooting Hardware Viva",
      channel_name: "Electrical And automation",
      duration: "30:35",
      difficulty: "Placement",
      topic_focus: "Safety PLCs (Safety Integrity Level SIL-3), Emergency Stops & Field Troubleshooting Viva",
      key_takeaways: [
        "Safety PLCs (Fail-Safe CPU) and dual-channel emergency stop circuits with pulse testing to detect cross-shorts",
        "Systematic troubleshooting of electrical control panels: Multimeter diagnostics, 24VDC sinking vs sourcing PNP/NPN inputs",
        "Commissioning analog 4-20mA pressure/temperature loops with signal conditioning and scaling blocks",
        "Passing automation controls engineer interviews at Rockwell Automation, Siemens, ABB, and Schneider Electric"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // ROBOTICS: Computer Vision & YOLO Object Detection
  // --------------------------------------------------------------------------
  'rob-vision': {
    0: [{
      id: "rob-vis-p0-opencv-basics",
      title: "OpenCV Python for Robotics: Color Spaces, Thresholding, Blurring & Edge Detection",
      youtube_video_id: "O9iGVrVOgr8",
      youtube_url: "https://www.youtube.com/watch?v=O9iGVrVOgr8",
      fallback_video_id: "PS7zHKwXWRM",
      search_query: "OpenCV Python Tutorial for Beginners Color Spaces HSV Canny Edge Detection",
      channel_name: "Hello Python By ProgrammingKnowledge",
      duration: "25:15",
      difficulty: "Beginner",
      topic_focus: "BGR to HSV Conversion, cv2.inRange Masking, Gaussian Blur & Canny Edge Detector",
      key_takeaways: [
        "Image representations in NumPy arrays: BGR color channels, pixel intensity slicing (0-255)",
        "Converting to Hue-Saturation-Value (HSV) color space for robust color-based object tracking under changing illumination",
        "Applying Gaussian smoothing filters to eliminate high-frequency camera sensor noise",
        "Canny edge detection algorithm: Gradient magnitude calculation, non-maximum suppression, and hysteresis thresholding"
      ]
    }],
    1: [{
      id: "rob-vis-p1-contours-blobs",
      title: "Contour Detection, Bounding Boxes, Moments & Centroid Tracking in OpenCV",
      youtube_video_id: "6AY5p1uC5gM",
      youtube_url: "https://www.youtube.com/watch?v=6AY5p1uC5gM",
      fallback_video_id: "Fchzk1lDt7Q",
      search_query: "OpenCV Contours FindContours Moments Centroid Bounding Box Area Filter",
      channel_name: "ASSEMTICA ROBOTICS",
      duration: "27:40",
      difficulty: "Intermediate",
      topic_focus: "cv2.findContours, Hierarchy, Spatial Moments (M00, M10, M01), Centroid (cx, cy) & Bounding Rect",
      key_takeaways: [
        "Extracting object contours using cv2.findContours with RETR_EXTERNAL and CHAIN_APPROX_SIMPLE",
        "Filtering small noise blobs using contour area thresholds (cv2.contourArea)",
        "Calculating centroid coordinates (cx = M10/M00, cy = M01/M00) using image spatial moments",
        "Fitting straight bounding boxes (cv2.boundingRect) and rotated minimum area rectangles (cv2.minAreaRect)"
      ]
    }],
    2: [{
      id: "rob-vis-p2-camera-calibration",
      title: "Camera Calibration, Checkerboard Distortion Correction & ArUco Markers",
      youtube_video_id: "H5qbRTikxI4",
      youtube_url: "https://www.youtube.com/watch?v=H5qbRTikxI4",
      fallback_video_id: "3h7wgR5fYik",
      search_query: "Camera Calibration OpenCV Pinhole Model Intrinsic Matrix DistCoeffs ArUco Pose Estimation",
      channel_name: "Kevin Wood | Robotics & AI",
      duration: "29:20",
      difficulty: "Intermediate",
      topic_focus: "Pinhole Camera Model, Intrinsic Matrix (fx, fy, cx, cy), Lens Radial Distortion & ArUco 6-DOF Pose",
      key_takeaways: [
        "Pinhole camera geometry: Focal lengths (fx, fy) and principal point optical center (cx, cy)",
        "Calibrating cameras using standard chessboard targets to find intrinsic camera matrix and lens distortion coefficients",
        "Undistorting fisheye and wide-angle webcam feeds using cv2.undistort",
        "Detecting ArUco fiducial markers and computing 6-DOF relative camera pose (rvec, tvec) using cv2.solvePnP"
      ]
    }],
    3: [{
      id: "rob-vis-p3-yolo-detection",
      title: "YOLO Real-Time Object Detection & Robotic Arm Pick-and-Place Integration",
      youtube_video_id: "ag3DLKsl2vk",
      youtube_url: "https://www.youtube.com/watch?v=ag3DLKsl2vk",
      fallback_video_id: "VScB36Lc_2Q",
      search_query: "YOLOv8 Real Time Object Detection PyTorch Custom Dataset Robot Arm Pick and Place",
      channel_name: "codebasics",
      duration: "33:45",
      difficulty: "Advanced",
      topic_focus: "YOLO Single-Stage Detector Architecture, Bounding Box Coordinates, NMS & Eye-in-Hand Calibration",
      key_takeaways: [
        "YOLO architecture: Single neural network pass predicting bounding box coordinates and class probabilities simultaneously",
        "Non-Maximum Suppression (NMS) and Intersection over Union (IoU) to eliminate duplicate detection boxes",
        "Training custom YOLO models on domain-specific manufacturing parts using transfer learning",
        "Hand-eye calibration (Eye-in-Hand vs Eye-to-Hand): Transforming 2D camera pixel detections into 3D robot workspace coordinates"
      ]
    }],
    4: [{
      id: "rob-vis-p4-vision-interview",
      title: "Computer Vision / Robotics Vision Placement Interview & Technical Screening Viva",
      youtube_video_id: "l2DpF14ngcU",
      youtube_url: "https://www.youtube.com/watch?v=l2DpF14ngcU",
      fallback_video_id: "YbUzFAN740M",
      search_query: "Computer Vision Engineer Interview Questions OpenCV YOLO Epipolar Geometry Viva",
      channel_name: "CareerGuide",
      duration: "31:10",
      difficulty: "Placement",
      topic_focus: "Epipolar Geometry (Fundamental & Essential Matrix), Stereo Depth & Placement Viva",
      key_takeaways: [
        "Stereo vision depth calculation: Disparity d = x_left - x_right; Depth Z = (Baseline * Focal Length) / Disparity",
        "Epipolar geometry principles: Epipoles, epipolar lines, and the Fundamental matrix (F) constraint",
        "Optimizing neural network inference speeds on edge robotics hardware: TensorRT and ONNX Runtime quantization",
        "Cracking computer vision interviews at NVIDIA, Cognex, Keyence, Mujin, and Skydio"
      ]
    }]
  },

  // --------------------------------------------------------------------------
  // ROBOTICS: BLDC Motors, Servos & PID Control Tuning
  // --------------------------------------------------------------------------
  'rob-motors': {
    0: [{
      id: "rob-mot-p0-motor-physics",
      title: "Electric Motor Working Principles: Brushed DC vs Brushless DC (BLDC) vs Stepper Motors",
      youtube_video_id: "wAtN3SEYSco",
      youtube_url: "https://www.youtube.com/watch?v=wAtN3SEYSco",
      fallback_video_id: "yiD5nCfmbV0",
      search_query: "How Brushless DC Motor Works BLDC vs Brushed vs Stepper Motor Comparison",
      channel_name: "CircuitBread",
      duration: "23:50",
      difficulty: "Beginner",
      topic_focus: "Lorentz Force Law, Stator Windings, Permanent Magnet Rotors, Back-EMF & Commutation",
      key_takeaways: [
        "Lorentz force physics: Torque generation from magnetic field interaction with current-carrying conductors",
        "Brushed DC motors: Mechanical commutator and carbon brushes vs BLDC electronic commutation",
        "Stepper motors: Open-loop microstepping precision vs high-speed efficiency limits",
        "Back-Electromotive Force (Back-EMF) generation and motor electrical constants (Kv, Kt in Nm/A)"
      ]
    }],
    1: [{
      id: "rob-mot-p1-bldc-commutation",
      title: "BLDC 6-Step Trapezoidal Commutation & Hall Effect Sensor Sequencing",
      youtube_video_id: "WYJWdMV3YMs",
      youtube_url: "https://www.youtube.com/watch?v=WYJWdMV3YMs",
      fallback_video_id: "fKEzVvwQHQw",
      search_query: "BLDC 6 Step Commutation Hall Effect Sensor Sequence Electronic Speed Controller ESC",
      channel_name: "MATLAB",
      duration: "26:35",
      difficulty: "Intermediate",
      topic_focus: "3 Hall Sensors (120-Degree Spacing), 6 Switching States, Half-Bridge Inverter & ESC Design",
      key_takeaways: [
        "Decoding 3 digital Hall effect sensor output states (120-degree electrical phase shift) to detect rotor angle",
        "The 6-step trapezoidal switching sequence: Energizing 2 out of 3 phases at any instant (1 floating phase)",
        "Zero-crossing detection of Back-EMF on the unenergized phase for sensorless BLDC electronic speed controllers (ESC)",
        "Pulse Width Modulation (PWM) duty cycle control for smooth variable speed regulation"
      ]
    }],
    2: [{
      id: "rob-mot-p2-encoders-feedback",
      title: "Optical & Magnetic Encoders: Quadrature Decoding, Resolution & Position Feedback",
      youtube_video_id: "o1Oev-B7ScM",
      youtube_url: "https://www.youtube.com/watch?v=o1Oev-B7ScM",
      fallback_video_id: "v4BbSzJ-hz4",
      search_query: "Quadrature Encoder Channel A B Index Resolution Counts Per Revolution 4x Decoding",
      channel_name: "DigiKey",
      duration: "28:10",
      difficulty: "Intermediate",
      topic_focus: "Quadrature Channels (A, B) 90-Deg Phase Shift, 4X Edge Decoding, Index Pulse (Z) & Absolute Encoders",
      key_takeaways: [
        "Quadrature encoder operating principles: Channel A and Channel B square waves with 90-degree phase offset",
        "Direction sensing and 4X resolution multiplication using hardware timer edge interrupt counting",
        "Homing calibration using the dedicated single-pulse Index (Z) channel for absolute home positioning",
        "Incremental vs absolute encoders (BiSS-C, SSI, CANopen protocols) that preserve position across power loss"
      ]
    }],
    3: [{
      id: "rob-mot-p3-closed-loop-pid",
      title: "Closed-Loop Cascaded PID Control: Current (Torque), Velocity & Position Loops",
      youtube_video_id: "4p6fOkmaVlI",
      youtube_url: "https://www.youtube.com/watch?v=4p6fOkmaVlI",
      fallback_video_id: "tbgV6caAVcs",
      search_query: "Cascaded PID Motor Control Current Loop Velocity Loop Position Loop ODrive",
      channel_name: "Electrical And automation",
      duration: "32:45",
      difficulty: "Advanced",
      topic_focus: "3-Tier Cascaded Control Architecture, Fast Inner Current Loop (FOC), Bandwidth Hierarchy",
      key_takeaways: [
        "The 3-tier cascaded motor control hierarchy: High-speed inner current loop (10-20 kHz), intermediate velocity loop (1 kHz), outer position loop (100 Hz)",
        "Field-Oriented Control (FOC) current control: Independent PI regulation of direct current (Id=0) and quadrature current (Iq)",
        "Tuning velocity feedforward and acceleration feedforward gains to eliminate tracking latency during fast robotic motions",
        "Preventing mechanical resonance: Setting notch filters and low-pass filter cutoffs on encoder velocity feedback"
      ]
    }],
    4: [{
      id: "rob-mot-p4-motor-interview",
      title: "Robotics Hardware / Motor Drive Engineer Placement Interview & Mechatronics Viva",
      youtube_video_id: "ftXmih5LIb0",
      youtube_url: "https://www.youtube.com/watch?v=ftXmih5LIb0",
      fallback_video_id: "93ad1naQ7zI",
      search_query: "Motor Drive Engineer Interview Questions BLDC FOC Gearbox Backlash Mechatronics Viva",
      channel_name: "GaugeHow AI",
      duration: "30:50",
      difficulty: "Placement",
      topic_focus: "Harmonic Drives, Planetary Gearbox Backlash, Motor Sizing (Torque-Speed Curves) & Viva",
      key_takeaways: [
        "Selecting robotic gearboxes: Zero-backlash strain wave (Harmonic) gears vs high-torque cycloidal and planetary drives",
        "Matching motor torque-speed curves: Continuous operating torque (thermal limit) vs peak intermittent stall torque",
        "Thermal protection: Thermistors (NTC/PTC) embedded in stator windings to prevent demagnetization of neodymium magnets",
        "Acing motor controls and mechatronics technical interviews at Maxon Motor, Moog, Parker Hannifin, and Tesla Bot"
      ]
    }]
  }
};

