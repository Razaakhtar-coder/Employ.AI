with open('c:/Users/RAZA AKHTAR/Desktop/Employ.AI/frontend/src/components/ResumePreview.css', encoding='utf-8') as f:
    css = f.read()

import re

templates = [
    'ats_classic', 'modern', 'professional', 'minimal', 'executive', 'student_fresher',
    'emerald_sidebar', 'lavender_lilac', 'midnight_gold', 'executive_yellow'
]

for t in templates:
    matches = re.findall(rf'(\.template-{t}[^{{]*\{{[^}}]*\}})', css)
    print(f"\n=== CSS for template-{t} (Count: {len(matches)}) ===")
    for m in matches[:5]:
        first_line = m.split('{')[0].strip()
        body = m.split('{')[1].split('}')[0].strip()
        properties = [p.strip() for p in body.split(';') if p.strip()]
        key_props = [p for p in properties if any(k in p for k in ['grid', 'flex', 'height', 'page-break', 'overflow', 'width', 'display'])]
        print(f"  {first_line} -> {key_props}")
