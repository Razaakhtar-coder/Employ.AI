from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field


class RoleSkillItem(BaseModel):
    skill_id: str
    skill_name: str
    domain: str
    is_required: bool
    weight: float
    importance_level: str


class RoleResponse(BaseModel):
    id: str
    title: str
    slug: str
    domain: str
    department_affinity: Optional[str] = None
    description: Optional[str] = None
    min_exp_months: int
    skills: List[RoleSkillItem] = []

    class Config:
        from_attributes = True


class SkillMatchItem(BaseModel):
    skill_id: str
    skill_name: str
    is_required: bool
    proficiency: str = "intermediate"
    source: str = "resume"


class MissingSkillItem(BaseModel):
    skill_id: str
    skill_name: str
    domain: str
    is_required: bool
    importance_level: str
    recommendation: Optional[str] = None


class MatchBreakdown(BaseModel):
    required_skills_score: float = Field(..., description="Coverage of mandatory skills (0-100)")
    preferred_skills_score: float = Field(..., description="Coverage of bonus/preferred skills (0-100)")
    projects_relevance_score: float = Field(..., description="Project domain alignment (0-100)")
    education_eligibility_score: float = Field(..., description="Degree and department eligibility (0-100)")
    overall_match: float = Field(..., description="Weighted composite match score (0-100)")


class ExplainabilityNarrative(BaseModel):
    summary: str
    why_matches: List[str]
    missing_critical_gaps: List[str]
    recommended_action_plan: List[str]


class SkillGapResponse(BaseModel):
    id: Optional[str] = None
    role_id: str
    role_title: str
    role_domain: str
    match_percentage: float
    breakdown: MatchBreakdown
    matched_skills: List[SkillMatchItem]
    missing_skills: List[MissingSkillItem]
    explainability: ExplainabilityNarrative
    calculated_at: Optional[datetime] = None


class RoleEvaluationRequest(BaseModel):
    role_id: Optional[str] = None
    custom_skills: Optional[List[str]] = None
