import React, { useRef, useEffect, useState, useCallback, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { useHologramTheme } from '../context/HologramThemeContext';
import { taxonomyApi, profileApi, matchingApi } from '../services/api';
import type { SkillItem, CareerRole, StudentSkillItem, LearningRoadmap } from '../types';
import { DOMAIN_CO_DOMAINS, generateCoDomainRoadmap } from '../utils/domainRoadmapData';
import { YouTubePracticeStudio } from './YouTubePracticeStudio';
import { 
  Sparkles, Filter, CheckCircle2, AlertCircle, RefreshCw, 
  Search, Scale, Briefcase, Receipt, BookOpen, HeartPulse, 
  Activity, Code, BarChart3, Wrench, Building2, Zap, FlaskConical, 
  Globe, Compass, Target, TrendingUp, Award, DollarSign, 
  ArrowRight, Play, Pause, ZoomIn, ZoomOut, 
  Layers, Check, ChevronRight, X, ExternalLink,
  Plane, Navigation, Users, Bot, Anchor, Dna,
  CheckCircle, Copy, HelpCircle, Lightbulb
} from 'lucide-react';

export interface GalaxyDomain {
  id: string;
  name: string;
  badge: string;
  group: 'Universal' | 'Engineering' | 'Aviation & Hospitality' | 'Law & Commerce' | 'Healthcare & Medicine' | 'Humanities';
  icon: React.ComponentType<{ size?: number; className?: string; color?: string; style?: React.CSSProperties }>;
  color: string;
  glow: string;
  description: string;
  careerFocus: string;
  marketDemand: string;
  avgSalary: string;
  topRoles: string[];
  certifications: string[];
  emergingTrends: string[];
  learningMilestones: { step: string; title: string; desc: string }[];
}

export const GALAXY_DOMAINS: GalaxyDomain[] = [
  {
    id: 'All',
    name: 'Universal Multi-Domain Universe',
    badge: 'All Universe',
    group: 'Universal',
    icon: Globe,
    color: '#38bdf8',
    glow: 'rgba(56, 189, 248, 0.4)',
    description: 'Cross-disciplinary universal skill constellation across Engineering, Aviation, Law, Commerce, Healthcare, and Humanities.',
    careerFocus: 'Universal Academia & Industry Ecosystem',
    marketDemand: '98% Multi-Disciplinary Hiring Surge',
    avgSalary: '₹7.5L – ₹35.0L / yr',
    topRoles: ['Fullstack Engineer', 'Commercial Pilot', 'Corporate Legal Counsel', 'Aeronautical Specialist'],
    certifications: ['AWS Cloud Solutions', 'DGCA License', 'Bar Council Certification', 'CPA / CA Ind AS'],
    emergingTrends: ['AI-Augmented Workflows', 'eVTOL Urban Air Mobility', 'Autonomous Process Optimization'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Foundational Competencies', desc: 'Core domain basics, academic curriculum mastery, and diagnostic assessments.' },
      { step: 'Phase 2', title: 'Applied Industry Tooling', desc: 'Hands-on frameworks, standardized simulation, and industry internships.' },
      { step: 'Phase 3', title: 'Capstone & Placement Delivery', desc: 'Verified live projects, placement portfolio reviews, and role benchmarking.' }
    ]
  },
  {
    id: 'Aeronautical',
    name: 'Aeronautical & Aerospace Engineering',
    badge: 'Aeronautical',
    group: 'Engineering',
    icon: Plane,
    color: '#0ea5e9',
    glow: 'rgba(14, 165, 233, 0.4)',
    description: 'Aerodynamics, computational fluid dynamics (CFD), aircraft structures, propulsion systems, flight dynamics, and avionics integration.',
    careerFocus: 'Aircraft Design Engineer, Propulsion Systems Lead, Aerodynamics Specialist, Flight Test Engineer',
    marketDemand: '94% High Growth (Defense & Civil Aviation Expansion)',
    avgSalary: '₹8.0L – ₹30.0L / yr',
    topRoles: ['Aircraft Structural Design Engineer', 'Gas Turbine Propulsion Lead', 'Aerospace CFD Analyst', 'Avionics Flight Control Specialist'],
    certifications: ['DGCA Aeronautical Systems Specialist', 'ANSYS Fluent Aerospace CFD Certification', 'CATIA V5 Aerospace Part & Assembly Design'],
    emergingTrends: ['Hypersonic Aerodynamics', 'Electric Aircraft Hybrid Propulsion', 'Autonomous Flight Avionics'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Fluid Mechanics & Aerodynamics', desc: 'Incompressible/compressible airflow, boundary layer theory, and airfoil lift/drag polar curves.' },
      { step: 'Phase 2', title: 'Propulsion & Structural Analysis', desc: 'Gas turbine thermodynamic cycles, rocket propulsion, and composite fuselage stress analysis.' },
      { step: 'Phase 3', title: 'Flight Mechanics & CFD Simulation', desc: 'Flight control stability derivatives, ANSYS Fluent mesh generation, and wind tunnel testing.' }
    ]
  },
  {
    id: 'Aviation',
    name: 'Aviation & Commercial Pilot Studies',
    badge: 'Commercial Pilot',
    group: 'Aviation & Hospitality',
    icon: Navigation,
    color: '#38bdf8',
    glow: 'rgba(56, 189, 248, 0.4)',
    description: 'Instrument Flight Rules (IFR), flight management systems (FMS), aviation meteorology, crew resource management (CRM), and multi-engine aerodynamics.',
    careerFocus: 'Commercial Airline Pilot (First Officer), Flight Operations Officer, Flight Instructor (CFI)',
    marketDemand: '96% Surge (Global Fleet & Airline Expansion)',
    avgSalary: '₹14.0L – ₹45.0L / yr',
    topRoles: ['Commercial Airline Pilot (First Officer)', 'Flight Operations & Dispatch Lead', 'Certified Flight Instructor (CFI)', 'Air Traffic & Navigation Specialist'],
    certifications: ['Commercial Pilot License (CPL - DGCA/FAA)', 'Instrument Rating (IR) & Multi-Engine (MER)', 'Airline Transport Pilot License (ATPL Ground)'],
    emergingTrends: ['eVTOL Urban Air Taxi Operations', 'NextGen Satellite Air Navigation (ADS-B)', 'AI-Assisted Flight Optimization'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Aviation Ground School & Meteorology', desc: 'Air navigation, aviation meteorology, air law, and aircraft technical general systems.' },
      { step: 'Phase 2', title: 'Single & Multi-Engine Flight Training', desc: '200+ logged flight hours, solo cross-country, night flying, and instrument flying procedures.' },
      { step: 'Phase 3', title: 'Type Rating & Airline Simulator Prep', desc: 'A320 / B737 Multi-Crew Cooperation (MCC), Jet Orientation Course (JOC), and DGCA checks.' }
    ]
  },
  {
    id: 'Cabin Crew',
    name: 'Cabin Crew & In-Flight Hospitality Management',
    badge: 'Cabin Crew / Air Hostess',
    group: 'Aviation & Hospitality',
    icon: Users,
    color: '#f43f5e',
    glow: 'rgba(244, 63, 94, 0.4)',
    description: 'In-flight passenger safety, aviation first aid & CPR, emergency evacuation drills, DGCA air regulations, and luxury hospitality standards.',
    careerFocus: 'International Flight Attendant, Senior In-Flight Cabin Manager, VIP Corporate Aviation Lead',
    marketDemand: '95% Surge (Massive Airline Fleet Deliveries)',
    avgSalary: '₹6.0L – ₹20.0L / yr',
    topRoles: ['International Flight Attendant', 'Senior Cabin Crew In-Charge', 'Corporate Aviation VIP Specialist', 'In-Flight Safety & Quality Officer'],
    certifications: ['DGCA Cabin Crew Attestation License', 'IATA Aviation Cabin Crew Diploma', 'Emergency First Aid & CPR (Red Cross / AHA)'],
    emergingTrends: ['Digital In-Flight Cabin Tablets', 'Sustainable In-Flight Eco-Operations', 'Enhanced Aviation Mental Well-Being & Crisis Handling'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Aviation Safety & Air Regulations', desc: 'Emergency exits, ditching procedures, slide deployment, fire fighting, and DGCA security standards.' },
      { step: 'Phase 2', title: 'Aviation First Aid & Emergency Response', desc: 'Hypoxia management, CPR, AED operation, emergency childbirth, and triage procedures.' },
      { step: 'Phase 3', title: 'In-Flight Service & Conflict De-escalation', desc: 'Multi-cultural passenger etiquette, luxury galley operations, and assertive conflict resolution.' }
    ]
  },
  {
    id: 'Robotics',
    name: 'Robotics, Automation & Mechatronics',
    badge: 'Robotics & Automation',
    group: 'Engineering',
    icon: Bot,
    color: '#a855f7',
    glow: 'rgba(168, 85, 247, 0.4)',
    description: 'Robot Operating System (ROS 2), inverse kinematics, autonomous navigation SLAM, PLC industrial automation, computer vision, and motor actuators.',
    careerFocus: 'Robotics Software Engineer, Autonomous Systems Specialist, Industrial Automation Lead',
    marketDemand: '95% High Demand across Smart Factories & Warehousing',
    avgSalary: '₹8.5L – ₹30.0L / yr',
    topRoles: ['Robotics Software Engineer (ROS 2)', 'Autonomous Mobile Robot (AMR) Specialist', 'Industrial Automation & PLC Lead', 'Computer Vision SLAM Engineer'],
    certifications: ['ROS 2 Industrial Robotics Developer', 'Siemens Certified PLC Automation Engineer', 'NVIDIA Isaac Sim Autonomous Systems'],
    emergingTrends: ['Humanoid Bipedal Locomotion', 'Generative AI for Robot Task Planning', 'Industrial Digital Twin Simulation'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Robotics Kinematics & Motor Actuation', desc: 'Forward/inverse kinematics, PID control loops, BLDC motors, and microcontroller interfacing.' },
      { step: 'Phase 2', title: 'ROS 2 & Sensor Fusion SLAM', desc: 'LiDAR point cloud processing, ROS 2 nodes/topics, Gazebo simulation, and Nav2 path planning.' },
      { step: 'Phase 3', title: 'Industrial Deployment & Vision', desc: 'OpenCV object detection, industrial PLC ladder logic, and autonomous grasping.' }
    ]
  },
  {
    id: 'Computer Science',
    name: 'Computer Science & Software Engineering',
    badge: 'Computer Science',
    group: 'Engineering',
    icon: Code,
    color: '#3b82f6',
    glow: 'rgba(59, 130, 246, 0.4)',
    description: 'Fullstack cloud development, Python, React, modern REST APIs, containerization, DevOps CI/CD, and cybersecurity.',
    careerFocus: 'Fullstack Cloud Engineer, Backend System Architect, AI/ML Specialist',
    marketDemand: '96% High Demand (Surge in AI/Cloud)',
    avgSalary: '₹8.5L – ₹32.0L / yr',
    topRoles: ['Fullstack Cloud Engineer', 'Backend System Architect', 'DevOps & Site Reliability Lead', 'Applied ML Specialist'],
    certifications: ['AWS Certified Solutions Architect', 'CKA (Kubernetes Administrator)', 'Meta Full-Stack Engineer'],
    emergingTrends: ['Agentic AI Architecture', 'Serverless Edge Microservices', 'Zero-Trust Cybersecurity'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Algorithms & Data Structures', desc: 'Time complexity, core algorithms, Python/TypeScript programming, and Git workflows.' },
      { step: 'Phase 2', title: 'Fullstack Systems & APIs', desc: 'React, Node/FastAPI, PostgreSQL relational modeling, and Docker microservices.' },
      { step: 'Phase 3', title: 'Cloud & Distributed Deployments', desc: 'AWS/GCP infrastructure, Kubernetes orchestration, CI/CD pipelines, and observability.' }
    ]
  },
  {
    id: 'Biotechnology',
    name: 'Biotechnology & Biomedical Engineering',
    badge: 'Biotechnology',
    group: 'Engineering',
    icon: Dna,
    color: '#10b981',
    glow: 'rgba(16, 185, 129, 0.4)',
    description: 'Genetic engineering, bioreactor fermentation, CRISPR gene editing, medical device design, and bioinformatics sequence modeling.',
    careerFocus: 'Bioprocess Development Scientist, Biomedical Device Engineer, Clinical Bio-Informatician',
    marketDemand: '90% Strong Demand across Biopharma & MedTech',
    avgSalary: '₹6.5L – ₹25.0L / yr',
    topRoles: ['Bioprocess Scientist (Upstream/Downstream)', 'Bioinformatics Sequence Analyst', 'Medical Device R&D Engineer', 'Clinical Assay Development Lead'],
    certifications: ['Regulatory Affairs Certified (RAC - Biopharma)', 'Six Sigma in Bio-Manufacturing', 'NCBI Bio-Informatics Tools Specialist'],
    emergingTrends: ['CRISPR Therapeutic Delivery', 'AI Protein Structure Prediction (AlphaFold)', 'Single-Use Bioreactor Scalability'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Molecular Biology & Biochemistry', desc: 'DNA/RNA extraction, PCR amplification, protein purification, and microbiology techniques.' },
      { step: 'Phase 2', title: 'Fermentation & Bio-Process Engineering', desc: 'Bioreactor parameters (DO, pH, agitation), downstream chromatography, and cGMP compliance.' },
      { step: 'Phase 3', title: 'Bioinformatics & Regulatory Validation', desc: 'Next-Gen Sequencing (NGS) data pipelines, Python BioPython, and FDA/CDSCO filings.' }
    ]
  },
  {
    id: 'Marine',
    name: 'Marine & Ocean Engineering',
    badge: 'Marine Engineering',
    group: 'Engineering',
    icon: Anchor,
    color: '#0284c7',
    glow: 'rgba(2, 132, 199, 0.4)',
    description: 'Naval architecture, ship hydrodynamics, marine diesel engine propulsion, offshore platforms, and IMO maritime environmental safety.',
    careerFocus: 'Marine Propulsion Engineer, Naval Architect, Offshore Structural Engineer, Maritime Surveyor',
    marketDemand: '88% High Demand across Global Shipping & Energy',
    avgSalary: '₹7.5L – ₹28.0L / yr',
    topRoles: ['Marine Propulsion Engineer (Class IV/II)', 'Naval Architect & Hull Designer', 'Offshore Platform Structural Engineer', 'Maritime Safety & Class Surveyor'],
    certifications: ['DG Shipping MEO Class Certification', 'SNAME Certified Naval Architect', 'Lloyds Register Marine Quality Auditor'],
    emergingTrends: ['Green Methanol / Ammonia Ship Propulsion', 'Autonomous Unmanned Surface Vessels (USV)', 'Digital Twin Engine Monitoring'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Ship Hydrostatics & Stability', desc: 'Archimedes principle, metacentric height, cross curves of stability, and resistance calculations.' },
      { step: 'Phase 2', title: 'Marine Diesel & Auxiliary Systems', desc: '2-stroke low-speed marine diesels, boilers, purifiers, fresh water generators, and steering gears.' },
      { step: 'Phase 3', title: 'Naval CAD & Sea-Time Training', desc: 'Maxsurf hull modeling, propeller cavitation analysis, and onboard watchkeeping.' }
    ]
  },
  {
    id: 'BA LLB',
    name: 'Law & Legal Studies (BA LLB / LLB)',
    badge: 'BA LLB (Law)',
    group: 'Law & Commerce',
    icon: Scale,
    color: '#f59e0b',
    glow: 'rgba(245, 158, 11, 0.4)',
    description: 'Contract drafting, corporate governance & compliance, civil litigation, dispute resolution, statutory research, and IPR.',
    careerFocus: 'Corporate Legal Associate, Compliance & Dispute Specialist, Legal Tech Counsel',
    marketDemand: '89% High Demand in Corporate & FinTech Law',
    avgSalary: '₹7.0L – ₹26.0L / yr',
    topRoles: ['Corporate Legal Associate', 'Regulatory Compliance Officer', 'Commercial Contract Specialist', 'IPR & Patent Attorney'],
    certifications: ['Bar Council All India Bar Exam (AIBE)', 'FICCI IPR & Patent Drafting', 'Corporate Governance Compliance (ICSI)'],
    emergingTrends: ['AI Contract Review Automation', 'Cross-Border Data Privacy Law (DPDP)', 'FinTech Regulatory Sandboxes'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Jurisprudence & Constitutional Law', desc: 'Statutory interpretation, constitutional principles, case law synthesis, and legal research.' },
      { step: 'Phase 2', title: 'Contract Drafting & Due Diligence', desc: 'Commercial agreements, dispute resolution procedures, and corporate governance compliance.' },
      { step: 'Phase 3', title: 'Moot Court & Corporate Practice', desc: 'Litigation advocacy, regulatory audits, IPR filing, and corporate advisory.' }
    ]
  },
  {
    id: 'BCOM',
    name: 'Commerce, Accounting & Taxation (BCOM / CA)',
    badge: 'BCOM (Commerce)',
    group: 'Law & Commerce',
    icon: Receipt,
    color: '#10b981',
    glow: 'rgba(16, 185, 129, 0.4)',
    description: 'Financial accounting, Ind AS compliance, GST & TDS filing, statutory auditing, Tally Prime, and financial modeling.',
    careerFocus: 'Financial & Tax Accountant, Statutory Assurance Specialist, Financial Analyst',
    marketDemand: '92% Strong Demand across Corporate & FinTech',
    avgSalary: '₹6.0L – ₹22.0L / yr',
    topRoles: ['Financial & Tax Accountant', 'Statutory Audit Specialist', 'Financial Modeling Analyst', 'Direct/Indirect Tax Consultant'],
    certifications: ['ICAI CA Intermediate / Final', 'ACCA (Global Chartered Accountant)', 'TallyPrime Certified Professional'],
    emergingTrends: ['Automated GST Reconciliation', 'Algorithmic Financial Forecasting', 'ESG Financial Reporting Standards'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Financial Accounting & Ind AS', desc: 'Double-entry bookkeeping, trial balance, P&L statements, and Indian Accounting Standards.' },
      { step: 'Phase 2', title: 'Taxation & Audit Methodologies', desc: 'GST/TDS filings, corporate tax computation, statutory auditing, and Tally Prime.' },
      { step: 'Phase 3', title: 'Corporate Finance & Modeling', desc: 'Discounted cash flow (DCF), 3-statement financial modeling, and audit documentation.' }
    ]
  },
  {
    id: 'BBA',
    name: 'Business Administration & Management (BBA / MBA)',
    badge: 'BBA (Management)',
    group: 'Law & Commerce',
    icon: Briefcase,
    color: '#ec4899',
    glow: 'rgba(236, 72, 153, 0.4)',
    description: 'Business strategy & operations, brand marketing, HRM, market research, consumer insights, and product lifecycle management.',
    careerFocus: 'Business Operations & Strategy Associate, Product Operations Lead, Brand Strategist',
    marketDemand: '91% High Demand across Startups & Enterprises',
    avgSalary: '₹6.5L – ₹24.0L / yr',
    topRoles: ['Business Operations Associate', 'Product Operations Manager', 'Growth & Brand Marketing Strategist', 'Human Capital Partner'],
    certifications: ['Project Management Professional (PMP)', 'Google Certified Digital Marketing Lead', 'SHRM Certified Professional'],
    emergingTrends: ['Product-Led Growth (PLG)', 'AI-Driven Consumer Analytics', 'Agile Supply Chain Resilience'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Management Principles & Microeconomics', desc: 'Organizational behavior, business communication, and market dynamics.' },
      { step: 'Phase 2', title: 'Operations, Marketing & Financial ROI', desc: 'Customer acquisition, unit economics, supply chain workflows, and KPI dashboards.' },
      { step: 'Phase 3', title: 'Strategic Product & Brand Execution', desc: 'Market entry strategies, operational scaling, and cross-functional leadership.' }
    ]
  },
  {
    id: 'Nursing',
    name: 'Nursing & Patient Care (B.Sc Nursing / GNM)',
    badge: 'Nursing (Healthcare)',
    group: 'Healthcare & Medicine',
    icon: HeartPulse,
    color: '#06b6d4',
    glow: 'rgba(6, 182, 212, 0.4)',
    description: 'Clinical patient care & triage, ICU hemodynamic monitoring, pharmacology, infection control, and BLS/ACLS emergency protocols.',
    careerFocus: 'Clinical Staff Nurse (Critical Care), Emergency Triage Specialist, Healthcare Quality Lead',
    marketDemand: '97% Critical Global & National Demand',
    avgSalary: '₹5.5L – ₹18.0L / yr',
    topRoles: ['Critical Care Staff Nurse (ICU)', 'Emergency Triage Specialist', 'Pediatric Care Specialist', 'Hospital Quality & Infection Officer'],
    certifications: ['Basic Life Support (BLS - AHA)', 'Advanced Cardiovascular Life Support (ACLS)', 'NABH Healthcare Quality Assessor'],
    emergingTrends: ['Smart ICU Telemonitoring', 'Point-of-Care Digital Diagnostics', 'Automated Infusion Protocols'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Anatomy, Physiology & Nursing Fundamentals', desc: 'Patient hygiene, vital signs monitoring, aseptic technique, and medical documentation.' },
      { step: 'Phase 2', title: 'Medical-Surgical & Pharmacology', desc: 'Medication administration, wound care, IV cannulation, and perioperative nursing.' },
      { step: 'Phase 3', title: 'Critical Care & Emergency Triage', desc: 'Ventilator management, CPR/ACLS algorithms, code blue response, and patient advocacy.' }
    ]
  },
  {
    id: 'MBBS',
    name: 'Medicine & Clinical Sciences (MBBS / MD)',
    badge: 'MBBS (Clinical)',
    group: 'Healthcare & Medicine',
    icon: Activity,
    color: '#ef4444',
    glow: 'rgba(239, 68, 68, 0.4)',
    description: 'Systemic clinical examination, differential diagnosis, acute trauma stabilization, radiology/lab interpretation, and medical ethics.',
    careerFocus: 'Resident Medical Officer (RMO), Clinical Trainee Specialist, Emergency Physician',
    marketDemand: '99% Essential High Priority',
    avgSalary: '₹9.0L – ₹35.0L / yr',
    topRoles: ['Resident Medical Officer (RMO)', 'Emergency Medicine Specialist', 'Clinical Research Associate', 'Primary Care Physician'],
    certifications: ['National Medical Commission (NMC) License', 'ATLS (Advanced Trauma Life Support)', 'GCP Clinical Trial Certification'],
    emergingTrends: ['AI-Assisted Diagnostic Radiology', 'Precision Pharmacogenomics', 'Telemedicine Emergency Networks'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Pre-Clinical & Paraclinical Sciences', desc: 'Anatomy, biochemistry, pathology, pharmacology, and microbiological diagnostics.' },
      { step: 'Phase 2', title: 'Clinical Bedside Medicine & Surgery', desc: 'History taking, physical examination, ECG interpretation, and clinical management.' },
      { step: 'Phase 3', title: 'Rotational Internship & Emergency Care', desc: 'Trauma resuscitations, ward rounds, minor surgical procedures, and medical ethics.' }
    ]
  },
  {
    id: 'Business Analytics',
    name: 'Data & Business Analytics',
    badge: 'Business Analytics',
    group: 'Engineering',
    icon: BarChart3,
    color: '#8b5cf6',
    glow: 'rgba(139, 92, 246, 0.4)',
    description: 'Power BI, Tableau, Advanced Excel, SQL modeling, data wrangling, BPMN workflows, and requirements gathering.',
    careerFocus: 'Business Intelligence Analyst, Data Analytics Associate, Strategy Insights Consultant',
    marketDemand: '94% High Growth across Consulting & Tech',
    avgSalary: '₹7.5L – ₹28.0L / yr',
    topRoles: ['Business Intelligence Analyst', 'Data Analytics Associate', 'SQL & Data Warehouse Developer', 'Decision Sciences Consultant'],
    certifications: ['Microsoft Certified: Power BI Data Analyst (PL-300)', 'Tableau Certified Data Analyst', 'AWS Certified Data Analytics'],
    emergingTrends: ['Automated Insight Generation', 'Real-time Streaming Analytics', 'Semantic Layer Modeling'],
    learningMilestones: [
      { step: 'Phase 1', title: 'SQL & Advanced Data Manipulation', desc: 'Relational database querying, window functions, CTEs, and Excel financial modeling.' },
      { step: 'Phase 2', title: 'Dashboarding & BI Visualization', desc: 'Power BI, DAX measures, Tableau calculated fields, and interactive executive reporting.' },
      { step: 'Phase 3', title: 'Predictive Modeling & Business Storytelling', desc: 'Python exploratory data analysis, hypothesis testing, and stakeholder presentation.' }
    ]
  },
  {
    id: 'Mechanical',
    name: 'Mechanical & Manufacturing Engineering',
    badge: 'Mechanical',
    group: 'Engineering',
    icon: Wrench,
    color: '#f97316',
    glow: 'rgba(249, 115, 22, 0.4)',
    description: 'SolidWorks, CATIA, GD&T, FEA structural analysis, ANSYS simulation, and CNC manufacturing processes.',
    careerFocus: 'Manufacturing Engineer, CAD Design Engineer, Thermal & Structural Analyst',
    marketDemand: '88% Steady Growth (EV & Robotics surge)',
    avgSalary: '₹6.5L – ₹24.0L / yr',
    topRoles: ['CAD/CAM Design Engineer', 'Finite Element Analysis (FEA) Specialist', 'EV Battery Mechanical Designer', 'Manufacturing Process Lead'],
    certifications: ['CSWP (Certified SolidWorks Professional)', 'ANSYS Certified Simulation Specialist', 'Six Sigma Green Belt (ASQ)'],
    emergingTrends: ['Electric Vehicle Battery Enclosures', 'Generative Mechanical Design', 'Additive 3D Metal Manufacturing'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Engineering Mechanics & Thermodynamics', desc: 'Kinematics, strength of materials, fluid mechanics, and material science.' },
      { step: 'Phase 2', title: '3D CAD Modeling & GD&T Standards', desc: 'SolidWorks parametric part design, complex assembly drafting, and geometric tolerances.' },
      { step: 'Phase 3', title: 'FEA Simulation & Manufacturing', desc: 'ANSYS stress/thermal simulation, CNC toolpaths, and DFM (Design for Manufacturing).' }
    ]
  },
  {
    id: 'Civil',
    name: 'Civil & Structural Engineering',
    badge: 'Civil',
    group: 'Engineering',
    icon: Building2,
    color: '#eab308',
    glow: 'rgba(234, 179, 8, 0.4)',
    description: 'STAAD.Pro, Revit BIM clash detection, ETABS structural modeling, quantity estimation, and geotechnical engineering.',
    careerFocus: 'Structural Engineer, BIM Project Coordinator, Infrastructure Project Manager',
    marketDemand: '87% Strong Growth across Infrastructure & Smart Cities',
    avgSalary: '₹6.0L – ₹23.0L / yr',
    topRoles: ['Structural Design Engineer', 'BIM Project Coordinator', 'Geotechnical Site Engineer', 'Construction Project Lead'],
    certifications: ['Autodesk Certified Professional: Revit BIM', 'Bentley STAAD.Pro Certified Specialist', 'Project Management in Construction'],
    emergingTrends: ['4D/5D BIM Construction Simulation', 'Carbon-Neutral Green Concrete', 'IoT Structural Health Monitoring'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Structural Analysis & Concrete Design', desc: 'Bending moment diagrams, shear forces, RCC design to IS 456, and steel structures.' },
      { step: 'Phase 2', title: 'STAAD.Pro & BIM Modeling', desc: 'Seismic & wind load modeling in STAAD.Pro, Revit architectural clash detection, and BOQ.' },
      { step: 'Phase 3', title: 'Site Project Management & Geotechnical', desc: 'Soil bearing capacity testing, foundation design, and site project scheduling.' }
    ]
  },
  {
    id: 'Electrical',
    name: 'Electrical & Electronics Engineering',
    badge: 'Electrical',
    group: 'Engineering',
    icon: Zap,
    color: '#14b8a6',
    glow: 'rgba(20, 184, 166, 0.4)',
    description: 'VLSI circuit design, Embedded C firmware, Verilog HDL, Altium PCB design, MATLAB Simulink, and IoT microcontrollers.',
    careerFocus: 'Embedded Systems Engineer, VLSI Design Engineer, Power Systems Specialist',
    marketDemand: '93% Surge (Semiconductors & EV Powertrains)',
    avgSalary: '₹7.5L – ₹29.0L / yr',
    topRoles: ['Embedded Firmware Engineer', 'VLSI Physical Design Specialist', 'EV Powertrain & BMS Engineer', 'IoT Hardware Systems Architect'],
    certifications: ['Cadence VLSI Design Professional', 'ARM Accredited MCU Engineer', 'IEEE Power Electronics Specialist'],
    emergingTrends: ['RISC-V Custom Silicon Cores', 'Silicon Carbide (SiC) Power Inverters', 'Edge AI Embedded Microcontrollers'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Analog & Digital Circuit Theory', desc: 'Kirchhoff laws, semiconductor devices, op-amps, and logic gate architectures.' },
      { step: 'Phase 2', title: 'Embedded C & PCB Layout Design', desc: 'Microcontroller peripherals (UART, SPI, I2C), Altium PCB routing, and firmware debugging.' },
      { step: 'Phase 3', title: 'VLSI Synthesis & Power System Modeling', desc: 'Verilog RTL coding, timing closure, MATLAB Simulink motor control, and BMS design.' }
    ]
  },
  {
    id: 'Chemical',
    name: 'Chemical & Process Engineering',
    badge: 'Chemical',
    group: 'Engineering',
    icon: FlaskConical,
    color: '#84cc16',
    glow: 'rgba(132, 204, 22, 0.4)',
    description: 'Aspen Plus steady-state simulation, chemical process design, reaction thermodynamics, HAZOP safety, and P&ID.',
    careerFocus: 'Process Engineer, Chemical Plant Safety Specialist, Petrochemical Refining Lead',
    marketDemand: '86% Steady Industrial Growth',
    avgSalary: '₹6.5L – ₹25.0L / yr',
    topRoles: ['Chemical Process Design Engineer', 'Plant Safety & HAZOP Specialist', 'Petrochemical Operations Engineer', 'Bio-Process Systems Lead'],
    certifications: ['Aspen Plus Certified User', 'NEBOSH International Safety Certificate', 'IChemE Associate Member'],
    emergingTrends: ['Green Hydrogen Electrolysis Design', 'Carbon Capture & Storage (CCS)', 'Digital Twin Process Simulation'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Mass & Energy Balances', desc: 'Chemical reaction stoichiometry, phase equilibrium thermodynamics, and fluid dynamics.' },
      { step: 'Phase 2', title: 'Unit Operations & Aspen Simulation', desc: 'Distillation column design, heat exchanger network synthesis, and Aspen Plus P&ID.' },
      { step: 'Phase 3', title: 'Plant Safety, HAZOP & Scale-Up', desc: 'Process hazard analysis, reactor scale-up calculations, and environmental compliance.' }
    ]
  },
  {
    id: 'BA Hons',
    name: 'Humanities & Social Sciences (BA Hons)',
    badge: 'BA Hons (Humanities)',
    group: 'Humanities',
    icon: BookOpen,
    color: '#a855f7',
    glow: 'rgba(168, 85, 247, 0.4)',
    description: 'Macroeconomic policy analysis, qualitative/quantitative research, public policy drafting, behavioral psychology, and communications.',
    careerFocus: 'Public Policy & Research Analyst, Communications Strategist, International Relations Associate',
    marketDemand: '85% Steady Demand across Think Tanks & NGOs',
    avgSalary: '₹5.5L – ₹20.0L / yr',
    topRoles: ['Public Policy Research Analyst', 'Strategic Communications Lead', 'Behavioral Insights Researcher', 'International Development Officer'],
    certifications: ['Certified Policy Analyst (CPA)', 'Qualitative Research Methods (SPSS/R)', 'Corporate ESG & CSR Strategist'],
    emergingTrends: ['Computational Social Science', 'Digital Public Infrastructure (DPI) Policy', 'Behavioral Economics for Governance'],
    learningMilestones: [
      { step: 'Phase 1', title: 'Social Theory & Qualitative Research', desc: 'Epistemology, ethnography, structured interviews, and historical policy analysis.' },
      { step: 'Phase 2', title: 'Quantitative Data Analysis & Policy Drafting', desc: 'SPSS/R statistical testing, white paper formulation, and stakeholder mapping.' },
      { step: 'Phase 3', title: 'Public Advocacy & Governance Evaluation', desc: 'Impact evaluation methodologies, media advocacy, and global policy briefs.' }
    ]
  }
];

// Fallback canonical skills for domains not yet populated in backend database
const getDomainFallbackSkills = (domainId: string): SkillItem[] => {
  if (domainId === 'All') {
    const allSkills: SkillItem[] = [];
    Object.entries(DOMAIN_CO_DOMAINS).forEach(([dom, coList]) => {
      coList.slice(0, 3).forEach((item, idx) => {
        allSkills.push({
          id: `${dom.toLowerCase()}-all-${idx}`,
          canonical_name: item.name,
          slug: item.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
          domain: dom,
          description: item.short_description,
          is_emerging: !!item.is_emerging,
          category_id: item.category
        });
      });
    });
    return allSkills;
  }

  const coDomains = DOMAIN_CO_DOMAINS[domainId] || DOMAIN_CO_DOMAINS[Object.keys(DOMAIN_CO_DOMAINS).find(k => k.toLowerCase().includes(domainId.toLowerCase()) || domainId.toLowerCase().includes(k.toLowerCase())) || ''] || [];

  if (coDomains.length > 0) {
    return coDomains.map((item, idx) => ({
      id: `${domainId.toLowerCase()}-codomain-${idx}`,
      canonical_name: item.name,
      slug: item.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      domain: domainId,
      description: item.short_description,
      is_emerging: !!item.is_emerging,
      category_id: item.category
    }));
  }

  return [
    'Foundational Principles', 'Applied Industry Tooling', 'System Architecture',
    'Diagnostic Protocols', 'Quality Assurance & Compliance', 'Flagship Capstone Execution'
  ].map((name, i) => ({
    id: `${domainId.toLowerCase()}-sk-${i}`,
    canonical_name: name,
    slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    domain: domainId,
    description: `Canonical industry competency benchmark for ${domainId} curriculum.`,
    is_emerging: i % 4 === 0,
    category_id: 'auto-taxonomy'
  }));
};

const getDomainFallbackRoles = (domainId: string): CareerRole[] => {
  const domainObj = GALAXY_DOMAINS.find(d => d.id === domainId) || GALAXY_DOMAINS[0];
  return domainObj.topRoles.map((roleTitle, i) => ({
    id: `${domainId.toLowerCase()}-role-${i}`,
    title: roleTitle,
    slug: roleTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    domain: domainId,
    description: `Industry benchmark career position for graduates in ${domainId}.`,
    skills: [
      { 
        skill_id: `${domainId}-1`, 
        skill_name: domainObj.topRoles[0] ? 'Core Domain Proficiency' : 'General Skill', 
        is_required: true,
        weight: 1.0,
        importance: 'critical'
      }
    ]
  }));
};

interface Node {
  id: string;
  name: string;
  category: string;
  domain: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  isAcquired: boolean;
  proficiency: string;
  importance: string;
  pulsePhase: number;
  isRole?: boolean;
  matchedRoles?: string[];
  description?: string;
  difficulty?: string;
  learningSteps?: string[];
}

interface Edge {
  source: string;
  target: string;
  sourceNode?: Node;
  targetNode?: Node;
  color: string;
  dashOffset: number;
}

interface SkillGalaxy3DProps {
  onNavigateToRoadmap?: (roleTitle?: string, domain?: string, isSkillCoDomain?: boolean) => void;
}

const SkillGalaxy3DComponent: React.FC<SkillGalaxy3DProps> = ({ onNavigateToRoadmap }) => {
  const { user } = useAuth();
  const { mode } = useHologramTheme();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Interaction State
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>('All');
  const [categoryGroup, setCategoryGroup] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [nodeFilter, setNodeFilter] = useState<'all' | 'acquired' | 'gaps' | 'roles'>('all');
  const [viewMode, setViewMode] = useState<'constellation' | 'explorer' | 'radar'>('constellation');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [zoomScale, setZoomScale] = useState<number>(1);
  const [showDomainModal, setShowDomainModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Performance refs to prevent unnecessary canvas recreation
  const selectedNodeRef = useRef<Node | null>(null);
  useEffect(() => { selectedNodeRef.current = selectedNode; }, [selectedNode]);

  const searchQueryRef = useRef<string>(searchQuery);
  useEffect(() => { searchQueryRef.current = searchQuery; }, [searchQuery]);

  const nodeFilterRef = useRef<'all' | 'acquired' | 'gaps' | 'roles'>(nodeFilter);
  useEffect(() => { nodeFilterRef.current = nodeFilter; }, [nodeFilter]);

  const isPausedRef = useRef<boolean>(isPaused);
  useEffect(() => { isPausedRef.current = isPaused; }, [isPaused]);

  const zoomScaleRef = useRef<number>(zoomScale);
  useEffect(() => { zoomScaleRef.current = zoomScale; }, [zoomScale]);

  const modeRef = useRef<string>(mode);
  useEffect(() => { modeRef.current = mode; }, [mode]);

  // Dedicated Co-Domain Beginner-to-Placement Roadmap Modal State
  const [selectedCoDomainRoadmap, setSelectedCoDomainRoadmap] = useState<LearningRoadmap | null>(null);
  const [activeRoadmapPhase, setActiveRoadmapPhase] = useState<number>(0);
  const [copiedKeyword, setCopiedKeyword] = useState<string | null>(null);
  const [taskCompletionMap, setTaskCompletionMap] = useState<Record<string, boolean>>({});

  // Data state
  const [skills, setSkills] = useState<SkillItem[]>([]);
  const [studentSkills, setStudentSkills] = useState<StudentSkillItem[]>([]);
  const [roles, setRoles] = useState<CareerRole[]>([]);

  // Show Toast
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleCopyText = (text: string, label?: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKeyword(text);
    triggerToast(`Copied ${label || 'text'} to clipboard!`);
    setTimeout(() => setCopiedKeyword(null), 2500);
  };

  const toggleTaskCompletion = (taskId: string) => {
    setTaskCompletionMap(prev => ({
      ...prev,
      [taskId]: !prev[taskId]
    }));
  };

  // Open Co-Domain Roadmap
  const handleOpenCoDomainRoadmap = (coDomainName: string, domainName?: string) => {
    const targetDomain = domainName || activeFilter !== 'All' ? activeFilter : currentDomainMeta.name;
    const roadmap = generateCoDomainRoadmap(coDomainName, targetDomain);
    setSelectedCoDomainRoadmap(roadmap);
    setActiveRoadmapPhase(0);
  };

  // Fetch real data from backend with fallback support for all domains
  const loadGraphData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [skillsData, rolesData] = await Promise.all([
        taxonomyApi.getSkills(activeFilter === 'All' ? undefined : activeFilter).catch(() => []),
        matchingApi.getRoles(activeFilter === 'All' ? undefined : activeFilter).catch(() => []),
      ]);

      const fallbackSkills = getDomainFallbackSkills(activeFilter);
      const skillNameSet = new Set<string>();
      const combinedSkills: SkillItem[] = [];

      (skillsData || []).forEach(s => {
        const key = s.canonical_name.toLowerCase().trim();
        if (!skillNameSet.has(key)) {
          skillNameSet.add(key);
          combinedSkills.push(s);
        }
      });

      fallbackSkills.forEach(s => {
        const key = s.canonical_name.toLowerCase().trim();
        if (!skillNameSet.has(key)) {
          skillNameSet.add(key);
          combinedSkills.push(s);
        }
      });

      const effectiveSkills = combinedSkills.length > 0 ? combinedSkills : fallbackSkills;
      const effectiveRoles = (rolesData && rolesData.length > 0)
        ? rolesData
        : getDomainFallbackRoles(activeFilter);

      setSkills(effectiveSkills);
      setRoles(effectiveRoles);

      if (user && user.role === 'student') {
        try {
          const profile = await profileApi.getStudentMe();
          setStudentSkills(profile.skills || []);
        } catch {
          setStudentSkills([]);
        }
      } else {
        setStudentSkills([]);
      }
    } catch (err) {
      console.warn('Failed to load galaxy graph data, applying fallback:', err);
      setSkills(getDomainFallbackSkills(activeFilter));
      setRoles(getDomainFallbackRoles(activeFilter));
    } finally {
      setIsLoading(false);
    }
  }, [activeFilter, user]);

  useEffect(() => {
    loadGraphData();
  }, [loadGraphData]);

  // Current domain metadata
  const currentDomainMeta = useMemo(() => {
    return GALAXY_DOMAINS.find(d => d.id === activeFilter) || GALAXY_DOMAINS[0];
  }, [activeFilter]);

  // Filtered domain list based on category group tab
  const visibleDomains = useMemo(() => {
    if (categoryGroup === 'All') return GALAXY_DOMAINS;
    return GALAXY_DOMAINS.filter(d => d.group === categoryGroup || d.id === 'All');
  }, [categoryGroup]);

  // User Acquired Skills Map
  const userSkillMap = useMemo(() => {
    const map = new Map<string, StudentSkillItem>();
    studentSkills.forEach(s => {
      map.set(s.skill_id, s);
      map.set(s.skill_name.toLowerCase(), s);
    });
    return map;
  }, [studentSkills]);

  // Readiness Metrics
  const domainReadiness = useMemo(() => {
    if (skills.length === 0) return { acquiredCount: 0, totalCount: 0, percentage: 0 };
    let acquired = 0;
    skills.forEach(s => {
      if (userSkillMap.has(s.id) || userSkillMap.has(s.canonical_name.toLowerCase())) {
        acquired++;
      }
    });
    const percentage = Math.round((acquired / skills.length) * 100);
    return { acquiredCount: acquired, totalCount: skills.length, percentage };
  }, [skills, userSkillMap]);

  // -------------------------------------------------------------
  // Interactive 3D Canvas Rendering (Runs on Mount & ViewMode Switch)
  // -------------------------------------------------------------
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 900);
    let height = (canvas.height = 540);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth || 900;
      height = canvas.height = 540;
    };
    window.addEventListener('resize', handleResize);

    // Construct Nodes Dynamically
    const rawNodes: Node[] = [];
    const edges: Edge[] = [];

    // 1. Central Core Node
    const coreName = user?.full_name ? `${user.full_name}` : 'Student Core';
    const coreDomain = user?.role === 'student' ? (activeFilter !== 'All' ? activeFilter : 'Universal') : 'Universal';
    rawNodes.push({
      id: 'core',
      name: coreName,
      category: 'Candidate Competency Core',
      domain: coreDomain,
      x: width / 2,
      y: height / 2,
      vx: 0,
      vy: 0,
      radius: 28,
      color: currentDomainMeta.color || '#38bdf8',
      isAcquired: true,
      proficiency: `${domainReadiness.percentage}% Ready`,
      importance: 'Core Anchor',
      pulsePhase: 0,
      description: `Central candidate anchor in ${currentDomainMeta.name}.`,
      difficulty: 'Expert',
      learningSteps: ['Academic Curriculum', 'Skill Gap Closure', 'Industry Internship', 'Placement Ready']
    });

    // 2. Skill Nodes from Taxonomy
    const displaySkills = skills.slice(0, 32);
    displaySkills.forEach((sk, idx) => {
      const angle = (idx / (displaySkills.length || 1)) * Math.PI * 2;
      const orbitalRing = (idx % 3 === 0 ? 135 : (idx % 3 === 1 ? 195 : 255));
      const distance = (orbitalRing + ((idx % 4) * 12)) * zoomScale;
      const x = width / 2 + Math.cos(angle) * distance;
      const y = height / 2 + Math.sin(angle) * (distance * 0.85);

      const isAcquired = userSkillMap.has(sk.id) || userSkillMap.has(sk.canonical_name.toLowerCase());
      const studentSkill = userSkillMap.get(sk.id) || userSkillMap.get(sk.canonical_name.toLowerCase());

      const color = isAcquired 
        ? '#00f2fe' 
        : sk.is_emerging 
          ? '#f59e0b' 
          : currentDomainMeta.color !== '#38bdf8' 
            ? currentDomainMeta.color 
            : '#f43f5e';

      rawNodes.push({
        id: `skill-${sk.id}`,
        name: sk.canonical_name,
        category: sk.domain || 'Technical',
        domain: sk.domain,
        x: Math.max(65, Math.min(width - 65, x)),
        y: Math.max(65, Math.min(height - 65, y)),
        vx: (Math.random() - 0.5) * 0.22,
        vy: (Math.random() - 0.5) * 0.22,
        radius: isAcquired ? 14 : 11,
        color,
        isAcquired,
        proficiency: isAcquired ? (studentSkill?.proficiency || 'Verified') : 'Skill Gap',
        importance: isAcquired ? 'Verified Profile Skill' : (sk.is_emerging ? '🔥 Emerging 2026' : 'Industry Co-Domain'),
        pulsePhase: idx * 0.45,
        description: sk.description || `Canonical competency aligned with the ${sk.domain} degree taxonomy.`,
        difficulty: idx % 3 === 0 ? 'Advanced' : (idx % 2 === 0 ? 'Intermediate' : 'Foundational'),
        learningSteps: [
          `Phase 1: Foundational theory & syntax of ${sk.canonical_name}`,
          `Phase 2: Practical implementation on real-world datasets/scenarios`,
          `Phase 3: Flagship project & industry placement preparation`
        ]
      });

      // Edge from core to skill
      edges.push({
        source: 'core',
        target: `skill-${sk.id}`,
        sourceNode: rawNodes[0],
        targetNode: rawNodes[rawNodes.length - 1],
        color: isAcquired ? 'rgba(56, 189, 248, 0.35)' : 'rgba(244, 63, 94, 0.18)',
        dashOffset: 0
      });
    });

    // 3. Target Career Role Nodes
    const targetRoles = roles.slice(0, 4);
    targetRoles.forEach((role, rIdx) => {
      const roleAngle = (rIdx / (targetRoles.length || 1)) * Math.PI * 2 + (Math.PI / 4);
      const roleRadius = Math.min(width, height) * 0.44 * zoomScaleRef.current;
      const roleX = width / 2 + Math.cos(roleAngle) * roleRadius;
      const roleY = height / 2 + Math.sin(roleAngle) * (roleRadius * 0.85);

      const roleNodeId = `role-${role.id}`;
      const roleNode: Node = {
        id: roleNodeId,
        name: role.title,
        category: 'Target Career Benchmark',
        domain: role.domain,
        x: Math.max(85, Math.min(width - 85, roleX)),
        y: Math.max(85, Math.min(height - 85, roleY)),
        vx: (Math.random() - 0.5) * 0.08,
        vy: (Math.random() - 0.5) * 0.08,
        radius: 20,
        color: '#c084fc',
        isAcquired: true,
        proficiency: `${role.domain} Benchmark`,
        importance: 'Target Career Role',
        pulsePhase: 4.5 + rIdx,
        isRole: true,
        description: role.description || `Verified industry benchmark role for ${role.domain} graduates.`,
        difficulty: 'Career Target',
        learningSteps: (role.skills || []).map(s => `Master ${s.skill_name} (Critical Requirement)`)
      };
      rawNodes.push(roleNode);

      // Connect required skills to role
      (role.skills || []).forEach(rs => {
        const matchingSkillNode = rawNodes.find(n => n.name.toLowerCase() === rs.skill_name.toLowerCase());
        if (matchingSkillNode) {
          matchingSkillNode.matchedRoles = matchingSkillNode.matchedRoles || [];
          matchingSkillNode.matchedRoles.push(role.title);

          edges.push({
            source: matchingSkillNode.id,
            target: roleNodeId,
            sourceNode: matchingSkillNode,
            targetNode: roleNode,
            color: 'rgba(192, 132, 252, 0.45)',
            dashOffset: 0
          });
        }
      });
    });

    // Background Stars (Static positions, fast alpha flicker)
    const stars = Array.from({ length: 65 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 1.4 + 0.4,
      alpha: Math.random() * 0.6 + 0.2,
    }));

    let time = 0;

    const render = () => {
      // Skip rendering if document is hidden to save 100% CPU/GPU
      if (typeof document !== 'undefined' && document.hidden) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      const isPausedVal = isPausedRef.current;
      const currentSelected = selectedNodeRef.current;
      const search = searchQueryRef.current.toLowerCase().trim();
      const filter = nodeFilterRef.current;
      const isLight = modeRef.current === 'light';
      const zoom = zoomScaleRef.current;

      if (!isPausedVal) {
        time += 0.022;
      }
      ctx.clearRect(0, 0, width, height);

      // 1. Draw Starfield (Fast Batch Fill)
      ctx.fillStyle = isLight ? 'rgba(2, 132, 199, 0.22)' : 'rgba(255, 255, 255, 0.55)';
      ctx.beginPath();
      stars.forEach((star) => {
        ctx.moveTo(star.x + star.size, star.y);
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
      });
      ctx.fill();

      // 2. Draw Orbit Track Rings (Multi-Layer Constellation)
      const orbitRadii = [135 * zoom, 195 * zoom, 255 * zoom, Math.min(width, height) * 0.44 * zoom];
      ctx.lineWidth = 1;
      orbitRadii.forEach((r, oIdx) => {
        ctx.strokeStyle = isLight ? `rgba(2, 132, 199, ${0.05 + oIdx * 0.015})` : `rgba(56, 189, 248, ${0.06 + oIdx * 0.02})`;
        ctx.setLineDash([4, 8]);
        ctx.beginPath();
        ctx.ellipse(width / 2, height / 2, r, r * 0.85, 0, 0, Math.PI * 2);
        ctx.stroke();
      });
      ctx.setLineDash([]);

      // 3. Draw Edges with Direct Node References (O(1) lookups)
      edges.forEach((edge) => {
        const sNode = edge.sourceNode;
        const tNode = edge.targetNode;
        if (!sNode || !tNode) return;

        // Apply node filtering
        if (filter === 'acquired' && (!sNode.isAcquired || !tNode.isAcquired)) return;
        if (filter === 'gaps' && (sNode.isAcquired && tNode.isAcquired && sNode.id !== 'core')) return;
        if (filter === 'roles' && (!sNode.isRole && !tNode.isRole)) return;

        const isHighlighted = currentSelected && (currentSelected.id === sNode.id || currentSelected.id === tNode.id);

        ctx.strokeStyle = isHighlighted ? '#38bdf8' : edge.color;
        ctx.lineWidth = isHighlighted ? 2.5 : (edge.source === 'core' || edge.target.startsWith('role-') ? 1.4 : 0.8);
        ctx.setLineDash([5, 5]);
        ctx.lineDashOffset = -time * 10;

        ctx.beginPath();
        ctx.moveTo(sNode.x, sNode.y);
        ctx.lineTo(tNode.x, tNode.y);
        ctx.stroke();
        ctx.setLineDash([]);
      });

      // 4. Draw Nodes with Zero Garbage-Collection Glow Fills
      rawNodes.forEach((node) => {
        // Node Filter Visibility
        if (filter === 'acquired' && !node.isAcquired && node.id !== 'core') return;
        if (filter === 'gaps' && (node.isAcquired || node.isRole) && node.id !== 'core') return;
        if (filter === 'roles' && !node.isRole && node.id !== 'core') return;

        if (node.id !== 'core' && !isPausedVal) {
          node.x += node.vx * 0.35;
          node.y += node.vy * 0.35;

          const padding = 55;
          if (node.x < padding || node.x > width - padding) node.vx *= -1;
          if (node.y < padding || node.y > height - padding) node.vy *= -1;
        }

        const isHovered = currentSelected?.id === node.id;
        const isSearchMatched = search !== '' && node.name.toLowerCase().includes(search);
        const pulse = Math.sin(time * 2 + node.pulsePhase) * 1.8;
        const currentRadius = node.radius + (isHovered || isSearchMatched ? 5 : 0);

        // Fast GPU Glow Halo (0 heap allocations)
        ctx.fillStyle = `${node.color}22`;
        ctx.beginPath();
        ctx.arc(node.x, node.y, currentRadius * 1.9 + pulse, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = `${node.color}55`;
        ctx.beginPath();
        ctx.arc(node.x, node.y, currentRadius * 1.35, 0, Math.PI * 2);
        ctx.fill();

        // Node Inner Core
        ctx.fillStyle = node.color;
        ctx.beginPath();
        ctx.arc(node.x, node.y, currentRadius, 0, Math.PI * 2);
        ctx.fill();

        // Highlight Sparkle
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(node.x - currentRadius * 0.3, node.y - currentRadius * 0.3, currentRadius * 0.25, 0, Math.PI * 2);
        ctx.fill();

        // Label
        ctx.font = node.id === 'core' || node.isRole ? 'bold 11px "Plus Jakarta Sans"' : '600 10px "Plus Jakarta Sans"';
        ctx.fillStyle = isLight ? '#0f172a' : '#f8fafc';
        ctx.textAlign = 'center';
        ctx.fillText(node.name, node.x, node.y + currentRadius + 13);

        // Subtext / Status
        ctx.font = '500 9px "Plus Jakarta Sans"';
        ctx.fillStyle = node.isRole ? '#c084fc' : (node.isAcquired ? '#10b981' : '#f43f5e');
        ctx.fillText(node.proficiency, node.x, node.y + currentRadius + 24);
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    // Click Detection
    const handleClick = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      let clicked: Node | null = null;
      rawNodes.forEach((node) => {
        const dist = Math.hypot(node.x - mouseX, node.y - mouseY);
        if (dist <= node.radius + 12) {
          clicked = node;
        }
      });
      setSelectedNode(clicked);
    };

    canvas.addEventListener('click', handleClick);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      canvas.removeEventListener('click', handleClick);
    };
  }, [skills, studentSkills, roles, activeFilter, currentDomainMeta, user?.full_name]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      {/* Toast Notification */}
      {toastMessage && (
        <div style={{
          position: 'fixed',
          top: '1.5rem',
          right: '1.5rem',
          zIndex: 99999,
          background: 'var(--bg-modal)',
          color: 'var(--text-primary)',
          border: '1.5px solid var(--accent-cyan)',
          padding: '0.75rem 1.25rem',
          borderRadius: '10px',
          boxShadow: 'var(--shadow-modal)',
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          fontSize: '0.85rem',
          fontWeight: 700
        }}>
          <Check size={16} color="var(--accent-emerald)" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header & Interactive Bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Compass size={24} style={{ color: currentDomainMeta.color }} />
              3D Skill Galaxy
            </h2>
            <span className="badge badge-cyan">
              <Sparkles size={12} /> Universal Multi-Discipline Universe
            </span>
            <span className="badge badge-purple" style={{ fontSize: '0.7rem' }}>
              {domainReadiness.percentage}% Domain Match
            </span>
          </div>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
            Cross-disciplinary interactive 3D universe connecting verified database taxonomies, real-time market salary benchmarks, and tailored learning paths.
          </p>
        </div>

        {/* View Switcher & Actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
          {/* View Mode Toggle */}
          <div style={{ display: 'flex', background: 'rgba(255, 255, 255, 0.05)', borderRadius: '8px', padding: '2px', border: '1px solid var(--border-subtle)' }}>
            <button
              onClick={() => setViewMode('constellation')}
              className={`btn btn-sm ${viewMode === 'constellation' ? 'btn-primary' : 'btn-ghost'}`}
              style={{ fontSize: '0.72rem', padding: '0.25rem 0.55rem' }}
              title="Interactive 3D Constellation"
            >
              <Globe size={12} /> 3D Galaxy
            </button>
            <button
              onClick={() => setViewMode('radar')}
              className={`btn btn-sm ${viewMode === 'radar' ? 'btn-primary' : 'btn-ghost'}`}
              style={{ fontSize: '0.72rem', padding: '0.25rem 0.55rem' }}
              title="Skill Gap & Readiness Radar"
            >
              <Target size={12} /> Gap Radar
            </button>
            <button
              onClick={() => setViewMode('explorer')}
              className={`btn btn-sm ${viewMode === 'explorer' ? 'btn-primary' : 'btn-ghost'}`}
              style={{ fontSize: '0.72rem', padding: '0.25rem 0.55rem' }}
              title="Comprehensive Field Explorer"
            >
              <Layers size={12} /> Field Explorer
            </button>
          </div>

          <button
            onClick={() => setShowDomainModal(true)}
            className="btn btn-secondary btn-sm"
            style={{ fontSize: '0.72rem', padding: '0.35rem 0.65rem', display: 'flex', alignItems: 'center', gap: '0.3rem', borderColor: currentDomainMeta.color }}
          >
            <TrendingUp size={13} style={{ color: currentDomainMeta.color }} />
            <span>Field Intelligence</span>
          </button>

          <button
            onClick={loadGraphData}
            className="btn btn-secondary btn-sm"
            style={{ padding: '0.35rem 0.55rem', display: 'flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.72rem' }}
            title="Synchronize Galaxy Graph"
          >
            <RefreshCw size={12} className={isLoading ? 'animate-spin-slow' : ''} />
            <span>Sync</span>
          </button>
        </div>
      </div>

      {/* Discipline Category Streams & Domain Selection */}
      <div className="glass-card" style={{ padding: '0.85rem 1rem', display: 'flex', flexDirection: 'column', gap: '0.75rem', border: '1px solid var(--border-subtle)' }}>
        {/* Stream Filter Tabs */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.3rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              <Filter size={12} /> Streams:
            </span>
            {[
              { id: 'All', label: 'All Disciplines' },
              { id: 'Engineering', label: '⚙️ Engineering & Tech' },
              { id: 'Aviation & Hospitality', label: '✈️ Aviation, Pilot & Crew' },
              { id: 'Law & Commerce', label: '⚖️ Law & Commerce' },
              { id: 'Healthcare & Medicine', label: '🩺 Health & Clinical' },
              { id: 'Humanities', label: '🏛️ Humanities & Policy' }
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => setCategoryGroup(cat.id)}
                className={categoryGroup === cat.id ? 'btn btn-primary btn-sm' : 'btn btn-secondary btn-sm'}
                style={{ fontSize: '0.725rem', padding: '0.25rem 0.6rem', borderRadius: '6px' }}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div style={{ position: 'relative', minWidth: '180px' }}>
            <Search size={13} style={{ position: 'absolute', left: '0.6rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input
              type="text"
              placeholder="Search skill or role..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                width: '100%',
                padding: '0.35rem 0.5rem 0.35rem 1.8rem',
                fontSize: '0.75rem',
                borderRadius: '6px',
                background: 'var(--bg-glass)',
                border: '1px solid var(--border-subtle)',
                color: 'var(--text-primary)',
                outline: 'none'
              }}
            />
          </div>
        </div>

        {/* Domain Selection Pill Grid */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap', paddingTop: '0.1rem' }}>
          {visibleDomains.map((dom) => {
            const IconComponent = dom.icon;
            const isActive = activeFilter === dom.id;
            return (
              <button
                key={dom.id}
                onClick={() => {
                  setActiveFilter(dom.id);
                  if (viewMode !== 'constellation') {
                    // Stay on current explorer or switch smoothly
                  }
                }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.4rem',
                  fontSize: '0.75rem',
                  padding: '0.32rem 0.7rem',
                  borderRadius: '20px',
                  border: isActive ? `1.5px solid ${dom.color}` : '1px solid var(--border-subtle)',
                  background: isActive ? `${dom.color}22` : 'rgba(255, 255, 255, 0.03)',
                  color: isActive ? (dom.color) : 'var(--text-secondary)',
                  fontWeight: isActive ? 700 : 500,
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                  boxShadow: isActive ? `0 0 12px ${dom.color}44` : 'none'
                }}
              >
                <IconComponent size={13} style={{ color: dom.color }} />
                <span>{dom.badge}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Domain Intelligence Strip */}
      <div 
        className="glass-card" 
        style={{ 
          padding: '0.85rem 1.1rem', 
          borderLeft: `4px solid ${currentDomainMeta.color}`,
          background: `linear-gradient(90deg, ${currentDomainMeta.color}11 0%, rgba(255,255,255,0.01) 100%)`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '0.85rem'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem', maxWidth: '650px' }}>
          <div style={{ 
            width: '40px', 
            height: '40px', 
            borderRadius: '10px', 
            background: `${currentDomainMeta.color}22`, 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            border: `1.5px solid ${currentDomainMeta.color}44`,
            flexShrink: 0
          }}>
            {React.createElement(currentDomainMeta.icon, { size: 20, color: currentDomainMeta.color })}
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
              <span style={{ fontWeight: 800, fontSize: '0.95rem', color: 'var(--text-primary)' }}>
                {currentDomainMeta.name}
              </span>
              <span className="badge" style={{ fontSize: '0.65rem', background: `${currentDomainMeta.color}22`, color: currentDomainMeta.color, border: `1px solid ${currentDomainMeta.color}44` }}>
                {currentDomainMeta.marketDemand}
              </span>
            </div>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '0.2rem', lineHeight: 1.4 }}>
              {currentDomainMeta.description}
            </p>
          </div>
        </div>

        {/* Key Metrics Quick Badges */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ textAlign: 'center', padding: '0.35rem 0.65rem', background: 'rgba(255,255,255,0.03)', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
            <div style={{ fontSize: '0.85rem', fontWeight: 800, color: '#10b981', display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
              <DollarSign size={13} /> {currentDomainMeta.avgSalary.split('–')[0]}
            </div>
            <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)' }}>Avg Benchmark</div>
          </div>

          <div style={{ textAlign: 'center', padding: '0.35rem 0.65rem', background: 'rgba(255,255,255,0.03)', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
            <div style={{ fontSize: '0.85rem', fontWeight: 800, color: currentDomainMeta.color }}>
              {domainReadiness.acquiredCount} / {domainReadiness.totalCount}
            </div>
            <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)' }}>Skills Verified</div>
          </div>

          <button
            onClick={() => setShowDomainModal(true)}
            className="btn btn-primary btn-sm"
            style={{ fontSize: '0.74rem', padding: '0.4rem 0.75rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}
          >
            <span>Explore Roadmap</span>
            <ArrowRight size={12} />
          </button>
        </div>
      </div>

      {/* =========================================================
          VIEW MODE 1: 3D CONSTELLATION CANVAS (ALWAYS PRESERVED)
          ========================================================= */}
      <div 
        className="glass-card" 
        style={{ 
          display: viewMode === 'constellation' ? 'block' : 'none',
          position: 'relative', 
          overflow: 'hidden', 
          border: '1px solid var(--border-subtle)' 
        }}
      >
        {/* Top Canvas Controls Bar */}
        <div style={{
          position: 'absolute',
          top: '0.85rem',
          left: '0.85rem',
          right: '0.85rem',
          zIndex: 10,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '0.5rem',
          pointerEvents: 'none'
        }}>
          {/* Legend Chips */}
          <div 
            className="floating-pill-bar"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.6rem',
              padding: '0.35rem 0.75rem',
              borderRadius: '8px',
              fontSize: '0.7rem',
              pointerEvents: 'auto'
            }}
          >
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', color: '#00f2fe', fontWeight: 600 }}>
              <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#00f2fe' }} /> Verified Skill
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', color: currentDomainMeta.color, fontWeight: 600 }}>
              <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: currentDomainMeta.color }} /> Taxonomy Skill
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', color: '#c084fc', fontWeight: 600 }}>
              <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#c084fc' }} /> Target Role
            </span>
          </div>

          {/* Quick Canvas Controls */}
          <div style={{ display: 'flex', gap: '0.35rem', pointerEvents: 'auto' }}>
            {/* Node Filter Selector */}
            <select
              value={nodeFilter}
              onChange={(e) => setNodeFilter(e.target.value as any)}
              style={{
                background: 'var(--bg-secondary)',
                color: 'var(--text-primary)',
                border: '1px solid var(--border-subtle)',
                borderRadius: '6px',
                fontSize: '0.72rem',
                padding: '0.25rem 0.5rem',
                outline: 'none',
                cursor: 'pointer'
              }}
            >
              <option value="all">Display All Nodes</option>
              <option value="acquired">Verified Skills Only</option>
              <option value="gaps">Skill Gaps (Missing)</option>
              <option value="roles">Target Benchmark Roles</option>
            </select>

            {/* Pause/Play Physics */}
            <button
              type="button"
              onClick={() => setIsPaused(prev => !prev)}
              className="btn btn-secondary btn-sm"
              style={{ padding: '0.3rem', fontSize: '0.7rem' }}
              title={isPaused ? "Resume Orbit Movement" : "Pause Orbit Movement"}
            >
              {isPaused ? <Play size={12} color="#10b981" /> : <Pause size={12} />}
            </button>

            {/* Zoom Controls */}
            <button
              type="button"
              onClick={() => setZoomScale(prev => Math.min(1.4, Number((prev + 0.1).toFixed(2))))}
              className="btn btn-secondary btn-sm"
              style={{ padding: '0.3rem', fontSize: '0.7rem' }}
              title="Zoom In Galaxy"
            >
              <ZoomIn size={12} />
            </button>
            <button
              type="button"
              onClick={() => setZoomScale(prev => Math.max(0.7, Number((prev - 0.1).toFixed(2))))}
              className="btn btn-secondary btn-sm"
              style={{ padding: '0.3rem', fontSize: '0.7rem' }}
              title="Zoom Out Galaxy"
            >
              <ZoomOut size={12} />
            </button>
            <button
              type="button"
              onClick={() => setZoomScale(1)}
              className="btn btn-secondary btn-sm"
              style={{ padding: '0.3rem 0.5rem', fontSize: '0.7rem' }}
              title="Reset Zoom"
            >
              100%
            </button>
          </div>
        </div>

        {/* Canvas Rendering */}
        <canvas
          ref={canvasRef}
          style={{ 
            width: '100%', 
            height: '540px', 
            display: 'block', 
            background: mode === 'light' 
              ? 'radial-gradient(ellipse at center, #ffffff 0%, #f1f5f9 100%)' 
              : 'radial-gradient(ellipse at center, #0e172e 0%, #060913 100%)', 
            cursor: 'grab' 
          }}
        />

        {/* Selected Node Details Drawer */}
        {selectedNode && (
          <div
            className="glass-card"
            style={{
              position: 'absolute',
              bottom: '1rem',
              right: '1rem',
              width: '350px',
              padding: '1.25rem',
              zIndex: 20,
              boxShadow: 'var(--shadow-lg)',
              border: `1.5px solid ${selectedNode.color}88`,
              background: 'var(--bg-modal)',
              backdropFilter: 'blur(16px)',
              borderRadius: '12px'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.6rem' }}>
              <span className={`badge ${selectedNode.isRole ? 'badge-purple' : (selectedNode.isAcquired ? 'badge-emerald' : 'badge-rose')}`}>
                {selectedNode.isRole ? <Target size={12} /> : (selectedNode.isAcquired ? <CheckCircle2 size={12} /> : <AlertCircle size={12} />)}
                {selectedNode.proficiency}
              </span>
              <button
                onClick={() => setSelectedNode(null)}
                style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '1.1rem' }}
              >
                ✕
              </button>
            </div>

            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.3rem' }}>
              {selectedNode.name}
            </h3>

            <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '0.8rem', lineHeight: '1.45' }}>
              {selectedNode.description}
            </p>

            <div style={{ padding: '0.6rem 0.8rem', background: 'var(--bg-tertiary)', border: '1px solid var(--border-subtle)', borderRadius: '8px', marginBottom: '0.8rem', fontSize: '0.75rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
                <span style={{ color: 'var(--text-muted)' }}>Status:</span>
                <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{selectedNode.importance}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
                <span style={{ color: 'var(--text-muted)' }}>Domain Stream:</span>
                <span style={{ fontWeight: 600, color: selectedNode.color }}>{selectedNode.domain}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-muted)' }}>Difficulty Level:</span>
                <span style={{ fontWeight: 600, color: 'var(--text-secondary)' }}>{selectedNode.difficulty || 'Intermediate'}</span>
              </div>
            </div>

            {selectedNode.learningSteps && selectedNode.learningSteps.length > 0 && (
              <div style={{ marginBottom: '0.85rem' }}>
                <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginBottom: '0.35rem', textTransform: 'uppercase', letterSpacing: '0.5px', fontWeight: 700 }}>
                  Learning & Verification Steps:
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.3rem', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                  {selectedNode.learningSteps.map((step, sIdx) => (
                    <div key={sIdx} style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                      <span style={{ width: '5px', height: '5px', borderRadius: '50%', background: selectedNode.color }} />
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.45rem' }}>
              <button
                type="button"
                onClick={() => handleOpenCoDomainRoadmap(selectedNode.name, selectedNode.domain)}
                className="btn btn-primary btn-sm"
                style={{ width: '100%', fontSize: '0.78rem', padding: '0.45rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.35rem', fontWeight: 700 }}
              >
                <Sparkles size={13} /> View Exact Placement Roadmap →
              </button>

              <div style={{ display: 'flex', gap: '0.4rem' }}>
                <button
                  type="button"
                  onClick={() => {
                    if (onNavigateToRoadmap) {
                      onNavigateToRoadmap(selectedNode.name, selectedNode.domain, true);
                    } else {
                      triggerToast(`Added "${selectedNode.name}" to your Target Learning Roadmap!`);
                    }
                  }}
                  className="btn btn-secondary btn-sm"
                  style={{ flex: 1, fontSize: '0.72rem', padding: '0.35rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.3rem' }}
                >
                  <Compass size={12} /> Master Roadmap Hub
                </button>
                <button
                  type="button"
                  onClick={() => setShowDomainModal(true)}
                  className="btn btn-secondary btn-sm"
                  style={{ fontSize: '0.72rem', padding: '0.35rem' }}
                  title="View Field Intelligence"
                >
                  <ExternalLink size={12} />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* =========================================================
          VIEW MODE 2: SKILL GAP & READINESS RADAR
          ========================================================= */}
      {viewMode === 'radar' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1.25rem' }}>
          {/* Card 1: Domain Readiness Score */}
          <div className="glass-card" style={{ padding: '1.5rem', border: '1px solid var(--border-subtle)' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.4rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Target size={18} style={{ color: currentDomainMeta.color }} />
              {currentDomainMeta.badge} Profile Readiness
            </h3>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginBottom: '1.25rem' }}>
              Comparison of your verified candidate credentials against the {currentDomainMeta.name} taxonomy.
            </p>

            {/* Score Radial Visual */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '1rem 0' }}>
              <div style={{
                width: '140px',
                height: '140px',
                borderRadius: '50%',
                background: `conic-gradient(${currentDomainMeta.color} ${domainReadiness.percentage * 3.6}deg, rgba(255,255,255,0.05) 0deg)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: '12px'
              }}>
                <div style={{
                  width: '100%',
                  height: '100%',
                  borderRadius: '50%',
                  background: 'var(--bg-card)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  <span style={{ fontSize: '1.8rem', fontWeight: 900, color: currentDomainMeta.color }}>
                    {domainReadiness.percentage}%
                  </span>
                  <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Match Rate</span>
                </div>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginTop: '1rem' }}>
              <div style={{ padding: '0.75rem', background: 'rgba(16, 185, 129, 0.08)', borderRadius: '8px', border: '1px solid rgba(16, 185, 129, 0.25)', textAlign: 'center' }}>
                <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#10b981' }}>{domainReadiness.acquiredCount}</div>
                <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Verified Skills</div>
              </div>
              <div style={{ padding: '0.75rem', background: 'rgba(244, 63, 94, 0.08)', borderRadius: '8px', border: '1px solid rgba(244, 63, 94, 0.25)', textAlign: 'center' }}>
                <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#f43f5e' }}>{domainReadiness.totalCount - domainReadiness.acquiredCount}</div>
                <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Skill Gaps to Close</div>
              </div>
            </div>
          </div>

          {/* Card 2: Missing High-Impact Skills */}
          <div className="glass-card" style={{ padding: '1.5rem', border: '1px solid var(--border-subtle)' }}>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.4rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <AlertCircle size={18} color="#f43f5e" />
              Priority Target Skill Gaps
            </h3>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginBottom: '1rem' }}>
              Acquiring these top taxonomy competencies will immediately boost your benchmark readiness.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
              {skills
                .filter(s => !userSkillMap.has(s.id) && !userSkillMap.has(s.canonical_name.toLowerCase()))
                .slice(0, 5)
                .map((sk, idx) => (
                  <div 
                    key={idx}
                    style={{ 
                      padding: '0.75rem', 
                      borderRadius: '8px', 
                      background: 'var(--bg-tertiary)', 
                      border: '1px solid var(--border-subtle)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between'
                    }}
                  >
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '0.85rem', color: 'var(--text-primary)' }}>
                        {sk.canonical_name}
                      </div>
                      <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                        {sk.domain} • {sk.is_emerging ? '🔥 Emerging 2026 Trend' : 'Standard Core Competency'}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => triggerToast(`Added "${sk.canonical_name}" to your learning roadmap!`)}
                      className="btn btn-secondary btn-sm"
                      style={{ fontSize: '0.7rem', padding: '0.25rem 0.55rem' }}
                    >
                      + Target
                    </button>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================
          VIEW MODE 3: FIELD EXPLORER & ROADMAP GRID
          ========================================================= */}
      {viewMode === 'explorer' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          {/* 3 Step Milestone Pathway */}
          <div className="glass-card" style={{ padding: '1.5rem', border: '1px solid var(--border-subtle)' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.4rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Compass size={20} style={{ color: currentDomainMeta.color }} />
              Standard Learning & Placement Pathway for {currentDomainMeta.name}
            </h3>
            <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', marginBottom: '1.25rem' }}>
              Systematic milestone architecture verified with leading Indian and international industry benchmarks.
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1rem' }}>
              {currentDomainMeta.learningMilestones.map((ms, idx) => (
                <div 
                  key={idx}
                  style={{
                    padding: '1.2rem',
                    borderRadius: '10px',
                    background: 'var(--bg-tertiary)',
                    border: `1.5px solid ${currentDomainMeta.color}44`,
                    position: 'relative',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between'
                  }}
                >
                  <div>
                    <span className="badge" style={{ background: `${currentDomainMeta.color}22`, color: currentDomainMeta.color, fontSize: '0.68rem', fontWeight: 700, marginBottom: '0.5rem' }}>
                      {ms.step}
                    </span>
                    <h4 style={{ fontSize: '0.95rem', fontWeight: 800, color: 'var(--text-primary)', margin: '0.3rem 0 0.4rem 0' }}>
                      {ms.title}
                    </h4>
                    <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', lineHeight: 1.45, margin: 0 }}>
                      {ms.desc}
                    </p>
                  </div>
                  <div style={{ marginTop: '1rem', paddingTop: '0.6rem', borderTop: '1px solid var(--border-subtle)', fontSize: '0.7rem', color: currentDomainMeta.color, fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                    <span>Step {idx + 1} of 3</span>
                    <ChevronRight size={12} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Industry Benchmark Roles Grid */}
          <div className="glass-card" style={{ padding: '1.5rem', border: '1px solid var(--border-subtle)' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.4rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Briefcase size={20} color="var(--accent-purple)" />
              Benchmark Career Roles in {currentDomainMeta.badge}
            </h3>
            <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', marginBottom: '1.25rem' }}>
              Target industry job descriptions mapped to this degree discipline.
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1rem' }}>
              {currentDomainMeta.topRoles.map((roleName, rIdx) => (
                <div
                  key={rIdx}
                  style={{
                    padding: '1.1rem',
                    borderRadius: '10px',
                    background: 'var(--bg-tertiary)',
                    border: '1px solid var(--border-subtle)',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    gap: '0.75rem'
                  }}
                >
                  <div>
                    <h4 style={{ fontSize: '0.95rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                      {roleName}
                    </h4>
                    <span style={{ fontSize: '0.72rem', color: 'var(--accent-purple)', fontWeight: 600 }}>
                      Industry Benchmark Role
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (onNavigateToRoadmap) {
                        onNavigateToRoadmap(roleName, currentDomainMeta.name);
                      } else {
                        triggerToast(`Targeting role: "${roleName}". Matching jobs filtered!`);
                      }
                    }}
                    className="btn btn-primary btn-sm"
                    style={{ 
                      fontSize: '0.75rem', 
                      width: '100%', 
                      padding: '0.45rem', 
                      display: 'inline-flex', 
                      alignItems: 'center', 
                      justifyContent: 'center', 
                      gap: '0.35rem',
                      fontWeight: 700
                    }}
                  >
                    <Compass size={13} />
                    Target this Role → View Roadmap
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================
          MODAL: FIELD INTELLIGENCE & DEEP-DIVE
          ========================================================= */}
      {showDomainModal && (
        <div 
          className="modal-backdrop"
          onClick={() => setShowDomainModal(false)}
        >
          <div 
            className="glass-card modal-content"
            onClick={(e) => e.stopPropagation()}
            style={{
              width: '90%',
              maxWidth: '720px',
              padding: '1.75rem',
              borderRadius: '16px',
              background: 'var(--bg-modal)',
              border: `1.5px solid ${currentDomainMeta.color}66`
            }}
          >
            {/* Modal Header */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <div style={{ width: '42px', height: '42px', borderRadius: '10px', background: `${currentDomainMeta.color}22`, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1.5px solid ${currentDomainMeta.color}44` }}>
                  {React.createElement(currentDomainMeta.icon, { size: 22, color: currentDomainMeta.color })}
                </div>
                <div>
                  <h3 style={{ fontSize: '1.3rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                    {currentDomainMeta.name}
                  </h3>
                  <div style={{ fontSize: '0.78rem', color: currentDomainMeta.color, fontWeight: 600 }}>
                    {currentDomainMeta.careerFocus}
                  </div>
                </div>
              </div>
              <button
                onClick={() => setShowDomainModal(false)}
                className="btn btn-ghost btn-sm"
                style={{ color: 'var(--text-muted)' }}
              >
                <X size={18} />
              </button>
            </div>

            {/* Quick Metrics Grid */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.85rem', marginBottom: '1.5rem' }}>
              <div style={{ padding: '0.9rem', background: 'var(--bg-tertiary)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Hiring Demand Index</div>
                <div style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--accent-emerald)', marginTop: '0.2rem' }}>
                  {currentDomainMeta.marketDemand}
                </div>
              </div>

              <div style={{ padding: '0.9rem', background: 'var(--bg-tertiary)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Salary Benchmark</div>
                <div style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--accent-cyan)', marginTop: '0.2rem' }}>
                  {currentDomainMeta.avgSalary}
                </div>
              </div>

              <div style={{ padding: '0.9rem', background: 'var(--bg-tertiary)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Your Profile Readiness</div>
                <div style={{ fontSize: '1.1rem', fontWeight: 800, color: currentDomainMeta.color, marginTop: '0.2rem' }}>
                  {domainReadiness.percentage}% Ready
                </div>
              </div>
            </div>

            {/* Emerging 2026 Trends */}
            <div style={{ marginBottom: '1.25rem' }}>
              <h4 style={{ fontSize: '0.92rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <Sparkles size={14} color="var(--accent-amber)" />
                Cutting-Edge 2026 Industry Shifts & Emerging Trends:
              </h4>
              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                {currentDomainMeta.emergingTrends.map((trend, tIdx) => (
                  <span key={tIdx} style={{ background: 'rgba(245, 158, 11, 0.12)', border: '1px solid rgba(245, 158, 11, 0.3)', color: 'var(--accent-amber)', padding: '0.3rem 0.75rem', borderRadius: '9999px', fontSize: '0.75rem', fontWeight: 600 }}>
                    ⚡ {trend}
                  </span>
                ))}
              </div>
            </div>

            {/* Recommended Industry Certifications */}
            <div style={{ marginBottom: '1.5rem' }}>
              <h4 style={{ fontSize: '0.92rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <Award size={14} color="var(--accent-purple)" />
                Top Recognized Industry Certifications:
              </h4>
              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                {currentDomainMeta.certifications.map((cert, cIdx) => (
                  <span key={cIdx} style={{ background: 'rgba(168, 85, 247, 0.12)', border: '1px solid rgba(168, 85, 247, 0.3)', color: 'var(--accent-purple)', padding: '0.3rem 0.75rem', borderRadius: '8px', fontSize: '0.75rem', fontWeight: 600 }}>
                    🏅 {cert}
                  </span>
                ))}
              </div>
            </div>

            <button
              onClick={() => {
                setShowDomainModal(false);
                if (onNavigateToRoadmap) {
                  onNavigateToRoadmap(currentDomainMeta.topRoles[0] || currentDomainMeta.name, currentDomainMeta.name);
                } else {
                  setViewMode('explorer');
                }
              }}
              className="btn btn-primary"
              style={{ width: '100%', fontSize: '0.85rem' }}
            >
              Open Interactive Learning Roadmap for {currentDomainMeta.name} →
            </button>
          </div>
        </div>
      )}

      {/* =========================================================
          MODAL: DEDICATED CO-DOMAIN BEGINNER TO PLACEMENT ROADMAP
          ========================================================= */}
      {selectedCoDomainRoadmap && (
        <div 
          className="modal-backdrop"
          onClick={() => setSelectedCoDomainRoadmap(null)}
          style={{ zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
        >
          <div 
            className="glass-card modal-content"
            onClick={(e) => e.stopPropagation()}
            style={{
              width: '92%',
              maxWidth: '920px',
              maxHeight: '90vh',
              overflowY: 'auto',
              padding: '1.75rem',
              borderRadius: '16px',
              background: 'var(--bg-modal)',
              border: `1.5px solid var(--accent-cyan)`,
              boxShadow: 'var(--shadow-modal)',
              position: 'relative'
            }}
          >
            {/* Modal Header */}
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1.25rem', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '1rem', flexWrap: 'wrap', gap: '0.75rem' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '0.35rem' }}>
                  <span className="badge badge-cyan" style={{ fontSize: '0.7rem', fontWeight: 800 }}>
                    <Sparkles size={12} /> 100% Exact Co-Domain Roadmap
                  </span>
                  <span className="badge badge-purple" style={{ fontSize: '0.7rem' }}>
                    {selectedCoDomainRoadmap.domain}
                  </span>
                  <span className="badge badge-emerald" style={{ fontSize: '0.7rem' }}>
                    Beginner → Placement Destination
                  </span>
                </div>
                <h3 style={{ fontSize: '1.45rem', fontWeight: 900, color: 'var(--text-primary)', margin: '0.2rem 0' }}>
                  {selectedCoDomainRoadmap.co_domain_name || selectedCoDomainRoadmap.title}
                </h3>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', margin: 0 }}>
                  Structured 5-tier roadmap engineered from foundational first principles to internship and placement readiness.
                </p>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <button
                  type="button"
                  onClick={() => {
                    const targetName = selectedCoDomainRoadmap.co_domain_name || selectedCoDomainRoadmap.title;
                    const targetDomain = selectedCoDomainRoadmap.domain || currentDomainMeta.name;
                    setSelectedCoDomainRoadmap(null);
                    if (onNavigateToRoadmap) {
                      onNavigateToRoadmap(targetName, targetDomain, true);
                    }
                  }}
                  className="btn btn-outline-cyan btn-sm"
                  style={{ fontSize: '0.75rem', padding: '0.4rem 0.75rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}
                >
                  <Compass size={13} /> Open Full Hub →
                </button>
                <button
                  onClick={() => setSelectedCoDomainRoadmap(null)}
                  className="btn btn-ghost btn-sm"
                  style={{ color: 'var(--text-muted)', padding: '0.35rem' }}
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* 5-Phase Navigation Tabs */}
            <div style={{ display: 'flex', gap: '0.4rem', overflowX: 'auto', paddingBottom: '0.75rem', marginBottom: '1.25rem', borderBottom: '1px solid var(--border-subtle)' }}>
              {selectedCoDomainRoadmap.milestones.map((ms, idx) => {
                const isActive = activeRoadmapPhase === idx;
                const completedTasks = ms.tasks.filter(t => taskCompletionMap[t.id] ?? t.is_completed).length;
                const totalTasks = ms.tasks.length;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveRoadmapPhase(idx)}
                    style={{
                      flex: 1,
                      minWidth: '150px',
                      padding: '0.6rem 0.75rem',
                      borderRadius: '10px',
                      border: isActive ? '1.5px solid var(--accent-cyan)' : '1px solid var(--border-subtle)',
                      background: isActive ? 'rgba(56, 189, 248, 0.12)' : 'rgba(255, 255, 255, 0.02)',
                      textAlign: 'left',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.2rem' }}>
                      <span style={{ fontSize: '0.68rem', fontWeight: 800, color: isActive ? 'var(--accent-cyan)' : 'var(--text-muted)', textTransform: 'uppercase' }}>
                        {ms.week_range}
                      </span>
                      <span style={{ fontSize: '0.65rem', color: completedTasks === totalTasks ? '#10b981' : 'var(--text-muted)' }}>
                        {completedTasks}/{totalTasks}
                      </span>
                    </div>
                    <div style={{ fontSize: '0.78rem', fontWeight: 700, color: isActive ? 'var(--text-primary)' : 'var(--text-secondary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {ms.phase_title?.replace(/Phase \d+: /, '') || ms.focus_skill.split(':')[0]}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Active Phase Content */}
            {selectedCoDomainRoadmap.milestones[activeRoadmapPhase] && (() => {
              const currentMs = selectedCoDomainRoadmap.milestones[activeRoadmapPhase];
              return (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                  {/* Goal & Focus Banner */}
                  <div style={{ padding: '1rem 1.25rem', background: 'rgba(56, 189, 248, 0.06)', borderRadius: '12px', border: '1px solid rgba(56, 189, 248, 0.25)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.35rem' }}>
                      <span className="badge badge-cyan" style={{ fontSize: '0.7rem', fontWeight: 800 }}>
                        {currentMs.week_range} Focus
                      </span>
                      <span style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                        {currentMs.focus_skill}
                      </span>
                    </div>
                    <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.5 }}>
                      <strong>Primary Objective:</strong> {currentMs.goal}
                    </p>
                  </div>

                  {/* Step-by-Step "How to Achieve" & Topics Grid */}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1rem' }}>
                    {/* How to Achieve */}
                    <div style={{ padding: '1rem', background: 'var(--bg-tertiary)', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                      <h4 style={{ fontSize: '0.88rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.6rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                        <Lightbulb size={15} color="var(--accent-amber)" />
                        Step-by-Step Execution Guide:
                      </h4>
                      <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', lineHeight: 1.6, whiteSpace: 'pre-line' }}>
                        {currentMs.how_to_achieve}
                      </div>
                    </div>

                    {/* Technical Topics & Tools */}
                    <div style={{ padding: '1rem', background: 'var(--bg-tertiary)', borderRadius: '10px', border: '1px solid var(--border-subtle)', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                      <div>
                        <h4 style={{ fontSize: '0.88rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <Code size={15} color="var(--accent-cyan)" />
                          Key Technical Topics to Master:
                        </h4>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                          {currentMs.topics.map((t, tIdx) => (
                            <div key={tIdx} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.4rem', fontSize: '0.76rem', color: 'var(--text-secondary)' }}>
                              <span style={{ color: 'var(--accent-cyan)', fontWeight: 800 }}>•</span>
                              <span>{t}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {currentMs.recommended_tools && currentMs.recommended_tools.length > 0 && (
                        <div style={{ paddingTop: '0.6rem', borderTop: '1px solid var(--border-subtle)' }}>
                          <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', display: 'block', marginBottom: '0.35rem' }}>
                            Recommended Software & Stack:
                          </span>
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                            {currentMs.recommended_tools.map((tl, tlIdx) => (
                              <span key={tlIdx} style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid var(--border-subtle)', padding: '0.2rem 0.55rem', borderRadius: '6px', fontSize: '0.72rem', color: 'var(--text-primary)', fontWeight: 600 }}>
                                🛠️ {tl}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* YouTube Video Masterclass Platform */}
                  {currentMs.youtube_resources && currentMs.youtube_resources.length > 0 && (
                    <YouTubePracticeStudio
                      resources={currentMs.youtube_resources}
                      domainName={selectedCoDomainRoadmap.domain || selectedCoDomainRoadmap.target_domain}
                      coDomainName={currentMs.focus_skill}
                    />
                  )}

                  {/* Verified Learning Platforms & Courseware Resources */}
                  {currentMs.learning_platforms && currentMs.learning_platforms.length > 0 && (
                    <div style={{ padding: '1rem', background: 'rgba(56, 189, 248, 0.05)', borderRadius: '10px', border: '1px solid rgba(56, 189, 248, 0.2)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.65rem', flexWrap: 'wrap', gap: '0.4rem' }}>
                        <h4 style={{ fontSize: '0.88rem', fontWeight: 800, color: 'var(--accent-cyan)', margin: 0, display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <BookOpen size={15} color="var(--accent-cyan)" />
                          Verified Learning Platforms & Courseware:
                        </h4>
                        <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>
                          Direct access to authentic learning portals & documentation
                        </span>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '0.65rem' }}>
                        {currentMs.learning_platforms.map((res, rIdx) => (
                          <a
                            key={rIdx}
                            href={res.platform_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            style={{
                              display: 'flex',
                              flexDirection: 'column',
                              justifyContent: 'space-between',
                              padding: '0.75rem 0.85rem',
                              background: 'var(--bg-tertiary)',
                              borderRadius: '8px',
                              border: '1px solid var(--border-subtle)',
                              textDecoration: 'none',
                              color: 'inherit',
                              transition: 'all 0.2s ease',
                              cursor: 'pointer'
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.borderColor = 'var(--accent-cyan)';
                              e.currentTarget.style.transform = 'translateY(-2px)';
                              e.currentTarget.style.boxShadow = '0 4px 12px rgba(56, 189, 248, 0.15)';
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.borderColor = 'var(--border-subtle)';
                              e.currentTarget.style.transform = 'translateY(0)';
                              e.currentTarget.style.boxShadow = 'none';
                            }}
                          >
                            <div>
                              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem', marginBottom: '0.35rem' }}>
                                <span style={{ fontWeight: 700, fontSize: '0.82rem', color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                                  🎓 {res.platform_name}
                                </span>
                                <span style={{ display: 'flex', alignItems: 'center', gap: '0.2rem', color: 'var(--accent-cyan)', fontSize: '0.7rem', fontWeight: 600 }}>
                                  <ExternalLink size={12} /> Open ↗
                                </span>
                              </div>
                              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.3rem', marginBottom: '0.4rem' }}>
                                <span style={{ background: 'rgba(56, 189, 248, 0.12)', color: 'var(--accent-cyan)', border: '1px solid rgba(56, 189, 248, 0.25)', fontSize: '0.66rem', fontWeight: 600, padding: '0.1rem 0.45rem', borderRadius: '4px' }}>
                                  📌 {res.topic_focus}
                                </span>
                                <span style={{ background: 'rgba(168, 85, 247, 0.12)', color: 'var(--accent-purple)', border: '1px solid rgba(168, 85, 247, 0.25)', fontSize: '0.66rem', fontWeight: 600, padding: '0.1rem 0.45rem', borderRadius: '4px' }}>
                                  ⭐ {res.access_badge}
                                </span>
                              </div>
                              <p style={{ fontSize: '0.74rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.4 }}>
                                {res.description}
                              </p>
                            </div>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Practical Project & Measurable Deliverable */}
                  <div style={{ padding: '1rem 1.25rem', background: 'rgba(16, 185, 129, 0.06)', borderRadius: '12px', border: '1px solid rgba(16, 185, 129, 0.25)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.35rem' }}>
                      <CheckCircle size={16} color="#10b981" />
                      <span style={{ fontSize: '0.88rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                        Phase Deliverable: {currentMs.practical_project}
                      </span>
                    </div>
                    <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', margin: 0 }}>
                      <strong>Tangible Verification Artifact:</strong> {currentMs.deliverable}
                    </p>
                  </div>

                  {/* Checkpoint Interview Questions (If Available) */}
                  {currentMs.interview_questions && currentMs.interview_questions.length > 0 && (
                    <div style={{ padding: '1rem', background: 'rgba(168, 85, 247, 0.06)', borderRadius: '12px', border: '1px solid rgba(168, 85, 247, 0.25)' }}>
                      <h4 style={{ fontSize: '0.88rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.6rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                        <HelpCircle size={15} color="var(--accent-purple)" />
                        Checkpoint Screening & Interview Questions:
                      </h4>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                        {currentMs.interview_questions.map((iq, iqIdx) => (
                          <div key={iqIdx} style={{ padding: '0.6rem 0.8rem', background: 'var(--bg-tertiary)', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
                            <div style={{ fontWeight: 700, fontSize: '0.78rem', color: 'var(--text-primary)', marginBottom: '0.25rem' }}>
                              Q{iqIdx + 1}: {iq.question}
                            </div>
                            {iq.answer_guide && (
                              <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                                <strong style={{ color: 'var(--accent-purple)' }}>Answer Strategy:</strong> {iq.answer_guide}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Actionable Tasks Checklist */}
                  <div>
                    <h4 style={{ fontSize: '0.88rem', fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.6rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                      <CheckCircle2 size={15} color="#10b981" />
                      Actionable Milestones Checklist:
                    </h4>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                      {currentMs.tasks.map((task) => {
                        const isDone = taskCompletionMap[task.id] ?? task.is_completed;
                        return (
                          <div 
                            key={task.id}
                            onClick={() => toggleTaskCompletion(task.id)}
                            style={{
                              padding: '0.75rem 1rem',
                              borderRadius: '8px',
                              background: isDone ? 'rgba(16, 185, 129, 0.08)' : 'var(--bg-tertiary)',
                              border: isDone ? '1px solid rgba(16, 185, 129, 0.3)' : '1px solid var(--border-subtle)',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'space-between',
                              cursor: 'pointer',
                              transition: 'all 0.15s ease'
                            }}
                          >
                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                              <div style={{
                                width: '18px',
                                height: '18px',
                                borderRadius: '4px',
                                border: isDone ? '1.5px solid #10b981' : '1.5px solid var(--border-subtle)',
                                background: isDone ? '#10b981' : 'transparent',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                flexShrink: 0
                              }}>
                                {isDone && <Check size={12} color="#ffffff" />}
                              </div>
                              <div>
                                <div style={{ fontWeight: 700, fontSize: '0.82rem', color: isDone ? 'var(--text-muted)' : 'var(--text-primary)', textDecoration: isDone ? 'line-through' : 'none' }}>
                                  {task.title}
                                </div>
                                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                                  {task.description}
                                </div>
                              </div>
                            </div>
                            <span className="badge" style={{ fontSize: '0.65rem', background: 'rgba(255,255,255,0.05)' }}>
                              ⏱️ {task.estimated_hours}h
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Placement Destination Intelligence Pack (Phase 5 / Global) */}
                  {selectedCoDomainRoadmap.placement_destination && (
                    <div style={{ padding: '1.25rem', background: 'var(--bg-tertiary)', borderRadius: '12px', border: '1.5px solid var(--accent-purple)44', marginTop: '0.5rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                          <Award size={18} color="var(--accent-purple)" />
                          <h4 style={{ fontSize: '0.95rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                            Placement & Internship Intelligence Pack
                          </h4>
                        </div>
                        <span className="badge badge-purple" style={{ fontSize: '0.7rem' }}>
                          {selectedCoDomainRoadmap.placement_destination.expected_salary_range}
                        </span>
                      </div>

                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem', marginBottom: '1rem' }}>
                        {/* Target Entry Roles */}
                        <div>
                          <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', display: 'block', marginBottom: '0.4rem' }}>
                            Target Entry Job Titles:
                          </span>
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                            {selectedCoDomainRoadmap.placement_destination.target_entry_roles.map((role, rIdx) => (
                              <span key={rIdx} style={{ background: 'rgba(168, 85, 247, 0.12)', border: '1px solid rgba(168, 85, 247, 0.3)', color: 'var(--accent-purple)', padding: '0.25rem 0.6rem', borderRadius: '6px', fontSize: '0.72rem', fontWeight: 600 }}>
                                🎯 {role}
                              </span>
                            ))}
                          </div>
                        </div>

                        {/* ATS Keywords */}
                        <div>
                          <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', display: 'block', marginBottom: '0.4rem' }}>
                            Top Resume ATS Keywords:
                          </span>
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                            {selectedCoDomainRoadmap.placement_destination.ats_keywords.map((kw, kIdx) => (
                              <button
                                key={kIdx}
                                type="button"
                                onClick={() => handleCopyText(kw, 'keyword')}
                                style={{
                                  background: copiedKeyword === kw ? '#10b98122' : 'rgba(56, 189, 248, 0.08)',
                                  border: copiedKeyword === kw ? '1px solid #10b981' : '1px solid rgba(56, 189, 248, 0.25)',
                                  color: copiedKeyword === kw ? '#10b981' : 'var(--accent-cyan)',
                                  padding: '0.2rem 0.55rem',
                                  borderRadius: '6px',
                                  fontSize: '0.7rem',
                                  fontWeight: 600,
                                  cursor: 'pointer',
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '0.25rem'
                                }}
                              >
                                {copiedKeyword === kw ? <Check size={11} /> : <Copy size={11} />}
                                <span>{kw}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* STAR Bullet Example */}
                      {selectedCoDomainRoadmap.placement_destination.star_bullet_examples.length > 0 && (
                        <div style={{ padding: '0.75rem', background: 'rgba(255,255,255,0.02)', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
                          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.3rem' }}>
                            <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase' }}>
                              Recommended Resume STAR Bullet:
                            </span>
                            <button
                              type="button"
                              onClick={() => handleCopyText(selectedCoDomainRoadmap.placement_destination!.star_bullet_examples[0], 'STAR bullet')}
                              className="btn btn-ghost btn-sm"
                              style={{ fontSize: '0.68rem', padding: '0.15rem 0.45rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                            >
                              <Copy size={11} /> Copy Bullet
                            </button>
                          </div>
                          <p style={{ fontSize: '0.76rem', color: 'var(--text-secondary)', margin: 0, lineHeight: 1.45 }}>
                            "{selectedCoDomainRoadmap.placement_destination.star_bullet_examples[0]}"
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* Modal Footer Controls */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '1.5rem', paddingTop: '1rem', borderTop: '1px solid var(--border-subtle)', flexWrap: 'wrap', gap: '0.75rem' }}>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button
                  type="button"
                  disabled={activeRoadmapPhase === 0}
                  onClick={() => setActiveRoadmapPhase(prev => Math.max(0, prev - 1))}
                  className="btn btn-secondary btn-sm"
                  style={{ fontSize: '0.78rem', opacity: activeRoadmapPhase === 0 ? 0.5 : 1 }}
                >
                  ← Previous Phase
                </button>
                <button
                  type="button"
                  disabled={activeRoadmapPhase === selectedCoDomainRoadmap.milestones.length - 1}
                  onClick={() => setActiveRoadmapPhase(prev => Math.min(selectedCoDomainRoadmap.milestones.length - 1, prev + 1))}
                  className="btn btn-secondary btn-sm"
                  style={{ fontSize: '0.78rem', opacity: activeRoadmapPhase === selectedCoDomainRoadmap.milestones.length - 1 ? 0.5 : 1 }}
                >
                  Next Phase →
                </button>
              </div>

              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button
                  type="button"
                  onClick={() => {
                    const targetName = selectedCoDomainRoadmap.co_domain_name || selectedCoDomainRoadmap.title;
                    const targetDomain = selectedCoDomainRoadmap.domain || currentDomainMeta.name;
                    setSelectedCoDomainRoadmap(null);
                    if (onNavigateToRoadmap) {
                      onNavigateToRoadmap(targetName, targetDomain, true);
                    }
                  }}
                  className="btn btn-primary btn-sm"
                  style={{ fontSize: '0.78rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.35rem' }}
                >
                  <Compass size={13} /> Open in Master Roadmap Hub →
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedCoDomainRoadmap(null)}
                  className="btn btn-ghost btn-sm"
                  style={{ fontSize: '0.78rem' }}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export const SkillGalaxy3D = React.memo(SkillGalaxy3DComponent);
