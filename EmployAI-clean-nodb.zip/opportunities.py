from typing import List, Optional
from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, require_premium_user
from app.models.user import User
from app.models.profile import StudentProfile, IndustryProfile
from app.models.opportunity import Opportunity, OpportunitySkill
from app.models.taxonomy import Skill, StudentSkill
from app.schemas.opportunity import OpportunityResponse, OpportunitySkillItem

router = APIRouter(prefix="/opportunities", tags=["Opportunities"])


@router.get("", response_model=List[OpportunityResponse])
def list_opportunities(
    domain: Optional[str] = Query(None, description="Filter by domain"),
    type: Optional[str] = Query(None, description="Filter by job / internship"),
    current_user: User = Depends(require_premium_user),
    db: Session = Depends(get_db)
):
    """Retrieve active opportunities with match scores dynamically calculated for the current student."""
    query = db.query(Opportunity).filter(Opportunity.is_active == True)
    if domain and domain.lower() != "all":
        query = query.filter(Opportunity.domain.ilike(f"%{domain}%"))
    if type and type.lower() != "all":
        query = query.filter(Opportunity.type == type.lower())

    opps = query.order_by(Opportunity.created_at.desc()).all()

    # If logged in as student, fetch student skills for matching
    student_skills_set = set()
    student_cgpa = 8.0
    if current_user and current_user.role == "student":
        st_profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
        if st_profile:
            student_cgpa = st_profile.cgpa or 8.0
            st_skills = db.query(StudentSkill).filter(StudentSkill.student_profile_id == st_profile.id).all()
            student_skills_set = {s.skill_id for s in st_skills}

    result = []
    for opp in opps:
        comp = db.query(IndustryProfile).filter(IndustryProfile.id == opp.company_id).first()
        company_name = comp.company_name if comp else "EmployAI Partner"
        company_loc = comp.location if comp else opp.location

        opp_skills = db.query(OpportunitySkill).filter(OpportunitySkill.opportunity_id == opp.id).all()
        skill_items = []
        matched_names = []
        missing_names = []

        req_count = 0
        req_matched = 0

        for os in opp_skills:
            sk = db.query(Skill).filter(Skill.id == os.skill_id).first()
            if sk:
                skill_items.append(OpportunitySkillItem(
                    skill_id=sk.id,
                    skill_name=sk.canonical_name,
                    is_required=os.is_required,
                    weight=os.weight
                ))
                if os.is_required:
                    req_count += 1
                    if sk.id in student_skills_set:
                        req_matched += 1
                        matched_names.append(sk.canonical_name)
                    else:
                        missing_names.append(sk.canonical_name)
                else:
                    if sk.id in student_skills_set:
                        matched_names.append(sk.canonical_name)

        match_pct = None
        if current_user and current_user.role == "student":
            base_score = (req_matched / (req_count or 1)) * 85.0
            cgpa_score = 15.0 if student_cgpa >= opp.eligibility_min_cgpa else 0.0
            match_pct = round(base_score + cgpa_score, 1)

        result.append(OpportunityResponse(
            id=opp.id,
            company_id=opp.company_id,
            company_name=company_name,
            company_location=company_loc,
            title=opp.title,
            type=opp.type,
            domain=opp.domain,
            location=opp.location,
            work_mode=opp.work_mode,
            description=opp.description,
            stipend_salary=opp.stipend_salary,
            eligibility_min_cgpa=opp.eligibility_min_cgpa,
            eligible_departments=opp.eligible_departments_json or [],
            deadline=opp.deadline,
            is_active=opp.is_active,
            created_at=opp.created_at,
            skills=skill_items,
            user_match_percentage=match_pct,
            matched_skills=matched_names if current_user else None,
            missing_skills=missing_names if current_user else None,
            eligibility_status="Eligible" if student_cgpa >= opp.eligibility_min_cgpa else "Below CGPA criteria"
        ))

    return result
