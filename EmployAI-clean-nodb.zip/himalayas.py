import re
import html
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting


class HimalayasProvider(JobProviderAdapter):
    """
    Himalayas Remote Jobs API Adapter.
    Public feed of verified remote roles across Engineering, Design, Product,
    Marketing, Finance, Healthcare, and Operations.
    """

    API_URL = "https://himalayas.app/jobs/api"

    @property
    def name(self) -> str:
        return "Himalayas"

    def _strip_html(self, raw_html: str) -> str:
        if not raw_html:
            return ""
        clean = re.sub(r"<[^>]+>", " ", raw_html)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        postings: List[RawJobPosting] = []
        try:
            params = {"limit": 50}
            if query:
                params["search"] = query

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) EmployAI/1.0",
                "Accept": "application/json"
            }

            async with httpx.AsyncClient(timeout=12.0, follow_redirects=True) as client:
                response = await client.get(self.API_URL, params=params, headers=headers)
                if response.status_code != 200:
                    print(f"[WARN] Himalayas API returned status {response.status_code}")
                    return []

                payload = response.json()
                jobs = payload.get("jobs", []) if isinstance(payload, dict) else payload

                for item in jobs:
                    raw_title = item.get("title", "")
                    raw_desc = self._strip_html(item.get("description") or item.get("excerpt", ""))
                    company_name = item.get("companyName", "Tech Employer")
                    cats = item.get("categories") or []
                    tags = list(cats)

                    emp_raw = item.get("employmentType") or "full-time"
                    emp_type = " ".join(emp_raw).lower() if isinstance(emp_raw, list) else str(emp_raw).lower()
                    mapped_type = "full-time"
                    if "intern" in emp_type or "intern" in raw_title.lower():
                        mapped_type = "internship"
                    elif "part" in emp_type:
                        mapped_type = "part-time"
                    elif "contract" in emp_type or "freelance" in emp_type:
                        mapped_type = "contract"

                    sen_raw = item.get("seniority") or ""
                    seniority = " ".join(sen_raw).lower() if isinstance(sen_raw, list) else str(sen_raw).lower()
                    exp_level = "entry"
                    if "senior" in seniority or "senior" in raw_title.lower() or "lead" in raw_title.lower() or "director" in raw_title.lower():
                        exp_level = "senior"
                    elif "mid" in seniority:
                        exp_level = "mid"
                    elif "entry" in seniority or "junior" in seniority or mapped_type == "internship":
                        exp_level = "intern" if mapped_type == "internship" else "entry"

                    min_sal = item.get("minSalary")
                    max_sal = item.get("maxSalary")
                    curr = item.get("currency") or "USD"
                    salary_str = None
                    if min_sal and max_sal:
                        salary_str = f"{curr} {min_sal:,} - {max_sal:,}"
                    elif min_sal:
                        salary_str = f"{curr} {min_sal:,}+"

                    postings.append(RawJobPosting(
                        source_id=f"himalayas-{item.get('guid', item.get('title', 'job'))}",
                        source="Himalayas",
                        title=raw_title,
                        company=company_name,
                        location="Remote",
                        remote=True,
                        job_type=mapped_type,
                        experience_level=exp_level,
                        description=raw_desc,
                        required_skills=tags,
                        apply_url=item.get("applicationLink") or "https://himalayas.app",
                        salary_range=salary_str,
                        posted_date=str(item.get("pubDate") or "Recently")
                    ))
        except Exception as e:
            print(f"[ERROR] Himalayas fetch_jobs failed: {e}")

        return postings
