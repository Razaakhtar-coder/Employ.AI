import sys
import os

os.environ["VERCEL"] = "1"
os.environ["DATABASE_URL"] = "sqlite:////tmp/employai.db"
os.environ.setdefault("GOOGLE_CLIENT_ID", "478210219727-5f0gv41g125sfb1fcrobo9e5k0m8vbgg.apps.googleusercontent.com")

# Add backend directory to Python sys.path
backend_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "backend"))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from app.core.database import init_db_tables
init_db_tables()

from app.main import app
