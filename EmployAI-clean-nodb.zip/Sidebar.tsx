import React, { useMemo, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  LayoutDashboard, Orbit, FileText, Target, 
  Compass, Briefcase, BarChart3, BookOpen, Layers, Scan,
  BookMarked, Mic, X, ShieldCheck, Lock
} from 'lucide-react';

export interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

const SidebarComponent: React.FC<SidebarProps> = ({ currentTab, setCurrentTab, isOpen = false, onClose }) => {
  const { activeRole, isPremium, isAdmin, openAdminPaymentsModal } = useAuth();

  const navItems = useMemo(() => {
    if (activeRole === 'academia') {
      return [
        { id: 'academia_overview', label: 'Institutional Dashboard', icon: LayoutDashboard },
        { id: 'curriculum', label: 'Curriculum Gap Analytics', icon: Layers, badge: 'AI Matrix' },
        { id: 'departments', label: 'Department Readiness', icon: BarChart3 },
        { id: 'syllabus', label: 'Syllabus Ingestion AI', icon: BookOpen }
      ];
    }
    // Default: Student Workflows
    const items = [
      { id: 'dashboard', label: 'Overview Dashboard', icon: LayoutDashboard },
      { 
        id: 'interview', 
        label: 'AI Mock Interview', 
        icon: Mic, 
        badge: (!isPremium && !isAdmin) ? 'PRO' : 'Voice & STAR',
        isLocked: !isPremium && !isAdmin 
      },
      { id: 'scanner3d', label: '3D Hologram Scanner', icon: Scan, badge: '3D Live' },
      { id: 'galaxy', label: '3D Skill Galaxy', icon: Orbit, badge: 'Interactive' },
      { 
        id: 'resume', 
        label: 'AI Resume & STAR', 
        icon: FileText, 
        badge: 'AI Engine'
      },
      { id: 'matching', label: 'Explainable Match', icon: Target },
      { 
        id: 'roadmap', 
        label: 'Placement Level Roadmap', 
        icon: Compass, 
        badge: (!isPremium && !isAdmin) ? 'PRO' : undefined,
        isLocked: !isPremium && !isAdmin 
      },
      { 
        id: 'opportunities', 
        label: 'Jobs & Internships', 
        icon: Briefcase, 
        badge: (!isPremium && !isAdmin) ? 'PRO' : undefined,
        isLocked: !isPremium && !isAdmin 
      },
      { id: 'resume_learning', label: 'Read & Learn Resume', icon: BookMarked, badge: 'AI Study' }
    ];

    if (isAdmin) {
      items.push({
        id: 'admin_approvals',
        label: 'Payment Approvals',
        icon: ShieldCheck,
        badge: 'Admin'
      } as any);
    }

    return items;
  }, [activeRole, isPremium, isAdmin]);

  // Only render mobile drawer backdrop when actually on mobile/tablet viewports (< 1024px)
  const [isMobile, setIsMobile] = React.useState<boolean>(() => {
    return typeof window !== 'undefined' ? window.innerWidth < 1024 : false;
  });

  React.useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleTabSelect = useCallback((tabId: string) => {
    if (tabId === 'admin_approvals') {
      openAdminPaymentsModal();
      if (isMobile && onClose) onClose();
      return;
    }

    React.startTransition(() => {
      setCurrentTab(tabId);
    });
    if (isMobile && onClose) {
      onClose();
    }
  }, [setCurrentTab, onClose, isMobile, openAdminPaymentsModal]);

  return (
    <>
      {/* Mobile Drawer Overlay Backdrop - strictly mounted on mobile screens */}
      {isOpen && isMobile && (
        <div 
          onClick={onClose}
          className="mobile-sidebar-backdrop"
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.65)',
            backdropFilter: 'blur(3px)',
            WebkitBackdropFilter: 'blur(3px)',
            zIndex: 9998,
            animation: 'fadeIn 0.15s ease-out'
          }}
        />
      )}

      <aside 
        className={`app-sidebar no-print ${isOpen ? 'sidebar-open' : 'sidebar-collapsed'}`}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.4rem 0.75rem', marginBottom: '0.5rem' }}>
          <span style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Navigation Menu
          </span>
          {onClose && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }}
              className="sidebar-close-toggle-btn"
              aria-label="Close navigation"
              title="Close Navigation"
              style={{
                background: 'rgba(255, 255, 255, 0.05)',
                border: '1px solid var(--border-subtle)',
                color: 'var(--text-secondary)',
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: '28px',
                height: '28px',
                borderRadius: '6px',
                padding: '0.2rem',
                transition: 'all 0.14s ease'
              }}
            >
              <X size={15} />
            </button>
          )}
        </div>

        <nav style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
          {navItems.map((item) => {
            const isActive = currentTab === item.id;
            const Icon = item.icon;

            return (
              <button
                key={item.id}
                onClick={() => handleTabSelect(item.id)}
                className={`sidebar-nav-btn ${isActive ? 'is-active' : ''}`}
              >
                <div className="sidebar-nav-label-box">
                  <Icon size={18} className="sidebar-nav-icon" color={isActive ? 'var(--accent-cyan)' : undefined} />
                  <span className="sidebar-nav-text" title={item.label}>{item.label}</span>
                </div>
                {(item as any).isLocked ? (
                  <span className="sidebar-lock-badge" title="PRO Feature — Upgrade to Unlock">
                    <span className="sidebar-lock-icon-wrap">
                      <Lock size={10} className="sidebar-lock-svg" strokeWidth={2.5} />
                    </span>
                    <span className="sidebar-lock-text">PRO</span>
                  </span>
                ) : item.badge ? (
                  <span className="badge badge-cyan sidebar-standard-badge">
                    {item.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </nav>

        {/* Engine Status Card */}
        <div style={{ marginTop: 'auto', padding: '1rem', borderRadius: '12px', background: 'rgba(255, 255, 255, 0.02)', border: '1px solid var(--border-subtle)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.4rem' }}>
            <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--accent-emerald)', boxShadow: '0 0 8px #10b981' }} />
            <span style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-primary)' }}>System Engine Live</span>
          </div>
          <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
            Database & Taxonomy Synchronized
          </p>
        </div>
      </aside>
    </>
  );
};

export const Sidebar = React.memo(SidebarComponent);
export default Sidebar;
