import requests

BASE = 'http://127.0.0.1:8000/api/v1'

def run_tests():
    try:
        print("--- 1. Testing GET /interviews/active-resume ---")
        res_resume = requests.get(f'{BASE}/interviews/active-resume', timeout=3)
        print('Active resume status:', res_resume.status_code)
        facts = res_resume.json()
        print('Extracted skills:', facts.get('skills', [])[:5])
        print('Extracted projects:', [p.get('title') if isinstance(p, dict) else p for p in facts.get('projects', [])[:3]])

        print("\n--- 2. Testing POST /interviews/start ---")
        res_start = requests.post(f'{BASE}/interviews/start', json={
            'target_role': 'Full Stack Developer',
            'interview_type': 'comprehensive',
            'difficulty': 'intermediate',
            'num_questions': 3
        }, timeout=5)
        print('Start session status:', res_start.status_code)
        if res_start.status_code != 200:
            print("Server requires auth or is offline. Skipping live integration tests.")
            return

        session = res_start.json()
        session_id = session.get('id')
        if not session_id:
            return
        questions = session.get('questions', [])
        print(f'Started session {session_id} with {len(questions)} questions.')

        print("\n--- 3. Testing 3-4 word answer (MUST BE 0/100) ---")
        q1_id = questions[0]['id']
        res_ans1 = requests.post(f'{BASE}/interviews/{session_id}/answer', json={
            'question_id': q1_id,
            'user_answer': 'i did it with python'
        }, timeout=5)
        ans1_eval = res_ans1.json()
        print('Score awarded:', ans1_eval['score'])
        print('Is correct:', ans1_eval['is_correct'])

        print("\n--- 4. Testing Substantive Technical Answer ---")
        q2_id = questions[1]['id']
        substantive_answer = 'In my previous project, I architected the backend REST API using FastAPI and PostgreSQL, implementing connection pooling and asynchronous database queries with SQLAlchemy. To reduce latency by 45 percent, I introduced a Redis caching layer for frequent read endpoints and configured JWT authentication with role-based access control.'
        res_ans2 = requests.post(f'{BASE}/interviews/{session_id}/answer', json={
            'question_id': q2_id,
            'user_answer': substantive_answer
        }, timeout=5)
        ans2_eval = res_ans2.json()
        print('Score awarded:', ans2_eval['score'])

        print("\n--- 5. Completing Session ---")
        res_comp = requests.post(f'{BASE}/interviews/{session_id}/complete', json={'duration_seconds': 145}, timeout=5)
        print('Complete status:', res_comp.status_code)
    except Exception as exc:
        print(f"Skipping live network test: {exc}")

if __name__ == '__main__':
    run_tests()
