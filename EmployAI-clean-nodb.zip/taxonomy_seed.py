import uuid
from sqlalchemy.orm import Session
from app.models.taxonomy import SkillCategory, Skill, SkillAlias
from app.models.matching import Role, RoleSkill


def seed_universal_taxonomy(db: Session):
    """Seed comprehensive multi-domain skill taxonomy and career roles across all academic degrees."""
    print("[INFO] Checking and Seeding Universal Multi-Domain Skill Taxonomy...")

    # 1. Categories
    category_definitions = {
        "technical": ("Technical Engineering Skills", "Core domain engineering methods and theory", "Cpu"),
        "cad_design": ("CAD & 3D Modeling", "Computer aided design and simulation tools", "Box"),
        "software_dev": ("Software Development & Cloud", "Programming languages, frameworks and infrastructure", "Code"),
        "data_analytics": ("Data & Business Analytics", "Data visualization, modeling and BI tools", "BarChart3"),
        "management_soft": ("Project & Soft Skills", "Methodologies, communication and management", "Users"),
        "legal": ("Legal & Corporate Governance", "Contract drafting, litigation, compliance and statutory research", "Scale"),
        "commerce_fin": ("Commerce, Accounting & Taxation", "Financial statements, GST, auditing and corporate accounting", "Receipt"),
        "management": ("Business Administration & Operations", "Strategy, HR, operations and marketing management", "Briefcase"),
        "humanities": ("Humanities & Social Sciences", "Economics, policy analysis, psychology and communications", "BookOpen"),
        "healthcare": ("Healthcare, Nursing & Clinical Medicine", "Patient care, diagnostics, clinical procedures and triage", "HeartPulse"),
        "pharmacy": ("Pharmaceutical & Life Sciences", "Drug formulation, pharmacovigilance and QA/QC", "Pill")
    }

    categories = {}
    for key, (name, desc, icon) in category_definitions.items():
        existing_cat = db.query(SkillCategory).filter_by(name=name).first()
        if not existing_cat:
            cat = SkillCategory(name=name, description=desc, icon=icon)
            db.add(cat)
            db.flush()
            categories[key] = cat
        else:
            categories[key] = existing_cat

    # 2. Multi-Domain Skills & Aliases
    # Format: (canonical_name, domain, category_key, description, is_emerging, [aliases])
    skills_data = [
        # Mechanical Engineering
        ("SolidWorks", "Mechanical", "cad_design", "3D parametric modeling, assembly design and simulation software", False, ["Solid Works", "Solidworks CAD", "SW 3D"]),
        ("CAD", "Mechanical", "cad_design", "Computer-Aided Design principles for 2D drafting and 3D modeling", False, ["Computer Aided Design", "AutoCAD Mech"]),
        ("CATIA", "Mechanical", "cad_design", "High-end multi-platform CAD/CAM/CAE software suite", False, ["Catia V5", "CATIA 3D"]),
        ("GD&T", "Mechanical", "technical", "Geometric Dimensioning and Tolerancing standard (ASME Y14.5)", False, ["Geometric Dimensioning & Tolerancing", "GDT", "Geometric Tolerancing"]),
        ("CNC", "Mechanical", "technical", "Computer Numerical Control machining, G-code & M-code programming", False, ["CNC Machining", "CNC Programming", "G-Code", "M-Code"]),
        ("FEA", "Mechanical", "cad_design", "Finite Element Analysis for structural and thermal stress analysis", False, ["Finite Element Analysis", "Finite Element Method", "FEM"]),
        ("ANSYS", "Mechanical", "cad_design", "Engineering simulation and finite element analysis software", False, ["Ansys Workbench", "ANSYS FEA"]),
        ("Manufacturing", "Mechanical", "technical", "Processes including casting, forming, machining, welding and additive manufacturing", False, ["Manufacturing Processes", "Production Engineering"]),
        ("Thermodynamics", "Mechanical", "technical", "Thermal systems, heat transfer, and energy conversion principles", False, ["Thermal Engineering", "Heat Transfer"]),
        ("Engineering Drawing", "Mechanical", "cad_design", "Orthographic projections, isometric views and blueprint reading", False, ["Drafting", "Engineering Blueprint"]),
        ("AutoCAD", "Mechanical", "cad_design", "2D and 3D drafting software by Autodesk", False, ["Auto CAD", "Autodesk CAD"]),
        ("Robotics & Automation", "Mechanical", "technical", "Industrial kinematics, PLC controls and automated manufacturing", True, ["Industrial Robotics", "PLC Programming"]),

        # Civil Engineering
        ("Revit", "Civil", "cad_design", "Building Information Modeling (BIM) software for structural & architectural design", False, ["Autodesk Revit", "Revit BIM"]),
        ("BIM", "Civil", "cad_design", "Building Information Modeling workflows and 3D clash detection", True, ["Building Information Modeling", "BIM 360"]),
        ("STAAD.Pro", "Civil", "technical", "Structural analysis and design software tool", False, ["STAAD Pro", "Staad-Pro", "STAAD"]),
        ("Quantity Estimation", "Civil", "technical", "Costing, estimation, bill of quantities (BOQ) and measurement", False, ["BOQ", "Estimation & Costing", "Quantity Surveying"]),
        ("Structural Analysis", "Civil", "technical", "Analysis of beams, trusses, frames, and load-bearing structures", False, ["Structural Design", "Theory of Structures"]),
        ("Construction Management", "Civil", "management_soft", "Site planning, CPM/PERT scheduling and safety standards", False, ["Site Management", "Project Construction Planning"]),
        ("ETABS", "Civil", "technical", "Structural analysis and design software for multi-story building systems", False, ["Etabs 3D"]),
        ("Geo-technical Engineering", "Civil", "technical", "Soil mechanics, foundation design and slope stability", False, ["Soil Mechanics", "Foundation Engineering"]),

        # Chemical Engineering
        ("Aspen Plus", "Chemical", "cad_design", "Chemical process simulation software for steady-state modeling", False, ["Aspen", "Aspen HYSYS", "Process Simulator"]),
        ("Process Design", "Chemical", "technical", "Unit operations design, mass and energy balance calculations", False, ["Chemical Process Design", "Plant Design"]),
        ("Chemical Thermodynamics", "Chemical", "technical", "Phase equilibria, reaction kinetics and thermodynamic cycles", False, ["Chemical Reaction Engineering", "Kinetics"]),
        ("Process Safety", "Chemical", "technical", "HAZOP analysis, chemical hazard assessment and plant safety standards", False, ["HAZOP", "Process Safety Management", "PSM"]),
        ("P&ID", "Chemical", "technical", "Piping and Instrumentation Diagrams interpretation and drafting", False, ["Piping & Instrumentation", "P and ID Diagram"]),

        # Electrical & Electronics
        ("VLSI", "Electrical", "technical", "Very Large Scale Integration digital and analog circuit design", False, ["VLSI Design", "ASIC Design"]),
        ("Embedded C", "Electrical", "software_dev", "Low-level micro-controller firmware programming", False, ["Embedded Systems", "Firmware C", "Microcontroller C"]),
        ("Verilog", "Electrical", "technical", "Hardware Description Language (HDL) for FPGA and digital design", False, ["VHDL", "Verilog HDL"]),
        ("MATLAB", "Electrical", "technical", "Numerical computing and Simulink simulation platform", False, ["Matlab / Simulink", "Simulink"]),
        ("PCB Design", "Electrical", "cad_design", "Printed Circuit Board schematic capture and routing", False, ["Altium Designer", "Eagle PCB", "KiCAD"]),
        ("Power Systems", "Electrical", "technical", "Electrical power generation, transmission, distribution and protection", False, ["Power Engineering", "Smart Grid"]),
        ("IoT & Microcontrollers", "Electrical", "technical", "ESP32, ARM Cortex, sensor interfacing and IoT protocols", True, ["IoT", "Internet of Things", "ESP32", "Arduino"]),

        # Computer Science & IT
        ("Python", "Computer Science", "software_dev", "High-level programming language for backend, data and scripting", False, ["Python 3", "Py"]),
        ("JavaScript", "Computer Science", "software_dev", "Core web scripting language for frontend and fullstack", False, ["JS", "Vanilla JS"]),
        ("TypeScript", "Computer Science", "software_dev", "Typed superset of JavaScript", False, ["TS"]),
        ("React", "Computer Science", "software_dev", "Component-based UI library for single-page web applications", False, ["React.js", "ReactJS"]),
        ("FastAPI", "Computer Science", "software_dev", "High-performance asynchronous Python REST API framework", False, ["FastAPI Framework"]),
        ("SQL", "Computer Science", "software_dev", "Relational database querying and schema manipulation", False, ["PostgreSQL", "MySQL", "RDBMS"]),
        ("Docker", "Computer Science", "software_dev", "Containerization and container orchestration tooling", False, ["Containers", "Docker Compose"]),
        ("Cloud Computing", "Computer Science", "software_dev", "Cloud infrastructure (AWS, GCP, Azure)", True, ["AWS", "Google Cloud", "Azure"]),
        ("DevOps & CI/CD", "Computer Science", "software_dev", "Automated deployment pipelines and infrastructure as code", True, ["DevOps", "CI/CD Pipelines", "GitHub Actions"]),
        ("Cybersecurity", "Computer Science", "technical", "Information security, network defense and vulnerability assessment", True, ["InfoSec", "Network Security"]),
        ("Machine Learning", "Computer Science", "data_analytics", "Supervised/unsupervised modeling and AI algorithms", True, ["ML", "Deep Learning", "AI"]),

        # Business & Data Analytics
        ("Advanced Excel", "Business Analytics", "data_analytics", "Formulas, PivotTables, VLOOKUP, XLOOKUP, macros and modeling", False, ["MS Excel", "Microsoft Excel", "Excel"]),
        ("Power BI", "Business Analytics", "data_analytics", "Business intelligence and interactive dashboard visualization tool", False, ["PowerBI", "MS Power BI"]),
        ("Tableau", "Business Analytics", "data_analytics", "Data visualization and interactive analytics platform", False, ["Tableau Desktop", "Tableau Analytics"]),
        ("Requirements Gathering", "Business Analytics", "management_soft", "BRD/FRD documentation, stakeholder interviews and scope definition", False, ["BRD Creation", "Business Requirements Document"]),
        ("Business Process Analysis", "Business Analytics", "management_soft", "Process mapping, BPMN workflows and gap analysis", False, ["BPMN", "Process Mapping", "Workflow Optimization"]),
        ("Data Wrangling", "Business Analytics", "data_analytics", "Data cleaning, transformation, and ETL workflows", False, ["Data Cleaning", "Data Preprocessing", "ETL"]),

        # Law & Legal Studies (BA LLB / LLB / LLM)
        ("Contract Drafting & Review", "BA LLB", "legal", "Drafting non-disclosure agreements, master service agreements, and terms of service", False, ["Contract Drafting", "Agreement Review", "Legal Drafting"]),
        ("Legal Research & Analysis", "BA LLB", "legal", "Statutory research, case law precedent analysis, and Manupatra/SCC Online citation", False, ["Legal Research", "Case Law Analysis", "SCC Online"]),
        ("Corporate Governance & Compliance", "BA LLB", "legal", "Companies Act compliance, SEBI regulations, board meeting documentation, and filings", False, ["Corporate Compliance", "SEBI Compliance", "Secretarial Standards"]),
        ("Litigation & Dispute Resolution", "BA LLB", "legal", "Pleadings, writ petitions, civil court procedures, and evidence assessment", False, ["Civil Litigation", "Court Pleadings", "Dispute Resolution"]),
        ("Intellectual Property (IPR)", "BA LLB", "legal", "Trademarks, patents, copyrights, design registrations, and infringement enforcement", True, ["IPR", "Trademark Filing", "Patent Prosecution"]),
        ("Arbitration & Mediation", "BA LLB", "legal", "Alternative dispute resolution (ADR), commercial arbitration hearings, and settlement drafting", False, ["ADR", "Commercial Arbitration", "Mediation"]),
        ("Constitutional & Commercial Law", "BA LLB", "legal", "Statutory interpretation, constitutional remedies, contract law, and mercantile jurisprudence", False, ["Commercial Law", "Contract Law", "Constitutional Law"]),
        ("Legal Due Diligence", "BA LLB", "legal", "M&A due diligence audits, regulatory clearances, and title verification reports", True, ["Due Diligence", "M&A Due Diligence", "Title Search"]),

        # Commerce & Accounting (BCOM / MCOM / CA)
        ("Financial Accounting & Reporting", "BCOM", "commerce_fin", "Double-entry bookkeeping, GAAP/Ind AS compliance, trial balance, and balance sheet preparation", False, ["Financial Accounting", "Balance Sheet Preparation", "Ind AS"]),
        ("Taxation & GST Filing", "BCOM", "commerce_fin", "Direct and indirect taxes, GST GSTR-1/3B filing, TDS computations, and income tax returns", False, ["GST Filing", "Direct Tax", "TDS Computation", "Income Tax"]),
        ("Auditing & Statutory Assurance", "BCOM", "commerce_fin", "Internal audit, vouching, verification, statutory audit checklists, and internal financial controls", False, ["Statutory Audit", "Internal Audit", "Vouching & Verification"]),
        ("Cost & Management Accounting", "BCOM", "commerce_fin", "Standard costing, variance analysis, marginal costing, and operational budgeting", False, ["Cost Accounting", "Variance Analysis", "Marginal Costing"]),
        ("Tally Prime & ERP Systems", "BCOM", "commerce_fin", "Accounting on Tally Prime, Zoho Books, QuickBooks, and voucher entries", False, ["Tally Prime", "Tally ERP 9", "Zoho Books", "QuickBooks"]),
        ("Financial Statement Analysis", "BCOM", "commerce_fin", "Ratio analysis, cash flow analysis, working capital assessment, and trend forecasting", False, ["Ratio Analysis", "Cash Flow Statement", "Working Capital"]),
        ("Corporate Finance & Valuation", "BCOM", "commerce_fin", "Capital budgeting, DCF valuation, cost of capital (WACC), and equity research", True, ["Corporate Finance", "DCF Valuation", "WACC"]),

        # Business Administration & Management (BBA / MBA)
        ("Business Strategy & Operations", "BBA", "management", "Strategic planning, operational workflows, competitive benchmarking, and OKRs", False, ["Business Strategy", "Operations Management", "Strategic Planning"]),
        ("Marketing Strategy & Branding", "BBA", "management", "Go-to-market strategy, product positioning, campaign execution, and marketing mix", False, ["Brand Management", "Marketing Strategy", "GTM Strategy"]),
        ("Human Resource Management (HRM)", "BBA", "management", "Talent acquisition, employee onboarding, KPI appraisal, and organizational behavior", False, ["HRM", "Talent Acquisition", "Employee Engagement"]),
        ("Supply Chain & Logistics", "BBA", "management", "Inventory management, procurement vendor evaluation, demand forecasting, and logistics", False, ["Supply Chain Management", "Procurement", "Logistics"]),
        ("Market Research & Consumer Insights", "BBA", "management", "Primary and secondary market surveys, consumer persona design, and focus group analysis", False, ["Market Research", "Consumer Insights", "Competitive Analysis"]),
        ("Product Strategy & Roadmapping", "BBA", "management", "User journey mapping, feature prioritization, PRD authoring, and product lifecycle management", True, ["Product Management", "PRD Authoring", "Product Strategy"]),

        # Liberal Arts & Humanities (BA Hons - Economics, Psychology, English, Public Policy)
        ("Macroeconomic Policy Analysis", "BA Hons", "humanities", "Fiscal and monetary policy evaluation, inflation-growth dynamics, and econometric indicators", False, ["Economic Analysis", "Policy Analysis", "Econometrics"]),
        ("Qualitative & Quantitative Research", "BA Hons", "humanities", "Research methodology, survey sampling, statistical hypothesis testing, and SPSS/R modeling", False, ["Research Methodology", "SPSS", "Qualitative Research"]),
        ("Public Policy Drafting", "BA Hons", "humanities", "Government policy whitepapers, stakeholder impact assessments, and regulatory briefings", True, ["Policy Drafting", "Policy Briefs", "Governance Analysis"]),
        ("Content Strategy & Communications", "BA Hons", "humanities", "Editorial writing, press releases, corporate narrative, and omnichannel communications", False, ["Content Strategy", "Corporate Communications", "Technical Writing"]),
        ("Behavioral & Social Psychology", "BA Hons", "humanities", "Cognitive psychology principles, behavioral interventions, and organizational dynamics", False, ["Behavioral Psychology", "Psychological Assessment", "Consumer Behavior"]),

        # Nursing & Patient Care (B.Sc Nursing / GNM)
        ("Clinical Patient Care & Triage", "Nursing", "healthcare", "Emergency triage, patient bedside care, head-to-toe assessment, and care plans", False, ["Patient Care", "Clinical Triage", "Bedside Nursing"]),
        ("Vital Signs & ICU Monitoring", "Nursing", "healthcare", "Multi-parameter monitors, ECG interpretation, hemodynamic monitoring, and ventilator care", False, ["Vital Signs", "ICU Monitoring", "ECG Interpretation"]),
        ("Pharmacology & Drug Administration", "Nursing", "healthcare", "Safe dosage calculation, IV cannulation, medication administration, and syringe pumps", False, ["Drug Administration", "IV Cannulation", "Medication Management"]),
        ("Infection Control & Sanitation", "Nursing", "healthcare", "Hospital-acquired infection protocols, aseptic techniques, biomedical waste management, and PPE", False, ["Infection Control", "Biomedical Waste", "Aseptic Technique"]),
        ("Electronic Health Records (EHR)", "Nursing", "healthcare", "Clinical documentation on hospital information systems, charting, and discharge summaries", False, ["EHR Systems", "Hospital Information Systems", "HIS Documentation"]),
        ("BLS & ACLS Emergency Protocols", "Nursing", "healthcare", "Basic Life Support, Advanced Cardiac Life Support, CPR execution, and crash cart management", True, ["BLS", "ACLS", "CPR", "Code Blue Protocol"]),

        # Medical & Clinical Sciences (MBBS / MD)
        ("Clinical Diagnostics & Examination", "MBBS", "healthcare", "Systemic clinical examination, differential diagnosis, symptom analysis, and clinical triage", False, ["Differential Diagnosis", "Clinical Examination", "Symptom Analysis"]),
        ("Patient Treatment & Pathology", "MBBS", "healthcare", "Disease pathology evaluation, therapeutic care plans, clinical pharmacology, and patient care", False, ["Disease Management", "Clinical Pathology", "Therapeutics"]),
        ("Emergency Medicine & Trauma Care", "MBBS", "healthcare", "Acute trauma stabilization, emergency airway management, shock protocols, and critical intervention", True, ["Emergency Medicine", "Trauma Stabilization", "Airway Management"]),
        ("Medical Ethics & Medico-Legal Protocols", "MBBS", "healthcare", "Informed consent, medical jurisprudence, patient confidentiality (HIPAA), and clinical audits", False, ["Medical Ethics", "Medico-Legal", "Informed Consent"]),
        ("Radiology & Lab Report Interpretation", "MBBS", "healthcare", "Interpretation of X-rays, CT scans, MRIs, blood biochemistry, and hematology panels", False, ["Radiology Interpretation", "Lab Investigations", "CT MRI Interpretation"]),
        ("Minor Surgical Procedures & Suturing", "MBBS", "healthcare", "Aseptic wound suturing, incision and drainage, local anesthesia administration, and minor OT skills", False, ["Suturing", "Minor OT Procedures", "Local Anesthesia"])
    ]

    skill_map = {}
    for name, domain, cat_key, desc, emerging, aliases in skills_data:
        existing_skill = db.query(Skill).filter_by(canonical_name=name).first()
        if not existing_skill:
            skill = Skill(
                canonical_name=name,
                slug=name.lower().replace(" ", "-").replace("&", "and").replace(".", "").replace("/", "-"),
                domain=domain,
                category_id=categories[cat_key].id,
                description=desc,
                is_emerging=emerging
            )
            db.add(skill)
            db.flush()
            skill_map[name] = skill

            for alias_text in aliases:
                alias = SkillAlias(
                    skill_id=skill.id,
                    alias=alias_text,
                    domain_hint=domain
                )
                db.add(alias)
        else:
            skill_map[name] = existing_skill

    # 3. Industry Career Roles & Required Skill Mappings
    roles_data = [
        # Mechanical
        {
            "title": "Manufacturing Engineer",
            "slug": "manufacturing-engineer",
            "domain": "Mechanical",
            "dept": "Mechanical Engineering, Production Engineering",
            "desc": "Designs, optimizes, and oversees manufacturing and production processes, CNC tooling, and quality assurance.",
            "skills": [
                ("SolidWorks", True, 1.0, "high"),
                ("CAD", True, 1.0, "high"),
                ("GD&T", True, 1.0, "high"),
                ("CNC", True, 1.0, "high"),
                ("Manufacturing", True, 1.0, "high"),
                ("Engineering Drawing", False, 0.7, "medium"),
                ("FEA", False, 0.5, "bonus")
            ]
        },
        {
            "title": "CAD Design Engineer",
            "slug": "cad-design-engineer",
            "domain": "Mechanical",
            "dept": "Mechanical Engineering, Automobile Engineering",
            "desc": "Creates detailed 3D CAD models, component assemblies, drafting specifications and GD&T blueprints.",
            "skills": [
                ("SolidWorks", True, 1.0, "high"),
                ("CAD", True, 1.0, "high"),
                ("CATIA", True, 0.9, "high"),
                ("GD&T", True, 0.9, "high"),
                ("Engineering Drawing", True, 0.8, "high"),
                ("AutoCAD", False, 0.6, "medium")
            ]
        },

        # Civil
        {
            "title": "Structural Engineer",
            "slug": "structural-engineer",
            "domain": "Civil",
            "dept": "Civil Engineering, Structural Engineering",
            "desc": "Performs structural calculations, load-bearing analysis, and ensures building seismic and safety standards.",
            "skills": [
                ("STAAD.Pro", True, 1.0, "high"),
                ("Structural Analysis", True, 1.0, "high"),
                ("AutoCAD", True, 0.9, "high"),
                ("ETABS", True, 0.8, "high"),
                ("Quantity Estimation", False, 0.6, "medium")
            ]
        },

        # Chemical
        {
            "title": "Process Engineer",
            "slug": "process-engineer",
            "domain": "Chemical",
            "dept": "Chemical Engineering, Petroleum Engineering",
            "desc": "Designs and optimizes continuous chemical reaction systems, distillation columns, and heat exchangers.",
            "skills": [
                ("Aspen Plus", True, 1.0, "high"),
                ("Process Design", True, 1.0, "high"),
                ("Chemical Thermodynamics", True, 1.0, "high"),
                ("Process Safety", True, 0.8, "high"),
                ("P&ID", False, 0.7, "medium")
            ]
        },

        # Electrical
        {
            "title": "Embedded Systems Engineer",
            "slug": "embedded-systems-engineer",
            "domain": "Electrical",
            "dept": "Electrical & Electronics, Electronics & Communication",
            "desc": "Programs micro-controller firmware, hardware abstraction layers, and real-time sensor communications.",
            "skills": [
                ("Embedded C", True, 1.0, "high"),
                ("IoT & Microcontrollers", True, 1.0, "high"),
                ("PCB Design", True, 0.8, "high"),
                ("MATLAB", False, 0.6, "medium")
            ]
        },

        # Computer Science
        {
            "title": "Fullstack Cloud Engineer",
            "slug": "fullstack-cloud-engineer",
            "domain": "Computer Science",
            "dept": "Computer Science, Information Technology",
            "desc": "Builds scalable end-to-end web applications with modern frontend frameworks, REST APIs, and cloud deployments.",
            "skills": [
                ("Python", True, 1.0, "high"),
                ("JavaScript", True, 1.0, "high"),
                ("React", True, 1.0, "high"),
                ("FastAPI", True, 0.9, "high"),
                ("SQL", True, 0.9, "high"),
                ("Docker", False, 0.7, "medium"),
                ("Cloud Computing", False, 0.7, "medium")
            ]
        },

        # Business Analytics
        {
            "title": "Business Intelligence Analyst",
            "slug": "business-intelligence-analyst",
            "domain": "Business Analytics",
            "dept": "Business Analytics, Management, Data Science",
            "desc": "Transforms enterprise transactional data into actionable business intelligence dashboards and executive reports.",
            "skills": [
                ("SQL", True, 1.0, "high"),
                ("Power BI", True, 1.0, "high"),
                ("Advanced Excel", True, 1.0, "high"),
                ("Business Process Analysis", True, 0.8, "high"),
                ("Requirements Gathering", False, 0.7, "medium"),
                ("Tableau", False, 0.6, "bonus")
            ]
        },

        # BA LLB (Law)
        {
            "title": "Corporate Legal Associate",
            "slug": "corporate-legal-associate",
            "domain": "BA LLB",
            "dept": "Law, Corporate Governance, Legal Studies",
            "desc": "Drafts and negotiates commercial contracts, ensures regulatory filings, and provides corporate compliance advisory.",
            "skills": [
                ("Contract Drafting & Review", True, 1.0, "high"),
                ("Corporate Governance & Compliance", True, 1.0, "high"),
                ("Legal Research & Analysis", True, 0.9, "high"),
                ("Legal Due Diligence", True, 0.9, "high"),
                ("Intellectual Property (IPR)", False, 0.7, "medium")
            ]
        },
        {
            "title": "Legal Compliance & Dispute Specialist",
            "slug": "legal-compliance-dispute-specialist",
            "domain": "BA LLB",
            "dept": "Law, Dispute Resolution",
            "desc": "Handles statutory compliance, arbitration proceedings, litigation pleadings, and regulatory risk mitigation.",
            "skills": [
                ("Litigation & Dispute Resolution", True, 1.0, "high"),
                ("Arbitration & Mediation", True, 1.0, "high"),
                ("Constitutional & Commercial Law", True, 0.9, "high"),
                ("Legal Research & Analysis", True, 0.8, "high")
            ]
        },

        # BCOM (Commerce & Finance)
        {
            "title": "Financial & Tax Accountant",
            "slug": "financial-tax-accountant",
            "domain": "BCOM",
            "dept": "Commerce, Accounting, Finance",
            "desc": "Manages end-to-end statutory bookkeeping, balance sheet consolidation, GST return filing, and direct taxation compliance.",
            "skills": [
                ("Financial Accounting & Reporting", True, 1.0, "high"),
                ("Taxation & GST Filing", True, 1.0, "high"),
                ("Tally Prime & ERP Systems", True, 0.9, "high"),
                ("Auditing & Statutory Assurance", True, 0.8, "high"),
                ("Financial Statement Analysis", False, 0.7, "medium")
            ]
        },

        # BBA (Management & Operations)
        {
            "title": "Business Operations & Strategy Associate",
            "slug": "business-operations-strategy-associate",
            "domain": "BBA",
            "dept": "Business Administration, Operations, Marketing",
            "desc": "Drives operational efficiency, cross-functional project workflows, market research, and GTM business planning.",
            "skills": [
                ("Business Strategy & Operations", True, 1.0, "high"),
                ("Marketing Strategy & Branding", True, 0.9, "high"),
                ("Human Resource Management (HRM)", True, 0.8, "high"),
                ("Market Research & Consumer Insights", True, 0.8, "high"),
                ("Supply Chain & Logistics", False, 0.7, "medium")
            ]
        },

        # BA Hons (Humanities & Public Policy)
        {
            "title": "Public Policy & Research Analyst",
            "slug": "public-policy-research-analyst",
            "domain": "BA Hons",
            "dept": "Economics, Political Science, Public Policy, Humanities",
            "desc": "Analyzes macroeconomic indicators, drafts policy whitepapers, conducts statistical survey research, and authors briefings.",
            "skills": [
                ("Macroeconomic Policy Analysis", True, 1.0, "high"),
                ("Qualitative & Quantitative Research", True, 1.0, "high"),
                ("Public Policy Drafting", True, 0.9, "high"),
                ("Content Strategy & Communications", True, 0.8, "high"),
                ("Behavioral & Social Psychology", False, 0.6, "medium")
            ]
        },

        # Nursing (Healthcare)
        {
            "title": "Clinical Staff Nurse (Critical Care)",
            "slug": "clinical-staff-nurse-critical-care",
            "domain": "Nursing",
            "dept": "Nursing, Healthcare, Hospital Care",
            "desc": "Delivers inpatient care, clinical triage, ICU hemodynamic monitoring, medication administration, and infection control.",
            "skills": [
                ("Clinical Patient Care & Triage", True, 1.0, "high"),
                ("Vital Signs & ICU Monitoring", True, 1.0, "high"),
                ("Pharmacology & Drug Administration", True, 1.0, "high"),
                ("BLS & ACLS Emergency Protocols", True, 0.9, "high"),
                ("Infection Control & Sanitation", True, 0.8, "high"),
                ("Electronic Health Records (EHR)", False, 0.7, "medium")
            ]
        },

        # MBBS (Medicine)
        {
            "title": "Resident Medical Officer (RMO)",
            "slug": "resident-medical-officer-rmo",
            "domain": "MBBS",
            "dept": "Medicine, Surgery, Clinical Healthcare",
            "desc": "Conducts patient clinical examinations, establishes differential diagnoses, oversees emergency trauma care, and prescribes therapies.",
            "skills": [
                ("Clinical Diagnostics & Examination", True, 1.0, "high"),
                ("Patient Treatment & Pathology", True, 1.0, "high"),
                ("Emergency Medicine & Trauma Care", True, 1.0, "high"),
                ("Radiology & Lab Report Interpretation", True, 0.9, "high"),
                ("Medical Ethics & Medico-Legal Protocols", True, 0.8, "high"),
                ("Minor Surgical Procedures & Suturing", False, 0.7, "medium")
            ]
        }
    ]

    for r_data in roles_data:
        existing_role = db.query(Role).filter_by(slug=r_data["slug"]).first()
        if not existing_role:
            role = Role(
                title=r_data["title"],
                slug=r_data["slug"],
                domain=r_data["domain"],
                department_affinity=r_data["dept"],
                description=r_data["desc"],
                min_exp_months=0
            )
            db.add(role)
            db.flush()

            for skill_name, is_req, weight, imp in r_data["skills"]:
                if skill_name in skill_map:
                    r_skill = RoleSkill(
                        role_id=role.id,
                        skill_id=skill_map[skill_name].id,
                        is_required=is_req,
                        weight=weight,
                        importance_level=imp
                    )
                    db.add(r_skill)

    db.commit()
    print("[SUCCESS] Universal Multi-Domain Taxonomy and Roles verified & seeded successfully!")
