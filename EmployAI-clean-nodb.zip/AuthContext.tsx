import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { User, UserRole, StudentProfile, AcademicProfile, IndustryProfile } from '../types';
import { authApi, profileApi, paymentsApi, getAuthToken, clearAuthToken, checkAndAnalyzeSubscriptionExpiry } from '../services/api';

export const ADMIN_EMAIL = 'akhtarrakeeb52@gmail.com';

interface AuthContextType {
  user: User | null;
  token: string | null;
  activeRole: UserRole;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  studentProfile: StudentProfile | null;
  academicProfile: AcademicProfile | null;
  industryProfile: IndustryProfile | null;
  isPremium: boolean;
  isAdmin: boolean;
  checkSubscription: () => Promise<void>;
  login: (email: string, password: string, username?: string) => Promise<void>;
  resetPassword: (email: string, newPassword: string) => Promise<void>;
  loginWithGoogle: (data: { email?: string; password?: string; full_name?: string; id_token?: string; avatar_url?: string; isRegister?: boolean; role?: UserRole }) => Promise<void>;
  register: (data: {
    email: string;
    password: string;
    full_name: string;
    role: UserRole;
    institution_or_company?: string;
    department_or_domain?: string;
  }) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
  openAuthModal: (initialMode?: 'login' | 'register', defaultRole?: UserRole) => void;
  closeAuthModal: () => void;
  clearError: () => void;
  isAuthModalOpen: boolean;
  authModalMode: 'login' | 'register';
  authModalDefaultRole: UserRole;
  isSubscriptionModalOpen: boolean;
  openSubscriptionModal: () => void;
  closeSubscriptionModal: () => void;
  isAdminPaymentsModalOpen: boolean;
  openAdminPaymentsModal: () => void;
  closeAdminPaymentsModal: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(getAuthToken());
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [studentProfile, setStudentProfile] = useState<StudentProfile | null>(null);
  const [academicProfile, setAcademicProfile] = useState<AcademicProfile | null>(null);
  const [industryProfile, setIndustryProfile] = useState<IndustryProfile | null>(null);

  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');
  const [authModalDefaultRole, setAuthModalDefaultRole] = useState<UserRole>('student');

  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState<boolean>(false);
  const [isAdminPaymentsModalOpen, setIsAdminPaymentsModalOpen] = useState<boolean>(false);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  const openAuthModal = (mode: 'login' | 'register' = 'login', defaultRole: UserRole = 'student') => {
    setError(null);
    setAuthModalMode(mode);
    setAuthModalDefaultRole(defaultRole);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setError(null);
    setIsAuthModalOpen(false);
  };

  const openSubscriptionModal = () => {
    setIsSubscriptionModalOpen(true);
  };

  const closeSubscriptionModal = () => {
    setIsSubscriptionModalOpen(false);
  };

  const openAdminPaymentsModal = () => {
    setIsAdminPaymentsModalOpen(true);
  };

  const closeAdminPaymentsModal = () => {
    setIsAdminPaymentsModalOpen(false);
  };

  const fetchRoleProfile = async (currentUser: User) => {
    try {
      if (currentUser.role === 'academia') {
        const ap = await profileApi.getAcademicMe();
        setAcademicProfile(ap);
      } else {
        const sp = await profileApi.getStudentMe();
        setStudentProfile(sp);
      }
    } catch {
      // ignore
    }
  };

  const checkSubscription = useCallback(async () => {
    if (!token) return;
    try {
      const status = await paymentsApi.getStatus();
      setUser(prev => {
        if (!prev) return prev;
        const isUserAdmin = Boolean(prev.email && prev.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase());
        
        let isPrem = status.is_premium || status.is_admin || isUserAdmin;
        let isExpired = false;
        let daysRem = status.days_remaining ?? 0;
        const validUntil = status.subscription_valid_until || prev.subscription_valid_until;

        if (!isUserAdmin) {
          const analysis = checkAndAnalyzeSubscriptionExpiry(prev.email, validUntil);
          if (analysis.is_expired || status.is_expired) {
            isPrem = false;
            isExpired = true;
            daysRem = 0;
          } else {
            isPrem = Boolean(status.is_premium || analysis.is_premium);
            daysRem = analysis.daysRemaining || status.days_remaining || 0;
            isExpired = !isPrem;
          }
        }

        const updated: User = {
          ...prev,
          is_premium: isPrem,
          role: (status.is_admin || isUserAdmin) ? ('admin' as UserRole) : prev.role,
          subscription_plan: status.plan_type || prev.subscription_plan,
          subscription_valid_until: validUntil,
          days_remaining: daysRem,
          is_expired: isExpired,
        };
        try {
          localStorage.setItem('employai_cached_user', JSON.stringify(updated));
        } catch {}
        return updated;
      });
    } catch {
      setUser(prev => {
        if (!prev) return prev;
        const isUserAdmin = Boolean(prev.email && prev.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase());
        if (isUserAdmin) return prev;
        const analysis = checkAndAnalyzeSubscriptionExpiry(prev.email, prev.subscription_valid_until);
        const updated: User = {
          ...prev,
          is_premium: analysis.is_premium,
          subscription_plan: analysis.plan || undefined,
          days_remaining: analysis.daysRemaining,
          is_expired: analysis.is_expired,
        };
        try {
          localStorage.setItem('employai_cached_user', JSON.stringify(updated));
        } catch {}
        return updated;
      });
    }
  }, [token]);

  const refreshUser = useCallback(async () => {
    const currentToken = getAuthToken();
    if (!currentToken) {
      setUser(null);
      setToken(null);
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);
      const me = await authApi.getMe();
      const savedName = localStorage.getItem('employai_custom_username');
      if (savedName && savedName.trim()) {
        me.full_name = savedName.trim();
      }

      // Check admin email
      const isUserAdmin = Boolean(me.email && me.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase());
      if (isUserAdmin) {
        me.role = 'admin';
        me.is_premium = true;
        me.subscription_plan = 'lifetime';
        me.days_remaining = 9999;
        me.is_expired = false;
      } else {
        let isPaidFromBackend = false;
        let isBackendExpired = false;
        let backendPlan: string | undefined = undefined;
        let backendDays: number | undefined = undefined;
        let validUntil = me.subscription_valid_until;

        try {
          const payStatus = await paymentsApi.getStatus();
          if (payStatus.is_premium) {
            isPaidFromBackend = true;
            backendPlan = payStatus.plan_type || undefined;
            backendDays = payStatus.days_remaining || undefined;
            if (payStatus.subscription_valid_until) {
              validUntil = payStatus.subscription_valid_until;
            }
          } else if (payStatus.is_expired) {
            isBackendExpired = true;
          }
        } catch {}

        const analysis = checkAndAnalyzeSubscriptionExpiry(me.email, validUntil);

        if (analysis.is_expired || isBackendExpired) {
          // EXPIRED: automatically reset PRO active back to regular user!
          me.is_premium = false;
          me.days_remaining = 0;
          me.is_expired = true;
        } else {
          me.is_premium = analysis.is_premium || isPaidFromBackend || Boolean(me.is_premium);
          me.subscription_plan = analysis.plan || backendPlan || me.subscription_plan;
          me.subscription_valid_until = validUntil;
          me.days_remaining = analysis.daysRemaining || backendDays || me.days_remaining || 0;
          me.is_expired = false;
        }
      }

      setUser(me);
      setToken(currentToken);
      try {
        localStorage.setItem('employai_cached_user', JSON.stringify(me));
      } catch {}
      await fetchRoleProfile(me);
    } catch (err: any) {
      console.warn('Auth token expired or invalid:', err?.message);
      clearAuthToken();
      setUser(null);
      setToken(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  // Continuous subscription time analysis: automatically resets PRO to upgrade when time is over
  useEffect(() => {
    const evaluateExpiry = () => {
      if (!user || user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) return;
      if (user.is_premium) {
        const analysis = checkAndAnalyzeSubscriptionExpiry(user.email, user.subscription_valid_until);
        if (analysis.is_expired) {
          setUser(prev => {
            if (!prev) return prev;
            const resetUser: User = { ...prev, is_premium: false, days_remaining: 0, is_expired: true };
            try {
              localStorage.setItem('employai_cached_user', JSON.stringify(resetUser));
            } catch {}
            return resetUser;
          });
        } else if (typeof analysis.daysRemaining === 'number' && user.days_remaining !== analysis.daysRemaining) {
          setUser(prev => {
            if (!prev || prev.days_remaining === analysis.daysRemaining) return prev;
            const updated: User = { ...prev, days_remaining: analysis.daysRemaining };
            try {
              localStorage.setItem('employai_cached_user', JSON.stringify(updated));
            } catch {}
            return updated;
          });
        }
      }
    };

    const interval = setInterval(evaluateExpiry, 10000);
    window.addEventListener('focus', evaluateExpiry);
    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', evaluateExpiry);
    };
  }, [user]);

  const login = async (email: string, password: string, username?: string) => {
    setError(null);
    setIsLoading(true);
    try {
      const res = await authApi.login({ email, password, username });
      setToken(res.access_token);
      const chosenName = username?.trim() || res.full_name || 'Student';
      try {
        localStorage.setItem('employai_custom_username', chosenName);
      } catch {
        // ignore
      }

      const isUserAdmin = res.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase();
      const analysis = checkAndAnalyzeSubscriptionExpiry(res.email, res.subscription_valid_until);
      const isPaid = isUserAdmin || (!analysis.is_expired && (analysis.is_premium || Boolean(res.is_premium)));

      const me: User = {
        id: res.user_id,
        email: res.email,
        full_name: chosenName,
        role: isUserAdmin ? 'admin' : res.role,
        avatar_url: res.avatar_url,
        is_premium: isPaid,
        subscription_plan: isUserAdmin ? 'lifetime' : (analysis.plan || res.subscription_plan || undefined),
        subscription_valid_until: res.subscription_valid_until || (analysis.expiresAt ? new Date(analysis.expiresAt).toISOString() : null),
        days_remaining: isUserAdmin ? 9999 : analysis.daysRemaining,
        is_expired: !isPaid && !isUserAdmin && analysis.is_expired,
      };

      try {
        localStorage.setItem('employai_cached_user', JSON.stringify(me));
        localStorage.removeItem('employai_active_resume_analysis');
        localStorage.removeItem('employai_active_structured_resume');
        localStorage.removeItem('employai_selected_template');
        localStorage.removeItem('employai_resume_view_tab');
        localStorage.removeItem('employai_my_resumes');
      } catch {
        // ignore
      }

      setUser(me);
      await fetchRoleProfile(me);
      closeAuthModal();
      window.dispatchEvent(new CustomEvent('employai:user-switched', { detail: me }));
    } catch (err: any) {
      setError(err?.message || 'Login failed');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const resetPassword = async (email: string, newPassword: string) => {
    setError(null);
    setIsLoading(true);
    try {
      const res = await authApi.resetPassword({ email, new_password: newPassword });
      setToken(res.access_token);
      const isUserAdmin = res.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase();
      const me: User = {
        id: res.user_id,
        email: res.email,
        full_name: res.full_name,
        role: isUserAdmin ? 'admin' : res.role,
        avatar_url: res.avatar_url,
        is_premium: isUserAdmin || Boolean(res.is_premium),
      };
      try {
        localStorage.setItem('employai_cached_user', JSON.stringify(me));
      } catch {}
      setUser(me);
      await fetchRoleProfile(me);
      closeAuthModal();
      window.dispatchEvent(new CustomEvent('employai:user-switched', { detail: me }));
    } catch (err: any) {
      setError(err?.message || 'Password reset failed');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: {
    email: string;
    password: string;
    full_name: string;
    role: UserRole;
    institution_or_company?: string;
    department_or_domain?: string;
  }) => {
    setError(null);
    setIsLoading(true);
    try {
      const res = await authApi.register(data);
      setToken(res.access_token);

      const isUserAdmin = res.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase();

      const me: User = {
        id: res.user_id,
        email: res.email,
        full_name: res.full_name,
        role: isUserAdmin ? 'admin' : res.role,
        avatar_url: res.avatar_url,
        is_premium: isUserAdmin || Boolean(res.is_premium),
      };

      try {
        localStorage.setItem('employai_custom_username', res.full_name);
        localStorage.setItem('employai_cached_user', JSON.stringify(me));
        localStorage.removeItem('employai_active_resume_analysis');
        localStorage.removeItem('employai_active_structured_resume');
        localStorage.removeItem('employai_selected_template');
        localStorage.removeItem('employai_resume_view_tab');
        localStorage.removeItem('employai_my_resumes');
      } catch {
        // ignore
      }

      setUser(me);
      await fetchRoleProfile(me);
      closeAuthModal();
      window.dispatchEvent(new CustomEvent('employai:user-switched', { detail: me }));
    } catch (err: any) {
      setError(err?.message || 'Registration failed');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithGoogle = async (data: { email?: string; password?: string; full_name?: string; id_token?: string; avatar_url?: string; isRegister?: boolean; role?: UserRole }) => {
    setError(null);
    setIsLoading(true);
    try {
      const res = await authApi.googleAuth(data);
      setToken(res.access_token);

      const isUserAdmin = res.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase();
      const analysis = checkAndAnalyzeSubscriptionExpiry(res.email, res.subscription_valid_until);
      const isPaid = isUserAdmin || (!analysis.is_expired && (analysis.is_premium || Boolean(res.is_premium)));
      const chosenName = data.full_name?.trim() || res.full_name || (isUserAdmin ? 'Admin' : 'Student Scholar');

      const me: User = {
        id: res.user_id,
        email: res.email,
        full_name: chosenName,
        role: isUserAdmin ? 'admin' : res.role,
        avatar_url: res.avatar_url,
        is_premium: isPaid,
        subscription_plan: isUserAdmin ? 'lifetime' : (analysis.plan || res.subscription_plan || undefined),
        subscription_valid_until: res.subscription_valid_until || (analysis.expiresAt ? new Date(analysis.expiresAt).toISOString() : null),
        days_remaining: isUserAdmin ? 9999 : analysis.daysRemaining,
        is_expired: !isPaid && !isUserAdmin && analysis.is_expired,
      };

      try {
        localStorage.setItem('employai_custom_username', chosenName);
        localStorage.setItem('employai_cached_user', JSON.stringify(me));
      } catch {
        // ignore
      }

      setUser(me);
      await fetchRoleProfile(me);
      closeAuthModal();
      window.dispatchEvent(new CustomEvent('employai:user-switched', { detail: me }));
    } catch (err: any) {
      const rawMsg = err?.message || 'Authentication failed.';
      const isNotFound = rawMsg.toLowerCase().includes('no account') || rawMsg.toLowerCase().includes('no employ.ai account') || rawMsg.toLowerCase().includes('switch to');
      const isPwdErr = !isNotFound && (rawMsg.toLowerCase().includes('incorrect password') || (rawMsg.toLowerCase().includes('password') && !rawMsg.toLowerCase().includes('required') && !rawMsg.toLowerCase().includes('characters')));
      const errorMessage = isNotFound ? rawMsg : (isPwdErr ? 'incorrect password' : rawMsg);
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    authApi.logout();
    clearAuthToken();
    try {
      localStorage.removeItem('employai_custom_username');
      localStorage.removeItem('employai_cached_user');
      localStorage.removeItem('employai_my_resumes');
      localStorage.removeItem('employai_active_resume_analysis');
      localStorage.removeItem('employai_active_structured_resume');
      localStorage.removeItem('employai_selected_template');
      localStorage.removeItem('employai_resume_view_tab');
      Object.keys(localStorage).forEach(k => {
        if (k.startsWith('employai_learning_reviewed_') || k.startsWith('employai_cached_') || k.startsWith('employai_active_')) {
          localStorage.removeItem(k);
        }
      });
    } catch {
      // ignore
    }
    setUser(null);
    setToken(null);
    setStudentProfile(null);
    setAcademicProfile(null);
    setIndustryProfile(null);
    window.dispatchEvent(new CustomEvent('employai:resume-updated', { detail: null }));
    window.dispatchEvent(new CustomEvent('employai:user-switched', { detail: null }));
  };

  const isAdmin = Boolean(user?.email && user.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase());
  const isPremium = isAdmin || (Boolean(user?.is_premium) && !user?.is_expired);

  const activeRole: UserRole = user?.role === 'academia' ? 'academia' : 'student';

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        activeRole,
        isAuthenticated: !!user && !!token,
        isLoading,
        error,
        studentProfile,
        academicProfile,
        industryProfile,
        isPremium,
        isAdmin,
        checkSubscription,
        login,
        resetPassword,
        loginWithGoogle,
        register,
        logout,
        refreshUser,
        openAuthModal,
        closeAuthModal,
        clearError,
        isAuthModalOpen,
        authModalMode,
        authModalDefaultRole,
        isSubscriptionModalOpen,
        openSubscriptionModal,
        closeSubscriptionModal,
        isAdminPaymentsModalOpen,
        openAdminPaymentsModal,
        closeAdminPaymentsModal,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;
