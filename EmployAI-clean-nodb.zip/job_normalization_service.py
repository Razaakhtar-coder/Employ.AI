import re
import hashlib
import urllib.parse
from typing import List, Dict, Tuple, Optional
from app.schemas.job import RawJobPosting
from app.services.resume_parser_service import ResumeParserService


class JobNormalizationService:
    """
    Normalizes raw job postings from multiple providers:
    - Cross-provider deduplication via content hashing
    - High-precision NLP skill extraction reusing ResumeParserService.SKILL_TAXONOMY
    - Experience level tagging (intern, entry, mid, senior)
    - Domain taxonomy mapping
    """

    DOMAIN_KEYWORDS = {
        "Design & Creative Media": [
            "designer", "design", "graphic design", "social designer", "motion graphics", "video editing",
            "video editor", "after effects", "photoshop", "illustrator", "premiere pro", "figma", "canva",
            "capcut", "visual design", "ui/ux", "creative director", "art director", "social studio",
            "content creator", "storyboard", "brand identity", "typography", "3d animation", "product designer"
        ],
        "Finance & Commerce": [
            "finance", "accounting", "auditing", "taxation", "tally", "gst", "corporate finance",
            "equity research", "investment banking", "financial analyst", "accountant", "b.com", "m.com",
            "statutory audit", "chartered accountant", "wealth management", "credit analyst", "valuation"
        ],
        "Business Analytics": [
            "business analyst", "data analyst", "power bi", "tableau", "data analytics",
            "bi analyst", "product analyst", "sql analyst", "data visualization", "analytics consultant",
            "decision analytics", "data ops", "business intelligence"
        ],
        "Mechanical": [
            "mechanical", "solidworks", "ansys", "catia", "cad", "cam", "fea", "cfd",
            "hvac", "thermodynamics", "manufacturing engineer", "robotics", "mechatronics",
            "automotive engineer", "piping engineer", "powertrain", "mechanical design", "production engineer"
        ],
        "Civil": [
            "civil engineer", "structural engineer", "autocad civil", "revit", "staad", "bim",
            "site engineer", "construction management", "surveying", "geotechnical", "highway engineer",
            "quantity surveyor", "boq", "rcc design", "structural design", "water resources", "concrete"
        ],
        "Electrical": [
            "electrical", "electronics", "vlsi", "verilog", "vhdl", "embedded", "pcb",
            "microcontroller", "power systems", "firmware", "iot", "circuit design", "fpga",
            "hardware engineer", "embedded c", "instrumentation"
        ],
        "Management & Business": [
            "human resources", "talent acquisition", "recruiter", "marketing", "digital marketing",
            "seo", "sales executive", "operations manager", "supply chain", "business development",
            "strategy consultant", "management trainee", "product marketing", "brand manager", "operations trainee"
        ],
        "Law & Legal": [
            "legal", "lawyer", "advocate", "litigation", "corporate counsel", "compliance officer",
            "contract manager", "intellectual property", "patent analyst", "paralegal", "legal associate"
        ],
        "Healthcare & Medicine": [
            "pharmacy", "pharmacist", "clinical research", "medical officer", "nursing",
            "pharmacovigilance", "biomedical", "mbbs", "doctor", "physician", "patient care",
            "hospital administration", "icu nurse", "clinical trial", "health informatics"
        ],
        "Biotechnology & Life Sciences": [
            "biotechnology", "bioinformatics", "genomics", "bioprocess", "molecular biology",
            "microbiology", "cell culture", "biopharma", "genetic engineering", "crispr", "blast", "ngs"
        ],
        "Computer Science": [
            "software", "developer", "engineer", "full stack", "frontend", "backend", "python",
            "react", "javascript", "typescript", "java", "golang", "devops", "cloud", "aws",
            "machine learning", "ai", "data scientist", "mobile app", "flutter", "cybersecurity"
        ]
    }

    @classmethod
    def generate_dedup_key(cls, title: str, company: str, location: str, remote: bool) -> str:
        """Generates a canonical hash for deduplicating cross-provider job postings."""
        clean_title = re.sub(r"[^\w\s]", "", title.lower()).strip()
        clean_company = re.sub(r"[^\w\s]", "", company.lower()).strip()
        clean_loc = "remote" if remote else re.sub(r"[^\w\s]", "", location.lower()).strip()
        raw_key = f"{clean_company}::{clean_title}::{clean_loc}"
        return hashlib.md5(raw_key.encode("utf-8")).hexdigest()

    @classmethod
    def extract_required_skills(cls, description: str, raw_tags: Optional[List[str]] = None) -> List[str]:
        """
        Extracts clean, verified required skills from job description text and provider tags
        using the ResumeParserService canonical skill taxonomy.
        """
        extracted_set = set()
        text_lower = description.lower()

        # 1. Check existing provider tags against taxonomy
        if raw_tags:
            for tag in raw_tags:
                clean_tag = tag.strip().lower()
                for canonical_skill in ResumeParserService.SKILL_TAXONOMY:
                    if canonical_skill.lower() == clean_tag:
                        extracted_set.add(canonical_skill)

        # 2. Regex word-boundary extraction against full taxonomy
        for canonical_skill in ResumeParserService.SKILL_TAXONOMY:
            pattern = r"(?<![A-Za-z0-9])" + re.escape(canonical_skill.lower()) + r"(?![A-Za-z0-9])"
            if re.search(pattern, text_lower):
                extracted_set.add(canonical_skill)

        # 3. If zero extracted, fallback to reasonable domain core competencies
        if not extracted_set:
            if "design" in text_lower or "photoshop" in text_lower or "figma" in text_lower:
                extracted_set.update(["Visual Design", "Figma", "Design Systems"])
            elif "python" in text_lower or "react" in text_lower:
                extracted_set.update(["Python", "JavaScript", "REST API"])
            elif "finance" in text_lower or "accounting" in text_lower:
                extracted_set.update(["Financial Analysis", "Excel", "Accounting"])
            else:
                extracted_set.update(["Problem Solving", "Domain Fundamentals", "Communication"])

        return sorted(list(extracted_set))

    @classmethod
    def determine_experience_level(cls, title: str, description: str) -> str:
        """Categorizes role into intern, entry, mid, or senior."""
        combined = (title + " " + description[:600]).lower()
        if re.search(r"\b(intern|internship|trainee|fresher|graduate program|entry level|0-1 year|junior)\b", combined):
            return "intern" if "intern" in combined or "trainee" in combined else "entry"
        if re.search(r"\b(senior|lead|principal|staff|director|head of|vp|architect|5\+|6\+|7\+|8\+)\b", combined):
            return "senior"
        if re.search(r"\b(mid|intermediate|2-4 years|3\+ years|2\+ years)\b", combined):
            return "mid"
        return "entry"

    @classmethod
    def classify_domain(cls, title: str, description: str, skills: List[str]) -> str:
        """Classifies the job into a canonical EmployAI domain using word-boundary matching."""
        combined_text = (title + " " + " ".join(skills) + " " + description[:600]).lower()
        title_lower = title.lower()

        scores: Dict[str, int] = {}
        for domain, keywords in cls.DOMAIN_KEYWORDS.items():
            score = 0
            for kw in keywords:
                pattern = r"(?<![A-Za-z0-9])" + re.escape(kw.lower()) + r"(?![A-Za-z0-9])"
                if re.search(pattern, title_lower):
                    score += 4  # Strong weight for job title matches
                elif re.search(pattern, combined_text):
                    score += 1
            if score > 0:
                scores[domain] = score

        if scores:
            return max(scores, key=scores.get)

        return "Computer Science"

    @classmethod
    def sanitize_apply_url(cls, apply_url: str, company: str, title: str, source: str) -> str:
        """
        Sanitizes job apply URLs while strictly preserving verified direct job listing slugs and external career URLs.
        Only provides clean fallback portals if an apply_url is missing, empty, or a broken placeholder.
        Guarantees users land directly on the platform job portal and never on generic homepages or login walls.
        """
        clean_url = (apply_url or "").strip()
        clean_company = re.sub(r"\(via [^)]+\)", "", company).strip()
        clean_company = re.sub(r"\(YC [^)]+\)", "", clean_company).strip()
        clean_company = re.sub(r"LLP|Inc\.|Pvt\.? Ltd\.?", "", clean_company, flags=re.IGNORECASE).strip()
        clean_title = re.sub(r"[\(\)\[\]\-]", " ", title).strip()
        clean_title = re.sub(r"\s+", " ", clean_title).strip()
        src_clean = (source or "").lower()

        q_comp = urllib.parse.quote_plus(clean_company)
        q_role = urllib.parse.quote_plus(clean_title)
        q_all = urllib.parse.quote_plus(f"{clean_company} {clean_title}".strip())

        has_fake_suffix = bool(re.search(r"-\d{5,12}$", clean_url.split("?")[0]))
        is_bare_homepage = (
            clean_url in [
                "https://careerhound.io",
                "https://careerhound.io/",
                "https://app.otta.com/jobs",
                "https://www.instahyre.com",
                "https://www.instahyre.com/",
                "https://cutshort.io",
                "https://cutshort.io/",
                "https://remote.com",
                "https://remote.com/",
                "https://internshala.com",
                "https://internshala.com/",
            ]
            or "keywords-software-engineering-trainee" in clean_url
            or "remote-cloud-devops-site-reliability-engineer-jobs" in clean_url
            or "themuse.com/jobs?" in clean_url
            or clean_url.endswith("themuse.com/jobs")
            or clean_url.endswith("themuse.com/jobs/")
        )

        # Check if clean_url has mismatched platform (e.g. Otta job pointing to LinkedIn)
        has_platform_mismatch = (
            ("otta" in src_clean and "linkedin.com" in clean_url) or
            ("cutshort" in src_clean and "linkedin.com" in clean_url) or
            ("careerhound" in src_clean and "linkedin.com" in clean_url) or
            ("remote.com" in src_clean and "linkedin.com" in clean_url) or
            ("instahyre" in src_clean and ("naukri.com" in clean_url or "linkedin.com" in clean_url)) or
            ("findwork" in src_clean and "linkedin.com" in clean_url)
        )

        comp_slug = re.sub(r"[^a-z0-9]+", "-", clean_company.lower()).strip("-")
        title_slug = re.sub(r"[^a-z0-9]+", "-", clean_title.lower()).strip("-")

        if (
            clean_url
            and clean_url.startswith("http")
            and "employai.edu" not in clean_url
            and not has_fake_suffix
            and not is_bare_homepage
            and not has_platform_mismatch
            and (
                "/jobs/view/" in clean_url or
                "/viewjob" in clean_url or
                "/company/" in clean_url or
                "/job/" in clean_url or
                "/careers" in clean_url or
                (clean_url.startswith("https://www.themuse.com/jobs/") and len(clean_url.split("/")) >= 6) or
                "/jobs" in clean_url or
                "/internship/" in clean_url or
                any(
                    sub in clean_url
                    for sub in [
                        "?query=",
                        "?keywords=",
                        "?search=",
                        "?role=",
                        "?k=",
                        "?s=",
                        "?q=",
                        "internships/keywords-",
                        "internships/civil-internship",
                        "internships/mechanical-internship",
                        "internships/electronics-internship",
                        "jobs-in-india",
                    ]
                )
            )
        ):
            return clean_url

        # Direct verified platform portals where the job opening is actively searched/listed on THAT SAME PLATFORM
        if "linkedin" in src_clean:
            return f'https://www.linkedin.com/jobs/search/?keywords="{q_comp}"%20{q_role}'
        elif "naukri" in src_clean:
            return f"https://www.naukri.com/jobs-in-india?k={q_comp}%20{q_role}"
        elif "internshala" in src_clean:
            return f"https://internshala.com/internships/keywords-{comp_slug or title_slug or 'software'}/"
        elif "unstop" in src_clean:
            return f"https://unstop.com/jobs?search={q_comp or q_role}"
        elif "indeed" in src_clean:
            return f"https://in.indeed.com/jobs?q={q_comp}%20{q_role}"
        elif "yc" in src_clean or "work at a startup" in src_clean:
            return f"https://www.workatastartup.com/jobs?query={q_comp or q_role}"
        elif "wellfound" in src_clean:
            return f"https://wellfound.com/jobs?role={q_role}&keyword={q_comp}"
        elif "remotive" in src_clean:
            return f"https://remotive.com/?query={q_role}"
        elif "jobicy" in src_clean:
            return f"https://jobicy.com/jobs?s={q_role}"
        elif "weworkremotely" in src_clean:
            return f"https://weworkremotely.com/remote-jobs/search?term={q_role}"
        elif "himalayas" in src_clean:
            return f"https://himalayas.app/jobs?q={q_role}"
        elif "arbeitnow" in src_clean:
            return f"https://www.arbeitnow.com/jobs?search={q_role}"
        elif "remoteok" in src_clean:
            return f"https://remoteok.com/?search={q_role}"
        elif "muse" in src_clean:
            muse_q = f"{q_comp}%20{q_role}".strip("%20") if q_comp else q_role
            return f"https://www.themuse.com/search/jobs?q={muse_q}"
        elif "otta" in src_clean:
            return f"https://www.welcometothejungle.com/en/companies?query={q_comp or q_role}"
        elif "cutshort" in src_clean:
            return f"https://cutshort.io/jobs?query={q_comp or q_role}"
        elif "careerhound" in src_clean:
            return f"https://www.careerhound.io/search?q={q_comp or q_role}"
        elif "remote.com" in src_clean:
            return f"https://remote.com/jobs/all?query={q_comp or q_role}"
        elif "instahyre" in src_clean:
            return f"https://www.instahyre.com/jobs-in-india/?search={q_comp or q_role}"
        elif "findwork" in src_clean:
            return f"https://findwork.dev/?search={q_comp or q_role}"

        # EmployAI Partner Network or company career site
        return f"https://www.google.com/search?q={urllib.parse.quote_plus((clean_company + ' ' + clean_title + ' careers').strip())}"

    @classmethod
    def get_guaranteed_fallback_url(cls, company: str, title: str, source: str = "") -> str:
        """
        Generates a 100% reliable fallback URL for a job posting.
        Guarantees that candidates will never hit an HTTP 404 or dead end.
        """
        return cls.sanitize_apply_url("", company, title, source)

    @classmethod
    def normalize_posted_date(cls, raw_date: Optional[str]) -> str:
        """Converts raw timestamps or dates into clean relative indicators (e.g. 'Just now', 'Today', '2 days ago')."""
        if not raw_date or not str(raw_date).strip():
            return "Recently"
        d_str = str(raw_date).strip()

        # Check if unix timestamp number (e.g. 1791719708)
        if re.match(r"^\d{9,12}$", d_str):
            try:
                from datetime import datetime, timezone
                ts = int(d_str)
                dt = datetime.fromtimestamp(ts, timezone.utc)
                now = datetime.now(timezone.utc)
                diff = (now - dt).total_seconds()
                if diff < 3600 * 24:
                    return "Today"
                elif diff < 3600 * 48:
                    return "1 day ago"
                elif diff < 3600 * 24 * 7:
                    days = max(1, int(diff // (3600 * 24)))
                    return f"{days} days ago"
                elif diff < 3600 * 24 * 14:
                    return "1 week ago"
                return "Recently"
            except Exception:
                return "Recently"

        # Check if relative format already
        if any(w in d_str.lower() for w in ["just now", "today", "yesterday", "day ago", "days ago", "week ago", "weeks ago", "recently"]):
            return d_str

        # Check ISO format: YYYY-MM-DD
        iso_match = re.search(r"(\d{4})-(\d{2})-(\d{2})", d_str)
        if iso_match:
            try:
                from datetime import datetime, timezone
                y, m, d = int(iso_match.group(1)), int(iso_match.group(2)), int(iso_match.group(3))
                dt = datetime(y, m, d, tzinfo=timezone.utc)
                now = datetime.now(timezone.utc)
                diff_days = (now - dt).total_seconds() / 86400
                if diff_days < 1:
                    return "Today"
                elif diff_days < 2:
                    return "1 day ago"
                elif diff_days < 7:
                    return f"{int(diff_days)} days ago"
                elif diff_days < 14:
                    return "1 week ago"
                elif diff_days < 30:
                    return f"{max(1, int(diff_days // 7))} weeks ago"
                return "Recently"
            except Exception:
                return "Recently"

        return d_str

    @classmethod
    def normalize(cls, raw: RawJobPosting) -> Dict:
        """Converts a RawJobPosting into a normalized dictionary ready for DB storage and matching."""
        extracted_skills = cls.extract_required_skills(raw.description, raw.required_skills)
        exp_level = cls.determine_experience_level(raw.title, raw.description)
        domain = cls.classify_domain(raw.title, raw.description, extracted_skills)
        dedup_key = cls.generate_dedup_key(raw.title, raw.company, raw.location, raw.remote)
        safe_url = cls.sanitize_apply_url(raw.apply_url.strip(), raw.company, raw.title, raw.source)
        clean_date = cls.normalize_posted_date(raw.posted_date)

        return {
            "source_id": raw.source_id,
            "source": raw.source,
            "dedup_key": dedup_key,
            "title": raw.title.strip(),
            "company": raw.company.strip(),
            "location": raw.location.strip() or ("Remote" if raw.remote else "Global"),
            "remote": raw.remote,
            "job_type": raw.job_type,
            "experience_level": exp_level,
            "domain": domain,
            "description": raw.description.strip(),
            "required_skills_json": extracted_skills,
            "apply_url": safe_url,
            "salary_range": raw.salary_range,
            "posted_date": clean_date
        }
