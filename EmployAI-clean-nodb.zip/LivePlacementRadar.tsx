import React, { useState, useMemo, useEffect } from 'react';
import { DOMAIN_CO_DOMAINS, getCanonicalDomain } from '../utils/domainRoadmapData';
import { 
  Sparkles, TrendingUp, Zap, Search, ArrowRight, 
  Orbit, DollarSign, Briefcase, 
  Code, Scale, HeartPulse, BarChart3, Wrench, Building2, 
  Plane, Receipt, BookOpen, Layers, Bot, Dna, FlaskConical, Anchor
} from 'lucide-react';

interface LivePlacementRadarProps {
  onNavigate: (tab: string) => void;
  onNavigateToRoadmap?: (roleTitleOrId?: string, domain?: string) => void;
  userDomain?: string;
}

const STREAM_CONFIG: Record<string, { label: string; icon: React.ComponentType<{ size?: number; color?: string; style?: React.CSSProperties }>; color: string; salary: string; demand: string; hiringCompanies: string[] }> = {
  'Computer Science': {
    label: 'CS & Software',
    icon: Code,
    color: '#00f2fe',
    salary: '₹8.5 - ₹35.0 LPA',
    demand: '96% Hiring Surge',
    hiringCompanies: ['Google', 'Microsoft', 'Amazon', 'Meta', 'Uber']
  },
  'MBBS': {
    label: 'MBBS & Clinical',
    icon: HeartPulse,
    color: '#ef4444',
    salary: '₹10.0 - ₹36.0 LPA',
    demand: '98% Critical Demand',
    hiringCompanies: ['Apollo Health', 'Fortis', 'Max Healthcare', 'Medanta', 'AIIMS']
  },
  'Nursing': {
    label: 'Nursing & Care',
    icon: HeartPulse,
    color: '#06b6d4',
    salary: '₹5.5 - ₹20.0 LPA',
    demand: '97% High Priority',
    hiringCompanies: ['Apollo Hospitals', 'Fortis', 'NHS UK', 'Max Healthcare', 'Cleveland Clinic']
  },
  'Business Analytics': {
    label: 'Business Analytics',
    icon: BarChart3,
    color: '#38bdf8',
    salary: '₹8.0 - ₹28.0 LPA',
    demand: '94% Active Growth',
    hiringCompanies: ['McKinsey', 'Bain', 'BCG', 'Deloitte', 'Fractal AI']
  },
  'BCOM': {
    label: 'Commerce & Ind AS',
    icon: Receipt,
    color: '#10b981',
    salary: '₹6.5 - ₹24.0 LPA',
    demand: '92% Strong Demand',
    hiringCompanies: ['PwC', 'EY', 'KPMG', 'Deloitte', 'BDO India']
  },
  'BBA': {
    label: 'Management & Strategy',
    icon: Briefcase,
    color: '#ec4899',
    salary: '₹6.5 - ₹26.0 LPA',
    demand: '91% High Demand',
    hiringCompanies: ['Amazon PM', 'HUL', 'P&G', 'Accenture Strategy', 'Zomato']
  },
  'BA LLB': {
    label: 'Corporate Law',
    icon: Scale,
    color: '#f59e0b',
    salary: '₹9.0 - ₹32.0 LPA',
    demand: '89% Placement Index',
    hiringCompanies: ['AZB & Partners', 'Khaitan & Co', 'Shardul Amarchand', 'Trilegal', 'JSA']
  },
  'Aviation': {
    label: 'Aviation & Pilot',
    icon: Plane,
    color: '#06b6d4',
    salary: '₹14.0 - ₹45.0 LPA',
    demand: '96% Global Fleet Surge',
    hiringCompanies: ['IndiGo', 'Air India', 'Emirates', 'Qatar Airways', 'Singapore Airlines']
  },
  'Aeronautical': {
    label: 'Aeronautical Eng',
    icon: Plane,
    color: '#0ea5e9',
    salary: '₹7.5 - ₹28.0 LPA',
    demand: '94% Aerospace Growth',
    hiringCompanies: ['ISRO', 'DRDO', 'HAL', 'Boeing India', 'Airbus']
  },
  'Cabin Crew': {
    label: 'Cabin Crew',
    icon: Plane,
    color: '#f43f5e',
    salary: '₹6.0 - ₹22.0 LPA',
    demand: '95% Airline Surge',
    hiringCompanies: ['Emirates', 'Qatar Airways', 'Singapore Airlines', 'Air India', 'IndiGo']
  },
  'Robotics': {
    label: 'Robotics & Automation',
    icon: Bot,
    color: '#8b5cf6',
    salary: '₹8.0 - ₹32.0 LPA',
    demand: '93% Autonomous Surge',
    hiringCompanies: ['Boston Dynamics', 'GreyOrange', 'ABB Robotics', 'Fanuc', 'Tesla']
  },
  'Mechanical': {
    label: 'Mechanical & CAD',
    icon: Wrench,
    color: '#f97316',
    salary: '₹6.5 - ₹25.0 LPA',
    demand: '88% Core Hiring',
    hiringCompanies: ['Tata Motors', 'Mahindra', 'L&T', 'BOSCH', 'Siemens']
  },
  'Civil': {
    label: 'Civil & BIM',
    icon: Building2,
    color: '#eab308',
    salary: '₹6.0 - ₹24.0 LPA',
    demand: '87% Infrastructure Growth',
    hiringCompanies: ['L&T Construction', 'Shapoorji Pallonji', 'Tata Projects', 'AECOM', 'AFCONS']
  },
  'Electrical': {
    label: 'Electrical & VLSI',
    icon: Zap,
    color: '#14b8a6',
    salary: '₹7.5 - ₹30.0 LPA',
    demand: '93% Semiconductor Surge',
    hiringCompanies: ['Texas Instruments', 'Qualcomm', 'Intel', 'NVIDIA', 'Schneider Electric']
  },
  'Chemical': {
    label: 'Chemical Process',
    icon: FlaskConical,
    color: '#84cc16',
    salary: '₹6.5 - ₹26.0 LPA',
    demand: '86% Industrial Growth',
    hiringCompanies: ['Reliance Industries', 'Tata Chemicals', 'IOCL', 'BPCL', 'Dow Chemical']
  },
  'Biotechnology': {
    label: 'Biotechnology',
    icon: Dna,
    color: '#a855f7',
    salary: '₹6.0 - ₹24.0 LPA',
    demand: '90% Biopharma Surge',
    hiringCompanies: ['Biocon', 'Serum Institute', "Dr. Reddy's", 'Bharat Biotech', 'Thermo Fisher']
  },
  'Marine': {
    label: 'Marine Engineering',
    icon: Anchor,
    color: '#0284c7',
    salary: '₹9.0 - ₹38.0 LPA',
    demand: '91% Merchant Marine',
    hiringCompanies: ['Maersk Line', 'Anglo-Eastern', 'Fleet Management', 'MSC', 'V.Group']
  },
  'BA Hons': {
    label: 'Humanities & Policy',
    icon: BookOpen,
    color: '#a855f7',
    salary: '₹5.5 - ₹22.0 LPA',
    demand: '85% Policy Engagement',
    hiringCompanies: ['NITI Aayog', 'ORF Think Tank', 'World Bank', 'Edelman', 'UNDP']
  }
};

const LivePlacementRadarComponent: React.FC<LivePlacementRadarProps> = ({
  onNavigate,
  onNavigateToRoadmap,
  userDomain
}) => {
  // Determine initial stream based on user domain or directly from user's active resume
  const defaultStream = useMemo(() => {
    let domainToResolve = userDomain;
    if (!domainToResolve || domainToResolve.toLowerCase() === 'computer science' || domainToResolve.toLowerCase() === 'computer science & engineering') {
      try {
        const userStr = localStorage.getItem('employai_auth_user');
        const userId = userStr ? JSON.parse(userStr)?.id : null;
        const key = userId ? `employai_active_resume_analysis_${userId}` : 'employai_active_resume_analysis';
        const raw = localStorage.getItem(key) || localStorage.getItem('employai_active_resume_analysis');
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed?.detected_domain && typeof parsed.detected_domain === 'string' && parsed.detected_domain.trim()) {
            domainToResolve = parsed.detected_domain.trim();
          } else if (parsed?.structured_resume?.education?.[0]?.field_of_study?.trim()) {
            domainToResolve = parsed.structured_resume.education[0].field_of_study.trim();
          }
        }
      } catch {}
    }

    if (!domainToResolve) return 'Computer Science';
    const canonical = getCanonicalDomain(domainToResolve);
    if (STREAM_CONFIG[canonical]) return canonical;
    return 'Computer Science';
  }, [userDomain]);

  const [selectedStream, setSelectedStream] = useState<string>(defaultStream);

  // Synchronize stream whenever userDomain or defaultStream updates from resume
  useEffect(() => {
    if (defaultStream && STREAM_CONFIG[defaultStream]) {
      setSelectedStream(defaultStream);
    }
  }, [defaultStream]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');

  const streamInfo = STREAM_CONFIG[selectedStream] || STREAM_CONFIG['Computer Science'];

  // Co-domains for this stream (guaranteed no accidental fallback to Computer Science)
  const rawCoDomains = useMemo(() => {
    const canonical = getCanonicalDomain(selectedStream);
    return DOMAIN_CO_DOMAINS[canonical] || DOMAIN_CO_DOMAINS[selectedStream] || DOMAIN_CO_DOMAINS['Computer Science'] || [];
  }, [selectedStream]);

  // Unique categories for filtering
  const categories = useMemo(() => {
    const cats = new Set<string>();
    rawCoDomains.forEach(c => cats.add(c.category));
    return Array.from(cats);
  }, [rawCoDomains]);

  // Filtered co-domains
  const filteredCoDomains = useMemo(() => {
    let list = rawCoDomains;
    if (activeCategoryFilter !== 'all') {
      list = list.filter(c => c.category === activeCategoryFilter);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(c => 
        c.name.toLowerCase().includes(q) || 
        c.category.toLowerCase().includes(q) ||
        c.short_description.toLowerCase().includes(q)
      );
    }
    return list;
  }, [rawCoDomains, activeCategoryFilter, searchQuery]);

  const handleLaunchRoadmap = (coDomainName: string) => {
    const canonical = getCanonicalDomain(selectedStream);
    if (onNavigateToRoadmap) {
      onNavigateToRoadmap(coDomainName, canonical);
    } else {
      onNavigate('roadmap');
    }
  };

  return (
    <div 
      className="glass-card" 
      style={{ 
        padding: '1.25rem 1.4rem', 
        display: 'flex', 
        flexDirection: 'column', 
        gap: '1rem',
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      {/* Top Header Row */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.55rem' }}>
          <div style={{
            width: '32px',
            height: '32px',
            borderRadius: '8px',
            background: `${streamInfo.color}1f`,
            border: `1px solid ${streamInfo.color}40`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: `0 0 14px ${streamInfo.color}26`
          }}>
            <Zap size={17} color={streamInfo.color} />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-primary)', margin: 0 }}>
                Live Placement Radar
              </h3>
              <span className="badge badge-cyan" style={{ fontSize: '0.62rem', padding: '0.15rem 0.45rem' }}>
                <Sparkles size={10} /> 5-Tier Roadmaps
              </span>
            </div>
            <p style={{ fontSize: '0.73rem', color: 'var(--text-muted)', margin: 0 }}>
              Direct Beginner to Internship & Placement roadmaps for all industry co-domains
            </p>
          </div>
        </div>

        <button 
          onClick={() => onNavigate('galaxy')} 
          className="btn btn-secondary btn-sm" 
          title="Open interactive 3D Constellation"
          style={{ fontSize: '0.72rem', padding: '0.3rem 0.65rem', display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}
        >
          <Orbit size={13} color="var(--accent-cyan)" />
          <span>3D Galaxy View</span>
          <ArrowRight size={12} />
        </button>
      </div>

      {/* Stream Tabs Bar (Responsive horizontal scroll) */}
      <div style={{ 
        display: 'flex', 
        gap: '0.45rem', 
        overflowX: 'auto', 
        paddingBottom: '0.35rem',
        scrollbarWidth: 'thin'
      }}>
        {Object.entries(STREAM_CONFIG).map(([key, config]) => {
          const IconComp = config.icon;
          const isSelected = selectedStream === key;
          return (
            <button
              key={key}
              onClick={() => {
                setSelectedStream(key);
                setActiveCategoryFilter('all');
                setSearchQuery('');
              }}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.35rem',
                padding: '0.38rem 0.75rem',
                borderRadius: '8px',
                fontSize: '0.74rem',
                fontWeight: isSelected ? 700 : 500,
                cursor: 'pointer',
                whiteSpace: 'nowrap',
                transition: 'all 0.15s ease',
                border: isSelected ? `1px solid ${config.color}` : '1px solid var(--border-subtle)',
                background: isSelected ? `${config.color}1a` : 'var(--bg-tertiary)',
                color: isSelected ? config.color : 'var(--text-secondary)',
                boxShadow: isSelected ? `0 0 12px ${config.color}26` : 'none'
              }}
            >
              <IconComp size={13} color={isSelected ? config.color : 'var(--text-muted)'} />
              <span>{config.label}</span>
            </button>
          );
        })}
      </div>

      {/* Selected Stream Telemetry Banner */}
      <div style={{
        padding: '0.75rem 0.95rem',
        background: 'var(--bg-tertiary)',
        border: '1px solid var(--border-subtle)',
        borderRadius: '10px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '0.6rem'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.74rem' }}>
            <DollarSign size={13} color="#10b981" />
            <span style={{ color: 'var(--text-muted)' }}>Placement Benchmark:</span>
            <strong style={{ color: '#10b981', fontWeight: 700 }}>{streamInfo.salary}</strong>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.74rem' }}>
            <TrendingUp size={13} color={streamInfo.color} />
            <span style={{ color: 'var(--text-muted)' }}>Market Index:</span>
            <strong style={{ color: 'var(--text-primary)', fontWeight: 700 }}>{streamInfo.demand}</strong>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.7rem', color: 'var(--text-muted)' }}>
          <Briefcase size={12} />
          <span>Top Hiring: </span>
          <span style={{ color: 'var(--text-secondary)', fontWeight: 600 }}>
            {streamInfo.hiringCompanies.slice(0, 3).join(', ')}
          </span>
        </div>
      </div>

      {/* Search & Category Filter */}
      <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: '1 1 200px' }}>
          <Search size={13} color="var(--text-muted)" style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)' }} />
          <input
            type="text"
            placeholder={`Search ${selectedStream} co-domains (e.g., React, DSA, Ind AS, Radiology)...`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              width: '100%',
              padding: '0.4rem 0.65rem 0.4rem 2rem',
              fontSize: '0.75rem',
              borderRadius: '7px',
              border: '1px solid var(--border-subtle)',
              background: 'var(--bg-secondary)',
              color: 'var(--text-primary)',
              outline: 'none'
            }}
          />
        </div>

        {categories.length > 1 && (
          <select
            value={activeCategoryFilter}
            onChange={(e) => setActiveCategoryFilter(e.target.value)}
            style={{
              padding: '0.38rem 0.65rem',
              fontSize: '0.73rem',
              borderRadius: '7px',
              border: '1px solid var(--border-subtle)',
              background: 'var(--bg-secondary)',
              color: 'var(--text-primary)',
              outline: 'none',
              cursor: 'pointer'
            }}
          >
            <option value="all">All Disciplines ({rawCoDomains.length})</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        )}
      </div>

      {/* Responsive Co-Domains Cards Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
        gap: '0.65rem',
        maxHeight: '340px',
        overflowY: 'auto',
        paddingRight: '0.25rem',
        scrollbarWidth: 'thin'
      }}>
        {filteredCoDomains.slice(0, 12).map((item) => (
          <div
            key={item.id}
            onClick={() => handleLaunchRoadmap(item.name)}
            style={{
              padding: '0.75rem 0.85rem',
              borderRadius: '9px',
              background: 'var(--bg-secondary)',
              border: '1px solid var(--border-subtle)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              gap: '0.5rem',
              cursor: 'pointer',
              transition: 'all 0.18s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = streamInfo.color;
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = `0 4px 16px ${streamInfo.color}26`;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = 'var(--border-subtle)';
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.3rem', marginBottom: '0.35rem' }}>
                <span style={{ 
                  fontSize: '0.63rem', 
                  fontWeight: 700, 
                  color: streamInfo.color, 
                  background: `${streamInfo.color}17`,
                  padding: '0.15rem 0.45rem',
                  borderRadius: '4px',
                  textTransform: 'uppercase'
                }}>
                  {item.category}
                </span>

                <span style={{ 
                  fontSize: '0.62rem', 
                  fontWeight: 600, 
                  color: item.difficulty === 'Advanced' ? '#f43f5e' : item.difficulty === 'Intermediate' ? '#38bdf8' : '#10b981'
                }}>
                  {item.difficulty}
                </span>
              </div>

              <h4 style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-primary)', margin: 0, lineHeight: 1.3 }}>
                {item.name}
              </h4>

              <p style={{ 
                fontSize: '0.7rem', 
                color: 'var(--text-muted)', 
                margin: '0.3rem 0 0', 
                lineHeight: 1.35,
                display: '-webkit-box',
                WebkitLineClamp: 2,
                WebkitBoxOrient: 'vertical',
                overflow: 'hidden'
              }}>
                {item.short_description}
              </p>
            </div>

            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'space-between', 
              paddingTop: '0.45rem', 
              borderTop: '1px solid var(--border-subtle)',
              fontSize: '0.7rem'
            }}>
              <span style={{ color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                <Layers size={11} color="var(--accent-cyan)" />
                5 Placement Tiers
              </span>
              <span style={{ 
                color: streamInfo.color, 
                fontWeight: 700, 
                display: 'inline-flex', 
                alignItems: 'center', 
                gap: '0.2rem' 
              }}>
                Launch Roadmap <ArrowRight size={11} />
              </span>
            </div>
          </div>
        ))}
      </div>

      {filteredCoDomains.length === 0 && (
        <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.8rem' }}>
          No co-domains matching &quot;{searchQuery}&quot; in {selectedStream}. Try clearing your search filter.
        </div>
      )}

      {/* Footer Quick Action Bar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '0.5rem',
        paddingTop: '0.5rem',
        borderTop: '1px solid var(--border-subtle)',
        fontSize: '0.72rem'
      }}>
        <span style={{ color: 'var(--text-muted)' }}>
          Showing <strong>{filteredCoDomains.length}</strong> verified placement co-domains in <strong>{selectedStream}</strong>
        </span>

        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button
            onClick={() => onNavigate('roadmap')}
            className="btn btn-outline-cyan btn-sm"
            style={{ fontSize: '0.72rem', padding: '0.25rem 0.65rem' }}
          >
            Explore Master Hub →
          </button>
        </div>
      </div>
    </div>
  );
};

export const LivePlacementRadar = React.memo(LivePlacementRadarComponent);
