from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class InterviewStartRequest(BaseModel):
    target_role: Optional[str] = Field(default=None, description="Target job title or role")
    interview_type: Optional[str] = Field(default="comprehensive", description="technical | behavioral_star | project_deepdive | comprehensive")
    difficulty: Optional[str] = Field(default="intermediate", description="beginner | intermediate | advanced")
    num_questions: Optional[int] = Field(default=5, ge=3, le=10, description="Number of questions (3 to 10)")
    resume_text: Optional[str] = Field(default=None, description="Optional raw resume text override")
    document_id: Optional[str] = Field(default=None, description="Optional document ID to ground interview on")
    previous_questions: Optional[List[str]] = Field(default_factory=list, description="Questions previously asked to candidate to prevent duplicates across multiple mock interviews")


class StarBreakdown(BaseModel):
    situation: Optional[str] = Field(default=None, description="Context or problem setup")
    task: Optional[str] = Field(default=None, description="Role responsibility or objective")
    action: Optional[str] = Field(default=None, description="Concrete technical actions taken")
    result: Optional[str] = Field(default=None, description="Measurable outcomes or impact")


class InterviewQuestionItem(BaseModel):
    id: str
    index: int
    question: str
    category: str  # technical, project_deepdive, behavioral_star, system_design, core_fundamentals
    resume_reference: Optional[str] = None  # e.g. "Project: Realtime Chat Application" or "Skill: Docker & Kubernetes"
    context_hint: Optional[str] = None
    ideal_answer_points: Optional[List[str]] = Field(default_factory=list)
    user_answer: Optional[str] = None
    score: Optional[float] = None  # 0 to 100
    feedback: Optional[str] = None
    strengths: Optional[List[str]] = Field(default_factory=list)
    improvements: Optional[List[str]] = Field(default_factory=list)
    star_breakdown: Optional[Dict[str, Any]] = None
    model_answer_snippet: Optional[str] = None


class SubmitAnswerRequest(BaseModel):
    question_id: str
    user_answer: str = Field(..., min_length=2, description="Candidate's spoken or typed answer")
    audio_duration_seconds: Optional[int] = 0


class QuestionEvaluationResponse(BaseModel):
    question_id: str
    score: float  # 0 to 100
    is_correct: Optional[bool] = True
    verdict: Optional[str] = "Evaluated"
    feedback: str
    strengths: List[str] = Field(default_factory=list)
    improvements: List[str] = Field(default_factory=list)
    star_breakdown: Optional[Dict[str, Any]] = None
    model_answer_snippet: Optional[str] = None


class InterviewCompleteRequest(BaseModel):
    duration_seconds: Optional[int] = 0


class InterviewSessionResponse(BaseModel):
    id: str
    user_id: Optional[str] = None
    student_profile_id: Optional[str] = None
    target_role: str
    interview_type: str
    difficulty: str
    total_questions: int
    status: str
    overall_score: Optional[float] = 0.0
    technical_score: Optional[float] = None
    communication_score: Optional[float] = None
    star_method_score: Optional[float] = None
    problem_solving_score: Optional[float] = None
    resume_authenticity_score: Optional[float] = None
    readiness_level: Optional[str] = "Developing"
    summary_verdict: Optional[str] = None
    strengths: List[str] = Field(default_factory=list)
    improvements: List[str] = Field(default_factory=list)
    key_takeaways: Optional[List[str]] = Field(default_factory=list)
    questions: List[InterviewQuestionItem] = Field(default_factory=list)
    resume_snapshot: Optional[Dict[str, Any]] = None
    duration_seconds: int = 0
    created_at: datetime
    completed_at: Optional[datetime] = None



class InterviewScoreHistoryItem(BaseModel):
    id: str
    target_role: str
    interview_type: str
    difficulty: str
    overall_score: float
    technical_score: Optional[float] = None
    communication_score: Optional[float] = None
    star_method_score: Optional[float] = None
    readiness_level: Optional[str] = "Developing"
    total_questions: int
    duration_seconds: int
    created_at: datetime
    completed_at: Optional[datetime] = None
    strengths_count: int = 0
    improvements_count: int = 0


class InterviewHistoryResponse(BaseModel):
    history: List[InterviewScoreHistoryItem] = Field(default_factory=list)
    total_interviews: int = 0
    average_score: float = 0.0
    highest_score: float = 0.0
    score_trend: List[Dict[str, Any]] = Field(default_factory=list)
    category_averages: Dict[str, float] = Field(default_factory=dict)
