import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import json
from app.services.interview_service import InterviewService

def run_tests():
    print("================================================================")
    print("TEST 1: Verify mode-specific diverse question generation")
    print("================================================================")

    sample_facts = {
        "has_resume": True,
        "skills": ["FastAPI", "React", "PostgreSQL", "Redis", "Docker", "Kubernetes"],
        "projects": [
            {
                "title": "Realtime AI Collaboration Hub",
                "key_technologies": ["React", "FastAPI", "Redis", "WebSockets"],
                "description": "Built low-latency real-time collaboration canvas supporting 5k concurrent users."
            },
            {
                "title": "Distributed Financial Ledger",
                "key_technologies": ["PostgreSQL", "Docker", "Kafka"],
                "description": "Engineered ACID-compliant ledger service with idempotent transactions."
            }
        ],
        "experience": [
            {
                "company_or_org": "Stripe",
                "role": "Software Engineering Intern",
                "highlights": ["Reduced API endpoint latency by 35% using Redis caching."]
            }
        ],
        "domain": "Full Stack Engineering"
    }

    # 1. Test Project Deep-Dive Mode
    proj_qs = InterviewService.generate_interview_questions(
        facts=sample_facts,
        target_role="Full Stack Engineer",
        interview_type="project_deepdive",
        difficulty="intermediate",
        num_questions=4
    )
    print(f"\n[Project Deep-Dive Mode] Generated {len(proj_qs)} questions:")
    for q in proj_qs:
        print(f"  • Category: {q['category']} | Ref: {q['resume_reference']}")
        assert q['category'] == 'project_deepdive', f"Expected project_deepdive but got {q['category']}"
        assert "Realtime AI Collaboration Hub" in q['question'] or "Distributed Financial Ledger" in q['question']

    # 2. Test Technical Theory Mode
    tech_qs = InterviewService.generate_interview_questions(
        facts=sample_facts,
        target_role="Full Stack Engineer",
        interview_type="technical",
        difficulty="hard",
        num_questions=4
    )
    print(f"\n[Technical Theory Mode] Generated {len(tech_qs)} questions:")
    for q in tech_qs:
        print(f"  • Category: {q['category']} | Ref: {q['resume_reference']}")
        assert q['category'] == 'technical', f"Expected technical but got {q['category']}"

    # 3. Test Comprehensive Mode
    comp_qs = InterviewService.generate_interview_questions(
        facts=sample_facts,
        target_role="Full Stack Engineer",
        interview_type="comprehensive",
        difficulty="intermediate",
        num_questions=5
    )
    print(f"\n[Comprehensive Mode] Generated {len(comp_qs)} questions:")
    categories = [q['category'] for q in comp_qs]
    assert len(set(categories)) >= 3, "Expected diverse category mix in comprehensive mode"

    print("\n================================================================")
    print("TEST 2: Verify Accuracy-Based Answer Evaluation (No Word Count Bias)")
    print("================================================================")

    technical_q = [q for q in tech_qs if "fastapi" in q['question'].lower() or "skill: fastapi" in q.get('resume_reference', '').lower()][0] if any("fastapi" in q['question'].lower() for q in tech_qs) else tech_qs[0]
    print(f"Evaluating Question: {technical_q['question']}")

    # A. Concise, highly accurate direct answer (Only ~25 words)
    concise_accurate = "I manage concurrency in FastAPI by leveraging Python async/await syntax with asyncio event loops, and optimize performance by using Redis caching and connection pooling."
    eval_concise = InterviewService.evaluate_answer(technical_q, concise_accurate)
    print("\nA. Concise Accurate Answer Evaluation:")
    print(f"   Score: {eval_concise['score']}/100 | Verdict: {eval_concise['verdict']} | Is Correct: {eval_concise['is_correct']}")
    assert eval_concise['score'] >= 60.0, f"Expected concise accurate answer to score >= 60, got {eval_concise['score']}"
    assert eval_concise['is_correct'] is True

    # B. Verbose generic fluff that misses the question (70+ words)
    verbose_fluff = "Well in my career as a developer I have always worked very hard every single day with many tools and great team spirit to achieve all the goals given by management and I always follow best practices and strive for high quality standards across every single line of code that I produce."
    eval_fluff = InterviewService.evaluate_answer(technical_q, verbose_fluff)
    print("\nB. Verbose Fluff Answer Evaluation:")
    print(f"   Score: {eval_fluff['score']}/100 | Verdict: {eval_fluff['verdict']} | Is Correct: {eval_fluff['is_correct']}")
    assert eval_fluff['score'] <= 35.0, f"Expected verbose fluff to score <= 35, got {eval_fluff['score']}"

    # C. Trivial non-answer
    trivial_ans = "i did it"
    eval_trivial = InterviewService.evaluate_answer(technical_q, trivial_ans)
    print("\nC. Trivial Non-Answer Evaluation:")
    print(f"   Score: {eval_trivial['score']}/100 | Verdict: {eval_trivial['verdict']} | Is Correct: {eval_trivial['is_correct']}")
    assert eval_trivial['score'] == 0.0
    assert eval_trivial['is_correct'] is False

    print("\n================================================================")
    print(">>> ALL MOCK FIX VERIFICATION TESTS PASSED SUCCESSFULLY (100%) <<<")
    print("================================================================")

if __name__ == '__main__':
    run_tests()
