import re
import html
from typing import List, Optional
import httpx
from app.services.job_providers.base import JobProviderAdapter
from app.schemas.job import RawJobPosting


class RemotiveProvider(JobProviderAdapter):
    """
    Remotive Open API Adapter.
    Pulls high-quality worldwide remote job postings across Software, Design,
    Marketing, Sales, Product, Business, Finance, and DevOps.
    """

    API_URL = "https://remotive.com/api/remote-jobs"

    @property
    def name(self) -> str:
        return "Remotive"

    def _strip_html(self, raw_html: str) -> str:
        if not raw_html:
            return ""
        clean = re.sub(r"<[^>]+>", " ", raw_html)
        clean = html.unescape(clean)
        return re.sub(r"\s+", " ", clean).strip()

    async def fetch_jobs(
        self,
        query: Optional[str] = None,
        location: Optional[str] = None,
        remote: Optional[bool] = None,
        job_type: Optional[str] = None,
        page: int = 1
    ) -> List[RawJobPosting]:
        postings: List[RawJobPosting] = []
        try:
            params = {"limit": 50}
            if query:
                params["search"] = query

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) EmployAI/1.0",
                "Accept": "application/json"
            }

            async with httpx.AsyncClient(timeout=12.0, follow_redirects=True) as client:
                response = await client.get(self.API_URL, params=params, headers=headers)
                if response.status_code != 200:
                    print(f"[WARN] Remotive API returned status {response.status_code}")
                    return []

                payload = response.json()
                jobs = payload.get("jobs", [])

                for item in jobs:
                    raw_title = item.get("title", "")
                    raw_desc = self._strip_html(item.get("description", ""))
                    company_name = item.get("company_name", "Global Tech Company")
                    tags = item.get("tags") or []
                    category = item.get("category", "")
                    if category and category not in tags:
                        tags.append(category)

                    raw_type = (item.get("job_type") or "full-time").lower()
                    mapped_type = "full-time"
                    if "intern" in raw_type or "intern" in raw_title.lower():
                        mapped_type = "internship"
                    elif "part" in raw_type or "part" in raw_title.lower():
                        mapped_type = "part-time"
                    elif "contract" in raw_type or "freelance" in raw_type:
                        mapped_type = "contract"

                    exp_level = "entry"
                    title_desc = (raw_title + " " + raw_desc[:400]).lower()
                    if re.search(r"\b(intern|internship|trainee|fresher|graduate program|junior)\b", title_desc):
                        exp_level = "intern" if "intern" in title_desc or "trainee" in title_desc else "entry"
                    elif re.search(r"\b(senior|lead|principal|staff|director|head of|vp|architect|5\+|6\+)\b", title_desc):
                        exp_level = "senior"
                    elif re.search(r"\b(mid|intermediate|2-4 years|3\+ years)\b", title_desc):
                        exp_level = "mid"

                    loc = item.get("candidate_required_location") or "Worldwide (Remote)"

                    postings.append(RawJobPosting(
                        source_id=f"remotive-{item.get('id', item.get('url', 'job'))}",
                        source="Remotive",
                        title=raw_title,
                        company=company_name,
                        location=loc,
                        remote=True,
                        job_type=mapped_type,
                        experience_level=exp_level,
                        description=raw_desc,
                        required_skills=tags,
                        apply_url=item.get("url") or "https://remotive.com",
                        salary_range=item.get("salary") or None,
                        posted_date=str(item.get("publication_date") or "Recently")
                    ))
        except Exception as e:
            print(f"[ERROR] Remotive fetch_jobs failed: {e}")

        return postings
