import React from 'react';
import type { JobPosting, JobExplainResult } from '../types';
import { 
  X, CheckCircle2, AlertTriangle, 
  ExternalLink, Sparkles, Target, Zap,
  FileText, ShieldCheck, ArrowRight, Award
} from 'lucide-react';

interface JobExplainModalProps {
  job: JobPosting | null;
  jobExplanation: JobExplainResult | null;
  isLoading: boolean;
  onClose: () => void;
  applyUrl?: string;
  onNavigate?: (tab: string) => void;
}

export const JobExplainModal: React.FC<JobExplainModalProps> = ({
  job,
  jobExplanation,
  isLoading,
  onClose,
  applyUrl,
  onNavigate
}) => {
  if (!job && !jobExplanation) return null;

  const score = Math.round(
    typeof jobExplanation?.match_score === 'number'
      ? jobExplanation.match_score
      : typeof job?.match_score === 'number'
        ? job.match_score
        : 0
  );

  const isHighFit = score >= 85;
  const isGoodFit = score >= 65 && score < 85;

  const scoreColor = isHighFit 
    ? 'var(--accent-emerald, #10b981)' 
    : isGoodFit 
      ? 'var(--accent-cyan, #0284c7)' 
      : 'var(--accent-amber, #f59e0b)';

  const title = jobExplanation?.title || job?.title || 'Job Opening';
  const company = jobExplanation?.company || job?.company || '';
  const source = jobExplanation?.source || job?.source || 'Partner Gateway';
  const domain = jobExplanation?.domain_assessment || job?.domain || 'Target Discipline';
  const targetApplyUrl = applyUrl || job?.apply_url || '#';

  // Safely extract matched skills from explanation or job
  const matchedSkills: Array<{ skill_name: string }> = (jobExplanation?.matched_skills && jobExplanation.matched_skills.length > 0)
    ? jobExplanation.matched_skills.map(s => (typeof s === 'string' ? { skill_name: s } : { skill_name: s?.skill_name || (s as any)?.name || '' })).filter(s => !!s.skill_name)
    : (job?.matched_skills || []).map(s => ({ skill_name: typeof s === 'string' ? s : (s as any)?.skill_name || '' })).filter(s => !!s.skill_name);

  // Safely extract missing skills from explanation or derive from required_skills
  const missingSkills: Array<{ skill_name: string; recommendation?: string | null }> = (jobExplanation?.missing_skills && jobExplanation.missing_skills.length > 0)
    ? jobExplanation.missing_skills.map(s => (typeof s === 'string' ? { skill_name: s, recommendation: null } : { skill_name: s?.skill_name || '', recommendation: s?.recommendation || null })).filter(s => !!s.skill_name)
    : (job?.required_skills || [])
        .filter(rs => !matchedSkills.some(ms => ms.skill_name.toLowerCase() === rs.toLowerCase()))
        .map(s => ({ skill_name: s, recommendation: `Add portfolio deliverables or coursework for ${s}.` }));

  const totalSkillsCount = matchedSkills.length + missingSkills.length;

  // Breakdown scores with safe fallbacks
  const breakdown = jobExplanation?.breakdown || {
    skill_overlap_score: Math.min(100, Math.round((matchedSkills.length / Math.max(1, totalSkillsCount || 1)) * 100)),
    experience_fit_score: 90,
    domain_fit_score: 100,
    ats_readiness_score: 87,
    overall_match: score
  };

  // Why matches list
  const whyMatches: string[] = (jobExplanation?.why_matches && jobExplanation.why_matches.length > 0)
    ? jobExplanation.why_matches
    : [
        matchedSkills.length > 0
          ? `Verified proficiency in ${matchedSkills.length} required skill${matchedSkills.length > 1 ? 's' : ''}: ${matchedSkills.slice(0, 4).map(m => m.skill_name).join(', ')}.`
          : 'Foundational baseline alignment with role criteria.',
        `Disciplinary alignment with ${domain}.`,
        `Experience level targeted for ${jobExplanation?.experience_assessment || job?.experience_level || 'entry-level graduates'}.`
      ];

  // Action plan list
  const actionPlan: string[] = (jobExplanation?.recommended_action_plan && jobExplanation.recommended_action_plan.length > 0)
    ? jobExplanation.recommended_action_plan
    : missingSkills.length > 0
      ? missingSkills.slice(0, 3).map(ms => `Add verified portfolio deliverables or certifications for '${ms.skill_name}'.`)
      : ['Your resume demonstrates solid coverage for this opening. Review your summary statement before applying.'];

  // Summary text
  const summaryText = jobExplanation?.summary || 
    `Candidate exhibits a ${score}% compatibility match for '${title}'. Based on your active resume analysis, you demonstrate strong alignment across core criteria.`;

  return (
    <div 
      onClick={onClose} 
      style={{ 
        position: 'fixed',
        inset: 0,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        width: '100vw',
        height: '100vh',
        backgroundColor: 'var(--modal-backdrop, rgba(15, 23, 42, 0.65))',
        backdropFilter: 'blur(8px)',
        WebkitBackdropFilter: 'blur(8px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 99999,
        padding: '1.25rem',
        boxSizing: 'border-box'
      }}
    >
      <div 
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '95%',
          maxWidth: '780px',
          maxHeight: '90vh',
          display: 'flex',
          flexDirection: 'column',
          background: 'var(--bg-modal, #ffffff)',
          color: 'var(--text-primary, #090d16)',
          border: '1.5px solid var(--border-glass, rgba(2, 132, 199, 0.25))',
          boxShadow: 'var(--shadow-modal, 0 25px 60px -15px rgba(15, 23, 42, 0.25))',
          borderRadius: '18px',
          boxSizing: 'border-box',
          position: 'relative',
          overflow: 'hidden'
        }}
      >
        {/* Modal Header */}
        <div style={{
          padding: '1.4rem 1.75rem',
          borderBottom: '1px solid var(--border-subtle, #e2e8f0)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '1rem',
          flexWrap: 'wrap',
          background: 'var(--bg-card, #ffffff)'
        }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.35rem', flexWrap: 'wrap' }}>
              <span className="badge badge-cyan" style={{ fontSize: '0.72rem', display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}>
                {source}
              </span>
              <span 
                className="badge"
                style={{
                  fontSize: '0.78rem',
                  fontWeight: 800,
                  backgroundColor: `rgba(${isHighFit ? '16, 185, 129' : isGoodFit ? '2, 132, 199' : '245, 158, 11'}, 0.15)`,
                  color: scoreColor,
                  borderColor: scoreColor
                }}
              >
                <Target size={13} style={{ display: 'inline', marginRight: '4px' }} />
                {score}% Resume Compatibility Match
              </span>
              <span className="badge badge-emerald" style={{ fontSize: '0.7rem', display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}>
                <ShieldCheck size={12} /> Ground-Truth Verified
              </span>
              {isLoading && (
                <span style={{ fontSize: '0.7rem', color: 'var(--accent-cyan)', display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}>
                  <Zap size={11} className="animate-spin-slow" /> Refreshing deep analysis...
                </span>
              )}
            </div>
            <h2 style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--text-primary, #090d16)', margin: '0 0 0.2rem 0', lineHeight: 1.25 }}>
              {title}
            </h2>
            <p style={{ fontSize: '0.9rem', color: 'var(--accent-cyan, #0284c7)', fontWeight: 700, margin: 0 }}>
              {company}
            </p>
          </div>

          <button
            onClick={onClose}
            className="btn btn-secondary btn-sm"
            style={{ 
              padding: '0.45rem', 
              borderRadius: '50%', 
              minWidth: '34px', 
              minHeight: '34px', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center',
              border: '1px solid var(--border-subtle, #e2e8f0)'
            }}
            aria-label="Close modal"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div style={{
          overflowY: 'auto',
          padding: '1.5rem 1.75rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '1.25rem',
          boxSizing: 'border-box'
        }}>
          {/* Resume Ground-Truth Evaluation Banner */}
          <div 
            style={{ 
              padding: '0.9rem 1.15rem', 
              borderRadius: '12px', 
              background: 'linear-gradient(135deg, rgba(2, 132, 199, 0.08) 0%, rgba(16, 185, 129, 0.08) 100%)', 
              border: '1px solid rgba(2, 132, 199, 0.3)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              gap: '0.75rem'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'rgba(2, 132, 199, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <FileText size={20} color="var(--accent-cyan, #0284c7)" />
              </div>
              <div>
                <div style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary, #090d16)' }}>
                  Why This Job Matched According to Your Resume
                </div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted, #64748b)' }}>
                  {matchedSkills.length} technical skills verified in your active resume claims • {domain}
                </div>
              </div>
            </div>
            {onNavigate && (
              <button 
                onClick={() => { onClose(); onNavigate('resume'); }}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.75rem', padding: '0.35rem 0.75rem', display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}
              >
                View Active Resume <ArrowRight size={12} />
              </button>
            )}
          </div>

          {/* Side-by-Side: Verified in Resume vs Missing Skill Gaps */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
            {/* Matched Skills */}
            <div style={{ padding: '1.15rem', background: 'rgba(16, 185, 129, 0.07)', borderRadius: '12px', border: '1px solid rgba(16, 185, 129, 0.3)' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <CheckCircle2 size={18} color="var(--accent-emerald, #059669)" />
                  <h4 style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--accent-emerald, #059669)', margin: 0 }}>
                    Skills Verified In Your Resume
                  </h4>
                </div>
                <span className="badge" style={{ fontSize: '0.7rem', backgroundColor: 'rgba(16, 185, 129, 0.2)', color: '#059669', borderColor: 'rgba(16, 185, 129, 0.4)' }}>
                  {matchedSkills.length} of {totalSkillsCount || '—'}
                </span>
              </div>
              {matchedSkills.length === 0 ? (
                <p style={{ fontSize: '0.78rem', color: 'var(--text-muted, #64748b)', margin: 0 }}>
                  No exact technical matches detected in your active resume for this role's listed requirements.
                </p>
              ) : (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.45rem' }}>
                  {matchedSkills.map((s, idx) => (
                    <span 
                      key={idx}
                      className="badge"
                      style={{
                        backgroundColor: 'rgba(16, 185, 129, 0.16)',
                        color: '#047857',
                        borderColor: 'rgba(16, 185, 129, 0.4)',
                        fontSize: '0.775rem',
                        padding: '0.3rem 0.65rem',
                        fontWeight: 700
                      }}
                    >
                      ✓ {s.skill_name}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Missing Skills */}
            <div style={{ padding: '1.15rem', background: 'rgba(245, 158, 11, 0.07)', borderRadius: '12px', border: '1px solid rgba(245, 158, 11, 0.3)' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <AlertTriangle size={18} color="var(--accent-amber, #d97706)" />
                  <h4 style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--accent-amber, #d97706)', margin: 0 }}>
                    Missing Skills (Skill Gaps)
                  </h4>
                </div>
                <span className="badge" style={{ fontSize: '0.7rem', backgroundColor: 'rgba(245, 158, 11, 0.2)', color: '#d97706', borderColor: 'rgba(245, 158, 11, 0.4)' }}>
                  {missingSkills.length} Gaps
                </span>
              </div>
              {missingSkills.length === 0 ? (
                <p style={{ fontSize: '0.78rem', color: 'var(--accent-emerald, #059669)', margin: 0, fontWeight: 700 }}>
                  ✨ Complete coverage! You satisfy all core technical skills specified for this opening.
                </p>
              ) : (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.45rem' }}>
                  {missingSkills.map((s, idx) => (
                    <span 
                      key={idx}
                      className="badge"
                      style={{
                        backgroundColor: 'rgba(245, 158, 11, 0.14)',
                        color: '#b45309',
                        borderColor: 'rgba(245, 158, 11, 0.35)',
                        fontSize: '0.775rem',
                        padding: '0.3rem 0.65rem',
                        fontWeight: 600
                      }}
                      title={s.recommendation || `Skill required: ${s.skill_name}`}
                    >
                      • {s.skill_name}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Score Breakdown (4 Weighted Pillars) */}
          <div style={{ padding: '1.15rem 1.35rem', background: 'var(--bg-tertiary, #f1f5f9)', borderRadius: '14px', border: '1px solid var(--border-subtle, #e2e8f0)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.9rem' }}>
              <h4 style={{ fontSize: '0.8rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted, #64748b)', margin: 0 }}>
                Multi-Pillar Match Score Breakdown
              </h4>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted, #64748b)' }}>
                Total: <strong style={{ color: scoreColor }}>{score}%</strong>
              </span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '1rem' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '0.35rem' }}>
                  <span style={{ color: 'var(--text-secondary, #334155)', fontWeight: 600 }}>Skill Overlap (55%)</span>
                  <span style={{ fontWeight: 800, color: 'var(--accent-cyan, #0284c7)' }}>{Math.round(breakdown.skill_overlap_score)}%</span>
                </div>
                <div style={{ width: '100%', height: '7px', backgroundColor: 'var(--border-subtle, #cbd5e1)', borderRadius: '4px', overflow: 'hidden' }}>
                  <div style={{ width: `${Math.min(100, Math.max(0, breakdown.skill_overlap_score))}%`, height: '100%', backgroundColor: 'var(--accent-cyan, #0284c7)', borderRadius: '4px' }} />
                </div>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '0.35rem' }}>
                  <span style={{ color: 'var(--text-secondary, #334155)', fontWeight: 600 }}>Seniority / Exp (20%)</span>
                  <span style={{ fontWeight: 800, color: 'var(--accent-emerald, #059669)' }}>{Math.round(breakdown.experience_fit_score)}%</span>
                </div>
                <div style={{ width: '100%', height: '7px', backgroundColor: 'var(--border-subtle, #cbd5e1)', borderRadius: '4px', overflow: 'hidden' }}>
                  <div style={{ width: `${Math.min(100, Math.max(0, breakdown.experience_fit_score))}%`, height: '100%', backgroundColor: 'var(--accent-emerald, #059669)', borderRadius: '4px' }} />
                </div>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '0.35rem' }}>
                  <span style={{ color: 'var(--text-secondary, #334155)', fontWeight: 600 }}>Domain Fit (15%)</span>
                  <span style={{ fontWeight: 800, color: '#7c3aed' }}>{Math.round(breakdown.domain_fit_score)}%</span>
                </div>
                <div style={{ width: '100%', height: '7px', backgroundColor: 'var(--border-subtle, #cbd5e1)', borderRadius: '4px', overflow: 'hidden' }}>
                  <div style={{ width: `${Math.min(100, Math.max(0, breakdown.domain_fit_score))}%`, height: '100%', backgroundColor: '#7c3aed', borderRadius: '4px' }} />
                </div>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: '0.35rem' }}>
                  <span style={{ color: 'var(--text-secondary, #334155)', fontWeight: 600 }}>Resume ATS (10%)</span>
                  <span style={{ fontWeight: 800, color: '#d97706' }}>{Math.round(breakdown.ats_readiness_score)}%</span>
                </div>
                <div style={{ width: '100%', height: '7px', backgroundColor: 'var(--border-subtle, #cbd5e1)', borderRadius: '4px', overflow: 'hidden' }}>
                  <div style={{ width: `${Math.min(100, Math.max(0, breakdown.ats_readiness_score))}%`, height: '100%', backgroundColor: '#d97706', borderRadius: '4px' }} />
                </div>
              </div>
            </div>
          </div>

          {/* Why This Matched Narrative & Detailed Evidence */}
          <div style={{ padding: '1.15rem 1.35rem', background: 'rgba(2, 132, 199, 0.05)', borderRadius: '14px', border: '1px solid rgba(2, 132, 199, 0.25)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.6rem' }}>
              <Sparkles size={18} color="var(--accent-cyan, #0284c7)" />
              <h4 style={{ fontSize: '0.875rem', fontWeight: 800, color: 'var(--accent-cyan, #0284c7)', margin: 0 }}>
                Detailed Match Evidence & Assessment
              </h4>
            </div>
            <p style={{ fontSize: '0.825rem', color: 'var(--text-primary, #090d16)', lineHeight: 1.55, marginBottom: '0.75rem' }}>
              {summaryText}
            </p>
            <ul style={{ margin: 0, paddingLeft: '1.25rem', fontSize: '0.8rem', color: 'var(--text-secondary, #334155)', display: 'flex', flexDirection: 'column', gap: '0.35rem', lineHeight: 1.45 }}>
              {whyMatches.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </div>

          {/* Recommended Preparation & Action Plan */}
          {actionPlan.length > 0 && (
            <div style={{ padding: '1rem 1.35rem', background: 'var(--bg-tertiary, #f1f5f9)', borderRadius: '12px', border: '1px solid var(--border-subtle, #e2e8f0)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', marginBottom: '0.5rem' }}>
                <Award size={16} color="var(--accent-amber, #d97706)" />
                <h4 style={{ fontSize: '0.8rem', fontWeight: 800, color: 'var(--text-muted, #64748b)', textTransform: 'uppercase', letterSpacing: '0.05em', margin: 0 }}>
                  Recommended Action Steps Before Applying
                </h4>
              </div>
              <ul style={{ margin: 0, paddingLeft: '1.25rem', fontSize: '0.8rem', color: 'var(--text-secondary, #334155)', display: 'flex', flexDirection: 'column', gap: '0.35rem', lineHeight: 1.45 }}>
                {actionPlan.map((act, idx) => (
                  <li key={idx}>{act}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div style={{
          padding: '1rem 1.75rem',
          borderTop: '1px solid var(--border-subtle, #e2e8f0)',
          display: 'flex',
          justifyContent: 'flex-end',
          alignItems: 'center',
          gap: '0.75rem',
          flexWrap: 'wrap',
          background: 'var(--bg-card, #ffffff)'
        }}>
          <button 
            onClick={onClose} 
            className="btn btn-secondary btn-sm" 
            style={{ padding: '0.5rem 1.15rem' }}
          >
            Close
          </button>
          <a
            href={targetApplyUrl && targetApplyUrl !== '#' ? (targetApplyUrl.startsWith('http') ? targetApplyUrl : `https://${targetApplyUrl}`) : 'https://www.google.com'}
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-primary btn-sm"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '0.45rem', padding: '0.5rem 1.25rem', fontWeight: 700 }}
          >
            Apply Directly on {source} <ExternalLink size={14} />
          </a>
        </div>
      </div>
    </div>
  );
};
